"""Immutable audit log helper. Every founder / cross-org / entitlement-critical action
writes here — used by the founder audit viewer + tenant impersonation banner.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import Request

from ..db import get_db, utc_now_iso


async def record(
    *,
    action: str,
    actor_user_id: Optional[str] = None,
    actor_role: Optional[str] = None,
    actor_email: Optional[str] = None,
    org_id: Optional[str] = None,
    target_type: Optional[str] = None,
    target_id: Optional[str] = None,
    reason: Optional[str] = None,
    meta: Optional[Dict[str, Any]] = None,
    impersonation_session_id: Optional[str] = None,
    request: Optional[Request] = None,
) -> str:
    """Insert an audit event. Never raises — audit failures must never break a request."""
    db = get_db()
    doc: Dict[str, Any] = {
        "action": action,
        "actor_user_id": actor_user_id,
        "actor_role": actor_role,
        "actor_email": actor_email,
        "org_id": org_id,
        "target_type": target_type,
        "target_id": target_id,
        "reason": reason,
        "meta": meta or {},
        "impersonation_session_id": impersonation_session_id,
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }
    if request is not None:
        try:
            doc["ip"] = (request.headers.get("x-forwarded-for") or request.client.host  # noqa: SIM108
                            if request.client else None)
            doc["user_agent"] = request.headers.get("user-agent")
            # Auto-tag the audit event with the current impersonation session id if the
            # caller didn't pass one — set by `current_user` when the token has imp_sid.
            if not impersonation_session_id:
                sid = getattr(request.state, "impersonation_session_id", None)
                if sid:
                    doc["impersonation_session_id"] = sid
        except Exception:  # noqa: BLE001
            pass
    try:
        r = await db.audit_events.insert_one(doc)
        return str(r.inserted_id)
    except Exception:  # noqa: BLE001
        return ""
