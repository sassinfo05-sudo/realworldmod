// REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import api from "@/lib/api";

/** Google (Emergent-managed) + Apple sign-in buttons. Apple only shows when configured. */
export default function SocialButtons({ mode = "login" }) {
    const [apple, setApple] = useState({ available: false });

    useEffect(() => {
        let alive = true;
        api.get("/auth/social-status")
            .then((r) => {
                if (!alive) return;
                setApple(r.data?.apple || { available: false });
            })
            .catch(() => {});
        return () => { alive = false; };
    }, []);

    function startGoogle() {
        const redirectUrl = window.location.origin + "/auth/callback";
        window.location.href =
            `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirectUrl)}`;
    }

    const label = mode === "signup" ? "Sign up with Google" : "Continue with Google";
    const appleLabel = mode === "signup" ? "Sign up with Apple" : "Continue with Apple";

    return (
        <div className="space-y-2" data-testid="social-auth-buttons">
            <Button
                type="button"
                variant="outline"
                onClick={startGoogle}
                className="w-full border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-800"
                data-testid="social-google-btn"
            >
                <svg viewBox="0 0 48 48" width="18" height="18" className="mr-2" aria-hidden="true">
                    <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.6l6.7-6.7C35.3 2.4 30 0 24 0 14.6 0 6.4 5.4 2.5 13.3l7.9 6.1C12.3 13.7 17.7 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.6c-.5 3-2.2 5.5-4.7 7.2l7.4 5.7c4.3-4 6.7-9.8 6.7-17.4z" />
                    <path fill="#FBBC05" d="M10.4 28.6c-.4-1.2-.7-2.4-.7-3.6s.3-2.4.7-3.6l-7.9-6.1C1 18.8 0 21.3 0 24s1 5.2 2.5 8.7l7.9-6.1z" />
                    <path fill="#34A853" d="M24 48c6 0 11.3-2 15.1-5.4l-7.4-5.7c-2 1.4-4.6 2.2-7.7 2.2-6.3 0-11.7-4.2-13.6-10l-7.9 6.1C6.4 42.6 14.6 48 24 48z" />
                </svg>
                {label}
            </Button>
            {apple.available && (
                <Button
                    type="button"
                    variant="outline"
                    onClick={() => { window.location.href = "/auth/apple/start"; }}
                    className="w-full bg-black hover:bg-zinc-800 text-white border-black"
                    data-testid="social-apple-btn"
                >
                    <svg viewBox="0 0 384 512" width="14" height="14" className="mr-2" aria-hidden="true">
                        <path fill="currentColor" d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zM254.8 89.7c30.8-36.5 28-69.8 27.1-81.7-27.2 1.6-58.7 18.5-76.6 39.4-19.8 22.4-31.4 50.1-28.9 79.4 29.4 2.3 56.3-12.8 78.4-37.1z" />
                    </svg>
                    {appleLabel}
                </Button>
            )}
            <div className="relative py-1">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-zinc-200"></span></div>
                <div className="relative flex justify-center text-xs uppercase tracking-widest">
                    <span className="bg-brand-surface px-2 text-zinc-500">or with email</span>
                </div>
            </div>
        </div>
    );
}
