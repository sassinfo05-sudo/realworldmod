# ZANELVO — HANDOFF ROUND 15 (for a NEW chat)

_Read `CURRENT_STATUS.md` first, then this, then `HANDOFF_ROUND_14.md` and earlier. Source code +
fresh test evidence override any older ✅ claims._

## 0. HOW TO CONTINUE (env is WIPED on import)
```bash
env | grep -i preview_endpoint                       # preview host changes per job
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && \
SEK=$(python3 -c "import secrets;print(secrets.token_urlsafe(32))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
SECRETS_ENC_KEY=$SEK
EMERGENT_LLM_KEY=<emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
SEED_DEMO_DATA=true
CORS_ORIGINS=*
EOF
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
pip install emergentintegrations --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile
sudo supervisorctl restart backend frontend && sleep 30 && curl -s localhost:8001/api/health
cat /app/memory/test_credentials.md      # FRESH passwords each seed
```
NOTE: `SEED_DEMO_DATA=true` is now REQUIRED to seed demo data (APP_ENV no longer seeds implicitly).

## 1. WHAT ROUND 15 SHIPPED & VERIFIED
### Pass 1 (earlier session)
Credential-incident cleanup + JWT rotation + secret scan; CORS fail-closed in prod;
production-seeding prevention + startup config validation; customer-facing `revenue-os`
DNS/brand cleanup. Plus (verified by testing agents 6/6 frontend + 5/5 backend): the
**cookie-auth migration** — HttpOnly `zv_access` + readable `zv_csrf` (CSRF double-submit),
NO raw JWT in localStorage, dual-mode (Bearer OR cookie), impersonation bug fixed.

### Pass 2 (this session) — all verified
- **Atomic two-cap metering** (services/usage.py): DB-backed, founder-editable per-plan AI
  hard cap + TOTAL variable-provider cap (Round-15 table). `enforce_budget(kind=...)` scoped
  pre-check for both; `confirm_reservation` race-safe FIFO per-cap confirm; `reserve()` fails
  closed (503) if metering down; pass-through kinds never consume margin; email meters the
  real org; plans API exposes both caps. Backend agent 5/5 + deterministic concurrency proof
  `backend/tests/test_atomic_metering.py` (20 concurrent AI holds settle $0.09 ≤ $0.10 cap).
- **XSS**: server-side sanitizers (`sanitize_svg`/`sanitize_html` nh3) confirmed on branding,
  uploads, legal; `Support.jsx` now escapes markdown before render. Regression
  `backend/tests/test_xss_sanitizer.py` (12 payloads) PASS.
- **Entitlement bypass fixed**: `PUT /api/store/products/{id}` enforces `subscriptions` when
  flipping `is_subscription=true` (free/launch → 402; autopilot → 200). Verified.
- **Voice tenant-routing**: resolved STRICTLY from the verified dialed number (`To` / Retell
  `call.to_number`); `?org_id=` + "first receptionist" fallback only in dev/test/demo; signatures
  verified before processing. Greeting path 200 verified.
- **Domain prod guard**: `get_provider()` never returns the SimulatedProvider in production
  (forces Cloudflare, which honestly reports Not-connected until creds exist) — a simulated
  domain can no longer reach Connected in prod.
- **Reproducible frontend build**: `yarn install --frozen-lockfile` + `yarn build` succeed.
See `CURRENT_STATUS.md` + `PRODUCTION_COST_MODEL.md`.

## 2. PRODUCTION_GATE: FAIL — residual P0/P1 backlog
Biggest remaining: Stripe Connect (replace tenant-pasted keys) + real sandbox probes; PayPal
signed sandbox; atomic inventory/gift-card + idempotent-webhook concurrency tests; inbound-email
status/state fix + identity + signature; outbound-webhook signature-doc + durable retries/DLQ;
custom-domain real SSL/ownership issuance; dedicated worker + durable queue for recurring jobs;
frontend HTML CSP as a deploy-time header; MFA fail-closed + atomic backup codes + distributed
staff-auth limiter; full server-side entitlement audit (product-subscription bypass done);
deployment manifests + CI; public-truth/legal/PRD/ledger reconciliation; a full fresh
production-mode regression. See `CURRENT_STATUS.md` §"RESIDUAL P0/P1 BACKLOG".

## 3. IMPORTANT GOTCHA
The pytest suite has HARDCODED STALE creds (`owner@demo.revenueos.com`) + no BASE_URL → it does
NOT run green as-is. Do not trust historical "all green" reports. Fix the fixtures first.

Do NOT push from the agent — use the chat's **Save to Github** button. Never modify `.env`
MONGO_URL/DB_NAME, never hardcode URLs, all backend routes under `/api`, UUIDs not ObjectId.

---
## Pass 4 addendum (this session) — what changed
See `CURRENT_STATUS.md` rows 16–27 for the evidence table. Highlights for the next agent:

* **Payments are now Stripe Connect-shaped.** `backend/app/services/stripe_connect.py` is the single place
  that touches the platform key. Tenants: `POST /api/store/payments/stripe/connect/start` → Stripe-hosted
  onboarding → `GET …/status`. `tenant_integrations.update()` REJECTS `stripe_secret_key` etc. (400).
  Store provider resolution (`_resolve_store_provider`) uses `tenant_charge_context()` (platform key +
  `Stripe-Account`). The sandbox platform key is in the Setup Center (encrypted). **Connect is NOT enabled
  on that sandbox** → everything reports "not available yet" honestly. Probe: `/api/founder/integrations/probe/stripe`.
* **Staff invitations**: collection `staff_invitations` (token_hash, expires_at, used_at, revoked_at).
  Accept endpoint is public + rate-limited + atomic. `staff_accounts.sessions_invalidated_at` (epoch seconds)
  is compared to the JWT `iat` in `deps.py`.
* **Founder bootstrap**: `backend/scripts/bootstrap_founder.py` (idempotent; `--reset`; `--prompt-password`).
  `seed.py` no longer creates a founder outside demo seeding.
* **Inbound email routing** only trusts `organizations.inbound_email` and `domains.state in (connected, active)`.
* **Visitor caps** live in `usage.enforce_budget` (context keys `visitor_ip`, `visitor_session`, set in
  `routes/ai.py::widget_message`). Ledger rows now carry those two fields.
* **Test harness**: `tests/conftest.py` injects a per-module `X-Forwarded-For` so the (wanted) login limiter
  does not create false failures. Legacy phase tests were re-pointed at `_creds` and current brand/plan names.

### Exact test commands (dev preview, from /app/backend)
```
python -m pytest -n 0 -q tests/test_store_stripe_webhook.py tests/test_staff_security.py \
  tests/test_entitlements_tiers.py tests/test_email_inbound_security.py tests/test_public_visitor_caps.py \
  tests/test_atomic_metering.py tests/test_commerce_concurrency.py tests/test_leader_lock.py \
  tests/test_webhook_retry.py tests/test_xss_sanitizer.py tests/test_prod_config_gate.py \
  tests/test_domain_providers.py tests/test_r15_reservation_concurrency.py
python -m pytest -q tests/            # full (legacy phase suites included; ~3 min; run in background)
```
