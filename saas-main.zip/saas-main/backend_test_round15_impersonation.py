#!/usr/bin/env python3
"""Round 15 RE-TEST: Impersonation fix verification ONLY.

Bug fix: /app/backend/app/deps.py now resolves founder actor from staff_accounts OR users
BEFORE the users lookup, fixing the "User not found" error when using impersonation tokens.

Test steps:
1. Login founder via POST /api/staff/auth/login (founder@zanelvo.com)
2. GET /api/founder/tenants → pick a target org id
3. POST /api/founder/impersonate/start {target_org_id, reason} → expect 200 with impersonation_token
4. Use impersonation_token as Bearer to GET /api/store/products → EXPECT 200 (previously 401)
5. POST /api/founder/impersonate/end → expect 200

Report each step's status code and confirm impersonation Bearer call returns 200 (not 401).
"""
import sys
import json
import requests

# Backend URL from frontend/.env
BACKEND_URL = "https://bootstrap-fix-2.preview.emergentagent.com"

# Credentials from /app/memory/test_credentials.md
import os
FOUNDER_EMAIL = os.environ.get("TEST_FOUNDER_EMAIL", "founder@zanelvo.com")


def _cred(email, env_key):
    """Load a test password from env or the gitignored creds file — never hardcoded in git."""
    v = os.environ.get(env_key)
    if v:
        return v
    try:
        import re
        txt = open("/app/memory/test_credentials.md", encoding="utf-8").read()
        m = re.search(re.escape(email) + r"[^`]*`([^`]+)`", txt)
        if m:
            return m.group(1)
    except Exception:
        pass
    return ""


FOUNDER_PASSWORD = _cred(FOUNDER_EMAIL, "TEST_FOUNDER_PASSWORD")

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'

def log(msg: str, color: str = Colors.RESET):
    print(f"{color}{msg}{Colors.RESET}")

def log_pass(msg: str):
    log(f"✅ {msg}", Colors.GREEN)

def log_fail(msg: str):
    log(f"❌ {msg}", Colors.RED)

def log_info(msg: str):
    log(f"ℹ️  {msg}", Colors.BLUE)

def log_step(step: int, msg: str):
    log(f"\n{'='*80}", Colors.BLUE)
    log(f"STEP {step}: {msg}", Colors.BLUE)
    log(f"{'='*80}", Colors.BLUE)

def main():
    log_info("\n" + "="*80)
    log_info("ROUND 15 IMPERSONATION FIX RE-TEST")
    log_info("Verifying impersonation tokens now work after deps.py fix")
    log_info("="*80)
    log_info(f"Backend URL: {BACKEND_URL}")
    log_info(f"Founder: {FOUNDER_EMAIL}")
    
    # STEP 1: Login founder
    log_step(1, "Login founder via POST /api/staff/auth/login")
    
    try:
        resp = requests.post(
            f"{BACKEND_URL}/api/staff/auth/login",
            json={"email": FOUNDER_EMAIL, "password": FOUNDER_PASSWORD},
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
        log_info(f"Status: {resp.status_code}")
        
        if resp.status_code != 200:
            log_fail(f"STEP 1 FAILED: Expected 200, got {resp.status_code}")
            log_info(f"Response: {resp.text[:500]}")
            return False
        
        data = resp.json()
        founder_token = data.get("access_token")
        
        if not founder_token:
            log_fail("STEP 1 FAILED: No access_token in response")
            log_info(f"Response keys: {list(data.keys())}")
            return False
        
        log_pass(f"STEP 1 PASSED: Founder logged in, token length: {len(founder_token)}")
        
    except Exception as e:
        log_fail(f"STEP 1 FAILED: Exception: {e}")
        return False
    
    founder_headers = {"Authorization": f"Bearer {founder_token}"}
    
    # STEP 2: Get list of tenants
    log_step(2, "GET /api/founder/tenants → pick a target org id")
    
    try:
        resp = requests.get(
            f"{BACKEND_URL}/api/founder/tenants",
            headers=founder_headers,
            timeout=30
        )
        
        log_info(f"Status: {resp.status_code}")
        
        if resp.status_code != 200:
            log_fail(f"STEP 2 FAILED: Expected 200, got {resp.status_code}")
            log_info(f"Response: {resp.text[:500]}")
            return False
        
        data = resp.json()
        tenants = data.get("tenants", [])
        
        if not tenants:
            log_fail("STEP 2 FAILED: No tenants found")
            return False
        
        # Find Demo Home Services org (known to have data)
        target_org_id = None
        target_org_name = None
        for tenant in tenants:
            if tenant.get("slug") == "demo-home-services":
                target_org_id = tenant["id"]
                target_org_name = tenant.get("name")
                break
        
        if not target_org_id:
            # Fallback to first tenant
            target_org_id = tenants[0]["id"]
            target_org_name = tenants[0].get("name")
        
        log_pass(f"STEP 2 PASSED: Found target org: {target_org_name} (org_id: {target_org_id})")
        
    except Exception as e:
        log_fail(f"STEP 2 FAILED: Exception: {e}")
        return False
    
    # STEP 3: Start impersonation
    log_step(3, "POST /api/founder/impersonate/start → expect 200 with impersonation_token")
    
    try:
        resp = requests.post(
            f"{BACKEND_URL}/api/founder/impersonate/start",
            json={"target_org_id": target_org_id, "reason": "round15 re-test"},
            headers={**founder_headers, "Content-Type": "application/json"},
            timeout=30
        )
        
        log_info(f"Status: {resp.status_code}")
        
        if resp.status_code != 200:
            log_fail(f"STEP 3 FAILED: Expected 200, got {resp.status_code}")
            log_info(f"Response: {resp.text[:500]}")
            return False
        
        data = resp.json()
        imp_token = data.get("impersonation_token")
        
        if not imp_token:
            log_fail("STEP 3 FAILED: No impersonation_token in response")
            log_info(f"Response keys: {list(data.keys())}")
            return False
        
        log_pass(f"STEP 3 PASSED: Impersonation started, token length: {len(imp_token)}")
        
    except Exception as e:
        log_fail(f"STEP 3 FAILED: Exception: {e}")
        return False
    
    # STEP 4: Use impersonation token to access tenant endpoint
    log_step(4, "Use impersonation_token as Bearer to GET /api/store/products → EXPECT 200")
    log_info("CRITICAL TEST: Previously failed with 401 'User not found'")
    
    try:
        imp_headers = {"Authorization": f"Bearer {imp_token}"}
        resp = requests.get(
            f"{BACKEND_URL}/api/store/products",
            headers=imp_headers,
            timeout=30
        )
        
        log_info(f"Status: {resp.status_code}")
        
        if resp.status_code == 401:
            log_fail(f"STEP 4 FAILED: Got 401 (impersonation token not working)")
            log_info(f"Response: {resp.text[:500]}")
            if "User not found" in resp.text:
                log_fail("ERROR: 'User not found' - The bug is NOT fixed!")
                log_fail("Root cause: deps.py still looking up user in 'users' before checking impersonation")
            return False
        
        if resp.status_code != 200:
            log_fail(f"STEP 4 FAILED: Expected 200, got {resp.status_code}")
            log_info(f"Response: {resp.text[:500]}")
            return False
        
        data = resp.json()
        products = data.get("products", [])
        
        log_pass(f"STEP 4 PASSED: Impersonation token works! Got 200 with {len(products)} products")
        log_pass("BUG FIX VERIFIED: Impersonation tokens now resolve founder from staff_accounts correctly")
        
    except Exception as e:
        log_fail(f"STEP 4 FAILED: Exception: {e}")
        return False
    
    # STEP 5: End impersonation
    log_step(5, "POST /api/founder/impersonate/end → expect 200")
    
    try:
        resp = requests.post(
            f"{BACKEND_URL}/api/founder/impersonate/end",
            headers={**founder_headers, "Content-Type": "application/json"},
            timeout=30
        )
        
        log_info(f"Status: {resp.status_code}")
        
        if resp.status_code != 200:
            log_fail(f"STEP 5 FAILED: Expected 200, got {resp.status_code}")
            log_info(f"Response: {resp.text[:500]}")
            return False
        
        log_pass("STEP 5 PASSED: Impersonation ended successfully")
        
    except Exception as e:
        log_fail(f"STEP 5 FAILED: Exception: {e}")
        return False
    
    # Summary
    log_info("\n" + "="*80)
    log_pass("ALL STEPS PASSED (5/5)")
    log_pass("IMPERSONATION FIX VERIFIED: deps.py now correctly resolves founder from staff_accounts")
    log_info("="*80)
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
