"""Deterministic tool registry for AI agents.

Every fact the LLM states about prices, hours, availability, existing bookings/invoices,
etc. MUST come from a tool. Tools are stateless, tenant-scoped, side-effect explicit.

Handlers accept a ToolContext (org_id, actor: 'agent'|'sandbox'|'human', deps) and
return a JSON-serialisable dict. Tools that mutate data (create_booking, take_message)
respect the ToolContext.actor — sandbox NEVER writes to the tenant DB.
"""
from __future__ import annotations

import logging
import secrets
from dataclasses import dataclass, field
from datetime import date as ddate, datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

from bson import ObjectId

from ..db import get_db, utc_now_iso

logger = logging.getLogger(__name__)


# ---------- Types ----------

@dataclass
class ToolContext:
    org_id: str
    actor: str = "agent"       # agent | sandbox | human
    website_slug: Optional[str] = None
    conversation_id: Optional[str] = None


@dataclass
class ToolResult:
    ok: bool
    data: Any = None
    error: Optional[str] = None
    citation_ids: List[str] = field(default_factory=list)


@dataclass
class ToolSpec:
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: Callable[..., Any]
    write: bool = False          # True → refused in sandbox mode
    citation_key: Optional[str] = None    # fact-key emitted for auditing


# ---------- Handlers ----------

async def _t_get_services(ctx: ToolContext) -> ToolResult:
    db = get_db()
    cur = db.service_offerings.find({"org_id": ctx.org_id, "active": True}).sort("name", 1)
    out = []
    async for d in cur:
        out.append({
            "id": str(d["_id"]),
            "name": d.get("name"),
            "description": d.get("description"),
            "duration_minutes": d.get("duration_minutes"),
            "price_cents": d.get("price_cents"),
            "currency": d.get("currency", "USD"),
            "bookable": bool(d.get("bookable", True)),
        })
    return ToolResult(ok=True, data={"services": out}, citation_ids=[f"service:{s['id']}" for s in out])


async def _t_get_hours(ctx: ToolContext) -> ToolResult:
    """Return business hours from the business profile snapshot."""
    db = get_db()
    prof = await db.business_profiles.find_one({"org_id": ctx.org_id})
    hours = (prof or {}).get("hours") or []
    return ToolResult(ok=True, data={"hours": hours}, citation_ids=["profile:hours"])


async def _t_get_locations(ctx: ToolContext) -> ToolResult:
    db = get_db()
    prof = await db.business_profiles.find_one({"org_id": ctx.org_id})
    locs = (prof or {}).get("locations") or []
    return ToolResult(ok=True, data={"locations": locs}, citation_ids=["profile:locations"])


async def _t_get_policies(ctx: ToolContext) -> ToolResult:
    """Return the free-text policies + booking rules the owner has set."""
    db = get_db()
    prof = await db.business_profiles.find_one({"org_id": ctx.org_id})
    policies = (prof or {}).get("policies") or {}
    return ToolResult(ok=True, data={"policies": policies}, citation_ids=["profile:policies"])


def _parse_date_input(v: str, field_name: str) -> ddate:
    if not isinstance(v, str) or not v:
        raise ValueError(f"{field_name} required (YYYY-MM-DD)")
    try:
        if "T" in v:
            return datetime.fromisoformat(v.replace("Z", "+00:00")).date()
        return ddate.fromisoformat(v)
    except ValueError:
        raise ValueError(f"{field_name} must be YYYY-MM-DD; got {v!r}")


async def _t_get_availability(ctx: ToolContext, service_id: str,
                                  date_from: Optional[str] = None,
                                  date_to: Optional[str] = None,
                                  limit: int = 8) -> ToolResult:
    from ..routes.bookings import _compute_availability
    try:
        df = _parse_date_input(date_from, "date_from") if date_from else ddate.today()
        dt = _parse_date_input(date_to, "date_to") if date_to else df + timedelta(days=14)
    except ValueError as e:
        return ToolResult(ok=False, error=str(e))
    # Never look up availability for a completed date. Snap to today so the LLM
    # cannot accidentally show a slot in the past.
    today = ddate.today()
    if df < today:
        df = today
    if dt < df:
        dt = df + timedelta(days=14)
    if not ObjectId.is_valid(service_id):
        return ToolResult(ok=False, error="invalid service_id")
    try:
        avail = await _compute_availability(ctx.org_id, service_id,
                                                 df.isoformat(), dt.isoformat(), staff_id=None)
    except Exception as e:  # noqa: BLE001
        return ToolResult(ok=False, error=f"availability lookup failed: {e}")
    slots = (avail.get("slots") or [])[: max(1, min(30, int(limit or 8)))]
    return ToolResult(ok=True, data={"service_id": service_id, "slots": slots},
                        citation_ids=[f"availability:{service_id}"])


async def _t_create_booking(ctx: ToolContext, service_id: str, start_at: str,
                                name: str, email: str, phone: Optional[str] = None,
                                customer_notes: Optional[str] = None,
                                staff_id: Optional[str] = None) -> ToolResult:
    """Real booking creation. Refused in sandbox mode."""
    if ctx.actor == "sandbox":
        return ToolResult(ok=True,
                            data={"sandbox": True,
                                    "message": "Sandbox mode — no real booking created."})
    if not (name and email):
        return ToolResult(ok=False, error="name and email required")
    from ..routes.bookings import _compute_availability
    db = get_db()
    if not ObjectId.is_valid(service_id):
        return ToolResult(ok=False, error="invalid service_id")
    svc = await db.service_offerings.find_one({"_id": ObjectId(service_id), "org_id": ctx.org_id})
    if not svc:
        return ToolResult(ok=False, error="service not found")
    try:
        start_dt = datetime.fromisoformat(start_at.replace("Z", "+00:00")).astimezone(timezone.utc)
    except ValueError:
        return ToolResult(ok=False, error="invalid start_at ISO datetime")
    if start_dt <= datetime.now(timezone.utc):
        return ToolResult(ok=False, error="start_at must be in the future — the visitor cannot book a past time")
    end_dt = start_dt + timedelta(minutes=svc["duration_minutes"])
    # Pick a staff if none supplied
    resolved_staff_id = staff_id
    if not resolved_staff_id:
        s_doc = await db.staff.find_one({"org_id": ctx.org_id, "active": True})
        if s_doc:
            resolved_staff_id = str(s_doc["_id"])
    # Verify slot is still open by comparing against fresh availability.
    df = start_dt.date()
    dt = df + timedelta(days=1)
    avail = await _compute_availability(ctx.org_id, service_id, df.isoformat(), dt.isoformat(),
                                             staff_id=resolved_staff_id)
    target_start = start_dt.isoformat().replace("+00:00", "Z")
    if not any(s.get("start_at") == target_start for s in (avail.get("slots") or [])):
        return ToolResult(ok=False, error="slot no longer available")
    # Contact upsert (chat/call channel). If the org has hit its contacts cap and this
    # visitor is a NEW contact, the upsert raises 402 — we translate that into a graceful
    # refusal so the AI doesn't half-book without a lead record.
    from ..routes.crm import upsert_contact_from_form
    from fastapi import HTTPException as _HTTPException
    try:
        contact_id = await upsert_contact_from_form(
            db, ctx.org_id,
            {"name": name, "email": email, "phone": phone or "", "message": customer_notes or ""},
            source="ai_chat",
        )
    except _HTTPException as he:
        if he.status_code == 402:
            return ToolResult(ok=False,
                                 error=("This business is at capacity for new customers right now. "
                                        "Please try again shortly or leave a message via the contact form."))
        raise
    booking_number = f"B-{datetime.now(timezone.utc).year}-{secrets.token_hex(2)}"
    doc = {
        "org_id": ctx.org_id,
        "service_id": service_id,
        "staff_id": resolved_staff_id,
        "contact_id": contact_id,
        "start_at": start_dt.isoformat().replace("+00:00", "Z"),
        "end_at": end_dt.isoformat().replace("+00:00", "Z"),
        "buffer_before_minutes": svc.get("buffer_before_minutes", 0),
        "buffer_after_minutes": svc.get("buffer_after_minutes", 15),
        "status": "confirmed",
        "source": "ai_chat",
        "booking_number": booking_number,
        "customer_name": name,
        "customer_email": email,
        "customer_phone": phone,
        "customer_notes": customer_notes,
        "tokens": {"cancel": secrets.token_urlsafe(20), "reschedule": secrets.token_urlsafe(20)},
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }
    ins = await db.bookings.insert_one(doc)
    bid = str(ins.inserted_id)
    from ..routes.crm import _record_interaction
    await _record_interaction(db, ctx.org_id, contact_id=contact_id,
                                 type_="booking_created",
                                 summary=f"AI chat booked {svc['name']} for {name} at {doc['start_at']}",
                                 ref_type="booking", ref_id=bid,
                                 meta={"via": "ai_chat", "conversation_id": ctx.conversation_id})
    return ToolResult(ok=True,
                        data={"booking_id": bid, "booking_number": booking_number,
                                "start_at": doc["start_at"], "service": svc["name"],
                                "contact_id": contact_id},
                        citation_ids=[f"booking:{bid}"])


async def _t_take_message(ctx: ToolContext, name: str, email: str,
                              phone: Optional[str] = None,
                              message: Optional[str] = None) -> ToolResult:
    if ctx.actor == "sandbox":
        return ToolResult(ok=True, data={"sandbox": True})
    if not (name and email):
        return ToolResult(ok=False, error="name and email required")
    db = get_db()
    from ..routes.crm import upsert_contact_from_form, _record_interaction
    contact_id = await upsert_contact_from_form(
        db, ctx.org_id,
        {"name": name, "email": email, "phone": phone or "", "message": message or ""},
        source="ai_chat",
    )
    await _record_interaction(db, ctx.org_id, contact_id=contact_id,
                                 type_="ai_message_captured",
                                 summary=f"AI captured a message from {name}: {(message or '')[:120]}",
                                 ref_type="contact", ref_id=contact_id,
                                 meta={"via": "ai_chat", "conversation_id": ctx.conversation_id,
                                        "message": message})
    return ToolResult(ok=True, data={"contact_id": contact_id},
                        citation_ids=[f"contact:{contact_id}"])


async def _t_get_booking(ctx: ToolContext, booking_number: Optional[str] = None,
                            email: Optional[str] = None) -> ToolResult:
    """Look up a booking by number or by the visitor's email + upcoming date."""
    db = get_db()
    q: Dict[str, Any] = {"org_id": ctx.org_id}
    if booking_number:
        q["booking_number"] = booking_number
    elif email:
        q["customer_email"] = email
    else:
        return ToolResult(ok=False, error="need booking_number or email")
    docs = []
    async for d in db.bookings.find(q).sort("start_at", -1).limit(3):
        docs.append({
            "id": str(d["_id"]), "booking_number": d.get("booking_number"),
            "status": d.get("status"), "start_at": d.get("start_at"),
            "customer_name": d.get("customer_name"),
        })
    return ToolResult(ok=True, data={"bookings": docs},
                        citation_ids=[f"booking:{b['id']}" for b in docs])


async def _t_get_invoice(ctx: ToolContext, number: Optional[str] = None,
                            email: Optional[str] = None) -> ToolResult:
    db = get_db()
    q: Dict[str, Any] = {"org_id": ctx.org_id}
    if number:
        q["number"] = number
    elif email:
        # Match via contact
        contact = await db.contacts.find_one({"org_id": ctx.org_id, "emails": email})
        if not contact:
            return ToolResult(ok=True, data={"invoices": []})
        q["contact_id"] = str(contact["_id"])
    else:
        return ToolResult(ok=False, error="need invoice number or email")
    docs = []
    async for d in db.invoices.find(q).sort("created_at", -1).limit(3):
        docs.append({
            "id": str(d["_id"]), "number": d.get("number"),
            "status": d.get("status"), "total_cents": d.get("total_cents"),
            "amount_paid_cents": d.get("amount_paid_cents", 0),
            "due_at": d.get("due_at"),
        })
    return ToolResult(ok=True, data={"invoices": docs},
                        citation_ids=[f"invoice:{i['id']}" for i in docs])


# ---------- Registry ----------

TOOLS: Dict[str, ToolSpec] = {
    "get_services": ToolSpec(
        name="get_services",
        description="List all bookable services with prices, durations and descriptions.",
        input_schema={"type": "object", "properties": {}, "required": []},
        handler=_t_get_services,
    ),
    "get_hours": ToolSpec(
        name="get_hours",
        description="Return the business's public opening hours by day of week.",
        input_schema={"type": "object", "properties": {}, "required": []},
        handler=_t_get_hours,
    ),
    "get_locations": ToolSpec(
        name="get_locations",
        description="Return the physical locations / service area of the business.",
        input_schema={"type": "object", "properties": {}, "required": []},
        handler=_t_get_locations,
    ),
    "get_policies": ToolSpec(
        name="get_policies",
        description="Return booking / cancellation / payment policies as free text.",
        input_schema={"type": "object", "properties": {}, "required": []},
        handler=_t_get_policies,
    ),
    "get_availability": ToolSpec(
        name="get_availability",
        description="Return open booking slots for a service between two dates. "
                       "Pass service_id (required); optionally date_from and date_to (YYYY-MM-DD).",
        input_schema={"type": "object", "properties": {
            "service_id": {"type": "string"},
            "date_from": {"type": "string"}, "date_to": {"type": "string"},
            "limit": {"type": "integer"},
        }, "required": ["service_id"]},
        handler=_t_get_availability,
    ),
    "create_booking": ToolSpec(
        name="create_booking",
        description="Book a real appointment. All fields required: service_id, start_at (ISO), "
                       "name, email. Optional: phone, customer_notes.",
        input_schema={"type": "object", "properties": {
            "service_id": {"type": "string"}, "start_at": {"type": "string"},
            "name": {"type": "string"}, "email": {"type": "string"},
            "phone": {"type": "string"}, "customer_notes": {"type": "string"},
            "staff_id": {"type": "string"},
        }, "required": ["service_id", "start_at", "name", "email"]},
        handler=_t_create_booking, write=True,
    ),
    "take_message": ToolSpec(
        name="take_message",
        description="Save a lead when you cannot fully help. Captures name, email, phone, message.",
        input_schema={"type": "object", "properties": {
            "name": {"type": "string"}, "email": {"type": "string"},
            "phone": {"type": "string"}, "message": {"type": "string"},
        }, "required": ["name", "email"]},
        handler=_t_take_message, write=True,
    ),
    "get_booking": ToolSpec(
        name="get_booking",
        description="Look up a booking by booking_number or by customer email.",
        input_schema={"type": "object", "properties": {
            "booking_number": {"type": "string"}, "email": {"type": "string"},
        }, "required": []},
        handler=_t_get_booking,
    ),
    "get_invoice": ToolSpec(
        name="get_invoice",
        description="Look up an invoice by number or by customer email.",
        input_schema={"type": "object", "properties": {
            "number": {"type": "string"}, "email": {"type": "string"},
        }, "required": []},
        handler=_t_get_invoice,
    ),
}


def tool_spec_summary(tool_names: List[str]) -> str:
    """Human/LLM-readable summary of the tools currently allowed."""
    lines = []
    for n in tool_names:
        t = TOOLS.get(n)
        if not t:
            continue
        req = t.input_schema.get("required") or []
        props = list((t.input_schema.get("properties") or {}).keys())
        arg_hint = ", ".join(f"{p}{'*' if p in req else ''}" for p in props) or "(no args)"
        lines.append(f"- {t.name}({arg_hint}): {t.description}")
    return "\n".join(lines)


async def run_tool(name: str, args: Dict[str, Any], ctx: ToolContext) -> ToolResult:
    spec = TOOLS.get(name)
    if not spec:
        return ToolResult(ok=False, error=f"unknown tool {name!r}")
    # Reject writes in sandbox — but let read tools flow.
    if spec.write and ctx.actor == "sandbox":
        return ToolResult(ok=True, data={"sandbox": True,
                                            "message": f"Sandbox — {name} was not executed."})
    try:
        return await spec.handler(ctx, **(args or {}))
    except TypeError as e:
        return ToolResult(ok=False, error=f"bad args to {name}: {e}")
    except Exception as e:  # noqa: BLE001
        logger.exception("Tool %s failed: %s", name, e)
        return ToolResult(ok=False, error=f"tool crashed: {e}")
