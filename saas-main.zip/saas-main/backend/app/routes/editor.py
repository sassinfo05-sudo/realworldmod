"""Visual editor endpoints — draft-state mutations, page CRUD, publishing, revisions.

All routes are org-scoped via `require_org`; the caller can only touch their own site.
Every write bumps `draft_updated_at` so the UI can show autosave state.
"""
import uuid
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import Block, Page, Revision, User, Website, WebsiteTheme
from ..services.publishing import (
    ensure_unique_slug, is_subdomain_available, normalize_subdomain,
    rollback_to_revision, slugify, snapshot_publish, validate_subdomain,
)

router = APIRouter(prefix="/editor", tags=["editor"])


# ---------------- helpers ----------------

async def _load_website(org_id: str) -> Website:
    from ..services.sites import active_website_doc
    doc = await active_website_doc(org_id)
    if not doc:
        raise HTTPException(404, "No website found for this workspace")
    return Website.from_mongo(doc)


def _find_page(website: Website, slug: str) -> Page:
    p = next((p for p in website.pages if p.slug == slug), None)
    if not p:
        raise HTTPException(404, f"Page '{slug}' not found in draft")
    return p


def _find_block(website: Website, block_id: str):
    for page in website.pages:
        for i, b in enumerate(page.blocks):
            if b.id == block_id:
                return page, i, b
    raise HTTPException(404, "Block not found")


async def _persist_draft(website: Website) -> None:
    db = get_db()
    await db.websites.update_one(
        {"_id": ObjectId(website.id)},
        {"$set": {
            "theme": website.theme.model_dump(),
            "pages": [p.model_dump() for p in website.pages],
            "nav_order": website.nav_order,
            "draft_updated_at": utc_now_iso(),
            "updated_at": utc_now_iso(),
        }},
    )


# ---------------- state ----------------

@router.get("/website")
async def get_editor_state(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    return {
        "website": website.model_dump(),
        "public_url_path": f"/site/{website.slug}" if website.slug else None,
    }


class ThemePatch(BaseModel):
    theme: Dict[str, Any]


@router.patch("/website/theme")
async def patch_theme(patch: ThemePatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    merged = {**website.theme.model_dump(), **patch.theme}
    website.theme = WebsiteTheme(**merged)
    await _persist_draft(website)
    return {"ok": True, "theme": website.theme.model_dump()}


class NavOrderPatch(BaseModel):
    nav_order: List[str]


@router.patch("/website/nav-order")
async def patch_nav_order(patch: NavOrderPatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    valid = {p.slug for p in website.pages}
    if any(s not in valid for s in patch.nav_order):
        raise HTTPException(400, "nav_order references unknown page slug")
    website.nav_order = patch.nav_order
    await _persist_draft(website)
    return {"ok": True, "nav_order": website.nav_order}


class SnapshotSetReq(BaseModel):
    """Bulk replace draft state — used by editor undo/redo/autosave."""
    theme: Dict[str, Any]
    pages: List[Dict[str, Any]]
    nav_order: List[str]


@router.post("/website/snapshot-set")
async def snapshot_set(req: SnapshotSetReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    # Validate through pydantic
    website.theme = WebsiteTheme(**{**website.theme.model_dump(), **req.theme})
    try:
        pages = [Page(**p) for p in req.pages]
    except Exception as e:
        raise HTTPException(400, f"Invalid pages: {e}")
    website.pages = pages
    # Filter nav_order to existing slugs
    valid = {p.slug for p in pages}
    website.nav_order = [s for s in req.nav_order if s in valid]
    for s in valid:
        if s not in website.nav_order:
            website.nav_order.append(s)
    await _persist_draft(website)
    return {"ok": True, "draft_updated_at": utc_now_iso()}


# ---------------- pages ----------------

class PageCreate(BaseModel):
    title: str
    slug: Optional[str] = None
    seo: Dict[str, Any] = Field(default_factory=dict)


@router.post("/website/pages")
async def create_page(req: PageCreate, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    slug = slugify(req.slug or req.title)
    if any(p.slug == slug for p in website.pages):
        # ensure unique within this website
        n = 1
        while any(p.slug == f"{slug}-{n}" for p in website.pages):
            n += 1
        slug = f"{slug}-{n}"
    page = Page(id=str(uuid.uuid4()), slug=slug, title=req.title, seo=req.seo, blocks=[])
    website.pages.append(page)
    if slug not in website.nav_order:
        website.nav_order.append(slug)
    await _persist_draft(website)
    return page.model_dump()


class PagePatch(BaseModel):
    title: Optional[str] = None
    slug: Optional[str] = None
    seo: Optional[Dict[str, Any]] = None
    hidden: Optional[bool] = None


@router.patch("/website/pages/{slug}")
async def patch_page(slug: str, patch: PagePatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    page = _find_page(website, slug)
    old_slug = page.slug
    if patch.title is not None:
        page.title = patch.title
    if patch.seo is not None:
        incoming = dict(patch.seo)
        # Never store a page password in plaintext — hash it server-side and drop
        # the plaintext so it can't be published or returned to any client.
        if "password" in incoming:
            pw = (incoming.pop("password") or "").strip()
            if pw:
                from ..security import hash_password
                incoming["password_hash"] = hash_password(pw)
            else:
                incoming["password_hash"] = ""  # empty clears protection
        merged = {**page.seo, **incoming}
        if incoming.get("password_hash") == "":
            merged.pop("password_hash", None)
        merged.pop("password", None)  # belt-and-braces: strip any legacy plaintext
        page.seo = merged
    if patch.hidden is not None:
        page.hidden = patch.hidden
    if patch.slug is not None:
        new_slug = slugify(patch.slug)
        if new_slug != old_slug:
            if any(p.slug == new_slug for p in website.pages):
                raise HTTPException(409, f"Page slug '{new_slug}' already exists")
            page.slug = new_slug
            website.nav_order = [new_slug if s == old_slug else s for s in website.nav_order]
    await _persist_draft(website)
    return page.model_dump()


@router.post("/website/pages/{slug}/duplicate")
async def duplicate_page(slug: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    page = _find_page(website, slug)
    base = f"{page.slug}-copy"
    new_slug = base
    n = 1
    while any(p.slug == new_slug for p in website.pages):
        n += 1
        new_slug = f"{base}-{n}"
    dup = Page(
        id=str(uuid.uuid4()),
        slug=new_slug,
        title=f"{page.title} (copy)",
        seo={**page.seo},
        blocks=[Block(id=str(uuid.uuid4()), type=b.type, variant=b.variant,
                      props={**b.props}, style={**b.style}) for b in page.blocks],
    )
    website.pages.append(dup)
    website.nav_order.append(new_slug)
    await _persist_draft(website)
    return dup.model_dump()


@router.delete("/website/pages/{slug}")
async def delete_page(slug: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    if len(website.pages) <= 1:
        raise HTTPException(400, "Cannot delete the last page")
    _find_page(website, slug)  # 404 if missing
    website.pages = [p for p in website.pages if p.slug != slug]
    website.nav_order = [s for s in website.nav_order if s != slug]
    await _persist_draft(website)
    return {"ok": True}


# ---------------- blocks ----------------

class BlockCreate(BaseModel):
    type: str
    variant: str = "a"
    props: Dict[str, Any] = Field(default_factory=dict)
    style: Dict[str, Any] = Field(default_factory=dict)
    position: Optional[int] = None  # index to insert at; append if None


@router.post("/website/pages/{slug}/blocks")
async def create_block(slug: str, req: BlockCreate, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    if req.type not in {b["type"] for b in BLOCK_LIBRARY} | {"booking", "chat_widget"}:
        raise HTTPException(400, f"Unknown block type: {req.type}")
    website = await _load_website(org_id)
    page = _find_page(website, slug)
    block = Block(id=str(uuid.uuid4()), type=req.type, variant=req.variant,
                  props=req.props, style=req.style)
    if req.position is None or req.position >= len(page.blocks):
        page.blocks.append(block)
    else:
        page.blocks.insert(max(0, req.position), block)
    await _persist_draft(website)
    return block.model_dump()


class BlockPatch(BaseModel):
    """Partial update of a single block. `props`/`style` are merged; `replace_props`
    fully replaces `props`. Unknown fields are rejected with 422 (no silent no-ops)."""
    model_config = {"extra": "forbid"}
    variant: Optional[str] = None
    hidden: Optional[bool] = None
    props: Optional[Dict[str, Any]] = None  # merged with existing
    style: Optional[Dict[str, Any]] = None
    replace_props: Optional[Dict[str, Any]] = None  # full replace


@router.patch("/website/blocks/{block_id}")
async def patch_block(block_id: str, patch: BlockPatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    page, idx, block = _find_block(website, block_id)
    if patch.variant is not None:
        block.variant = patch.variant
    if patch.hidden is not None:
        block.hidden = patch.hidden
    if patch.replace_props is not None:
        block.props = patch.replace_props
    elif patch.props is not None:
        block.props = {**block.props, **patch.props}
    if patch.style is not None:
        block.style = {**block.style, **patch.style}
    page.blocks[idx] = block
    await _persist_draft(website)
    return block.model_dump()


@router.post("/website/blocks/{block_id}/duplicate")
async def duplicate_block(block_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    page, idx, block = _find_block(website, block_id)
    dup = Block(id=str(uuid.uuid4()), type=block.type, variant=block.variant,
                props={**block.props}, style={**block.style})
    page.blocks.insert(idx + 1, dup)
    await _persist_draft(website)
    return dup.model_dump()


# ---------------- reusable saved sections (Round 11) ----------------

class SaveSectionReq(BaseModel):
    model_config = {"extra": "forbid"}
    name: str = Field(min_length=1, max_length=80)


def _saved_out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {"id": str(d["_id"]), "name": d.get("name"), "type": d.get("type"), "variant": d.get("variant", "a"),
            "props": d.get("props", {}), "style": d.get("style", {}), "created_at": d.get("created_at")}


@router.get("/saved-sections")
async def list_saved_sections(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = [_saved_out(d) async for d in db.saved_sections.find({"org_id": org_id}).sort("created_at", -1).limit(100)]
    return {"sections": rows}


@router.post("/website/blocks/{block_id}/save-as-section")
async def save_block_as_section(block_id: str, req: SaveSectionReq, user: User = Depends(current_user),
                                org_id: str = Depends(require_org)):
    """Store a copy of a block (type/variant/props/style) as a reusable section for this workspace."""
    db = get_db()
    website = await _load_website(org_id)
    _page, _idx, block = _find_block(website, block_id)
    if await db.saved_sections.count_documents({"org_id": org_id}) >= 100:
        raise HTTPException(400, "Saved-section limit reached (100). Delete some first.")
    doc = {"org_id": org_id, "name": req.name.strip(), "type": block.type, "variant": block.variant,
           "props": dict(block.props), "style": dict(block.style), "source_block_id": block_id,
           "created_by": user.id, "created_at": utc_now_iso()}
    res = await db.saved_sections.insert_one(doc)
    doc["_id"] = res.inserted_id
    return _saved_out(doc)


@router.post("/website/pages/{slug}/blocks/from-saved/{section_id}")
async def insert_saved_section(slug: str, section_id: str, position: Optional[int] = None,
                               user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    try:
        saved = await db.saved_sections.find_one({"_id": ObjectId(section_id), "org_id": org_id})
    except Exception:  # noqa: BLE001
        saved = None
    if not saved:
        raise HTTPException(404, "Saved section not found")
    website = await _load_website(org_id)
    page = _find_page(website, slug)
    block = Block(id=str(uuid.uuid4()), type=saved["type"], variant=saved.get("variant", "a"),
                  props=dict(saved.get("props", {})), style=dict(saved.get("style", {})))
    if position is None or position >= len(page.blocks):
        page.blocks.append(block)
    else:
        page.blocks.insert(max(0, position), block)
    await _persist_draft(website)
    return block.model_dump()


@router.delete("/saved-sections/{section_id}")
async def delete_saved_section(section_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    try:
        res = await db.saved_sections.delete_one({"_id": ObjectId(section_id), "org_id": org_id})
    except Exception:  # noqa: BLE001
        raise HTTPException(404, "Saved section not found")
    if not res.deleted_count:
        raise HTTPException(404, "Saved section not found")
    return {"ok": True}


@router.delete("/website/blocks/{block_id}")
async def delete_block(block_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    page, idx, block = _find_block(website, block_id)
    del page.blocks[idx]
    await _persist_draft(website)
    return {"ok": True}


class BlockReorder(BaseModel):
    block_ids: List[str]  # new full order for this page


@router.post("/website/pages/{slug}/reorder")
async def reorder_blocks(slug: str, req: BlockReorder, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    website = await _load_website(org_id)
    page = _find_page(website, slug)
    by_id = {b.id: b for b in page.blocks}
    if set(req.block_ids) != set(by_id.keys()):
        raise HTTPException(400, "reorder ids must match existing block set")
    page.blocks = [by_id[i] for i in req.block_ids]
    await _persist_draft(website)
    return {"ok": True, "block_order": [b.id for b in page.blocks]}


# ---------------- publish / rollback / revisions ----------------

class PublishReq(BaseModel):
    slug: Optional[str] = None
    note: Optional[str] = None


@router.get("/website/slug-available")
async def slug_available(slug: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Live availability + validity check for a customer's zanelvo.com/site/<name> address."""
    website = await _load_website(org_id)
    cand = normalize_subdomain(slug)
    err = validate_subdomain(cand)
    if err:
        return {"available": False, "normalized": cand, "reason": err}
    ok = await is_subdomain_available(cand, exclude_website_id=website.id)
    return {"available": ok, "normalized": cand,
            "reason": None if ok else "That address is already taken. Please choose another."}


@router.post("/website/publish")
async def publish_site(req: PublishReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    website = await _load_website(org_id)

    # Resolve slug: user override → existing slug → derive from business profile
    desired = req.slug
    if desired:
        # Customer is choosing their zanelvo.com/site/<name> address → strict rules.
        cand = normalize_subdomain(desired)
        err = validate_subdomain(cand)
        if err:
            raise HTTPException(400, err)
        if cand != website.slug and not await is_subdomain_available(cand, exclude_website_id=website.id):
            raise HTTPException(409, "That address is already taken. Please choose another.")
        final = cand
    elif website.slug:
        final = website.slug
    else:
        profile = await db.business_profiles.find_one({"org_id": org_id})
        final = await ensure_unique_slug(slugify((profile or {}).get("business_name") or "site"),
                                          exclude_website_id=website.id)

    if final != website.slug:
        old = website.slug
        website.slug = final
        if old and old != final and old not in website.slug_history:
            website.slug_history.append(old)
        await db.websites.update_one(
            {"_id": ObjectId(website.id)},
            {"$set": {"slug": website.slug, "slug_history": website.slug_history,
                      "updated_at": utc_now_iso()}},
        )

    revision = await snapshot_publish(website, req.note, user.id)
    return {
        "ok": True,
        "revision_id": revision.id,
        "slug": website.slug,
        "public_url_path": f"/site/{website.slug}",
        "published_at": utc_now_iso(),
    }


@router.get("/website/revisions")
async def list_revisions(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    website = await _load_website(org_id)
    cursor = db.revisions.find({"org_id": org_id, "website_id": website.id}).sort("created_at", -1).limit(50)
    out = []
    async for doc in cursor:
        out.append({
            "id": str(doc["_id"]),
            "kind": doc.get("kind"),
            "note": doc.get("note"),
            "created_at": doc.get("created_at"),
            "author_user_id": doc.get("author_user_id"),
            "rolled_back_from_id": doc.get("rolled_back_from_id"),
            "pages_count": len(doc.get("pages") or []),
        })
    return {"revisions": out}


@router.get("/website/revisions/{rev_id}")
async def preview_revision(rev_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.revisions.find_one({"_id": ObjectId(rev_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Revision not found")
    return Revision.from_mongo(doc).model_dump()


class RollbackReq(BaseModel):
    note: Optional[str] = None


@router.post("/website/revisions/{rev_id}/rollback")
async def rollback(rev_id: str, req: RollbackReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    website = await _load_website(org_id)
    doc = await db.revisions.find_one({"_id": ObjectId(rev_id), "org_id": org_id,
                                        "website_id": website.id})
    if not doc:
        raise HTTPException(404, "Revision not found")
    rev = Revision.from_mongo(doc)
    new_rev = await rollback_to_revision(website, rev, user.id)
    return {"ok": True, "new_revision_id": new_rev.id}


# ---------------- block library ----------------

BLOCK_LIBRARY = [
    {"type": "hero", "variant": "a", "label": "Hero — split (image right)"},
    {"type": "hero", "variant": "b", "label": "Hero — dark stats"},
    {"type": "hero", "variant": "c", "label": "Hero — editorial center"},
    {"type": "services_grid", "variant": "a", "label": "Services — 3-column"},
    {"type": "services_grid", "variant": "b", "label": "Services — 2-column with price chips"},
    {"type": "services_grid", "variant": "c", "label": "Services — dense list"},
    {"type": "about_split", "variant": "a", "label": "About — image + bullets"},
    {"type": "testimonials", "variant": "a", "label": "Testimonials — 3 cards"},
    {"type": "cta_band", "variant": "a", "label": "CTA band"},
    {"type": "contact_hours", "variant": "a", "label": "Contact & hours"},
    {"type": "form", "variant": "a", "label": "Contact form"},
    {"type": "store", "variant": "a", "label": "Store — product grid + checkout"},
    {"type": "faq", "variant": "a", "label": "FAQ accordion"},
    {"type": "gallery", "variant": "a", "label": "Image gallery"},
    {"type": "pricing_table", "variant": "a", "label": "Pricing table"},
    {"type": "video", "variant": "a", "label": "Video (YouTube / Vimeo / MP4)"},
    {"type": "map", "variant": "a", "label": "Google map"},
    {"type": "stats", "variant": "a", "label": "Stats / big numbers"},
    {"type": "team", "variant": "a", "label": "Team members"},
    {"type": "logo_cloud", "variant": "a", "label": "Logo cloud"},
    {"type": "countdown", "variant": "a", "label": "Countdown timer"},
    {"type": "social_links", "variant": "a", "label": "Social links"},
    {"type": "text", "variant": "a", "label": "Rich text"},
    {"type": "blog_list", "variant": "a", "label": "Blog — latest articles"},
    {"type": "booking", "variant": "a", "label": "Booking — live availability"},
    {"type": "footer", "variant": "a", "label": "Footer"},
]


@router.get("/block-library")
async def block_library(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"blocks": BLOCK_LIBRARY}


# ---------------- Round 10: templates / from-scratch / section regeneration ----------------

@router.get("/templates")
async def list_site_templates(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from ..services import site_templates
    return {"templates": site_templates.list_templates()}


class ApplyTemplateReq(BaseModel):
    template_id: Optional[str] = None      # None → blank "from scratch" starter
    mode: str = "replace"                  # replace (current draft) | new_site
    name: Optional[str] = None             # new site name (new_site mode)


async def _new_site_from(org_id: str, name: str, theme: Dict[str, Any], pages: List[Dict[str, Any]],
                         nav: List[str]) -> str:
    """Create an additional website document (respecting the plan's site limit) and activate it."""
    from ..services import sites as svc
    from .sites import _list as _sites_list
    db = get_db()
    state = await _sites_list(org_id)
    if not state["can_create"]:
        raise HTTPException(402, {"error": "plan_limit", "message": f"Your plan allows {state['limit']} website(s). Upgrade to add more.",
                                  "limit": state["limit"], "used": state["used"]})
    profile = await db.business_profiles.find_one({"org_id": org_id}) or {}
    doc = {"org_id": org_id, "business_profile_id": str(profile.get("_id", "")), "name": name.strip()[:60],
           "theme": theme, "pages": pages, "nav_order": nav, "slug": None, "slug_history": [],
           "status": "draft", "maintenance": {}, "draft_updated_at": utc_now_iso(),
           "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.websites.insert_one(doc)
    await svc.set_active(org_id, str(r.inserted_id))
    return str(r.inserted_id)


@router.post("/website/apply-template")
async def apply_template(req: ApplyTemplateReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Template gallery + build-from-scratch. `template_id=None` = blank starter (no AI, no cost).
    mode=replace overwrites the CURRENT draft (published version is untouched until you publish);
    mode=new_site creates another site (plan-limited) and makes it active."""
    from ..services import site_templates
    from ..services import sites as svc
    db = get_db()
    profile = await db.business_profiles.find_one({"org_id": org_id}) or {}
    org = await db.organizations.find_one({"_id": ObjectId(org_id)}, {"name": 1}) or {}
    business_name = profile.get("business_name") or org.get("name") or "Your business"
    if req.template_id:
        try:
            built = site_templates.build_template(req.template_id, business_name, profile.get("tagline") or "")
        except KeyError:
            raise HTTPException(404, "Template not found")
        theme, pages, nav = built["theme"], built["pages"], built["nav_order"]
    else:
        pages, theme, nav = svc.blank_pages(business_name), dict(svc.DEFAULT_THEME), ["home"]
    # validate through pydantic
    try:
        theme_m = WebsiteTheme(**theme)
        pages_m = [Page(**p) for p in pages]
    except Exception as e:  # noqa: BLE001
        raise HTTPException(500, f"Template invalid: {e}")
    if req.mode == "new_site":
        name = req.name or (f"{business_name} — {req.template_id}" if req.template_id else f"{business_name} — new site")
        wid = await _new_site_from(org_id, name, theme_m.model_dump(), [p.model_dump() for p in pages_m], nav)
        return {"ok": True, "mode": "new_site", "website_id": wid, "pages": [p.slug for p in pages_m]}
    website = await _load_website(org_id)
    website.theme = theme_m
    website.pages = pages_m
    website.nav_order = nav
    await _persist_draft(website)
    return {"ok": True, "mode": "replace", "website_id": website.id, "pages": [p.slug for p in pages_m],
            "source": req.template_id or "blank"}


class RegenerateReq(BaseModel):
    instruction: Optional[str] = Field(default=None, max_length=400)   # e.g. "shorter, friendlier"
    tone: Optional[str] = Field(default=None, max_length=60)


_REGEN_SYSTEM = """You rewrite ONE section of a small-business website. You receive the block type, its current
props JSON and the business profile. Return ONLY a JSON object with the SAME keys as the current props (keep
ids, image URLs, hrefs, field definitions and any structural arrays the same length), rewriting only the
human-readable text (headlines, subheadlines, descriptions, bullets, labels). Truth rule: never invent
prices, statistics, reviews, awards, years in business or guarantees that are not in the profile. Keep copy
concise, specific, and in the business's tone. No markdown, no commentary."""


@router.post("/website/blocks/{block_id}/regenerate")
async def regenerate_block(block_id: str, req: RegenerateReq, user: User = Depends(current_user),
                           org_id: str = Depends(require_org)):
    """AI 'Regenerate copy' for a single section — metered (feature=section_regenerate)."""
    import json as _json
    from ..models import BusinessProfile
    from ..services.generation import _profile_prompt
    from ..services.llm import generate_json
    db = get_db()
    website = await _load_website(org_id)
    page, idx, block = _find_block(website, block_id)
    pdoc = await db.business_profiles.find_one({"org_id": org_id})
    profile_txt = ""
    if pdoc:
        try:
            profile_txt = _profile_prompt(BusinessProfile.from_mongo(pdoc))
        except Exception:  # noqa: BLE001
            profile_txt = f"Business: {pdoc.get('business_name','')} — {pdoc.get('tagline','')}"
    extra = ""
    if req.instruction:
        extra += f"\nOwner instruction: {req.instruction}"
    if req.tone:
        extra += f"\nTone: {req.tone}"
    prompt = (f"{profile_txt}\nPAGE: {page.title} ({page.slug})\nBLOCK TYPE: {block.type} (variant {block.variant})\n"
              f"CURRENT PROPS JSON:\n{_json.dumps(block.props)[:6000]}{extra}\nReturn the rewritten props JSON only.")
    raw = await generate_json(_REGEN_SYSTEM, prompt, max_retries=1, feature="section_regenerate")
    if not isinstance(raw, dict) or not raw:
        raise HTTPException(502, "The AI returned an unusable result — please try again.")
    # Preserve non-text structural values the model must not change.
    merged = {**block.props}
    for k, v in raw.items():
        if k in block.props and k in ("image", "background_image", "fields", "website_slug", "page_slug", "images", "url", "target"):
            continue
        merged[k] = v
    block.props = merged
    page.blocks[idx] = block
    await _persist_draft(website)
    return {"ok": True, "block": block.model_dump()}
