"""Phase 4 routes — services catalog, staff, availability, bookings, jobs,
quotes (with approvals + portal), invoices, payments (with simulated + stripe adapter).

All routes org-scoped via require_org. Public routes for the customer portal
use tokenized links (per-record `portal_token`), NOT JWTs.
"""
from __future__ import annotations

import hmac
import logging
import secrets
import uuid
from datetime import date as ddate, datetime, timedelta, timezone
from typing import Any, Dict, List, Literal, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr, Field

from .crm import _record_interaction, upsert_contact_from_form
from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..models_bookings import (
    Booking, ChecklistItem, Invoice, InvoiceLine, Job, Payment,
    Quote, QuoteLine, QuoteTotals, ServiceOffering, Staff, TimeOff,
    WorkingHours,
)
from ..models_crm import ScheduledSend
from ..services.availability import check_conflict, compute_open_slots
from ..services.payment_providers import (
    CheckoutRequest, build_payment_provider, drain_simulated_events,
    list_payment_providers, simulated_pay,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/booking", tags=["booking"])
quotes_router = APIRouter(prefix="/quotes", tags=["quotes"])
invoices_router = APIRouter(prefix="/invoices", tags=["invoices"])
jobs_router = APIRouter(prefix="/jobs", tags=["jobs"])
public_router = APIRouter(prefix="/public/booking", tags=["public-booking"])
public_portal = APIRouter(prefix="/public/portal", tags=["public-portal"])
payments_router = APIRouter(prefix="/payments", tags=["payments"])


def _to_datetime(v: str, field: str = "datetime") -> datetime:
    """Tolerant ISO datetime parser. Returns UTC-aware datetime, 422 on bad input."""
    if not isinstance(v, str) or not v:
        raise HTTPException(422, {"error": "bad_datetime",
                                    "detail": f"{field} is required (ISO datetime)"})
    try:
        dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        raise HTTPException(422, {"error": "bad_datetime",
                                    "detail": f"{field} must be an ISO datetime; got {v!r}"})


def _to_date(v: str, field: str = "date") -> ddate:
    """Tolerant date parser — accepts YYYY-MM-DD or full ISO datetime (truncated to date).
    Public endpoints must never 500 on malformed input; raise 422 with a helpful message."""
    if not isinstance(v, str) or not v:
        raise HTTPException(422, {"error": "bad_date",
                                    "detail": f"{field} is required (YYYY-MM-DD)"})
    try:
        if "T" in v:
            return datetime.fromisoformat(v.replace("Z", "+00:00")).date()
        return ddate.fromisoformat(v)
    except ValueError:
        raise HTTPException(422, {"error": "bad_date",
                                    "detail": f"{field} must be YYYY-MM-DD (or ISO datetime); got {v!r}"})


# =============== helpers ===============

def _new_token(length: int = 24) -> str:
    return secrets.token_urlsafe(length)


def _tokens_equal(a, b) -> bool:
    """Constant-time compare. Protects tokenized portals from timing attacks."""
    if not a or not b:
        return False
    return hmac.compare_digest(str(a).encode("utf-8"), str(b).encode("utf-8"))


def _token_matches_any(tk: str, *candidates) -> bool:
    return any(_tokens_equal(tk, c) for c in candidates)


async def _next_number(db, org_id: str, kind: str, prefix: str) -> str:
    """Simple per-org sequence: read the max existing suffix + 1."""
    year = datetime.now(timezone.utc).year
    field = "number"
    coll = getattr(db, kind)
    max_doc = await coll.find_one({"org_id": org_id}, sort=[(field, -1)])
    suffix = 1
    if max_doc and (max_doc.get(field) or "").startswith(f"{prefix}-{year}-"):
        try:
            suffix = int((max_doc.get(field) or "").split("-")[-1]) + 1
        except Exception:  # noqa: BLE001
            suffix = 1
    return f"{prefix}-{year}-{suffix:04d}"


# =============== SERVICES CATALOG ===============

class ServiceIn(BaseModel):
    model_config = {"extra": "forbid"}
    name: str
    description: Optional[str] = None
    duration_minutes: int = 60
    buffer_before_minutes: int = 0
    buffer_after_minutes: int = 15
    price_cents: int = 0
    deposit_cents: int = 0
    currency: str = "USD"
    location_type: Literal["on_site", "at_business", "virtual"] = "on_site"
    required_staff_ids: List[str] = Field(default_factory=list)
    bookable: bool = True
    color: Optional[str] = None
    max_daily_bookings: Optional[int] = None


@router.post("/services")
async def create_service(req: ServiceIn, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    svc = ServiceOffering(org_id=org_id, **req.model_dump())
    res = await db.service_offerings.insert_one(svc.to_mongo())
    svc.id = str(res.inserted_id)
    return svc.model_dump()


@router.get("/services")
async def list_services(active_only: bool = True, user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if active_only:
        q["active"] = True
    cursor = db.service_offerings.find(q).sort("name", 1)
    return {"services": [ServiceOffering.from_mongo(d).model_dump() async for d in cursor]}


@router.patch("/services/{sid}")
async def patch_service(sid: str, req: ServiceIn,
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    updates = {**req.model_dump(), "updated_at": utc_now_iso()}
    res = await db.service_offerings.update_one(
        {"_id": ObjectId(sid), "org_id": org_id}, {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(404, "Service not found")
    return {"ok": True}


# =============== STAFF ===============

class StaffIn(BaseModel):
    model_config = {"extra": "forbid"}
    display_name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    role: str = "technician"
    timezone: str = "America/Los_Angeles"
    working_hours: List[Dict[str, Any]] = Field(default_factory=list)
    breaks: List[Dict[str, Any]] = Field(default_factory=list)
    time_off: List[Dict[str, Any]] = Field(default_factory=list)
    capacity: int = 1
    color: Optional[str] = None


@router.post("/staff")
async def create_staff(req: StaffIn, user: User = Depends(current_user),
                        org_id: str = Depends(require_org)):
    db = get_db()
    staff = Staff(
        org_id=org_id, display_name=req.display_name, email=req.email, phone=req.phone,
        role=req.role, timezone=req.timezone, capacity=req.capacity, color=req.color,
        working_hours=[WorkingHours(**w) for w in req.working_hours],
        breaks=[WorkingHours(**w) for w in req.breaks],
        time_off=[TimeOff(**t) for t in req.time_off],
    )
    res = await db.staff.insert_one(staff.to_mongo())
    staff.id = str(res.inserted_id)
    return staff.model_dump()


@router.get("/staff")
async def list_staff(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.staff.find({"org_id": org_id, "active": True}).sort("display_name", 1)
    return {"staff": [Staff.from_mongo(d).model_dump() async for d in cursor]}


@router.patch("/staff/{sid}")
async def patch_staff(sid: str, req: StaffIn,
                        user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    updates = {**req.model_dump(), "updated_at": utc_now_iso()}
    res = await db.staff.update_one({"_id": ObjectId(sid), "org_id": org_id}, {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(404, "Staff not found")
    return {"ok": True}


# =============== AVAILABILITY + BOOKINGS ===============

async def _pick_staff(db, org_id: str, service: Dict[str, Any],
                        preferred_staff_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Round-robin pick among service.required_staff_ids or ALL active staff.
    Deterministic for a given input set."""
    if preferred_staff_id:
        return await db.staff.find_one({"_id": ObjectId(preferred_staff_id), "org_id": org_id})
    filt: Dict[str, Any] = {"org_id": org_id, "active": True}
    if service.get("required_staff_ids"):
        filt["_id"] = {"$in": [ObjectId(x) for x in service["required_staff_ids"]]}
    candidates = [s async for s in db.staff.find(filt).sort("display_name", 1)]
    return candidates[0] if candidates else None


@router.get("/availability")
async def owner_availability(service_id: str, date_from: str, date_to: str,
                                staff_id: Optional[str] = None,
                                user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await _compute_availability(org_id, service_id, date_from, date_to, staff_id)


@public_router.get("/services")
async def public_list_services(website_slug: str):
    """Public: list bookable services for a site — used by the on-site BookingBlock."""
    db = get_db()
    site = await db.websites.find_one({"slug": website_slug.lower(), "status": "published"})
    if not site:
        raise HTTPException(404, "Site not found")
    cursor = db.service_offerings.find({"org_id": site["org_id"], "active": True, "bookable": True}).sort("name", 1)
    out = []
    async for d in cursor:
        out.append({
            "id": str(d["_id"]),
            "name": d.get("name"),
            "description": d.get("description"),
            "duration_minutes": d.get("duration_minutes"),
            "price_cents": d.get("price_cents"),
            "currency": d.get("currency", "USD"),
        })
    return {"services": out}


@public_router.get("/availability")
async def public_availability(website_slug: str, service_id: str, date_from: str,
                                 date_to: str, staff_id: Optional[str] = None):
    """Public: called from a live-site booking block. Resolves website_slug → org."""
    db = get_db()
    site = await db.websites.find_one({"slug": website_slug.lower(), "status": "published"})
    if not site:
        raise HTTPException(404, "Site not found")
    return await _compute_availability(site["org_id"], service_id, date_from, date_to, staff_id)


async def _compute_availability(org_id: str, service_id: str, date_from: str, date_to: str,
                                  staff_id: Optional[str]) -> Dict[str, Any]:
    db = get_db()
    svc = await db.service_offerings.find_one({"_id": ObjectId(service_id), "org_id": org_id})
    if not svc:
        raise HTTPException(404, "Service not found")
    if not svc.get("bookable", True):
        return {"slots": []}
    df = _to_date(date_from, "date_from"); dt = _to_date(date_to, "date_to")
    # Cap the range so a slow client can't force a giant scan
    if (dt - df).days > 60:
        raise HTTPException(400, "Range too large (max 60 days)")
    # candidate staff
    staff_filter: Dict[str, Any] = {"org_id": org_id, "active": True}
    if staff_id:
        staff_filter["_id"] = ObjectId(staff_id)
    elif svc.get("required_staff_ids"):
        staff_filter["_id"] = {"$in": [ObjectId(x) for x in svc["required_staff_ids"]]}
    staffs = [s async for s in db.staff.find(staff_filter)]
    if not staffs:
        return {"slots": []}
    # pre-load bookings for the window per-staff
    all_slots: List[Dict[str, Any]] = []
    window_start = datetime.combine(df, datetime.min.time(), tzinfo=timezone.utc).isoformat()
    window_end = datetime.combine(dt + timedelta(days=1), datetime.min.time(),
                                    tzinfo=timezone.utc).isoformat()
    for s in staffs:
        bookings = [b async for b in db.bookings.find({
            "org_id": org_id, "staff_id": str(s["_id"]),
            "start_at": {"$lt": window_end},
            "end_at": {"$gte": window_start},
        })]
        slots = compute_open_slots(
            staff={**s, "id": str(s["_id"])},
            existing_bookings=bookings,
            service_duration_minutes=svc["duration_minutes"],
            service_buffer_before=svc.get("buffer_before_minutes", 0),
            service_buffer_after=svc.get("buffer_after_minutes", 0),
            date_from=df, date_to=dt,
        )
        for sl in slots:
            sl["staff_display_name"] = s.get("display_name")
        all_slots.extend(slots)
    # Sort chronologically
    all_slots.sort(key=lambda x: x["start_at"])
    # Never return past slots — the availability engine iterates by weekday and can
    # produce slots earlier today or on requested past dates. Trim to now onwards.
    _now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    all_slots = [sl for sl in all_slots if sl["start_at"] >= _now_iso]
    return {"service_id": service_id, "slots": all_slots[:500]}


class BookingCreate(BaseModel):
    model_config = {"extra": "forbid"}
    service_id: str
    start_at: str  # ISO UTC
    staff_id: Optional[str] = None
    website_slug: Optional[str] = None  # required for public
    name: str
    email: EmailStr
    phone: Optional[str] = None
    customer_notes: Optional[str] = None
    attribution: Dict[str, Any] = Field(default_factory=dict)  # Round 11: UTM first-touch (public only; allow-listed)


@public_router.post("/book")
async def public_book(req: BookingCreate, request: Request):
    """Public: create a booking from a visitor. Also auto-creates a Contact."""
    if not req.website_slug:
        raise HTTPException(400, "website_slug is required")
    db = get_db()
    site = await db.websites.find_one({"slug": req.website_slug.lower(), "status": "published"})
    if not site:
        raise HTTPException(404, "Site not found")
    return await _create_booking(db, site["org_id"], req, source="public", website_id=str(site["_id"]))


@router.post("/bookings")
async def owner_book(req: BookingCreate, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    db = get_db()
    return await _create_booking(db, org_id, req, source="manual", author_user_id=user.id)


async def _create_booking(db, org_id: str, req: BookingCreate, *,
                            source: str, website_id: Optional[str] = None,
                            author_user_id: Optional[str] = None) -> Dict[str, Any]:
    svc = await db.service_offerings.find_one({"_id": ObjectId(req.service_id), "org_id": org_id})
    if not svc:
        raise HTTPException(404, "Service not found")
    if not svc.get("bookable", True):
        raise HTTPException(400, "Service is not bookable")
    staff = await _pick_staff(db, org_id, svc, req.staff_id)
    if not staff:
        raise HTTPException(400, "No staff available for this service")
    # Compute end_at
    duration = timedelta(minutes=svc["duration_minutes"])
    start_dt = _to_datetime(req.start_at, "start_at")
    # Refuse past-dated bookings — server-side guard (public API + owner API).
    if start_dt <= datetime.now(timezone.utc):
        raise HTTPException(422, {"error": "past_start_at",
                                     "detail": "Booking start_at must be in the future."})
    end_dt = start_dt + duration
    # Conflict check against staff's existing bookings (last-line defence — the
    # availability endpoint might have been called with stale data).
    existing = [b async for b in db.bookings.find({
        "org_id": org_id, "staff_id": str(staff["_id"]),
        "start_at": {"$lt": (end_dt + timedelta(hours=2)).isoformat()},
        "end_at": {"$gte": (start_dt - timedelta(hours=2)).isoformat()},
    })]
    conflict = check_conflict(
        staff=staff, existing_bookings=existing,
        start_at=start_dt.isoformat(), end_at=end_dt.isoformat(),
        buffer_before=svc.get("buffer_before_minutes", 0),
        buffer_after=svc.get("buffer_after_minutes", 0),
    )
    if conflict:
        raise HTTPException(409, {"error": "slot_conflict", "detail": conflict})
    # Upsert contact
    contact_id = await upsert_contact_from_form(
        db, org_id,
        {"name": req.name, "email": str(req.email), "phone": req.phone or "",
         "message": req.customer_notes or ""},
        source="booking", website_id=website_id,
    )
    number = await _next_number(db, org_id, "bookings", "B")
    tokens = {"cancel": _new_token(), "reschedule": _new_token()}
    booking = Booking(
        org_id=org_id, service_id=req.service_id, staff_id=str(staff["_id"]),
        contact_id=contact_id,
        start_at=start_dt.isoformat().replace("+00:00", "Z"),
        end_at=end_dt.isoformat().replace("+00:00", "Z"),
        buffer_before_minutes=svc.get("buffer_before_minutes", 0),
        buffer_after_minutes=svc.get("buffer_after_minutes", 0),
        customer_notes=req.customer_notes, source=source,
        booking_number=number, tokens=tokens,
    )
    res = await db.bookings.insert_one(booking.to_mongo())
    booking.id = str(res.inserted_id)
    # Round 11 — attribution + funnel event (never fails the visitor)
    try:
        from ..services import attribution as _attr
        attr = _attr.clean_attribution(getattr(req, "attribution", None))
        if attr:
            await db.bookings.update_one({"_id": res.inserted_id}, {"$set": {"attribution": attr}})
            if contact_id:
                await db.contacts.update_one({"_id": ObjectId(contact_id), "attribution": {"$exists": False}},
                                             {"$set": {"attribution": attr}})
        await _attr.emit(db, org_id, "booking_created", website_id=website_id, attribution=attr,
                         meta={"booking_id": booking.id, "service_id": svc.get("_id") if isinstance(svc.get("_id"), str) else str(svc.get("_id"))})
    except Exception as e:  # noqa: BLE001
        logger.warning("booking attribution failed: %s", e)
    try:
        import asyncio as _asyncio
        from ..services.webhooks import dispatch_event as _dispatch
        _asyncio.create_task(_dispatch(org_id, "booking.created", {"booking_id": booking.id, "service_id": booking.service_id,
                                                                   "start_at": booking.start_at, "end_at": booking.end_at,
                                                                   "customer_name": req.customer_name, "email": req.email}))
    except Exception:  # noqa: BLE001
        pass
    await _record_interaction(db, org_id, contact_id=contact_id, type_="booking_created",
                                 summary=f"Booked {svc['name']} with {staff.get('display_name')} on {start_dt.strftime('%b %d, %I:%M %p')}",
                                 ref_type="booking", ref_id=booking.id,
                                 author_user_id=author_user_id)
    # Confirmation "email" via provider (simulated)
    try:
        await _send_booking_confirmation(db, org_id, booking, svc, staff, req.email, tokens, website_id)
    except Exception as e:  # noqa: BLE001
        logger.warning("booking confirmation email failed: %s", e)
    # Fire automations
    try:
        from ..routes.marketing import fire_trigger
        await fire_trigger(org_id, "booking_created", {
            "booking_id": booking.id, "contact_id": contact_id,
            "email": req.email, "name": req.name,
            "service_name": svc.get("name"),
        })
    except Exception as e:  # noqa: BLE001
        logger.warning("booking_created automation trigger failed: %s", e)
    return booking.model_dump()


async def _send_booking_confirmation(db, org_id, booking, svc, staff, email, tokens,
                                        website_id: Optional[str]) -> None:
    from ..models_crm import EmailProviderConfig
    from ..services.email_providers import SendPayload, build_provider_from_config
    cfg_doc = await db.email_provider_configs.find_one({"org_id": org_id})
    cfg = EmailProviderConfig.from_mongo(cfg_doc) if cfg_doc else EmailProviderConfig(org_id=org_id)
    provider = build_provider_from_config(cfg)
    portal_prefix = "/portal"
    body = (f"Your booking is confirmed for {svc['name']} on "
             f"{datetime.fromisoformat(booking.start_at.replace('Z','+00:00')).strftime('%A, %B %d at %I:%M %p UTC')}.\n\n"
             f"Reschedule: {portal_prefix}/booking/{booking.id}?tk={tokens['reschedule']}\n"
             f"Cancel: {portal_prefix}/booking/{booking.id}?tk={tokens['cancel']}\n")
    payload = SendPayload(
        from_email=cfg.from_email or "notifications@zanelvo.local",
        from_name=cfg.from_name or "Zanelvo",
        to=[str(email)],
        subject=f"Booking confirmed — {svc['name']}",
        text=body,
    )
    result = await provider.send(payload)
    booking.delivery = None  # not persisted here — we just record the interaction
    await _record_interaction(db, org_id, contact_id=booking.contact_id,
                                 type_="booking_confirmation_sent",
                                 summary=f"Confirmation {'delivered (simulated)' if result.simulated else 'sent'} to {email}",
                                 ref_type="booking", ref_id=booking.id,
                                 meta={"simulated": result.simulated,
                                         "provider": provider.key,
                                         "provider_message_id": result.provider_message_id})


@router.get("/bookings")
async def list_bookings(date_from: Optional[str] = None, date_to: Optional[str] = None,
                          staff_id: Optional[str] = None, status: Optional[str] = None,
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if staff_id: q["staff_id"] = staff_id
    if status: q["status"] = status
    if date_from: q["end_at"] = {"$gte": date_from}
    if date_to: q.setdefault("start_at", {})["$lte"] = date_to
    cursor = db.bookings.find(q).sort("start_at", 1).limit(500)
    return {"bookings": [Booking.from_mongo(d).model_dump() async for d in cursor]}


@router.patch("/bookings/{bid}")
async def patch_booking(bid: str, body: Dict[str, Any],
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    allowed = {"status", "notes", "staff_id", "start_at", "end_at"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(400, "Nothing to update")
    updates["updated_at"] = utc_now_iso()
    res = await db.bookings.update_one({"_id": ObjectId(bid), "org_id": org_id}, {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(404, "Booking not found")
    fresh = await db.bookings.find_one({"_id": ObjectId(bid), "org_id": org_id})
    await _record_interaction(db, org_id, contact_id=fresh.get("contact_id"),
                                 type_=f"booking_{updates.get('status') or 'updated'}",
                                 summary=f"Booking {updates.get('status') or 'updated'}",
                                 ref_type="booking", ref_id=bid, author_user_id=user.id)
    return Booking.from_mongo(fresh).model_dump()


# ---- Customer portal (token-based, no auth) ----

@public_portal.get("/booking/{bid}")
async def portal_booking(bid: str, tk: str):
    db = get_db()
    doc = await db.bookings.find_one({"_id": ObjectId(bid)})
    if not doc:
        raise HTTPException(404, "Booking not found")
    tokens = doc.get("tokens") or {}
    if not _token_matches_any(tk, tokens.get("cancel"), tokens.get("reschedule")):
        raise HTTPException(403, "Invalid token")
    svc = await db.service_offerings.find_one({"_id": ObjectId(doc["service_id"])})
    return {
        "booking": Booking.from_mongo(doc).model_dump(),
        "service": {"name": (svc or {}).get("name"),
                     "duration_minutes": (svc or {}).get("duration_minutes")},
        "policy": {"min_notice_hours": 4,
                    "text": "Cancellations within 4 hours may incur a fee."},
    }


@public_portal.get("/booking/{bid}/availability")
async def portal_booking_availability(bid: str, tk: str, date_from: str, date_to: str):
    """Reschedule-page availability. Uses booking's own org_id/service_id/staff_id."""
    db = get_db()
    doc = await db.bookings.find_one({"_id": ObjectId(bid)})
    if not doc or not _tokens_equal(tk, (doc.get("tokens") or {}).get("reschedule")):
        raise HTTPException(403, "Invalid token")
    return await _compute_availability(doc["org_id"], doc["service_id"], date_from, date_to,
                                          doc.get("staff_id"))


class RescheduleReq(BaseModel):
    start_at: str


@public_portal.post("/booking/{bid}/reschedule")
async def portal_reschedule(bid: str, tk: str, req: RescheduleReq):
    db = get_db()
    doc = await db.bookings.find_one({"_id": ObjectId(bid)})
    if not doc:
        raise HTTPException(404, "Booking not found")
    if not _tokens_equal(tk, (doc.get("tokens") or {}).get("reschedule")):
        raise HTTPException(403, "Invalid token")
    # min-notice guard (default 4h)
    old_start = datetime.fromisoformat(doc["start_at"].replace("Z", "+00:00")).astimezone(timezone.utc)
    if (old_start - datetime.now(timezone.utc)).total_seconds() < 4 * 3600:
        raise HTTPException(400, {"error": "min_notice",
                                     "detail": "Reschedule requires at least 4 hours notice."})
    svc = await db.service_offerings.find_one({"_id": ObjectId(doc["service_id"])})
    duration = timedelta(minutes=svc["duration_minutes"])
    new_start = _to_datetime(req.start_at, "start_at")
    if new_start <= datetime.now(timezone.utc):
        raise HTTPException(422, {"error": "past_start_at",
                                     "detail": "Reschedule start_at must be in the future."})
    new_end = new_start + duration
    staff = await db.staff.find_one({"_id": ObjectId(doc["staff_id"])})
    other_bookings = [b async for b in db.bookings.find({
        "org_id": doc["org_id"], "staff_id": doc["staff_id"],
        "_id": {"$ne": doc["_id"]},
        "start_at": {"$lt": (new_end + timedelta(hours=2)).isoformat()},
        "end_at": {"$gte": (new_start - timedelta(hours=2)).isoformat()},
    })]
    conflict = check_conflict(
        staff=staff, existing_bookings=other_bookings,
        start_at=new_start.isoformat(), end_at=new_end.isoformat(),
        buffer_before=doc.get("buffer_before_minutes", 0),
        buffer_after=doc.get("buffer_after_minutes", 0),
    )
    if conflict:
        raise HTTPException(409, {"error": "slot_conflict", "detail": conflict})
    await db.bookings.update_one({"_id": doc["_id"]}, {
        "$set": {"start_at": new_start.isoformat().replace("+00:00", "Z"),
                    "end_at": new_end.isoformat().replace("+00:00", "Z"),
                    "source": "reschedule", "updated_at": utc_now_iso()}
    })
    await _record_interaction(db, doc["org_id"], contact_id=doc.get("contact_id"),
                                 type_="booking_rescheduled",
                                 summary=f"Rescheduled to {new_start.strftime('%b %d, %I:%M %p')}",
                                 ref_type="booking", ref_id=bid)
    return {"ok": True}


@public_portal.post("/booking/{bid}/cancel")
async def portal_cancel(bid: str, tk: str):
    db = get_db()
    doc = await db.bookings.find_one({"_id": ObjectId(bid)})
    if not doc:
        raise HTTPException(404, "Booking not found")
    if not _tokens_equal(tk, (doc.get("tokens") or {}).get("cancel")):
        raise HTTPException(403, "Invalid token")
    old_start = datetime.fromisoformat(doc["start_at"].replace("Z", "+00:00")).astimezone(timezone.utc)
    hours_notice = (old_start - datetime.now(timezone.utc)).total_seconds() / 3600
    within_min_notice = hours_notice < 4
    await db.bookings.update_one({"_id": doc["_id"]}, {
        "$set": {"status": "cancelled",
                    "cancellation_reason": "customer_cancel",
                    "updated_at": utc_now_iso(),
                    "within_min_notice": within_min_notice}
    })
    await _record_interaction(db, doc["org_id"], contact_id=doc.get("contact_id"),
                                 type_="booking_cancelled",
                                 summary=f"Cancelled by customer ({'within notice' if within_min_notice else 'outside notice'})",
                                 ref_type="booking", ref_id=bid,
                                 meta={"within_min_notice": within_min_notice})
    return {"ok": True, "fee_may_apply": within_min_notice}


# =============== QUOTES ===============

def compute_quote_totals(lines: List[Dict[str, Any]], global_discount_percent: float,
                          tax_rate: float, deposit: int, currency: str) -> Dict[str, Any]:
    """Compute quote totals. All percent inputs are on a 0-100 scale.

    Contract:
    - global_discount_percent: 0-100 (e.g. 25 means 25% off subtotal net of line discounts).
    - tax_rate: 0-100 (e.g. 8 means 8% VAT on the post-discount taxable base).
    - Per-line discount_percent: 0-100. Per-line tax_rate: 0-100.
    - discount_amount_cents on a line is a flat cent value (not a percent).
    Rounds to integer cents throughout.
    """
    subtotal = 0
    total_discount = 0
    taxable_subtotal = 0
    gd = max(0.0, min(100.0, float(global_discount_percent or 0))) / 100.0
    tr = max(0.0, min(100.0, float(tax_rate or 0))) / 100.0
    for line in lines:
        line_gross = int(round((line.get("quantity", 1) or 0) * (line.get("unit_price_cents", 0) or 0)))
        subtotal += line_gross
        line_disc_pct = max(0.0, min(100.0, float(line.get("discount_percent", 0) or 0))) / 100.0
        line_disc_amt = int(round(line_gross * line_disc_pct)) + int(line.get("discount_amount_cents") or 0)
        line_disc_amt = min(line_disc_amt, line_gross)  # clamp: discount can't exceed the line
        total_discount += line_disc_amt
        net = max(0, line_gross - line_disc_amt)
        if line.get("taxable", True):
            taxable_subtotal += net
    global_disc = int(round((subtotal - total_discount) * gd))
    total_discount += global_disc
    total_discount = min(total_discount, subtotal)  # invariant: never discount more than gross
    taxable_subtotal = max(0, taxable_subtotal - int(round(taxable_subtotal * gd)))
    tax = int(round(taxable_subtotal * tr))
    total = subtotal - total_discount + tax
    total = max(0, total)  # invariant: totals cannot be negative
    return {
        "subtotal_cents": subtotal,
        "discount_cents": total_discount,
        "tax_cents": tax,
        "total_cents": total,
        "deposit_cents": max(0, int(deposit or 0)),
        "currency": currency,
    }


class QuoteLineIn(BaseModel):
    id: Optional[str] = None
    kind: Literal["service", "product", "custom"] = "custom"
    ref_id: Optional[str] = None
    label: str
    description: Optional[str] = None
    quantity: float = Field(default=1.0, ge=0, le=100000)
    unit_price_cents: int = Field(default=0, ge=0, le=10_000_000_00)
    discount_percent: float = Field(default=0.0, ge=0, le=100,
                                      description="0-100 (e.g. 25 = 25%). Values >100 rejected.")
    discount_amount_cents: int = Field(default=0, ge=0)
    tax_rate: float = Field(default=0.0, ge=0, le=50,
                              description="0-50 (e.g. 8 = 8%). Values >50 rejected.")
    taxable: bool = True


class QuoteCreate(BaseModel):
    model_config = {"extra": "forbid"}
    contact_id: Optional[str] = None
    lines: List[QuoteLineIn] = Field(default_factory=list)
    tax_rate: float = Field(default=0.0, ge=0, le=50,
                              description="Percent, 0-50. Values >50 rejected.")
    global_discount_percent: float = Field(default=0.0, ge=0, le=100,
                                             description="Percent, 0-100. Values >100 rejected.")
    deposit_required_cents: int = Field(default=0, ge=0)
    currency: str = Field(default="USD", min_length=3, max_length=3)
    notes: Optional[str] = None
    terms: Optional[str] = None
    expires_at: Optional[str] = None


async def _needs_approval(db, org_id: str, discount_percent: float, total_cents: int) -> Optional[str]:
    """Return an approval reason string when the discount / total crosses a rule threshold.
    All discount values are on the 0-100 scale."""
    async for rule in db.approval_rules.find({"org_id": org_id, "active": True}):
        if rule["threshold_type"] == "discount_percent" and discount_percent >= rule["threshold_value"]:
            return f"Discount {int(round(discount_percent))}% ≥ threshold {int(round(rule['threshold_value']))}%"
        if rule["threshold_type"] == "total_cents" and total_cents >= rule["threshold_value"]:
            return f"Total {total_cents/100:.2f} ≥ threshold {rule['threshold_value']/100:.2f}"
    return None


@quotes_router.post("")
async def create_quote(req: QuoteCreate, user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    db = get_db()
    lines_data = []
    for ln in req.lines:
        d = ln.model_dump()
        d["id"] = ln.id or uuid.uuid4().hex[:8]
        lines_data.append(d)
    totals_raw = compute_quote_totals(lines_data, req.global_discount_percent, req.tax_rate,
                                         req.deposit_required_cents, req.currency)
    # Hard invariant — money paths must be impossible to corrupt.
    if totals_raw["total_cents"] < 0 or totals_raw["discount_cents"] > totals_raw["subtotal_cents"]:
        raise HTTPException(422, {"error": "invalid_totals",
                                    "detail": "Computed totals violate invariants "
                                                "(total < 0 or discount > subtotal). Check inputs."})
    reason = await _needs_approval(db, org_id, req.global_discount_percent, totals_raw["total_cents"])
    approval_state = "pending" if reason else "not_required"
    status = "pending_approval" if reason else "draft"
    number = await _next_number(db, org_id, "quotes", "Q")
    q = Quote(
        org_id=org_id, number=number, contact_id=req.contact_id, author_user_id=user.id,
        status=status, approval_state=approval_state, approval_reason=reason,
        lines=[QuoteLine(**l) for l in lines_data],
        tax_rate=req.tax_rate, global_discount_percent=req.global_discount_percent,
        deposit_required_cents=req.deposit_required_cents,
        currency=req.currency, notes=req.notes, terms=req.terms, expires_at=req.expires_at,
        totals=QuoteTotals(**totals_raw), version=1,
        versions=[{"version": 1, "created_at": utc_now_iso(), "author_user_id": user.id,
                     "lines": lines_data, "totals": totals_raw}],
        portal_token=_new_token(),
    )
    res = await db.quotes.insert_one(q.to_mongo())
    q.id = str(res.inserted_id)
    await _record_interaction(db, org_id, contact_id=req.contact_id, type_="quote_created",
                                 summary=f"Quote {number} — {totals_raw['total_cents']/100:.2f} {req.currency}",
                                 ref_type="quote", ref_id=q.id,
                                 meta={"approval_state": approval_state, "reason": reason},
                                 author_user_id=user.id)
    return q.model_dump()


@quotes_router.get("")
async def list_quotes(status: Optional[str] = None, contact_id: Optional[str] = None,
                        user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if status: q["status"] = status
    if contact_id: q["contact_id"] = contact_id
    cursor = db.quotes.find(q).sort("created_at", -1).limit(200)
    return {"quotes": [Quote.from_mongo(d).model_dump() async for d in cursor]}


@quotes_router.get("/{qid}")
async def get_quote(qid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.quotes.find_one({"_id": ObjectId(qid), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Quote not found")
    return Quote.from_mongo(doc).model_dump()


class QuoteApprove(BaseModel):
    approve: bool
    note: Optional[str] = None


@quotes_router.post("/{qid}/approve")
async def approve_quote(qid: str, req: QuoteApprove,
                         user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.quotes.find_one({"_id": ObjectId(qid), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Quote not found")
    if doc.get("approval_state") != "pending":
        raise HTTPException(400, "Quote is not pending approval")
    # RBAC — check the caller's role
    caller_role = user.role
    if caller_role not in ("owner", "manager"):
        raise HTTPException(403, "Only owner/manager can approve quotes")
    if req.approve:
        updates = {"approval_state": "approved", "approved_by": user.id,
                    "approved_at": utc_now_iso(), "status": "draft",
                    "approval_note": req.note, "updated_at": utc_now_iso()}
    else:
        updates = {"approval_state": "rejected", "rejected_by": user.id,
                    "rejected_at": utc_now_iso(), "status": "rejected",
                    "approval_note": req.note, "updated_at": utc_now_iso()}
    await db.quotes.update_one({"_id": ObjectId(qid)}, {"$set": updates})
    await _record_interaction(db, org_id, contact_id=doc.get("contact_id"),
                                 type_=f"quote_{updates['approval_state']}",
                                 summary=f"Quote {doc.get('number')} {updates['approval_state']} by {user.email}",
                                 ref_type="quote", ref_id=qid, author_user_id=user.id,
                                 meta={"note": req.note})
    return {"ok": True}


@quotes_router.post("/{qid}/send")
async def send_quote(qid: str, user: User = Depends(current_user),
                      org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.quotes.find_one({"_id": ObjectId(qid), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Quote not found")
    if doc.get("approval_state") == "pending":
        raise HTTPException(400, "Quote is pending approval — approve first")
    await db.quotes.update_one({"_id": ObjectId(qid)},
                                 {"$set": {"status": "sent", "updated_at": utc_now_iso()}})
    try:
        from .marketing import fire_trigger as _fire
        await _fire(org_id, "quote_sent", {"contact_id": doc.get("contact_id"), "quote_id": qid,
                                           "quote_number": doc.get("number"), "total_cents": doc.get("total_cents")})
    except Exception as _e:  # noqa: BLE001
        logger.warning("quote_sent trigger failed: %s", _e)
    await _record_interaction(db, org_id, contact_id=doc.get("contact_id"),
                                 type_="quote_sent",
                                 summary=f"Quote {doc.get('number')} sent to customer",
                                 ref_type="quote", ref_id=qid, author_user_id=user.id)
    return {"ok": True, "portal_token": doc.get("portal_token")}


class QuoteConvertReq(BaseModel):
    to_invoice: bool = True
    to_job: bool = False
    due_days: int = 14


@quotes_router.post("/{qid}/convert")
async def convert_quote(qid: str, req: QuoteConvertReq, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.quotes.find_one({"_id": ObjectId(qid), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Quote not found")
    if doc.get("status") not in ("accepted",):
        raise HTTPException(400, "Only accepted quotes can be converted")
    out: Dict[str, Any] = {}
    if req.to_invoice:
        inv_lines = [InvoiceLine(id=uuid.uuid4().hex[:8],
                                    label=l.get("label") or "",
                                    description=l.get("description"),
                                    quantity=l.get("quantity", 1),
                                    unit_price_cents=l.get("unit_price_cents", 0),
                                    tax_rate=l.get("tax_rate", doc.get("tax_rate", 0)),
                                    taxable=l.get("taxable", True))
                      for l in doc.get("lines", [])]
        totals = doc.get("totals") or {}
        inv = Invoice(
            org_id=org_id, contact_id=doc.get("contact_id"), quote_id=qid,
            author_user_id=user.id, status="sent",
            lines=inv_lines, tax_rate=doc.get("tax_rate", 0),
            subtotal_cents=totals.get("subtotal_cents", 0),
            tax_cents=totals.get("tax_cents", 0),
            total_cents=totals.get("total_cents", 0),
            currency=doc.get("currency", "USD"),
            due_at=(datetime.now(timezone.utc) + timedelta(days=req.due_days)).isoformat(),
            portal_token=_new_token(),
        )
        inv.number = await _next_number(db, org_id, "invoices", "INV")
        res = await db.invoices.insert_one(inv.to_mongo())
        inv.id = str(res.inserted_id)
        out["invoice_id"] = inv.id
        await _record_interaction(db, org_id, contact_id=doc.get("contact_id"),
                                     type_="invoice_created",
                                     summary=f"Invoice {inv.number} created from quote {doc.get('number')}",
                                     ref_type="invoice", ref_id=inv.id, author_user_id=user.id)
    if req.to_job:
        job = Job(
            org_id=org_id, name=f"Job for quote {doc.get('number')}",
            contact_id=doc.get("contact_id"), quote_id=qid,
            invoice_id=out.get("invoice_id"),
            checklist=[ChecklistItem(id=uuid.uuid4().hex[:8], label=l.get("label") or "")
                          for l in doc.get("lines", [])],
        )
        job.number = await _next_number(db, org_id, "jobs", "J")
        res = await db.jobs.insert_one(job.to_mongo())
        job.id = str(res.inserted_id)
        out["job_id"] = job.id
        await _record_interaction(db, org_id, contact_id=doc.get("contact_id"),
                                     type_="job_created",
                                     summary=f"Job {job.number} created from quote {doc.get('number')}",
                                     ref_type="job", ref_id=job.id, author_user_id=user.id)
    return out


# Customer portal

@public_portal.get("/quote/{qid}")
async def portal_quote(qid: str, tk: str):
    db = get_db()
    doc = await db.quotes.find_one({"_id": ObjectId(qid)})
    if not doc:
        raise HTTPException(404, "Quote not found")
    if not _tokens_equal(tk, doc.get("portal_token")):
        raise HTTPException(403, "Invalid token")
    org = await db.organizations.find_one({"_id": ObjectId(doc["org_id"])})
    business = await db.business_profiles.find_one({"org_id": doc["org_id"]})
    # Mark viewed
    if doc.get("status") in ("sent",):
        await db.quotes.update_one({"_id": doc["_id"]}, {"$set": {"status": "viewed",
                                                                     "updated_at": utc_now_iso()}})
    return {
        "quote": Quote.from_mongo(doc).model_dump(),
        "business": {"business_name": (business or {}).get("business_name"),
                      "tagline": (business or {}).get("tagline")},
        "org_name": (org or {}).get("name"),
    }


class QuoteDeclineReq(BaseModel):
    reason: Optional[str] = None


@public_portal.post("/quote/{qid}/accept")
async def portal_accept_quote(qid: str, tk: str, request: Request):
    db = get_db()
    doc = await db.quotes.find_one({"_id": ObjectId(qid)})
    if not doc:
        raise HTTPException(404, "Quote not found")
    if not _tokens_equal(tk, doc.get("portal_token")):
        raise HTTPException(403, "Invalid token")
    if doc.get("status") in ("accepted",):
        return {"ok": True, "already": True}
    if doc.get("approval_state") == "pending":
        raise HTTPException(400, "Quote is pending internal approval")
    meta = {"ip": request.client.host if request.client else None,
             "user_agent": request.headers.get("user-agent")}
    await db.quotes.update_one({"_id": doc["_id"]},
                                 {"$set": {"status": "accepted",
                                             "accepted_at": utc_now_iso(),
                                             "accepted_meta": meta,
                                             "updated_at": utc_now_iso()}})
    await _record_interaction(db, doc["org_id"], contact_id=doc.get("contact_id"),
                                 type_="quote_accepted",
                                 summary=f"Quote {doc.get('number')} accepted by customer",
                                 ref_type="quote", ref_id=qid, meta=meta)
    return {"ok": True}


@public_portal.post("/quote/{qid}/decline")
async def portal_decline_quote(qid: str, tk: str, req: QuoteDeclineReq, request: Request):
    db = get_db()
    doc = await db.quotes.find_one({"_id": ObjectId(qid)})
    if not doc:
        raise HTTPException(404, "Quote not found")
    if not _tokens_equal(tk, doc.get("portal_token")):
        raise HTTPException(403, "Invalid token")
    if doc.get("status") in ("accepted", "declined"):
        return {"ok": True, "already": True}
    meta = {"ip": request.client.host if request.client else None,
             "reason": req.reason}
    await db.quotes.update_one({"_id": doc["_id"]},
                                 {"$set": {"status": "declined",
                                             "updated_at": utc_now_iso()}})
    await _record_interaction(db, doc["org_id"], contact_id=doc.get("contact_id"),
                                 type_="quote_declined",
                                 summary=f"Quote {doc.get('number')} declined by customer"
                                           + (f": {req.reason}" if req.reason else ""),
                                 ref_type="quote", ref_id=qid, meta=meta)
    return {"ok": True}


# =============== INVOICES + PAYMENTS ===============

@invoices_router.get("")
async def list_invoices(status: Optional[str] = None,
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if status: q["status"] = status
    cursor = db.invoices.find(q).sort("created_at", -1).limit(200)
    return {"invoices": [Invoice.from_mongo(d).model_dump() async for d in cursor]}


@invoices_router.get("/{iid}")
async def get_invoice(iid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.invoices.find_one({"_id": ObjectId(iid), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Invoice not found")
    return Invoice.from_mongo(doc).model_dump()


@public_portal.get("/invoice/{iid}")
async def portal_invoice(iid: str, tk: str):
    db = get_db()
    doc = await db.invoices.find_one({"_id": ObjectId(iid)})
    if not doc or not _tokens_equal(tk, doc.get("portal_token")):
        raise HTTPException(403, "Invalid token or invoice not found")
    business = await db.business_profiles.find_one({"org_id": doc["org_id"]})
    return {"invoice": Invoice.from_mongo(doc).model_dump(),
             "business": {"business_name": (business or {}).get("business_name")}}


class CheckoutStartReq(BaseModel):
    invoice_id: str
    provider: Literal["simulated", "stripe"] = "simulated"
    success_url: str = "/pay/success"
    cancel_url: str = "/pay/cancel"


@public_portal.post("/invoice/{iid}/checkout")
async def portal_checkout(iid: str, tk: str, req: CheckoutStartReq):
    db = get_db()
    doc = await db.invoices.find_one({"_id": ObjectId(iid)})
    if not doc or not _tokens_equal(tk, doc.get("portal_token")):
        raise HTTPException(403, "Invalid token or invoice not found")
    if doc.get("status") == "paid":
        raise HTTPException(400, "Invoice already paid")
    amount = int(doc.get("total_cents", 0) - doc.get("amount_paid_cents", 0))
    if amount <= 0:
        raise HTTPException(400, "Nothing to pay")
    provider = build_payment_provider(req.provider)
    contact = None
    if doc.get("contact_id"):
        contact = await db.contacts.find_one({"_id": ObjectId(doc["contact_id"])})
    email = ((contact or {}).get("emails") or [None])[0]
    result = await provider.create_checkout(CheckoutRequest(
        invoice_id=iid, amount_cents=amount, currency=doc.get("currency", "USD"),
        customer_email=email, success_url=req.success_url, cancel_url=req.cancel_url,
        metadata={"invoice_id": iid, "org_id": doc["org_id"]},
    ))
    if not result.ok:
        raise HTTPException(502, {"error": "checkout_failed", "detail": result.error, "hint": result.hint})
    pay = Payment(
        org_id=doc["org_id"], invoice_id=iid, amount_cents=amount,
        currency=doc.get("currency", "USD"),
        method="stripe_checkout" if req.provider == "stripe" else "simulated",
        provider="stripe" if req.provider == "stripe" else "simulated",
        provider_session_id=result.session_id, status="initiated",
    )
    await db.payments.insert_one(pay.to_mongo())
    return {"checkout_url": result.checkout_url, "session_id": result.session_id,
             "simulated": bool(result.simulated)}


class SimulatedPayReq(BaseModel):
    session_id: str


@payments_router.post("/simulated/pay")
async def simulated_pay_endpoint(req: SimulatedPayReq, request: Request):
    """Public: called by the in-app simulated checkout page. Marks the session paid,
    updates the invoice, and drains synthetic webhook events into DB state.

    Disabled in production — real money is confirmed only by verified provider webhooks."""
    from .. import config as cfg
    if not cfg.simulation_allowed():
        raise HTTPException(403, {"error": "simulated_payment_forbidden",
                                  "message": "Simulated payments are disabled in production."})
    if not simulated_pay(req.session_id):
        raise HTTPException(400, "Session not payable")
    db = get_db()
    # Process events
    events = drain_simulated_events()
    for ev in events:
        if ev["type"] == "checkout.session.completed":
            await _apply_paid_event(db, ev["session_id"], ev.get("amount_cents"))
    return {"ok": True}


async def _apply_paid_event(db, session_id: str, amount_cents: Optional[int]) -> None:
    # Store orders use the same simulated session lifecycle — route them to the
    # store handler (idempotent: flips order paid + decrements stock once).
    store_pay = await db.payments.find_one({"provider_session_id": session_id,
                                             "kind": "store_order"})
    if store_pay:
        from .store import apply_store_order_paid
        await apply_store_order_paid(db, session_id, amount_cents)
        return
    pay = await db.payments.find_one({"provider_session_id": session_id})
    if not pay or pay.get("status") == "paid":
        return
    inv = await db.invoices.find_one({"_id": ObjectId(pay["invoice_id"])})
    if not inv:
        return
    paid_now = int(amount_cents or pay["amount_cents"])
    new_paid = int(inv.get("amount_paid_cents", 0)) + paid_now
    new_status = "paid" if new_paid >= inv["total_cents"] else "partial"
    await db.payments.update_one({"_id": pay["_id"]},
                                    {"$set": {"status": "paid", "updated_at": utc_now_iso()}})
    await db.invoices.update_one({"_id": inv["_id"]},
                                    {"$set": {"amount_paid_cents": new_paid,
                                                "status": new_status,
                                                "updated_at": utc_now_iso()}})
    await _record_interaction(db, inv["org_id"], contact_id=inv.get("contact_id"),
                                 type_="payment_received",
                                 summary=f"Payment received: {paid_now/100:.2f} {inv.get('currency')} (simulated)",
                                 ref_type="payment", ref_id=str(pay["_id"]),
                                 meta={"invoice_id": pay["invoice_id"], "simulated": True})


@payments_router.get("/status/{session_id}")
async def payment_status(session_id: str):
    """Public: unauthenticated status check for a payment session."""
    db = get_db()
    pay = await db.payments.find_one({"provider_session_id": session_id})
    if not pay:
        raise HTTPException(404, "Session not found")
    return {"session_id": session_id, "status": pay.get("status"),
             "invoice_id": pay.get("invoice_id"), "amount_cents": pay.get("amount_cents"),
             "currency": pay.get("currency"), "simulated": pay.get("provider") == "simulated"}


@payments_router.get("/providers")
async def payment_providers(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"providers": list_payment_providers()}


# =============== JOBS ===============

class JobPatch(BaseModel):
    model_config = {"extra": "forbid"}
    name: Optional[str] = None
    address: Optional[str] = None
    staff_id: Optional[str] = None
    status: Optional[Literal["scheduled", "in_progress", "completed", "cancelled"]] = None
    notes: Optional[str] = None


@jobs_router.get("")
async def list_jobs(status: Optional[str] = None, staff_id: Optional[str] = None,
                     user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if status: q["status"] = status
    if staff_id: q["staff_id"] = staff_id
    cursor = db.jobs.find(q).sort("created_at", -1).limit(200)
    return {"jobs": [Job.from_mongo(d).model_dump() async for d in cursor]}


@jobs_router.patch("/{jid}")
async def patch_job(jid: str, req: JobPatch,
                     user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    updates = {k: v for k, v in req.model_dump(exclude_none=True).items()}
    if not updates:
        raise HTTPException(400, "Nothing to update")
    if updates.get("status") == "completed":
        updates["completed_at"] = utc_now_iso()
    elif updates.get("status") == "in_progress":
        updates["started_at"] = utc_now_iso()
    updates["updated_at"] = utc_now_iso()
    res = await db.jobs.update_one({"_id": ObjectId(jid), "org_id": org_id}, {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(404, "Job not found")
    fresh = await db.jobs.find_one({"_id": ObjectId(jid), "org_id": org_id})
    # If just completed → queue a follow-up "thank-you + review-request placeholder"
    if updates.get("status") == "completed":
        await _queue_job_followup(db, fresh, user)
    return Job.from_mongo(fresh).model_dump()


async def _queue_job_followup(db, job: Dict[str, Any], user: User) -> None:
    """Schedule a follow-up email 2 hours after job completion via ScheduledSend."""
    contact = None
    if job.get("contact_id"):
        contact = await db.contacts.find_one({"_id": ObjectId(job["contact_id"])})
    if not contact or not (contact.get("emails") or []):
        return
    release = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat()
    # We need a conversation for scheduled_sends. Reuse or create.
    conv = await db.conversations.find_one({"org_id": job["org_id"], "contact_id": job["contact_id"]},
                                              sort=[("last_message_at", -1)])
    if not conv:
        from ..models_crm import Conversation
        c = Conversation(org_id=job["org_id"], channel="email", contact_id=job["contact_id"],
                          subject=f"Follow-up for job {job.get('number')}", status="open",
                          unread=False, last_message_at=utc_now_iso(),
                          last_message_preview="Thanks — quick follow-up")
        cr = await db.conversations.insert_one(c.to_mongo())
        conv_id = str(cr.inserted_id)
    else:
        conv_id = str(conv["_id"])
    email = contact["emails"][0]
    sched = ScheduledSend(
        org_id=job["org_id"], conversation_id=conv_id, author_user_id=user.id,
        release_at=release,
        payload={"to": [email], "subject": "Thank you — quick favor?",
                    "body_text": (f"Thanks for having us. Job {job.get('number')} is complete. "
                                   f"When you have a moment, we'd love a short review — just reply to this email."),
                    "reply_to_message_id": None},
    )
    r = await db.scheduled_sends.insert_one(sched.to_mongo())
    await _record_interaction(db, job["org_id"], contact_id=job["contact_id"],
                                 type_="job_completed",
                                 summary=f"Job {job.get('number')} completed — follow-up scheduled",
                                 ref_type="job", ref_id=str(job["_id"]),
                                 meta={"scheduled_send_id": str(r.inserted_id),
                                         "release_at": release})


class ChecklistCheck(BaseModel):
    item_id: str
    done: bool = True


@jobs_router.post("/{jid}/checklist/check")
async def check_item(jid: str, req: ChecklistCheck,
                       user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.jobs.find_one({"_id": ObjectId(jid), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Job not found")
    checklist = doc.get("checklist") or []
    for item in checklist:
        if item.get("id") == req.item_id:
            item["done"] = req.done
            item["done_at"] = utc_now_iso() if req.done else None
            item["done_by_user_id"] = user.id if req.done else None
    await db.jobs.update_one({"_id": doc["_id"]}, {"$set": {"checklist": checklist,
                                                                 "updated_at": utc_now_iso()}})
    return {"ok": True}
