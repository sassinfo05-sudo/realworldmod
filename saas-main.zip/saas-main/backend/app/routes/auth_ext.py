"""Auth extensions for Phase 6: MFA (TOTP), rate limiting on auth + public forms/chat,
secure token compare on portal tokens.
"""
from __future__ import annotations

import hmac
import logging
import secrets
from datetime import datetime, timezone
from typing import Literal, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr

from ..db import get_db, utc_now_iso
from ..deps import current_user
from ..models import User
from ..security import hash_password, verify_password
from ..services import audit, mfa
from ..services.entitlements import enforce_entitlement

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/auth", tags=["auth-mfa"])


# ---------- Team ----------

@router.get("/team")
async def team(user: User = Depends(current_user)):
    if not user.org_id:
        return {"members": []}
    db = get_db()
    members = []
    async for u in db.users.find({"org_id": user.org_id}).sort("created_at", 1):
        members.append({"id": str(u["_id"]), "email": u.get("email"),
                        "role": u.get("role"), "full_name": u.get("full_name"),
                        "mfa_enabled": bool((await db.mfa_secrets.find_one({"user_id": str(u["_id"]),
                                                                                "enabled": True}))),
                        "created_at": u.get("created_at")})
    return {"members": members}


class InviteReq(BaseModel):
    email: EmailStr
    # Accepted invite roles are enumerated so the OpenAPI schema exposes the
    # full set. `readonly` is intentionally not invitable via this endpoint.
    role: Literal["owner", "manager", "staff"] = "staff"
    full_name: Optional[str] = None


@router.post("/team/invite")
async def invite_teammate(req: InviteReq, request: Request,
                              user: User = Depends(current_user)):
    if user.role not in ("owner", "manager", "platform_founder"):
        raise HTTPException(403, "Insufficient role")
    if user.role == "platform_founder":
        raise HTTPException(400, "Founder has no org; impersonate first")
    if req.role not in ("owner", "manager", "staff"):
        raise HTTPException(422, "Unknown role")
    db = get_db()
    email = req.email.lower().strip()
    if await db.users.find_one({"email": email}):
        raise HTTPException(409, "Email already registered")
    await enforce_entitlement(user.org_id, "users", increment=1)
    # Invitee gets a set-password link (hashed single-use token, 48h). The account has an
    # unguessable random password until they set their own. No temporary password is ever
    # returned by the API in production — only a dev-mode inline link when no sender is connected.
    tmp_pw = secrets.token_urlsafe(24)
    r = await db.users.insert_one({
        "email": email, "password_hash": hash_password(tmp_pw),
        "full_name": req.full_name, "org_id": user.org_id,
        "role": req.role, "email_verified": False, "invited_by": user.id,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    from .auth import _hash_token, _send_reset_email  # reuse the hashed reset-token flow
    from ..security import generate_reset_token
    from .. import config as _cfg
    from datetime import timedelta
    token = generate_reset_token()
    await db.password_reset_tokens.insert_one({
        "user_id": str(r.inserted_id), "token_hash": _hash_token(token),
        "expires_at": (datetime.now(timezone.utc) + timedelta(hours=48)).isoformat(),
        "consumed": False, "purpose": "invite", "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    sent = await _send_reset_email(email, token)
    await audit.record(action="team.invite", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=user.org_id,
                          target_type="user", target_id=email,
                          meta={"role": req.role, "emailed": sent}, request=request)
    out = {"ok": True, "email": email, "emailed": sent,
           "note": ("Invitation email sent with a set-password link." if sent else
                    "No email provider is connected yet — connect one in Staff → Email to send invitations automatically.")}
    if not sent and _cfg.APP_ENV in ("dev", "test", "demo"):
        out["dev_set_password_token"] = token
    return out


# ---------- Login rate limit (wraps existing login) ----------

class LoginReq(BaseModel):
    email: EmailStr
    password: str
    mfa_code: Optional[str] = None


class TokenResp(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict
    mfa_required: bool = False


@router.post("/login-secure")
async def secure_login(req: LoginReq, request: Request):
    """DEPRECATED alias. Every login path must enforce ONE MFA/session policy, so this
    delegates to the canonical `/api/auth/login` (TOTP challenge + email-code + persistent
    rate limiting + session-invalidation checks). Clients should call /api/auth/login."""
    from .auth import login as _canonical_login, LoginReq as _CanonicalLoginReq
    return await _canonical_login(_CanonicalLoginReq(email=req.email, password=req.password), request)


# ---------- MFA enrollment ----------

@router.post("/mfa/start")
async def mfa_start(user: User = Depends(current_user)):
    """Kick off enrollment — returns TOTP secret + QR data URL. Not yet enabled."""
    db = get_db()
    existing = await db.mfa_secrets.find_one({"user_id": user.id, "enabled": True})
    if existing:
        raise HTTPException(400, "MFA already enabled — disable first to re-enroll")
    secret = mfa.generate_secret()
    uri = mfa.totp_uri(secret, user.email)
    qr = mfa.qr_png_data_url(uri)
    await db.mfa_secrets.update_one(
        {"user_id": user.id},
        {"$set": {"user_id": user.id, "secret_base32": mfa.encrypt_secret(secret),
                    "enabled": False, "updated_at": utc_now_iso()},
         "$setOnInsert": {"created_at": utc_now_iso(),
                            "backup_codes_hashed": []}},
        upsert=True,
    )
    return {"secret": secret, "qr_png": qr, "otpauth_uri": uri}


class MfaConfirm(BaseModel):
    code: str


@router.post("/mfa/confirm")
async def mfa_confirm(req: MfaConfirm, request: Request,
                          user: User = Depends(current_user)):
    """Confirm the 6-digit code from the authenticator — enables MFA + issues backup codes."""
    db = get_db()
    doc = await db.mfa_secrets.find_one({"user_id": user.id})
    if not doc:
        raise HTTPException(400, "Start enrollment first")
    if not mfa.verify_code(mfa.secret_from_doc(doc), req.code):
        raise HTTPException(401, "Invalid code")
    plain, hashed = mfa.generate_backup_codes(8)
    await db.mfa_secrets.update_one(
        {"_id": doc["_id"]},
        {"$set": {"enabled": True, "activated_at": utc_now_iso(),
                    "backup_codes_hashed": hashed,
                    "updated_at": utc_now_iso()}},
    )
    await audit.record(action="mfa.enroll", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email,
                          org_id=user.org_id, request=request)
    return {"ok": True, "backup_codes": plain,
             "note": "Save these one-time backup codes. They're shown once and each can be used once."}


class MfaDisable(BaseModel):
    password: str
    code: Optional[str] = None


@router.post("/mfa/disable")
async def mfa_disable(req: MfaDisable, request: Request,
                          user: User = Depends(current_user)):
    """Disable — requires current password. Founder role additionally requires TOTP code
    or a backup code (defence-in-depth for the highest-privilege account).
    """
    db = get_db()
    u = await db.users.find_one({"_id": ObjectId(user.id)})
    if not u or not verify_password(req.password, u["password_hash"]):
        raise HTTPException(401, "Password check failed")
    doc = await db.mfa_secrets.find_one({"user_id": user.id, "enabled": True})
    if not doc:
        return {"ok": True, "already": True}
    if user.role == "platform_founder":
        code = (req.code or "").strip()
        if not code:
            raise HTTPException(401, "Founder MFA disable requires a TOTP code or backup code.")
        if not mfa.verify_code(doc["secret_base32"], code) and \
                mfa.hash_backup(code) not in (doc.get("backup_codes_hashed") or []):
            raise HTTPException(401, "Invalid MFA code")
    await db.mfa_secrets.update_one({"_id": doc["_id"]},
                                        {"$set": {"enabled": False, "activated_at": None,
                                                    "backup_codes_hashed": [],
                                                    "updated_at": utc_now_iso()}})
    await audit.record(action="mfa.disable", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email,
                          org_id=user.org_id, request=request)
    return {"ok": True}


@router.get("/mfa/status")
async def mfa_status(user: User = Depends(current_user)):
    db = get_db()
    doc = await db.mfa_secrets.find_one({"user_id": user.id})
    if not doc:
        return {"enabled": False, "enrollable": True}
    return {"enabled": bool(doc.get("enabled")),
             "activated_at": doc.get("activated_at"),
             "backup_codes_remaining": len(doc.get("backup_codes_hashed") or [])}


def secure_token_equal(a: str, b: str) -> bool:
    """Constant-time compare — use in every portal-token check."""
    return hmac.compare_digest((a or "").encode("utf-8"), (b or "").encode("utf-8"))
