import { useEffect, useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { Package, Key, Webhook, ShieldCheck, Download } from "lucide-react";

const SUBNAV = [
    { to: "/app/setup", label: "Overview", icon: Package, end: true },
    { to: "/app/setup/api-keys", label: "API keys", icon: Key },
    { to: "/app/setup/webhooks", label: "Webhooks", icon: Webhook },
    { to: "/app/setup/security", label: "Security & MFA", icon: ShieldCheck },
    { to: "/app/setup/data", label: "Export / delete", icon: Download },
];

export default function SetupShell() {
    return (
        <div className="min-h-full" data-testid="setup-shell">
            <div className="border-b border-brand-line bg-white sticky top-0 z-10">
                <div className="px-6 py-3 flex flex-wrap gap-2 items-center">
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mr-3">Setup Center</div>
                    <nav className="flex gap-1 flex-wrap">
                        {SUBNAV.map(({ to, label, icon: Icon, end }) => (
                            <NavLink
                                key={to} to={to} end={!!end}
                                data-testid={`setup-subnav-${label.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                                className={({ isActive }) =>
                                    `inline-flex items-center gap-1.5 text-sm px-2.5 py-1.5 rounded-md transition-colors ${
                                        isActive ? "bg-brand-cream text-brand-ink" : "text-zinc-500 hover:text-brand-ink"
                                    }`
                                }
                            >
                                <Icon className="w-3.5 h-3.5" />
                                {label}
                            </NavLink>
                        ))}
                    </nav>
                </div>
            </div>
            <Outlet />
        </div>
    );
}
