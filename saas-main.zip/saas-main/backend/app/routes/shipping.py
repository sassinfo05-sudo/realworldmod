"""Online-selling & shipping routes (owner-scoped + public quote).

Owner endpoints under /api/store/... ; public shipping quote under
/api/public/store/{org_id}/shipping/quote. Complements store.py + ecommerce.py.
"""
from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..services import shipping as ship

router = APIRouter(prefix="/store", tags=["shipping"])
public_router = APIRouter(prefix="/public/store", tags=["shipping-public"])


# =========================== COUNTRIES / CARRIERS ===========================

@router.get("/shipping/countries")
async def shipping_countries(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"countries": ship.list_countries()}


@router.get("/shipping/carriers")
async def shipping_carriers(country: Optional[str] = None,
                            user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return ship.carriers_for_country(country)


# =========================== SETTINGS ===========================

class OriginIn(BaseModel):
    name: str = ""
    address: str = ""
    city: str = ""
    region: str = ""
    postal_code: str = ""
    country: str = "US"


class ShippingSettingsIn(BaseModel):
    model_config = {"extra": "ignore"}
    origin: Optional[OriginIn] = None
    weight_unit: Optional[str] = None            # g | oz
    default_weight_grams: Optional[int] = Field(default=None, ge=0)
    handling_fee_cents: Optional[int] = Field(default=None, ge=0)
    countries_served: Optional[List[str]] = None
    currency: Optional[str] = None


@router.get("/shipping/settings")
async def get_shipping_settings(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await ship.get_settings(org_id)


@router.put("/shipping/settings")
async def put_shipping_settings(req: ShippingSettingsIn,
                                user: User = Depends(current_user), org_id: str = Depends(require_org)):
    patch: Dict[str, Any] = {}
    if req.origin is not None:
        patch["origin"] = req.origin.model_dump()
    for f in ("weight_unit", "default_weight_grams", "handling_fee_cents", "countries_served", "currency"):
        v = getattr(req, f)
        if v is not None:
            patch[f] = v
    return await ship.save_settings(org_id, patch)


# =========================== ZONES + RATES ===========================

class RateIn(BaseModel):
    id: Optional[str] = None
    name: str = "Shipping"
    type: str = "flat"                            # flat | weight | price | free_over
    amount_cents: int = Field(default=0, ge=0)
    free_over_cents: int = Field(default=0, ge=0)
    tiers: List[Dict[str, Any]] = Field(default_factory=list)


class ZoneIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    country_codes: List[str] = Field(default_factory=list)  # "*" = rest of world
    rates: List[RateIn] = Field(default_factory=list)


def _rates_docs(rates: List[RateIn]) -> List[Dict[str, Any]]:
    out = []
    for r in rates:
        d = r.model_dump()
        d["id"] = d.get("id") or uuid.uuid4().hex
        if d.get("type") not in ("flat", "weight", "price", "free_over"):
            raise HTTPException(400, "rate type must be flat|weight|price|free_over")
        out.append(d)
    return out


@router.get("/shipping/zones")
async def list_zones(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = [ship.zone_out(z) async for z in db.store_shipping_zones.find({"org_id": org_id}).sort("created_at", 1)]
    return {"zones": rows}


@router.post("/shipping/zones")
async def create_zone(req: ZoneIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    now = utc_now_iso()
    codes = [c.strip().upper() if c != "*" else "*" for c in req.country_codes if c]
    doc = {"_id": uuid.uuid4().hex, "org_id": org_id, "name": req.name,
           "country_codes": codes, "rates": _rates_docs(req.rates),
           "created_at": now, "updated_at": now}
    await db.store_shipping_zones.insert_one(doc)
    return ship.zone_out(doc)


@router.put("/shipping/zones/{zid}")
async def update_zone(zid: str, req: ZoneIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    codes = [c.strip().upper() if c != "*" else "*" for c in req.country_codes if c]
    patch = {"name": req.name, "country_codes": codes, "rates": _rates_docs(req.rates),
             "updated_at": utc_now_iso()}
    res = await db.store_shipping_zones.find_one_and_update(
        {"_id": zid, "org_id": org_id}, {"$set": patch}, return_document=True)
    if not res:
        raise HTTPException(404, "Zone not found")
    return ship.zone_out(res)


@router.delete("/shipping/zones/{zid}")
async def delete_zone(zid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.store_shipping_zones.delete_one({"_id": zid, "org_id": org_id})
    if not r.deleted_count:
        raise HTTPException(404, "Zone not found")
    return {"ok": True}


class QuoteIn(BaseModel):
    country_code: str
    subtotal_cents: int = Field(default=0, ge=0)
    weight_grams: int = Field(default=0, ge=0)


@router.post("/shipping/quote")
async def owner_quote(req: QuoteIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await ship.quote(org_id, req.country_code, req.subtotal_cents, req.weight_grams)


@public_router.post("/{org_id}/shipping/quote")
async def public_quote(org_id: str, req: QuoteIn):
    return await ship.quote(org_id, req.country_code, req.subtotal_cents, req.weight_grams)


# =========================== INVENTORY ===========================

class AdjustIn(BaseModel):
    product_id: str
    delta: int
    reason: str = ""


@router.post("/inventory/adjust")
async def inventory_adjust(req: AdjustIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    p = await db.store_products.find_one({"_id": req.product_id, "org_id": org_id})
    if not p:
        raise HTTPException(404, "Product not found")
    new_stock = max(0, int(p.get("stock", 0)) + int(req.delta))
    now = utc_now_iso()
    await db.store_products.update_one({"_id": req.product_id, "org_id": org_id},
                                       {"$set": {"stock": new_stock, "updated_at": now}})
    await db.store_inventory_log.insert_one({
        "_id": uuid.uuid4().hex, "org_id": org_id, "product_id": req.product_id,
        "product_name": p.get("name", ""), "delta": int(req.delta),
        "old_stock": int(p.get("stock", 0)), "new_stock": new_stock,
        "reason": req.reason or "manual adjustment",
        "by": getattr(user, "email", ""), "created_at": now})
    return {"product_id": req.product_id, "stock": new_stock}


@router.get("/inventory/log")
async def inventory_log(product_id: Optional[str] = None, limit: int = 100,
                        user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if product_id:
        q["product_id"] = product_id
    rows = []
    async for e in db.store_inventory_log.find(q).sort("created_at", -1).limit(max(1, min(limit, 500))):
        e.pop("_id", None)
        rows.append(e)
    return {"entries": rows}


@router.get("/inventory/low-stock")
async def low_stock(threshold: int = 5, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = []
    async for p in db.store_products.find({"org_id": org_id, "track_inventory": {"$ne": False},
                                           "stock": {"$lte": max(0, threshold)}}).sort("stock", 1):
        rows.append({"id": p["_id"], "name": p.get("name"), "sku": p.get("sku", ""),
                     "stock": int(p.get("stock", 0)), "image_url": p.get("image_url", "")})
    return {"threshold": threshold, "products": rows}


class BulkStockIn(BaseModel):
    items: List[Dict[str, Any]]   # [{product_id, stock}]


@router.post("/inventory/bulk")
async def inventory_bulk(req: BulkStockIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    now = utc_now_iso()
    updated = 0
    for it in req.items:
        pid = it.get("product_id")
        if pid is None or "stock" not in it:
            continue
        stock = max(0, int(it["stock"]))
        r = await db.store_products.update_one({"_id": pid, "org_id": org_id},
                                               {"$set": {"stock": stock, "updated_at": now}})
        if r.modified_count or r.matched_count:
            updated += 1
    return {"updated": updated}


# =========================== ORDER: SHIP + INVOICE ===========================

class ShipIn(BaseModel):
    carrier: str = ""
    tracking_number: str = ""
    tracking_url: str = ""
    notify: bool = True


@router.post("/orders/{order_id}/ship")
async def ship_order(order_id: str, req: ShipIn = ShipIn(),
                     user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    if not o:
        raise HTTPException(404, "Order not found")
    if o.get("status") not in ("paid", "fulfilled", "shipped"):
        raise HTTPException(400, "Only paid orders can be shipped")
    now = utc_now_iso()
    fulfillment = {"carrier": req.carrier, "tracking_number": req.tracking_number,
                   "tracking_url": req.tracking_url, "shipped_at": now}
    await db.store_orders.update_one({"_id": order_id, "org_id": org_id},
                                     {"$set": {"status": "shipped", "shipped_at": now,
                                               "fulfilled_at": o.get("fulfilled_at") or now,
                                               "fulfillment": fulfillment, "updated_at": now}})
    # Timeline
    try:
        from .crm import _record_interaction
        await _record_interaction(
            db, org_id, contact_id=o.get("contact_id"), type_="store_order_shipped",
            summary=f"Order shipped via {req.carrier or 'carrier'}"
                    + (f" · tracking {req.tracking_number}" if req.tracking_number else ""),
            ref_type="store_order", ref_id=order_id, meta=fulfillment)
    except Exception:  # noqa: BLE001
        pass
    # Notify buyer
    if req.notify and (o.get("buyer") or {}).get("email"):
        try:
            await _notify_shipped(db, o, fulfillment)
        except Exception:  # noqa: BLE001
            pass
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    from .store import _order_out
    return _order_out(o)


async def _notify_shipped(db, order, fulfillment) -> None:
    from ..models_crm import EmailProviderConfig
    from ..services.email_providers import SendPayload, build_provider_from_config
    from .store import _get_org
    cfg_doc = await db.email_provider_configs.find_one({"org_id": order["org_id"]})
    cfg = EmailProviderConfig.from_mongo(cfg_doc) if cfg_doc else EmailProviderConfig(org_id=order["org_id"])
    provider = build_provider_from_config(cfg)
    org = await _get_org(db, order["org_id"])
    store_name = (org or {}).get("name", "our store")
    buyer = order.get("buyer", {})
    track = ""
    if fulfillment.get("tracking_number"):
        track = f"Tracking number: {fulfillment['tracking_number']}\n"
    if fulfillment.get("tracking_url"):
        track += f"Track it here: {fulfillment['tracking_url']}\n"
    body = (f"Hi {buyer.get('name') or 'there'},\n\n"
            f"Good news — your order (ref {order['_id'][:8]}) has shipped"
            + (f" via {fulfillment.get('carrier')}" if fulfillment.get("carrier") else "") + ".\n\n"
            f"{track}\nThanks for shopping with {store_name}!\n")
    await provider.send(SendPayload(
        from_email=cfg.from_email or "notifications@zanelvo.local",
        from_name=cfg.from_name or store_name, to=[buyer["email"]],
        subject=f"Your order has shipped — {store_name}", text=body))


@router.get("/orders/{order_id}/invoice")
async def order_invoice(order_id: str, doc: str = "invoice",
                        user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    if not o:
        raise HTTPException(404, "Order not found")
    from .store import _get_org
    org = await _get_org(db, org_id)
    settings = await ship.get_settings(org_id)
    html_doc = ship.render_document(o, org or {}, settings, doc=doc)
    return {"html": html_doc, "doc": doc, "order_id": order_id}


@router.get("/orders/{order_id}/invoice.html", response_class=Response)
async def order_invoice_html(order_id: str, doc: str = "invoice",
                             user: User = Depends(current_user), org_id: str = Depends(require_org)):
    payload = await order_invoice(order_id, doc, user, org_id)
    return Response(content=payload["html"], media_type="text/html")
