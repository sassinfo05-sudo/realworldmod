import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import api from "@/lib/api";
import { toast } from "sonner";
import {
    RefreshCw, CheckCircle2, FlaskConical, PlugZap, AlertTriangle, Rocket,
    ArrowRight, ChevronDown, HardDrive, PartyPopper,
} from "lucide-react";

const STYLE = {
    connected: { cls: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/20 dark:text-emerald-200", icon: CheckCircle2, label: "Connected" },
    sandbox: { cls: "bg-sky-100 text-sky-800 dark:bg-sky-500/20 dark:text-sky-200", icon: FlaskConical, label: "Sandbox" },
    not_connected: { cls: "bg-zinc-100 text-zinc-600 dark:bg-white/10 dark:text-white/60", icon: PlugZap, label: "Not connected" },
    error: { cls: "bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-200", icon: AlertTriangle, label: "Error" },
};

const STORAGE_PROVIDERS = [
    { v: "s3", label: "Amazon S3" },
    { v: "r2", label: "Cloudflare R2" },
    { v: "b2", label: "Backblaze B2" },
    { v: "minio", label: "MinIO / S3-compatible" },
];

function StorageConfig({ onSaved }) {
    const [cfg, setCfg] = useState(null);
    const [form, setForm] = useState({});
    const [busy, setBusy] = useState(false);
    const [testing, setTesting] = useState(false);

    async function load() {
        try {
            const r = await api.get("/founder/storage");
            setCfg(r.data);
            const c = r.data?.config || {};
            setForm({
                provider: c.provider || "s3", bucket: c.bucket || "", endpoint: c.endpoint || "",
                region: c.region || "", public_base_url: c.public_base_url || "",
                access_key_id: "", secret_access_key: "",
            });
        } catch (e) { toast.error(e?.response?.data?.detail || "Cannot load storage config"); }
    }
    useEffect(() => { load(); }, []);

    async function save() {
        setBusy(true);
        try {
            // Only send secrets if the owner typed a new value (masked placeholders are never re-sent).
            const patch = { ...form };
            if (!patch.access_key_id) delete patch.access_key_id;
            if (!patch.secret_access_key) delete patch.secret_access_key;
            const r = await api.put("/founder/storage", patch);
            setCfg(r.data);
            toast.success("Storage settings saved");
            onSaved?.();
        } catch (e) { toast.error(e?.response?.data?.detail || "Save failed"); }
        finally { setBusy(false); }
    }

    async function test() {
        setTesting(true);
        try {
            const r = await api.post("/founder/storage/test");
            const ok = r.data?.configured && (r.data?.status === "ok" || r.data?.health?.ok);
            ok ? toast.success("Storage reachable") : toast.warning(`Storage status: ${r.data?.status || "unknown"}`);
            onSaved?.();
        } catch (e) { toast.error(e?.response?.data?.detail || "Test failed"); }
        finally { setTesting(false); }
    }

    const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
    const secretSet = cfg?.config?.access_key_id && String(cfg.config.access_key_id).includes("(set)");

    return (
        <div className="mt-3 rounded-xl border border-brand-line dark:border-white/10 bg-brand-cream/50 dark:bg-white/5 p-4" data-testid="golive-storage-form">
            <div className="grid sm:grid-cols-2 gap-3">
                <label className="text-xs text-zinc-600 dark:text-white/70">Provider
                    <select value={form.provider || "s3"} onChange={set("provider")} data-testid="golive-storage-provider"
                        className="mt-1 w-full rounded-md border border-brand-line dark:border-white/15 bg-white dark:bg-black/20 px-2 py-1.5 text-sm text-brand-ink dark:text-white">
                        {STORAGE_PROVIDERS.map((p) => <option key={p.v} value={p.v}>{p.label}</option>)}
                    </select>
                </label>
                <Field label="Bucket / container" value={form.bucket} onChange={set("bucket")} placeholder="zanelvo-media" testid="golive-storage-bucket" />
                <Field label="Endpoint (R2/B2/MinIO)" value={form.endpoint} onChange={set("endpoint")} placeholder="https://<acct>.r2.cloudflarestorage.com" />
                <Field label="Region" value={form.region} onChange={set("region")} placeholder="auto / us-east-1" />
                <Field label="Public / CDN base URL" value={form.public_base_url} onChange={set("public_base_url")} placeholder="https://cdn.yourdomain.com" />
                <Field label={`Access key ID${secretSet ? " (set — leave blank to keep)" : ""}`} value={form.access_key_id} onChange={set("access_key_id")} placeholder="••••" />
                <Field label={`Secret access key${secretSet ? " (set — leave blank to keep)" : ""}`} value={form.secret_access_key} onChange={set("secret_access_key")} placeholder="••••" type="password" />
            </div>
            <p className="text-[11px] text-zinc-500 mt-2">Keys are encrypted at rest and never shown again. Existing assets keep being read from the provider they were uploaded with.</p>
            <div className="mt-3 flex gap-2">
                <button onClick={save} disabled={busy} data-testid="golive-storage-save"
                    className="inline-flex items-center gap-1.5 text-sm rounded-md bg-brand-copper text-white px-3 py-1.5 disabled:opacity-60">
                    {busy ? "Saving…" : "Save storage settings"}
                </button>
                <button onClick={test} disabled={testing} data-testid="golive-storage-test"
                    className="inline-flex items-center gap-1.5 text-sm rounded-md border border-brand-line dark:border-white/15 px-3 py-1.5">
                    <HardDrive className={`w-4 h-4 ${testing ? "animate-pulse" : ""}`} /> Test connection
                </button>
            </div>
        </div>
    );
}

function Field({ label, value, onChange, placeholder, type = "text", testid }) {
    return (
        <label className="text-xs text-zinc-600 dark:text-white/70">{label}
            <input type={type} value={value || ""} onChange={onChange} placeholder={placeholder} data-testid={testid}
                className="mt-1 w-full rounded-md border border-brand-line dark:border-white/15 bg-white dark:bg-black/20 px-2 py-1.5 text-sm text-brand-ink dark:text-white" />
        </label>
    );
}

export default function GoLive() {
    const [data, setData] = useState(null);
    const [busy, setBusy] = useState(false);
    const [openKey, setOpenKey] = useState(null);

    async function load() {
        setBusy(true);
        try { const r = await api.get("/staff/providers/go-live"); setData(r.data); }
        catch (e) { toast.error(e?.response?.data?.detail || "Cannot load go-live status"); }
        finally { setBusy(false); }
    }
    useEffect(() => { load(); }, []);

    const s = data?.summary;
    const pct = s?.required_total ? Math.round((s.required_connected / s.required_total) * 100) : 0;

    return (
        <div className="max-w-4xl" data-testid="golive-page">
            <div className={`rounded-2xl border p-5 ${data?.live_ready
                ? "border-emerald-300 bg-emerald-50 dark:bg-emerald-500/10 dark:border-emerald-500/30"
                : "border-brand-line bg-white dark:bg-white/5 dark:border-white/10"}`}>
                <div className="flex items-start justify-between flex-wrap gap-3">
                    <div>
                        <div className="text-xs uppercase tracking-[0.28em] text-brand-copper flex items-center gap-1.5">
                            <Rocket className="w-3.5 h-3.5" /> Go-Live Wizard
                        </div>
                        <h2 className="font-display text-2xl text-brand-ink dark:text-white mt-1">
                            {data?.live_ready ? "You're live" : "Get Zanelvo ready to go live"}
                        </h2>
                        <p className="text-sm text-zinc-500 mt-1">
                            {data?.live_ready
                                ? "Every essential provider is connected. Customers are fully served."
                                : data?.app_ready
                                    ? "The app is running. Connect the essentials below to switch from sandbox to live."
                                    : "Finish the foundation steps so the app can run."}
                            {data?.environment ? ` · Environment: ${data.environment}` : ""}
                        </p>
                    </div>
                    <button onClick={load} disabled={busy} data-testid="golive-recheck"
                        className="inline-flex items-center gap-1.5 text-sm rounded-md border border-brand-line dark:border-white/15 px-3 py-1.5">
                        <RefreshCw className={`w-4 h-4 ${busy ? "animate-spin" : ""}`} /> Re-check
                    </button>
                </div>

                {s && (
                    <div className="mt-4">
                        <div className="flex items-center justify-between text-xs text-zinc-500 mb-1">
                            <span>{s.required_connected} of {s.required_total} essentials connected</span>
                            <span>{pct}%</span>
                        </div>
                        <div className="h-2.5 rounded-full bg-zinc-200 dark:bg-white/10 overflow-hidden">
                            <div className={`h-full rounded-full transition-all ${data.live_ready ? "bg-emerald-500" : "bg-brand-copper"}`} style={{ width: `${pct}%` }} />
                        </div>
                        {data.live_ready && (
                            <div className="mt-3 inline-flex items-center gap-1.5 text-sm text-emerald-700 dark:text-emerald-300">
                                <PartyPopper className="w-4 h-4" /> All required providers connected.
                            </div>
                        )}
                    </div>
                )}
            </div>

            <div className="mt-4 space-y-3">
                {data?.steps?.map((step, i) => {
                    const st = STYLE[step.status] || STYLE.not_connected; const Icon = st.icon;
                    const done = step.status === "connected";
                    const isOpen = openKey === step.key;
                    return (
                        <div key={step.key} className="rounded-xl border border-brand-line dark:border-white/10 bg-white dark:bg-white/5 p-4" data-testid={`golive-step-${step.key}`}>
                            <div className="flex items-start justify-between gap-3 flex-wrap">
                                <div className="flex items-start gap-3 min-w-0">
                                    <div className={`shrink-0 w-7 h-7 rounded-full grid place-items-center text-xs font-semibold ${done ? "bg-emerald-500 text-white" : "bg-zinc-200 dark:bg-white/10 text-zinc-600 dark:text-white/70"}`}>
                                        {done ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
                                    </div>
                                    <div className="min-w-0">
                                        <div className="flex items-center gap-2 flex-wrap">
                                            <span className="font-medium text-brand-ink dark:text-white">{step.title}</span>
                                            {step.required ? <span className="text-[10px] px-1.5 py-0.5 rounded bg-brand-copper/10 text-brand-copper">Essential</span>
                                                : <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-white/10 text-zinc-500">Optional</span>}
                                        </div>
                                        {step.detail && <div className="text-xs text-zinc-500 mt-0.5 break-words">{step.detail}</div>}
                                        {step.owner_action && !done && <div className="text-[11px] mt-1.5 text-amber-700 dark:text-amber-300">Next: {step.owner_action}</div>}
                                    </div>
                                </div>
                                <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full whitespace-nowrap ${st.cls}`}><Icon className="w-3 h-3" />{st.label}</span>
                            </div>

                            {!done && (
                                <div className="mt-3 pl-10">
                                    {step.configurable ? (
                                        <>
                                            <button onClick={() => setOpenKey(isOpen ? null : step.key)} data-testid={`golive-configure-${step.key}`}
                                                className="inline-flex items-center gap-1.5 text-sm rounded-md bg-brand-copper text-white px-3 py-1.5">
                                                <HardDrive className="w-4 h-4" /> Configure {step.title.toLowerCase()}
                                                <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                                            </button>
                                            {isOpen && <StorageConfig onSaved={load} />}
                                        </>
                                    ) : (
                                        <NavLink to={step.link} data-testid={`golive-fix-${step.key}`}
                                            className="inline-flex items-center gap-1.5 text-sm rounded-md border border-brand-line dark:border-white/15 px-3 py-1.5 hover:bg-brand-cream dark:hover:bg-white/10">
                                            Set up now <ArrowRight className="w-4 h-4" />
                                        </NavLink>
                                    )}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
