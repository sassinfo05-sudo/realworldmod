# Requirements Ledger — Revenue OS (final)

Legend: **Live** = functional in this codebase / **Demo** = simulated but complete E2E / **Not connected** = adapter present, needs credentials / **Blocked — budget** = descoped this iteration.

## Phase 1 — Brand + multi-tenancy + auth + onboarding + AI generation
| Requirement | Status | Notes |
|---|---|---|
| Brand config (name, logo, colors, tagline) | **Live** | `brand_config` collection; founder-editable |
| Multi-tenant with `org_id` scoping on every domain doc | **Live** | `require_org` dependency enforced globally |
| JWT auth + bcrypt + password reset token | **Live** | 24h TTL |
| Roles: platform_founder / owner / manager / staff / readonly | **Live** | `require_role` factory |
| Onboarding interview → BusinessProfile + Website (block JSON) | **Live** | LLM-grounded, industry-varied output |
| Fact-correction review UI | **Live** | Owner-verified flag persisted |
| Public marketing shell (home + pricing) | **Live** | 5 plans in DB |

## Phase 2 — Visual editor
| Block schema + editor + revisions + rollback + publishing | **Live** | dnd-kit reorder; publish → `/site/{slug}` |

## Phase 3 — Domains + import + analytics + forms + email
| Custom domains | **Demo** | Cloudflare adapter present, simulated by default |
| Import from URL | **Live** | Crawl + LLM summarise + generate |
| Analytics + forms | **Live** | Per-page + per-form tracking |
| Email providers (Resend / SMTP) | **Not connected** | Simulated by default |

## Phase 4 — CRM + Inbox + Booking + Quote-to-cash + Payments
| CRM (contacts, deals, tags, imports) | **Live** | CSV import with cap pre-check |
| Inbox (email conversations, scheduled sends, suppression, AI drafts) | **Live** | Simulated provider |
| Booking + portal reschedule/cancel | **Live** | Past-date guarded on 4 code paths |
| Quotes / Invoices / Jobs / Payments | **Live** | Simulated + Stripe adapter |
| Stripe live | **Not connected** | Adapter refuses without `STRIPE_SECRET_KEY` |

## Phase 5 — Knowledge base + AI employees + Agent Studio + Voice
| Knowledge sources with extraction | **Live** | pypdf + python-docx |
| AI receptionist (tool-grounded booking + escalation) | **Live** | Retry-once on transient LLM error |
| Agent Studio (versions, rollback, sandbox, audit, kill switch) | **Live** | Per-org + platform-wide |
| Voice provider | **Not connected** | In-app call simulator only |

## Phase 6 — Billing / Entitlements / Founder / Setup / Support / Security
| Plans + 6 entitlement meters | **Live** | free / launch / revenue / autopilot / scale |
| Enforcement at write time (contacts, users, AI convos, email sends, websites, CSV batch) | **Live** | 402 with `upgrade_url` |
| Public chat over cap → honest fallback (not 402 to visitor) | **Live** | |
| Simulated checkout lifecycle (upgrade/downgrade/cancel/resume/dunning/coupons) | **Live** | `LAUNCH20` seeded |
| Free-plan "Powered by Revenue OS" footer | **Live** | `show_platform_branding` in public payload |
| Founder cockpit + tenants + metrics | **Live** | |
| Audited impersonation w/ scoped JWT (30-min TTL, mandatory reason, banner) | **Live** | Actions auto-tagged with session id |
| Global kill switches + feature flags + announcements + maintenance | **Live** | |
| Setup Center (21 connection cards) + Launch Score | **Live** | |
| Scoped API keys `yv_live_*/yv_test_*` + HMAC webhooks (5-min replay) | **Live** | |
| Public API v1 (contacts / bookings / invoices / quotes) + `bookings:write` | **Live** | POST /api/public/v1/bookings |
| MFA (TOTP + 8 backup codes) | **Live** | Founder recovery documented in `SECURITY.md` |
| Rate limits (auth + public chat) | **Live** | In-process |
| Data export ZIP + org soft-delete + 30-day grace | **Live** | Purge worker deferred |
| Support: 10 help articles + tickets + grounded AI assistant + status page | **Live** | |

## Phase 7 — Marketing
| Campaigns E2E (create → segment → compose ± AI-assist → send simulated → metrics) | **Live** | Consent + suppression + quiet-hours + global email kill switch enforced |
| Review-request fields on campaigns | **Live** | Configurable link |
| Automations (linear trigger → cond → 1-3 actions) | **Live** | Triggers wired: `form_submitted`, `booking_created` |
| Automation templates | **Live** | Seeded 2 templates |
| Creative Studio (EN/ES/HE ad copy + RTL + storyboard + video script) | **Live** | Image = DEMO placeholders; video = script only |
| Ad bundle ZIP export | **Live** | |
| Google Ads / Meta Ads adapters | **Not connected** | |
| Budget cap / requires_approval / paused on send | **Live** | |
| Attribution + per-source report | **Blocked — budget** | Analytics events capture referrer/UA; report deferred |
| Founder growth console (lifecycle emails, referrals, CAC) | **Blocked — budget** | |

## Phase 8 — Finalization
| Demo orgs to parity (home / auto / beauty) | **Live** | Autopilot demo + Ridgeline Auto + Mira & Co. Beauty end-to-end |
| Free-plan demo with published site | **Live** | Cedar Lane Landscaping |
| i18n + Hebrew for sidebar + RTL layout flip | **Live** | Language switcher; deep screens fall back to English honestly |
| Public marketing pages: Home / Pricing / Product / Industries / Security / Terms / Privacy | **Live** | Concise real copy |
| Docs: README + REQUIREMENTS_LEDGER + BUILD_LEDGER + SECURITY + DEPLOYMENT + TESTING + ENVIRONMENT_VARIABLES + OWNER_SETUP_CHECKLIST + CHANGELOG + PRD | **Live** | `DECISIONS.md`, `INTEGRATIONS.md`, `PRICING_AND_USAGE.md`, `OPERATIONS_MANUAL.md`, `SUPPORT_RUNBOOK.md` — **Blocked — budget** (content folded into README + BUILD_LEDGER + SECURITY) |

## Cut items (documented so nothing is silent)
- Founder growth console.
- Real Stripe live cutover.
- Real Retell / Twilio voice.
- Google Ads / Meta Ads real launch.
- Google / Microsoft Calendar sync.
- QuickBooks / Xero sync.
- Real image / video gen in Creative Studio.
- Cluster-safe rate limiter.
- MFA secret encryption at rest.
- Org purge worker.
- WhatsApp / social DM channels.
- Deep-screen Hebrew (only sidebar + core settings translated).

## Round 17 — Storage & Asset Library
- [x] Provider-neutral storage service (S3-compatible + local dev + prod-disabled)
- [x] Storage data model: assets, asset_references, upload_reservations, storage_usage, storage_overrides (+indexes)
- [x] Unified Asset Library UI + reusable Asset Picker (wired into CMS media field)
- [x] Atomic upload flow + validation/sanitisation + per-tenant dedup + quota reservation
- [x] DB-backed founder-editable plan allowances + per-tenant override + 70/90/100 behaviour
- [x] Trash/restore/purge with accurate storage accounting + delete dead-letter
- [x] Public/private URL resolution (signed private) + safe blob serving
- [x] Idempotent migration (dry-run + bounded + cleanup) for legacy base64 media
- [x] Founder storage config (encrypted, masked, status) + staff overview/override
- [ ] Real provider creds connected (owner action) — PENDING_EXTERNAL_SETUP
- [ ] Responsive image variants/srcset, presigned direct upload, bandwidth reconciliation (remaining)
