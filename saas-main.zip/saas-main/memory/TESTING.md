# Testing

## Backend suites
```bash
cd /app/backend
pytest tests/test_phase5.py -v
pytest tests/test_phase6.py -v
pytest tests/test_phase6_followups.py -v
```

## Test reports (JSON)
- `/app/test_reports/iteration_5.json` — Phase 5 initial (15/15)
- `/app/test_reports/iteration_6.json` — Phase 5 hardening
- `/app/test_reports/iteration_7.json` — Phase 5 E2E
- `/app/test_reports/iteration_8.json` — Phase 6 acceptance (30/30 after 1 auto-fix)
- `/app/test_reports/pytest/phase6_followups.xml` — Phase 6 follow-ups (10 passed / 1 auto-fix / 1 blocked → fixed post-run)

## What's covered
| Area | Backend | Frontend |
|---|---|---|
| Auth (login/signup/reset/rate-limit) | ✓ | manual screenshot |
| Multi-tenant isolation | ✓ | — |
| Onboarding + LLM generation | ✓ | — |
| Website editor + publish | ✓ | — |
| CRM + import batch cap | ✓ | — |
| Inbox + scheduled sends | ✓ | — |
| Booking (all past-date paths + portal reschedule) | ✓ | — |
| Quote-to-cash + Stripe adapter (simulated) | ✓ | — |
| AI receptionist (sandbox + tool grounding) | ✓ | — |
| Kill switches (per-org + global) | ✓ | — |
| Billing lifecycle (upgrade/coupon/downgrade/cancel/dunning) | ✓ | — |
| Entitlement caps (contacts/users/AI convos/email/websites/CSV pre-check) | ✓ | — |
| Impersonation scoped token + audit tagging + expiry | ✓ | — |
| Setup Center + Launch Score + API keys + webhooks HMAC | ✓ | — |
| MFA enroll / verify shape / disable | ✓ | manual |
| Support (help, tickets, grounded AI ask, status, announcement) | ✓ | — |
| Public API v1 (scope enforcement + POST /bookings) | ✓ | — |

## Not covered (documented so nothing is silent)
- Automated frontend e2e — validated via curl + hand-run screenshots only in this iteration.
- Real Stripe/Resend/Retell/Twilio/Google/Meta — never hit external APIs from tests.
- Load / soak testing.
- Purge worker (not yet implemented).

## Quick curl smoke test
```bash
API=$(grep REACT_APP_BACKEND_URL /app/frontend/.env | cut -d '=' -f2)
curl -s $API/api/health && echo
curl -s $API/api/openapi.json | python3 -c "import sys,json;print(len(json.load(sys.stdin).get('paths',{})),'routes')"
curl -s $API/api/support/status | python3 -c "import sys,json;print(json.load(sys.stdin)['overall'])"
```

## Quiet-hours bypass for marketing campaigns

The `_hours_ok_now()` guard in `/app/backend/app/routes/marketing.py` normally
blocks `POST /api/marketing/campaigns/{cid}/send` outside 06:00–23:00 UTC.

Two bypass paths exist for integration tests. Only these two.

1. **Global env flag (pod-wide).** Set `REVENUE_OS_SKIP_QUIET_HOURS=1` in
   `backend/.env`. Applies to every send call. Use only in ephemeral test
   environments — never in a shared preview pod.

2. **Founder-only per-request header.** Send `X-Test-Override: <founder JWT>`
   on the send request. The server calls `decode_access_token(...)` on the
   header value and honours the bypass **only when `claims["role"] ==
   "platform_founder"`**. Owner/manager/staff/readonly JWTs are silently
   ignored — those callers still see the normal quiet-hours 400.

Example (during a UTC quiet hour, using founder JWT):
```
FT=$(curl -s -X POST "$API/api/auth/login" -H 'content-type: application/json' \
   -d '{"email":"founder@revenueos.com","password":"<pw>"}' \
   | python3 -c 'import json,sys; print(json.load(sys.stdin)["access_token"])')
OT=$(login as owner …)
curl -s -X POST "$API/api/marketing/campaigns/$CID/send" \
   -H "Authorization: Bearer $OT" -H "X-Test-Override: $FT"
```

Failure modes to assert in test suites:
- Same header with an owner token → 400 quiet-hours error.
- No header, UTC quiet hour → 400 quiet-hours error.
- Founder header + regular hour → still requires valid campaign + segment.
