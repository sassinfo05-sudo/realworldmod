"""Payment provider adapters — SimulatedProvider (active) + StripeProvider (honest not-connected).

Amounts are integer cents. All operations are idempotent on `session_id` / `event_id`.
"""
from __future__ import annotations

import logging
import os
import secrets
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol

import httpx

logger = logging.getLogger(__name__)


@dataclass
class CheckoutRequest:
    invoice_id: str
    amount_cents: int
    currency: str
    customer_email: Optional[str]
    success_url: str
    cancel_url: str
    metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class CheckoutResult:
    ok: bool
    checkout_url: Optional[str] = None
    session_id: Optional[str] = None
    error: Optional[str] = None
    hint: Optional[str] = None
    simulated: bool = False


@dataclass
class StatusResult:
    session_id: str
    status: str  # 'pending' | 'paid' | 'failed' | 'expired' | 'refunded'
    payment_intent_id: Optional[str] = None
    simulated: bool = False


class PaymentProvider(Protocol):
    key: str

    @property
    def is_connected(self) -> bool: ...

    @property
    def honest_status(self) -> str: ...

    async def create_checkout(self, req: CheckoutRequest) -> CheckoutResult: ...

    async def get_status(self, session_id: str) -> StatusResult: ...

    async def refund(self, session_id: str, amount_cents: int) -> Dict[str, Any]: ...


# ---------------- Simulated ----------------

_SIM_SESSIONS: Dict[str, Dict[str, Any]] = {}
_SIM_EVENTS: List[Dict[str, Any]] = []


def simulated_pay(session_id: str) -> bool:
    """Test-only helper — flip a simulated session to `paid` and enqueue a webhook-style event."""
    ses = _SIM_SESSIONS.get(session_id)
    if not ses or ses["status"] == "paid":
        return False
    ses["status"] = "paid"
    ses["paid_at"] = "now"
    _SIM_EVENTS.append({"id": f"evt_{uuid.uuid4().hex[:12]}",
                          "type": "checkout.session.completed",
                          "session_id": session_id,
                          "invoice_id": ses.get("invoice_id"),
                          "amount_cents": ses.get("amount_cents")})
    return True


def drain_simulated_events() -> List[Dict[str, Any]]:
    out = list(_SIM_EVENTS)
    _SIM_EVENTS.clear()
    return out


class SimulatedProvider:
    key = "simulated"

    @property
    def is_connected(self) -> bool:
        return True

    @property
    def honest_status(self) -> str:
        return "Simulated — test payment page in-app. No real charges."

    async def create_checkout(self, req: CheckoutRequest) -> CheckoutResult:
        session_id = f"sim_cs_{secrets.token_urlsafe(12)}"
        _SIM_SESSIONS[session_id] = {
            "session_id": session_id,
            "invoice_id": req.invoice_id,
            "amount_cents": req.amount_cents,
            "currency": req.currency,
            "status": "pending",
            "customer_email": req.customer_email,
            "metadata": dict(req.metadata),
        }
        # In the simulated flow we point the customer to an in-app "test checkout"
        # page (frontend route /pay/simulated/{session_id}) that lets them "Pay now"
        # or "Cancel" — the button posts to /api/payments/simulated/{id}/pay
        checkout_url = f"/pay/simulated/{session_id}?return_to={req.success_url}"
        return CheckoutResult(ok=True, checkout_url=checkout_url, session_id=session_id, simulated=True)

    async def get_status(self, session_id: str) -> StatusResult:
        ses = _SIM_SESSIONS.get(session_id)
        if not ses:
            return StatusResult(session_id=session_id, status="failed", simulated=True)
        return StatusResult(session_id=session_id, status=ses["status"],
                              payment_intent_id=None, simulated=True)

    async def refund(self, session_id: str, amount_cents: int) -> Dict[str, Any]:
        ses = _SIM_SESSIONS.get(session_id)
        if not ses or ses["status"] != "paid":
            return {"ok": False, "error": "session not paid"}
        ses["status"] = "refunded"
        ses["refunded_amount_cents"] = amount_cents
        _SIM_EVENTS.append({"id": f"evt_{uuid.uuid4().hex[:12]}",
                              "type": "charge.refunded",
                              "session_id": session_id,
                              "amount_cents": amount_cents})
        return {"ok": True, "refund_id": f"sim_ref_{secrets.token_urlsafe(8)}", "simulated": True}


# ---------------- Stripe (honest not-connected when creds absent) ----------------

# We use httpx directly (no SDK) so unit tests can mock cleanly.
# STRIPE_SECRET_KEY absent or set to the shared placeholder ⇒ "Not connected".
_STRIPE_PLACEHOLDER = {"", "sk_test_emergent", None}


class StripeProvider:
    key = "stripe"
    API_BASE = "https://api.stripe.com/v1"

    def __init__(self, api_key: Optional[str] = None, webhook_secret: Optional[str] = None,
                 stripe_account: Optional[str] = None):
        self.api_key = api_key or os.environ.get("STRIPE_SECRET_KEY") or ""
        self.webhook_secret = webhook_secret or os.environ.get("STRIPE_WEBHOOK_SECRET") or ""
        # Stripe Connect: when set, every call is made ON BEHALF of the tenant's connected account
        # (direct charges) using the PLATFORM key — the tenant never holds a secret key.
        self.stripe_account = stripe_account or ""

    def _headers(self) -> Dict[str, str]:
        return {"Stripe-Account": self.stripe_account} if self.stripe_account else {}

    @property
    def is_connected(self) -> bool:
        # Treat the emergent shared test placeholder as NOT connected so we don't
        # accidentally send test transactions to a shared account. The user must
        # explicitly set their own STRIPE_SECRET_KEY to activate Stripe.
        return self.api_key not in _STRIPE_PLACEHOLDER

    @property
    def honest_status(self) -> str:
        if self.is_connected:
            return "Connected — real Stripe checkout for real charges."
        return ("Not connected — set STRIPE_SECRET_KEY (and STRIPE_WEBHOOK_SECRET) on "
                 "the org's payment provider config to activate. Use the Simulated "
                 "provider in the meantime for tests.")

    async def create_checkout(self, req: CheckoutRequest) -> CheckoutResult:
        if not self.is_connected:
            return CheckoutResult(ok=False, error="Stripe not connected",
                                    hint="Set STRIPE_SECRET_KEY to activate.")
        payload = {
            "mode": "payment",
            "success_url": req.success_url + "?session_id={CHECKOUT_SESSION_ID}",
            "cancel_url": req.cancel_url,
            "line_items[0][price_data][currency]": (req.currency or "usd").lower(),
            "line_items[0][price_data][product_data][name]": f"Invoice {req.invoice_id}",
            "line_items[0][price_data][unit_amount]": str(int(req.amount_cents)),
            "line_items[0][quantity]": "1",
            "metadata[invoice_id]": req.invoice_id,
        }
        for k, v in (req.metadata or {}).items():
            payload[f"metadata[{k}]"] = v
        if req.customer_email:
            payload["customer_email"] = req.customer_email

        async with httpx.AsyncClient(base_url=self.API_BASE, timeout=30, headers=self._headers()) as c:
            r = await c.post("/checkout/sessions", data=payload,
                              auth=(self.api_key, ""),
                              headers={"Idempotency-Key": f"zv-co-{req.invoice_id}"} if req.invoice_id else None)
            if r.status_code >= 400:
                return CheckoutResult(ok=False, error=f"HTTP {r.status_code}: {r.text[:300]}")
            data = r.json()
            return CheckoutResult(ok=True, checkout_url=data.get("url"), session_id=data.get("id"))

    async def get_status(self, session_id: str) -> StatusResult:
        if not self.is_connected:
            return StatusResult(session_id=session_id, status="failed")
        async with httpx.AsyncClient(base_url=self.API_BASE, timeout=30, headers=self._headers()) as c:
            r = await c.get(f"/checkout/sessions/{session_id}", auth=(self.api_key, ""))
            if r.status_code >= 400:
                return StatusResult(session_id=session_id, status="failed")
            data = r.json()
            pay_status = "paid" if data.get("payment_status") == "paid" else "pending"
            return StatusResult(session_id=session_id, status=pay_status,
                                  payment_intent_id=data.get("payment_intent"))

    async def refund(self, session_id: str, amount_cents: int) -> Dict[str, Any]:
        if not self.is_connected:
            return {"ok": False, "error": "Stripe not connected"}
        # first, retrieve the session to get the payment_intent
        async with httpx.AsyncClient(base_url=self.API_BASE, timeout=30, headers=self._headers()) as c:
            r = await c.get(f"/checkout/sessions/{session_id}", auth=(self.api_key, ""))
            if r.status_code >= 400:
                return {"ok": False, "error": f"session lookup failed: {r.text[:200]}"}
            pi = r.json().get("payment_intent")
            if not pi:
                return {"ok": False, "error": "no payment_intent on session"}
            r = await c.post("/refunds", data={"payment_intent": pi, "amount": int(amount_cents)},
                              auth=(self.api_key, ""))
            if r.status_code >= 400:
                return {"ok": False, "error": f"refund failed: {r.text[:200]}"}
            return {"ok": True, "refund_id": r.json().get("id")}

    def verify_webhook(self, payload: bytes, signature_header: Optional[str]) -> bool:
        """Stripe signature verification. Returns True if the signature matches."""
        if not self.webhook_secret:
            return False
        if not signature_header:
            return False
        try:
            import hashlib, hmac, time
            parts = dict(p.split("=", 1) for p in signature_header.split(",") if "=" in p)
            timestamp = parts.get("t")
            v1 = parts.get("v1")
            if not timestamp or not v1:
                return False
            # Reject old events (default 5 min tolerance)
            if abs(time.time() - int(timestamp)) > 300:
                return False
            signed_payload = f"{timestamp}.{payload.decode('utf-8', errors='ignore')}"
            expected = hmac.new(self.webhook_secret.encode(), signed_payload.encode(),
                                  hashlib.sha256).hexdigest()
            return hmac.compare_digest(expected, v1)
        except Exception:  # noqa: BLE001
            return False


class PayPalWebhookVerifier:
    """Round 11 — PayPal webhook signature verification via PayPal's own
    `POST /v1/notifications/verify-webhook-signature` API (the documented method; PayPal does not use a
    shared HMAC secret). Needs client_id/secret + the webhook_id registered in the PayPal dashboard.

    The PayPal LIVE checkout rail is STILL refused in routes/billing.py until credentials are entered in the
    Staff Setup Center — this class only makes the webhook side ready. `verify()` returns False on any doubt.
    """
    LIVE = "https://api-m.paypal.com"
    SANDBOX = "https://api-m.sandbox.paypal.com"
    REQUIRED_HEADERS = ("paypal-transmission-id", "paypal-transmission-time", "paypal-cert-url",
                        "paypal-auth-algo", "paypal-transmission-sig")

    def __init__(self, client_id: Optional[str], client_secret: Optional[str], webhook_id: Optional[str], sandbox: bool = True):
        self.client_id, self.client_secret, self.webhook_id = client_id, client_secret, webhook_id
        self.base = self.SANDBOX if sandbox else self.LIVE

    @property
    def is_configured(self) -> bool:
        return bool(self.client_id and self.client_secret and self.webhook_id)

    async def _token(self) -> Optional[str]:
        async with httpx.AsyncClient(base_url=self.base, timeout=20) as c:
            r = await c.post("/v1/oauth2/token", data={"grant_type": "client_credentials"},
                             auth=(self.client_id or "", self.client_secret or ""))
            if r.status_code >= 400:
                return None
            return r.json().get("access_token")

    async def verify(self, headers: Dict[str, str], body: bytes) -> bool:
        if not self.is_configured:
            return False
        h = {k.lower(): v for k, v in headers.items()}
        if any(k not in h for k in self.REQUIRED_HEADERS):
            return False
        try:
            import json as _json
            token = await self._token()
            if not token:
                return False
            payload = {"auth_algo": h["paypal-auth-algo"], "cert_url": h["paypal-cert-url"],
                       "transmission_id": h["paypal-transmission-id"], "transmission_sig": h["paypal-transmission-sig"],
                       "transmission_time": h["paypal-transmission-time"], "webhook_id": self.webhook_id,
                       "webhook_event": _json.loads(body or b"{}")}
            async with httpx.AsyncClient(base_url=self.base, timeout=20) as c:
                r = await c.post("/v1/notifications/verify-webhook-signature", json=payload,
                                 headers={"Authorization": f"Bearer {token}"})
            return r.status_code < 300 and (r.json() or {}).get("verification_status") == "SUCCESS"
        except Exception:  # noqa: BLE001
            return False


def build_payment_provider(cfg_provider_key: str = "simulated", **overrides) -> PaymentProvider:
    if cfg_provider_key == "stripe":
        return StripeProvider(api_key=overrides.get("stripe_api_key"),
                                webhook_secret=overrides.get("stripe_webhook_secret"),
                                stripe_account=overrides.get("stripe_account"))
    return SimulatedProvider()


def list_payment_providers() -> List[Dict[str, Any]]:
    return [
        {"key": "simulated", "label": "Simulated (dev)",
         "is_connected": True,
         "honest_status": SimulatedProvider().honest_status,
         "docs": "In-app test checkout. No real charges — safe to use for demos."},
        {"key": "stripe", "label": "Stripe",
         "is_connected": StripeProvider().is_connected,
         "honest_status": StripeProvider().honest_status,
         "docs": "Platform key lives in the Staff Setup Center; tenants onboard via Stripe Connect."},
        {"key": "paypal", "label": "PayPal",
         "is_connected": False,
         "honest_status": "Not connected — webhook verification ready; live checkout refused until client id/secret/webhook id are entered.",
         "docs": "Enter PayPal client id, secret and webhook id in the Staff Setup Center (payments section)."},
    ]
