"""Founder Control Center: exception-first cockpit, tenant directory, metrics,
audited impersonation, global controls (kill switches, feature flags, announcement,
maintenance), provider/queue health, and the approval queue.

Every mutating route audits. Impersonation is the only mechanism by which a founder
can access tenant data; there is NO "pass ?org_id=..." shortcut anywhere.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel

from ..config import EMERGENT_LLM_KEY
from ..db import get_db, utc_now_iso
from ..deps import require_role
from ..models import User
from ..services import audit, impersonation
from ..services.entitlements import measure_usage, entitlements_dict

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/founder", tags=["founder"])

# Guard: every route below requires platform_founder
_founder = require_role("platform_founder")


# ============ LAUNCH GATE (explicit owner/legal review) ============

async def _read_launch_gate(db) -> Dict[str, Any]:
    from ..services.platform_settings import SETTINGS_KEY as _SK
    doc = await db.platform_settings.find_one({"key": _SK}, {"launch_gate": 1})
    gate = (doc or {}).get("launch_gate") or {}
    legal = bool(gate.get("legal_reviewed"))
    return {
        "legal_reviewed": legal,
        "legal_reviewed_at": gate.get("legal_reviewed_at"),
        "legal_reviewed_by": gate.get("legal_reviewed_by"),
        # launch_ready is the AND of every explicit go-live gate (currently: legal review).
        "launch_ready": legal,
    }


@router.get("/launch-gate")
async def get_launch_gate(user: User = Depends(_founder)):
    """Owner/founder launch-readiness gate. Generated Terms/Privacy are NOT legally approved
    until a human confirms legal review here."""
    return await _read_launch_gate(get_db())


class LaunchGateIn(BaseModel):
    legal_reviewed: bool


@router.put("/launch-gate")
async def set_launch_gate(body: LaunchGateIn, user: User = Depends(_founder)):
    db = get_db()
    from ..services.platform_settings import SETTINGS_KEY as _SK
    gate = {
        "legal_reviewed": bool(body.legal_reviewed),
        "legal_reviewed_at": utc_now_iso() if body.legal_reviewed else None,
        "legal_reviewed_by": getattr(user, "email", None) if body.legal_reviewed else None,
    }
    await db.platform_settings.update_one(
        {"key": _SK}, {"$set": {"launch_gate": gate, "updated_at": utc_now_iso()}}, upsert=True)
    try:
        await audit.record(action="launch_gate.set", actor_user_id=user.id,
                           actor_role="platform_founder", actor_email=getattr(user, "email", None),
                           meta=gate)
    except Exception:  # noqa: BLE001
        pass
    return {**gate, "launch_ready": gate["legal_reviewed"]}


# ============ COCKPIT ============

@router.get("/cockpit")
async def cockpit(user: User = Depends(_founder)):
    """Exception-first summary: things that need action NOW."""
    db = get_db()
    # 1. Orgs over any hard limit (contacts, users, ai_convos, websites — the sticky ones)
    orgs_over_limit: List[Dict[str, Any]] = []
    async for o in db.organizations.find({}):
        oid = str(o["_id"])
        sub = await db.subscriptions.find_one({"org_id": oid})
        plan = (sub or {}).get("plan_code") or "free"
        ent = entitlements_dict(plan)
        usage = await measure_usage(oid)
        over = []
        for k, cap_key in [("contacts", "max_contacts"), ("users", "max_users"),
                                ("websites", "websites"),
                                ("ai_conversations", "ai_conversations_per_month"),
                                ("email_sends", "email_sends_per_month")]:
            cap = ent.get(cap_key)
            if cap and usage.get(k, 0) >= cap:
                over.append({"meter": k, "used": usage.get(k, 0), "cap": cap})
        if over:
            orgs_over_limit.append({"org_id": oid, "org_name": o.get("name"),
                                        "plan": plan, "over": over})

    # 2. Dead-lettered / repeatedly failing webhooks
    failing_webhooks = await db.webhook_deliveries.count_documents({"status": "failed"})
    dead_webhooks = await db.webhook_deliveries.count_documents({"status": "dead"})

    # 3. Pending approvals
    pending_approvals = await db.approval_requests.count_documents({"status": "pending"})

    # 4. Past-due subscriptions (dunning)
    past_due = await db.subscriptions.count_documents({"status": "past_due"})

    # 5. Error spikes: LLM errors in past 24h from audit + agent_interactions.outcome
    since_iso = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat().replace("+00:00", "Z")
    llm_errors_24h = await db.agent_interactions.count_documents({
        "outcome": "llm_error", "created_at": {"$gte": since_iso},
    })

    # 6. Active impersonation sessions (context awareness)
    active_impersonations = await db.impersonation_sessions.count_documents({"active": True})

    return {
        "orgs_over_limit": orgs_over_limit,
        "failing_webhooks": failing_webhooks,
        "dead_webhooks": dead_webhooks,
        "pending_approvals": pending_approvals,
        "past_due_subscriptions": past_due,
        "llm_errors_24h": llm_errors_24h,
        "active_impersonations": active_impersonations,
    }


# ============ TENANT DIRECTORY ============

@router.get("/tenants")
async def list_tenants(q: Optional[str] = None, plan: Optional[str] = None,
                          status: Optional[str] = None,
                          limit: int = Query(200, ge=1, le=500),
                          user: User = Depends(_founder)):
    db = get_db()
    query: Dict[str, Any] = {}
    if q:
        query["$or"] = [
            {"name": {"$regex": q, "$options": "i"}},
            {"slug": {"$regex": q, "$options": "i"}},
        ]
    orgs = []
    async for o in db.organizations.find(query).sort("created_at", -1).limit(limit):
        oid = str(o["_id"])
        sub = await db.subscriptions.find_one({"org_id": oid})
        current_plan = (sub or {}).get("plan_code") or "free"
        if plan and plan != current_plan:
            continue
        sub_status = (sub or {}).get("status", "trialing")
        if status and status != sub_status:
            continue
        # activation
        website = await db.websites.find_one({"org_id": oid})
        has_site = bool(website)
        is_published = bool((website or {}).get("status") == "published")
        ai_enabled = False
        ai_agent = await db.agents.find_one({"org_id": oid, "enabled": True})
        if ai_agent:
            ks = await db.kill_switches.find_one({"org_id": oid})
            ai_enabled = not (ks and not ks.get("ai_enabled", True))
        usage = await measure_usage(oid)
        # cost estimate: sum agent_interactions.cost_cents this month
        month_start = usage["month_start"]
        cost_cents = 0.0
        async for i in db.agent_interactions.find({"org_id": oid, "created_at": {"$gte": month_start}}):
            cost_cents += float(i.get("cost_cents") or 0)
        # MRR contribution
        p = await db.plans.find_one({"code": current_plan})
        mrr = float((p or {}).get("price_usd") or 0)
        # Health score
        ent = entitlements_dict(current_plan)
        health_factors: List[str] = []
        score = 100
        if not has_site:
            score -= 30; health_factors.append("no_website")
        elif not is_published:
            score -= 15; health_factors.append("draft_not_published")
        if usage["ai_conversations"] >= ent["ai_conversations_per_month"] and ent["ai_conversations_per_month"] > 0:
            score -= 10; health_factors.append("ai_over_limit")
        if usage["contacts"] >= ent["max_contacts"]:
            score -= 10; health_factors.append("contacts_over_limit")
        if sub_status == "past_due":
            score -= 25; health_factors.append("past_due")
        if not ai_enabled and current_plan in ("autopilot", "scale"):
            score -= 10; health_factors.append("paid_ai_disabled")
        # Suspended?
        suspended = bool(o.get("suspended"))
        orgs.append({
            "id": oid, "name": o.get("name"), "slug": o.get("slug"),
            "plan": current_plan, "sub_status": sub_status,
            "created_at": o.get("created_at"),
            "suspended": suspended,
            "activation": {"has_site": has_site, "published": is_published,
                             "ai_enabled": ai_enabled},
            "usage": usage,
            "cost_cents_this_month": round(cost_cents, 2),
            "mrr_usd": mrr,
            "gross_margin_estimate_usd": round(mrr - cost_cents / 100.0, 2) if mrr else 0,
            "health_score": max(0, score),
            "health_factors": health_factors,
        })
    return {"tenants": orgs, "count": len(orgs)}


@router.get("/tenants/{org_id}")
async def get_tenant(org_id: str, user: User = Depends(_founder)):
    db = get_db()
    org = await db.organizations.find_one({"_id": ObjectId(org_id)})
    if not org:
        raise HTTPException(404, "Not found")
    sub = await db.subscriptions.find_one({"org_id": org_id})
    if sub and "_id" in sub:
        sub["id"] = str(sub.pop("_id"))
    users = []
    async for u in db.users.find({"org_id": org_id}):
        users.append({"id": str(u["_id"]), "email": u.get("email"),
                        "role": u.get("role"), "full_name": u.get("full_name")})
    website = await db.websites.find_one({"org_id": org_id})
    profile = await db.business_profiles.find_one({"org_id": org_id})
    usage = await measure_usage(org_id)
    org["id"] = str(org.pop("_id"))
    return {"org": org, "subscription": (sub or {}),
             "users": users,
             "website": {"slug": (website or {}).get("slug"),
                          "status": (website or {}).get("status")},
             "business_profile": {"business_name": (profile or {}).get("business_name"),
                                     "industry": (profile or {}).get("industry")},
             "usage": usage}


class SuspendReq(BaseModel):
    suspend: bool
    reason: Optional[str] = None


@router.post("/tenants/{org_id}/suspend")
async def suspend_tenant(org_id: str, req: SuspendReq, request: Request,
                            user: User = Depends(_founder)):
    db = get_db()
    r = await db.organizations.update_one(
        {"_id": ObjectId(org_id)},
        {"$set": {"suspended": bool(req.suspend), "suspension_reason": req.reason,
                    "updated_at": utc_now_iso()}},
    )
    if r.matched_count == 0:
        raise HTTPException(404, "Not found")
    await audit.record(action=("org.suspend" if req.suspend else "org.unsuspend"),
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, org_id=org_id,
                          target_type="org", target_id=org_id,
                          reason=req.reason, request=request)
    return {"ok": True}


# ============ METRICS ============

@router.get("/metrics")
async def metrics(user: User = Depends(_founder)):
    db = get_db()
    orgs_total = await db.organizations.count_documents({})
    subs = [s async for s in db.subscriptions.find({})]
    mrr = 0.0
    per_plan: Dict[str, int] = {}
    for s in subs:
        code = s.get("plan_code") or "free"
        per_plan[code] = per_plan.get(code, 0) + 1
        if s.get("status") in ("active", "past_due") and code != "free":
            p = await db.plans.find_one({"code": code})
            mrr += float((p or {}).get("price_usd") or 0)
    # Activation funnel: signup → interview → website → published → active
    signups = orgs_total
    with_profile = await db.business_profiles.count_documents({})
    with_website = await db.websites.count_documents({})
    published = await db.websites.count_documents({"status": "published"})
    active_last_7 = 0
    since_iso = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat().replace("+00:00", "Z")
    orgs_active = set()
    async for i in db.agent_interactions.find({"created_at": {"$gte": since_iso}}):
        orgs_active.add(i.get("org_id"))
    active_last_7 = len(orgs_active)
    # Churn count (canceled subs in last 30d)
    cutoff_30d = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat().replace("+00:00", "Z")
    churned_30d = await db.subscriptions.count_documents({
        "canceled_at": {"$gte": cutoff_30d},
    })
    # Aggregate per-org gross margin
    per_org = []
    async for o in db.organizations.find({}):
        oid = str(o["_id"])
        sub = await db.subscriptions.find_one({"org_id": oid})
        code = (sub or {}).get("plan_code") or "free"
        p = await db.plans.find_one({"code": code})
        rev = float((p or {}).get("price_usd") or 0)
        # cost this month
        month_start = (datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0)
                       .isoformat().replace("+00:00", "Z"))
        cost_cents = 0.0
        async for i in db.agent_interactions.find({"org_id": oid, "created_at": {"$gte": month_start}}):
            cost_cents += float(i.get("cost_cents") or 0)
        per_org.append({"org_id": oid, "name": o.get("name"), "plan": code,
                          "mrr_usd": rev, "ai_cost_usd": round(cost_cents / 100.0, 2),
                          "gross_margin_usd": round(rev - cost_cents / 100.0, 2)})
    return {"orgs_total": orgs_total, "mrr_usd": round(mrr, 2),
             "arr_usd": round(mrr * 12, 2),
             "per_plan": per_plan,
             "funnel": {"signups": signups, "interview_done": with_profile,
                          "website_created": with_website,
                          "published": published, "active_last_7d": active_last_7},
             "churned_last_30d": churned_30d,
             "per_org": per_org}


# ============ IMPERSONATION ============

class ImpersonateStartReq(BaseModel):
    target_org_id: str
    reason: str


@router.post("/impersonate/start")
async def impersonate_start(req: ImpersonateStartReq, request: Request,
                                user: User = Depends(_founder)):
    from ..security import create_impersonation_token
    sid = await impersonation.start(user, req.target_org_id, req.reason)
    token = create_impersonation_token(user.id, req.target_org_id, sid,
                                            minutes=impersonation.MAX_SESSION_MINUTES)
    await audit.record(action="impersonation.start", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email,
                          org_id=req.target_org_id,
                          target_type="org", target_id=req.target_org_id,
                          reason=req.reason, impersonation_session_id=sid,
                          request=request)
    return {"session_id": sid, "impersonation_token": token,
             "expires_in_minutes": impersonation.MAX_SESSION_MINUTES}


@router.get("/impersonate/current")
async def impersonate_current(user: User = Depends(_founder)):
    sess = await impersonation.current_session(user)
    if not sess:
        return {"active": False}
    sess["id"] = str(sess.pop("_id"))
    return {"active": True, "session": sess}


@router.post("/impersonate/end")
async def impersonate_end(request: Request, user: User = Depends(_founder)):
    sess = await impersonation.current_session(user)
    if not sess:
        return {"ok": True, "already": True}
    sid = str(sess["_id"])
    await impersonation.end(user, exit_reason="manual")
    await audit.record(action="impersonation.end", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email,
                          org_id=sess["target_org_id"],
                          impersonation_session_id=sid, request=request)
    return {"ok": True}


# ============ AUDIT LOG ============

@router.get("/audit")
async def audit_list(q: Optional[str] = None, action: Optional[str] = None,
                       org_id: Optional[str] = None,
                       limit: int = Query(200, ge=1, le=500),
                       user: User = Depends(_founder)):
    db = get_db()
    query: Dict[str, Any] = {}
    if action:
        query["action"] = {"$regex": f"^{action}"}
    if org_id:
        query["org_id"] = org_id
    if q:
        query["$or"] = [
            {"actor_email": {"$regex": q, "$options": "i"}},
            {"reason": {"$regex": q, "$options": "i"}},
        ]
    out = []
    async for e in db.audit_events.find(query).sort("created_at", -1).limit(limit):
        out.append({"id": str(e["_id"]), "action": e.get("action"),
                     "actor_email": e.get("actor_email"),
                     "actor_role": e.get("actor_role"),
                     "org_id": e.get("org_id"),
                     "target_type": e.get("target_type"),
                     "target_id": e.get("target_id"),
                     "reason": e.get("reason"),
                     "meta": e.get("meta") or {},
                     "ip": e.get("ip"),
                     "impersonation_session_id": e.get("impersonation_session_id"),
                     "created_at": e.get("created_at")})
    return {"events": out}


# ============ GLOBAL CONTROLS ============

@router.get("/global-controls")
async def get_global_controls(user: User = Depends(_founder)):
    db = get_db()
    ks = await db.global_kill_switches.find_one({"key": "global"}) or {}
    ann = await db.announcements.find_one({"active": True}, sort=[("created_at", -1)])
    mt = await db.maintenance_modes.find_one({"key": "primary"}) or {}
    flags = []
    async for f in db.feature_flags.find({}).sort("key", 1):
        flags.append({"id": str(f["_id"]), "key": f.get("key"),
                        "label": f.get("label"), "description": f.get("description"),
                        "enabled_globally": bool(f.get("enabled_globally", True)),
                        "per_plan_overrides": f.get("per_plan_overrides") or {},
                        "per_org_overrides": f.get("per_org_overrides") or {}})
    return {
        "global_kill": {
            "all_ai_disabled": bool(ks.get("all_ai_disabled")),
            "all_email_disabled": bool(ks.get("all_email_disabled")),
            "all_public_chat_disabled": bool(ks.get("all_public_chat_disabled")),
            "reason": ks.get("reason"),
        },
        "announcement": {"title": (ann or {}).get("title"),
                          "body": (ann or {}).get("body"),
                          "level": (ann or {}).get("level"),
                          "id": str(ann["_id"]) if ann else None,
                          "active": bool(ann)},
        "maintenance": {"enabled": bool(mt.get("enabled")), "message": mt.get("message"),
                          "updated_at": mt.get("updated_at")},
        "feature_flags": flags,
    }


class KillSwitchReq(BaseModel):
    all_ai_disabled: Optional[bool] = None
    all_email_disabled: Optional[bool] = None
    all_public_chat_disabled: Optional[bool] = None
    reason: Optional[str] = None


@router.put("/global-controls/kill")
async def set_kill(req: KillSwitchReq, request: Request,
                      user: User = Depends(_founder)):
    db = get_db()
    upd: Dict[str, Any] = {"updated_at": utc_now_iso(), "updated_by_user_id": user.id,
                             "key": "global"}
    for f in ("all_ai_disabled", "all_email_disabled", "all_public_chat_disabled", "reason"):
        v = getattr(req, f)
        if v is not None:
            upd[f] = v
    await db.global_kill_switches.update_one({"key": "global"},
                                                 {"$set": upd,
                                                    "$setOnInsert": {"created_at": utc_now_iso()}},
                                                 upsert=True)
    await audit.record(action="global.kill_switch",
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, meta=upd, request=request)
    return {"ok": True}


class AnnouncementReq(BaseModel):
    title: str
    body: str
    level: str = "info"


@router.post("/global-controls/announcement")
async def set_announcement(req: AnnouncementReq, request: Request,
                              user: User = Depends(_founder)):
    db = get_db()
    # Deactivate previous
    await db.announcements.update_many({"active": True}, {"$set": {"active": False}})
    doc = {"title": req.title, "body": req.body, "level": req.level,
             "active": True, "dismissible": True,
             "created_by_user_id": user.id,
             "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.announcements.insert_one(doc)
    await audit.record(action="global.announcement",
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, meta={"id": str(r.inserted_id),
                                                          "title": req.title}, request=request)
    return {"id": str(r.inserted_id)}


@router.delete("/global-controls/announcement")
async def clear_announcement(request: Request, user: User = Depends(_founder)):
    db = get_db()
    r = await db.announcements.update_many({"active": True}, {"$set": {"active": False}})
    await audit.record(action="global.announcement_clear",
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, request=request)
    return {"ok": True, "cleared": r.modified_count}


class MaintenanceReq(BaseModel):
    enabled: bool
    message: Optional[str] = None


@router.put("/global-controls/maintenance")
async def set_maintenance(req: MaintenanceReq, request: Request,
                             user: User = Depends(_founder)):
    db = get_db()
    upd = {"enabled": req.enabled, "message": req.message or "Zanelvo is undergoing maintenance.",
             "updated_by_user_id": user.id, "updated_at": utc_now_iso()}
    await db.maintenance_modes.update_one({"key": "primary"},
                                              {"$set": {**upd, "key": "primary"},
                                               "$setOnInsert": {"created_at": utc_now_iso()}},
                                              upsert=True)
    await audit.record(action="global.maintenance",
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, meta=upd, request=request)
    return {"ok": True}


class FeatureFlagReq(BaseModel):
    key: str
    label: Optional[str] = None
    description: Optional[str] = None
    enabled_globally: Optional[bool] = None
    per_plan_overrides: Optional[Dict[str, bool]] = None
    per_org_overrides: Optional[Dict[str, bool]] = None


@router.put("/global-controls/feature-flag")
async def set_feature_flag(req: FeatureFlagReq, request: Request,
                              user: User = Depends(_founder)):
    db = get_db()
    upd: Dict[str, Any] = {"updated_at": utc_now_iso()}
    for f in ("label", "description", "enabled_globally", "per_plan_overrides",
                 "per_org_overrides"):
        v = getattr(req, f)
        if v is not None:
            upd[f] = v
    await db.feature_flags.update_one({"key": req.key},
                                          {"$set": {**upd, "key": req.key},
                                           "$setOnInsert": {"created_at": utc_now_iso(),
                                                            "label": req.label or req.key,
                                                            "enabled_globally": True}},
                                          upsert=True)
    await audit.record(action="global.feature_flag",
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, meta={"key": req.key, **upd},
                          request=request)
    return {"ok": True}


# ============ PROVIDER / QUEUE HEALTH ============

@router.get("/error-events")
async def error_events(limit: int = 100, user: User = Depends(_founder)):
    """Recent unhandled API errors (captured redacted by server.py::_unhandled). Founder ops view."""
    db = get_db()
    limit = max(1, min(int(limit), 500))
    rows = await db.error_events.find({}, {"_id": 0}).sort("created_at", -1).to_list(limit)
    total = await db.error_events.count_documents({})
    return {"items": rows, "total": total}



@router.get("/health")
async def health(user: User = Depends(_founder)):
    db = get_db()
    # LLM: check that key is set
    llm_ok = bool(EMERGENT_LLM_KEY)
    # Email: how many providers connected
    email_configs = await db.email_provider_configs.count_documents({})
    payment_configs = await db.payment_provider_configs.count_documents({"active": True})
    # Webhook queue
    pending = await db.webhook_deliveries.count_documents({"status": "pending"})
    failed = await db.webhook_deliveries.count_documents({"status": "failed"})
    dead = await db.webhook_deliveries.count_documents({"status": "dead"})
    # Scheduled sends
    scheduled_pending = await db.scheduled_sends.count_documents({"status": "scheduled"})
    scheduled_failed = await db.scheduled_sends.count_documents({"status": "failed"})
    return {"llm": {"key_set": llm_ok,
                       "status": "ok" if llm_ok else "not_configured"},
             "email": {"provider_configs": email_configs,
                          "status": "configured" if email_configs else "no_provider"},
             "payments": {"active_providers": payment_configs,
                           "stripe_key_env": bool(os.environ.get("STRIPE_SECRET_KEY"))},
             "webhooks": {"pending": pending, "failed": failed, "dead": dead},
             "scheduled_sends": {"pending": scheduled_pending, "failed": scheduled_failed}}


@router.get("/webhooks/dead-letter")
async def dead_letters(user: User = Depends(_founder)):
    db = get_db()
    out = []
    async for d in db.webhook_deliveries.find({"status": {"$in": ["failed", "dead"]}}) \
                                                .sort("created_at", -1).limit(200):
        out.append({"id": str(d["_id"]), "org_id": d.get("org_id"),
                     "webhook_id": d.get("webhook_id"), "event": d.get("event"),
                     "status": d.get("status"),
                     "attempts": d.get("attempts"),
                     "last_error": d.get("last_error"),
                     "last_response_code": d.get("last_response_code"),
                     "created_at": d.get("created_at")})
    return {"deliveries": out}


@router.post("/webhooks/{delivery_id}/retry")
async def retry_delivery(delivery_id: str, request: Request,
                             user: User = Depends(_founder)):
    from ..services.webhooks import dispatch_event
    db = get_db()
    d = await db.webhook_deliveries.find_one({"_id": ObjectId(delivery_id)})
    if not d:
        raise HTTPException(404, "Not found")
    # Retry by dispatching again with same event/payload for the same org
    await dispatch_event(d["org_id"], d["event"], d.get("payload") or {})
    await db.webhook_deliveries.update_one({"_id": d["_id"]}, {"$inc": {"attempts": 1}})
    await audit.record(action="webhook.retry", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email,
                          org_id=d.get("org_id"), target_type="webhook_delivery",
                          target_id=delivery_id, request=request)
    return {"ok": True}


# ============ APPROVAL QUEUE ============

@router.get("/approvals")
async def list_approvals(status: str = Query("pending"),
                            user: User = Depends(_founder)):
    db = get_db()
    out = []
    async for a in db.approval_requests.find({"status": status}).sort("created_at", -1).limit(200):
        out.append({"id": str(a["_id"]), "org_id": a.get("org_id"),
                     "kind": a.get("kind"),
                     "requested_by_user_id": a.get("requested_by_user_id"),
                     "payload": a.get("payload") or {},
                     "status": a.get("status"),
                     "created_at": a.get("created_at")})
    return {"approvals": out}


class ApprovalDecisionReq(BaseModel):
    approve: bool
    note: Optional[str] = None


@router.post("/approvals/{aid}/decide")
async def decide_approval(aid: str, req: ApprovalDecisionReq, request: Request,
                              user: User = Depends(_founder)):
    db = get_db()
    a = await db.approval_requests.find_one({"_id": ObjectId(aid)})
    if not a:
        raise HTTPException(404, "Not found")
    await db.approval_requests.update_one({"_id": a["_id"]}, {"$set": {
        "status": "approved" if req.approve else "rejected",
        "reviewer_user_id": user.id, "reviewer_note": req.note,
        "reviewed_at": utc_now_iso(), "updated_at": utc_now_iso(),
    }})
    await audit.record(action=f"approval.{'approve' if req.approve else 'reject'}",
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, org_id=a.get("org_id"),
                          target_type="approval", target_id=aid,
                          reason=req.note, request=request)
    return {"ok": True}
