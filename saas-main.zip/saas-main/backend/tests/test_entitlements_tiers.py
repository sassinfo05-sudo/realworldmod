"""Round 15 — server-side plan-entitlement enforcement at DENIED (free) and ALLOWED (revenue) tiers.

A fresh owner is signed up (free plan). Every gated backend operation must return 402 with a precise
`feature_not_in_plan` / `plan_limit_reached` payload — regardless of what the UI shows. The org's plan is
then set to `revenue` directly in the DB (the runtime source of truth) and the same operations succeed.
"""
from __future__ import annotations

import os
import secrets
import uuid

import pytest
import requests

import _creds

API = _creds.api()
_IP = f"10.97.{secrets.randbelow(250)}.{secrets.randbelow(250)}"


def _hdr(tok):
    return {"Authorization": f"Bearer {tok}", "X-Forwarded-For": _IP}


@pytest.fixture(scope="module")
def free_owner():
    email = f"ent-{uuid.uuid4().hex[:10]}@example.com"
    r = requests.post(f"{API}/auth/signup", headers={"X-Forwarded-For": _IP},
                      json={"email": email, "password": "Ent1tlement-Pass!", "full_name": "Ent Test",
                            "business_name": "Entitlement Test Co"}, timeout=30)
    assert r.status_code in (200, 201), r.text
    tok = r.json()["access_token"]
    me = requests.get(f"{API}/auth/me", headers=_hdr(tok), timeout=30).json()
    org_id = me.get("org_id") or (me.get("user") or {}).get("org_id")
    assert org_id
    return {"token": tok, "org_id": org_id, "email": email}


def _set_plan(org_id, plan_code):
    from pymongo import MongoClient
    db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
    db.subscriptions.update_one({"org_id": org_id}, {"$set": {"plan_code": plan_code, "status": "active"}}, upsert=True)


def _website_id(tok):
    r = requests.get(f"{API}/sites", headers=_hdr(tok), timeout=30)
    if r.status_code == 200:
        items = r.json().get("items") or r.json().get("sites") or []
        if items:
            return items[0].get("id") or items[0].get("_id")
    return None


def _is_402(r, kinds=("feature_not_in_plan", "plan_limit_reached", "plan_limit")):
    assert r.status_code == 402, f"{r.status_code} {r.text[:200]}"
    d = r.json().get("detail") or {}
    assert d.get("error") in kinds, d
    assert d.get("message"), d
    return d


def test_free_tier_denied(free_owner):
    tok = free_owner["token"]
    h = _hdr(tok)
    # custom domain
    _is_402(requests.post(f"{API}/domains", headers=h, json={"hostname": "shop.example.com", "website_id": "x" * 24}, timeout=30))
    # automations (workflow create / template / publish)
    _is_402(requests.post(f"{API}/workflows", headers=h, json={"name": "Nurture", "trigger": "new_lead"}, timeout=30))
    _is_402(requests.post(f"{API}/workflows/from-template/anything", headers=h, timeout=30))
    # campaigns
    _is_402(requests.post(f"{API}/marketing/campaigns", headers=h, json={"name": "C", "subject": "S"}, timeout=30))
    _is_402(requests.post(f"{API}/marketing/campaigns/{'0'*24}/send", headers=h, timeout=30))
    # ai receptionist voice config
    _is_402(requests.put(f"{API}/numbers/{'0'*24}/voice", headers=h, json={"persona": "x"}, timeout=30))
    # abandoned cart sweep
    _is_402(requests.post(f"{API}/store/abandoned/sweep", headers=h, json={}, timeout=30))
    # api keys
    _is_402(requests.post(f"{API}/setup/api-keys", headers=h, json={"name": "k", "scopes": ["contacts:write"]}, timeout=30))
    # subscription product (create) + bypass via update
    _is_402(requests.post(f"{API}/store/products", headers=h,
                          json={"name": "Sub", "price_cents": 1000, "is_subscription": True}, timeout=30))
    ok = requests.post(f"{API}/store/products", headers=h, json={"name": "Plain", "price_cents": 1000}, timeout=30)
    assert ok.status_code in (200, 201), ok.text
    pid = ok.json().get("id") or ok.json().get("_id")
    _is_402(requests.put(f"{API}/store/products/{pid}", headers=h,
                         json={"name": "Plain", "price_cents": 1000, "is_subscription": True}, timeout=30))
    # product cap (free = 10): we have 1, add 9 more OK, the 11th → 402 plan_limit_reached
    for i in range(9):
        r = requests.post(f"{API}/store/products", headers=h, json={"name": f"P{i}", "price_cents": 100}, timeout=30)
        assert r.status_code in (200, 201), r.text
    d = _is_402(requests.post(f"{API}/store/products", headers=h, json={"name": "P-over", "price_cents": 100}, timeout=30))
    assert d.get("feature") == "products" and d.get("cap") == 10
    # Ordinary CRUD remains available when entitlements are exhausted
    assert requests.get(f"{API}/store/products", headers=h, timeout=30).status_code == 200
    assert requests.get(f"{API}/auth/me", headers=h, timeout=30).status_code == 200


def test_revenue_tier_allowed(free_owner):
    tok, org_id = free_owner["token"], free_owner["org_id"]
    _set_plan(org_id, "revenue")
    h = _hdr(tok)
    # Plans API must reflect the DB plan as runtime truth
    u = requests.get(f"{API}/usage/summary", headers=h, timeout=30)
    if u.status_code == 200:
        assert (u.json().get("plan") or {}).get("plan_code", "revenue") == "revenue"
    r = requests.post(f"{API}/workflows", headers=h, json={"name": "Nurture", "trigger": "new_lead"}, timeout=30)
    assert r.status_code == 201, r.text
    r = requests.post(f"{API}/marketing/campaigns", headers=h, json={"name": "C", "subject": "S"}, timeout=30)
    assert r.status_code in (200, 201), r.text
    r = requests.post(f"{API}/store/products", headers=h, json={"name": "Sub", "price_cents": 1000, "is_subscription": True}, timeout=30)
    assert r.status_code in (200, 201), r.text
    r = requests.post(f"{API}/setup/api-keys", headers=h, json={"name": "k", "scopes": ["contacts:write"]}, timeout=30)
    assert r.status_code in (200, 201), r.text
    r = requests.post(f"{API}/store/abandoned/sweep", headers=h, json={}, timeout=30)
    assert r.status_code == 200, r.text
    # custom domain: entitlement passes; downstream validation (website ownership) applies
    r = requests.post(f"{API}/domains", headers=h, json={"hostname": "shop.example.com", "website_id": "0" * 24}, timeout=30)
    assert r.status_code != 402, r.text
    # ai receptionist still NOT in revenue → 402 (autopilot+ only)
    _is_402(requests.put(f"{API}/numbers/{'0'*24}/voice", headers=h, json={"persona": "x"}, timeout=30))
    _set_plan(org_id, "autopilot")
    r = requests.put(f"{API}/numbers/{'0'*24}/voice", headers=h, json={"persona": "x"}, timeout=30)
    assert r.status_code != 402, r.text


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
