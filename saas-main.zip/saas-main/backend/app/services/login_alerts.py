"""New-device / new-location sign-in tracking + owner email alerts.

On each successful login we fingerprint the session (device id + IP + user-agent). The FIRST device
for an account is recorded silently (it's the owner enrolling). Any subsequent NEW device or new
IP-country triggers a `security_alert` transactional email (already default-on, sent from security@).
Fails open: alerting never blocks or breaks login.
"""
from __future__ import annotations

import hashlib
from typing import Any, Dict

from fastapi import Request

from ..db import get_db, utc_now_iso

DEVICES = "login_devices"
HISTORY = "login_history"


def client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for") or ""
    if xff:
        return xff.split(",")[0].strip()
    return getattr(getattr(request, "client", None), "host", "") or ""


def _country(request: Request) -> str:
    for h in ("cf-ipcountry", "x-vercel-ip-country", "x-geo-country", "x-appengine-country"):
        v = request.headers.get(h)
        if v and v != "XX":
            return v
    return ""


def _device_label(ua: str) -> str:
    ua = (ua or "").lower()
    os_ = ("iPhone" if "iphone" in ua else "iPad" if "ipad" in ua else "Android" if "android" in ua
           else "Mac" if "mac os" in ua or "macintosh" in ua else "Windows" if "windows" in ua
           else "Linux" if "linux" in ua else "device")
    br = ("Edge" if "edg" in ua else "Chrome" if "chrome" in ua and "edg" not in ua
          else "Safari" if "safari" in ua and "chrome" not in ua else "Firefox" if "firefox" in ua
          else "browser")
    return f"{br} on {os_}"


def _fingerprint(request: Request, device_id: str) -> str:
    ua = request.headers.get("user-agent") or ""
    basis = device_id or (ua + "|" + client_ip(request))
    return hashlib.sha256(basis.encode()).hexdigest()[:32]


async def record_and_alert(user, request: Request) -> Dict[str, Any]:
    """Record this sign-in; email the owner if the device/country is new. Never raises."""
    try:
        db = get_db()
        ua = request.headers.get("user-agent") or ""
        did = request.headers.get("x-device-id") or ""
        fp = _fingerprint(request, did)
        ip = client_ip(request)
        country = _country(request)
        label = _device_label(ua)
        location = country or (ip or "an unknown location")

        prior_count = await db[DEVICES].count_documents({"user_id": user.id})
        existing = await db[DEVICES].find_one({"user_id": user.id, "fingerprint": fp})
        now = utc_now_iso()

        await db[HISTORY].insert_one({"user_id": user.id, "org_id": user.org_id, "ip": ip,
                                      "country": country, "device": label, "fingerprint": fp,
                                      "new_device": not existing, "created_at": now})

        if existing:
            await db[DEVICES].update_one({"_id": existing["_id"]},
                                         {"$set": {"last_seen": now, "ip": ip, "country": country}})
            return {"new_device": False}

        await db[DEVICES].insert_one({"user_id": user.id, "org_id": user.org_id, "fingerprint": fp,
                                      "device": label, "ip": ip, "country": country,
                                      "first_seen": now, "last_seen": now})

        # Silently enrol the very first device; alert on every new one after that.
        if prior_count == 0:
            return {"new_device": True, "alerted": False, "first_device": True}

        import asyncio
        from . import transactional as _tx
        asyncio.create_task(_tx.send_transactional(
            "security_alert", user.email,
            {"name": getattr(user, "full_name", "") or "there", "device": label, "location": location}))
        return {"new_device": True, "alerted": True}
    except Exception:  # noqa: BLE001 — alerting must never break login
        return {"new_device": False, "error": True}


async def recent_logins(user_id: str, limit: int = 15):
    db = get_db()
    out = []
    async for r in db[HISTORY].find({"user_id": user_id}, {"_id": 0}).sort("created_at", -1).limit(int(limit)):
        out.append(r)
    return out


async def list_devices(user_id: str):
    db = get_db()
    out = []
    async for d in db[DEVICES].find({"user_id": user_id}, {"_id": 0}).sort("last_seen", -1):
        out.append(d)
    return out
