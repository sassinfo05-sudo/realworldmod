import { useEffect, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, ShieldCheck, Mail, KeyRound, Trash2, UserX, UserCheck, Copy } from "lucide-react";

export default function StaffTeam() {
    const [members, setMembers] = useState([]);
    const [roles, setRoles] = useState([]);
    const [me, setMe] = useState(null);
    const [open, setOpen] = useState(false);
    const [form, setForm] = useState({ email: "", full_name: "", role: "support", work_handle: "", password: "" });
    const [created, setCreated] = useState(null);
    const [busy, setBusy] = useState(false);

    async function load() {
        try {
            const [m, r, meR] = await Promise.all([api.get("/staff/members"), api.get("/staff/roles"), api.get("/staff/me").catch(() => ({ data: null }))]);
            setMembers(m.data); setRoles(r.data); setMe(meR.data);
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not load team"); }
    }
    useEffect(() => { load(); }, []);

    async function create(e) {
        e.preventDefault(); setBusy(true);
        try {
            const { data } = await api.post("/staff/members", { ...form, work_handle: form.work_handle || null, password: form.password || null });
            setCreated(data); setForm({ email: "", full_name: "", role: "support", work_handle: "", password: "" }); load();
            toast.success("Staff member added");
        } catch (err) { toast.error(err?.response?.data?.detail || "Could not add"); } finally { setBusy(false); }
    }
    async function patch(id, body, okMsg) {
        try { await api.patch(`/staff/members/${id}`, body); toast.success(okMsg); load(); }
        catch (err) { toast.error(err?.response?.data?.detail || "Update failed"); }
    }
    async function remove(m) {
        if (!window.confirm(`Remove ${m.email} from staff?`)) return;
        try { await api.delete(`/staff/members/${m.id}`); toast.success("Removed"); load(); } catch (err) { toast.error(err?.response?.data?.detail || "Delete failed"); }
    }
    function resetPw(m) {
        const pw = window.prompt(`New password for ${m.email} (min 10 chars)`);
        if (pw) patch(m.id, { new_password: pw }, "Password updated");
    }

    return (
        <div className="px-4 md:px-8 py-6 max-w-[1200px] mx-auto" data-testid="staff-team-page">
            <div className="flex flex-wrap items-end justify-between gap-3 mb-6">
                <div>
                    <h2 className="font-display text-2xl md:text-3xl text-brand-ink dark:text-white">Team & roles</h2>
                    <p className="text-sm text-zinc-500 mt-1">Zanelvo workers have their own accounts (separate from customers), a preset role and a <b>@zanelvo.com</b> work alias. Two-factor email codes are always on{me && !me.twofa_email_configured ? " — skipped until you connect the 2FA sender in Payments & email" : ""}.</p>
                </div>
                <Button onClick={() => { setCreated(null); setOpen(true); }} data-testid="staff-add-btn"><Plus className="w-4 h-4" /> Add staff member</Button>
            </div>

            <div className="grid md:grid-cols-3 gap-3 mb-8">
                {roles.map((r) => (
                    <div key={r.key} className="rounded-xl border border-brand-line bg-white dark:bg-zinc-900 p-4" data-testid={`staff-role-${r.key}`}>
                        <div className="flex items-center justify-between"><div className="font-medium text-sm">{r.label}</div><span className="text-[10px] text-zinc-400">{members.filter((m) => m.role === r.key).length} member(s)</span></div>
                        <p className="text-xs text-zinc-500 mt-1">{r.desc}</p>
                        <div className="mt-2 flex flex-wrap gap-1">{r.perms.map((p) => <span key={p} className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-white/10">{p === "*" ? "everything" : p}</span>)}</div>
                    </div>
                ))}
            </div>

            <div className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 overflow-hidden">
                <table className="w-full text-sm">
                    <thead className="bg-zinc-50 dark:bg-white/5 text-left text-[11px] uppercase tracking-widest text-zinc-500"><tr><th className="px-4 py-3">Member</th><th className="px-4 py-3">Role</th><th className="px-4 py-3">Work email</th><th className="px-4 py-3">2FA</th><th className="px-4 py-3">Last login</th><th className="px-4 py-3"></th></tr></thead>
                    <tbody>
                        {members.map((m) => (
                            <tr key={m.id} className="border-t border-brand-line/70" data-testid={`staff-member-${m.id}`}>
                                <td className="px-4 py-3"><div className="font-medium flex items-center gap-2">{m.full_name}{!m.active && <span className="text-[10px] px-1.5 rounded bg-zinc-200">disabled</span>}</div><div className="text-xs text-zinc-500">{m.email}</div></td>
                                <td className="px-4 py-3">
                                    <select value={m.role} onChange={(e) => patch(m.id, { role: e.target.value }, "Role updated")} className="h-8 rounded-md border border-brand-line bg-white dark:bg-zinc-900 px-2 text-xs" data-testid={`staff-role-select-${m.id}`}>
                                        {roles.map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}
                                    </select>
                                </td>
                                <td className="px-4 py-3 text-xs"><span className="inline-flex items-center gap-1"><Mail className="w-3 h-3 text-zinc-400" />{m.work_email}</span>
                                    <button className="ml-1 text-zinc-400 hover:text-brand-copper" title="Copy" onClick={() => { navigator.clipboard?.writeText(m.work_email); toast.success("Copied"); }}><Copy className="w-3 h-3 inline" /></button>
                                    <button className="ml-2 text-[11px] text-brand-copper" onClick={() => { const h = window.prompt("Work alias handle (before @)", m.work_email?.split("@")[0]); if (h) patch(m.id, { work_handle: h }, "Alias updated"); }}>edit</button></td>
                                <td className="px-4 py-3 text-xs text-emerald-700 inline-flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> email, always</td>
                                <td className="px-4 py-3 text-xs text-zinc-500">{m.last_login_at ? new Date(m.last_login_at).toLocaleString() : "never"}</td>
                                <td className="px-4 py-3 text-right whitespace-nowrap">
                                    <Button size="sm" variant="ghost" onClick={() => resetPw(m)} title="Reset password"><KeyRound className="w-3.5 h-3.5" /></Button>
                                    {m.role !== "owner" && <Button size="sm" variant="ghost" onClick={() => patch(m.id, { active: !m.active }, m.active ? "Deactivated" : "Reactivated")} title={m.active ? "Deactivate" : "Reactivate"}>{m.active ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}</Button>}
                                    {m.role !== "owner" && <Button size="sm" variant="ghost" className="text-red-600" onClick={() => remove(m)} data-testid={`staff-delete-${m.id}`}><Trash2 className="w-3.5 h-3.5" /></Button>}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent data-testid="staff-add-dialog">
                    <DialogHeader><DialogTitle>{created ? "Staff member added" : "Add a staff member"}</DialogTitle></DialogHeader>
                    {created ? (
                        <div className="space-y-3 text-sm">
                            {created.emailed ? (
                                <>
                                    <p><b>{created.full_name}</b> was invited at <b>{created.email}</b>.</p>
                                    <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-emerald-900" data-testid="staff-invite-emailed">A single-use set-password link was emailed (valid 48h). No password is ever shown or sent in plain text.</div>
                                </>
                            ) : created.invite_link ? (
                                <>
                                    <p><b>{created.full_name}</b> needs to set a password before signing in.</p>
                                    <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-900 break-all">Dev/test only (no email provider connected) — share this single-use link (valid 48h):<br /><code className="font-mono text-xs" data-testid="staff-invite-link">{created.invite_link}</code></div>
                                </>
                            ) : created.note ? (
                                <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-900">{created.note}</div>
                            ) : (
                                <p><b>{created.full_name}</b> can sign in at <code>/staff/login</code> with <b>{created.email}</b> and the password you set.</p>
                            )}
                            <p className="text-zinc-500">Work alias: <b>{created.work_email}</b>.</p>
                            <div className="flex justify-end"><Button onClick={() => setOpen(false)}>Done</Button></div>
                        </div>
                    ) : (
                        <form onSubmit={create} className="space-y-3">
                            <div><Label>Full name</Label><Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required className="mt-1" data-testid="staff-add-name" /></div>
                            <div><Label>Login email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required className="mt-1" data-testid="staff-add-email" /></div>
                            <div className="grid grid-cols-2 gap-3">
                                <div><Label>Role</Label><select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="mt-1 w-full h-10 rounded-lg border border-brand-line bg-white px-3 text-sm" data-testid="staff-add-role">{roles.filter((r) => r.key !== "owner" || me?.role === "owner").map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}</select></div>
                                <div><Label>Work alias</Label><div className="mt-1 flex items-center"><Input value={form.work_handle} onChange={(e) => setForm({ ...form, work_handle: e.target.value })} placeholder="firstname" className="rounded-r-none" /><span className="h-10 px-2 grid place-items-center text-xs rounded-r-lg border border-l-0 border-brand-line bg-zinc-50">@zanelvo.com</span></div></div>
                            </div>
                            <div><Label>Password (optional — leave blank to send a set-password invitation)</Label><Input value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="mt-1" placeholder="Leave blank to email an invitation link" /></div>
                            <div className="flex justify-end gap-2"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={busy} data-testid="staff-add-submit">{busy ? "Adding…" : "Add member"}</Button></div>
                        </form>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}
