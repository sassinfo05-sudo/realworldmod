# ZANELVO — HANDOFF (Round 7)
_Continues HANDOFF_ROUND_6.md. Env is wiped on import — rebuild per Round 6 §0 first._

## Preview + creds (this run)
- Preview: https://bootstrap-fix-2.preview.emergentagent.com
- Owner (customer /app): owner@zanelvo.com / <rotated — see test_credentials.md>
- Founder (staff /staff, separate /api/staff/auth/login, 2FA auto-skipped): founder@zanelvo.com / <rotated — see test_credentials.md>
- (Seed regenerates passwords each fresh seed — always check /app/memory/test_credentials.md)

## SHIPPED & TESTED this round (all backend-agent green)
1. **Universal LLM/AI cost tracking + per-plan budget (biggest ask).** New `services/usage.py`:
   request-scoped ContextVar (org_id/user_id/feature set in deps.current_user), COST_RATES table
   (founder-overridable via platform_settings key `llm_cost_rates`), `record_llm_usage` writes to
   `db.llm_usage_events`, `enforce_llm_budget` raises 402 'ai_budget_reached'. ALL LLM calls funnel
   through `services/llm.py` (generate_text/generate_json/generate_image) which now ENFORCE before +
   RECORD after every call — so tracking is automatic/comprehensive. Plan AI budgets added to
   entitlements (`ai_credits_usd_per_month`): free $0.50 / launch $3 / revenue $15 / autopilot $60 /
   scale $300, overridable via plan `limits`. Endpoints: GET /api/usage/ai (owner) + GET
   /api/staff/usage/ai (founder audit). UI: AI-usage panel in Billing.jsx; new StaffAiUsage.jsx
   (/staff/ai-usage, nav "AI cost & usage"). Tested 23/23.
2. **Email system 100x.** Rewrote `services/transactional.py` design system: premium responsive
   _SHELL (gradient brand header+logo tile, accent bar, shadowed card, preheader, footer w/ product
   URL + support email), new components (_BTN gradient, _INFO, _DIVIDER, _MUTED), all 9 templates
   rewritten w/ warmer copy + preheaders. NEW POST /api/staff/email/ai-draft (LLM writes/improves an
   email; auto-metered as feature 'staff/email/ai-draft'). UI: "Write with AI" panel in EmailCenter
   ComposeTab. Tested (templates render with zero unresolved {braces}; ai-draft valid + tracked).
3. **Brand/dev-mention cleanup (#7 partial).** Removed Wix/Shopify/Squarespace comparison table in
   Home.jsx → new "everything included" value grid; removed "just like Shopify" in Discounts.jsx;
   de-jargoned SimulatedSubscriptionCheckout copy; cleaned AddSectionMenu comment. (Internal-only code
   comments in backend shipping.py/ecommerce.py still say "Shopify-style" — not user-visible.)
4. **Plan price visibility (#3).** Verified Pricing page + checkout sessions read live /api/plans and
   backend session price — founder edits propagate. (No further change needed unless adding a pricing
   block to Home.)
5. **Health check (#4 partial).** Backend boots clean; core owner endpoints all 200; Phase 1 verified.

## FRONTEND UI-TESTED (Round 7): Billing AI panel, Staff AI-usage page, AI email composer — all 3 PASS.

## ROUND 8 IN PROGRESS (this session, after Round 7 checkpoint)
- [x] Frontend UI tests for Round-7 AI features — 3/3 PASS.
- [x] Marketing Analytics 100x — BUILT & TESTED (8/8 pass). services/campaign_tracking.py +
      routes/tracking.py (public /api/t/o/{token}.gif + /api/t/c/{token} UTM redirect). Send embeds
      tracked HTML; A/B (ab_test+variants[], 50/50, per-variant metrics + winner). Endpoints:
      GET /api/marketing/campaigns/{id}/analytics + /api/marketing/analytics/overview. Revenue
      last-touch attribution in store _finalize_paid_order (7-day window). Frontend Marketing.jsx:
      A/B toggle + variant B + analytics modal. NOTE: campaign send has a 09:00-21:00 UTC quiet-hours
      guard + consent/suppression filters.
- [x] Logo memory & auto-apply — BUILT & TESTED (6/6 pass). Provider (gemini|openai gpt-image-1)
      remembered per org (org_branding.logo_provider). llm.generate_image takes provider/model override.
      New GET /api/branding/providers, POST /api/branding/apply-logo (auto-applies + mirrors to website
      theme; store already reads org_branding logo). ai-logo threads provider + remembers + optional
      auto_apply. PUT /branding no longer wipes logo_provider/logo_image on empty. Frontend LogoStudio:
      engine selector (remembered) + "Use & apply" button.
- [ ] Everything else left (home/pricing redesign for "wow", optimize) — NEXT.

## STILL LEFT (user wants ALL — priority)
- #5 Optimize to the max (perf/UX pass — broad, define scope).
- #6 FULL Home + Pricing redesign for "way more impressive/instant selling" (large, subjective — do
  incrementally, keep data-testids, screenshot before/after). Current pages are clean but not "wow".
- Deeper #7 audit (sweep any remaining competitor/dev-progress strings incl. backend comments if user
  wants literal-everything).
- Round-6 backlog (unchanged): logo provider choice (Gemini vs OpenAI gpt-image-1 — ASK user),
  storefront language switcher UI, marketing analytics 100x (open/click/conversion tracking + UTM +
  A/B), website-editor overhaul, live carrier rates/labels (needs Shippo/EasyPost key), onboarding
  rework, pro dashboard redesign, drag-drop uploads.
- NOTE: payments + live carrier rates remain SIMULATED until real keys connected.

## GOTCHAS
- usage.py cost = tokens estimated ~chars/4 (emergentintegrations doesn't return token counts). Rates
  founder-overridable. Image gen counted per-image.
- Budget enforce is a no-op when org_id unknown (public flows) — by design.
