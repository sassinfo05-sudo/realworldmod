import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, useParams } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { BookOpen, MessageSquare, Bot, HeartPulse, Send, Plus, ExternalLink, Search, Sparkles, LifeBuoy, ArrowRight, Rocket } from "lucide-react";

const CAT_ICON = {
    "Getting started": Rocket,
    "Plans & billing": Sparkles,
    "Booking": BookOpen,
    "Payments": Sparkles,
    "AI": Bot,
    "Security": LifeBuoy,
    "Domains": ExternalLink,
};

function ArticlesList() {
    const [q, setQ] = useState("");
    const [category, setCategory] = useState(null);
    const [articles, setArticles] = useState([]);
    const [cats, setCats] = useState([]);
    const [allCount, setAllCount] = useState(0);

    async function load() {
        const params = new URLSearchParams();
        if (q) params.set("q", q);
        if (category) params.set("category", category);
        const { data } = await api.get(`/support/articles${params.toString() ? "?" + params.toString() : ""}`);
        setArticles(data.articles || []);
        if (data.categories) setCats(data.categories);
        if (!q && !category) setAllCount((data.articles || []).length);
    }
    useEffect(() => { load(); }, [q, category]);

    const QUICK = [
        { to: "/app/support/ai", icon: Bot, title: "Ask the AI assistant", body: "Instant answers grounded on our help articles." },
        { to: "/app/support/tickets", icon: MessageSquare, title: "Contact support", body: "Open a ticket and we'll get back to you." },
        { to: "/app/support/status", icon: HeartPulse, title: "System status", body: "Check if everything is running smoothly." },
    ];

    return (
        <div data-testid="support-articles-page">
            {/* Hero */}
            <div className="relative overflow-hidden bg-brand-ink text-white px-6 py-12">
                <div className="pointer-events-none absolute -top-24 -right-16 w-96 h-96 rounded-full bg-brand-copper/30 blur-[110px]" />
                <div className="pointer-events-none absolute -bottom-32 -left-20 w-96 h-96 rounded-full bg-brand-accent/20 blur-[110px]" />
                <div className="relative max-w-3xl mx-auto text-center">
                    <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/70 mb-4">
                        <LifeBuoy className="w-3.5 h-3.5" /> Help Center
                    </div>
                    <h1 className="font-display text-3xl md:text-4xl font-medium">How can we help?</h1>
                    <p className="mt-2 text-white/60">Search guides and how-tos, or ask our AI assistant.</p>
                    <div className="relative mt-6 max-w-xl mx-auto">
                        <Search className="w-4 h-4 absolute left-4 top-3.5 text-zinc-400" />
                        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search the help center…"
                            className="w-full rounded-xl bg-white text-brand-ink pl-11 pr-4 py-3 text-sm outline-none ring-2 ring-transparent focus:ring-brand-copper/40"
                            data-testid="support-search" />
                    </div>
                </div>
            </div>

            <div className="p-6 max-w-5xl mx-auto">
                {/* Quick help cards */}
                <div className="grid sm:grid-cols-3 gap-3 -mt-12 relative z-10">
                    {QUICK.map((c) => (
                        <NavLink key={c.to} to={c.to} className="group rounded-xl border border-brand-line bg-white p-4 hover:-translate-y-1 hover:shadow-lg transition-all"
                            data-testid={`support-quick-${c.title.toLowerCase().replace(/\W/g, "-")}`}>
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-brand-copper/15 to-brand-accent/10 text-brand-copper flex items-center justify-center group-hover:scale-110 transition-transform"><c.icon className="w-5 h-5" /></div>
                            <div className="mt-3 font-medium text-brand-ink flex items-center gap-1">{c.title} <ArrowRight className="w-3.5 h-3.5 opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" /></div>
                            <div className="text-xs text-zinc-500 mt-1">{c.body}</div>
                        </NavLink>
                    ))}
                </div>

                {/* Category chips */}
                <div className="flex gap-2 items-center flex-wrap mt-8 mb-4">
                    <button onClick={() => setCategory(null)}
                        className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${!category ? "bg-brand-ink text-white border-brand-ink" : "border-brand-line text-zinc-500 hover:text-brand-ink"}`}
                        data-testid="support-cat-all">All articles</button>
                    {cats.map((c) => (
                        <button key={c} onClick={() => setCategory(c)}
                            className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${category === c ? "bg-brand-ink text-white border-brand-ink" : "border-brand-line text-zinc-500 hover:text-brand-ink"}`}
                            data-testid={`support-cat-${c.replace(/\W/g, "-")}`}>{c}</button>
                    ))}
                </div>

                {/* Article grid */}
                <div className="grid md:grid-cols-2 gap-3">
                    {articles.map((a) => {
                        const Ic = CAT_ICON[a.category] || BookOpen;
                        return (
                            <NavLink key={a.slug} to={`/app/support/article/${a.slug}`} data-testid={`support-article-${a.slug}`}
                                className="group flex gap-3 rounded-xl border border-brand-line bg-white p-4 hover:border-brand-copper hover:shadow-md transition-all">
                                <div className="w-9 h-9 shrink-0 rounded-lg bg-brand-cream text-brand-copper flex items-center justify-center"><Ic className="w-4 h-4" /></div>
                                <div className="min-w-0">
                                    <div className="text-[10px] uppercase tracking-widest text-brand-copper">{a.category}</div>
                                    <div className="mt-0.5 font-medium text-brand-ink group-hover:text-brand-copper transition-colors">{a.title}</div>
                                    <div className="mt-1 text-xs text-zinc-500 line-clamp-2">{a.excerpt}</div>
                                </div>
                            </NavLink>
                        );
                    })}
                    {!articles.length && <div className="text-zinc-500 col-span-full py-10 text-center" data-testid="support-articles-empty">No articles match your search.</div>}
                </div>
            </div>
        </div>
    );
}

function ArticleView() {
    const { slug } = useParams();
    const [article, setArticle] = useState(null);
    useEffect(() => {
        api.get(`/support/articles/${slug}`).then((r) => setArticle(r.data));
    }, [slug]);
    if (!article) return <div className="p-6 text-zinc-500">Loading…</div>;
    // very light markdown-to-HTML for headings, code, lists.
    // SECURITY: HTML-escape every line first so raw article text can never inject markup
    // (stored-XSS defense). Markdown control chars (# - ` *) are not escaped, so the
    // lightweight transforms below still work on the already-escaped, safe text.
    const esc = (s) => String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    const html = article.body_markdown
        .split("\n")
        .map((raw) => {
            const l = esc(raw);
            if (l.startsWith("# ")) return `<h1 class="font-display text-2xl text-brand-ink mt-4 mb-2">${l.slice(2)}</h1>`;
            if (l.startsWith("## ")) return `<h2 class="font-display text-lg text-brand-ink mt-4 mb-1">${l.slice(3)}</h2>`;
            if (l.startsWith("### ")) return `<h3 class="font-medium text-brand-ink mt-3 mb-1">${l.slice(4)}</h3>`;
            if (l.startsWith("- ")) return `<li class="ml-4 list-disc">${l.slice(2)}</li>`;
            if (l.match(/^\d+\. /)) return `<li class="ml-4 list-decimal">${l.replace(/^\d+\. /, "")}</li>`;
            if (!l.trim()) return "<br/>";
            return `<p class="text-sm text-zinc-700 my-1.5">${l}</p>`;
        })
        .join("\n")
        .replace(/`([^`]+)`/g, '<code class="bg-brand-cream px-1 rounded font-mono text-xs">$1</code>')
        .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    return (
        <div className="p-6 max-w-3xl" data-testid={`support-article-view-${slug}`}>
            <div className="text-[10px] uppercase tracking-widest text-brand-copper">{article.category}</div>
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: html }} />
        </div>
    );
}

function TicketsList() {
    const [tickets, setTickets] = useState([]);
    const [open, setOpen] = useState(false);
    const [subject, setSubject] = useState("");
    const [body, setBody] = useState("");
    const [severity, setSeverity] = useState("medium");
    const [category, setCategory] = useState("general");
    const [busy, setBusy] = useState(false);

    async function load() {
        const { data } = await api.get("/support/tickets");
        setTickets(data.tickets || []);
    }
    useEffect(() => { load(); }, []);

    async function create() {
        setBusy(true);
        try {
            await api.post("/support/tickets", { subject, body, severity, category });
            toast.success("Ticket opened");
            setOpen(false); setSubject(""); setBody("");
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); }
        finally { setBusy(false); }
    }

    return (
        <div className="p-6 max-w-5xl" data-testid="support-tickets-page">
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-medium text-brand-ink">Support tickets</h2>
                <Button onClick={() => setOpen(!open)} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="support-ticket-new-btn">
                    <Plus className="w-4 h-4 mr-1" /> New ticket
                </Button>
            </div>
            {open && (
                <div className="mb-4 rounded-lg border border-brand-line bg-white p-4 space-y-2" data-testid="support-ticket-form">
                    <Input placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} data-testid="support-ticket-subject" />
                    <div className="grid grid-cols-2 gap-2">
                        <select value={severity} onChange={(e) => setSeverity(e.target.value)} className="border border-brand-line rounded px-2 py-1.5 text-sm bg-white" data-testid="support-ticket-severity">
                            {["low", "medium", "high", "urgent"].map((s) => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <select value={category} onChange={(e) => setCategory(e.target.value)} className="border border-brand-line rounded px-2 py-1.5 text-sm bg-white">
                            {["general", "billing", "bug", "feature_request"].map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
                        </select>
                    </div>
                    <Textarea placeholder="What's going on?" rows={4} value={body} onChange={(e) => setBody(e.target.value)} data-testid="support-ticket-body" />
                    <Button onClick={create} disabled={busy || !subject || !body} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="support-ticket-submit-btn">
                        Open ticket
                    </Button>
                </div>
            )}
            <div className="border border-brand-line rounded-lg bg-white overflow-hidden divide-y divide-brand-line">
                {tickets.map((t) => (
                    <div key={t.id} className="p-3 flex items-center gap-3" data-testid={`support-ticket-${t.id}`}>
                        <div className="flex-1">
                            <div className="text-sm font-medium text-brand-ink">{t.subject}</div>
                            <div className="text-xs text-zinc-500">{t.category} · {t.severity} · {t.status}</div>
                        </div>
                        <div className="text-xs text-zinc-400 font-mono">{t.created_at?.slice(0, 16)}</div>
                    </div>
                ))}
                {!tickets.length && <div className="text-center text-zinc-500 py-8" data-testid="support-tickets-empty">No tickets yet.</div>}
            </div>
        </div>
    );
}

function AiAssistant() {
    const [q, setQ] = useState("");
    const [messages, setMessages] = useState([]);
    const [busy, setBusy] = useState(false);

    async function ask() {
        const text = q.trim(); if (!text || busy) return;
        setBusy(true);
        setMessages((m) => [...m, { role: "user", content: text }]);
        setQ("");
        try {
            const { data } = await api.post("/support/ai/ask", { message: text });
            setMessages((m) => [...m, {
                role: "ai", content: data.reply_text, cited: data.cited_slugs,
                intent: data.intent, confidence: data.confidence,
            }]);
        } catch (e) { toast.error("Failed"); }
        finally { setBusy(false); }
    }

    return (
        <div className="p-6 max-w-3xl" data-testid="support-ai-page">
            <div className="mb-3">
                <h2 className="text-lg font-medium text-brand-ink">Ask the AI support assistant</h2>
                <p className="text-sm text-zinc-500">Grounded on help articles only. Won&apos;t invent behaviors — will escalate to a ticket instead.</p>
            </div>
            <div className="rounded-lg border border-brand-line bg-white overflow-hidden">
                <div className="p-3 space-y-2 min-h-[240px] max-h-[420px] overflow-y-auto" data-testid="support-ai-messages">
                    {messages.map((m, i) => (
                        <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                            <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${
                                m.role === "user" ? "bg-brand-ink text-white" :
                                "bg-brand-cream text-brand-ink whitespace-pre-wrap"
                            }`}>
                                {m.content}
                                {m.cited && m.cited.length > 0 && (
                                    <div className="mt-2 text-[10px] uppercase tracking-widest text-brand-copper">
                                        Cited: {m.cited.join(", ")}
                                    </div>
                                )}
                                {m.intent === "escalate" && (
                                    <div className="mt-2 text-[11px] text-amber-700 flex items-center gap-1">
                                        ↳ suggests opening a ticket
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                    {!messages.length && <div className="text-zinc-500 text-sm p-4">Ask about plans, MFA, webhooks, booking rules — anything covered in the help articles.</div>}
                </div>
                <form onSubmit={(e) => { e.preventDefault(); ask(); }} className="border-t border-brand-line p-2 flex gap-1.5 bg-white">
                    <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Type your question…" disabled={busy} data-testid="support-ai-input" />
                    <Button type="submit" disabled={busy || !q.trim()} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="support-ai-send-btn">
                        <Send className="w-4 h-4" />
                    </Button>
                </form>
            </div>
        </div>
    );
}

function StatusPage() {
    const [state, setState] = useState(null);
    useEffect(() => {
        api.get("/support/status").then((r) => setState(r.data));
    }, []);
    return (
        <div className="p-6 max-w-3xl" data-testid="support-status-page">
            <h2 className="text-lg font-medium text-brand-ink mb-3">System status</h2>
            <div className={`rounded-lg border p-4 mb-4 ${
                state?.overall === "operational" ? "border-emerald-200 bg-emerald-50" :
                state?.overall === "degraded" ? "border-amber-200 bg-amber-50" : "border-red-200 bg-red-50"
            }`} data-testid={`support-status-overall-${state?.overall}`}>
                <div className="text-xs uppercase tracking-widest">Overall</div>
                <div className="mt-1 font-display text-2xl capitalize">{state?.overall || "loading"}</div>
                {state?.as_of && <div className="text-[10px] text-zinc-500 mt-1 font-mono">As of {state.as_of}</div>}
            </div>
            <div className="space-y-2">
                {(state?.checks || []).map((c) => (
                    <div key={c.component} className="flex items-center justify-between rounded-md border border-brand-line bg-white px-3 py-2" data-testid={`support-status-check-${c.component}`}>
                        <div className="text-sm font-medium text-brand-ink capitalize">{c.component}</div>
                        <div className={`text-xs uppercase tracking-widest ${
                            c.status === "operational" ? "text-emerald-600" :
                            c.status === "degraded" ? "text-amber-600" : "text-red-600"
                        }`}>{c.status}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export function SupportShell() {
    return (
        <div data-testid="support-shell">
            <div className="border-b border-brand-line bg-white sticky top-0 z-10 px-6 py-3 flex flex-wrap gap-2 items-center">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mr-3">Support</div>
                <nav className="flex gap-1 flex-wrap">
                    {[
                        { to: "/app/support", label: "Help center", icon: BookOpen, end: true },
                        { to: "/app/support/tickets", label: "Tickets", icon: MessageSquare },
                        { to: "/app/support/ai", label: "AI assistant", icon: Bot },
                        { to: "/app/support/status", label: "Status", icon: HeartPulse },
                    ].map(({ to, label, icon: Icon, end }) => (
                        <NavLink key={to} to={to} end={!!end}
                                    data-testid={`support-nav-${label.toLowerCase().replace(/\W/g, "-")}`}
                                    className={({ isActive }) =>
                                        `inline-flex items-center gap-1.5 text-sm px-2.5 py-1.5 rounded-md ${
                                            isActive ? "bg-brand-cream text-brand-ink" : "text-zinc-500 hover:text-brand-ink"
                                        }`
                                    }>
                            <Icon className="w-3.5 h-3.5" /> {label}
                        </NavLink>
                    ))}
                </nav>
            </div>
            <Outlet />
        </div>
    );
}

export { ArticlesList, ArticleView, TicketsList, AiAssistant, StatusPage };
