"""Visual workflow engine (Round 10, Gate 5).

Workflow = trigger + directed graph {nodes:[{id,type,config}], edges:[{from,to,when}]}.
Node types: trigger · condition (yes/no edges) · delay · wait_until (hour of day) · send_email · add_tag ·
remove_tag · create_task · notify_owner · webhook (SSRF-guarded) · ai_generate (metered) · approval · end.

Runs are persisted step-by-step in db.workflow_runs so delays/approvals survive restarts:
  status: running | waiting (next_at) | awaiting_approval | completed | failed | dead_letter | cancelled
Retries: a failing node is retried up to MAX_ATTEMPTS with backoff; then the run is dead-lettered
(replayable via /runs/{id}/retry). Test mode never sends/mutates — it records what WOULD happen.
Cost limits: per-workflow monthly AI cap (settings.cost_cap_usd) checked against the usage ledger
(feature = "workflow:<id>"); every AI/email node is metered through the central cost service.
"""
from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from bson import ObjectId

from ..db import get_db, utc_now_iso

logger = logging.getLogger(__name__)

MAX_ATTEMPTS = 3
MAX_STEPS_PER_RUN = 60

TRIGGERS: List[Dict[str, str]] = [
    {"key": "form_submitted", "label": "Form submitted", "group": "Website"},
    {"key": "new_lead", "label": "New lead / contact created", "group": "CRM"},
    {"key": "tag_added", "label": "Tag added to contact", "group": "CRM"},
    {"key": "booking_created", "label": "Booking created", "group": "Bookings"},
    {"key": "booking_cancelled", "label": "Booking cancelled", "group": "Bookings"},
    {"key": "booking_reminder", "label": "Booking reminder due", "group": "Bookings"},
    {"key": "quote_sent", "label": "Quote sent", "group": "Sales"},
    {"key": "quote_accepted", "label": "Quote accepted", "group": "Sales"},
    {"key": "quote_not_answered", "label": "Quote not answered (48h)", "group": "Sales"},
    {"key": "invoice_paid", "label": "Invoice paid", "group": "Sales"},
    {"key": "invoice_overdue", "label": "Invoice overdue", "group": "Sales"},
    {"key": "payment_failed", "label": "Payment failed", "group": "Sales"},
    {"key": "job_completed", "label": "Job completed", "group": "Operations"},
    {"key": "order_paid", "label": "Store order paid", "group": "Store"},
    {"key": "order_completed", "label": "Store order fulfilled", "group": "Store"},
    {"key": "abandoned_checkout", "label": "Abandoned checkout", "group": "Store"},
    {"key": "low_stock", "label": "Low stock", "group": "Store"},
    {"key": "review_request", "label": "Review request due", "group": "Growth"},
    {"key": "win_back", "label": "Win-back (no activity 90 days)", "group": "Growth"},
    {"key": "support_escalation", "label": "Support escalated to human", "group": "Support"},
    {"key": "manual", "label": "Manual / test only", "group": "Other"},
]

NODE_TYPES: List[Dict[str, Any]] = [
    {"type": "trigger", "label": "Trigger", "config": {}},
    {"type": "condition", "label": "Condition (yes / no)", "config": {"field": "contact.tags", "op": "contains", "value": ""}},
    {"type": "ab_split", "label": "A/B split", "config": {"percent_a": 50, "sticky": True}},
    {"type": "delay", "label": "Wait", "config": {"amount": 1, "unit": "hours"}},
    {"type": "wait_until", "label": "Wait until time of day", "config": {"hour": 9}},
    {"type": "send_email", "label": "Send email", "config": {"subject": "", "body": "", "to": "{{contact.email}}"}},
    {"type": "add_tag", "label": "Add tag", "config": {"tag": ""}},
    {"type": "remove_tag", "label": "Remove tag", "config": {"tag": ""}},
    {"type": "create_task", "label": "Create task", "config": {"title": "Follow up"}},
    {"type": "notify_owner", "label": "Notify owner", "config": {"message": ""}},
    {"type": "webhook", "label": "Call webhook", "config": {"url": "", "method": "POST"}},
    {"type": "ai_generate", "label": "AI: write text", "config": {"prompt": "", "save_as": "ai_text"}},
    {"type": "approval", "label": "Approval gate", "config": {"note": ""}},
    {"type": "end", "label": "End", "config": {}},
]

_VAR = re.compile(r"{{\s*([a-zA-Z0-9_.]+)\s*}}")


def _get(ctx: Dict[str, Any], path: str) -> Any:
    cur: Any = ctx
    for part in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    return cur


def render(text: str, ctx: Dict[str, Any]) -> str:
    def sub(m):
        v = _get(ctx, m.group(1))
        return "" if v is None else (", ".join(map(str, v)) if isinstance(v, list) else str(v))
    return _VAR.sub(sub, text or "")


def validate_graph(graph: Dict[str, Any]) -> List[str]:
    errs: List[str] = []
    nodes = graph.get("nodes") or []
    edges = graph.get("edges") or []
    ids = [n.get("id") for n in nodes]
    if len(ids) != len(set(ids)):
        errs.append("duplicate node ids")
    known = {n["type"] for n in NODE_TYPES}
    trig = [n for n in nodes if n.get("type") == "trigger"]
    if len(trig) != 1:
        errs.append("exactly one trigger node is required")
    for n in nodes:
        if n.get("type") not in known:
            errs.append(f"unknown node type {n.get('type')}")
    idset = set(ids)
    for e in edges:
        if e.get("from") not in idset or e.get("to") not in idset:
            errs.append("edge references unknown node")
    # out-degree sanity: conditions need yes/no, others at most one outgoing
    for n in nodes:
        outs = [e for e in edges if e.get("from") == n.get("id")]
        if n.get("type") == "condition":
            whens = {e.get("when") for e in outs}
            if not whens & {"yes", "no"}:
                errs.append(f"condition {n.get('id')} needs a yes or no edge")
        elif n.get("type") == "ab_split":
            whens = {e.get("when") for e in outs}
            if not whens & {"a", "b"}:
                errs.append(f"A/B split {n.get('id')} needs an A or B edge")
            pa = (n.get("config") or {}).get("percent_a", 50)
            if not isinstance(pa, (int, float)) or not 0 <= float(pa) <= 100:
                errs.append(f"A/B split {n.get('id')} percent_a must be 0-100")
        elif n.get("type") != "end" and len(outs) > 1:
            errs.append(f"node {n.get('id')} has more than one outgoing edge")
    return errs


def _next(graph: Dict[str, Any], node_id: str, when: Optional[str] = None) -> Optional[str]:
    for e in graph.get("edges") or []:
        if e.get("from") == node_id and (when is None or (e.get("when") or "yes") == when):
            return e.get("to")
    return None


async def _load_contact(db, org_id: str, ctx: Dict[str, Any]) -> Dict[str, Any]:
    cid = ctx.get("contact_id")
    if not cid:
        if ctx.get("email"):
            c = await db.contacts.find_one({"org_id": org_id, "emails": str(ctx["email"]).lower()})
            if c:
                ctx["contact_id"] = str(c["_id"])
                return _contact_view(c)
        return {}
    try:
        c = await db.contacts.find_one({"_id": ObjectId(cid), "org_id": org_id})
    except Exception:  # noqa: BLE001
        c = None
    return _contact_view(c)


def _contact_view(c: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not c:
        return {}
    v = {k: val for k, val in c.items() if k != "_id"}
    v["id"] = str(c["_id"])
    v["email"] = (c.get("emails") or [None])[0] or c.get("email")
    v["phone"] = (c.get("phones") or [None])[0] or c.get("phone")
    v["name"] = c.get("display_name") or " ".join(x for x in (c.get("first_name"), c.get("last_name")) if x) or v["email"] or ""
    return v


def _eval_condition(cfg: Dict[str, Any], ctx: Dict[str, Any]) -> bool:
    field = cfg.get("field") or ""
    op = cfg.get("op") or "exists"
    val = cfg.get("value")
    cur = _get(ctx, field)
    if op == "exists":
        return cur not in (None, "", [], {})
    if op == "contains":
        if isinstance(cur, list):
            return val in cur
        return str(val or "").lower() in str(cur or "").lower()
    if op == "equals":
        return str(cur).lower() == str(val).lower()
    if op == "not_equals":
        return str(cur).lower() != str(val).lower()
    try:
        a, b = float(cur), float(val)
    except Exception:  # noqa: BLE001
        return False
    return {"gt": a > b, "gte": a >= b, "lt": a < b, "lte": a <= b}.get(op, False)


async def _ai_spend_this_month(db, workflow_id: str) -> float:
    month = datetime.now(timezone.utc).strftime("%Y-%m")
    total = 0.0
    async for r in db["llm_usage_events"].find({"feature": f"workflow:{workflow_id}", "billing_period": month},
                                        {"actual_cost_usd": 1, "estimated_cost_usd": 1}):
        total += float(r.get("actual_cost_usd") or r.get("estimated_cost_usd") or 0)
    return total


async def _send_email(db, org_id: str, to: str, subject: str, body: str, wf_id: str, test: bool) -> Dict[str, Any]:
    if not to or "@" not in to:
        return {"ok": False, "error": "no recipient email"}
    if await db.suppressions.find_one({"org_id": org_id, "email": to.lower()}):
        return {"ok": True, "skipped": "suppressed"}
    if test:
        return {"ok": True, "test_mode": True, "would_send_to": to, "subject": subject}
    from ..routes.inbox import _get_provider_config
    from ..services.email_providers import SendPayload, build_provider_from_config
    from ..models_crm import Message, MessageAddress
    from ..services import usage
    cfg = await _get_provider_config(db, org_id)
    business = await db.business_profiles.find_one({"org_id": org_id}) or {}
    from_email = cfg.from_email or "notifications@zanelvo.local"
    from_name = cfg.from_name or business.get("business_name") or "Team"
    provider = build_provider_from_config(cfg)
    usage.set_context(org_id=org_id, feature=f"workflow:{wf_id}")
    res = await provider.send(SendPayload(from_email=from_email, from_name=from_name, to=[to], subject=subject,
                                          text=body, html="<p>" + body.replace("\n", "<br/>") + "</p>",
                                          tags={"workflow_id": wf_id}))
    ok = bool(getattr(res, "ok", True))
    simulated = getattr(provider, "key", "simulated") == "simulated" or not provider.is_connected
    await db.messages.insert_one(Message(
        org_id=org_id, conversation_id=None, direction="outbound", channel="email",
        from_addr=MessageAddress(email=from_email, name=from_name), to_addrs=[MessageAddress(email=to)],
        subject=subject, body_text=body, sent_at=utc_now_iso(),
        delivery={"provider": getattr(provider, "key", "simulated"), "simulated": simulated,
                  "status": "sent" if ok else "failed", "workflow_id": wf_id}).to_mongo())
    return {"ok": ok, "provider": getattr(provider, "key", "simulated"), "simulated": simulated,
            "to": to, "error": None if ok else str(getattr(res, "error", "send failed"))}


async def _exec_node(db, wf: Dict[str, Any], run: Dict[str, Any], node: Dict[str, Any]) -> Dict[str, Any]:
    """Executes one node. Returns {"result":..., "next": node_id|None, "wait_until": iso|None, "pause": str|None}."""
    org_id = wf["org_id"]
    graph = wf["graph"]
    ctx = run["context"]
    cfg = node.get("config") or {}
    t = node.get("type")
    test = bool(run.get("test_mode"))
    wf_id = str(wf["_id"])
    if t in ("trigger", "end"):
        return {"result": {"ok": True}, "next": _next(graph, node["id"]) if t == "trigger" else None}
    if t == "condition":
        yes = _eval_condition(cfg, ctx)
        return {"result": {"ok": True, "branch": "yes" if yes else "no"}, "next": _next(graph, node["id"], "yes" if yes else "no")}
    if t == "ab_split":
        # Round 11 — deterministic ("sticky") per contact+node when a contact id/email exists, else random.
        import hashlib as _hl
        import random as _rnd
        pct = max(0.0, min(100.0, float(cfg.get("percent_a", 50) or 0)))
        key = (_get(ctx, "contact.id") or _get(ctx, "contact.email") or _get(ctx, "email") or "")
        if cfg.get("sticky", True) and key:
            bucket = int(_hl.sha256(f"{wf_id}:{node['id']}:{key}".encode()).hexdigest()[:8], 16) % 10000 / 100.0
        else:
            bucket = _rnd.random() * 100
        branch = "a" if bucket < pct else "b"
        if not test:
            await db.workflow_ab_stats.update_one({"workflow_id": wf_id, "node_id": node["id"]},
                                                  {"$inc": {f"count_{branch}": 1}, "$set": {"updated_at": utc_now_iso()},
                                                   "$setOnInsert": {"org_id": org_id, "created_at": utc_now_iso()}}, upsert=True)
        return {"result": {"ok": True, "branch": branch.upper(), "percent_a": pct}, "next": _next(graph, node["id"], branch)}
    if t == "delay":
        amt = float(cfg.get("amount") or 0)
        unit = cfg.get("unit") or "hours"
        secs = amt * {"minutes": 60, "hours": 3600, "days": 86400}.get(unit, 3600)
        if test:
            return {"result": {"ok": True, "test_mode": True, "would_wait_seconds": secs}, "next": _next(graph, node["id"])}
        return {"result": {"ok": True, "wait_seconds": secs}, "next": _next(graph, node["id"]),
                "wait_until": (datetime.now(timezone.utc) + timedelta(seconds=secs)).isoformat()}
    if t == "wait_until":
        hour = int(cfg.get("hour") or 9)
        now = datetime.now(timezone.utc)
        target = now.replace(hour=max(0, min(23, hour)), minute=0, second=0, microsecond=0)
        if target <= now:
            target += timedelta(days=1)
        if test:
            return {"result": {"ok": True, "test_mode": True, "would_wait_until": target.isoformat()}, "next": _next(graph, node["id"])}
        return {"result": {"ok": True}, "next": _next(graph, node["id"]), "wait_until": target.isoformat()}
    if t == "send_email":
        to = render(cfg.get("to") or "{{contact.email}}", ctx) or ctx.get("email") or ""
        r = await _send_email(db, org_id, to, render(cfg.get("subject") or "", ctx), render(cfg.get("body") or "", ctx), wf_id, test)
        if not r.get("ok"):
            raise RuntimeError(r.get("error") or "email failed")
        return {"result": r, "next": _next(graph, node["id"])}
    if t in ("add_tag", "remove_tag"):
        tag = render(cfg.get("tag") or "", ctx).strip()
        cid = ctx.get("contact_id")
        if tag and cid and not test:
            op = "$addToSet" if t == "add_tag" else "$pull"
            await db.contacts.update_one({"_id": ObjectId(cid), "org_id": org_id}, {op: {"tags": tag}})
        return {"result": {"ok": True, "tag": tag, "contact_id": cid, "test_mode": test}, "next": _next(graph, node["id"])}
    if t == "create_task":
        title = render(cfg.get("title") or "Follow up", ctx)
        if not test:
            await db.tasks.insert_one({"org_id": org_id, "title": title, "contact_id": ctx.get("contact_id"),
                                       "created_at": utc_now_iso(), "status": "open", "workflow_id": wf_id})
        return {"result": {"ok": True, "title": title, "test_mode": test}, "next": _next(graph, node["id"])}
    if t == "notify_owner":
        msg = render(cfg.get("message") or f"Workflow {wf.get('name')} ran", ctx)
        if not test:
            await db.notifications.insert_one({"org_id": org_id, "kind": "workflow", "title": wf.get("name"),
                                               "message": msg, "read": False, "created_at": utc_now_iso()})
        return {"result": {"ok": True, "message": msg, "test_mode": test}, "next": _next(graph, node["id"])}
    if t == "webhook":
        url = render(cfg.get("url") or "", ctx)
        if test:
            return {"result": {"ok": True, "test_mode": True, "would_call": url}, "next": _next(graph, node["id"])}
        from ..services import netsafe
        import httpx
        if not url or not await netsafe.url_is_safe(url, allow_http=False):
            raise RuntimeError("webhook url blocked or empty (https + public host required)")
        async with httpx.AsyncClient(timeout=10, follow_redirects=False) as client:
            resp = await client.request((cfg.get("method") or "POST").upper(), url,
                                        json={"workflow": wf.get("name"), "trigger": run.get("trigger"), "context": ctx})
        if resp.status_code >= 400:
            raise RuntimeError(f"webhook {resp.status_code}")
        return {"result": {"ok": True, "status": resp.status_code}, "next": _next(graph, node["id"])}
    if t == "ai_generate":
        cap = float((wf.get("settings") or {}).get("cost_cap_usd") or 0)
        if cap and await _ai_spend_this_month(db, wf_id) >= cap:
            return {"result": {"ok": True, "skipped": "workflow_cost_cap_reached"}, "next": _next(graph, node["id"])}
        if test:
            return {"result": {"ok": True, "test_mode": True, "would_prompt": render(cfg.get("prompt") or "", ctx)[:200]},
                    "next": _next(graph, node["id"])}
        from ..services.llm import generate_text
        from ..services import usage
        usage.set_context(org_id=org_id, feature=f"workflow:{wf_id}")
        text = await generate_text("You write short, honest business messages. No invented facts, prices or reviews.",
                                   render(cfg.get("prompt") or "", ctx), feature=f"workflow:{wf_id}")
        ctx[cfg.get("save_as") or "ai_text"] = text
        return {"result": {"ok": True, "chars": len(text)}, "next": _next(graph, node["id"])}
    if t == "approval":
        if test:
            return {"result": {"ok": True, "test_mode": True, "would_pause_for_approval": True}, "next": _next(graph, node["id"])}
        return {"result": {"ok": True, "awaiting_approval": True}, "next": _next(graph, node["id"]), "pause": "awaiting_approval"}
    raise RuntimeError(f"unknown node type {t}")


async def advance(run_id: Any) -> Dict[str, Any]:
    """Drive a run forward until it completes, waits, pauses, fails or dead-letters."""
    db = get_db()
    run = await db.workflow_runs.find_one({"_id": run_id})
    if not run or run.get("status") not in ("running", "waiting", "approved"):
        return run or {}
    wf = await db.workflows.find_one({"_id": ObjectId(run["workflow_id"])})
    if not wf:
        await db.workflow_runs.update_one({"_id": run_id}, {"$set": {"status": "failed", "error": "workflow deleted"}})
        return run
    graph = wf["graph"]
    nodes = {n["id"]: n for n in graph.get("nodes") or []}
    cursor = run.get("cursor")
    if run.get("status") == "approved":
        # resume after approval: cursor already points to the node AFTER the approval gate
        run["status"] = "running"
    steps = 0
    while cursor and steps < MAX_STEPS_PER_RUN:
        node = nodes.get(cursor)
        if not node:
            break
        steps += 1
        attempts = int(run.get("attempts") or 0)
        try:
            out = await _exec_node(db, wf, run, node)
        except Exception as exc:  # noqa: BLE001
            attempts += 1
            entry = {"node_id": cursor, "type": node.get("type"), "ok": False, "error": str(exc)[:300],
                     "attempt": attempts, "at": utc_now_iso()}
            if attempts >= MAX_ATTEMPTS:
                await db.workflow_runs.update_one({"_id": run_id}, {"$set": {
                    "status": "dead_letter", "error": str(exc)[:300], "attempts": attempts, "cursor": cursor,
                    "updated_at": utc_now_iso()}, "$push": {"steps": entry}})
                await db.workflows.update_one({"_id": wf["_id"]}, {"$inc": {"stats.dead_letter": 1}})
                return await db.workflow_runs.find_one({"_id": run_id})
            backoff = 60 * (2 ** (attempts - 1))
            await db.workflow_runs.update_one({"_id": run_id}, {"$set": {
                "status": "waiting", "attempts": attempts, "cursor": cursor,
                "next_at": (datetime.now(timezone.utc) + timedelta(seconds=backoff)).isoformat(),
                "updated_at": utc_now_iso()}, "$push": {"steps": entry}})
            return await db.workflow_runs.find_one({"_id": run_id})
        entry = {"node_id": cursor, "type": node.get("type"), "ok": True, "result": out.get("result"), "at": utc_now_iso()}
        nxt = out.get("next")
        upd: Dict[str, Any] = {"cursor": nxt, "attempts": 0, "context": run["context"], "updated_at": utc_now_iso()}
        if out.get("pause"):
            upd["status"] = out["pause"]
            await db.workflow_runs.update_one({"_id": run_id}, {"$set": upd, "$push": {"steps": entry}})
            return await db.workflow_runs.find_one({"_id": run_id})
        if out.get("wait_until"):
            upd.update({"status": "waiting", "next_at": out["wait_until"]})
            await db.workflow_runs.update_one({"_id": run_id}, {"$set": upd, "$push": {"steps": entry}})
            return await db.workflow_runs.find_one({"_id": run_id})
        await db.workflow_runs.update_one({"_id": run_id}, {"$set": upd, "$push": {"steps": entry}})
        cursor = nxt
    await db.workflow_runs.update_one({"_id": run_id}, {"$set": {
        "status": "completed", "cursor": None, "completed_at": utc_now_iso(), "updated_at": utc_now_iso()}})
    await db.workflows.update_one({"_id": wf["_id"]}, {"$inc": {"stats.completed": 1}})
    return await db.workflow_runs.find_one({"_id": run_id})


async def start_run(wf: Dict[str, Any], context: Dict[str, Any], *, test_mode: bool = False,
                    trigger: Optional[str] = None) -> Dict[str, Any]:
    db = get_db()
    org_id = wf["org_id"]
    ctx = dict(context or {})
    ctx["contact"] = await _load_contact(db, org_id, ctx)
    if not ctx.get("email") and ctx["contact"].get("email"):
        ctx["email"] = ctx["contact"]["email"]
    settings = wf.get("settings") or {}
    # per-day run cap
    cap = int(settings.get("max_runs_per_day") or 0)
    if cap and not test_mode:
        since = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
        n = await db.workflow_runs.count_documents({"workflow_id": str(wf["_id"]), "created_at": {"$gte": since}, "test_mode": {"$ne": True}})
        if n >= cap:
            return {"skipped": "max_runs_per_day"}
    trig_node = next((n for n in wf["graph"].get("nodes") or [] if n.get("type") == "trigger"), None)
    run = {"org_id": org_id, "workflow_id": str(wf["_id"]), "workflow_version": wf.get("version", 1),
           "trigger": trigger or wf.get("trigger"), "context": ctx, "status": "running",
           "cursor": trig_node["id"] if trig_node else None, "steps": [], "attempts": 0,
           "test_mode": test_mode, "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.workflow_runs.insert_one(run)
    await db.workflows.update_one({"_id": wf["_id"]}, {"$inc": {"stats.runs": 1}})
    return await advance(r.inserted_id)


async def fire(org_id: str, trigger: str, context: Dict[str, Any]) -> int:
    """Start every published workflow of this org listening to `trigger`."""
    db = get_db()
    n = 0
    async for wf in db.workflows.find({"org_id": org_id, "trigger": trigger, "status": "published"}):
        n += 1
        try:
            await start_run(wf, context, trigger=trigger)
        except Exception as exc:  # noqa: BLE001
            logger.warning("workflow %s failed to start: %s", wf.get("_id"), exc)
    return n


async def resume_due() -> int:
    db = get_db()
    now = utc_now_iso()
    n = 0
    due = await db.workflow_runs.find({"status": "waiting", "next_at": {"$lte": now}}, {"_id": 1}).to_list(100)
    for run in due:
        n += 1
        try:
            await db.workflow_runs.update_one({"_id": run["_id"]}, {"$set": {"status": "running"}, "$unset": {"next_at": ""}})
            await advance(run["_id"])
        except Exception as exc:  # noqa: BLE001
            logger.warning("workflow resume failed: %s", exc)
    return n


async def scheduler_loop(interval: int = 15) -> None:
    while True:
        try:
            await resume_due()
        except Exception as exc:  # noqa: BLE001
            logger.exception("workflow scheduler error: %s", exc)
        await asyncio.sleep(interval)


def _n(nid: str, t: str, cfg: Dict[str, Any], x: int, y: int) -> Dict[str, Any]:
    return {"id": nid, "type": t, "config": cfg, "position": {"x": x, "y": y}}


TEMPLATES: List[Dict[str, Any]] = [
    {"key": "welcome_lead", "name": "Welcome new leads", "trigger": "new_lead",
     "description": "Thank a new lead instantly, tag them, and create a follow-up task for you.",
     "graph": {"nodes": [_n("t", "trigger", {}, 0, 0),
                         _n("e1", "send_email", {"to": "{{contact.email}}", "subject": "Thanks for reaching out, {{contact.name}}",
                                                 "body": "Hi {{contact.name}},\n\nThanks for getting in touch — we'll reply within one business day.\n\nTalk soon."}, 0, 120),
                         _n("tag", "add_tag", {"tag": "lead"}, 0, 240),
                         _n("task", "create_task", {"title": "Call {{contact.name}}"}, 0, 360),
                         _n("end", "end", {}, 0, 480)],
               "edges": [{"from": "t", "to": "e1"}, {"from": "e1", "to": "tag"}, {"from": "tag", "to": "task"}, {"from": "task", "to": "end"}]}},
    {"key": "review_after_order", "name": "Ask for a review after an order", "trigger": "order_paid",
     "description": "Wait 3 days after payment, then ask happy customers for a review (skips anyone tagged 'no-marketing').",
     "graph": {"nodes": [_n("t", "trigger", {}, 0, 0),
                         _n("d", "delay", {"amount": 3, "unit": "days"}, 0, 120),
                         _n("c", "condition", {"field": "contact.tags", "op": "contains", "value": "no-marketing"}, 0, 240),
                         _n("e", "send_email", {"to": "{{email}}", "subject": "How did we do?",
                                                "body": "Hi {{contact.name}},\n\nThanks for your order. If you have a minute, we'd love a quick review."}, -160, 380),
                         _n("end", "end", {}, 160, 380)],
               "edges": [{"from": "t", "to": "d"}, {"from": "d", "to": "c"}, {"from": "c", "to": "end", "when": "yes"},
                         {"from": "c", "to": "e", "when": "no"}, {"from": "e", "to": "end"}]}},
    {"key": "quote_follow_up", "name": "Quote follow-up with approval", "trigger": "quote_sent",
     "description": "Two days after a quote goes out, AI drafts a friendly nudge that you approve before it sends.",
     "graph": {"nodes": [_n("t", "trigger", {}, 0, 0),
                         _n("d", "delay", {"amount": 2, "unit": "days"}, 0, 120),
                         _n("ai", "ai_generate", {"prompt": "Write a 3-sentence friendly follow-up to {{contact.name}} about the quote we sent. No prices.", "save_as": "ai_text"}, 0, 240),
                         _n("ap", "approval", {"note": "Review the AI draft before it is sent"}, 0, 360),
                         _n("e", "send_email", {"to": "{{contact.email}}", "subject": "Following up on your quote", "body": "{{ai_text}}"}, 0, 480),
                         _n("end", "end", {}, 0, 600)],
               "edges": [{"from": "t", "to": "d"}, {"from": "d", "to": "ai"}, {"from": "ai", "to": "ap"}, {"from": "ap", "to": "e"}, {"from": "e", "to": "end"}]}},
]
