import { useEffect, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { ShieldAlert, Globe, Fingerprint, Ban, Trash2 } from "lucide-react";

const KIND_LABEL = {
    disposable_email: "Disposable email",
    ip_velocity: "IP velocity",
    device_velocity: "Device velocity",
};

export default function StaffFraud() {
    const [data, setData] = useState(null);
    const [days, setDays] = useState(30);
    const [loading, setLoading] = useState(true);

    async function load(d = days) {
        setLoading(true);
        try { const res = await api.get(`/staff/fraud/overview?days=${d}`); setData(res.data); }
        catch (e) { toast.error(e?.response?.data?.detail || "Cannot load (needs audit permission)"); }
        finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    const t = data?.totals || { signals: 0, attempts: 0, by_kind: {} };

    return (
        <div className="p-6 max-w-6xl mx-auto space-y-6 text-brand-ink">
            <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                    <h1 className="text-2xl font-semibold flex items-center gap-2"><ShieldAlert className="w-6 h-6 text-amber-500" /> Abuse & fraud</h1>
                    <p className="text-zinc-500 text-sm mt-1">Signup fraud signals, high-volume IPs and repeat device fingerprints.</p>
                </div>
                <select value={days} onChange={(e) => { setDays(+e.target.value); load(+e.target.value); }} className="bg-white border border-brand-line rounded-md px-3 py-1.5 text-sm" data-testid="fraud-days">
                    {[7, 30, 90, 180].map((d) => <option key={d} value={d} >Last {d} days</option>)}
                </select>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Stat label="Fraud signals" value={t.signals} />
                <Stat label="Signup attempts" value={t.attempts} />
                <Stat label="Unique risky IPs" value={(data?.top_ips || []).length} />
                <Stat label="Repeat devices" value={(data?.repeat_devices || []).length} />
            </div>

            {loading && <div className="text-zinc-500">Loading…</div>}

            {!loading && (
                <div className="grid lg:grid-cols-2 gap-5">
                    <Panel title="Recent fraud signals" icon={<ShieldAlert className="w-4 h-4" />}>
                        {(data?.signals || []).length === 0 ? <Empty text="No fraud signals in this window — clean." /> : (
                            <div className="divide-y divide-brand-line">
                                {(data.signals).slice(0, 40).map((s, i) => (
                                    <div key={i} className="py-2 text-sm flex items-start justify-between gap-3" data-testid={`fraud-signal-${i}`}>
                                        <div>
                                            <span className="inline-block px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-xs mr-2">{KIND_LABEL[s.kind] || s.kind}</span>
                                            <span className="text-zinc-700">{s.email || "—"}</span>
                                            <div className="text-zinc-400 text-xs mt-0.5">{s.ip || "no ip"} · {s.detail || ""} {s.device_id ? `· dev ${String(s.device_id).slice(0, 8)}` : ""}</div>
                                        </div>
                                        <div className="text-zinc-400 text-xs whitespace-nowrap">{(s.created_at || "").slice(0, 10)}</div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </Panel>

                    <div className="space-y-5">
                        <Panel title="Top IPs by signups" icon={<Globe className="w-4 h-4" />}>
                            {(data?.top_ips || []).length === 0 ? <Empty text="No signup activity yet." /> : (
                                <div className="space-y-1">
                                    {data.top_ips.map((r, i) => (
                                        <div key={i} className="flex items-center justify-between text-sm">
                                            <span className="font-mono text-zinc-700">{r.ip}</span>
                                            <span className={`px-2 py-0.5 rounded text-xs ${r.count >= 5 ? "bg-red-100 text-red-700" : "bg-zinc-100 text-zinc-600"}`}>{r.count}</span>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </Panel>
                        <Panel title="Repeat device fingerprints" icon={<Fingerprint className="w-4 h-4" />}>
                            {(data?.repeat_devices || []).length === 0 ? <Empty text="No device reused across signups." /> : (
                                <div className="space-y-1">
                                    {data.repeat_devices.map((r, i) => (
                                        <div key={i} className="flex items-center justify-between text-sm">
                                            <span className="font-mono text-zinc-700">{String(r.device_id).slice(0, 14)}…</span>
                                            <span className={`px-2 py-0.5 rounded text-xs ${r.count >= 3 ? "bg-red-100 text-red-700" : "bg-zinc-100 text-zinc-600"}`}>{r.count} accounts</span>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </Panel>
                    </div>
                </div>
            )}

            <Blocklist />
        </div>
    );
}

function Stat({ label, value }) {
    return (
        <div className="rounded-xl bg-white border border-brand-line p-4">
            <div className="text-2xl font-semibold">{value ?? 0}</div>
            <div className="text-zinc-500 text-xs mt-1">{label}</div>
        </div>
    );
}
function Panel({ title, icon, children }) {
    return (
        <div className="rounded-2xl bg-white border border-brand-line p-5">
            <div className="text-sm font-medium mb-3 flex items-center gap-2 text-zinc-700">{icon} {title}</div>
            {children}
        </div>
    );
}
function Empty({ text }) { return <div className="text-zinc-400 text-sm py-4 text-center">{text}</div>; }

/** Round 11 — staff-managed blocklist (IP / email domain / exact email) enforced at signup. */
function Blocklist() {
    const [rows, setRows] = useState([]);
    const [form, setForm] = useState({ kind: "email_domain", value: "", reason: "" });
    const inp = "bg-white border border-brand-line rounded-md px-3 py-1.5 text-sm text-brand-ink placeholder:text-zinc-400 outline-none";
    const load = async () => { try { const { data } = await api.get("/staff/fraud/blocklist"); setRows(data.entries || []); } catch { /* perm */ } };
    useEffect(() => { load(); }, []);
    const add = async () => {
        try { await api.post("/staff/fraud/blocklist", form); toast.success("Blocked"); setForm({ ...form, value: "", reason: "" }); load(); }
        catch (e) { toast.error(e?.response?.data?.detail || "Could not add"); }
    };
    const del = async (id) => { try { await api.delete(`/staff/fraud/blocklist/${id}`); load(); } catch { toast.error("Could not remove"); } };
    return (
        <Panel title="Blocklist — signups refused" icon={<Ban className="w-4 h-4" />}>
            <div className="flex flex-wrap gap-2 mb-3" data-testid="fraud-blocklist-form">
                <select className={`${inp} `} value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })} data-testid="fraud-block-kind">
                    <option value="email_domain">Email domain</option><option value="email">Exact email</option><option value="ip">IP address</option>
                </select>
                <input className={`${inp} flex-1 min-w-[180px]`} placeholder={form.kind === "ip" ? "203.0.113.7" : form.kind === "email" ? "person@example.com" : "example.com"} value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} data-testid="fraud-block-value" />
                <input className={`${inp} flex-1 min-w-[160px]`} placeholder="Reason (internal)" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
                <button onClick={add} disabled={form.value.trim().length < 2} className="rounded-md px-3 py-1.5 text-sm bg-red-600 hover:bg-red-500 text-white disabled:opacity-50" data-testid="fraud-block-add">Block</button>
            </div>
            <div className="divide-y divide-brand-line" data-testid="fraud-blocklist">
                {rows.length === 0 && <div className="text-sm text-zinc-400 py-2">Nothing blocked. Disposable-email and velocity rules still apply automatically.</div>}
                {rows.map((r) => (
                    <div key={r.id} className="flex items-center gap-3 py-2 text-sm" data-testid={`fraud-block-${r.id}`}>
                        <span className="px-2 py-0.5 rounded bg-zinc-100 text-zinc-600 text-xs">{r.kind.replace("_", " ")}</span>
                        <span className="font-mono flex-1 truncate">{r.value}</span>
                        <span className="text-xs text-zinc-400 truncate max-w-[200px]">{r.reason}</span>
                        <span className="text-xs text-zinc-500">{r.hits} hits</span>
                        <button onClick={() => del(r.id)} className="text-zinc-400 hover:text-red-600" title="Remove"><Trash2 className="w-4 h-4" /></button>
                    </div>
                ))}
            </div>
        </Panel>
    );
}
