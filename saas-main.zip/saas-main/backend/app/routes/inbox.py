"""Inbox + Email workspace routes.

Unified inbox across email/chat/form channels. Supports:
- Conversation list + filters (status, channel, assignee, unread)
- Thread view + reply/send (uses per-org email provider adapter; simulated by default)
- Snooze / assign / label / status transitions
- Internal notes with @mentions
- Scheduled send (background poller releases them)
- Collision detection (presence heartbeat + reply-in-flight guard)
- AI copilot: summarize, classify, draft-reply, rewrite/translate
- Dev-only simulate-inbound endpoint so threading is testable end-to-end

Every route enforces org scoping via require_org; conversations/messages queried by (org_id, id).
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Literal, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User, BusinessProfile
from ..models_crm import (
    Conversation, MessageAddress, Message, ScheduledSend, Suppression,
    EmailSignature, EmailProviderConfig,
)
from ..services.email_providers import (
    SendPayload, build_provider_from_config, list_providers,
)
from ..services.inbox_ai import (
    summarize_conversation, classify_message, draft_reply, rewrite_message,
)
from ..services.entitlements import enforce_entitlement, check_metered
from .crm import upsert_contact_from_form, _record_interaction

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/inbox", tags=["inbox"])
email_router = APIRouter(prefix="/email", tags=["email"])


PRESENCE_TTL_SECONDS = 30


def _addr(d: Optional[Dict[str, Any]]) -> Optional[MessageAddress]:
    if not d:
        return None
    return MessageAddress(email=d.get("email") or "", name=d.get("name"))


async def _get_provider_config(db, org_id: str) -> EmailProviderConfig:
    doc = await db.email_provider_configs.find_one({"org_id": org_id})
    if doc:
        return EmailProviderConfig.from_mongo(doc)
    cfg = EmailProviderConfig(org_id=org_id, provider="simulated",
                                from_email=None, from_name=None)
    res = await db.email_provider_configs.insert_one(cfg.to_mongo())
    cfg.id = str(res.inserted_id)
    return cfg


async def _from_address_for(db, org_id: str, user: User, cfg: EmailProviderConfig) -> Dict[str, str]:
    if cfg.from_email:
        return {"email": cfg.from_email, "name": cfg.from_name or ""}
    business = await db.business_profiles.find_one({"org_id": org_id})
    biz_name = (business or {}).get("business_name") or "Team"
    return {"email": user.email, "name": biz_name}


async def _is_suppressed(db, org_id: str, email: str) -> Optional[Dict[str, Any]]:
    return await db.suppressions.find_one({"org_id": org_id, "email": email.lower()})


async def _touch_conversation(db, conv_id: str, org_id: str, *, preview: str,
                                 last_message_at: str, unread: Optional[bool] = None,
                                 first_owner_response_at: Optional[str] = None) -> None:
    setu: Dict[str, Any] = {"last_message_at": last_message_at,
                              "last_message_preview": preview[:160],
                              "updated_at": utc_now_iso()}
    if unread is not None:
        setu["unread"] = unread
    if first_owner_response_at is not None:
        setu["first_owner_response_at"] = first_owner_response_at
    await db.conversations.update_one({"_id": ObjectId(conv_id), "org_id": org_id},
                                        {"$set": setu})


# ---------------- Conversations ----------------

@router.get("/conversations")
async def list_conversations(status: Optional[str] = None, channel: Optional[str] = None,
                                 unread: Optional[bool] = None, assignee_user_id: Optional[str] = None,
                                 limit: int = 100,
                                 user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if status: q["status"] = status
    if channel: q["channel"] = channel
    if unread is not None: q["unread"] = unread
    if assignee_user_id: q["assignee_user_id"] = assignee_user_id
    cursor = db.conversations.find(q).sort("last_message_at", -1).limit(min(limit, 500))
    return {"conversations": [Conversation.from_mongo(d).model_dump() async for d in cursor]}


@router.get("/conversations/{conv_id}")
async def get_conversation(conv_id: str, user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.conversations.find_one({"_id": ObjectId(conv_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Conversation not found")
    conv = Conversation.from_mongo(doc)
    # Mark as read on open
    if conv.unread:
        await db.conversations.update_one({"_id": doc["_id"]}, {"$set": {"unread": False}})
        conv.unread = False
    msgs = []
    async for m in db.messages.find({"org_id": org_id, "conversation_id": conv_id}).sort("created_at", 1):
        msgs.append(Message.from_mongo(m).model_dump())
    scheduled = []
    async for s in db.scheduled_sends.find({"org_id": org_id, "conversation_id": conv_id,
                                                "status": "scheduled"}).sort("release_at", 1):
        scheduled.append(ScheduledSend.from_mongo(s).model_dump())
    return {"conversation": conv.model_dump(), "messages": msgs, "scheduled": scheduled}


class ConvPatch(BaseModel):
    model_config = {"extra": "forbid"}
    status: Optional[Literal["open", "snoozed", "closed"]] = None
    snooze_until: Optional[str] = None
    assignee_user_id: Optional[str] = None
    labels: Optional[List[str]] = None
    priority: Optional[Literal["low", "normal", "high", "urgent"]] = None
    unread: Optional[bool] = None


@router.patch("/conversations/{conv_id}")
async def patch_conversation(conv_id: str, req: ConvPatch,
                                user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    updates = {k: v for k, v in req.model_dump(exclude_none=True).items()}
    if not updates:
        raise HTTPException(400, "Nothing to update")
    updates["updated_at"] = utc_now_iso()
    res = await db.conversations.update_one({"_id": ObjectId(conv_id), "org_id": org_id},
                                              {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(404, "Conversation not found")
    fresh = await db.conversations.find_one({"_id": ObjectId(conv_id), "org_id": org_id})
    return Conversation.from_mongo(fresh).model_dump()


# ---------------- Send / Reply ----------------

class SendReq(BaseModel):
    conversation_id: Optional[str] = None  # if omitted, we create a new conversation
    contact_id: Optional[str] = None
    to: List[EmailStr]
    cc: List[EmailStr] = Field(default_factory=list)
    subject: str
    body_text: Optional[str] = None
    body_html: Optional[str] = None
    reply_to_message_id: Optional[str] = None
    schedule_at: Optional[str] = None  # if set, message is scheduled instead
    force: bool = False  # override collision guard


@router.post("/send")
async def send_or_schedule(req: SendReq, user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    db = get_db()
    cfg = await _get_provider_config(db, org_id)
    from_addr = await _from_address_for(db, org_id, user, cfg)

    # Suppression pre-check (any recipient suppressed → 409 with names)
    suppressed = []
    for addr in req.to + req.cc:
        s = await _is_suppressed(db, org_id, addr)
        if s:
            suppressed.append({"email": addr, "reason": s.get("reason")})
    if suppressed:
        raise HTTPException(409, {"error": "suppressed_recipients", "suppressed": suppressed})

    # Resolve / create conversation
    conv_id = req.conversation_id
    if not conv_id:
        conv = Conversation(org_id=org_id, channel="email", contact_id=req.contact_id,
                              subject=req.subject, status="open", unread=False,
                              assignee_user_id=user.id, last_message_at=utc_now_iso(),
                              last_message_preview=(req.body_text or "")[:160])
        r = await db.conversations.insert_one(conv.to_mongo())
        conv_id = str(r.inserted_id)
    else:
        cdoc = await db.conversations.find_one({"_id": ObjectId(conv_id), "org_id": org_id})
        if not cdoc:
            raise HTTPException(404, "Conversation not found")

    # Collision guard: if another user has an outbound reply in-flight in the last 60s, block.
    if not req.force:
        cutoff = (datetime.now(timezone.utc) - timedelta(seconds=60)).isoformat()
        recent = await db.messages.find_one({
            "org_id": org_id, "conversation_id": conv_id,
            "direction": "outbound", "sent_at": {"$gte": cutoff},
            "author_user_id": {"$ne": user.id},
        })
        if recent:
            raise HTTPException(409, {"error": "collision",
                                         "detail": "Another user just replied here — refresh, or resend with force=true."})

    # Schedule branch
    if req.schedule_at:
        # Entitlement gate at scheduling time as well — refuse creating a scheduled
        # send that couldn't be delivered anyway. Release-time check is enforced by
        # `_run_send_now`, so late-arriving over-cap is caught there too.
        await enforce_entitlement(org_id, "email_sends", increment=1)
        sched = ScheduledSend(org_id=org_id, conversation_id=conv_id, author_user_id=user.id,
                                release_at=req.schedule_at,
                                payload={"subject": req.subject, "body_text": req.body_text,
                                            "body_html": req.body_html,
                                            "to": req.to, "cc": req.cc,
                                            "reply_to_message_id": req.reply_to_message_id})
        r = await db.scheduled_sends.insert_one(sched.to_mongo())
        sched.id = str(r.inserted_id)
        return {"ok": True, "scheduled_send_id": sched.id, "release_at": req.schedule_at}

    # Immediate send
    await enforce_entitlement(org_id, "email_sends", increment=1)
    provider = build_provider_from_config(cfg)
    payload = SendPayload(
        from_email=from_addr["email"], from_name=from_addr["name"],
        to=[str(x) for x in req.to], cc=[str(x) for x in req.cc],
        subject=req.subject, html=req.body_html or "", text=req.body_text or "",
        reply_to=cfg.reply_to,
    )
    result = await provider.send(payload)
    if not result.ok:
        raise HTTPException(502, {"error": "send_failed", "detail": result.error, "hint": result.hint})

    msg = Message(
        org_id=org_id, conversation_id=conv_id, direction="outbound", channel="email",
        from_addr=MessageAddress(**from_addr),
        to_addrs=[MessageAddress(email=x) for x in req.to],
        cc_addrs=[MessageAddress(email=x) for x in req.cc],
        subject=req.subject, body_html=req.body_html, body_text=req.body_text,
        in_reply_to=req.reply_to_message_id, sent_at=utc_now_iso(),
        author_user_id=user.id,
        delivery={"provider": provider.key,
                    "provider_message_id": result.provider_message_id,
                    "simulated": bool(result.simulated),
                    "status": "delivered" if result.simulated else "sent"},
    )
    mr = await db.messages.insert_one(msg.to_mongo())
    msg.id = str(mr.inserted_id)

    # Touch conversation, record SLA metric for first response, add timeline
    cdoc = await db.conversations.find_one({"_id": ObjectId(conv_id), "org_id": org_id})
    first_response = None
    if cdoc and not cdoc.get("first_owner_response_at"):
        first_response = utc_now_iso()
    await _touch_conversation(db, conv_id, org_id,
                                 preview=(req.body_text or req.subject or "")[:160],
                                 last_message_at=utc_now_iso(), unread=False,
                                 first_owner_response_at=first_response)
    contact_id = (cdoc or {}).get("contact_id")
    await _record_interaction(db, org_id, contact_id=contact_id, type_="email_sent",
                                 summary=f"Sent: {req.subject}",
                                 ref_type="message", ref_id=msg.id, author_user_id=user.id,
                                 meta={"conversation_id": conv_id, "simulated": bool(result.simulated)})
    return {"ok": True, "message_id": msg.id, "conversation_id": conv_id,
             "simulated": bool(result.simulated),
             "provider_message_id": result.provider_message_id}


@router.get("/scheduled")
async def list_scheduled(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.scheduled_sends.find({"org_id": org_id, "status": "scheduled"}).sort("release_at", 1)
    return {"scheduled": [ScheduledSend.from_mongo(d).model_dump() async for d in cursor]}


@router.post("/scheduled/{sched_id}/cancel")
async def cancel_scheduled(sched_id: str, user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    db = get_db()
    res = await db.scheduled_sends.update_one(
        {"_id": ObjectId(sched_id), "org_id": org_id, "status": "scheduled"},
        {"$set": {"status": "canceled", "updated_at": utc_now_iso()}},
    )
    if res.matched_count == 0:
        raise HTTPException(404, "Scheduled send not found or already released")
    return {"ok": True}


# ---------------- Presence (collision) ----------------

class PresencePing(BaseModel):
    action: Literal["viewing", "typing"] = "viewing"


@router.post("/conversations/{conv_id}/presence")
async def presence_ping(conv_id: str, req: PresencePing,
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    expiry = (datetime.now(timezone.utc) + timedelta(seconds=PRESENCE_TTL_SECONDS)).isoformat()
    await db.conversations.update_one(
        {"_id": ObjectId(conv_id), "org_id": org_id},
        {"$set": {f"presence.{user.id}": expiry, "updated_at": utc_now_iso()}},
    )
    doc = await db.conversations.find_one({"_id": ObjectId(conv_id), "org_id": org_id},
                                             {"presence": 1})
    now = datetime.now(timezone.utc).isoformat()
    active = [uid for uid, exp in (doc.get("presence") or {}).items()
              if exp > now and uid != user.id]
    return {"ok": True, "others_viewing": active}


# ---------------- Simulate inbound (dev only) ----------------

class SimulateInboundReq(BaseModel):
    from_email: EmailStr
    from_name: Optional[str] = None
    subject: str
    body_text: str
    contact_id: Optional[str] = None  # optional; else auto-create/upsert


@router.post("/simulate-inbound")
async def simulate_inbound(req: SimulateInboundReq, user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    """Dev-only: simulate an inbound email so the reply/threading flow is fully testable."""
    db = get_db()
    # Upsert contact
    contact_id = req.contact_id
    if not contact_id:
        contact_id = await upsert_contact_from_form(
            db, org_id,
            {"email": str(req.from_email), "name": req.from_name or ""},
            source="inbound_email",
        )
    # Create conversation
    conv = Conversation(org_id=org_id, channel="email", contact_id=contact_id,
                          subject=req.subject, status="open", unread=True,
                          last_message_at=utc_now_iso(),
                          last_message_preview=req.body_text[:160])
    r = await db.conversations.insert_one(conv.to_mongo())
    conv_id = str(r.inserted_id)
    # Insert inbound message
    msg = Message(
        org_id=org_id, conversation_id=conv_id, direction="inbound", channel="email",
        from_addr=MessageAddress(email=str(req.from_email), name=req.from_name),
        subject=req.subject, body_text=req.body_text,
        sent_at=utc_now_iso(),
        delivery={"provider": "simulated_inbound", "simulated": True, "status": "received"},
    )
    mr = await db.messages.insert_one(msg.to_mongo())
    msg.id = str(mr.inserted_id)
    await _record_interaction(db, org_id, contact_id=contact_id, type_="email_received",
                                 summary=f"Received: {req.subject}",
                                 ref_type="message", ref_id=msg.id,
                                 meta={"conversation_id": conv_id, "simulated": True})
    return {"ok": True, "conversation_id": conv_id, "message_id": msg.id, "contact_id": contact_id}


# ---------------- AI copilot ----------------

@router.post("/conversations/{conv_id}/ai/summarize")
async def ai_summarize(conv_id: str, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    cdoc = await db.conversations.find_one({"_id": ObjectId(conv_id), "org_id": org_id})
    if not cdoc:
        raise HTTPException(404, "Conversation not found")
    msgs = [Message.from_mongo(m).model_dump()
            async for m in db.messages.find({"org_id": org_id, "conversation_id": conv_id}).sort("created_at", 1)]
    return await summarize_conversation(msgs)


@router.post("/messages/{msg_id}/ai/classify")
async def ai_classify(msg_id: str, user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    db = get_db()
    mdoc = await db.messages.find_one({"_id": ObjectId(msg_id), "org_id": org_id})
    if not mdoc:
        raise HTTPException(404, "Message not found")
    business = await db.business_profiles.find_one({"org_id": org_id})
    business_dict = BusinessProfile.from_mongo(business).model_dump() if business else None
    labels = await classify_message(Message.from_mongo(mdoc).model_dump(), business_dict)
    # persist on the message
    await db.messages.update_one({"_id": mdoc["_id"]},
                                    {"$set": {"ai_labels": labels, "updated_at": utc_now_iso()}})
    return labels


class DraftReplyReq(BaseModel):
    owner_hint: Optional[str] = None


@router.post("/conversations/{conv_id}/ai/draft-reply")
async def ai_draft(conv_id: str, req: DraftReplyReq,
                     user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cdoc = await db.conversations.find_one({"_id": ObjectId(conv_id), "org_id": org_id})
    if not cdoc:
        raise HTTPException(404, "Conversation not found")
    business = await db.business_profiles.find_one({"org_id": org_id})
    if not business:
        raise HTTPException(400, "No business profile — the AI draft needs it to stay grounded.")
    business_dict = BusinessProfile.from_mongo(business).model_dump()
    msgs = [Message.from_mongo(m).model_dump()
            async for m in db.messages.find({"org_id": org_id, "conversation_id": conv_id}).sort("created_at", 1)]
    return await draft_reply(msgs, business_dict, req.owner_hint)


class RewriteReq(BaseModel):
    text: str
    action: str  # 'shorter' | 'longer' | 'warmer' | 'firmer' | 'translate:<lang>'


@router.post("/ai/rewrite")
async def ai_rewrite(req: RewriteReq, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    return {"text": await rewrite_message(req.text, req.action)}


# ================ EMAIL SETTINGS ================

@email_router.get("/providers")
async def email_providers(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"providers": list_providers()}


@email_router.get("/config")
async def get_config(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cfg = await _get_provider_config(db, org_id)
    d = cfg.model_dump()
    # Never leak the api key / smtp password to the client — return "set" indicators only
    d["resend_api_key_set"] = bool(d.pop("resend_api_key", None))
    d["smtp_password_set"] = bool(d.pop("smtp_password", None))
    return d


class ConfigPatch(BaseModel):
    model_config = {"extra": "forbid"}
    provider: Optional[Literal["simulated", "resend", "smtp"]] = None
    from_email: Optional[str] = None
    from_name: Optional[str] = None
    reply_to: Optional[str] = None
    resend_api_key: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_use_tls: Optional[bool] = None


@email_router.patch("/config")
async def patch_config(req: ConfigPatch, user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    db = get_db()
    cfg = await _get_provider_config(db, org_id)
    updates = {k: v for k, v in req.model_dump(exclude_none=True).items()}
    updates["updated_at"] = utc_now_iso()
    await db.email_provider_configs.update_one({"_id": ObjectId(cfg.id)}, {"$set": updates})
    return {"ok": True}


class TestSendReq(BaseModel):
    to: EmailStr
    subject: str = "Zanelvo test message"
    body_text: str = "This is a test send from Zanelvo. If you see this, delivery works."


@email_router.post("/test-send")
async def test_send(req: TestSendReq, user: User = Depends(current_user),
                      org_id: str = Depends(require_org)):
    db = get_db()
    cfg = await _get_provider_config(db, org_id)
    from_addr = await _from_address_for(db, org_id, user, cfg)
    provider = build_provider_from_config(cfg)
    payload = SendPayload(from_email=from_addr["email"], from_name=from_addr["name"],
                             to=[str(req.to)], subject=req.subject, text=req.body_text)
    result = await provider.send(payload)
    outcome = {"ok": result.ok, "provider": provider.key,
                 "simulated": bool(result.simulated),
                 "message": result.error or "Test send completed",
                 "provider_message_id": result.provider_message_id,
                 "hint": result.hint}
    await db.email_provider_configs.update_one(
        {"_id": ObjectId(cfg.id)},
        {"$set": {"last_test_at": utc_now_iso(), "last_test_result": outcome,
                    "updated_at": utc_now_iso()}},
    )
    return outcome


# Suppressions

class SuppressionCreate(BaseModel):
    email: EmailStr
    reason: Literal["bounce", "complaint", "unsubscribe", "manual"] = "manual"


@email_router.post("/suppressions")
async def add_suppression(req: SuppressionCreate, user: User = Depends(current_user),
                            org_id: str = Depends(require_org)):
    db = get_db()
    s = Suppression(org_id=org_id, email=str(req.email).lower(), reason=req.reason)
    await db.suppressions.update_one(
        {"org_id": org_id, "email": s.email},
        {"$set": s.to_mongo()},
        upsert=True,
    )
    return {"ok": True}


@email_router.get("/suppressions")
async def list_suppressions(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.suppressions.find({"org_id": org_id}).sort("created_at", -1)
    return {"suppressions": [Suppression.from_mongo(d).model_dump() async for d in cursor]}


@email_router.delete("/suppressions/{email}")
async def delete_suppression(email: str, user: User = Depends(current_user),
                                org_id: str = Depends(require_org)):
    db = get_db()
    res = await db.suppressions.delete_one({"org_id": org_id, "email": email.lower()})
    if res.deleted_count == 0:
        raise HTTPException(404, "Suppression not found")
    return {"ok": True}


# Signatures

class SignatureUpsert(BaseModel):
    name: str = "Default"
    html: str = ""
    is_default: bool = True


@email_router.get("/signatures")
async def list_signatures(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.email_signatures.find({"org_id": org_id, "user_id": user.id})
    return {"signatures": [EmailSignature.from_mongo(d).model_dump() async for d in cursor]}


@email_router.post("/signatures")
async def upsert_signature(req: SignatureUpsert, user: User = Depends(current_user),
                             org_id: str = Depends(require_org)):
    db = get_db()
    sig = EmailSignature(org_id=org_id, user_id=user.id, **req.model_dump())
    if req.is_default:
        await db.email_signatures.update_many(
            {"org_id": org_id, "user_id": user.id},
            {"$set": {"is_default": False}},
        )
    await db.email_signatures.update_one(
        {"org_id": org_id, "user_id": user.id, "name": req.name},
        {"$set": sig.to_mongo()},
        upsert=True,
    )
    return {"ok": True}


# ================ Scheduled send background poller ================

_poller_task: Optional[asyncio.Task] = None


async def scheduled_send_loop():
    """Every 5 seconds, release any scheduled sends whose release_at is in the past."""
    from ..db import get_db as _get_db
    while True:
        try:
            db = _get_db()
            now = utc_now_iso()
            async for doc in db.scheduled_sends.find({"status": "scheduled",
                                                          "release_at": {"$lte": now}}):
                await _release_scheduled(db, doc)
        except Exception as e:  # noqa: BLE001
            logger.exception("scheduled_send_loop error: %s", e)
        await asyncio.sleep(5)


async def _release_scheduled(db, doc: Dict[str, Any]) -> None:
    org_id = doc.get("org_id")
    payload = doc.get("payload") or {}
    cfg = await _get_provider_config(db, org_id)
    author_user = await db.users.find_one({"_id": ObjectId(doc["author_user_id"])})
    from_addr = (
        {"email": cfg.from_email, "name": cfg.from_name or ""}
        if cfg.from_email
        else {"email": (author_user or {}).get("email") or "noreply@zanelvo.local", "name": ""}
    )
    # Suppression check at release-time
    for addr in list(payload.get("to") or []) + list(payload.get("cc") or []):
        if await _is_suppressed(db, org_id, addr):
            await db.scheduled_sends.update_one(
                {"_id": doc["_id"]},
                {"$set": {"status": "failed", "error": f"recipient suppressed: {addr}",
                            "updated_at": utc_now_iso()}},
            )
            return
    # Entitlement gate at release-time — an org may have hit its cap between schedule and release.
    if not await check_metered(org_id, "email_sends"):
        await db.scheduled_sends.update_one(
            {"_id": doc["_id"]},
            {"$set": {"status": "failed",
                        "error": "plan_limit_reached: email_sends over cap at release",
                        "updated_at": utc_now_iso()}},
        )
        return
    provider = build_provider_from_config(cfg)
    send_payload = SendPayload(
        from_email=from_addr["email"], from_name=from_addr["name"],
        to=list(payload.get("to") or []), cc=list(payload.get("cc") or []),
        subject=payload.get("subject") or "", html=payload.get("body_html") or "",
        text=payload.get("body_text") or "", reply_to=cfg.reply_to,
    )
    result = await provider.send(send_payload)
    if not result.ok:
        await db.scheduled_sends.update_one(
            {"_id": doc["_id"]},
            {"$set": {"status": "failed", "error": result.error, "updated_at": utc_now_iso()}},
        )
        return
    msg = Message(
        org_id=org_id, conversation_id=doc["conversation_id"], direction="outbound", channel="email",
        from_addr=MessageAddress(**from_addr),
        to_addrs=[MessageAddress(email=x) for x in (payload.get("to") or [])],
        cc_addrs=[MessageAddress(email=x) for x in (payload.get("cc") or [])],
        subject=send_payload.subject, body_html=send_payload.html, body_text=send_payload.text,
        in_reply_to=payload.get("reply_to_message_id"),
        sent_at=utc_now_iso(), author_user_id=doc["author_user_id"],
        delivery={"provider": provider.key, "provider_message_id": result.provider_message_id,
                    "simulated": bool(result.simulated), "status": "delivered" if result.simulated else "sent",
                    "scheduled_send_id": str(doc["_id"])},
    )
    mr = await db.messages.insert_one(msg.to_mongo())
    await db.scheduled_sends.update_one(
        {"_id": doc["_id"]},
        {"$set": {"status": "sent", "sent_message_id": str(mr.inserted_id),
                    "updated_at": utc_now_iso()}},
    )
    await _touch_conversation(db, doc["conversation_id"], org_id,
                                 preview=(send_payload.text or send_payload.subject)[:160],
                                 last_message_at=utc_now_iso(), unread=False)
    cdoc = await db.conversations.find_one({"_id": ObjectId(doc["conversation_id"]), "org_id": org_id})
    await _record_interaction(db, org_id, contact_id=(cdoc or {}).get("contact_id"),
                                 type_="email_sent",
                                 summary=f"Sent (scheduled): {send_payload.subject}",
                                 ref_type="message", ref_id=str(mr.inserted_id),
                                 author_user_id=doc["author_user_id"],
                                 meta={"conversation_id": doc["conversation_id"], "scheduled": True,
                                         "simulated": bool(result.simulated)})


def start_scheduled_send_loop():
    """Called from server startup — kicks off the background loop."""
    global _poller_task
    if _poller_task and not _poller_task.done():
        return
    _poller_task = asyncio.create_task(scheduled_send_loop())
