"""Central cost & usage service — the ONE gate for everything that costs money.

Every paid or variable-cost operation (LLM text/JSON/image, email, SMS/WhatsApp, voice
minutes, phone numbers, translation, shipping-rate/label calls, ad-platform calls…)
must go through this module:

    1. `enforce_budget()`      — pause-all switch, provider kill switches, founder global cap,
                                 org plan cap, per-user cap, per-feature cap. Raises 402/503.
    2. `reserve()`             — atomic pre-call reservation (counts against the org budget while
                                 the call is in flight; auto-expires) + idempotency lookup.
    3. `settle()` / `release()`— reconcile the reservation with the real outcome or free it.
    4. `record_usage()`        — one ledger row in `usage_events` (aka `llm_usage_events` — the
                                 collection name is kept for backwards compatibility).

The ledger stores organisation, user, feature, operation, provider, model, request id,
idempotency key, token counts, image count, units (chars / seconds / messages), retry count,
cache hit, estimated + actual cost, currency, latency, status, error, timestamp and billing
period. It NEVER stores prompts, secrets or personal data.

`services/llm.py` wraps every LLM call with this module, `services/email_providers.py` meters
every email send, so tracking is automatic; feature code only needs to set the request context
(`set_context(org_id=…, feature=…)`), which `deps.current_user` already does for signed-in
requests and the public widget does for tenant-scoped visitor flows.
"""
from __future__ import annotations

import contextvars
import logging
import math
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from fastapi import HTTPException

from ..db import get_db, utc_now_iso

logger = logging.getLogger(__name__)

LEDGER = "llm_usage_events"          # universal usage ledger (name kept for compatibility)
RESERVATIONS = "usage_reservations"
CONTROLS_AUDIT = "usage_controls_audit"
RESERVATION_TTL_S = 300

# Which metered `kind`s roll up to which hard cap (Round 15 closed-beta cost model).
#   • AI hard cap                 — direct LLM serving cost only.
#   • Total variable-provider cap — every margin-consuming provider cost EXCEPT the
#     pass-through/prepaid items, which are billed straight to the tenant and must never
#     silently consume plan margin (voice minutes, phone numbers, SMS/WhatsApp, ad spend,
#     shipping labels, domain registration, payment-processing fees).
AI_KINDS = frozenset({"text", "json", "image"})
PASSTHROUGH_KINDS = frozenset({
    "sms", "whatsapp", "voice_second", "shipping_label",
    "phone_number_month", "ad_spend_usd", "domain_registration", "payment_fee",
})


def _kind_match(scope: str) -> Dict[str, Any]:
    """Mongo match fragment selecting the ledger/reservation rows that count toward a cap."""
    if scope == "ai":
        return {"kind": {"$in": list(AI_KINDS)}}
    # "variable" = every metered kind that is NOT pass-through/prepaid.
    return {"kind": {"$nin": list(PASSTHROUGH_KINDS)}}

# ---------------------------------------------------------------------------
# Request-scoped context (org_id / user_id / feature)
# ---------------------------------------------------------------------------
_ctx: contextvars.ContextVar[Dict[str, Any]] = contextvars.ContextVar("usage_ctx", default={})


def set_context(**kwargs: Any) -> None:
    """Merge values into the current usage context (org_id, user_id, feature, request_id)."""
    cur = dict(_ctx.get() or {})
    for k, v in kwargs.items():
        if v is not None:
            cur[k] = v
    _ctx.set(cur)


def reset_context(feature: Optional[str] = None) -> None:
    _ctx.set({"feature": feature} if feature else {})


def get_context() -> Dict[str, Any]:
    return dict(_ctx.get() or {})


# ---------------------------------------------------------------------------
# Cost model (USD). Founder can override via platform_settings key "llm_cost_rates".
# ---------------------------------------------------------------------------
COST_RATES: Dict[str, Dict[str, float]] = {
    # provider/model : {in_per_1k, out_per_1k}
    "anthropic/claude-sonnet-4-6": {"in_per_1k": 0.003, "out_per_1k": 0.015},
    "anthropic/claude-sonnet-4": {"in_per_1k": 0.003, "out_per_1k": 0.015},
    "anthropic/claude-3-5-sonnet": {"in_per_1k": 0.003, "out_per_1k": 0.015},
    "openai/gpt-4o": {"in_per_1k": 0.005, "out_per_1k": 0.015},
    "openai/gpt-4o-mini": {"in_per_1k": 0.00015, "out_per_1k": 0.0006},
    "gemini/gemini-2.5-pro": {"in_per_1k": 0.00125, "out_per_1k": 0.005},
    "gemini/gemini-2.5-flash": {"in_per_1k": 0.0003, "out_per_1k": 0.0025},
    # image models: flat per-image cost
    "gemini/gemini-3.1-flash-image-preview": {"per_image": 0.039},
    "openai/gpt-image-1": {"per_image": 0.04},
    # non-LLM unit rates (per unit)
    "unit/email": {"per_unit": 0.0009},
    "unit/sms": {"per_unit": 0.0079},
    "unit/whatsapp": {"per_unit": 0.005},
    "unit/voice_second": {"per_unit": 0.013 / 60},
    "unit/translation_char": {"per_unit": 0.00002},
    "unit/embedding_1k": {"per_unit": 0.0001},
    "unit/shipping_rate": {"per_unit": 0.0},
    "unit/shipping_label": {"per_unit": 0.05},
    "unit/phone_number_month": {"per_unit": 1.15},
    "unit/ad_api_call": {"per_unit": 0.0},
    "unit/ad_spend_usd": {"per_unit": 1.0},
}
_DEFAULT_TEXT_RATE = {"in_per_1k": 0.003, "out_per_1k": 0.015}
_DEFAULT_IMAGE_RATE = {"per_image": 0.04}

_rate_cache: Dict[str, Any] = {"rates": None, "ts": 0.0}


async def _rates() -> Dict[str, Dict[str, float]]:
    """Merge founder overrides (platform_settings.llm_cost_rates) over defaults."""
    now = time.time()
    if _rate_cache["rates"] is not None and now - _rate_cache["ts"] < 60:
        return _rate_cache["rates"]
    merged = {k: dict(v) for k, v in COST_RATES.items()}
    try:
        from .platform_settings import SETTINGS_KEY as _SK

        settings = await get_db().platform_settings.find_one({"key": _SK}, {"llm_cost_rates": 1})
        override = (settings or {}).get("llm_cost_rates")
        if isinstance(override, dict):
            for k, v in override.items():
                if isinstance(v, dict):
                    merged.setdefault(k, {}).update(v)
    except Exception:  # noqa: BLE001
        pass
    _rate_cache["rates"] = merged
    _rate_cache["ts"] = now
    return merged


def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token (English)."""
    if not text:
        return 0
    return max(1, math.ceil(len(text) / 4))


def _month_key(dt: Optional[datetime] = None) -> str:
    dt = dt or datetime.now(timezone.utc)
    return dt.strftime("%Y-%m")


async def estimate_cost(*, kind: str, provider: str, model: str, input_text: str = "",
                        expected_output_tokens: int = 600, images: int = 1, units: float = 0) -> float:
    """Pre-call cost estimate used for reservations."""
    rates = await _rates()
    key = f"{provider}/{model}"
    if kind == "image":
        r = rates.get(key) or _DEFAULT_IMAGE_RATE
        return round(float(r.get("per_image", 0.04)) * max(1, images), 6)
    if kind in ("text", "json"):
        r = rates.get(key) or _DEFAULT_TEXT_RATE
        return round((estimate_tokens(input_text) / 1000.0) * float(r.get("in_per_1k", 0.003))
                     + (expected_output_tokens / 1000.0) * float(r.get("out_per_1k", 0.015)), 6)
    r = rates.get(f"unit/{kind}") or {"per_unit": 0.0}
    return round(float(r.get("per_unit", 0.0)) * max(0.0, float(units or 0)), 6)


# ---------------------------------------------------------------------------
# Founder controls: pause-all, provider kill switches, global budget, caps
# ---------------------------------------------------------------------------
DEFAULT_CONTROLS: Dict[str, Any] = {
    "pause_all": False,                 # emergency stop for every paid operation
    "provider_kill": {},                # {"anthropic": true, "openai": false, "gemini": false, "email": false, ...}
    "global_monthly_budget_usd": 0.0,   # 0 = no founder cap
    "warn_pct": 80,                     # warning threshold (org + global)
    "per_user_share_pct": 70,           # a single user may consume at most this % of the org budget
    "feature_caps_usd": {},             # {"logo_generation": 2.0} per-org monthly caps by feature
    "public_visitor_daily_cap_usd": 0.0,  # per-org cap for public (visitor-triggered) flows, 0 = plan-only
}
_controls_cache: Dict[str, Any] = {"v": None, "ts": 0.0}


async def get_controls(force: bool = False) -> Dict[str, Any]:
    now = time.time()
    if not force and _controls_cache["v"] is not None and now - _controls_cache["ts"] < 15:
        return _controls_cache["v"]
    merged = dict(DEFAULT_CONTROLS)
    try:
        from .platform_settings import SETTINGS_KEY as _SK

        doc = await get_db().platform_settings.find_one({"key": _SK}, {"usage_controls": 1})
        saved = (doc or {}).get("usage_controls")
        if isinstance(saved, dict):
            merged.update({k: v for k, v in saved.items() if k in DEFAULT_CONTROLS})
    except Exception:  # noqa: BLE001
        pass
    _controls_cache["v"] = merged
    _controls_cache["ts"] = now
    return merged


async def set_controls(patch: Dict[str, Any], actor: Optional[str] = None) -> Dict[str, Any]:
    """Founder-only. Validates, persists to platform_settings, writes an audit row."""
    cur = await get_controls(force=True)
    new = dict(cur)
    for k, v in (patch or {}).items():
        if k not in DEFAULT_CONTROLS:
            continue
        if k in ("pause_all",):
            new[k] = bool(v)
        elif k in ("global_monthly_budget_usd", "public_visitor_daily_cap_usd"):
            new[k] = max(0.0, float(v or 0))
        elif k in ("warn_pct", "per_user_share_pct"):
            new[k] = int(min(100, max(1, int(v or 1))))
        elif k in ("provider_kill",) and isinstance(v, dict):
            new[k] = {str(pk): bool(pv) for pk, pv in v.items()}
        elif k in ("feature_caps_usd",) and isinstance(v, dict):
            new[k] = {str(fk): max(0.0, float(fv or 0)) for fk, fv in v.items()}
    # Persist directly (platform_settings.update_settings only accepts its own editable keys).
    from .platform_settings import SETTINGS_KEY as _SK
    await get_db().platform_settings.update_one({"key": _SK}, {"$set": {"usage_controls": new,
                                                                        "updated_at": utc_now_iso()}}, upsert=True)
    _controls_cache["v"] = new
    _controls_cache["ts"] = time.time()
    try:
        await get_db()[CONTROLS_AUDIT].insert_one({
            "id": str(uuid.uuid4()), "actor": actor, "before": cur, "after": new,
            "created_at": utc_now_iso(),
        })
    except Exception:  # noqa: BLE001
        pass
    return new


# ---------------------------------------------------------------------------
# Aggregates used by enforcement
# ---------------------------------------------------------------------------
async def _sum_cost(match: Dict[str, Any]) -> float:
    db = get_db()
    async for row in db[LEDGER].aggregate([{"$match": match},
                                           {"$group": {"_id": None, "cost": {"$sum": "$cost_usd"}}}]):
        return round(float(row.get("cost") or 0.0), 6)
    return 0.0


async def _held_reservations(match: Dict[str, Any]) -> float:
    db = get_db()
    match = {**match, "status": "held", "expires_at": {"$gt": utc_now_iso()}}
    async for row in db[RESERVATIONS].aggregate([{"$match": match},
                                                 {"$group": {"_id": None, "c": {"$sum": "$est_cost_usd"}}}]):
        return round(float(row.get("c") or 0.0), 6)
    return 0.0


async def month_cost_for_org(org_id: str, month: Optional[str] = None, include_held: bool = False) -> float:
    if not org_id:
        return 0.0
    month = month or _month_key()
    total = await _sum_cost({"org_id": org_id, "month": month})
    if include_held:
        await expire_stale_reservations()   # crash-safety: holds older than TTL never block a tenant
        total += await _held_reservations({"org_id": org_id, "month": month})
    return round(total, 6)


async def _month_cost_scoped(org_id: str, month: str, scope: str, include_held: bool = False) -> float:
    """Month-to-date spend for an org restricted to a cap scope ('ai' or 'variable')."""
    if not org_id:
        return 0.0
    kf = _kind_match(scope)
    total = await _sum_cost({"org_id": org_id, "month": month, **kf})
    if include_held:
        await expire_stale_reservations()
        total += await _held_reservations({"org_id": org_id, "month": month, **kf})
    return round(total, 6)


async def _held_through_scoped(reservation: Dict[str, Any], scope: str) -> float:
    """FIFO cumulative held cost (by (created_at, id)) up to AND INCLUDING this reservation,
    restricted to a cap scope. Used for the race-safe atomic confirmation."""
    db = get_db()
    month = reservation.get("month") or _month_key()
    q = {"org_id": reservation.get("org_id"), "month": month, "status": "held",
         "expires_at": {"$gt": utc_now_iso()}, **_kind_match(scope),
         "$or": [
             {"created_at": {"$lt": reservation["created_at"]}},
             {"created_at": reservation["created_at"], "id": {"$lte": reservation["id"]}},
         ]}
    total = 0.0
    async for row in db[RESERVATIONS].aggregate([{"$match": q},
                                                 {"$group": {"_id": None, "c": {"$sum": "$est_cost_usd"}}}]):
        total = float(row.get("c") or 0.0)
    return round(total, 6)


async def month_cost_global(month: Optional[str] = None) -> float:
    month = month or _month_key()
    return await _sum_cost({"month": month})


# --- Owner-set hard monthly AI spend cap (owner controls their own spend) ---------------
ORG_AI_SETTINGS = "org_ai_settings"   # {org_id, monthly_cap_usd, updated_at}


async def owner_ai_cap(org_id: Optional[str]) -> float:
    """The owner's self-imposed hard monthly AI $ limit (0 = no owner cap)."""
    if not org_id:
        return 0.0
    doc = await get_db()[ORG_AI_SETTINGS].find_one({"org_id": org_id}, {"_id": 0, "monthly_cap_usd": 1})
    try:
        return max(0.0, float((doc or {}).get("monthly_cap_usd") or 0))
    except (TypeError, ValueError):
        return 0.0


async def set_owner_ai_cap(org_id: str, cap_usd: Optional[float]) -> Dict[str, Any]:
    """Set (or clear with 0) the owner's hard monthly AI cap."""
    try:
        cap = max(0.0, round(float(cap_usd or 0), 2))
    except (TypeError, ValueError):
        cap = 0.0
    await get_db()[ORG_AI_SETTINGS].update_one(
        {"org_id": org_id},
        {"$set": {"org_id": org_id, "monthly_cap_usd": cap, "updated_at": utc_now_iso()},
         "$unset": {"cap_alert_80_month": "", "cap_alert_100_month": ""}},
        upsert=True,
    )
    return {"monthly_cap_usd": cap}


def _402(error: str, **extra: Any) -> HTTPException:
    return HTTPException(status_code=402, detail={"error": error, "upgrade_url": "/app/billing", **extra})


async def enforce_budget(org_id: Optional[str], *, provider: Optional[str] = None,
                         feature: Optional[str] = None, user_id: Optional[str] = None,
                         est_cost: float = 0.0, public: bool = False, kind: str = "text") -> None:
    """Gate a paid operation. Order: pause-all → provider kill → global cap → org AI cap →
    org variable-provider cap → user cap → feature cap → public visitor cap.

    `kind` decides which plan caps apply (AI kinds hit the AI cap; every non-pass-through kind
    hits the variable-provider cap). Raises 503 (paused / provider disabled / metering down) or
    402 (budget). No org means a platform-level (staff) op: only pause/kill/global checks apply.
    """
    controls = await get_controls()
    if controls.get("pause_all"):
        raise HTTPException(503, detail={"error": "usage_paused",
                                         "message": "Paid operations are temporarily paused by the platform."})
    if provider and (controls.get("provider_kill") or {}).get(provider):
        raise HTTPException(503, detail={"error": "provider_disabled", "provider": provider,
                                         "message": f"The {provider} provider is currently disabled."})
    gcap = float(controls.get("global_monthly_budget_usd") or 0)
    if gcap > 0:
        gused = await month_cost_global()
        if gused + est_cost >= gcap:
            logger.error("GLOBAL usage budget reached: %.2f / %.2f", gused, gcap)
            raise HTTPException(503, detail={"error": "platform_budget_reached",
                                             "message": "Platform-wide monthly budget reached. Try again later."})
    if not org_id:
        return
    from .entitlements import ai_budget_usd, variable_provider_cap_usd, get_org_plan, _next_plan

    plan = await get_org_plan(org_id)
    month = _month_key()
    is_ai = kind in AI_KINDS
    passthrough = kind in PASSTHROUGH_KINDS
    budget = ai_budget_usd(plan) if is_ai else 0.0
    owner_cap = await owner_ai_cap(org_id) if is_ai else 0.0
    # --- AI hard cap (AI-scoped serving cost only) ---
    if is_ai and (budget > 0 or owner_cap > 0):
        used = await _month_cost_scoped(org_id, month, "ai", include_held=True)
        if budget > 0 and used + est_cost > budget:
            raise _402("ai_budget_reached", feature="ai_credits", plan_code=plan,
                       used_usd=round(used, 4), budget_usd=budget, suggest_plan=_next_plan(plan),
                       message=(f"You've used your monthly AI allowance on the {plan.title()} plan "
                                f"(${used:.2f}/${budget:.2f}). Upgrade to {_next_plan(plan).title()} for more."))
        if owner_cap > 0 and used + est_cost > owner_cap:
            raise _402("owner_ai_cap_reached", feature="ai_credits", used_usd=round(used, 4),
                       budget_usd=owner_cap, owner_cap=True,
                       message=(f"You've reached the monthly AI spend limit you set "
                                f"(${used:.2f}/${owner_cap:.2f}). Raise or remove it in Billing → AI usage to continue."))
    # --- Total variable-provider hard cap (every margin-consuming provider cost) ---
    if not passthrough:
        var_cap = variable_provider_cap_usd(plan)
        if var_cap > 0:
            vused = await _month_cost_scoped(org_id, month, "variable", include_held=True)
            if vused + est_cost > var_cap:
                raise _402("variable_provider_cap_reached", feature="variable_providers", plan_code=plan,
                           used_usd=round(vused, 4), budget_usd=var_cap, suggest_plan=_next_plan(plan),
                           message=(f"Your {plan.title()} plan's monthly usage allowance is exhausted "
                                    f"(${vused:.2f}/${var_cap:.2f}). Upgrade to {_next_plan(plan).title()} "
                                    f"or top up to continue."))
    # per-user share (only meaningful when a plan AI budget exists & multi-seat; never blocks the sole user)
    share = int(controls.get("per_user_share_pct") or 100)
    if budget > 0 and user_id and share < 100 and not public:
        seats = await get_db().users.count_documents({"org_id": org_id})
        if seats > 1:
            uused = await _sum_cost({"org_id": org_id, "user_id": user_id, "month": _month_key()})
            if uused + est_cost > budget * share / 100.0:
                raise _402("user_ai_budget_reached", plan_code=plan, used_usd=round(uused, 4),
                           budget_usd=round(budget * share / 100.0, 2),
                           message="You've reached your personal share of the team's monthly AI allowance.")
    # per-feature cap
    caps = controls.get("feature_caps_usd") or {}
    if feature and caps.get(feature):
        fused = await _sum_cost({"org_id": org_id, "feature": feature, "month": _month_key()})
        if fused + est_cost > float(caps[feature]):
            raise _402("feature_budget_reached", feature=feature, used_usd=round(fused, 4),
                       budget_usd=float(caps[feature]),
                       message="This feature has reached its monthly allowance.")
    # Public (visitor-triggered) flows: layered anti-exhaustion caps so ONE visitor / IP can never drain
    # the tenant's whole monthly allowance. All values are founder-editable in cost controls; defaults are
    # derived from the plan's AI cap: tenant public ceiling = 40% of the AI cap per day, per-IP = 10%,
    # per-session = 5% (floored at a few cents so tiny plans still get a handful of messages).
    if public:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        ai_cap = float(ai_budget_usd(plan) or 0)
        vcap = float(controls.get("public_visitor_daily_cap_usd") or 0) or (round(ai_cap * 0.40, 4) if ai_cap else 0)
        if vcap > 0:
            pused = await _sum_cost({"org_id": org_id, "public": True, "created_at": {"$gte": today}})
            if pused + est_cost > vcap:
                raise _402("public_daily_cap_reached", used_usd=round(pused, 4), budget_usd=vcap,
                           message="Visitor AI usage for today is exhausted.")
        ctx = get_context()
        ip_cap = float(controls.get("public_ip_daily_cap_usd") or 0) or (max(0.02, round(ai_cap * 0.10, 4)) if ai_cap else 0)
        if ip_cap > 0 and ctx.get("visitor_ip"):
            iused = await _sum_cost({"org_id": org_id, "public": True, "visitor_ip": ctx["visitor_ip"],
                                     "created_at": {"$gte": today}})
            if iused + est_cost > ip_cap:
                raise _402("public_ip_cap_reached", used_usd=round(iused, 4), budget_usd=ip_cap,
                           message="This network has used today's visitor AI allowance.")
        sess_cap = float(controls.get("public_session_daily_cap_usd") or 0) or (max(0.01, round(ai_cap * 0.05, 4)) if ai_cap else 0)
        if sess_cap > 0 and ctx.get("visitor_session"):
            sused = await _sum_cost({"org_id": org_id, "public": True, "visitor_session": ctx["visitor_session"],
                                     "created_at": {"$gte": today}})
            if sused + est_cost > sess_cap:
                raise _402("public_session_cap_reached", used_usd=round(sused, 4), budget_usd=sess_cap,
                           message="This conversation has used today's visitor AI allowance.")


async def enforce_llm_budget(org_id: Optional[str]) -> None:
    """Backwards-compatible alias."""
    ctx = get_context()
    await enforce_budget(org_id, feature=ctx.get("feature"), user_id=ctx.get("user_id"),
                         public=bool(ctx.get("public")))


# ---------------------------------------------------------------------------
# Reservations (atomic pre-call hold) + idempotency
# ---------------------------------------------------------------------------
IDEMPOTENCY = "usage_idempotency"   # {key, output, expires_at} — 24h result cache for idempotent calls


def _scoped_key(idempotency_key: str, *, provider: Optional[str] = None,
                model: Optional[str] = None) -> str:
    """Bind an idempotency key to the calling tenant/user/session/feature/operation so
    one tenant can NEVER read another tenant's cached output (or a different feature's)."""
    import hashlib
    ctx = get_context()
    parts = [
        str(ctx.get("org_id") or ""),
        str(ctx.get("user_id") or ctx.get("session_id") or ctx.get("public_session") or ""),
        str(ctx.get("feature") or ""),
        str(ctx.get("operation") or ""),
        str(provider or ctx.get("provider") or ""),
        str(model or ctx.get("model") or ""),
        str(idempotency_key or ""),
    ]
    raw = "\x1f".join(parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


async def find_idempotent(idempotency_key: Optional[str], *, provider: Optional[str] = None,
                          model: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Return {"output": ...} when a successful result was already produced for this
    key WITHIN THE CURRENT TENANT/USER/FEATURE SCOPE."""
    if not idempotency_key:
        return None
    skey = _scoped_key(idempotency_key, provider=provider, model=model)
    try:
        doc = await get_db()[IDEMPOTENCY].find_one({"skey": skey,
                                                    "expires_at": {"$gt": utc_now_iso()}}, {"_id": 0})
    except Exception:  # noqa: BLE001
        doc = None
    return doc


async def remember_idempotent(idempotency_key: Optional[str], output: Any, ttl_hours: int = 24,
                              *, provider: Optional[str] = None, model: Optional[str] = None) -> None:
    if not idempotency_key:
        return
    skey = _scoped_key(idempotency_key, provider=provider, model=model)
    ctx = get_context()
    try:
        exp = (datetime.now(timezone.utc) + timedelta(hours=ttl_hours)).isoformat().replace("+00:00", "Z")
        await get_db()[IDEMPOTENCY].update_one({"skey": skey},
                                               {"$set": {"output": output, "expires_at": exp,
                                                         "org_id": ctx.get("org_id"),
                                                         "feature": ctx.get("feature"),
                                                         "created_at": utc_now_iso()}}, upsert=True)
    except Exception:  # noqa: BLE001
        pass


async def reserve(*, kind: str, provider: str, model: str, est_cost: float,
                  org_id: Optional[str] = None, user_id: Optional[str] = None,
                  feature: Optional[str] = None, idempotency_key: Optional[str] = None,
                  request_id: Optional[str] = None) -> Dict[str, Any]:
    """Create a `held` reservation that counts against the org budget until settled/released."""
    ctx = get_context()
    now = datetime.now(timezone.utc)
    doc = {
        "id": str(uuid.uuid4()),
        "request_id": request_id or ctx.get("request_id") or str(uuid.uuid4()),
        "idempotency_key": idempotency_key,
        "kind": kind, "provider": provider, "model": model,
        "org_id": org_id or ctx.get("org_id"), "user_id": user_id or ctx.get("user_id"),
        "feature": feature or ctx.get("feature") or "unknown",
        "est_cost_usd": round(float(est_cost or 0), 6),
        "status": "held", "month": _month_key(now),
        "created_at": now.isoformat().replace("+00:00", "Z"),
        "expires_at": (now + timedelta(seconds=RESERVATION_TTL_S)).isoformat().replace("+00:00", "Z"),
    }
    try:
        await get_db()[RESERVATIONS].insert_one(dict(doc))
    except Exception as e:  # noqa: BLE001
        # FAIL CLOSED: if reservation storage is unavailable we must NOT let the paid
        # operation proceed unmetered. Reject the request rather than risk unbounded spend.
        logger.error("reserve() storage unavailable — failing closed: %s", e)
        raise HTTPException(503, detail={"error": "metering_unavailable",
                                         "message": "Usage metering is temporarily unavailable. Please retry shortly."})
    doc.pop("_id", None)
    return doc


async def confirm_reservation(reservation: Optional[Dict[str, Any]],
                              org_id: Optional[str] = None) -> None:
    """Atomic, race-safe budget confirmation AFTER a hold is inserted.

    `enforce_budget()` is a fast pre-check but a read-then-insert leaves a TOCTOU window: two
    concurrent requests can both pass the pre-check and both reserve. This closes that window.

    For every cap that applies to this reservation's `kind` (the AI hard cap and/or the owner's
    self-set AI cap for AI kinds, and the total variable-provider cap for every non-pass-through
    kind) we compute the FIFO-ordered cumulative spend within that cap's scope (settled ledger +
    all `held` reservations whose (created_at, id) is <= THIS reservation, restricted to the
    scope's kinds) and compare it to the cap. Because every concurrent request first inserts its
    own hold and then measures the cumulative total up to *its own* position, exactly the holds
    that fit under each cap survive; any that would push a running total over a cap release
    themselves and are rejected. The sum of surviving holds can never exceed any cap. Idempotent
    releases + TTL expiry keep this crash-safe. Pass-through/prepaid kinds are never gated here.
    """
    if not reservation:
        return
    org_id = org_id or reservation.get("org_id")
    if not org_id:
        return
    kind = reservation.get("kind") or ""
    if kind in PASSTHROUGH_KINDS:
        return  # prepaid / pass-through — billed to tenant, never against plan margin caps
    from .entitlements import (ai_budget_usd, variable_provider_cap_usd,
                               get_org_plan, _next_plan)
    plan = await get_org_plan(org_id)
    month = reservation.get("month") or _month_key()
    await expire_stale_reservations()
    settled_cache: Dict[str, float] = {}

    async def _settled(scope: str) -> float:
        if scope not in settled_cache:
            settled_cache[scope] = await _sum_cost({"org_id": org_id, "month": month, **_kind_match(scope)})
        return settled_cache[scope]

    # Build the list of caps that apply to this reservation, strictest first.
    checks = []  # (scope, cap, kind_of_error)
    if kind in AI_KINDS:
        ai_cap = ai_budget_usd(plan)
        owner_cap = await owner_ai_cap(org_id)
        ai_caps = [c for c in (ai_cap, owner_cap) if c and c > 0]
        if ai_caps:
            eff = min(ai_caps)
            is_owner = bool(owner_cap) and eff == owner_cap and (not ai_cap or owner_cap <= ai_cap)
            checks.append(("ai", eff, "owner" if is_owner else "ai"))
    var_cap = variable_provider_cap_usd(plan)
    if var_cap and var_cap > 0:
        checks.append(("variable", var_cap, "variable"))

    for scope, cap, err_kind in checks:
        settled = await _settled(scope)
        held_through = await _held_through_scoped(reservation, scope)
        cumulative = round(settled + held_through, 6)
        if cumulative > cap + 1e-9:
            await release(reservation, reason="over_budget")
            if err_kind == "owner":
                raise _402("owner_ai_cap_reached", feature="ai_credits", used_usd=round(settled, 4),
                           budget_usd=cap, owner_cap=True,
                           message=(f"You've reached the monthly AI spend limit you set (${cap:.2f}). "
                                    f"Raise or remove it in Billing → AI usage to continue."))
            if err_kind == "ai":
                raise _402("ai_budget_reached", feature="ai_credits", plan_code=plan,
                           used_usd=round(settled, 4), budget_usd=cap, suggest_plan=_next_plan(plan),
                           message=(f"You've used your monthly AI allowance on the {plan.title()} plan "
                                    f"(${cap:.2f}). Upgrade to {_next_plan(plan).title()} for more."))
            raise _402("variable_provider_cap_reached", feature="variable_providers", plan_code=plan,
                       used_usd=round(settled, 4), budget_usd=cap, suggest_plan=_next_plan(plan),
                       message=(f"Your {plan.title()} plan's monthly usage allowance is exhausted "
                                f"(${cap:.2f}). Upgrade to {_next_plan(plan).title()} or top up to continue."))


async def release(reservation: Optional[Dict[str, Any]], reason: str = "released") -> None:
    if not reservation:
        return
    try:
        await get_db()[RESERVATIONS].update_one({"id": reservation["id"], "status": "held"},
                                                {"$set": {"status": reason, "closed_at": utc_now_iso()}})
    except Exception:  # noqa: BLE001
        pass


async def settle(reservation: Optional[Dict[str, Any]], **record_kwargs: Any) -> Dict[str, Any]:
    """Reconcile: write the real ledger row, then close the reservation."""
    if reservation:
        record_kwargs.setdefault("request_id", reservation.get("request_id"))
        record_kwargs.setdefault("idempotency_key", reservation.get("idempotency_key"))
        record_kwargs.setdefault("estimated_cost_usd", reservation.get("est_cost_usd"))
        record_kwargs.setdefault("org_id", reservation.get("org_id"))
        record_kwargs.setdefault("user_id", reservation.get("user_id"))
        record_kwargs.setdefault("feature", reservation.get("feature"))
    ev = await record_usage(**record_kwargs)
    if reservation:
        try:
            await get_db()[RESERVATIONS].update_one(
                {"id": reservation["id"]},
                {"$set": {"status": "settled", "actual_cost_usd": ev.get("cost_usd"),
                          "closed_at": utc_now_iso()}})
        except Exception:  # noqa: BLE001
            pass
        # Fire a one-per-period budget-warning email if this spend crossed the threshold.
        try:
            oid = reservation.get("org_id")
            if oid:
                await maybe_send_budget_warning(oid)
                await maybe_send_owner_cap_alert(oid)
        except Exception:  # noqa: BLE001
            pass
    return ev


async def maybe_send_budget_warning(org_id: str) -> bool:
    """Email the org owner ONCE per billing period when AI spend crosses the warn threshold.
    Idempotent per (org, month) via an atomic guard on the organization document."""
    if not org_id:
        return False
    db = get_db()
    try:
        summary = await org_usage_summary(org_id)
    except Exception:  # noqa: BLE001
        return False
    if not summary.get("warn"):
        return False
    month = summary.get("month") or _month_key(datetime.now(timezone.utc))
    # Atomic claim: only the first crossing this month proceeds (prevents duplicate emails).
    try:
        from bson import ObjectId as _OID
        _oid_q = {"_id": _OID(org_id)} if len(org_id) == 24 else {"_id": org_id}
    except Exception:  # noqa: BLE001
        _oid_q = {"_id": org_id}
    res = await db.organizations.update_one(
        {**_oid_q, "usage_warned_month": {"$ne": month}},
        {"$set": {"usage_warned_month": month}})
    if res.modified_count == 0:
        return False  # already warned this month (or org not found)
    org = await db.organizations.find_one(_oid_q)
    owner = None
    if org:
        owner = await db.users.find_one({"org_id": org_id, "role": {"$in": ["owner", "manager"]}})
    to_email = (owner or {}).get("email")
    if not to_email:
        return False
    pct = int(summary.get("pct") or 0)
    budget = summary.get("budget_usd") or 0
    try:
        from . import platform_mail
        await platform_mail.send(
            "noreply", to_email, "You're close to your Zanelvo AI usage limit",
            f"Heads up — your organization has used about {pct}% of its monthly AI budget "
            f"(${summary.get('used_usd', 0):.2f} of ${budget:.2f}). AI features pause when the "
            f"limit is reached; upgrade your plan or wait for the next billing period to continue.",
            f"<p>Heads up — your organization has used about <b>{pct}%</b> of its monthly AI budget "
            f"(${summary.get('used_usd', 0):.2f} of ${budget:.2f}).</p>"
            f"<p>AI features pause when the limit is reached. Upgrade your plan or wait for the next "
            f"billing period to continue.</p>")
    except Exception:  # noqa: BLE001
        return False
    return True


async def maybe_send_owner_cap_alert(org_id: str) -> bool:
    """Email the owner when AI spend crosses 80% and again at 100% of THEIR self-set cap.
    Idempotent per (org, month, threshold) via atomic guards on db.org_ai_settings."""
    if not org_id:
        return False
    db = get_db()
    try:
        summary = await org_usage_summary(org_id)
    except Exception:  # noqa: BLE001
        return False
    cap = float(summary.get("owner_cap_usd") or 0)
    if cap <= 0:
        return False
    pct = int(summary.get("owner_cap_pct") or 0)
    threshold = 100 if pct >= 100 else (80 if pct >= 80 else 0)
    if threshold == 0:
        return False
    month = summary.get("month") or _month_key(datetime.now(timezone.utc))
    field = f"cap_alert_{threshold}_month"
    res = await db.org_ai_settings.update_one(
        {"org_id": org_id, field: {"$ne": month}},
        {"$set": {"org_id": org_id, field: month}}, upsert=True)
    if res.modified_count == 0 and res.upserted_id is None:
        return False  # already alerted this month at this threshold
    owner = await db.users.find_one({"org_id": org_id, "role": {"$in": ["owner", "manager"]}})
    to_email = (owner or {}).get("email")
    if not to_email:
        return False
    used = float(summary.get("used_usd") or 0)
    reached = threshold >= 100
    subject = ("Your Zanelvo AI spend limit has been reached" if reached
               else "You've used 80% of your Zanelvo AI spend limit")
    lead = (f"You've reached the monthly AI spend limit you set (${used:.2f} of ${cap:.2f}). "
            f"AI features are now paused until next month — raise or remove the limit in Billing → AI usage to continue."
            if reached else
            f"You've used about {pct}% of the monthly AI spend limit you set "
            f"(${used:.2f} of ${cap:.2f}). AI features will pause automatically when you hit 100%.")
    try:
        from . import platform_mail
        await platform_mail.send(
            "noreply", to_email, subject, lead,
            f"<p>{lead}</p><p>Manage your limit any time in <b>Billing → AI usage</b>.</p>")
    except Exception:  # noqa: BLE001
        return False
    return True
# Recording (universal ledger)
# ---------------------------------------------------------------------------
async def record_usage(
    *,
    kind: str,                       # text|json|image|email|sms|whatsapp|voice_second|translation_char|
                                     # embedding_1k|shipping_rate|shipping_label|phone_number_month|ad_api_call|ad_spend_usd
    provider: str,
    model: str = "",
    operation: Optional[str] = None,
    input_text: str = "",
    output_text: str = "",
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
    images: int = 0,
    image_resolution: Optional[str] = None,
    units: float = 0.0,
    org_id: Optional[str] = None,
    user_id: Optional[str] = None,
    feature: Optional[str] = None,
    ok: bool = True,
    error: Optional[str] = None,
    request_id: Optional[str] = None,
    idempotency_key: Optional[str] = None,
    retry_count: int = 0,
    cache_hit: bool = False,
    latency_ms: Optional[int] = None,
    estimated_cost_usd: Optional[float] = None,
    actual_cost_usd: Optional[float] = None,
    simulated: bool = False,
    public: Optional[bool] = None,
    currency: str = "USD",
) -> Dict[str, Any]:
    """Persist one ledger row (best-effort, never raises). Prompts are NOT stored — only sizes."""
    ctx = get_context()
    org_id = org_id or ctx.get("org_id")
    user_id = user_id or ctx.get("user_id")
    feature = feature or ctx.get("feature") or "unknown"
    request_id = request_id or ctx.get("request_id")
    public = bool(ctx.get("public")) if public is None else public

    key = f"{provider}/{model}" if model else f"unit/{kind}"
    rates = await _rates()
    rate = rates.get(key)

    in_tokens = input_tokens if input_tokens is not None else estimate_tokens(input_text)
    out_tokens = output_tokens if output_tokens is not None else estimate_tokens(output_text)
    cost = 0.0
    if actual_cost_usd is not None:
        cost = float(actual_cost_usd)
    elif simulated or cache_hit:
        cost = 0.0
    elif kind == "image":
        r = rate or _DEFAULT_IMAGE_RATE
        cost = float(r.get("per_image", _DEFAULT_IMAGE_RATE["per_image"])) * max(1, images or 1) if ok else 0.0
    elif kind in ("text", "json"):
        r = rate or _DEFAULT_TEXT_RATE
        cost = (in_tokens / 1000.0) * float(r.get("in_per_1k", _DEFAULT_TEXT_RATE["in_per_1k"]))
        cost += (out_tokens / 1000.0) * float(r.get("out_per_1k", _DEFAULT_TEXT_RATE["out_per_1k"]))
    else:
        r = rates.get(f"unit/{kind}") or {"per_unit": 0.0}
        cost = float(r.get("per_unit", 0.0)) * max(0.0, float(units or 0)) if ok else 0.0
    cost = round(cost, 6)

    now = datetime.now(timezone.utc)
    doc = {
        "id": str(uuid.uuid4()),
        "kind": kind,
        "operation": operation or kind,
        "provider": provider,
        "model": model,
        "feature": feature,
        "org_id": org_id,
        "user_id": user_id,
        "public": public,
        "visitor_ip": (get_context().get("visitor_ip") if public else None),
        "visitor_session": (get_context().get("visitor_session") if public else None),
        "request_id": request_id,
        "idempotency_key": idempotency_key,
        "input_tokens": in_tokens if kind in ("text", "json") else 0,
        "output_tokens": out_tokens if kind in ("text", "json") else 0,
        "total_tokens": (in_tokens + out_tokens) if kind in ("text", "json") else 0,
        "images": images if kind == "image" else 0,
        "image_resolution": image_resolution,
        "units": float(units or 0),
        "retry_count": int(retry_count or 0),
        "cache_hit": bool(cache_hit),
        "simulated": bool(simulated),
        "estimated_cost_usd": round(float(estimated_cost_usd), 6) if estimated_cost_usd is not None else None,
        "cost_usd": cost,               # actual (or best-estimate) cost — what dashboards sum
        "currency": currency,
        "latency_ms": latency_ms,
        "ok": ok,
        "status": "ok" if ok else "error",
        "error": (error or "")[:300] or None,
        "month": _month_key(now),
        "billing_period": _month_key(now),
        "created_at": now.isoformat().replace("+00:00", "Z"),
        "ts": now,
    }
    try:
        await get_db()[LEDGER].insert_one(dict(doc))
    except Exception as e:  # noqa: BLE001
        logger.warning("record_usage failed: %s", e)
    doc.pop("ts", None)
    doc.pop("_id", None)
    return doc


async def record_llm_usage(*, kind: str, provider: str, model: str, input_text: str = "",
                           output_text: str = "", images: int = 0, org_id: Optional[str] = None,
                           user_id: Optional[str] = None, feature: Optional[str] = None,
                           ok: bool = True, error: Optional[str] = None, **kw: Any) -> Dict[str, Any]:
    """Backwards-compatible wrapper around `record_usage` for LLM text/image calls."""
    return await record_usage(kind=kind, provider=provider, model=model, input_text=input_text,
                              output_text=output_text, images=images, org_id=org_id, user_id=user_id,
                              feature=feature, ok=ok, error=error, **kw)


# ---------------------------------------------------------------------------
# Summaries for dashboards
# ---------------------------------------------------------------------------
async def org_usage_summary(org_id: str, month: Optional[str] = None) -> Dict[str, Any]:
    db = get_db()
    month = month or _month_key()
    match = {"org_id": org_id, "month": month}
    total = {"cost_usd": 0.0, "calls": 0, "tokens": 0, "images": 0, "units": 0.0}
    by_feature: Dict[str, Dict[str, Any]] = {}
    by_kind: Dict[str, Dict[str, Any]] = {}
    for field, target in (("feature", by_feature), ("kind", by_kind)):
        async for row in db[LEDGER].aggregate([
            {"$match": match},
            {"$group": {"_id": f"${field}", "cost": {"$sum": "$cost_usd"}, "calls": {"$sum": 1},
                        "tokens": {"$sum": "$total_tokens"}, "images": {"$sum": "$images"},
                        "units": {"$sum": "$units"}}},
            {"$sort": {"cost": -1}},
        ]):
            f = row["_id"] or "unknown"
            target[f] = {"cost_usd": round(float(row["cost"] or 0), 4), "calls": int(row["calls"] or 0),
                         "tokens": int(row["tokens"] or 0), "images": int(row["images"] or 0),
                         "units": round(float(row.get("units") or 0), 2)}
            if field == "feature":
                total["cost_usd"] += float(row["cost"] or 0)
                total["calls"] += int(row["calls"] or 0)
                total["tokens"] += int(row["tokens"] or 0)
                total["images"] += int(row["images"] or 0)
                total["units"] += float(row.get("units") or 0)
    total["cost_usd"] = round(total["cost_usd"], 4)
    total["units"] = round(total["units"], 2)

    from .entitlements import ai_budget_usd, get_org_plan

    controls = await get_controls()
    plan = await get_org_plan(org_id)
    budget = ai_budget_usd(plan)
    held = await _held_reservations({"org_id": org_id, "month": month})
    pct = int((total["cost_usd"] / budget) * 100) if budget > 0 else 0
    warn_pct = int(controls.get("warn_pct") or 80)
    o_cap = await owner_ai_cap(org_id)
    cap_pct = int((total["cost_usd"] / o_cap) * 100) if o_cap > 0 else 0
    return {
        "month": month,
        "plan": plan,
        "budget_usd": budget,
        "used_usd": total["cost_usd"],
        "held_usd": held,
        "pct": min(999, pct),
        "over": budget > 0 and total["cost_usd"] >= budget,
        "warn": budget > 0 and warn_pct <= pct < 100,
        "warn_pct": warn_pct,
        "owner_cap_usd": o_cap,
        "owner_cap_pct": min(999, cap_pct),
        "owner_cap_over": o_cap > 0 and total["cost_usd"] >= o_cap,
        "paused": bool(controls.get("pause_all")),
        "totals": total,
        "by_feature": by_feature,
        "by_kind": by_kind,
    }


async def global_usage_summary(month: Optional[str] = None) -> Dict[str, Any]:
    """Founder-facing: platform-wide spend this month, by feature/model/org/kind + controls."""
    db = get_db()
    month = month or _month_key()
    match = {"month": month}

    async def _group(field: str, limit: int = 50):
        out = []
        async for row in db[LEDGER].aggregate([
            {"$match": match},
            {"$group": {"_id": f"${field}", "cost": {"$sum": "$cost_usd"}, "calls": {"$sum": 1},
                        "tokens": {"$sum": "$total_tokens"}, "errors": {"$sum": {"$cond": ["$ok", 0, 1]}}}},
            {"$sort": {"cost": -1}}, {"$limit": limit},
        ]):
            out.append({"key": row["_id"] or "unknown", "cost_usd": round(float(row["cost"] or 0), 4),
                        "calls": int(row["calls"] or 0), "tokens": int(row["tokens"] or 0),
                        "errors": int(row.get("errors") or 0)})
        return out

    total_cost, total_calls, total_errors, cache_hits = 0.0, 0, 0, 0
    async for row in db[LEDGER].aggregate([
        {"$match": match},
        {"$group": {"_id": None, "cost": {"$sum": "$cost_usd"}, "calls": {"$sum": 1},
                    "errors": {"$sum": {"$cond": ["$ok", 0, 1]}},
                    "cache": {"$sum": {"$cond": ["$cache_hit", 1, 0]}}}},
    ]):
        total_cost = round(float(row.get("cost") or 0), 4)
        total_calls = int(row.get("calls") or 0)
        total_errors = int(row.get("errors") or 0)
        cache_hits = int(row.get("cache") or 0)

    series = []
    async for row in db[LEDGER].aggregate([
        {"$match": match},
        {"$group": {"_id": {"$substr": ["$created_at", 0, 10]}, "cost": {"$sum": "$cost_usd"},
                    "calls": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
    ]):
        series.append({"day": row["_id"], "cost_usd": round(float(row["cost"] or 0), 4),
                       "calls": int(row["calls"] or 0)})

    controls = await get_controls()
    gcap = float(controls.get("global_monthly_budget_usd") or 0)
    held = await _held_reservations({"month": month})
    return {
        "month": month,
        "total_cost_usd": total_cost,
        "total_calls": total_calls,
        "total_errors": total_errors,
        "cache_hits": cache_hits,
        "held_usd": held,
        "global_budget_usd": gcap,
        "global_pct": int(total_cost / gcap * 100) if gcap > 0 else 0,
        "controls": controls,
        "by_feature": await _group("feature"),
        "by_model": await _group("model"),
        "by_kind": await _group("kind"),
        "by_provider": await _group("provider"),
        "by_org": await _group("org_id", limit=100),
        "daily": series,
        "updated_at": utc_now_iso(),
    }


async def margin_summary(month: Optional[str] = None) -> Dict[str, Any]:
    """Gross margin: subscription MRR (active subscriptions, price snapshots) vs. metered cost."""
    db = get_db()
    month = month or _month_key()
    mrr = 0.0
    subs_by_org: Dict[str, float] = {}
    async for s in db.subscriptions.find({"status": {"$in": ["active", "trialing", "past_due"]}}):
        cents = s.get("price_cents") or s.get("amount_cents") or 0
        interval = s.get("interval") or "monthly"
        monthly = (cents / 100.0) / (12 if interval == "annual" else 1)
        if not cents:
            plan = await db.plans.find_one({"code": s.get("plan_code")}, {"price_usd": 1})
            monthly = float((plan or {}).get("price_usd") or 0)
        subs_by_org[str(s.get("org_id"))] = subs_by_org.get(str(s.get("org_id")), 0.0) + monthly
        mrr += monthly
    cost_by_org: Dict[str, float] = {}
    async for row in db[LEDGER].aggregate([{"$match": {"month": month}},
                                           {"$group": {"_id": "$org_id", "cost": {"$sum": "$cost_usd"}}}]):
        cost_by_org[str(row["_id"])] = round(float(row["cost"] or 0), 4)
    total_cost = round(sum(cost_by_org.values()), 4)
    orgs = []
    for oid in set(list(subs_by_org) + list(cost_by_org)):
        rev = round(subs_by_org.get(oid, 0.0), 2)
        cost = cost_by_org.get(oid, 0.0)
        orgs.append({"org_id": oid, "mrr_usd": rev, "cost_usd": cost, "margin_usd": round(rev - cost, 4),
                     "margin_pct": round((rev - cost) / rev * 100, 1) if rev > 0 else None,
                     "loss_making": cost > rev})
    orgs.sort(key=lambda o: o["margin_usd"])
    return {
        "month": month,
        "mrr_usd": round(mrr, 2),
        "metered_cost_usd": total_cost,
        "gross_margin_usd": round(mrr - total_cost, 2),
        "gross_margin_pct": round((mrr - total_cost) / mrr * 100, 1) if mrr > 0 else None,
        "orgs": orgs[:200],
        "loss_making_orgs": sum(1 for o in orgs if o["loss_making"]),
    }


async def ledger_rows(month: Optional[str] = None, org_id: Optional[str] = None,
                      limit: int = 5000) -> List[Dict[str, Any]]:
    db = get_db()
    match: Dict[str, Any] = {"month": month or _month_key()}
    if org_id:
        match["org_id"] = org_id
    rows = []
    async for d in db[LEDGER].find(match, {"_id": 0, "ts": 0}).sort("created_at", -1).limit(limit):
        rows.append(d)
    return rows


LEDGER_CSV_COLUMNS = ["created_at", "billing_period", "org_id", "user_id", "feature", "operation", "kind",
                      "provider", "model", "request_id", "idempotency_key", "input_tokens", "output_tokens",
                      "images", "image_resolution", "units", "retry_count", "cache_hit", "simulated",
                      "estimated_cost_usd", "cost_usd", "currency", "latency_ms", "status", "error", "public"]


def ledger_csv(rows: List[Dict[str, Any]]) -> str:
    import csv
    import io

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=LEDGER_CSV_COLUMNS, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k, "") for k in LEDGER_CSV_COLUMNS})
    return buf.getvalue()


async def controls_audit(limit: int = 100) -> List[Dict[str, Any]]:
    out = []
    async for d in get_db()[CONTROLS_AUDIT].find({}, {"_id": 0}).sort("created_at", -1).limit(limit):
        out.append(d)
    return out


async def expire_stale_reservations() -> int:
    """Release reservations whose TTL passed (crash safety). Called opportunistically."""
    try:
        r = await get_db()[RESERVATIONS].update_many(
            {"status": "held", "expires_at": {"$lte": utc_now_iso()}},
            {"$set": {"status": "expired", "closed_at": utc_now_iso()}})
        return int(r.modified_count or 0)
    except Exception:  # noqa: BLE001
        return 0
