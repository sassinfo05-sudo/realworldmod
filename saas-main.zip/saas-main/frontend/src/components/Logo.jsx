import { useBrand } from "@/context/BrandContext";

export default function Logo({ className = "", size = 28 }) {
    const brand = useBrand();
    // Prefer server-provided SVG; fallback to inline.
    if (brand?.logo_svg) {
        return (
            <span
                className={`inline-flex items-center text-brand-copper ${className}`}
                style={{ width: size, height: size }}
                aria-label={`${brand?.name || "Zanelvo"} logo`}
                dangerouslySetInnerHTML={{ __html: brand.logo_svg }}
                data-testid="brand-logo"
            />
        );
    }
    return (
        <svg
            width={size}
            height={size}
            viewBox="0 0 40 40"
            className={`text-brand-copper ${className}`}
            aria-label={`${brand?.name || "Zanelvo"} logo`}
            data-testid="brand-logo"
        >
            <circle cx="20" cy="20" r="17" fill="none" stroke="currentColor" strokeWidth="2.5" />
            <path d="M20 12 L27 20 L20 28 L13 20 Z" fill="currentColor" />
        </svg>
    );
}

export function Wordmark({ className = "", light = false }) {
    const brand = useBrand();
    return (
        <span className={`inline-flex items-center gap-2 ${className}`} data-testid="brand-wordmark">
            <Logo size={24} />
            <span className={`font-display text-xl font-semibold tracking-tight ${light ? "text-white" : "text-brand-ink"}`}>
                {brand?.name || "Zanelvo"}
            </span>
        </span>
    );
}
