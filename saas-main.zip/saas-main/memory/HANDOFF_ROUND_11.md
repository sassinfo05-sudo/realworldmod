# ZANELVO — HANDOFF ROUND 11 (for a NEW chat)

_Living document for Round 11. Read this first, then `HANDOFF_ROUND_10.md`, `HANDOFF_ROUND_9.md`, then
`HANDOFF_ROUND_8.md` §2 (the authoritative A–N backlog with "how to build" notes). Source code + fresh
test evidence override any older ✅ claims._

---------------------------------------------------------------------------------------------------
## 0. HOW TO CONTINUE (first 10 minutes) — env is WIPED on import
---------------------------------------------------------------------------------------------------
```bash
env | grep -i preview_endpoint                       # preview host changes per job
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && \
SEK=$(python3 -c "import secrets;print(secrets.token_urlsafe(32))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
SECRETS_ENC_KEY=$SEK
EMERGENT_LLM_KEY=<emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
SEED_DEMO=true
CORS_ORIGINS=*
EOF
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile
sudo supervisorctl restart backend frontend && sleep 35 && curl -s localhost:8001/api/health
cat /app/memory/test_credentials.md      # regenerated with FRESH passwords on seed; send the NEW ones
```
Logins: owner `/login` → `/app`; founder/staff `/staff/login` (`POST /api/staff/auth/login`, dev 2FA code shown
inline); public demo `/site/demo-home-services`; storefront `/store/<org_id>`.
Verified at Round-11 start: health ok, owner + staff login 200, frontend 200, Round-10 features present.

---------------------------------------------------------------------------------------------------
## 1. ROUND 11 PROGRESS TRACKER (⬜ todo · 🟨 in progress · ✅ done & verified)
---------------------------------------------------------------------------------------------------
### R11-0 Round-10 leftovers
- ⬜ Docs: CHANGELOG / SECOND_RUN_AUDIT / PRD entries for Round 10 + 11

### R11-1 Website breadth leftovers (Gate 3 / HANDOFF_8 §D)
- ✅ Reusable saved sections (`db.saved_sections`, `POST /api/editor/website/blocks/{id}/save-as-section`, list/insert/delete, AddSectionMenu "Saved")
- ✅ JSON-LD schema markup on public site (LocalBusiness + FAQPage + Service + Product + Article) — NOTE: older docs claimed LocalBusiness existed; grep shows none
- ✅ Alt-text editing for images in the editor Inspector

### R11-2 Commerce leftovers (Gate 4 / §E, §I)
- ✅ Storefront text search + sort (`GET /api/public/store/{org}/products?q=&sort=`) + UI
- ✅ Related products "You may also like" on storefront (related_ids → shared tags fallback)
- ✅ Automatic discounts (`auto: true` rules applied when no code)
- ✅ Product feeds: `GET /api/public/store/{org}/feed.xml` (Google Shopping RSS) + `feed.csv`; owner toggle

### R11-3 Analytics & attribution (§H)
- ✅ UTM/landing attribution persisted (`zv_attr`) → attached to form submits, bookings, buy-now
- ✅ `routes/analytics.py`: funnel, channel report, AOV/LTV/repeat rate, CSV export + dashboard UI

### R11-4 Staff / support operations (§J, §K)
- ✅ Unified staff support inbox (all tenants' tickets, assign, internal notes, collision lock)
- ✅ Public status page `/status` + founder incidents CRUD
- ✅ Deployment health: build SHA + uptime + DB ping latency in `/api/health` + founder health
- ✅ Fraud blocklist (IP / email domain) enforced at signup + staff UI

### R11-5 Infra / security leftovers (§B)
- ✅ Chunked uploads `POST /api/media/upload/init|chunk|complete`
- ✅ Outbound webhook replay by delivery id
- ✅ Email bounce/complaint provider webhooks → `email_logs` + suppression
- ✅ PayPal webhook signature verification code path (live rail STILL refused until creds)

### R11-6 Workflows
- ✅ A/B split node

### Tests / docs
- ⬜ backend testing agent run for Round 11 · ⬜ frontend testing · ⬜ test_result.md round11 blocks

---------------------------------------------------------------------------------------------------
## 2. WHAT ROUND 11 SHIPPED (appended per task as it completes)
---------------------------------------------------------------------------------------------------
(filled in below)

### 2.1 R11-1 Website breadth leftovers
- `routes/editor.py`: `GET /api/editor/saved-sections`, `POST /api/editor/website/blocks/{id}/save-as-section {name}`,
  `POST /api/editor/website/pages/{slug}/blocks/from-saved/{section_id}?position=`, `DELETE /api/editor/saved-sections/{id}`
  (collection `db.saved_sections`, org-scoped, cap 100). curl-verified (save → list → insert → delete → 404).
- Frontend: `EditorProvider.saveBlockAsSection` (flushes autosave first); Inspector "Save as reusable" button
  (`inspector-save-section`, window.prompt for name) + "Image alt text" field (`inspector-image-alt`, prop `image_alt`,
  rendered by HeroBlock/AboutSplitBlock `<img alt>`); AddSectionMenu shows a "Saved sections" group (`add-section-group-saved`,
  insert = client-side onAdd with the saved props; delete icon).
- JSON-LD: `PublicSite.jsx` exports `buildJsonLd(site,page,url)` + `setJsonLd(schemas,id)` → `<script id="zv-jsonld">` with
  LocalBusiness (name/url/tagline/phone/email/address from contact_hours or footer props), FAQPage (faq items), ItemList of
  Service (services_grid). `PublicBlog.jsx` emits Article (`zv-jsonld-article`). Built only from published owner content —
  no invented ratings/prices.

### 2.2 R11-2 Commerce leftovers
- `routes/ecommerce.py`: `DiscountIn` gained `auto: bool` + `title`; `best_discount(db, org, subtotal, code)` = manual code
  (must be valid) OR the single largest active `auto` rule (no stacking). `_discount_out` exposes `auto`/`title`.
- `routes/store.py` public: `GET /api/public/store/{org}/products?q=&sort=newest|price_asc|price_desc|name&collection_id=&tag=`
  (regex search over name/description/tags/sku; response has `query` + `auto_discounts[]`),
  `GET …/products/{id}/related?limit=` (related_ids → shared tags/collections fallback; `source`),
  `GET …/discount-preview?subtotal_cents=&code=`, `GET …/feed.xml` (Google Shopping RSS, g: namespace, gtin=barcode, mpn=sku,
  sale_price when compare_at > price) + `GET …/feed.csv` (Meta). `PUBLIC_BASE_URL` env optional for absolute links.
  Buy-now: `BuyNowReq.discount_code`; discount resolved server-side; shipping quote + tax computed on the DISCOUNTED subtotal;
  order stores `discount_cents/discount_code/discount_auto`; invalid typed code → 400; `_finalize_paid_order` increments
  `used_count` once per paid order. `_order_out` exposes discount fields.
- `routes/commerce_ext.py`: `GET/PUT /api/store/feeds {enabled}` (db.store_settings.feeds_enabled; off → feeds 404).
- UI: `Storefront.jsx` search box + sort select (`storefront-search`, `storefront-sort`), automatic-discount banner
  (`storefront-auto-discounts`), buy dialog discount code input + live server preview (`storefront-discount-code`,
  `storefront-discount-line`, `storefront-total`) and "You may also like" (`storefront-related`). `Discounts.jsx` auto toggle +
  label (`discount-auto-toggle`) and "Automatic" badge. `Products.jsx` `FeedsCard` (`products-feeds-card`, toggle + URLs).
- Verified: curl (search/sort/related/preview/buy-now auto + bad code 400/feed gtin/toggle 404↔200) + browser screenshot
  (total $17.10 after automatic 10%). Test products (Drain Snake Pro / Pipe Wrench 14in / Water Filter Cartridge) + AUTO10 rule
  were left in the demo org on purpose so the storefront is not empty.

### 2.3 R11-3 Analytics & attribution
- `services/attribution.py`: `clean_attribution()` (allow-list source/medium/campaign/content/term/referrer/landing/gclid/fbclid/
  first_seen, 200-char cap), `channel_of()` (direct/paid_search/paid_social/email/social/organic_search/referral/other),
  `emit(db, org, kind, …)` → `analytics_events` rows with `meta.attribution` + `meta.channel` (never raises).
- Hooks: `POST /api/analytics/track` keeps only label/href/block_id + attribution in meta; `POST /api/forms/submit` accepts
  `attribution` → form_submission + FIRST-TOUCH on `contacts.attribution` (never overwritten) + event; `POST /api/public/booking/book`
  accepts `attribution` → booking + contact + `booking_created` event; buy-now accepts `attribution` → `store_orders.attribution`
  + `checkout_started` event; `_finalize_paid_order` emits `order_paid` with `revenue_cents`.
- `routes/analytics.py` (mounted `/api/analytics/reports`): `GET /overview?days=` → funnel (Visits → CTA → Form → Bookings →
  Checkouts → Orders paid with rates), channels (first-touch; visits/cta/leads/orders/revenue/lead_rate), commerce KPIs
  (revenue, AOV, buyers, repeat rate, revenue/customer "LTV", refunds), daily timeseries, honesty notes (CAC/ROAS need ad spend);
  `GET /export.csv?days=`.
- Frontend: `lib/attribution.js` (`captureAttribution()` first-touch in localStorage `zv_attr`, 30 d; `getAttribution()`), wired
  into PublicSite pageview + NEW delegated CTA-click tracking (links/buttons inside hero/cta_band/pricing/services/contact/store/
  booking blocks), FormBlock, BookingBlock, Storefront buy-now. `pages/dashboard/Analytics.jsx` gained "Funnel & channels"
  (`analytics-funnel-report`: window select, Export CSV, 4 KPI cards, funnel bars, channel table, daily bars).
- Verified: curl chain (track w/ gclid → form submit → buy-now → simulated pay) → funnel 1/0/1/0/1/1, channel paid_search
  $44.10, contact.attribution stored; browser screenshot of /app/analytics.

### 2.4 R11-4 Staff / support operations
- NEW `routes/staff_support.py` (prefix `/api/staff`, added via `app.include_router`):
  - Unified inbox (perm `tenants`): `GET /support/tickets?status=&assignee=me|unassigned|<id>&q=`, `GET /support/stats`
    (by_status, unassigned_open, median first response, per-assignee load), `GET /support/tickets/{id}` (messages +
    internal_notes + history), `POST …/assign {staff_id|"me"|null}`, `POST …/notes {text}` (staff-only), `POST …/reply
    {text, status?}` (tenant-visible, sets first_response_at, auto-assigns, emails owner via platform_mail best-effort, 409
    `ticket_locked` if another agent holds the lock), `POST …/status {status}`, `POST|DELETE …/lock` (60 s collision lock).
    Tenant `GET /api/support/tickets/{id}` now strips internal_notes/lock/history/assignee ids (exposes `assigned: bool`).
  - Incidents (perm `health`): `GET/POST /api/staff/incidents`, `POST /api/staff/incidents/{id}/updates`; public
    `GET /api/support/status` now returns `incidents[]` (active + resolved ≤7 d), `active_incidents`, and degrades component
    checks named in an active incident (critical → outage / `major_outage`).
  - Fraud blocklist (perm `audit`): `GET/POST /api/staff/fraud/blocklist {kind: ip|email_domain|email, value, reason}`,
    `DELETE …/{id}`; `services/antifraud.assess_signup` refuses blocked signups (signal kind `blocklist`, hit counter).
- `/api/health` now returns `build` (BUILD_SHA/GIT_SHA env or .git HEAD), `env`, `uptime_seconds`, `db.latency_ms`.
- UI: `pages/staff/StaffSupport.jsx` at `/staff/support` (nav "Support inbox"; tabs Tickets / Incidents & status page;
  stats strip, filters, list + detail with assign/status/reply/send-&-resolve/internal notes, lock heartbeat every 30 s);
  `pages/public/StatusPage.jsx` at `/status` (imported as `PublicStatusPage` in App.js — a dashboard `StatusPage` export already
  exists in Support.jsx); `StaffFraud.jsx` gained a Blocklist panel AND was converted from dark to the light staff theme
  (it was white-on-white before).
- Verified: curl (ticket → staff list/assign/lock/note/reply → tenant view hides notes → stats; owner token 403; incident
  degrades status then resolves; blocklist refuses signup) + screenshots of /status and /staff/support.

### 2.5 R11-5 Infra / security leftovers
- Chunked uploads (`routes/media_forms_analytics.py`): `POST /api/media/upload/init {filename,mime,total_bytes}` →
  `{upload_id, chunk_bytes:524288, chunks}`; `POST /api/media/upload/{id}/chunk {index,data_base64}` (≤512 KB each, staged at
  `UPLOAD_DIR/chunks/<id>/`); `POST …/complete` assembles, checks size, then re-uses the single-shot `upload_media` validation
  (mime sniff/SVG sanitise/4 MB image cap); `DELETE …/{id}` aborts. `db.media_uploads` tracks status. `MediaPicker.jsx` uses the
  chunked path for files > 1 MB with a % indicator. Verified: init → complete-too-early 400 chunks_missing → chunk → complete
  asset; spoofed mime 415.
- Outbound webhooks: `GET /api/setup/webhooks/{wid}/deliveries`, `POST /api/setup/webhooks/{wid}/replay/{delivery_id}`
  (owner-scoped; new row gets `replayed_from`). FIXED GAP: `form.submitted` (in-app form path) and `booking.created`
  (public booking path) now actually dispatch — previously only the public API fired outbound webhooks. `Webhooks.jsx` has a
  Deliveries panel (history icon per endpoint) with Replay buttons. Verified live against httpbin (200) + replay.
- Email delivery events (`routes/email_inbound.py::_delivery_event`): Resend `email.bounced|complained|delivered|delivery_delayed`
  and SendGrid Event Webhook JSON arrays (bounce/dropped/spamreport/delivered/deferred) on the same `/api/webhooks/email/{provider}`
  URLs. Tenant resolved from the SENDER address (`resolve_org_for_address`); bounces/complaints upsert `db.suppressions`
  (tenant) or `db.platform_suppressions`; `email_logs.delivery_status` annotated by provider_message_id; all events in
  `db.email_events`. Verified both routes (platform vs tenant after setting inbound_email).
- PayPal: `services/payment_providers.PayPalWebhookVerifier` (verify-webhook-signature API, sandbox/live) +
  `POST /api/billing/webhook/paypal` (400 when unconfigured/unverifiable; idempotent `paypal_events`; finalizes store orders on
  PAYMENT.CAPTURE.COMPLETED via custom_id). Reads secrets `payments.paypal_client_id/paypal_client_secret/paypal_webhook_id/
  paypal_mode` from the Setup Center store. Live PayPal CHECKOUT is STILL refused (no creds) — `list_payment_providers` now lists
  PayPal honestly as not connected.

### 2.6 R11-6 Workflows — A/B split node
- `services/workflows.py`: node type `ab_split` `{percent_a: 0-100, sticky: true}`; edges use `when: "a"|"b"`; validate_graph
  requires an A or B edge and a 0-100 percent; execution buckets deterministically per `wf_id:node_id:contact.id|contact.email|email`
  (sha256 → 0-100) when sticky and a key exists, else random; live runs `$inc` `db.workflow_ab_stats.count_a|count_b`
  (test runs excluded). Step result shows `branch: "A"|"B"`.
- `GET /api/workflows/{wid}/ab-stats` → per-node counts + share_a. `Workflows.jsx`: teal node with A/B handles, inspector slider
  (`wf-ab-percent`) + sticky checkbox, edge colours, "A/B split results" box in the Run history panel (`wf-ab-stats`).
- Verified: create → validate ok → 10 test runs; branch assignment matches an offline sha256 recomputation (deterministic).

---------------------------------------------------------------------------------------------------
## 3. STILL NOT DONE AFTER ROUND 11 (do NOT claim live)
---------------------------------------------------------------------------------------------------
- 🔒 PayPal live rail (needs creds) · 🔒 real SSL issuance (Cloudflare for SaaS / Vercel domains) · 🔒 live carrier rates
  (Shippo/EasyPost key) · 🔒 ad-account OAuth (Google/Meta) · 🔒 SMS/WhatsApp (no provider)
- Customer accounts / saved carts · subscriptions (Stripe Billing) · gift cards · bundles UI · customer groups
- Drag-and-drop email editor · per-language authored site content · Redis-backed rate limits · Stripe Connect
- Home + Pricing "wow" redesign · Lighthouse/axe pass · developer docs page
