import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Lock } from "lucide-react";

export default function PaymentSettings() {
    const [providers, setProviders] = useState([]);
    useEffect(() => {
        api.get("/payments/providers").then((r) => setProviders(r.data.providers || [])).catch(() => {});
    }, []);
    return (
        <div className="p-6" data-testid="payment-settings-page">
            <h2 className="text-lg font-medium text-brand-ink">Payment providers</h2>
            <p className="text-sm text-zinc-500 mt-1 mb-4">Simulated is active by default — safe for tests. Add Stripe keys to accept real charges.</p>
            <div className="grid md:grid-cols-2 gap-3">
                {providers.map((p) => (
                    <div key={p.key} className={`rounded-xl border-2 p-4 ${p.is_connected ? "border-emerald-300 bg-emerald-50/40" : "border-brand-line bg-white"}`} data-testid={`payment-provider-${p.key}`}>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-medium text-brand-ink">
                                <CreditCard className="w-4 h-4" /> {p.label}
                            </div>
                            <Badge className={p.is_connected ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-600"}>
                                {p.is_connected ? "Active" : "Not connected"}
                            </Badge>
                        </div>
                        <p className="text-xs text-zinc-600 mt-2">{p.honest_status}</p>
                        <p className="text-[10px] text-zinc-400 mt-1 flex items-start gap-1"><Lock className="w-3 h-3 mt-0.5" />{p.docs}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}
