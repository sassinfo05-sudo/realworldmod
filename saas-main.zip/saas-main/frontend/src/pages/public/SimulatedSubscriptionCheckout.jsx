import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Zap, Lock } from "lucide-react";

function money(cents) {
    return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format((cents || 0) / 100);
}

export default function SimulatedSubscriptionCheckout() {
    const { sid } = useParams();
    const navigate = useNavigate();
    const [session, setSession] = useState(null);
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        api.get(`/billing/checkout/${sid}`).then((r) => setSession(r.data));
    }, [sid]);

    async function pay() {
        setBusy(true);
        try {
            await api.post(`/billing/checkout/${sid}/complete`);
            toast.success("Plan upgraded — entitlements refreshed.");
            navigate("/app/billing");
        } catch (e) { toast.error("Payment failed"); }
        finally { setBusy(false); }
    }

    if (!session) return <div className="min-h-screen flex items-center justify-center text-zinc-500">Loading…</div>;

    return (
        <div className="min-h-screen bg-brand-cream flex items-center justify-center p-6" data-testid="sub-checkout-page">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-lg border border-brand-line p-6">
                <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper">
                    <Lock className="w-3 h-3" /> Simulated checkout
                </div>
                <div className="mt-3 flex items-baseline justify-between">
                    <div>
                        <div className="text-sm text-zinc-500">Plan</div>
                        <div className="font-display text-xl text-brand-ink capitalize">{session.plan_code}</div>
                    </div>
                    <div className="text-right">
                        <div className="text-sm text-zinc-500">Amount</div>
                        <div className="font-display text-3xl text-brand-ink">{money(session.price_cents)}</div>
                    </div>
                </div>
                {session.coupon_code && (
                    <div className="mt-2 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded px-2 py-1">
                        Coupon applied: <span className="font-mono">{session.coupon_code}</span>
                    </div>
                )}
                <div className="mt-4 text-xs text-zinc-500 bg-brand-cream border border-brand-line rounded p-3">
                    Secure checkout — no card is charged in this preview. Clicking Pay applies your plan change instantly.
                </div>
                <Button onClick={pay} disabled={busy || session.status !== "pending"} className="w-full mt-4 bg-brand-copper hover:bg-brand-copperHover text-white h-11" data-testid="sub-checkout-pay-btn">
                    <Zap className="w-4 h-4 mr-2" />
                    {session.status === "completed" ? "Already completed" : `Pay ${money(session.price_cents)}`}
                </Button>
                <Button variant="ghost" className="w-full mt-2" onClick={() => navigate("/app/billing")} data-testid="sub-checkout-cancel-btn">Cancel</Button>
            </div>
        </div>
    );
}
