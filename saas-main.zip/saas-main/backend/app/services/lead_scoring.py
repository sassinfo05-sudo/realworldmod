"""Explainable rule-based + LLM-assessed lead scoring.

Every score returned to the UI includes a factor breakdown so owners can trust it.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

from .llm import generate_json, LlmError

logger = logging.getLogger(__name__)

# Weights sum to 60; AI-assessed fit can add up to 40 → total 0-100.
_RULE_WEIGHTS = {
    "has_email": 8,
    "has_phone": 8,
    "has_name": 6,
    "source_form": 10,
    "source_referral": 10,
    "source_import": 3,
    "form_completeness": 8,      # scaled by % of standard fields filled
    "recent_activity": 10,       # within 30 days
    "consent_granted": 5,
    "tag_priority": 5,           # 'hot', 'priority' tags
}


def compute_rule_factors(contact: Dict[str, Any]) -> Tuple[float, List[Dict[str, Any]]]:
    """Return (rule_score_0_60, factors) — every factor lists points + explanation."""
    factors: List[Dict[str, Any]] = []
    score = 0.0

    def add(key: str, points: float, note: str):
        nonlocal score
        score += points
        factors.append({"key": key, "points": round(points, 1), "note": note})

    if contact.get("emails"):
        add("has_email", _RULE_WEIGHTS["has_email"], "Has an email on file")
    if contact.get("phones"):
        add("has_phone", _RULE_WEIGHTS["has_phone"], "Has a phone number on file")
    if contact.get("first_name") or contact.get("last_name") or contact.get("display_name"):
        add("has_name", _RULE_WEIGHTS["has_name"], "Full name on record")

    source = (contact.get("source") or "").lower()
    if source == "form":
        add("source_form", _RULE_WEIGHTS["source_form"], "Reached out via website form (highest intent)")
    elif source == "referral":
        add("source_referral", _RULE_WEIGHTS["source_referral"], "Referred by an existing customer")
    elif source == "import":
        add("source_import", _RULE_WEIGHTS["source_import"], "Imported from an external list (colder)")

    fields_filled = sum(bool(contact.get(k)) for k in
                        ("first_name", "last_name", "emails", "phones", "address", "title"))
    if fields_filled >= 4:
        add("form_completeness", _RULE_WEIGHTS["form_completeness"],
            f"{fields_filled}/6 standard fields filled — strong context")
    elif fields_filled >= 2:
        add("form_completeness", _RULE_WEIGHTS["form_completeness"] * 0.5,
            f"{fields_filled}/6 fields filled — partial context")

    if contact.get("last_activity_at"):
        # crude "within 30 days" heuristic — the caller can preprocess this
        add("recent_activity", _RULE_WEIGHTS["recent_activity"],
            "Recent activity in the last 30 days")

    if any((c or {}).get("status") == "granted" for c in (contact.get("consents") or [])):
        add("consent_granted", _RULE_WEIGHTS["consent_granted"],
            "Marketing consent on file — safe to reach out")

    tags = [t.lower() for t in (contact.get("tags") or [])]
    if any(t in {"hot", "priority", "high-intent"} for t in tags):
        add("tag_priority", _RULE_WEIGHTS["tag_priority"],
            "Tagged as priority / high-intent")

    return score, factors


async def compute_ai_fit(contact: Dict[str, Any], business: Dict[str, Any]) -> Tuple[float, List[Dict[str, Any]]]:
    """Ask the LLM for a 0-40 fit score with 2-4 factor rationales.
    Returns (score, factors). Never invents facts — grounded only on provided data.
    """
    system = (
        "You are a sober CRM analyst. Score how well this Contact matches the Business's "
        "ideal customer, on a scale of 0-40 (integer). Return STRICT JSON. Use ONLY facts "
        "supplied — do not invent tenure, size, budget, or intent. If information is missing, "
        "penalize the score and say so in a factor. Never award full points on thin data."
    )
    user = {
        "business": {k: business.get(k) for k in
                     ("business_name", "industry", "tone", "services", "differentiators", "goals")},
        "contact": {k: contact.get(k) for k in
                    ("first_name", "last_name", "title", "emails", "phones", "tags",
                     "source", "custom_fields", "company_id", "language", "notes_count")},
    }
    prompt = (
        "Score the contact fit for this business.\n"
        f"DATA:\n{user}\n\n"
        'Return JSON: {"score": <int 0-40>, "factors": [{"key": "<short>", "points": <int>, "note": "<one sentence>"} ...]} '
        "Factors' points sum should approximately equal `score`. 2-4 factors."
    )
    try:
        data = await generate_json(system, prompt, max_retries=1)
        score = float(data.get("score") or 0)
        score = max(0.0, min(40.0, score))
        factors_raw = data.get("factors") or []
        factors: List[Dict[str, Any]] = []
        for f in factors_raw[:4]:
            if not isinstance(f, dict):
                continue
            factors.append({
                "key": str(f.get("key") or "ai_factor")[:32],
                "points": round(float(f.get("points") or 0), 1),
                "note": str(f.get("note") or ""),
                "source": "ai",
            })
        return score, factors
    except LlmError as e:
        logger.warning("AI fit scoring failed: %s", e)
        return 0.0, [{"key": "ai_unavailable", "points": 0, "note": f"AI fit not available ({e})", "source": "ai"}]


async def score_contact(contact: Dict[str, Any], business: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Compose rule + AI factors. Return {score, factors, breakdown}."""
    rule_score, rule_factors = compute_rule_factors(contact)
    ai_score, ai_factors = 0.0, []
    if business:
        try:
            ai_score, ai_factors = await compute_ai_fit(contact, business)
        except Exception as e:  # noqa: BLE001
            logger.warning("AI fit failed silently: %s", e)
    total = round(min(100.0, rule_score + ai_score), 1)
    return {
        "score": total,
        "factors": rule_factors + ai_factors,
        "breakdown": {"rule_score": round(rule_score, 1), "ai_fit_score": round(ai_score, 1),
                      "max_possible": 100},
    }
