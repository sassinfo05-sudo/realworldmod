"""Phase 5 routes: knowledge base, agents (with versioning + sandbox), chat (public widget +
dashboard), call simulator, daily digest, and the org-wide AI kill switch.

Every mutating endpoint is org-scoped via current_user / current_org; public widget uses a
short-lived session token bound to a website_slug + org_id.
"""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends, File, HTTPException, Query, Request, UploadFile
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_role as require_roles
from ..models import User
from ..models_ai import (
    AgentVersion, ChatConversation, ChatMessage,
    CallRecord, DailyDigest,
)
from ..services.ai_agent_runner import run_turn
from ..services.ai_tools import TOOLS
from ..services.knowledge import (
    add_faq, add_policy, add_upload, detect_contradictions,
    ingest_website_pages, refresh_structured_facts,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/ai", tags=["ai"])
public_ai = APIRouter(prefix="/api/public/chat", tags=["public-chat"])


# ---------- Kill switch ----------

class KillSwitchPatch(BaseModel):
    ai_enabled: bool
    reason: Optional[str] = None


@router.get("/kill-switch")
async def get_kill_switch(user: User = Depends(current_user)):
    db = get_db()
    ks = await db.kill_switches.find_one({"org_id": user.org_id})
    if not ks:
        return {"ai_enabled": True, "reason": None, "updated_at": None}
    return {"ai_enabled": bool(ks.get("ai_enabled", True)),
             "reason": ks.get("reason"),
             "updated_at": ks.get("updated_at")}


@router.put("/kill-switch")
async def set_kill_switch(patch: KillSwitchPatch,
                             user: User = Depends(require_roles("owner", "manager"))):
    db = get_db()
    await db.kill_switches.update_one(
        {"org_id": user.org_id},
        {"$set": {"ai_enabled": patch.ai_enabled, "reason": patch.reason,
                    "updated_by": str(user.id), "updated_at": utc_now_iso(),
                    "org_id": user.org_id}},
        upsert=True,
    )
    return {"ok": True}


# ---------- Knowledge base ----------

@router.get("/knowledge/sources")
async def list_sources(kind: Optional[str] = None,
                          user: User = Depends(current_user)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": user.org_id}
    if kind:
        q["kind"] = kind
    out = []
    async for d in db.knowledge_sources.find(q).sort("ingested_at", -1):
        out.append({
            "id": str(d["_id"]),
            "kind": d.get("kind"), "title": d.get("title"),
            "origin": d.get("origin"),
            "status": d.get("status"),
            "ingested_at": d.get("ingested_at"),
            "contradiction_flag": d.get("contradiction_flag"),
            "version": d.get("version"),
            "chunk_count": len(d.get("chunks") or []),
            "has_body": bool(d.get("body_text")),
            "has_facts": bool(d.get("facts")),
        })
    return {"sources": out}


@router.get("/knowledge/sources/{sid}")
async def get_source(sid: str, user: User = Depends(current_user)):
    db = get_db()
    d = await db.knowledge_sources.find_one({"_id": ObjectId(sid), "org_id": user.org_id})
    if not d:
        raise HTTPException(404, "Not found")
    d["id"] = str(d.pop("_id"))
    return d


class FAQCreate(BaseModel):
    title: str
    body: str


@router.post("/knowledge/faq")
async def create_faq(req: FAQCreate,
                        user: User = Depends(require_roles("owner", "manager"))):
    sid = await add_faq(user.org_id, req.title, req.body, created_by=str(user.id))
    return {"id": sid}


@router.post("/knowledge/policy")
async def create_policy(req: FAQCreate,
                          user: User = Depends(require_roles("owner", "manager"))):
    sid = await add_policy(user.org_id, req.title, req.body, created_by=str(user.id))
    return {"id": sid}


@router.post("/knowledge/upload")
async def upload_source(file: UploadFile = File(...),
                          user: User = Depends(require_roles("owner", "manager"))):
    raw = await file.read()
    if len(raw) > 4 * 1024 * 1024:
        raise HTTPException(413, "Uploads capped at 4 MB")
    sid, err = await add_upload(user.org_id, file.filename or "upload",
                                    raw, created_by=str(user.id))
    if err:
        raise HTTPException(400, err)
    return {"id": sid}


@router.post("/knowledge/refresh")
async def refresh_knowledge(user: User = Depends(require_roles("owner", "manager"))):
    facts_id = await refresh_structured_facts(user.org_id)
    page_count = await ingest_website_pages(user.org_id)
    contradictions = await detect_contradictions(user.org_id)
    return {"ok": True, "structured_facts_id": facts_id,
             "website_pages_ingested": page_count,
             "contradictions_flagged": contradictions}


class SourcePatch(BaseModel):
    status: Optional[str] = None
    body: Optional[str] = None
    title: Optional[str] = None


@router.patch("/knowledge/sources/{sid}")
async def patch_source(sid: str, patch: SourcePatch,
                          user: User = Depends(require_roles("owner", "manager"))):
    db = get_db()
    existing = await db.knowledge_sources.find_one({"_id": ObjectId(sid), "org_id": user.org_id})
    if not existing:
        raise HTTPException(404, "Not found")
    if existing.get("kind") == "structured_facts":
        raise HTTPException(400, "Structured facts are managed via records — refresh instead.")
    upd: Dict[str, Any] = {"updated_at": utc_now_iso()}
    if patch.status and patch.status in ("active", "excluded", "stale"):
        upd["status"] = patch.status
    if patch.title is not None:
        upd["title"] = patch.title.strip() or existing.get("title")
    if patch.body is not None:
        from ..services.knowledge import _chunk_text
        upd["body_text"] = patch.body
        upd["chunks"] = [{"id": f"c{i}", "text": c} for i, c in enumerate(_chunk_text(patch.body))]
        upd["version"] = (existing.get("version", 1) + 1)
    await db.knowledge_sources.update_one({"_id": existing["_id"]}, {"$set": upd})
    return {"ok": True}


@router.delete("/knowledge/sources/{sid}")
async def delete_source(sid: str,
                           user: User = Depends(require_roles("owner", "manager"))):
    db = get_db()
    existing = await db.knowledge_sources.find_one({"_id": ObjectId(sid), "org_id": user.org_id})
    if not existing:
        raise HTTPException(404, "Not found")
    if existing.get("kind") == "structured_facts":
        raise HTTPException(400, "Structured facts cannot be deleted.")
    await db.knowledge_sources.delete_one({"_id": existing["_id"]})
    return {"ok": True}


# ---------- Agents ----------

@router.get("/agents")
async def list_agents(user: User = Depends(current_user)):
    db = get_db()
    out = []
    async for a in db.agents.find({"org_id": user.org_id}).sort("agent_type", 1):
        live = None
        if a.get("live_version_id"):
            v = await db.agent_versions.find_one({"_id": ObjectId(a["live_version_id"])})
            if v:
                v["id"] = str(v.pop("_id"))
                live = v
        out.append({
            "id": str(a["_id"]), "agent_type": a.get("agent_type"),
            "name": a.get("name"), "enabled": a.get("enabled", True),
            "live_version_id": a.get("live_version_id"),
            "draft_version_id": a.get("draft_version_id"),
            "live_version": live,
            "updated_at": a.get("updated_at"),
        })
    return {"agents": out}


@router.get("/agents/{agent_id}")
async def get_agent(agent_id: str, user: User = Depends(current_user)):
    db = get_db()
    a = await db.agents.find_one({"_id": ObjectId(agent_id), "org_id": user.org_id})
    if not a:
        raise HTTPException(404, "Not found")
    versions = []
    async for v in db.agent_versions.find({"agent_id": agent_id,
                                                "org_id": user.org_id}).sort("version", -1):
        v["id"] = str(v.pop("_id"))
        versions.append(v)
    a["id"] = str(a.pop("_id"))
    return {"agent": a, "versions": versions}


class AgentVersionSave(BaseModel):
    label: Optional[str] = None
    purpose: str
    tone: Optional[str] = None
    languages: List[str] = Field(default_factory=lambda: ["en"])
    allowed_tools: List[str] = Field(default_factory=list)
    qualification_questions: List[Dict[str, Any]] = Field(default_factory=list)
    escalation_rules: List[Dict[str, Any]] = Field(default_factory=list)
    allowed_claims: Optional[str] = None
    confidence_threshold: float = Field(default=0.4, ge=0.0, le=1.0)
    require_approval: bool = False
    system_prompt_override: Optional[str] = None
    model: str = "claude-sonnet-4-6"
    promote_to_live: bool = False


@router.post("/agents/{agent_id}/versions")
async def create_version(agent_id: str, req: AgentVersionSave,
                            user: User = Depends(require_roles("owner", "manager"))):
    db = get_db()
    a = await db.agents.find_one({"_id": ObjectId(agent_id), "org_id": user.org_id})
    if not a:
        raise HTTPException(404, "Agent not found")
    # Validate tools
    for t in req.allowed_tools:
        if t not in TOOLS:
            raise HTTPException(422, f"unknown tool {t!r}")
    latest = await db.agent_versions.find({"agent_id": agent_id, "org_id": user.org_id}) \
                                        .sort("version", -1).to_list(length=1)
    next_ver = 1 + (latest[0]["version"] if latest else 0)
    version = AgentVersion(
        org_id=user.org_id, agent_id=agent_id, version=next_ver,
        label=req.label, purpose=req.purpose,
        tone=req.tone or "warm, helpful", languages=req.languages,
        allowed_tools=req.allowed_tools,
        qualification_questions=[q for q in req.qualification_questions],
        escalation_rules=[r for r in req.escalation_rules],
        allowed_claims=req.allowed_claims,
        confidence_threshold=req.confidence_threshold,
        require_approval=req.require_approval,
        system_prompt_override=req.system_prompt_override,
        model=req.model,
        is_live=False, is_sandbox=False,
        created_by=str(user.id),
    )
    r = await db.agent_versions.insert_one(version.to_mongo())
    vid = str(r.inserted_id)
    update_set: Dict[str, Any] = {"draft_version_id": vid, "updated_at": utc_now_iso()}
    if req.promote_to_live:
        # Mark existing live as not-live, promote new
        if a.get("live_version_id"):
            await db.agent_versions.update_one({"_id": ObjectId(a["live_version_id"])},
                                                    {"$set": {"is_live": False}})
        await db.agent_versions.update_one({"_id": ObjectId(vid)},
                                                {"$set": {"is_live": True}})
        update_set["live_version_id"] = vid
        update_set["draft_version_id"] = None
    await db.agents.update_one({"_id": ObjectId(agent_id)}, {"$set": update_set})
    return {"id": vid, "version": next_ver, "is_live": req.promote_to_live}


@router.post("/agents/{agent_id}/promote/{version_id}")
async def promote_version(agent_id: str, version_id: str,
                             user: User = Depends(require_roles("owner", "manager"))):
    db = get_db()
    a = await db.agents.find_one({"_id": ObjectId(agent_id), "org_id": user.org_id})
    if not a:
        raise HTTPException(404, "Not found")
    v = await db.agent_versions.find_one({"_id": ObjectId(version_id),
                                                "agent_id": agent_id, "org_id": user.org_id})
    if not v:
        raise HTTPException(404, "Version not found")
    if a.get("live_version_id"):
        await db.agent_versions.update_one({"_id": ObjectId(a["live_version_id"])},
                                                {"$set": {"is_live": False}})
    await db.agent_versions.update_one({"_id": ObjectId(version_id)},
                                            {"$set": {"is_live": True}})
    await db.agents.update_one({"_id": ObjectId(agent_id)},
                                    {"$set": {"live_version_id": version_id,
                                                "updated_at": utc_now_iso()}})
    return {"ok": True, "live_version_id": version_id}


class AgentTogglePatch(BaseModel):
    enabled: bool


@router.patch("/agents/{agent_id}")
async def patch_agent(agent_id: str, patch: AgentTogglePatch,
                        user: User = Depends(require_roles("owner", "manager"))):
    db = get_db()
    r = await db.agents.update_one(
        {"_id": ObjectId(agent_id), "org_id": user.org_id},
        {"$set": {"enabled": patch.enabled, "updated_at": utc_now_iso()}},
    )
    if r.matched_count == 0:
        raise HTTPException(404, "Not found")
    return {"ok": True}


@router.get("/tools")
async def list_tools(user: User = Depends(current_user)):
    return {"tools": [{"name": t.name, "description": t.description,
                          "write": t.write, "input_schema": t.input_schema}
                        for t in TOOLS.values()]}


# ---------- Agent chat (dashboard sandbox) ----------

class SandboxRequest(BaseModel):
    agent_id: str
    version_id: Optional[str] = None      # test a specific version
    message: str
    conversation_id: Optional[str] = None


@router.post("/sandbox/message")
async def sandbox_chat(req: SandboxRequest, user: User = Depends(current_user)):
    """Sandbox chat: transient conversation, write tools no-op. Never creates real CRM."""
    db = get_db()
    a = await db.agents.find_one({"_id": ObjectId(req.agent_id), "org_id": user.org_id})
    if not a:
        raise HTTPException(404, "Agent not found")
    if req.conversation_id:
        conv = await db.chat_conversations.find_one({"_id": ObjectId(req.conversation_id),
                                                          "org_id": user.org_id})
        if not conv or not conv.get("is_sandbox"):
            raise HTTPException(400, "not a sandbox conversation")
        cid = req.conversation_id
    else:
        conv = ChatConversation(
            org_id=user.org_id, channel="chat",
            session_token=secrets.token_urlsafe(20),
            agent_id=req.agent_id,
            agent_version_id=req.version_id or a.get("live_version_id"),
            status="sandbox", started_at=utc_now_iso(),
            last_message_at=utc_now_iso(),
            is_sandbox=True,
        )
        r = await db.chat_conversations.insert_one(conv.to_mongo())
        cid = str(r.inserted_id)

    result = await run_turn(
        org_id=user.org_id, agent_id=req.agent_id,
        conversation_id=cid, user_text=req.message,
        website_slug=None, is_sandbox=True,
        agent_version_id=req.version_id,
    )
    return {"conversation_id": cid, **result}


# ---------- Public chat widget ----------

class WidgetStartRequest(BaseModel):
    website_slug: str


class WidgetMessageRequest(BaseModel):
    session_token: str
    message: str


@public_ai.post("/start")
async def widget_start(req: WidgetStartRequest, request: Request):
    from ..services import rate_limit as rl
    rl.check("public_chat_start", request, limit=30, window_seconds=60)
    db = get_db()
    site = await db.websites.find_one({"slug": req.website_slug.lower(), "status": "published"})
    if not site:
        raise HTTPException(404, "site not found")
    org_id = site["org_id"]
    # Global kill switch — platform-wide (founder-controlled)
    global_ks = await db.global_kill_switches.find_one({"key": "global"})
    if global_ks and (global_ks.get("all_public_chat_disabled") or global_ks.get("all_ai_disabled")):
        return {"disabled": True,
                 "greeting": "Chat is temporarily paused across Zanelvo. Please try again shortly."}
    agent = await db.agents.find_one({"org_id": org_id, "agent_type": "receptionist",
                                          "enabled": True})
    if not agent:
        return {"disabled": True,
                 "greeting": "Chat is offline right now — please use the contact form and we'll follow up."}
    ks = await db.kill_switches.find_one({"org_id": org_id})
    if ks and not ks.get("ai_enabled", True):
        return {"disabled": True,
                 "greeting": "Chat is temporarily paused — please leave a message via the contact form."}
    # Entitlement gate: over the monthly AI-conversations cap → honest fallback, never a raw 402
    from ..services.entitlements import check_metered
    if not await check_metered(org_id, "ai_conversations"):
        return {"disabled": True, "over_limit": True,
                 "greeting": ("Chat is unavailable right now. Please leave a message via the "
                                 "contact form and we'll get back to you shortly.")}
    prof = await db.business_profiles.find_one({"org_id": org_id})
    business_name = (prof or {}).get("business_name") or site.get("name") or "our team"
    conv = ChatConversation(
        org_id=org_id, channel="chat",
        session_token=secrets.token_urlsafe(24),
        website_slug=req.website_slug,
        agent_id=str(agent["_id"]),
        agent_version_id=agent.get("live_version_id"),
        status="ai", started_at=utc_now_iso(),
        last_message_at=utc_now_iso(),
    )
    r = await db.chat_conversations.insert_one(conv.to_mongo())
    return {
        "session_token": conv.session_token,
        "conversation_id": str(r.inserted_id),
        "greeting": f"Hi — I'm here to help with {business_name}. What do you need?",
    }


@public_ai.post("/message")
async def widget_message(req: WidgetMessageRequest, request: Request):
    from ..services import rate_limit as rl
    rl.check("public_chat_message", request, limit=60, window_seconds=60)
    db = get_db()
    conv = await db.chat_conversations.find_one({"session_token": req.session_token})
    if not conv:
        raise HTTPException(404, "session not found")
    if conv.get("status") == "human":
        return {"paused": True,
                 "note": "A team member is handling this conversation — please wait for their reply."}
    if conv.get("status") == "closed":
        raise HTTPException(400, "conversation is closed")
    # Visitor-triggered AI runs against the TENANT's budget (never unmetered) and is flagged public
    # so the per-visitor daily cap + plan cap apply. Over budget → honest fallback, not a raw 402.
    from ..services.usage import set_context as _set_ctx, enforce_budget as _enforce
    _xff = request.headers.get("x-forwarded-for")
    _ip = (_xff.split(",")[0].strip() if _xff else (request.client.host if request.client else "anon"))
    _set_ctx(org_id=conv["org_id"], feature="public_chat", public=True, user_id=None,
             visitor_ip=_ip, visitor_session=str(conv["_id"]))
    try:
        await _enforce(conv["org_id"], feature="public_chat", public=True)
    except HTTPException:
        return {"paused": True, "over_limit": True,
                "note": "Chat is unavailable right now — please use the contact form and we'll follow up."}
    result = await run_turn(
        org_id=conv["org_id"], agent_id=conv["agent_id"],
        conversation_id=str(conv["_id"]), user_text=req.message,
        website_slug=conv.get("website_slug"), is_sandbox=False,
        agent_version_id=conv.get("agent_version_id"),
    )
    return result


@public_ai.get("/messages")
async def widget_messages(session_token: str):
    db = get_db()
    conv = await db.chat_conversations.find_one({"session_token": session_token})
    if not conv:
        raise HTTPException(404, "session not found")
    msgs = []
    async for m in db.chat_messages.find({"conversation_id": str(conv["_id"])}) \
                                       .sort("created_at_iso", 1):
        msgs.append({"id": str(m["_id"]), "role": m.get("role"),
                        "content": m.get("content"),
                        "citations": m.get("citations") or [],
                        "confidence": m.get("confidence"),
                        "created_at": m.get("created_at_iso") or m.get("created_at")})
    return {"messages": msgs, "status": conv.get("status"),
             "needs_human": bool(conv.get("needs_human")),
             "escalation_reason": conv.get("escalation_reason")}


# ---------- Dashboard: conversations ----------

@router.get("/conversations")
async def list_conversations(user: User = Depends(current_user),
                                 status: Optional[str] = None,
                                 limit: int = Query(100, ge=1, le=200)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": user.org_id, "is_sandbox": {"$ne": True}}
    if status:
        q["status"] = status
    out = []
    async for c in db.chat_conversations.find(q).sort("last_message_at", -1).limit(limit):
        last = None
        async for m in db.chat_messages.find({"conversation_id": str(c["_id"])}) \
                                            .sort("created_at_iso", -1).limit(1):
            last = m.get("content")
        out.append({"id": str(c["_id"]), "channel": c.get("channel"),
                     "status": c.get("status"), "needs_human": c.get("needs_human"),
                     "escalation_reason": c.get("escalation_reason"),
                     "started_at": c.get("started_at"),
                     "last_message_at": c.get("last_message_at"),
                     "assigned_user_id": c.get("assigned_user_id"),
                     "visitor_meta": c.get("visitor_meta") or {},
                     "last_message": last})
    return {"conversations": out}


@router.get("/conversations/{cid}")
async def get_conversation(cid: str, user: User = Depends(current_user)):
    db = get_db()
    c = await db.chat_conversations.find_one({"_id": ObjectId(cid), "org_id": user.org_id})
    if not c:
        raise HTTPException(404, "Not found")
    msgs = []
    async for m in db.chat_messages.find({"conversation_id": cid}).sort("created_at_iso", 1):
        msgs.append({"id": str(m["_id"]), "role": m.get("role"),
                        "content": m.get("content"),
                        "citations": m.get("citations") or [],
                        "confidence": m.get("confidence"),
                        "author_user_id": m.get("author_user_id"),
                        "created_at": m.get("created_at_iso") or m.get("created_at")})
    interactions = []
    async for i in db.agent_interactions.find({"conversation_id": cid}) \
                                             .sort("created_at", -1).limit(50):
        interactions.append({"id": str(i["_id"]), "action": i.get("action"),
                                "model": i.get("model"),
                                "total_tokens": i.get("total_tokens"),
                                "cost_cents": i.get("cost_cents"),
                                "latency_ms": i.get("latency_ms"),
                                "tools_used": i.get("tools_used") or [],
                                "confidence": i.get("confidence"),
                                "created_at": i.get("created_at")})
    c["id"] = str(c.pop("_id"))
    return {"conversation": c, "messages": msgs, "interactions": interactions}


class TakeoverRequest(BaseModel):
    reply: Optional[str] = None


@router.post("/conversations/{cid}/takeover")
async def takeover(cid: str,
                     req: Optional[TakeoverRequest] = Body(default=None),
                     user: User = Depends(current_user)):
    """Human takes over — AI is server-side paused for this conversation.
    Body is optional; pass {reply: "..."} to also post the first human message.
    """
    db = get_db()
    c = await db.chat_conversations.find_one({"_id": ObjectId(cid), "org_id": user.org_id})
    if not c:
        raise HTTPException(404, "Not found")
    await db.chat_conversations.update_one(
        {"_id": ObjectId(cid)},
        {"$set": {"status": "human", "assigned_user_id": str(user.id),
                    "needs_human": False,
                    "last_message_at": utc_now_iso()}},
    )
    if req and req.reply:
        msg = ChatMessage(org_id=user.org_id, conversation_id=cid, role="human",
                            content=req.reply, author_user_id=str(user.id),
                            created_at_iso=utc_now_iso())
        await db.chat_messages.insert_one(msg.to_mongo())
    return {"ok": True, "status": "human"}


@router.post("/conversations/{cid}/resume")
async def resume(cid: str, user: User = Depends(current_user)):
    """Hand back to AI."""
    db = get_db()
    c = await db.chat_conversations.find_one({"_id": ObjectId(cid), "org_id": user.org_id})
    if not c:
        raise HTTPException(404, "Not found")
    await db.chat_conversations.update_one(
        {"_id": ObjectId(cid)},
        {"$set": {"status": "ai", "assigned_user_id": None,
                    "last_message_at": utc_now_iso()}},
    )
    return {"ok": True, "status": "ai"}


class HumanReplyRequest(BaseModel):
    reply: str


@router.post("/conversations/{cid}/reply")
async def human_reply(cid: str, req: HumanReplyRequest, user: User = Depends(current_user)):
    db = get_db()
    c = await db.chat_conversations.find_one({"_id": ObjectId(cid), "org_id": user.org_id})
    if not c:
        raise HTTPException(404, "Not found")
    # Also mark taken-over if not already
    updates: Dict[str, Any] = {"last_message_at": utc_now_iso()}
    if c.get("status") != "human":
        updates.update({"status": "human", "assigned_user_id": str(user.id),
                          "needs_human": False})
    await db.chat_conversations.update_one({"_id": ObjectId(cid)}, {"$set": updates})
    msg = ChatMessage(org_id=user.org_id, conversation_id=cid, role="human",
                        content=req.reply, author_user_id=str(user.id),
                        created_at_iso=utc_now_iso())
    r = await db.chat_messages.insert_one(msg.to_mongo())
    return {"ok": True, "message_id": str(r.inserted_id), "status": "human"}


# ---------- Cost / audit rollup ----------

@router.get("/usage")
async def usage_rollup(days: int = Query(30, ge=1, le=90),
                          user: User = Depends(current_user)):
    db = get_db()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat().replace("+00:00", "Z")
    agents_map: Dict[str, Dict[str, Any]] = {}
    total = {"interactions": 0, "tokens": 0, "cost_cents": 0.0}
    async for a in db.agents.find({"org_id": user.org_id}):
        agents_map[str(a["_id"])] = {
            "id": str(a["_id"]), "name": a.get("name"), "agent_type": a.get("agent_type"),
            "interactions": 0, "tokens": 0, "cost_cents": 0.0,
        }
    async for i in db.agent_interactions.find({"org_id": user.org_id,
                                                    "created_at": {"$gte": since},
                                                    "is_sandbox": {"$ne": True}}):
        a = agents_map.get(i.get("agent_id"))
        if a:
            a["interactions"] += 1
            a["tokens"] += int(i.get("total_tokens") or 0)
            a["cost_cents"] += float(i.get("cost_cents") or 0)
        total["interactions"] += 1
        total["tokens"] += int(i.get("total_tokens") or 0)
        total["cost_cents"] += float(i.get("cost_cents") or 0)
    total["cost_cents"] = round(total["cost_cents"], 2)
    for a in agents_map.values():
        a["cost_cents"] = round(a["cost_cents"], 2)
    return {"days": days, "total": total, "per_agent": list(agents_map.values())}


# ---------- Call simulator (voice honesty) ----------

class CallStartRequest(BaseModel):
    caller_name: Optional[str] = None
    caller_phone: Optional[str] = None


@router.post("/call/start")
async def call_start(req: CallStartRequest, user: User = Depends(current_user)):
    db = get_db()
    agent = await db.agents.find_one({"org_id": user.org_id, "agent_type": "receptionist"})
    if not agent:
        raise HTTPException(400, "no receptionist configured")
    conv = ChatConversation(
        org_id=user.org_id, channel="call",
        session_token=secrets.token_urlsafe(20),
        agent_id=str(agent["_id"]),
        agent_version_id=agent.get("live_version_id"),
        status="ai", started_at=utc_now_iso(),
        last_message_at=utc_now_iso(),
        visitor_meta={"name": req.caller_name, "phone": req.caller_phone},
    )
    r = await db.chat_conversations.insert_one(conv.to_mongo())
    cid = str(r.inserted_id)
    call = CallRecord(org_id=user.org_id, conversation_id=cid,
                        direction="inbound", duration_seconds=0,
                        transcript="", ai_summary="",
                        extracted_fields={}, outcome="no_action",
                        simulated=True, cost_cents=0.0)
    cr = await db.call_records.insert_one(call.to_mongo())
    return {"conversation_id": cid, "call_record_id": str(cr.inserted_id),
             "session_token": conv.session_token,
             "greeting": "Thanks for calling — how can I help?"}


class CallTurnRequest(BaseModel):
    call_record_id: str
    caller_message: str


@router.post("/call/turn")
async def call_turn(req: CallTurnRequest, user: User = Depends(current_user)):
    db = get_db()
    call = await db.call_records.find_one({"_id": ObjectId(req.call_record_id),
                                                "org_id": user.org_id})
    if not call:
        raise HTTPException(404, "call not found")
    conv_id = call["conversation_id"]
    conv = await db.chat_conversations.find_one({"_id": ObjectId(conv_id),
                                                       "org_id": user.org_id})
    if not conv:
        raise HTTPException(404, "conversation not found")
    result = await run_turn(
        org_id=user.org_id, agent_id=conv["agent_id"],
        conversation_id=conv_id, user_text=req.caller_message,
        website_slug=None, is_sandbox=False,
        agent_version_id=conv.get("agent_version_id"),
        call_record_id=req.call_record_id,
    )
    return result


class CallEndRequest(BaseModel):
    call_record_id: str
    duration_seconds: int = 0


@router.post("/call/end")
async def call_end(req: CallEndRequest, user: User = Depends(current_user)):
    """Close a simulated call — build transcript, extract fields, guess outcome."""
    db = get_db()
    call = await db.call_records.find_one({"_id": ObjectId(req.call_record_id),
                                                "org_id": user.org_id})
    if not call:
        raise HTTPException(404, "call not found")
    conv_id = call["conversation_id"]
    lines: List[str] = []
    booked = False
    extracted: Dict[str, Any] = {}
    async for m in db.chat_messages.find({"conversation_id": conv_id}).sort("created_at_iso", 1):
        role = m.get("role")
        who = "Caller" if role == "visitor" else ("Agent" if role == "ai" else role.title())
        lines.append(f"{who}: {m.get('content')}")
        tc = m.get("tool_calls") or []
        for t in tc:
            if t.get("name") == "create_booking" and t.get("ok"):
                booked = True
            if t.get("name") == "take_message" and t.get("ok"):
                extracted.setdefault("captured_lead", True)
    transcript = "\n".join(lines)
    outcome = "booked" if booked else ("took_message" if extracted.get("captured_lead") else "no_action")
    # Naive AI summary from the transcript
    summary = ("Call summary: " + " ".join(l.split(": ", 1)[-1] for l in lines[:6]))[:500]
    total_cost = 0.0
    async for i in db.agent_interactions.find({"call_record_id": req.call_record_id}):
        total_cost += float(i.get("cost_cents") or 0)
    await db.call_records.update_one(
        {"_id": ObjectId(req.call_record_id)},
        {"$set": {"transcript": transcript, "ai_summary": summary,
                    "duration_seconds": max(0, req.duration_seconds),
                    "outcome": outcome, "cost_cents": round(total_cost, 2),
                    "ended_at": utc_now_iso(), "updated_at": utc_now_iso(),
                    "extracted_fields": extracted}},
    )
    await db.chat_conversations.update_one({"_id": ObjectId(conv_id)},
                                                {"$set": {"status": "closed"}})
    return {"ok": True, "outcome": outcome, "transcript": transcript, "summary": summary,
             "cost_cents": round(total_cost, 2)}


@router.get("/calls")
async def list_calls(limit: int = Query(50, ge=1, le=200),
                        user: User = Depends(current_user)):
    db = get_db()
    out = []
    async for c in db.call_records.find({"org_id": user.org_id}) \
                                       .sort("created_at", -1).limit(limit):
        out.append({"id": str(c["_id"]), "conversation_id": c.get("conversation_id"),
                     "direction": c.get("direction"),
                     "duration_seconds": c.get("duration_seconds"),
                     "outcome": c.get("outcome"),
                     "ai_summary": c.get("ai_summary"),
                     "simulated": c.get("simulated", True),
                     "cost_cents": c.get("cost_cents"),
                     "created_at": c.get("created_at"),
                     "ended_at": c.get("ended_at")})
    return {"calls": out}


@router.get("/calls/{call_id}")
async def get_call(call_id: str, user: User = Depends(current_user)):
    db = get_db()
    c = await db.call_records.find_one({"_id": ObjectId(call_id), "org_id": user.org_id})
    if not c:
        raise HTTPException(404, "Not found")
    c["id"] = str(c.pop("_id"))
    return c


# ---------- Voice provider adapter cards (honest state) ----------

@router.get("/voice/providers")
async def voice_providers(user: User = Depends(current_user)):
    """Honest voice-provider state from the platform Setup Center (never 'Configured' without credentials).
    Tenant routing is by the VERIFIED dialed number — there is no `?org_id=` selector anymore."""
    from ..services import integrations as _integ
    raw = (await _integ._raw()).get("voice", {}) or {}  # noqa: SLF001
    retell_ok = bool(raw.get("retell_api_key"))
    twilio_ok = bool(raw.get("twilio_account_sid") and raw.get("twilio_auth_token"))
    telnyx_ok = bool(raw.get("telnyx_api_key"))
    def _card(key, label, ok, endpoint, steps, docs):
        return {"key": key, "label": label, "is_connected": ok,
                "status": "connected" if ok else "not_connected",
                "honest_status": (f"Connected — {label} credentials present in Staff Setup Center; calls route by the dialed number."
                                  if ok else f"Not connected — a platform admin must add {label} credentials in Staff Setup Center → Voice."),
                "webhook_url": endpoint, "bind_steps": steps, "docs": docs}
    return {"providers": [
        _card("retell", "Retell", retell_ok, "/api/voice/retell/webhook",
              ["Create a Retell agent in the Retell dashboard.",
               "Set the agent's Webhook URL to the endpoint above (prefixed with the backend URL).",
               "Attach a phone number you bought in Zanelvo → Numbers; calls route to that number's receptionist."],
              "POST /api/voice/retell/webhook — signature verified; tenant resolved from call.to_number."),
        _card("twilio", "Twilio Voice", twilio_ok, "/api/voice/twilio/inbound",
              ["In Twilio Console open Phone Numbers > your number > Voice.",
               "Set 'A CALL COMES IN' to Webhook, HTTP POST, URL = the endpoint above.",
               "Incoming calls speak with the receptionist bound to that number."],
              "POST /api/voice/twilio/inbound — X-Twilio-Signature verified; tenant resolved from the To number."),
        _card("telnyx", "Telnyx", telnyx_ok, "/api/voice/telnyx/inbound",
              ["Add the Telnyx API key + connection id in Staff Setup Center → Voice.",
               "Buy numbers in Zanelvo → Numbers; they are provisioned on the Telnyx connection."],
              "Recommended carrier for managed numbers."),
    ]}


# ---------- Admin daily digest ----------

@router.get("/digest/today")
async def digest_today(user: User = Depends(current_user)):
    db = get_db()
    org_id = user.org_id
    today = datetime.now(timezone.utc).date().isoformat()
    tomorrow = (datetime.now(timezone.utc).date() + timedelta(days=1)).isoformat()

    today_bookings = await db.bookings.count_documents({
        "org_id": org_id, "start_at": {"$gte": today, "$lt": tomorrow},
        "status": {"$ne": "cancelled"},
    })
    since = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat().replace("+00:00", "Z")
    new_leads = await db.contacts.count_documents({"org_id": org_id, "created_at": {"$gte": since}})
    overdue_invoices = await db.invoices.count_documents({"org_id": org_id, "status": "overdue"})
    pending_approvals = await db.quotes.count_documents({"org_id": org_id,
                                                             "status": "pending_approval"})
    conflicts = 0  # (no explicit scheduling-conflict store yet — placeholder for later phase)
    summary = (f"Today: {today_bookings} bookings, {new_leads} new leads in 24h, "
                f"{overdue_invoices} overdue invoices, {pending_approvals} quotes pending approval.")
    digest = DailyDigest(
        org_id=org_id, for_date=today,
        todays_bookings_count=today_bookings, new_leads_count=new_leads,
        overdue_invoices_count=overdue_invoices,
        pending_approvals_count=pending_approvals,
        scheduling_conflicts=conflicts,
        summary_markdown=summary,
        facts={"today_bookings": today_bookings, "new_leads": new_leads,
                "overdue_invoices": overdue_invoices,
                "pending_approvals": pending_approvals},
    ).to_mongo()
    # Idempotent replace-for-today
    await db.daily_digests.update_one({"org_id": org_id, "for_date": today},
                                          {"$set": digest}, upsert=True)
    return {"for_date": today, "summary": summary,
             "todays_bookings_count": today_bookings, "new_leads_count": new_leads,
             "overdue_invoices_count": overdue_invoices,
             "pending_approvals_count": pending_approvals,
             "scheduling_conflicts": conflicts}


# ---------- Sales / reactivation drafts (grounded, DRAFT ONLY) ----------

class SalesDraftReq(BaseModel):
    contact_id: str
    context: Optional[str] = None       # e.g. an inbound message
    goal: Optional[str] = "first_response"


@router.post("/sales/draft")
async def sales_draft(req: SalesDraftReq, user: User = Depends(current_user)):
    """Draft a first-response for owner review. Nothing sent."""
    db = get_db()
    contact = await db.contacts.find_one({"_id": ObjectId(req.contact_id),
                                                "org_id": user.org_id})
    if not contact:
        raise HTTPException(404, "contact not found")
    agent = await db.agents.find_one({"org_id": user.org_id, "agent_type": "sales"})
    if not agent:
        raise HTTPException(400, "sales agent not configured")
    # Reuse the standard run_turn — build a transient conversation, then discard.
    conv = ChatConversation(
        org_id=user.org_id, channel="chat",
        session_token=secrets.token_urlsafe(16),
        agent_id=str(agent["_id"]),
        agent_version_id=agent.get("live_version_id"),
        status="sandbox", is_sandbox=True,
        started_at=utc_now_iso(), last_message_at=utc_now_iso(),
    )
    r = await db.chat_conversations.insert_one(conv.to_mongo())
    cid = str(r.inserted_id)
    user_prompt = (f"Draft a first response to lead {contact.get('display_name')} "
                     f"({contact.get('emails', [''])[0]}). Goal: {req.goal}. "
                     f"Context: {req.context or 'no additional context'}. "
                     "Return the draft as reply_text. Do not include tool calls.")
    result = await run_turn(
        org_id=user.org_id, agent_id=str(agent["_id"]),
        conversation_id=cid, user_text=user_prompt,
        website_slug=None, is_sandbox=True,
    )
    return {"draft": result.get("reply"),
             "confidence": result.get("confidence"),
             "citations": result.get("citations")}


class ReactivationSegmentReq(BaseModel):
    stale_days: int = 30


@router.post("/reactivation/segment")
async def reactivation_segment(req: ReactivationSegmentReq, user: User = Depends(current_user)):
    """Return a segment of stale contacts (no activity in stale_days). Draft messages happen client-side."""
    db = get_db()
    cutoff = (datetime.now(timezone.utc) - timedelta(days=req.stale_days)).isoformat().replace("+00:00", "Z")
    hits = []
    async for c in db.contacts.find({"org_id": user.org_id,
                                          "last_activity_at": {"$lt": cutoff}}) \
                                   .sort("last_activity_at", 1).limit(50):
        hits.append({"id": str(c["_id"]), "display_name": c.get("display_name"),
                        "emails": c.get("emails") or [], "last_activity_at": c.get("last_activity_at")})
    return {"stale_days": req.stale_days, "count": len(hits), "contacts": hits}
