import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { FileText, Plus, Check, X, Copy, ExternalLink } from "lucide-react";

const STATUS_TONES = {
    draft: "bg-zinc-100 text-zinc-700",
    pending_approval: "bg-amber-100 text-amber-800",
    sent: "bg-blue-100 text-blue-800",
    viewed: "bg-indigo-100 text-indigo-800",
    accepted: "bg-emerald-100 text-emerald-800",
    declined: "bg-zinc-100 text-zinc-500",
    rejected: "bg-red-100 text-red-800",
    expired: "bg-zinc-100 text-zinc-500",
};

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

export default function Quotes() {
    const [tab, setTab] = useState("all");
    const [quotes, setQuotes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [approvalQuote, setApprovalQuote] = useState(null);
    const [approvalNote, setApprovalNote] = useState("");
    const navigate = useNavigate();

    async function load() {
        setLoading(true);
        try {
            const params = tab === "all" ? "" : `?status=${tab}`;
            const { data } = await api.get(`/quotes${params}`);
            setQuotes(data.quotes || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [tab]);

    const pendingCount = useMemo(() => quotes.filter((q) => q.approval_state === "pending").length, [quotes]);

    async function actOnApproval(approve) {
        if (!approvalQuote) return;
        try {
            await api.post(`/quotes/${approvalQuote.id}/approve`, { approve, note: approvalNote.trim() || null });
            toast.success(approve ? "Quote approved" : "Quote rejected");
            setApprovalQuote(null); setApprovalNote("");
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Action failed");
        }
    }

    async function sendQuote(qid) {
        try {
            await api.post(`/quotes/${qid}/send`);
            toast.success("Sent to customer.");
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not send"); }
    }

    return (
        <div className="p-6" data-testid="quotes-page">
            <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Quotes</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Quotes</h1>
                    <p className="text-sm text-zinc-500 mt-1">Send priced work. Approvals kick in above your thresholds. Convert to an invoice or job on accept.</p>
                </div>
                <Button onClick={() => navigate("/app/quotes/new")} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="new-quote-btn">
                    <Plus className="w-4 h-4 mr-1" /> New quote
                </Button>
            </div>

            <Tabs value={tab} onValueChange={setTab}>
                <TabsList data-testid="quotes-tabs">
                    <TabsTrigger value="all" data-testid="quotes-tab-all">All</TabsTrigger>
                    <TabsTrigger value="pending_approval" data-testid="quotes-tab-pending">
                        Pending approval {pendingCount ? <span className="ml-1 rounded-full bg-amber-200 text-amber-900 text-[10px] px-1.5">{pendingCount}</span> : null}
                    </TabsTrigger>
                    <TabsTrigger value="sent" data-testid="quotes-tab-sent">Sent</TabsTrigger>
                    <TabsTrigger value="accepted" data-testid="quotes-tab-accepted">Accepted</TabsTrigger>
                </TabsList>

                <TabsContent value={tab} className="mt-4">
                    <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Number</TableHead>
                                    <TableHead>Contact</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Total</TableHead>
                                    <TableHead>Portal</TableHead>
                                    <TableHead></TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {quotes.map((q) => (
                                    <TableRow key={q.id} data-testid={`quote-row-${q.id}`} className="hover:bg-brand-cream/30">
                                        <TableCell className="font-mono text-xs">
                                            <button onClick={() => navigate(`/app/quotes/${q.id}`)} className="text-brand-copper hover:underline" data-testid={`quote-open-${q.id}`}>
                                                {q.number || q.id.slice(0, 8)}
                                            </button>
                                            {q.approval_reason && <div className="text-[10px] text-amber-700 mt-0.5 font-normal">{q.approval_reason}</div>}
                                        </TableCell>
                                        <TableCell className="text-xs text-zinc-600">{q.contact_id ? q.contact_id.slice(-6) : "—"}</TableCell>
                                        <TableCell>
                                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs ${STATUS_TONES[q.status] || "bg-zinc-100"}`}>{q.status}</span>
                                        </TableCell>
                                        <TableCell className="font-mono">{money(q.totals?.total_cents, q.currency)}</TableCell>
                                        <TableCell>
                                            {q.portal_token && (
                                                <button
                                                    className="text-xs text-brand-copper hover:underline inline-flex items-center gap-1"
                                                    data-testid={`quote-copy-portal-${q.id}`}
                                                    onClick={() => {
                                                        const url = `${window.location.origin}/portal/quote/${q.id}?tk=${q.portal_token}`;
                                                        navigator.clipboard.writeText(url);
                                                        toast.success("Portal link copied");
                                                    }}
                                                ><Copy className="w-3 h-3" /> Copy link</button>
                                            )}
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-1">
                                                {q.approval_state === "pending" && (
                                                    <Button size="sm" variant="outline" onClick={() => setApprovalQuote(q)} data-testid={`quote-review-${q.id}`}>
                                                        Review
                                                    </Button>
                                                )}
                                                {q.status === "draft" && q.approval_state !== "pending" && (
                                                    <Button size="sm" variant="outline" onClick={() => sendQuote(q.id)} data-testid={`quote-send-${q.id}`}>Send</Button>
                                                )}
                                                {q.portal_token && (
                                                    <a href={`/portal/quote/${q.id}?tk=${q.portal_token}`} target="_blank" rel="noreferrer">
                                                        <Button size="sm" variant="ghost" data-testid={`quote-open-portal-${q.id}`}><ExternalLink className="w-3.5 h-3.5" /></Button>
                                                    </a>
                                                )}
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {!loading && !quotes.length && (
                                    <TableRow><TableCell colSpan={6} className="text-center text-zinc-500 py-10" data-testid="quotes-empty">
                                        {tab === "pending_approval" ? "No quotes need approval right now." : "No quotes yet. Create your first."}
                                    </TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </TabsContent>
            </Tabs>

            {/* Approval Dialog */}
            <Dialog open={!!approvalQuote} onOpenChange={(o) => { if (!o) { setApprovalQuote(null); setApprovalNote(""); } }}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Review quote {approvalQuote?.number}</DialogTitle>
                        <DialogDescription>Approve or reject this quote. Your note is recorded on the quote's audit trail.</DialogDescription>
                    </DialogHeader>
                    {approvalQuote && (
                        <>
                            <div className="rounded-md bg-amber-50 border border-amber-200 text-amber-900 p-3 text-sm" data-testid="approval-reason">
                                {approvalQuote.approval_reason || "Requires approval"}
                            </div>
                            <div className="text-sm text-zinc-600">Total: <span className="font-mono">{money(approvalQuote.totals?.total_cents, approvalQuote.currency)}</span></div>
                            <Textarea
                                value={approvalNote}
                                onChange={(e) => setApprovalNote(e.target.value)}
                                placeholder="Approval note (optional)"
                                rows={3}
                                data-testid="approval-note"
                            />
                        </>
                    )}
                    <DialogFooter>
                        <Button variant="destructive" onClick={() => actOnApproval(false)} data-testid="approval-reject-btn"><X className="w-4 h-4 mr-1" /> Reject</Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={() => actOnApproval(true)} data-testid="approval-approve-btn"><Check className="w-4 h-4 mr-1" /> Approve</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
