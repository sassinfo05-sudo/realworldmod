import usePageMeta from "@/hooks/usePageMeta";
import { useEffect, useMemo, useState, Fragment } from "react";
import PublicNav from "@/components/PublicNav";
import api from "@/lib/api";
import { Link } from "react-router-dom";
import { useBrand } from "@/context/BrandContext";
import { Button } from "@/components/ui/button";
import { Check, Minus, Sparkles, ShieldCheck, Zap } from "lucide-react";

function fmtNum(v) {
    if (typeof v !== "number") return v;
    if (v >= 100000) return "Unlimited";
    return v.toLocaleString();
}

function CellValue({ type, value, available = true, note = "" }) {
    if (!available && value) {
        return <span className="inline-flex items-center rounded-full bg-zinc-100 px-2 py-0.5 text-[11px] text-zinc-600" title={note} data-testid="feature-not-yet-available">Not yet available</span>;
    }
    if (type === "bool") {
        return value
            ? <Check className="w-4 h-4 text-brand-copper inline" aria-label="Included" />
            : <Minus className="w-4 h-4 text-zinc-300 inline" aria-label="Not included" />;
    }
    return <span className="text-zinc-700">{fmtNum(value)}</span>;
}

export default function Pricing() {
    usePageMeta("Pricing");
    const brand = useBrand();
    const [plans, setPlans] = useState([]);
    const [matrix, setMatrix] = useState({ groups: [] });
    const [loading, setLoading] = useState(true);
    const [annual, setAnnual] = useState(true);

    useEffect(() => {
        api.get("/billing/plans")
            .then((r) => { setPlans(r.data?.plans || []); setMatrix(r.data?.matrix || { groups: [] }); })
            .finally(() => setLoading(false));
    }, []);

    const codes = useMemo(() => plans.map((p) => p.code), [plans]);

    const priceOf = (p) => {
        if (!p.price_usd) return { big: "0", sub: "Free forever" };
        if (annual && p.annual_price_usd) {
            const monthly = Math.round(p.annual_price_usd / 12);
            return { big: `${monthly}`, sub: `$${p.annual_price_usd.toLocaleString()} billed yearly` };
        }
        return { big: `${p.price_usd}`, sub: "billed monthly" };
    };
    const savingsPct = (p) => {
        if (!p.price_usd || !p.annual_price_usd) return 0;
        return Math.round((1 - (p.annual_price_usd / 12) / p.price_usd) * 100);
    };
    const topSaving = plans.reduce((m, p) => Math.max(m, savingsPct(p)), 0);

    return (
        <div className="min-h-screen bg-brand-surface text-brand-ink">
            <PublicNav />

            {/* Hero */}
            <section className="relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-brand-cream/50 to-transparent pointer-events-none" />
                <div className="relative mx-auto max-w-6xl px-6 pt-20 md:pt-28 pb-6 text-center">
                    <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-4">
                        <Sparkles className="w-3.5 h-3.5" /> Simple, honest pricing
                    </div>
                    <h1 className="font-display text-4xl md:text-6xl text-brand-ink font-medium leading-[1.05]">
                        One platform. Every tool<br className="hidden md:block" /> your business needs.
                    </h1>
                    <p className="mt-5 text-zinc-600 max-w-2xl mx-auto text-lg">
                        Start free and switch on websites, an online store, marketing and AI employees as you grow.
                        No add-ons, no surprises — cancel anytime.
                    </p>

                    <div className="mt-8 inline-flex items-center gap-1 bg-white border border-brand-line rounded-full p-1 shadow-sm" data-testid="billing-toggle">
                        <button onClick={() => setAnnual(false)} data-testid="toggle-monthly"
                            className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${!annual ? "bg-brand-ink text-white" : "text-zinc-500"}`}>Monthly</button>
                        <button onClick={() => setAnnual(true)} data-testid="toggle-annual"
                            className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${annual ? "bg-brand-ink text-white" : "text-zinc-500"}`}>
                            Annual{topSaving ? ` · save up to ${topSaving}%` : ""}
                        </button>
                    </div>
                </div>
            </section>

            {/* Plan cards */}
            <section className="mx-auto max-w-6xl px-6 pb-10">
                <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4" data-testid="pricing-grid">
                    {loading && <div className="text-zinc-500 col-span-full text-center py-10">Loading plans…</div>}
                    {plans.map((p) => {
                        const pr = priceOf(p);
                        const sv = savingsPct(p);
                        return (
                            <div key={p.code} data-testid={`plan-${p.code}`}
                                className={`relative rounded-2xl p-5 border bg-white flex flex-col transition-all hover:-translate-y-0.5 hover:shadow-lg animate-fade-in-up ${
                                    p.highlight ? "border-brand-copper shadow-md ring-1 ring-brand-copper/20 lg:-mt-2 lg:mb-2" : "border-brand-line"
                                }`}>
                                {p.badge && (
                                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-semibold uppercase tracking-widest text-white bg-brand-copper rounded-full px-3 py-1 shadow">
                                        {p.badge}
                                    </div>
                                )}
                                <div className="font-display text-lg text-brand-ink mt-1">{p.name}</div>
                                <div className="text-xs text-zinc-400 mt-0.5 min-h-[2rem]">{p.audience}</div>
                                <div className="mt-4">
                                    <div className="flex items-end gap-1">
                                        <span className="font-display text-4xl text-brand-ink">${pr.big}</span>
                                        {p.price_usd > 0 && <span className="text-sm text-zinc-500 mb-1">/mo</span>}
                                    </div>
                                    <div className="text-xs text-zinc-400 mt-1">{pr.sub}</div>
                                    {annual && sv > 0 && <div className="text-xs text-emerald-600 mt-0.5 font-medium">Save {sv}%</div>}
                                </div>
                                <Link to="/signup" className="block mt-5" data-testid={`plan-${p.code}-cta`}>
                                    <Button className={`w-full ${p.highlight ? "bg-brand-copper hover:bg-brand-copperHover text-white" : "bg-brand-ink hover:bg-black text-white"}`}>
                                        {p.cta}
                                    </Button>
                                </Link>
                                <ul className="mt-5 space-y-2 text-sm border-t border-brand-line/60 pt-4">
                                    {(p.features || []).map((f) => (
                                        <li key={f} className="flex items-start gap-2">
                                            <Check className="w-4 h-4 mt-0.5 text-brand-copper shrink-0" />
                                            <span className="text-zinc-700 leading-snug">{f}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        );
                    })}
                </div>

                {/* Trust strip */}
                <div className="mt-10 grid sm:grid-cols-3 gap-4 text-sm">
                    {[
                        [ShieldCheck, "No lock-in", "Cancel or downgrade anytime. Your data is always exportable."],
                        [Zap, "Everything included", "No per-feature add-ons — your plan unlocks whole toolsets."],
                        [Sparkles, "AI on every plan", "Even Free includes the AI website builder to get you live fast."],
                    ].map(([Icon, t, d]) => (
                        <div key={t} className="rounded-xl border border-brand-line bg-white p-4 flex gap-3">
                            <Icon className="w-5 h-5 text-brand-copper shrink-0 mt-0.5" />
                            <div><div className="font-medium text-brand-ink">{t}</div><div className="text-zinc-500 mt-0.5">{d}</div></div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Full comparison matrix */}
            {!loading && plans.length > 0 && (
                <section className="mx-auto max-w-6xl px-6 pb-24">
                    <div className="text-center max-w-2xl mx-auto">
                        <h2 className="font-display text-3xl text-brand-ink">Compare every feature</h2>
                        <p className="mt-2 text-sm text-zinc-500">A check means it&apos;s included. Numbers are your monthly allowances on that plan.</p>
                    </div>
                    <div className="mt-8 overflow-x-auto rounded-2xl border border-brand-line bg-white shadow-sm">
                        <table className="w-full text-sm min-w-[720px]" data-testid="capability-matrix">
                            <thead className="sticky top-0">
                                <tr className="border-b border-brand-line bg-brand-cream/40">
                                    <th className="text-left font-medium text-zinc-500 p-4 w-[32%]">Feature</th>
                                    {plans.map((p) => (
                                        <th key={p.code} className={`p-4 text-center font-semibold ${p.highlight ? "text-brand-copper" : "text-brand-ink"}`}>
                                            {p.name}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {matrix.groups.map((g) => (
                                    <Fragment key={g.name}>
                                        <tr className="bg-brand-cream/70">
                                            <td colSpan={plans.length + 1} className="px-4 py-2.5 text-[11px] uppercase tracking-widest text-brand-copper font-bold">{g.name}</td>
                                        </tr>
                                        {g.rows.map((row) => (
                                            <tr key={row.key} className="border-b border-brand-line/60 last:border-0 hover:bg-brand-cream/20">
                                                <td className="p-4 text-zinc-700">{row.label}</td>
                                                {codes.map((c) => (
                                                    <td key={c} className="p-4 text-center">
                                                        <CellValue type={row.type} value={row.values[c]} available={row.available !== false} note={row.note} />
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </Fragment>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    <div className="mt-12 text-center rounded-2xl border border-brand-line bg-gradient-to-br from-brand-ink to-zinc-800 text-white p-10">
                        <h3 className="font-display text-2xl md:text-3xl">Ready to build with {brand?.name || "Zanelvo"}?</h3>
                        <p className="mt-2 text-zinc-300 max-w-xl mx-auto">Launch a site free in minutes, then turn on the tools you need. No credit card required to start.</p>
                        <Link to="/signup" className="inline-block mt-6"><Button className="bg-brand-copper hover:bg-brand-copperHover text-white px-8">Start free</Button></Link>
                    </div>
                </section>
            )}
        </div>
    );
}
