import usePageMeta from "@/hooks/usePageMeta";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PublicNav from "@/components/PublicNav";
import SocialButtons from "@/components/SocialButtons";
import { useAuth } from "@/context/AuthContext";
import { useBrand } from "@/context/BrandContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function Signup() {
    usePageMeta("Create account");
    const [fullName, setFullName] = useState("");
    const [businessName, setBusinessName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [busy, setBusy] = useState(false);
    const [showEmail, setShowEmail] = useState(true);
    const { signup } = useAuth();
    const brand = useBrand();
    const navigate = useNavigate();

    async function onSubmit(e) {
        e.preventDefault();
        if (password.length < 8) {
            toast.error("Password must be at least 8 characters.");
            return;
        }
        setBusy(true);
        try {
            await signup({
                full_name: fullName || null,
                business_name: businessName || null,
                email: email.trim(),
                password,
            });
            toast.success("Account created.");
            navigate("/onboarding");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Signup failed");
        } finally {
            setBusy(false);
        }
    }

    return (
        <div className="min-h-screen bg-brand-surface">
            <PublicNav />
            <div className="mx-auto max-w-md px-6 py-16">
                <h1 className="font-display text-3xl text-brand-ink font-medium" data-testid="signup-title">
                    Let's build your workspace.
                </h1>
                <p className="mt-2 text-sm text-zinc-500">
                    Ninety seconds to your first live preview. No card.
                </p>
                <div className="mt-8">
                    <SocialButtons mode="signup" />
                </div>
                {!showEmail ? (
                    <button type="button" onClick={() => setShowEmail(true)} data-testid="signup-use-email"
                        className="mt-5 w-full text-center text-sm text-zinc-500 hover:text-brand-ink">
                        Sign up with email instead
                    </button>
                ) : (
                <form onSubmit={onSubmit} className="mt-4 space-y-4" data-testid="signup-form">
                    <div>
                        <Label htmlFor="full_name">Your name</Label>
                        <Input
                            id="full_name"
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            className="mt-1"
                            data-testid="signup-full-name"
                        />
                    </div>
                    <div>
                        <Label htmlFor="business_name">Business name (optional)</Label>
                        <Input
                            id="business_name"
                            value={businessName}
                            onChange={(e) => setBusinessName(e.target.value)}
                            className="mt-1"
                            placeholder="You can also set this in the interview."
                            data-testid="signup-business-name"
                        />
                    </div>
                    <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                            id="email"
                            type="email"
                            required
                            autoComplete="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="mt-1"
                            data-testid="signup-email"
                        />
                    </div>
                    <div>
                        <Label htmlFor="password">Password</Label>
                        <Input
                            id="password"
                            type="password"
                            required
                            autoComplete="new-password"
                            minLength={8}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="mt-1"
                            data-testid="signup-password"
                        />
                        <p className="mt-1 text-xs text-zinc-500">At least 8 characters.</p>
                    </div>
                    <Button
                        type="submit"
                        disabled={busy}
                        className="w-full bg-brand-copper hover:bg-brand-copperHover text-white grain"
                        data-testid="signup-submit"
                    >
                        {busy ? "Creating…" : "Create account"}
                    </Button>
                </form>
                )}
                <div className="mt-6 text-sm text-zinc-500">
                    Already have an account?{" "}
                    <Link to="/login" className="text-brand-ink underline" data-testid="signup-login-link">
                        Log in
                    </Link>
                </div>
            </div>
        </div>
    );
}
