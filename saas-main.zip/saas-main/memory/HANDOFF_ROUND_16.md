# ZANELVO — HANDOFF ROUND 16 (Dynamic CMS & Extensions Foundation)

_Read `CURRENT_STATUS.md` first, then `HANDOFF_ROUND_15.md`. Source code + fresh test evidence
override older ✅ claims. Env is WIPED on import — follow HANDOFF_ROUND_15 §0 to rebuild `.env`
(JWT/SECRETS rotated, `SEED_DEMO_DATA=true`) and restart supervisor._

## 1. WHAT ROUND 16 SHIPPED & VERIFIED
Post–Round-15 goal: an AI-native, no-code extensibility system. No arbitrary customer JS / backend
code / eval / shell in this phase (documented as a future isolated runtime).

### Backend (built prior session; this session extended + verified)
- `app/services/cms.py` + `app/routes/cms.py` — registered in `server.py` as `/api/cms/*` (owner) and
  `/api/public/cms/*` (safe public). 17 field types; collections/items CRUD; validation; unique + atomic
  slug; revisions + rollback; bounded CSV import (5MB/5000 rows/60 cols); dynamic page templates
  (list+detail, publish w/ revision, SEO `{{token}}` resolve); safe public projection (published +
  non-archived only, private fields + audit stripped); DB-backed plan limits (free/launch/revenue/
  autopilot/scale) founder-editable via `platform_settings.cms_limits`; SSRF-hardened external REST
  connector (https-only, public-IP-only every-redirect, approved port 443, size/timeout caps, Fernet-
  encrypted headers, metered); metered AI propose/apply (usage.reserve/confirm/settle, EMERGENT_LLM_KEY).
- **This session added**: published dynamic CMS pages now included in `sitemap.xml`
  (`routes/public_sites.py`); form→collection controlled create already wired in
  `media_forms_analytics.py` (`collection_id` + `collection_map`) alongside form→CRM upsert.
- **New tests**: `backend/tests/test_cms_foundation.py` — 16 passed / 1 skipped (AI gated by RUN_CMS_AI=1).
  Backend testing agent full API regression: **16/17 acceptance journeys PASS** (tenant isolation 404,
  stored-XSS sanitised, SSRF blocked, plan limits, CSV bounds, revisions/rollback, private-field
  projection, sitemap w/ 12 dynamic URLs, form→collection+CRM, metered AI propose). No P0.

### Frontend (built this session — was entirely missing)
- `lib/cms.js` (API client + field metadata), `components/cms/FieldsEditor.jsx` (+ `FieldInput`).
- `pages/dashboard/ContentManager.jsx` — `/app/content`: collections grid, visual field builder,
  plan-limit pill, archive; **AI create** tab (describe → preview → confirm → apply); **Connectors**
  tab (encrypted headers, SSRF-safe, test). Nav item added in `DashboardShell.jsx` under "Build".
- `pages/dashboard/ContentCollection.jsx` — `/app/content/:cid`: spreadsheet item manager
  (create/edit/duplicate/archive, search, sort, pagination), CSV import (column mapping) + export,
  revision history + rollback, schema editor, **Dynamic Pages wizard** (site/route/slug/SEO → publish → live URLs).
- `pages/public/DynamicCollectionPage.jsx` — public directory (`/site/:slug/:routeBase`, via PublicSite
  fallback) + detail (`/site/:slug/:routeBase/:itemSlug`). Routes wired in `App.js`.
- Frontend testing agent: Content Manager loads/creates; deeper item + dynamic-page flow self-verified
  by main (item saved, wizard renders with populated site selector). Lint clean, prod compile OK.

### Home light-mode visual fix (user agentic-edit request)
- The hero "app screenshot" mockup (`DashboardMock`) and the showcase `ActivitySlider` card were
  hardcoded dark and stayed dark in bright mode. Made theme-adaptive via a scoped `.mock-light` wrapper
  class (added to the two mock containers in `Home.jsx`) + a light-mode-only CSS block in `index.css`
  (`html:not(.dark) .mock-light …`) that flips dark bg/border/muted-text tokens and keeps full-white
  text on coloured surfaces (brand-copper / gradient / black tooltip). Verified light + dark by screenshot.

## 2. STATUS
- No new P0. Round-15 external blockers unchanged (Stripe Connect enablement, Cloudflare-for-SaaS creds,
  PayPal signed sandbox, legal review, production-mode staging sweep) — owner/merchant actions.
- `PRODUCTION_GATE`: still FAIL only on those owner/external actions. `CODE_GATE`: PASS for this phase.

## 3. REMAINING CMS BRIEF ITEMS (future increments, not blockers)
1. **Visual data binding in the website editor Inspector** (bind block text/image/link/repeater to
   collection fields, fallbacks, conditional visibility, formatted date/currency) — largest remaining.
2. Scheduled connector sync + JSON response-mapping INTO a collection (currently manual test/fetch).
3. Safe styling: expanded theme tokens, hover/focus/active states, approved animations, optional
   validated scoped custom CSS under CSP.
4. System-collection adapters (services/products/blog/team as read-only bindable collections).
5. AI: propose full list/detail LAYOUTS + form mappings (currently schema + route suggestion).
6. Future (out of phase): isolated serverless-function runtime for arbitrary code.

## 4. TEST COMMANDS (dev preview, from /app/backend)
```
python -m pytest -n 0 -q tests/test_cms_foundation.py           # 16 passed / 1 skipped
RUN_CMS_AI=1 python -m pytest -n 0 -q tests/test_cms_foundation.py::test_ai_propose_is_metered_preview
```
Creds: gitignored `memory/test_credentials.md`. Do NOT push from agent — use chat "Save to Github".
