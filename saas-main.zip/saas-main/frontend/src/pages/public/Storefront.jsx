import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import LanguageSwitcher from "@/components/public/LanguageSwitcher";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { ShoppingBag, Loader2, Minus, Plus, Search, User, Gift, Package, LogOut } from "lucide-react";
import { captureAttribution, getAttribution } from "@/lib/attribution";

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

export default function Storefront() {
    const { orgId } = useParams();
    const rootRef = useRef(null);
    const navigate = useNavigate();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [active, setActive] = useState(null);
    const [qty, setQty] = useState(1);
    const [buyer, setBuyer] = useState({ name: "", email: "", phone: "", address: "" });
    const [busy, setBusy] = useState(false);
    const [q, setQ] = useState("");
    const [sort, setSort] = useState("newest");
    const [related, setRelated] = useState([]);
    const [code, setCode] = useState("");
    const [disc, setDisc] = useState(null);
    // Round 12 — gift card + shopper account
    const [gift, setGift] = useState("");
    const [giftInfo, setGiftInfo] = useState(null);
    const tokenKey = `zv_shop_${orgId}`;
    const [token, setToken] = useState(() => localStorage.getItem(tokenKey) || "");
    const [me, setMe] = useState(null);
    const [accountOpen, setAccountOpen] = useState(false);

    useEffect(() => { captureAttribution(); }, []);

    useEffect(() => {
        const t = setTimeout(() => {
            api.get(`/public/store/${orgId}/products`, { params: { q, sort } })
                .then((r) => setData(r.data))
                .catch(() => setData({ store_name: "Store", products: [] }))
                .finally(() => setLoading(false));
        }, q ? 250 : 0);
        return () => clearTimeout(t);
    }, [orgId, q, sort]);

    const authHeader = useCallback(() => (token ? { headers: { Authorization: `Bearer ${token}` } } : {}), [token]);

    useEffect(() => {
        if (!token) { setMe(null); return; }
        api.get(`/public/shop/${orgId}/me`, authHeader())
            .then((r) => setMe(r.data))
            .catch(() => { setMe(null); setToken(""); localStorage.removeItem(tokenKey); });
    }, [token, orgId, authHeader, tokenKey]);

    useEffect(() => {
        if (!active) { setRelated([]); setDisc(null); return; }
        api.get(`/public/store/${orgId}/products/${active.id}/related`, { params: { limit: 3 } })
            .then((r) => setRelated(r.data?.related || [])).catch(() => setRelated([]));
    }, [orgId, active]);

    useEffect(() => {
        if (!active) return;
        const subtotal = active.price_cents * qty;
        const t = setTimeout(() => {
            api.get(`/public/store/${orgId}/discount-preview`, { params: { subtotal_cents: subtotal, code: code.trim() } })
                .then((r) => setDisc(r.data)).catch(() => setDisc(null));
        }, code ? 300 : 0);
        return () => clearTimeout(t);
    }, [orgId, active, qty, code]);

    function openBuy(p) {
        setActive(p); setQty(1); setCode(""); setGift(""); setGiftInfo(null);
        setBuyer({ name: me?.name || "", email: me?.email || "", phone: me?.phone || "", address: "" });
    }

    async function checkGift() {
        if (!gift.trim()) return;
        try {
            const { data: g } = await api.get(`/public/store/${orgId}/gift-card/${gift.trim().toUpperCase()}`);
            setGiftInfo(g);
            if (!g.valid) toast.error(g.message || "Gift card not valid");
        } catch { setGiftInfo(null); }
    }

    async function checkout() {
        if (!buyer.email && !buyer.phone) { toast.error("Add an email or phone so we can send your confirmation"); return; }
        setBusy(true);
        try {
            if (active.is_subscription) {
                const { data: res } = await api.post(`/public/store/${orgId}/subscribe`, {
                    product_id: active.id, buyer, success_url: `/store/${orgId}?ok=1`,
                    customer_token: token || "",
                });
                navigate(res.checkout_url);
                return;
            }
            const { data: res } = await api.post(`/public/store/${orgId}/buy-now`, {
                product_id: active.id, qty, buyer, success_url: `/store/${orgId}?ok=1`,
                discount_code: code.trim(), gift_card_code: gift.trim(),
                customer_token: token || "",
                attribution: getAttribution(),
            });
            if (res.paid && !res.checkout_url) {
                toast.success("Order paid in full with your gift card — thank you!");
                setActive(null);
                navigate(`/store/${orgId}?ok=1`);
                return;
            }
            navigate(res.checkout_url);
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not start checkout"); }
        finally { setBusy(false); }
    }

    if (loading && !data) return <div className="min-h-screen grid place-items-center"><Loader2 className="w-6 h-6 animate-spin text-brand-copper" /></div>;
    const autos = data?.auto_discounts || [];
    const products = data?.products || [];
    const giftApplies = giftInfo?.valid && giftInfo.balance_cents > 0;
    const afterDiscount = active ? Math.max(0, active.price_cents * qty - (disc?.valid ? disc.discount_cents : 0)) : 0;
    const giftApplied = giftApplies ? Math.min(giftInfo.balance_cents, afterDiscount) : 0;

    return (
        <div className="min-h-screen bg-brand-cream" data-testid="storefront" ref={rootRef}>
            <header className="border-b border-brand-line bg-white/80 backdrop-blur sticky top-0 z-10">
                <div className="max-w-6xl mx-auto px-6 py-5 flex items-center gap-3">
                    {data?.branding?.logo_image ? (
                        <img src={data.branding.logo_image} alt={data?.store_name || "Store"} className={`h-10 w-auto object-contain logo-intro logo-intro-${data?.branding?.logo_animation || "none"}`} data-testid="store-logo-image" />
                    ) : data?.branding?.logo_svg ? (
                        <div className={`h-10 flex items-center [&_svg]:h-10 [&_svg]:w-auto logo-intro logo-intro-${data?.branding?.logo_animation || "none"}`} dangerouslySetInnerHTML={{ __html: data.branding.logo_svg }} data-testid="store-logo-svg" />
                    ) : (
                        <>
                            <ShoppingBag className="w-6 h-6 text-brand-copper" />
                            <h1 className="text-xl font-semibold text-brand-ink">{data?.store_name || "Store"}</h1>
                        </>
                    )}
                    <div className="ml-auto flex items-center gap-3">
                        <button onClick={() => setAccountOpen(true)} className="flex items-center gap-2 text-sm text-brand-ink hover:text-brand-copper" data-testid="storefront-account-btn">
                            <User className="w-4 h-4" />
                            {me ? <span className="max-w-[140px] truncate">{me.name || me.email}</span> : "Sign in"}
                        </button>
                        <LanguageSwitcher orgId={orgId} containerRef={rootRef} />
                    </div>
                </div>
            </header>

            <main className="max-w-6xl mx-auto px-6 py-10">
                {autos.length > 0 && (
                    <div className="mb-6 rounded-xl border border-indigo-100 bg-indigo-50 text-indigo-800 text-sm px-4 py-3 flex flex-wrap gap-x-6 gap-y-1" data-testid="storefront-auto-discounts">
                        {autos.map((a, i) => (
                            <span key={i}><strong>{a.title}</strong> — {a.type === "percent" ? `${a.value}% off` : `$${a.value} off`}{a.min_subtotal_cents ? ` on orders over ${money(a.min_subtotal_cents)}` : ""}, applied automatically at checkout</span>
                        ))}
                    </div>
                )}
                <div className="mb-6 flex flex-col sm:flex-row gap-3" data-testid="storefront-toolbar">
                    <div className="flex-1 flex items-center gap-2 bg-white border border-brand-line rounded-lg px-3 py-2">
                        <Search className="w-4 h-4 text-zinc-400" />
                        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products" className="flex-1 outline-none text-sm bg-transparent" data-testid="storefront-search" />
                    </div>
                    <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-white border border-brand-line rounded-lg px-3 py-2 text-sm" data-testid="storefront-sort">
                        <option value="newest">Newest</option>
                        <option value="price_asc">Price: low to high</option>
                        <option value="price_desc">Price: high to low</option>
                        <option value="name">Name A–Z</option>
                    </select>
                </div>
                {!products.length && (
                    <div className="text-center text-zinc-500 py-24" data-testid="storefront-empty">{q ? `No products match "${q}".` : "No products available right now."}</div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products.map((p, i) => (
                        <div key={p.id} className="animate-in-up group bg-white border border-brand-line rounded-xl overflow-hidden hover:shadow-lg transition-shadow duration-300"
                            style={{ animationDelay: `${i * 60}ms` }} data-testid={`storefront-product-${p.id}`}>
                            <div className="aspect-[4/3] bg-brand-cream overflow-hidden">
                                {p.image_url
                                    ? <img src={p.image_url} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                    : <div className="w-full h-full grid place-items-center text-zinc-300">{p.product_type === "gift_card" ? <Gift className="w-10 h-10" /> : <ShoppingBag className="w-10 h-10" />}</div>}
                            </div>
                            <div className="p-4">
                                <div className="flex items-center gap-2">
                                    <h3 className="font-medium text-brand-ink">{p.name}</h3>
                                    {p.product_type === "gift_card" && <span className="text-[10px] px-1.5 py-0.5 rounded bg-brand-copper/10 text-brand-copper">Gift card</span>}
                                    {p.product_type === "bundle" && <span className="text-[10px] px-1.5 py-0.5 rounded bg-fuchsia-100 text-fuchsia-700">Bundle</span>}
                                    {p.is_subscription && <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700">Subscription</span>}
                                </div>
                                {p.description && <p className="text-sm text-zinc-500 mt-1 line-clamp-2">{p.description}</p>}
                                <div className="flex items-center justify-between mt-3">
                                    <span className="font-mono text-brand-ink">{money(p.price_cents, p.currency)}{p.is_subscription ? <span className="text-xs text-zinc-400">/{p.billing_interval === "year" ? "yr" : "mo"}</span> : null}</span>
                                    <Button size="sm" className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={() => openBuy(p)} data-testid={`storefront-buy-${p.id}`}>{p.is_subscription ? "Subscribe" : "Buy now"}</Button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </main>

            <Dialog open={!!active} onOpenChange={(v) => !v && setActive(null)}>
                <DialogContent className="max-w-md">
                    <DialogHeader><DialogTitle>{active?.name}</DialogTitle></DialogHeader>
                    {active && (
                        <div className="space-y-3">
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-zinc-500">Price</span>
                                <span className="font-mono text-brand-ink">{money(active.price_cents, active.currency)}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-zinc-500">Quantity</span>
                                <div className="flex items-center gap-2">
                                    <Button size="icon" variant="outline" className="h-8 w-8 border-brand-line" onClick={() => setQty(Math.max(1, qty - 1))}><Minus className="w-3 h-3" /></Button>
                                    <span className="w-8 text-center font-mono" data-testid="storefront-qty">{qty}</span>
                                    <Button size="icon" variant="outline" className="h-8 w-8 border-brand-line" onClick={() => setQty(active.track_inventory ? Math.min(active.stock, qty + 1) : qty + 1)}><Plus className="w-3 h-3" /></Button>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                <div><Label className="text-xs">Name</Label><Input value={buyer.name} onChange={(e) => setBuyer({ ...buyer, name: e.target.value })} data-testid="storefront-buyer-name" /></div>
                                <div><Label className="text-xs">Email</Label><Input type="email" value={buyer.email} onChange={(e) => setBuyer({ ...buyer, email: e.target.value })} data-testid="storefront-buyer-email" /></div>
                                <div><Label className="text-xs">Phone</Label><Input value={buyer.phone} onChange={(e) => setBuyer({ ...buyer, phone: e.target.value })} /></div>
                                <div><Label className="text-xs">Address</Label><Input value={buyer.address} onChange={(e) => setBuyer({ ...buyer, address: e.target.value })} /></div>
                            </div>
                            <div className="pt-2 border-t border-brand-line space-y-1.5">
                                <div className="flex items-center gap-2">
                                    <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="Discount code (optional)" className="h-8 text-xs font-mono" data-testid="storefront-discount-code" />
                                </div>
                                <div className="flex items-center gap-2">
                                    <Input value={gift} onChange={(e) => { setGift(e.target.value.toUpperCase()); setGiftInfo(null); }} placeholder="Gift card code (optional)" className="h-8 text-xs font-mono" data-testid="storefront-gift-code" />
                                    <Button size="sm" variant="outline" className="h-8 border-brand-line" onClick={checkGift} data-testid="storefront-gift-check">Apply</Button>
                                </div>
                                {disc?.valid && disc.discount_cents > 0 && (
                                    <div className="flex items-center justify-between text-xs text-emerald-700" data-testid="storefront-discount-line">
                                        <span>{disc.auto ? `${disc.title || "Discount"} (automatic)` : `Code ${disc.code}`}</span>
                                        <span className="font-mono">−{money(disc.discount_cents, active.currency)}</span>
                                    </div>
                                )}
                                {code.trim() && disc && !disc.valid && (
                                    <div className="text-xs text-red-600" data-testid="storefront-discount-error">{disc.message}</div>
                                )}
                                {giftApplied > 0 && (
                                    <div className="flex items-center justify-between text-xs text-brand-copper" data-testid="storefront-gift-line">
                                        <span>Gift card {giftInfo.code || gift}</span>
                                        <span className="font-mono">−{money(giftApplied, active.currency)}</span>
                                    </div>
                                )}
                                {gift.trim() && giftInfo && !giftInfo.valid && (
                                    <div className="text-xs text-red-600" data-testid="storefront-gift-error">{giftInfo.message}</div>
                                )}
                                <div className="flex items-center justify-between">
                                    <span className="text-sm font-medium">Total</span>
                                    <span className="font-mono font-medium text-brand-ink" data-testid="storefront-total">{money(Math.max(0, afterDiscount - giftApplied), active.currency)}</span>
                                </div>
                                <p className="text-[11px] text-zinc-500">Shipping and tax are calculated at checkout.</p>
                            </div>
                            {related.length > 0 && (
                                <div className="pt-2 border-t border-brand-line" data-testid="storefront-related">
                                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">You may also like</div>
                                    <div className="grid grid-cols-3 gap-2">
                                        {related.map((r) => (
                                            <button key={r.id} onClick={() => openBuy(r)} className="text-left rounded-lg border border-brand-line hover:border-brand-copper overflow-hidden bg-white" data-testid={`storefront-related-${r.id}`}>
                                                <div className="aspect-square bg-brand-cream">{r.image_url ? <img src={r.image_url} alt={r.name} className="w-full h-full object-cover" /> : <div className="w-full h-full grid place-items-center text-zinc-300"><ShoppingBag className="w-5 h-5" /></div>}</div>
                                                <div className="p-1.5"><div className="text-[11px] font-medium text-brand-ink truncate">{r.name}</div><div className="text-[11px] font-mono text-zinc-500">{money(r.price_cents, r.currency)}</div></div>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setActive(null)}>Cancel</Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={checkout} data-testid="storefront-checkout">{busy ? "Starting\u2026" : (active?.is_subscription ? `Subscribe \u2014 ${money(active.price_cents, active.currency)}/${active.billing_interval === "year" ? "yr" : "mo"}` : "Continue to payment")}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <ShopAccountDialog
                open={accountOpen} onClose={() => setAccountOpen(false)} orgId={orgId}
                token={token} me={me}
                onSignedIn={(tok) => { localStorage.setItem(tokenKey, tok); setToken(tok); }}
                onSignOut={() => { localStorage.removeItem(tokenKey); setToken(""); setMe(null); }}
            />
        </div>
    );
}

function ShopAccountDialog({ open, onClose, orgId, token, me, onSignedIn, onSignOut }) {
    const [step, setStep] = useState("email");
    const [email, setEmail] = useState("");
    const [otp, setOtp] = useState("");
    const [devCode, setDevCode] = useState("");
    const [busy, setBusy] = useState(false);
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        if (open && token) {
            api.get(`/public/shop/${orgId}/orders`, { headers: { Authorization: `Bearer ${token}` } })
                .then((r) => setOrders(r.data?.orders || [])).catch(() => setOrders([]));
        }
    }, [open, token, orgId]);

    async function requestCode() {
        if (!email.trim()) return toast.error("Enter your email");
        setBusy(true);
        try {
            const { data } = await api.post(`/public/shop/${orgId}/auth/request`, { email: email.trim() });
            setDevCode(data.dev_code || "");
            setStep("code");
            toast.success("We sent you a 6-digit code");
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not send code"); }
        finally { setBusy(false); }
    }
    async function verify() {
        setBusy(true);
        try {
            const { data } = await api.post(`/public/shop/${orgId}/auth/verify`, { email: email.trim(), code: otp.trim() });
            onSignedIn(data.access_token);
            setStep("email"); setOtp(""); setEmail("");
            toast.success("Signed in");
        } catch (e) { toast.error(e?.response?.data?.detail || "Incorrect code"); }
        finally { setBusy(false); }
    }

    return (
        <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
            <DialogContent className="max-w-md">
                <DialogHeader><DialogTitle className="flex items-center gap-2"><User className="w-5 h-5 text-brand-copper" /> {token ? "Your account" : "Sign in"}</DialogTitle></DialogHeader>
                {!token ? (
                    <div className="space-y-3">
                        <p className="text-sm text-zinc-500">Sign in with a one-time code — no password needed. Track your orders and save your cart.</p>
                        {step === "email" ? (
                            <>
                                <Label className="text-xs">Email</Label>
                                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" data-testid="shop-login-email" />
                                <Button className="w-full bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={requestCode} data-testid="shop-login-send">{busy ? "Sending…" : "Send code"}</Button>
                            </>
                        ) : (
                            <>
                                <Label className="text-xs">6-digit code</Label>
                                <Input value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="123456" className="font-mono tracking-widest" data-testid="shop-login-code" />
                                {devCode && <p className="text-[11px] text-zinc-400">Dev code: <span className="font-mono">{devCode}</span></p>}
                                <Button className="w-full bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={verify} data-testid="shop-login-verify">{busy ? "Verifying…" : "Verify & sign in"}</Button>
                                <button className="text-xs text-zinc-500 underline" onClick={() => setStep("email")}>Use a different email</button>
                            </>
                        )}
                    </div>
                ) : (
                    <div className="space-y-3">
                        <div className="text-sm text-brand-ink">Signed in as <strong>{me?.email}</strong></div>
                        <div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-2"><Package className="w-3.5 h-3.5" /> Order history</div>
                        <div className="max-h-64 overflow-auto space-y-2" data-testid="shop-orders">
                            {orders.length === 0 && <div className="text-sm text-zinc-400 py-6 text-center">No orders yet.</div>}
                            {orders.map((o) => (
                                <div key={o.id} className="rounded-lg border border-brand-line p-3 text-sm" data-testid={`shop-order-${o.id}`}>
                                    <div className="flex items-center justify-between">
                                        <span className="font-mono text-xs text-zinc-500">#{o.id.slice(0, 8)}</span>
                                        <span className={`text-[11px] px-2 py-0.5 rounded-full ${o.status === "paid" || o.status === "fulfilled" ? "bg-emerald-100 text-emerald-700" : "bg-zinc-100 text-zinc-500"}`}>{o.status}</span>
                                    </div>
                                    <div className="mt-1 text-zinc-600">{(o.items || []).map((it) => `${it.name} × ${it.qty}`).join(", ")}</div>
                                    <div className="mt-1 font-mono text-brand-ink">{money(o.total_cents, o.currency)}</div>
                                </div>
                            ))}
                        </div>
                        <Button variant="outline" className="w-full border-brand-line" onClick={() => { onSignOut(); }} data-testid="shop-signout"><LogOut className="w-4 h-4 mr-2" /> Sign out</Button>
                    </div>
                )}
            </DialogContent>
        </Dialog>
    );
}
