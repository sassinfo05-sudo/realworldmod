"""Phase 6 models: billing, entitlements, founder controls, setup, support, security.

All documents extend BaseDocument. Tenant-scoped docs carry `org_id`; platform-level
docs (audit log, announcements, help articles, global switches) MAY have org_id=None.
"""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .db import BaseDocument


# --- Subscriptions ---

SubscriptionStatus = Literal[
    "active", "trialing", "past_due", "canceled", "paused",
]


class Subscription(BaseDocument):
    org_id: str
    plan_code: str
    status: SubscriptionStatus = "active"
    provider: Literal["simulated", "stripe"] = "simulated"
    provider_customer_id: Optional[str] = None
    provider_subscription_id: Optional[str] = None
    current_period_start: str  # iso
    current_period_end: str    # iso
    cancel_at_period_end: bool = False
    canceled_at: Optional[str] = None
    coupon_code: Optional[str] = None
    trial_end: Optional[str] = None
    # dunning
    failed_payment_count: int = 0
    last_payment_failed_at: Optional[str] = None
    last_payment_at: Optional[str] = None


class Coupon(BaseDocument):
    code: str
    percent_off: Optional[int] = None       # 0-100
    amount_off_cents: Optional[int] = None
    duration: Literal["once", "repeating", "forever"] = "once"
    duration_in_months: Optional[int] = None
    max_redemptions: Optional[int] = None
    redemptions: int = 0
    expires_at: Optional[str] = None
    active: bool = True
    note: Optional[str] = None


class BillingInvoice(BaseDocument):
    """Subscription-level invoice (as opposed to customer-facing invoices in Phase 4)."""
    org_id: str
    number: str
    plan_code: str
    subtotal_cents: int
    discount_cents: int = 0
    total_cents: int
    period_start: str
    period_end: str
    status: Literal["open", "paid", "void", "uncollectible"] = "paid"
    provider: Literal["simulated", "stripe"] = "simulated"
    provider_ref: Optional[str] = None
    line_items: List[Dict[str, Any]] = Field(default_factory=list)
    paid_at: Optional[str] = None
    coupon_code: Optional[str] = None


class CheckoutSession(BaseDocument):
    """A simulated Stripe-like checkout session for plan changes."""
    org_id: str
    plan_code: str
    coupon_code: Optional[str] = None
    provider: Literal["simulated", "stripe"] = "simulated"
    status: Literal["pending", "completed", "expired", "canceled"] = "pending"
    price_cents: int
    expires_at: str
    completed_at: Optional[str] = None


# --- API keys + webhooks (public API + Zapier/Make paths) ---

class ApiKey(BaseDocument):
    org_id: str
    name: str
    prefix: str            # first 12 chars visible (yv_live_xxxx)
    key_hash: str          # sha256 of full key (server never stores full key)
    scopes: List[str] = Field(default_factory=list)  # e.g. ["contacts:read","bookings:write"]
    created_by_user_id: Optional[str] = None
    last_used_at: Optional[str] = None
    revoked: bool = False
    revoked_at: Optional[str] = None


class Webhook(BaseDocument):
    org_id: str
    url: str
    secret_hash: str
    events: List[str] = Field(default_factory=list)   # ["booking.created", "contact.created", ...]
    active: bool = True
    last_delivery_at: Optional[str] = None
    last_error: Optional[str] = None
    created_by_user_id: Optional[str] = None


class WebhookDelivery(BaseDocument):
    org_id: str
    webhook_id: str
    event: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    status: Literal["pending", "delivered", "failed", "dead"] = "pending"
    attempts: int = 0
    next_retry_at: Optional[str] = None
    last_response_code: Optional[int] = None
    last_error: Optional[str] = None
    delivered_at: Optional[str] = None
    signature: Optional[str] = None
    timestamp: Optional[str] = None


# --- MFA / TOTP ---

class MfaSecret(BaseDocument):
    user_id: str
    secret_base32: str       # TOTP shared secret (dev store; encryption enhancement noted)
    enabled: bool = False
    activated_at: Optional[str] = None
    backup_codes_hashed: List[str] = Field(default_factory=list)  # sha256 of one-time codes
    last_verified_at: Optional[str] = None


# --- Immutable audit log ---

class AuditEvent(BaseDocument):
    org_id: Optional[str] = None
    actor_user_id: Optional[str] = None
    actor_role: Optional[str] = None
    actor_email: Optional[str] = None
    action: str                        # e.g. "subscription.upgrade", "impersonation.start"
    target_type: Optional[str] = None  # e.g. "org", "subscription", "user"
    target_id: Optional[str] = None
    reason: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)
    impersonation_session_id: Optional[str] = None
    ip: Optional[str] = None
    user_agent: Optional[str] = None


class ImpersonationSession(BaseDocument):
    """Founder → tenant read/write session with mandatory reason + hard expiry."""
    founder_user_id: str
    target_org_id: str
    reason: str
    started_at: str
    expires_at: str
    ended_at: Optional[str] = None
    active: bool = True
    exit_reason: Optional[str] = None
    actions_count: int = 0


# --- Feature flags + announcements + maintenance ---

class FeatureFlag(BaseDocument):
    key: str
    label: str
    description: Optional[str] = None
    enabled_globally: bool = True
    per_plan_overrides: Dict[str, bool] = Field(default_factory=dict)
    per_org_overrides: Dict[str, bool] = Field(default_factory=dict)


class Announcement(BaseDocument):
    title: str
    body: str
    level: Literal["info", "warn", "urgent"] = "info"
    active: bool = True
    dismissible: bool = True
    created_by_user_id: Optional[str] = None


class MaintenanceMode(BaseDocument):
    key: str = "primary"
    enabled: bool = False
    message: str = "Zanelvo is undergoing maintenance."
    updated_by_user_id: Optional[str] = None


class GlobalKillSwitchDoc(BaseDocument):
    """Platform-wide kill switches. Per-org switch already exists as KillSwitch (models_ai).
    """
    key: str = "global"
    all_ai_disabled: bool = False
    all_email_disabled: bool = False
    all_public_chat_disabled: bool = False
    reason: Optional[str] = None
    updated_by_user_id: Optional[str] = None


# --- Approval queue ---

class ApprovalRequest(BaseDocument):
    org_id: str
    kind: Literal["refund", "delete_org", "custom"] = "refund"
    requested_by_user_id: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    status: Literal["pending", "approved", "rejected"] = "pending"
    reviewer_user_id: Optional[str] = None
    reviewer_note: Optional[str] = None
    reviewed_at: Optional[str] = None


# --- Provider connection cards (Setup Center) ---

class ProviderConnection(BaseDocument):
    """Per-org state of a setup card: 'connected' | 'not_connected' | 'error'.
    Kept intentionally loose so different providers can store their own config blob.
    """
    org_id: str
    key: str  # 'resend', 'gmail', 'twilio', 'stripe', 'gbp', 'ga4', 'quickbooks', ...
    status: Literal["not_connected", "connected", "error", "requires_credential"] = "not_connected"
    config_blob: Dict[str, Any] = Field(default_factory=dict)  # non-secret metadata only
    error_hint: Optional[str] = None
    last_test_at: Optional[str] = None
    last_test_ok: Optional[bool] = None


# --- Help / support ---

class HelpArticle(BaseDocument):
    slug: str
    title: str
    body_markdown: str
    category: str
    keywords: List[str] = Field(default_factory=list)
    related_routes: List[str] = Field(default_factory=list)   # ["/api/booking", ...]
    order: int = 0


class SupportTicket(BaseDocument):
    org_id: str
    user_id: str
    subject: str
    category: str
    severity: Literal["low", "medium", "high", "urgent"] = "medium"
    status: Literal["open", "in_progress", "waiting_user", "resolved", "closed"] = "open"
    messages: List[Dict[str, Any]] = Field(default_factory=list)  # {author, text, created_at}
    resolved_at: Optional[str] = None


class SupportChatMessage(BaseModel):
    """In-app AI-support chat message, ephemeral (not stored per-org)."""
    role: Literal["user", "ai"] = "user"
    content: str


# --- Data export / deletion workflow ---

class DataExportJob(BaseDocument):
    org_id: str
    requested_by_user_id: str
    status: Literal["pending", "running", "ready", "failed"] = "pending"
    file_url: Optional[str] = None
    error: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


class OrgDeletionRequest(BaseDocument):
    org_id: str
    requested_by_user_id: str
    reason: Optional[str] = None
    status: Literal["scheduled", "canceled", "completed"] = "scheduled"
    scheduled_purge_at: str
    executed_at: Optional[str] = None
