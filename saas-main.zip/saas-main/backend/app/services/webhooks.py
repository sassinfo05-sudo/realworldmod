"""Scoped API keys + HMAC-signed outbound webhooks.

Key format: yv_live_<20 char urlsafe>  |  yv_test_<20 char urlsafe>
Server stores only sha256(hash) — full key is shown once at creation.

Webhook signing: X-Zanelvo-Signature: t=<ts>,v1=<hex hmac_sha256(ts.body)>
The signing secret is stored ENCRYPTED (reversible, Fernet) so deliveries can be
signed with the exact plaintext secret the customer was shown once at creation.
Replay window: 5 minutes.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import secrets
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple

import httpx
from bson import ObjectId
from fastapi import HTTPException, Request

from ..db import get_db, utc_now_iso
from . import secretbox

logger = logging.getLogger(__name__)

REPLAY_WINDOW_SECONDS = 300  # 5 minutes

# Keys whose values are redacted before a delivery payload is persisted at rest.
_PII_KEYS = {"email", "emails", "phone", "phones", "password", "token", "secret",
             "card", "cardnumber", "card_number", "cvv", "ssn", "address", "ip",
             "authorization", "api_key", "apikey", "access_token"}


def redact_pii(value: Any, _depth: int = 0) -> Any:
    """Recursively redact obvious PII/secret fields from a payload we persist."""
    if _depth > 6:
        return "…"
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if str(k).lower() in _PII_KEYS:
                out[k] = "[redacted]"
            else:
                out[k] = redact_pii(v, _depth + 1)
        return out
    if isinstance(value, list):
        return [redact_pii(v, _depth + 1) for v in value[:50]]
    return value


# ---------- API keys ----------

def new_api_key(env: str = "live") -> Tuple[str, str, str]:
    """Return (full_key, prefix, sha256_hash)."""
    env = "live" if env not in ("live", "test") else env
    raw = secrets.token_urlsafe(24).replace("-", "").replace("_", "")[:24]
    full = f"yv_{env}_{raw}"
    prefix = full[:12]
    h = hashlib.sha256(full.encode("utf-8")).hexdigest()
    return full, prefix, h


def hash_key(full_key: str) -> str:
    return hashlib.sha256((full_key or "").strip().encode("utf-8")).hexdigest()


async def resolve_api_key(request: Request, required_scope: Optional[str] = None) -> Dict[str, Any]:
    """Look up the API key from Authorization: Bearer yv_...  or X-Api-Key header."""
    auth = request.headers.get("authorization") or ""
    key: str = ""
    if auth.lower().startswith("bearer yv_"):
        key = auth.split(" ", 1)[1].strip()
    elif request.headers.get("x-api-key", "").startswith("yv_"):
        key = request.headers["x-api-key"].strip()
    if not key:
        raise HTTPException(status_code=401, detail="Missing API key")
    db = get_db()
    doc = await db.api_keys.find_one({"key_hash": hash_key(key), "revoked": {"$ne": True}})
    if not doc:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key")
    scopes = doc.get("scopes") or []
    if required_scope and required_scope not in scopes:
        raise HTTPException(status_code=403, detail={
            "error": "insufficient_scope",
            "required": required_scope, "granted": scopes,
        })
    # touch last_used
    await db.api_keys.update_one(
        {"_id": doc["_id"]}, {"$set": {"last_used_at": utc_now_iso()}},
    )
    return doc


# ---------- Webhook signing ----------

def sign_payload(secret: str, body_bytes: bytes, ts: Optional[int] = None) -> Tuple[str, int]:
    """Return (signature_header_value, ts). secret is the plain shared secret (post-create)."""
    ts = ts if ts is not None else int(time.time())
    signed_payload = f"{ts}.".encode("utf-8") + body_bytes
    mac = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
    return f"t={ts},v1={mac}", ts


def verify_signature(header_value: str, secret: str, body_bytes: bytes,
                        replay_window_seconds: int = REPLAY_WINDOW_SECONDS) -> None:
    """Raise HTTPException(400) on any failure. Constant-time compare."""
    if not header_value:
        raise HTTPException(400, "Missing X-Zanelvo-Signature")
    parts = {kv.split("=", 1)[0]: kv.split("=", 1)[1]
                for kv in header_value.split(",") if "=" in kv}
    ts_raw, v1 = parts.get("t"), parts.get("v1")
    if not ts_raw or not v1:
        raise HTTPException(400, "Malformed signature")
    try:
        ts = int(ts_raw)
    except ValueError:
        raise HTTPException(400, "Bad timestamp")
    if abs(int(time.time()) - ts) > replay_window_seconds:
        raise HTTPException(400, "Timestamp outside replay window")
    signed_payload = f"{ts}.".encode("utf-8") + body_bytes
    expected = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, v1):
        raise HTTPException(400, "Bad signature")


# ---------- Webhook secrets (stored ENCRYPTED, reversible) ----------

def new_webhook_secret() -> Tuple[str, str]:
    """(plain_secret, encrypted_secret). Show plain once; store the encrypted value."""
    plain = "whsec_" + secrets.token_urlsafe(24)
    return plain, secretbox.encrypt(plain)


def signing_secret_for(w: Dict[str, Any]) -> Optional[str]:
    """Return the plaintext signing secret for a webhook doc, decrypting the stored
    encrypted value. Legacy docs that only kept a sha256 hash cannot be recovered and
    must be rotated — returns None so the caller can mark the delivery accordingly."""
    enc = w.get("secret_enc")
    if enc:
        try:
            return secretbox.decrypt(enc)
        except Exception:  # noqa: BLE001
            return None
    return None


# ---------- Outbound delivery ----------

async def dispatch_event(org_id: str, event: str, payload: Dict[str, Any]) -> int:
    """Fire the event to all matching webhooks, log a WebhookDelivery for each attempt.

    Delivery is best-effort synchronous with a short timeout — a real deployment would
    queue this via Celery/Rq. Returns the count of webhooks matched.
    """
    db = get_db()
    hits = 0
    async for w in db.webhooks.find({"org_id": org_id, "active": True,
                                          "events": {"$in": [event, "*"]}}):
        hits += 1
        # Sign with the ACTUAL plaintext secret (decrypted from storage) so the
        # customer can reproduce the HMAC with the whsec_ value we showed them once.
        secret_material = signing_secret_for(w)
        if not secret_material:
            # Legacy webhook without a recoverable secret — record and skip signing safely.
            await db.webhook_deliveries.insert_one({
                "org_id": org_id, "webhook_id": str(w["_id"]), "event": event,
                "payload": redact_pii(payload), "status": "failed", "attempts": 1,
                "last_error": "signing secret missing/legacy — rotate the webhook secret",
                "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
            })
            continue
        stored_payload = redact_pii(payload)
        body_bytes = json.dumps({"event": event, "org_id": org_id, "data": payload,
                                     "created_at": utc_now_iso()}).encode("utf-8")
        sig, ts = sign_payload(secret_material, body_bytes)
        delivery_id = secrets.token_hex(12)
        code, err = await _post_once(w, body_bytes, sig, event)
        ok = code is not None and 200 <= code < 300
        import base64 as _b64
        doc = {
            "_id": delivery_id, "org_id": org_id, "webhook_id": str(w["_id"]),
            "event": event, "payload": stored_payload,
            "status": "delivered" if ok else "pending_retry",
            "attempts": 1, "max_attempts": MAX_ATTEMPTS,
            "last_response_code": code, "last_error": None if ok else err,
            "delivered_at": utc_now_iso() if ok else None,
            "signature": sig, "timestamp": str(ts),
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        }
        if not ok:
            # DURABLE RETRY: schedule an exponential-backoff retry (worker picks it up).
            doc["next_attempt_at"] = _backoff(1)
            doc["retry_body"] = _b64.b64encode(body_bytes).decode()
        await db.webhook_deliveries.insert_one(doc)
        await db.webhooks.update_one({"_id": w["_id"]}, {"$set": {
            "last_delivery_at": utc_now_iso(), "last_error": None if ok else err}})
    return hits


# --------------------------- Durable retries + dead-letter + replay ---------------------------
MAX_ATTEMPTS = 6
_BACKOFF_S = [60, 300, 900, 3600, 21600]   # 1m, 5m, 15m, 1h, 6h → then dead-letter


def _backoff(attempts: int) -> str:
    from datetime import timedelta
    idx = min(max(attempts - 1, 0), len(_BACKOFF_S) - 1)
    return (datetime.now(timezone.utc) + timedelta(seconds=_BACKOFF_S[idx])).isoformat()


async def _post_once(w: Dict[str, Any], body_bytes: bytes, sig: str, event: str):
    """Single delivery attempt. Returns (status_code|None, error|None)."""
    try:
        from .netsafe import url_is_safe
        if not await url_is_safe(w["url"]):
            return None, "webhook target is not a public http(s) host"
        async with httpx.AsyncClient(timeout=6.0, follow_redirects=False) as c:
            r = await c.post(w["url"], content=body_bytes, headers={
                "Content-Type": "application/json",
                "X-Zanelvo-Signature": sig, "X-Zanelvo-Event": event})
        return r.status_code, (None if 200 <= r.status_code < 300 else (r.text or "")[:200])
    except Exception as e:  # noqa: BLE001
        return None, str(e)[:200]


def _wh_query(webhook_id):
    try:
        return {"_id": ObjectId(webhook_id)} if len(str(webhook_id)) == 24 else {"_id": webhook_id}
    except Exception:  # noqa: BLE001
        return {"_id": webhook_id}


async def retry_due(limit: int = 50) -> Dict[str, int]:
    """Worker: re-attempt due `pending_retry` deliveries; dead-letter after max attempts.
    Each delivery is atomically claimed so concurrent workers never double-send."""
    import base64 as _b64
    db = get_db()
    now = utc_now_iso()
    out = {"retried": 0, "delivered": 0, "dead_letter": 0}
    async for d in db.webhook_deliveries.find(
            {"status": "pending_retry", "next_attempt_at": {"$lte": now}}).limit(limit):
        claim = await db.webhook_deliveries.update_one(
            {"_id": d["_id"], "status": "pending_retry"},
            {"$set": {"status": "retrying", "updated_at": now}})
        if claim.modified_count != 1:
            continue  # another worker took it
        attempts = int(d.get("attempts", 1)) + 1
        w = await db.webhooks.find_one(_wh_query(d["webhook_id"]))
        if not w or not w.get("active", True) or not d.get("retry_body"):
            await db.webhook_deliveries.update_one({"_id": d["_id"]}, {
                "$set": {"status": "dead_letter", "attempts": attempts,
                         "last_error": "webhook removed/inactive or body unavailable",
                         "updated_at": utc_now_iso()}, "$unset": {"retry_body": ""}})
            out["dead_letter"] += 1
            continue
        body_bytes = _b64.b64decode(d["retry_body"])
        sig, ts = sign_payload(signing_secret_for(w), body_bytes)
        code, err = await _post_once(w, body_bytes, sig, d["event"])
        ok = code is not None and 200 <= code < 300
        out["retried"] += 1
        if ok:
            await db.webhook_deliveries.update_one({"_id": d["_id"]}, {
                "$set": {"status": "delivered", "attempts": attempts, "delivered_at": utc_now_iso(),
                         "last_response_code": code, "last_error": None, "signature": sig,
                         "timestamp": str(ts), "updated_at": utc_now_iso()},
                "$unset": {"retry_body": ""}})
            out["delivered"] += 1
        elif attempts >= int(d.get("max_attempts", MAX_ATTEMPTS)):
            await db.webhook_deliveries.update_one({"_id": d["_id"]}, {
                "$set": {"status": "dead_letter", "attempts": attempts, "last_response_code": code,
                         "last_error": err, "updated_at": utc_now_iso()}, "$unset": {"retry_body": ""}})
            out["dead_letter"] += 1
        else:
            await db.webhook_deliveries.update_one({"_id": d["_id"]}, {
                "$set": {"status": "pending_retry", "attempts": attempts, "last_response_code": code,
                         "last_error": err, "next_attempt_at": _backoff(attempts),
                         "updated_at": utc_now_iso()}})
    return out


async def retry_loop(interval_s: int = 60) -> None:
    import asyncio
    while True:
        try:
            await retry_due()
        except Exception as e:  # noqa: BLE001
            logger.warning("webhook retry_loop error: %s", e)
        await asyncio.sleep(interval_s)


async def replay_delivery(org_id: str, delivery_id: str) -> bool:
    """Owner-triggered replay of a delivery (including a dead-lettered one)."""
    import base64 as _b64
    db = get_db()
    d = await db.webhook_deliveries.find_one({"_id": delivery_id, "org_id": org_id})
    if not d:
        return False
    updates = {"status": "pending_retry", "next_attempt_at": utc_now_iso(),
               "attempts": 0, "updated_at": utc_now_iso()}
    if not d.get("retry_body"):
        body = json.dumps({"event": d.get("event"), "org_id": org_id, "data": d.get("payload"),
                           "created_at": utc_now_iso()}).encode("utf-8")
        updates["retry_body"] = _b64.b64encode(body).decode()
    await db.webhook_deliveries.update_one({"_id": delivery_id}, {"$set": updates})
    return True
