"""Brand / logo store (owner-scoped, /api/branding).

Persists the tenant's generated logo (SVG string), a compact logomark, palette
and style so it survives reloads and can be reused across the app + public site.
Logo generation itself happens client-side (instant, no API keys); this route
just stores/returns the result. UUID/string ids only.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, field_validator

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..services.svg_safe import sanitize_svg

router = APIRouter(prefix="/branding", tags=["branding"])


def _out(d: Optional[Dict[str, Any]], org_name: str = "") -> Dict[str, Any]:
    d = d or {}
    return {
        "logo_svg": d.get("logo_svg", ""),
        "logomark_svg": d.get("logomark_svg", ""),
        "logo_image": d.get("logo_image", ""),
        "logo_animation": d.get("logo_animation", "none"),
        "name": d.get("name", org_name),
        "colors": d.get("colors", {"fg": "#0f172a", "bg": "#ffffff", "accent": "#b45309"}),
        "style": d.get("style", "monogram"),
        "font": d.get("font", "DM Sans"),
        "icon": d.get("icon", "spark"),
        "logo_provider": d.get("logo_provider", "gemini"),
        "logo_applied": bool(d.get("logo_applied", False)),
        "updated_at": d.get("updated_at"),
    }


# Supported AI logo providers (remembered per org). All run on the Emergent key.
LOGO_PROVIDERS = {
    "gemini": {"provider": "gemini", "model": "gemini-3.1-flash-image-preview", "label": "Gemini (Nano Banana)"},
    "openai": {"provider": "openai", "model": "gpt-image-1", "label": "OpenAI (gpt-image-1)"},
}


@router.get("")
async def get_branding(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.org_branding.find_one({"org_id": org_id})
    org = await db.organizations.find_one({"_id": org_id}) if not doc else None
    name = ""
    if org:
        name = org.get("name", "")
    return _out(doc, name)


class BrandingIn(BaseModel):
    logo_svg: str = ""
    logomark_svg: str = ""
    logo_image: str = ""
    logo_animation: str = "none"  # none | fade | rise | pop | glow | sweep
    name: str = ""
    colors: Dict[str, str] = Field(default_factory=dict)
    style: str = "monogram"
    font: str = "DM Sans"
    icon: str = "spark"
    logo_provider: str = ""

    @field_validator("logo_svg", "logomark_svg")
    @classmethod
    def _clean_svg(cls, v: str) -> str:
        # Strip any executable/remote content before it is stored or rendered.
        return sanitize_svg(v) if v else v


class AiLogoIn(BaseModel):
    name: str = ""
    industry: str = ""
    description: str = ""
    style: str = "modern minimalist"  # modern minimalist | playful | luxury | bold | vintage | tech
    palette: str = "brand colors"
    count: int = Field(default=2, ge=1, le=3)
    provider: str = ""       # "" -> use remembered pref (or gemini); "gemini" | "openai"
    remember: bool = True    # remember this provider as the org default
    auto_apply: bool = False  # if true, save the first generated image as the live brand logo


@router.get("/providers")
async def logo_providers(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """List available AI logo providers + the org's remembered choice."""
    db = get_db()
    doc = await db.org_branding.find_one({"org_id": org_id})
    return {
        "providers": [{"key": k, "label": v["label"]} for k, v in LOGO_PROVIDERS.items()],
        "selected": (doc or {}).get("logo_provider", "gemini"),
    }


@router.post("/ai-logo")
async def ai_logo(req: AiLogoIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Generate AI logo image(s). Uses the org's remembered provider unless one is passed."""
    from ..services import llm
    db = get_db()
    doc = await db.org_branding.find_one({"org_id": org_id}) or {}
    prov_key = (req.provider or doc.get("logo_provider") or "gemini").lower()
    if prov_key not in LOGO_PROVIDERS:
        prov_key = "gemini"
    prov = LOGO_PROVIDERS[prov_key]
    name = (req.name or "the brand").strip()
    prompt = (
        f"Design a single professional, iconic vector-style LOGO for a business named '{name}'. "
        f"Industry: {req.industry or 'general'}. {req.description or ''} "
        f"Style: {req.style}. Color palette: {req.palette}. "
        "The logo must be centered on a clean solid white background, high contrast, crisp edges, "
        "balanced negative space, no photorealism, no text paragraphs, no watermark, no mockup, "
        "no drop shadow clutter. Simple enough to work as an app icon. Square composition."
    )
    from fastapi import HTTPException
    images: List[str] = []
    errors = 0
    for _ in range(req.count):
        try:
            b64 = await llm.generate_image(prompt, provider=prov["provider"], model=prov["model"])
            if b64:
                images.append(f"data:image/png;base64,{b64}")
        except HTTPException:
            # Budget / cap / pause gates (402/503) must reach the owner, not be masked as "unavailable".
            raise
        except Exception:  # noqa: BLE001
            errors += 1
    if not images:
        raise HTTPException(502,
            f"Logo generation via {prov['label']} is temporarily unavailable. Please try again"
            + (" or switch provider." if prov_key != "gemini" else "."))
    # Remember the provider choice for next time.
    update: Dict[str, Any] = {"updated_at": utc_now_iso(), "org_id": org_id}
    if req.remember:
        update["logo_provider"] = prov_key
    if req.auto_apply and images:
        update["logo_image"] = images[0]
        update["logo_applied"] = True
    if len(update) > 2:
        await db.org_branding.update_one({"org_id": org_id}, {"$set": update}, upsert=True)
        if req.auto_apply and images:
            await _mirror_logo(db, org_id, logo_image=images[0])
    return {"images": images, "prompt_used": prompt, "generated": len(images),
             "failed": errors, "provider": prov_key, "auto_applied": bool(req.auto_apply)}


async def _mirror_logo(db, org_id: str, logo_svg: str = "", logo_image: str = "", logo_animation: Optional[str] = None) -> None:
    """Auto-apply the logo everywhere the public surfaces read it — both the DRAFT `theme`
    AND the live `published_theme` — so the site header shows it immediately (no re-publish)."""
    try:
        website = await db.websites.find_one({"org_id": org_id})
        if not website:
            return
        set_fields: Dict[str, Any] = {"updated_at": utc_now_iso()}
        for key in ("theme", "published_theme"):
            block = website.get(key)
            if not isinstance(block, dict):
                continue
            if logo_svg:
                block["logo_svg"] = logo_svg
            if logo_image:
                block["logo_image"] = logo_image
            if logo_animation is not None:
                block["logo_animation"] = logo_animation
            set_fields[key] = block
        await db.websites.update_one({"_id": website["_id"]}, {"$set": set_fields})
    except Exception:  # noqa: BLE001
        pass


@router.post("/apply-logo")
async def apply_logo(req: BrandingIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Set a chosen logo as the LIVE brand logo and auto-apply it across dashboard, store & site."""
    db = get_db()
    now = utc_now_iso()
    patch: Dict[str, Any] = {"org_id": org_id, "updated_at": now, "logo_applied": True}
    if req.logo_image:
        patch["logo_image"] = req.logo_image
    if req.logo_svg:
        patch["logo_svg"] = req.logo_svg
    if req.logo_provider:
        patch["logo_provider"] = req.logo_provider
    patch["logo_animation"] = req.logo_animation or "none"
    await db.org_branding.update_one({"org_id": org_id}, {"$set": patch}, upsert=True)
    await _mirror_logo(db, org_id, logo_svg=req.logo_svg, logo_image=req.logo_image, logo_animation=req.logo_animation or "none")
    doc = await db.org_branding.find_one({"org_id": org_id})
    return _out(doc)


@router.put("")
async def save_branding(req: BrandingIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    now = utc_now_iso()
    doc = req.model_dump()
    doc["org_id"] = org_id
    doc["updated_at"] = now
    if not doc.get("logo_provider"):
        doc.pop("logo_provider", None)  # don't wipe the remembered provider
    if not doc.get("logo_image"):
        doc.pop("logo_image", None)  # don't wipe the applied logo image
    if req.logo_image or req.logo_svg:
        doc["logo_applied"] = True
    await db.org_branding.update_one({"org_id": org_id}, {"$set": doc}, upsert=True)
    # Auto-apply the logo onto the public website theme (store reads org_branding directly).
    await _mirror_logo(db, org_id, logo_svg=req.logo_svg, logo_image=req.logo_image, logo_animation=req.logo_animation or "none")
    doc = await db.org_branding.find_one({"org_id": org_id})
    return _out(doc)
