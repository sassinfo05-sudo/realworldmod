import HeroBlock from "@/components/blocks/HeroBlock";
import ServicesGridBlock from "@/components/blocks/ServicesGridBlock";
import AboutSplitBlock from "@/components/blocks/AboutSplitBlock";
import TestimonialsBlock from "@/components/blocks/TestimonialsBlock";
import CtaBandBlock from "@/components/blocks/CtaBandBlock";
import ContactHoursBlock from "@/components/blocks/ContactHoursBlock";
import FormBlock from "@/components/blocks/FormBlock";
import FooterBlock from "@/components/blocks/FooterBlock";
import BookingBlock from "@/components/blocks/BookingBlock";
import ChatWidgetBlock from "@/components/blocks/ChatWidgetBlock";
import StoreBlock from "@/components/blocks/StoreBlock";
import { EXTRA_REGISTRY } from "@/components/blocks/ExtraBlocks";
import BlogListBlock from "@/components/blocks/BlogListBlock";

const REGISTRY = {
    hero: HeroBlock,
    services_grid: ServicesGridBlock,
    about_split: AboutSplitBlock,
    testimonials: TestimonialsBlock,
    cta_band: CtaBandBlock,
    contact_hours: ContactHoursBlock,
    form: FormBlock,
    footer: FooterBlock,
    booking: BookingBlock,
    chat_widget: ChatWidgetBlock,
    store: StoreBlock,
    ...EXTRA_REGISTRY,
    blog_list: BlogListBlock,
};

/**
 * BlockRenderer — themed renderer for the generated block JSON.
 * Applies theme as CSS custom properties on the root so children can consume via var().
 * The DOM is intentionally structured for a future click-to-edit editor:
 *   [data-block-id], [data-block-type], [data-editable] are set on every block.
 */
export default function BlockRenderer({ page, theme, testidPrefix = "block" }) {
    if (!page) return null;
    const styleVars = theme
        ? {
              "--tenant-primary": theme.primary,
              "--tenant-secondary": theme.secondary,
              "--tenant-bg": theme.background,
              "--tenant-surface": theme.surface,
              "--tenant-fg": theme.foreground,
              "--tenant-accent": theme.accent,
              "--tenant-radius": theme.radius,
              fontFamily: theme.font_body,
              backgroundColor: theme.background,
              color: theme.foreground,
          }
        : {};

    return (
        <div
            className="tenant-site"
            style={styleVars}
            data-testid={`${testidPrefix}-page-${page.slug}`}
        >
            <style>{`
                .tenant-site [data-heading] { font-family: ${theme?.font_heading || "serif"}; }
                .tenant-site a { color: inherit; }
            `}</style>
            {(page.blocks || []).filter((b) => !b.hidden).map((b) => {
                const Comp = REGISTRY[b.type];
                if (!Comp) return null;
                return (
                    <div
                        key={b.id}
                        data-block-id={b.id}
                        data-block-type={b.type}
                        data-block-variant={b.variant}
                        data-editable="true"
                        data-testid={`${testidPrefix}-${b.type}`}
                    >
                        <Comp block={b} theme={theme} />
                    </div>
                );
            })}
        </div>
    );
}
