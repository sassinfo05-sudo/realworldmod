import { useState } from "react";
import { getAttribution } from "@/lib/attribution";

export default function FormBlock({ block, theme }) {
    const { props = {} } = block;
    const {
        headline = "Get in touch",
        subheadline = "Tell us what you need. We'll respond within one business day.",
        fields = [
            { name: "name", label: "Your name", type: "text", required: true },
            { name: "email", label: "Email", type: "email", required: true },
            { name: "message", label: "How can we help?", type: "textarea", required: true },
        ],
        submit_label = "Send",
        website_slug,
        page_slug,
    } = props;

    const [values, setValues] = useState({});
    const [state, setState] = useState("idle"); // idle | sending | done | error
    const [error, setError] = useState(null);

    async function onSubmit(e) {
        e.preventDefault();
        setState("sending");
        setError(null);
        try {
            const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/forms/submit`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    website_slug,
                    page_slug: page_slug || "contact",
                    block_id: block.id,
                    fields: values,
                    attribution: getAttribution(),
                }),
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            setState("done");
        } catch (err) {
            setState("error");
            setError(err.message);
        }
    }

    return (
        <section className="py-16" style={{ backgroundColor: theme?.background }} data-testid="form-block">
            <div className="mx-auto max-w-2xl px-6">
                <div className="rounded-2xl border p-6 md:p-8"
                     style={{ background: theme?.surface, borderColor: `${theme?.foreground}14` }}>
                    <h2 data-heading className="text-2xl md:text-3xl font-semibold" style={{ color: theme?.foreground }}>{headline}</h2>
                    {subheadline && (
                        <p className="mt-2 text-sm" style={{ color: `${theme?.foreground}A0` }}>{subheadline}</p>
                    )}
                    {state === "done" ? (
                        <div className="mt-6 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 p-4" data-testid="form-block-success">
                            Thanks — we've received your message and will reply soon.
                        </div>
                    ) : (
                        <form className="mt-6 space-y-4" onSubmit={onSubmit} data-testid="form-block-form">
                            {fields.map((f) => (
                                <div key={f.name}>
                                    <label className="text-xs uppercase tracking-widest" style={{ color: `${theme?.foreground}90` }}>
                                        {f.label}{f.required && " *"}
                                    </label>
                                    {f.type === "textarea" ? (
                                        <textarea
                                            required={!!f.required}
                                            rows={4}
                                            value={values[f.name] || ""}
                                            onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}
                                            className="mt-1 w-full rounded-md border px-3 py-2 text-sm"
                                            style={{ borderColor: `${theme?.foreground}26`, background: theme?.background }}
                                            data-testid={`form-field-${f.name}`}
                                        />
                                    ) : (
                                        <input
                                            type={f.type || "text"}
                                            required={!!f.required}
                                            value={values[f.name] || ""}
                                            onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}
                                            className="mt-1 w-full rounded-md border px-3 py-2 text-sm"
                                            style={{ borderColor: `${theme?.foreground}26`, background: theme?.background }}
                                            data-testid={`form-field-${f.name}`}
                                        />
                                    )}
                                </div>
                            ))}
                            {error && (
                                <div className="rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm">{error}</div>
                            )}
                            <button
                                type="submit"
                                disabled={state === "sending"}
                                className="w-full inline-flex items-center justify-center px-5 py-3 rounded-md font-medium text-white"
                                style={{ background: theme?.primary }}
                                data-testid="form-submit-btn"
                            >
                                {state === "sending" ? "Sending…" : submit_label}
                            </button>
                        </form>
                    )}
                </div>
            </div>
        </section>
    );
}
