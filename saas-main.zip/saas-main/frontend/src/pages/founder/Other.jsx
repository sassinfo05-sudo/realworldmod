import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

export function AuditLog() {
    const [events, setEvents] = useState([]);
    const [q, setQ] = useState("");
    const [action, setAction] = useState("");
    const [loading, setLoading] = useState(true);

    async function load() {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (q) params.append("q", q);
            if (action) params.append("action", action);
            const { data } = await api.get(`/founder/audit${params.toString() ? "?" + params.toString() : ""}`);
            setEvents(data.events || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    return (
        <div className="p-6 max-w-6xl" data-testid="founder-audit-page">
            <div className="flex gap-2 items-center mb-4 flex-wrap">
                <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-zinc-400" />
                    <Input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} placeholder="Search by actor / reason" className="pl-8 w-64" data-testid="audit-search" />
                </div>
                <Input value={action} onChange={(e) => setAction(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} placeholder="Filter action (e.g. impersonation)" className="w-60" data-testid="audit-action" />
                <Button variant="ghost" onClick={load}>Refresh</Button>
                <div className="ml-auto text-xs text-zinc-500 font-mono">{events.length} events</div>
            </div>
            <div className="border border-brand-line rounded-lg bg-white overflow-hidden divide-y">
                {events.map((e) => (
                    <div key={e.id} className="p-3 text-sm" data-testid={`audit-${e.id}`}>
                        <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] uppercase tracking-widest text-brand-copper font-mono">{e.action}</span>
                            <span className="text-xs text-zinc-500">by {e.actor_email || "system"} ({e.actor_role})</span>
                            {e.org_id && <span className="text-[10px] text-zinc-400 font-mono">org={e.org_id.slice(-6)}</span>}
                            <span className="ml-auto text-[10px] text-zinc-400 font-mono">{e.created_at?.slice(0, 19)}</span>
                        </div>
                        {e.reason && <div className="text-xs text-zinc-600 mt-1">Reason: {e.reason}</div>}
                        {e.target_type && <div className="text-[10px] text-zinc-400 mt-0.5 font-mono">→ {e.target_type} {e.target_id?.slice(-8)}</div>}
                        {e.impersonation_session_id && <div className="text-[10px] text-amber-700 mt-0.5">during impersonation session {e.impersonation_session_id.slice(-8)}</div>}
                    </div>
                ))}
                {!loading && !events.length && <div className="text-center text-zinc-500 py-10" data-testid="audit-empty">No events match.</div>}
            </div>
        </div>
    );
}

export function ProviderHealth() {
    const [health, setHealth] = useState(null);
    const [deadLetters, setDeadLetters] = useState([]);
    async function load() {
        const [h, d] = await Promise.all([
            api.get("/founder/health"),
            api.get("/founder/webhooks/dead-letter"),
        ]);
        setHealth(h.data); setDeadLetters(d.data.deliveries || []);
    }
    useEffect(() => { load(); }, []);
    async function retry(id) {
        try { await api.post(`/founder/webhooks/${id}/retry`); load(); }
        catch (e) { /* toast handled elsewhere */ }
    }
    if (!health) return <div className="p-6 text-zinc-500">Loading…</div>;
    return (
        <div className="p-6 max-w-4xl" data-testid="founder-health-page">
            <div className="grid md:grid-cols-2 gap-3 mb-6">
                {[
                    ["LLM", `Key ${health.llm.key_set ? "set" : "missing"}`, health.llm.status],
                    ["Email providers", `${health.email.provider_configs} configured`, health.email.status],
                    ["Payments (Stripe env)", health.payments.stripe_key_env ? "Set" : "Not set", null],
                    ["Webhook queue", `pending=${health.webhooks.pending} failed=${health.webhooks.failed} dead=${health.webhooks.dead}`, null],
                    ["Scheduled sends", `pending=${health.scheduled_sends.pending} failed=${health.scheduled_sends.failed}`, null],
                ].map(([label, sub, status]) => (
                    <div key={label} className="rounded-lg border border-brand-line bg-white p-4">
                        <div className="text-xs uppercase tracking-widest text-zinc-500">{label}</div>
                        <div className="mt-1 text-sm text-brand-ink">{sub}</div>
                        {status && <div className={`text-[10px] uppercase tracking-widest mt-1 ${status === "ok" || status === "configured" ? "text-emerald-600" : "text-amber-600"}`}>{status}</div>}
                    </div>
                ))}
            </div>
            <div>
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Failed / dead webhooks</div>
                <div className="border border-brand-line rounded-lg bg-white overflow-hidden divide-y">
                    {deadLetters.map((d) => (
                        <div key={d.id} className="p-3 text-sm flex items-center gap-2" data-testid={`deadletter-${d.id}`}>
                            <div className="flex-1">
                                <div className="text-brand-ink font-mono text-xs">{d.event}</div>
                                <div className="text-[10px] text-zinc-500">org={d.org_id?.slice(-6)} · attempts={d.attempts} · code={d.last_response_code || "—"} · {d.last_error?.slice(0, 80)}</div>
                            </div>
                            <span className={`text-[10px] uppercase tracking-widest ${d.status === "dead" ? "text-red-600" : "text-amber-600"}`}>{d.status}</span>
                            <Button size="sm" variant="outline" onClick={() => retry(d.id)} data-testid={`deadletter-retry-${d.id}`}>Retry</Button>
                        </div>
                    ))}
                    {!deadLetters.length && <div className="text-center text-zinc-500 py-6 text-sm" data-testid="deadletter-empty">No failed deliveries.</div>}
                </div>
            </div>
            <ErrorEvents />
        </div>
    );
}

/** Recent unhandled API errors (server.py::_unhandled → db.error_events). Redacted: method/path/type/message only. */
function ErrorEvents() {
    const [data, setData] = useState(null);
    useEffect(() => { api.get("/founder/error-events", { params: { limit: 50 } }).then((r) => setData(r.data)).catch(() => setData({ items: [], total: 0 })); }, []);
    return (
        <div className="mt-6 rounded-2xl border border-brand-line bg-white" data-testid="founder-error-events">
            <div className="px-4 py-3 border-b border-brand-line flex items-center justify-between">
                <div className="font-medium text-brand-ink text-sm">API errors (500s)</div>
                <span className="text-xs text-zinc-500">{data ? `${data.total} total` : "…"}</span>
            </div>
            <div className="divide-y divide-brand-line max-h-80 overflow-y-auto">
                {(data?.items || []).map((e, i) => (
                    <div key={i} className="px-4 py-2 text-xs flex items-start gap-3" data-testid="error-event-row">
                        <span className="font-mono text-zinc-500 shrink-0">{new Date(e.created_at).toLocaleString()}</span>
                        <span className="font-mono text-brand-ink shrink-0">{e.method} {e.path}</span>
                        <span className="text-rose-700 truncate">{e.error_type}: {e.message}</span>
                    </div>
                ))}
                {data && !data.items.length && <div className="text-center text-zinc-500 py-6 text-sm" data-testid="error-events-empty">No unhandled errors recorded.</div>}
            </div>
        </div>
    );
}

export function Approvals() {
    const [items, setItems] = useState([]);
    async function load() {
        const { data } = await api.get("/founder/approvals?status=pending");
        setItems(data.approvals || []);
    }
    useEffect(() => { load(); }, []);
    async function decide(id, approve) {
        const note = window.prompt(approve ? "Approval note (optional)" : "Reason (required for reject)", "") || "";
        try { await api.post(`/founder/approvals/${id}/decide`, { approve, note }); load(); }
        catch (e) { /* toast */ }
    }
    return (
        <div className="p-6 max-w-3xl" data-testid="founder-approvals-page">
            <h2 className="text-lg font-medium text-brand-ink mb-3">Pending approvals</h2>
            {items.length ? (
                <div className="space-y-2">
                    {items.map((a) => (
                        <div key={a.id} className="rounded-lg border border-brand-line bg-white p-3" data-testid={`approval-${a.id}`}>
                            <div className="text-sm font-medium text-brand-ink">{a.kind}</div>
                            <div className="text-xs text-zinc-500 font-mono">org={a.org_id?.slice(-6)}</div>
                            <div className="text-xs text-zinc-600 mt-1">{JSON.stringify(a.payload)}</div>
                            <div className="mt-2 flex gap-2">
                                <Button size="sm" className="bg-emerald-600 text-white hover:bg-emerald-700" onClick={() => decide(a.id, true)} data-testid={`approval-${a.id}-approve`}>Approve</Button>
                                <Button size="sm" variant="destructive" onClick={() => decide(a.id, false)} data-testid={`approval-${a.id}-reject`}>Reject</Button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-emerald-900 text-sm" data-testid="approvals-empty">Nothing pending.</div>
            )}
        </div>
    );
}
