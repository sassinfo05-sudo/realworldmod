import { Link, useLocation } from "react-router-dom";
import { Wordmark } from "@/components/Logo";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import ThemeToggle from "@/components/ThemeToggle";

export default function PublicNav() {
    const { user } = useAuth();
    const location = useLocation();

    const link = (to, label, testid) => {
        const active = location.pathname === to;
        return (
            <Link
                key={to}
                to={to}
                data-testid={testid}
                className={`text-sm transition-colors ${
                    active ? "text-brand-ink" : "text-zinc-500 hover:text-brand-ink"
                }`}
            >
                {label}
            </Link>
        );
    };

    return (
        <header
            className="sticky top-0 z-40 backdrop-blur-md bg-white/85 border-b border-brand-line"
            data-testid="public-nav"
        >
            <div className="mx-auto max-w-6xl px-6 h-16 flex items-center justify-between">
                <Link to="/" className="flex items-center" data-testid="nav-home-link">
                    <Wordmark />
                </Link>
                <nav className="hidden md:flex items-center gap-8">
                    {link("/product", "Product", "nav-product-link")}
                    {link("/pricing", "Pricing", "nav-pricing-link")}
                    {link("/developers", "Developers", "nav-developers-link")}
                </nav>
                <div className="flex items-center gap-3">
                    <ThemeToggle />
                    {user ? (
                        <Link to="/app" data-testid="nav-dashboard-link">
                            <Button variant="ghost" size="sm">Open dashboard</Button>
                        </Link>
                    ) : (
                        <>
                            <Link to="/login" className="hidden sm:inline" data-testid="nav-login-link">
                                <Button variant="ghost" size="sm">Log in</Button>
                            </Link>
                            <Link to="/signup" data-testid="nav-signup-link">
                                <Button size="sm" className="bg-brand-ink hover:bg-black text-white">
                                    Start free
                                </Button>
                            </Link>
                        </>
                    )}
                </div>
            </div>
        </header>
    );
}
