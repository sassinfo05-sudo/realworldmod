# ZANELVO — HANDOFF (Round 6) & TASKS LEFT FOR NEXT AGENT
_Last updated: this session (round 6). Read WHATS_LEFT.md + CHANGELOG.md too._

---
## 0. CRITICAL FIRST STEP — env is wiped on every import
`backend/.env`, `frontend/.env` and Mongo are EMPTY after an import. Rebuild before anything:

**/app/backend/.env** (key lines)
```
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=<any long random string>
EMERGENT_LLM_KEY=<EMERGENT_LLM_KEY — fetch via emergent_integrations_manager>   # fetch via emergent_integrations_manager if changed
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
CORS_ORIGINS=*
```
**/app/frontend/.env**
```
REACT_APP_BACKEND_URL=https://bootstrap-fix-2.preview.emergentagent.com   # from /app/.emergent config
WDS_SOCKET_PORT=443
```
Then: install deps and restart.
- Backend deps: `pip install -r requirements.txt` FAILS on a resolver clash between the pinned
  `emergentintegrations==0.2.0` and the direct litellm whl URL. Workaround that works:
  `grep -v -i emergentintegrations requirements.txt > /tmp/r.txt && pip install -r /tmp/r.txt`
  (emergentintegrations is already installed in the image). Then
  `pip install emergentintegrations --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/` if missing.
- Frontend: `cd /app/frontend && yarn install`
- `sudo supervisorctl restart all` ; backend auto-seeds founder + owner + 6 demo orgs on startup.

## 1. Preview + credentials (seed regenerates passwords each fresh seed — check /app/memory/test_credentials.md)
- Preview: current run = https://bootstrap-fix-2.preview.emergentagent.com
- Owner (customer dashboard /app): `owner@zanelvo.com` / `<rotated — see test_credentials.md>`
- Founder (staff panel /staff): `founder@zanelvo.com` / `<rotated — see test_credentials.md>`
- STAFF PANEL LOGIN IS A SEPARATE FLOW: POST `/api/staff/auth/login` (2FA auto-skipped when the
  platform email sender is unconfigured). Do NOT try to enter /staff by copying an /api/auth/login
  token into localStorage — log in through the /staff/login UI (click "Staff sign in" → form).
  For screenshot automation: click "Staff sign in", fill email+password, submit, THEN navigate.

## 2. LLM / image integrations (Emergent universal key, emergentintegrations)
- Helper: `app/services/llm.py` — `generate_text`, `generate_json` (text, provider/model from config),
  and NEW `generate_image(prompt)` → base64 PNG via Gemini Nano Banana.
- Config (`app/config.py`): text default `anthropic/claude-sonnet-4-6`; image `gemini/gemini-3.1-flash-image-preview`.
- NEVER log full base64 (prefix only). Image gen ~8-20s and consumes credits.

---
## 3. WHAT WAS BUILT & TESTED THIS SESSION (rounds 5-6) — all green
Round 5 (backend 14/14, frontend 4/4):
- **Shipping/selling suite**: `services/shipping.py` + `routes/shipping.py` (+`public_router`) + page
  `pages/dashboard/Shipping.jsx` (nav Sell→Shipping). Zones/rates, carrier directory + aggregators,
  countries allowlist, inventory adjust/log/low-stock/bulk, order ship+tracking, invoice/packing HTML,
  buy-now shipping in checkout total. Product `weight_grams`/`requires_shipping`.
- **Product form depth** (Products.jsx): compare-at, digital/physical, weight, tags, variants, SEO.
- **Logo Studio SVG maker**: `routes/branding.py` (`/api/branding` GET+PUT) + `pages/dashboard/LogoStudio.jsx`.

Round 6 (backend 20/20 checks, frontend 3/4 + fraud page verified by screenshot):
- **AI logo generation**: `POST /api/branding/ai-logo` (Gemini Nano Banana) → data-uri PNGs;
  LogoStudio.jsx has an "AI logo generator" mode; `logo_image` persists on branding.
- **Multi-language**: `routes/localization.py` — `/api/localization/languages|settings|translate`
  + public `/api/public/localization/{org_id}/translate` (LLM translate + `translation_cache`).
  Page `pages/dashboard/Localization.jsx` (nav → Languages).
- **Anti-abuse**: `antifraud.py` now captures `X-Device-Id` header + user_agent + per-device 24h
  velocity; `GET /api/staff/fraud/overview` (require_staff 'audit'); page `pages/staff/StaffFraud.jsx`
  (staff nav "Abuse & fraud", /staff/fraud). Frontend api client sends a stable `X-Device-Id`.
- **Storefront logo**: public `/api/public/store/{org_id}/products` now returns `branding{logo_svg,logo_image}`;
  `Storefront.jsx` header renders the saved logo.

Router registrations (server.py): shipping.router + shipping.public_router, branding.router,
localization.router + public_router. store.public_router already there.

---
## 4. TASKS STILL LEFT (priority order) — for the next agent
Each is a real, distinct chunk. Backend LLM/image helpers + Emergent key already wired, so lean on them.

1. **AI logo = pick provider properly.** Currently hard-defaulted to Gemini Nano Banana. The user was
   never asked Gemini vs OpenAI (gpt-image-1). If they want choice, add an owner/staff setting +
   swap `config.IMAGE_PROVIDER/IMAGE_MODEL`. (integration playbooks already fetched: gemini image =
   `gemini-3.1-flash-image-preview`; openai path exists in emergentintegrations.)

2. **Onboarding rework (item 2, NOT started).** Move the signup interview OUT of signup into the
   dashboard; add a "build from scratch" path + a template gallery; humanize the interview question
   copy. Interview steps live in `app/routes/onboarding.py` (INTERVIEW_STEPS) — copy rewrite is low
   risk; the signup/flow restructure is higher risk (touches auth/signup + first-run redirect).

3. **Professional dashboard redesign (item 4, NOT started).** Make DashboardShell + pages feel like
   premium Wix/Shopify (less "gaming"). Subjective + high regression risk — do incrementally, keep
   data-testids, screenshot before/after. Consider spacing, typography, card system, empty states.

4. **Drag & drop uploads everywhere (item 5, NOT started).** There's an existing `MediaPicker`
   component. Add drag-drop + chunked upload; reuse across editor, products, marketing, profile,
   email. Chunked upload to bypass proxy limits; store to a persistent path.

5. **Marketing 100× (item 7, PARTIALLY exists).** `routes/marketing.py` already has campaigns,
   ai-assist, automations, creative/generate, bundles. STILL MISSING: real analytics
   (opens/clicks/conversions via tracking pixel + click-redirect, revenue attribution), UTM builder,
   A/B testing, and turning thin stat pages into real dashboards. Add tracking endpoints +
   `marketing_events` collection + analytics rollups; front the numbers in Marketing.jsx.

6. **Website editor overhaul (item 8, NOT started).** Biggest item. Editor is in `routes/editor.py`
   (+ WebsiteTheme model now has optional `logo_svg`) and frontend editor/blocks. Wants a much richer
   editor. Multi-session; scope carefully. NOTE: render the saved `theme.logo_svg` in the PUBLIC
   site header too (only the Storefront header uses branding today; PublicSite.jsx does not yet).

7. **Multi-language on the actual storefront/site (item 9, backend DONE, UI wiring left).** Translation
   API + settings exist and are tested. STILL TODO: a language switcher on the public Storefront /
   PublicSite that calls the public translate endpoint and swaps visible strings; cache client-side.

8. **Live shipping rates + labels (needs keys).** Current shipping is a native rules engine (works
   with no keys). To offer real-time carrier rates + printable labels, integrate Shippo or EasyPost
   (call integration_playbook_expert_v2, then ask user for the key). The carrier directory UI already
   lists these aggregators as "connect to enable".

9. **Anti-abuse depth (item 6 follow-ups).** Add blocking of repeat trial/discount abuse using the
   device/IP history now being logged; optional: surface a "block this IP/device" action in
   StaffFraud.jsx (needs a blocklist collection + a check in signup/discount paths).

10. **Global bug sweep + full regression** once the above land.

---
## 5. GOTCHAS / CONVENTIONS
- Use UUID string ids everywhere (no Mongo ObjectId in JSON). All API routes under `/api`.
- Owner endpoints: `Depends(current_user)` + `Depends(require_org)`. Staff: `require_staff('<perm>')`.
- Frontend design tokens: `brand-copper`, `brand-ink`, `brand-line`, `brand-cream`, font-display.
  card = `rounded-2xl border border-brand-line bg-white p-5 shadow-sm`.
- Add every new page to App.js routes + DashboardShell NAV (+ title map) or StaffShell NAV.
- ALWAYS: read test_result.md before invoking testing agents; never edit its "Testing Protocol";
  ask user before FRONTEND testing (backend testing is fine anytime).
- The `mcp_create_file` tool truncated a long file once this session — verify big new files with
  `wc -l` / grep after writing.
