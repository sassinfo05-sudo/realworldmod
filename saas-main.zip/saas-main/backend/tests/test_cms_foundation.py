"""Dynamic CMS & Extensions Foundation — fresh regression.

Covers the post-Round-15 acceptance journeys against the LIVE API:
  * collection CRUD + field validation + schema version bump
  * item CRUD, unique/slug conflict, revisions + rollback
  * tenant isolation (org A cannot read org B's collection / items / templates)
  * private-field projection on the PUBLIC endpoints (never leaks private fields / drafts / archived)
  * CSV import bounded limits
  * plan limits (free: 1 collection / 100 items / 0 connectors) enforced server-side
  * dynamic list + detail public rendering, slug conflict on template routes
  * external connector SSRF protection (localhost / private / metadata / non-https / bad port all blocked)
  * stored-XSS payload in rich_text is sanitised (renders harmlessly)

Creds resolved from env / memory/test_credentials.md (never hardcoded). Plans set directly in Mongo
(the runtime source of truth). AI propose/apply is metered and covered by test_atomic_metering; a light
smoke of /cms/ai/propose is gated behind RUN_CMS_AI=1 so the shared LLM budget is not drained by default.
"""
from __future__ import annotations

import os
import secrets
import uuid

import pytest
import requests

import _creds

API = _creds.api()
_IP = f"10.61.{secrets.randbelow(250)}.{secrets.randbelow(250)}"


def _hdr(tok):
    return {"Authorization": f"Bearer {tok}", "X-Forwarded-For": _IP}


def _signup():
    # Fresh random source IP per signup so the (wanted) per-IP signup limiter is never a false failure.
    ip = f"10.{secrets.randbelow(250)}.{secrets.randbelow(250)}.{secrets.randbelow(250)}"
    email = f"cms-{uuid.uuid4().hex[:10]}@example.com"
    r = requests.post(f"{API}/auth/signup", headers={"X-Forwarded-For": ip},
                      json={"email": email, "password": "CmsTest-Pass1!", "full_name": "CMS Test",
                            "business_name": f"CMS Co {uuid.uuid4().hex[:4]}"}, timeout=30)
    assert r.status_code in (200, 201), r.text
    tok = r.json()["access_token"]
    me = requests.get(f"{API}/auth/me", headers=_hdr(tok), timeout=30).json()
    org_id = me.get("org_id") or (me.get("user") or {}).get("org_id")
    assert org_id, me
    return {"token": tok, "org_id": org_id, "email": email}


def _set_plan(org_id, plan_code):
    from pymongo import MongoClient
    db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
    db.subscriptions.update_one({"org_id": org_id},
                                {"$set": {"plan_code": plan_code, "status": "active"}}, upsert=True)


@pytest.fixture(scope="module")
def owner():
    o = _signup()
    _set_plan(o["org_id"], "autopilot")  # high limits so CRUD tests are not blocked
    return o


# --------------------------------------------------------------------------- collections + items
def _mk_team_collection(tok):
    body = {
        "name": "Team",
        "display_field": "name",
        "fields": [
            {"label": "Name", "type": "short_text", "required": True, "searchable": True},
            {"label": "Role", "type": "short_text", "searchable": True},
            {"label": "Bio", "type": "rich_text"},
            {"label": "Email", "type": "email", "private": True},   # private → never public
            {"label": "Slug", "type": "slug"},
        ],
    }
    r = requests.post(f"{API}/cms/collections", headers=_hdr(tok), json=body, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()


def test_collection_crud_and_field_validation(owner):
    tok = owner["token"]
    coll = _mk_team_collection(tok)
    assert coll["internal_id"]
    assert coll["schema_version"] == 1
    keys = {f["key"] for f in coll["fields"]}
    assert {"name", "role", "bio", "email", "slug"} <= keys

    # invalid field type rejected
    bad = requests.post(f"{API}/cms/collections", headers=_hdr(tok),
                        json={"name": "Bad", "fields": [{"label": "X", "type": "nonsense"}]}, timeout=30)
    assert bad.status_code == 400, bad.text

    # patch → schema version bumps when fields change
    patch = requests.patch(f"{API}/cms/collections/{coll['id']}", headers=_hdr(tok),
                           json={"fields": coll["fields"] + [{"label": "Phone", "type": "phone"}]}, timeout=30)
    assert patch.status_code == 200, patch.text
    assert patch.json()["schema_version"] == 2

    # email validation on item create
    bad_item = requests.post(f"{API}/cms/collections/{coll['id']}/items", headers=_hdr(tok),
                             json={"values": {"name": "A", "email": "not-an-email"}}, timeout=30)
    assert bad_item.status_code == 400, bad_item.text


def test_items_crud_revisions_rollback_and_slug(owner):
    tok = owner["token"]
    coll = _mk_team_collection(tok)
    cid = coll["id"]
    # create 3
    ids = []
    for nm in ("Ada Lovelace", "Alan Turing", "Grace Hopper"):
        r = requests.post(f"{API}/cms/collections/{cid}/items", headers=_hdr(tok),
                          json={"values": {"name": nm, "role": "Engineer"}, "status": "published"}, timeout=30)
        assert r.status_code == 200, r.text
        ids.append(r.json()["id"])
        assert r.json()["slug"]  # slug auto-generated

    # list + search + sort + pagination
    lst = requests.get(f"{API}/cms/collections/{cid}/items?q=Ada&page=1&page_size=10",
                       headers=_hdr(tok), timeout=30).json()
    assert lst["total"] >= 1 and any(i["values"]["name"] == "Ada Lovelace" for i in lst["items"])

    # update → creates a revision, then rollback
    up = requests.patch(f"{API}/cms/items/{ids[0]}", headers=_hdr(tok),
                        json={"values": {"role": "Countess"}}, timeout=30)
    assert up.status_code == 200 and up.json()["values"]["role"] == "Countess"
    revs = requests.get(f"{API}/cms/items/{ids[0]}/revisions", headers=_hdr(tok), timeout=30).json()["revisions"]
    assert len(revs) >= 2
    # roll back to the oldest (role == Engineer)
    oldest = revs[-1]
    rb = requests.post(f"{API}/cms/items/{ids[0]}/rollback", headers=_hdr(tok),
                       json={"revision_id": oldest["id"]}, timeout=30)
    assert rb.status_code == 200 and rb.json()["values"]["role"] == "Engineer"

    # duplicate
    dup = requests.post(f"{API}/cms/items/{ids[1]}/duplicate", headers=_hdr(tok), timeout=30)
    assert dup.status_code == 200 and dup.json()["status"] == "draft"


def test_unique_constraint(owner):
    tok = owner["token"]
    r = requests.post(f"{API}/cms/collections", headers=_hdr(tok),
                      json={"name": "SKUs", "fields": [{"label": "Code", "type": "short_text", "unique": True}]},
                      timeout=30)
    cid = r.json()["id"]
    a = requests.post(f"{API}/cms/collections/{cid}/items", headers=_hdr(tok),
                      json={"values": {"code": "ABC-1"}}, timeout=30)
    assert a.status_code == 200
    b = requests.post(f"{API}/cms/collections/{cid}/items", headers=_hdr(tok),
                      json={"values": {"code": "ABC-1"}}, timeout=30)
    assert b.status_code == 409, b.text


def test_xss_richtext_sanitised(owner):
    tok = owner["token"]
    coll = _mk_team_collection(tok)
    payload = '<img src=x onerror=alert(1)><script>alert(2)</script><b>ok</b>'
    r = requests.post(f"{API}/cms/collections/{coll['id']}/items", headers=_hdr(tok),
                      json={"values": {"name": "XSS", "bio": payload}}, timeout=30)
    assert r.status_code == 200, r.text
    bio = r.json()["values"]["bio"]
    assert "onerror" not in bio.lower()
    assert "<script" not in bio.lower()


def test_csv_import_bounded(owner):
    tok = owner["token"]
    r = requests.post(f"{API}/cms/collections", headers=_hdr(tok),
                      json={"name": "Contacts CSV", "fields": [{"label": "Name", "type": "short_text"}]}, timeout=30)
    cid = r.json()["id"]
    csv_text = "Name\n" + "\n".join(f"Person {i}" for i in range(5))
    imp = requests.post(f"{API}/cms/collections/{cid}/import", headers=_hdr(tok),
                        json={"csv_text": csv_text, "mapping": {"Name": "name"}}, timeout=60)
    assert imp.status_code == 200, imp.text
    assert imp.json()["created"] == 5

    # oversized CSV rejected (413)
    big = "Name\n" + ("x" * (5 * 1024 * 1024 + 10))
    over = requests.post(f"{API}/cms/collections/{cid}/import", headers=_hdr(tok),
                         json={"csv_text": big, "mapping": {"Name": "name"}}, timeout=60)
    assert over.status_code == 413, over.status_code


# --------------------------------------------------------------------------- tenant isolation
def test_tenant_isolation():
    a = _signup(); _set_plan(a["org_id"], "autopilot")
    b = _signup(); _set_plan(b["org_id"], "autopilot")
    coll = _mk_team_collection(a["token"])
    item = requests.post(f"{API}/cms/collections/{coll['id']}/items", headers=_hdr(a["token"]),
                         json={"values": {"name": "Secret Person"}}, timeout=30).json()

    # B cannot read A's collection or items
    assert requests.get(f"{API}/cms/collections/{coll['id']}", headers=_hdr(b["token"]), timeout=30).status_code == 404
    assert requests.get(f"{API}/cms/collections/{coll['id']}/items", headers=_hdr(b["token"]), timeout=30).status_code == 404
    assert requests.get(f"{API}/cms/items/{item['id']}/revisions", headers=_hdr(b["token"]), timeout=30).json()["revisions"] == []
    # B's collection list must not include A's collection
    b_list = requests.get(f"{API}/cms/collections", headers=_hdr(b["token"]), timeout=30).json()["collections"]
    assert all(c["id"] != coll["id"] for c in b_list)


# --------------------------------------------------------------------------- plan limits
def test_free_plan_limits():
    o = _signup()
    _set_plan(o["org_id"], "free")
    tok = o["token"]
    # 1 collection allowed
    c1 = requests.post(f"{API}/cms/collections", headers=_hdr(tok),
                       json={"name": "One", "fields": [{"label": "N", "type": "short_text"}]}, timeout=30)
    assert c1.status_code == 200
    c2 = requests.post(f"{API}/cms/collections", headers=_hdr(tok),
                       json={"name": "Two", "fields": [{"label": "N", "type": "short_text"}]}, timeout=30)
    assert c2.status_code == 402 and c2.json()["detail"]["error"] == "cms_collection_limit"

    # connectors not in free plan
    conn = requests.post(f"{API}/cms/connectors", headers=_hdr(tok),
                         json={"name": "x", "url": "https://api.example.com/data"}, timeout=30)
    assert conn.status_code == 402 and conn.json()["detail"]["error"] == "cms_connector_not_in_plan"

    # limits endpoint reflects the plan
    lim = requests.get(f"{API}/cms/limits", headers=_hdr(tok), timeout=30).json()
    assert lim["max_collections"] == 1 and lim["max_connectors"] == 0


# --------------------------------------------------------------------------- dynamic pages (public)
def test_dynamic_pages_public_and_private_projection():
    o = _signup(); _set_plan(o["org_id"], "autopilot")
    tok = o["token"]
    coll = _mk_team_collection(tok)
    cid = coll["id"]
    # published item with a private email
    pub = requests.post(f"{API}/cms/collections/{cid}/items", headers=_hdr(tok),
                        json={"values": {"name": "Public Person", "role": "CEO", "email": "secret@corp.com"},
                              "status": "published"}, timeout=30).json()
    # draft item (must NEVER appear publicly)
    requests.post(f"{API}/cms/collections/{cid}/items", headers=_hdr(tok),
                  json={"values": {"name": "Draft Person"}, "status": "draft"}, timeout=30)

    # need a website slug for this org to resolve public routes
    from pymongo import MongoClient
    db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
    slug = f"cms-site-{uuid.uuid4().hex[:8]}"
    db.websites.update_one({"org_id": o["org_id"]},
                           {"$set": {"slug": slug, "org_id": o["org_id"], "status": "published"}}, upsert=True)

    tpl = requests.post(f"{API}/cms/templates", headers=_hdr(tok),
                        json={"collection_id": cid, "site_slug": slug, "route_base": "team",
                              "slug_field": "slug",
                              "detail_layout": {"blocks": []},
                              "seo": {"title": "{{name}} — {{role}}"}}, timeout=30).json()
    assert tpl["route_base"] == "team"

    # duplicate route conflict
    dup = requests.post(f"{API}/cms/templates", headers=_hdr(tok),
                        json={"collection_id": cid, "site_slug": slug, "route_base": "team"}, timeout=30)
    assert dup.status_code == 409

    # not published yet → public list 404
    assert requests.get(f"{API}/public/cms/{slug}/team", timeout=30).status_code == 404
    # publish
    requests.patch(f"{API}/cms/templates/{tpl['id']}", headers=_hdr(tok),
                   json={"status": "published"}, timeout=30)

    lst = requests.get(f"{API}/public/cms/{slug}/team", timeout=30)
    assert lst.status_code == 200, lst.text
    data = lst.json()
    # only the published item; draft excluded
    names = [i["values"].get("name") for i in data["items"]]
    assert "Public Person" in names and "Draft Person" not in names
    # private field 'email' must NOT be present publicly
    for i in data["items"]:
        assert "email" not in i["values"]

    # detail page + resolved SEO, private field still stripped
    detail = requests.get(f"{API}/public/cms/{slug}/team/{pub['slug']}", timeout=30)
    assert detail.status_code == 200, detail.text
    dj = detail.json()
    assert "email" not in dj["item"]["values"]
    assert dj["seo"]["title"] == "Public Person — CEO"

    # unknown slug → 404
    assert requests.get(f"{API}/public/cms/{slug}/team/does-not-exist", timeout=30).status_code == 404


# --------------------------------------------------------------------------- SSRF connector
@pytest.fixture(scope="module")
def conn_owner():
    o = _signup(); _set_plan(o["org_id"], "autopilot")
    return o


@pytest.mark.parametrize("url", [
    "http://api.example.com/data",          # non-https
    "https://localhost/data",               # localhost
    "https://127.0.0.1/data",               # loopback
    "https://169.254.169.254/latest/meta",  # cloud metadata
    "https://10.0.0.5/data",                # private
    "https://metadata.google.internal/x",   # internal hostname
    "https://example.com:8080/data",        # non-approved port
])
def test_connector_ssrf_blocked(conn_owner, url):
    tok = conn_owner["token"]
    r = requests.post(f"{API}/cms/connectors", headers=_hdr(tok),
                      json={"name": "ssrf", "url": url}, timeout=30)
    assert r.status_code == 400, f"expected block for {url}, got {r.status_code} {r.text[:120]}"
    assert r.json()["detail"]["error"] == "ssrf_blocked"


def test_connector_secret_never_returned(conn_owner):
    tok = conn_owner["token"]
    r = requests.post(f"{API}/cms/connectors", headers=_hdr(tok),
                      json={"name": "public-api", "url": "https://example.com/",
                            "headers": {"Authorization": "Bearer super-secret-token"}}, timeout=30)
    assert r.status_code == 200, r.text
    body = r.json()
    # only header KEYS are ever returned, never the secret value
    assert body.get("header_keys") == ["Authorization"]
    assert "super-secret-token" not in requests.get(f"{API}/cms/connectors", headers=_hdr(tok), timeout=30).text


# --------------------------------------------------------------------------- AI (metered) — gated
@pytest.mark.skipif(os.environ.get("RUN_CMS_AI") != "1", reason="AI smoke drains shared LLM budget; set RUN_CMS_AI=1")
def test_ai_propose_is_metered_preview():
    o = _signup(); _set_plan(o["org_id"], "autopilot")
    tok = o["token"]
    r = requests.post(f"{API}/cms/ai/propose", headers=_hdr(tok),
                      json={"prompt": "Create a team directory with a page for each employee."}, timeout=90)
    assert r.status_code in (200, 402, 502), r.text
    if r.status_code == 200:
        j = r.json()
        assert j["preview"] is True and "will_create" in j
