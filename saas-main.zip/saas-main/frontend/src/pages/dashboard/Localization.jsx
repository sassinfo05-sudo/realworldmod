import React, { useEffect, useState, useCallback } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Languages, Check, Sparkles } from "lucide-react";

const card = "rounded-2xl border border-brand-line bg-white p-5 shadow-sm";

export default function Localization() {
    const [langs, setLangs] = useState([]);
    const [settings, setSettings] = useState({ enabled: false, default_language: "en", languages: ["en"] });
    const [busy, setBusy] = useState(false);
    const [sample, setSample] = useState("Welcome to our store — free shipping on orders over $50!");
    const [target, setTarget] = useState("es");
    const [result, setResult] = useState("");
    const [translating, setTranslating] = useState(false);

    // Authored (owner-written) translations that override AI on the live site
    const [authLang, setAuthLang] = useState("es");
    const [authEntries, setAuthEntries] = useState({});
    const [authSources, setAuthSources] = useState([]);
    const [authLoading, setAuthLoading] = useState(false);
    const [authSaving, setAuthSaving] = useState(false);
    const [authSuggesting, setAuthSuggesting] = useState(false);

    const loadOverrides = useCallback(async (lang) => {
        setAuthLoading(true);
        try {
            const { data } = await api.get("/localization/overrides", { params: { lang } });
            setAuthEntries(data.entries || {});
            setAuthSources(data.sources || []);
        } catch { setAuthEntries({}); setAuthSources([]); }
        finally { setAuthLoading(false); }
    }, []);
    useEffect(() => { loadOverrides(authLang); }, [authLang, loadOverrides]);

    const saveOverrides = async () => {
        setAuthSaving(true);
        try {
            const cleaned = Object.fromEntries(Object.entries(authEntries).filter(([, v]) => (v || "").trim()));
            const { data } = await api.put("/localization/overrides", { lang: authLang, entries: cleaned });
            setAuthEntries(data.entries || {});
            toast.success(`Saved ${data.count} translation${data.count === 1 ? "" : "s"}`);
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not save"); }
        finally { setAuthSaving(false); }
    };

    const aiSuggest = async () => {
        setAuthSuggesting(true);
        try {
            const { data } = await api.post("/localization/overrides/auto", { lang: authLang, sources: authSources });
            const sug = data.suggestions || {};
            setAuthEntries((prev) => {
                const next = { ...prev };
                Object.entries(sug).forEach(([k, v]) => { if (!(next[k] || "").trim()) next[k] = v; });
                return next;
            });
            toast.success(`Filled ${Object.keys(sug).length} suggestions — review, then Save`);
        } catch (e) { toast.error(e?.response?.data?.detail || "AI suggest failed"); }
        finally { setAuthSuggesting(false); }
    };

    const load = useCallback(async () => {
        try {
            const [l, s] = await Promise.all([api.get("/localization/languages"), api.get("/localization/settings")]);
            setLangs(l.data.languages || []);
            setSettings(s.data);
        } catch { /* noop */ }
    }, []);
    useEffect(() => { load(); }, [load]);

    const toggleLang = (code) => {
        setSettings((p) => {
            const has = p.languages.includes(code);
            let languages = has ? p.languages.filter((c) => c !== code) : [...p.languages, code];
            if (!languages.includes(p.default_language)) languages = [p.default_language, ...languages];
            return { ...p, languages };
        });
    };

    const save = async () => {
        setBusy(true);
        try {
            const { data } = await api.put("/localization/settings", settings);
            setSettings(data);
            toast.success("Language settings saved");
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not save"); }
        finally { setBusy(false); }
    };

    const translate = async () => {
        setTranslating(true); setResult("");
        try {
            const { data } = await api.post("/localization/translate", { texts: [sample], target });
            setResult((data.translations || [])[0] || "");
        } catch (e) { toast.error(e?.response?.data?.detail || "Translation failed"); }
        finally { setTranslating(false); }
    };

    return (
        <div className="max-w-4xl mx-auto p-6 space-y-6">
            <div>
                <h1 className="font-display text-2xl text-brand-ink flex items-center gap-2">
                    <Languages className="w-6 h-6 text-brand-copper" /> Languages
                </h1>
                <p className="text-brand-ink/60 mt-1 text-sm">
                    Sell to the world. Turn on the languages you want, and your storefront content is translated automatically with AI.
                </p>
            </div>

            <div className={card + " space-y-4"}>
                <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" checked={settings.enabled} onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })} data-testid="loc-enabled" />
                    <span className="text-sm font-medium text-brand-ink">Enable multi-language storefront</span>
                </label>

                <div>
                    <label className="text-xs text-zinc-500">Default (original) language</label>
                    <select value={settings.default_language} onChange={(e) => setSettings({ ...settings, default_language: e.target.value })} className="w-full max-w-xs border border-brand-line rounded-md p-2 text-sm bg-white block mt-1" data-testid="loc-default">
                        {langs.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
                    </select>
                </div>

                <div>
                    <div className="text-xs text-zinc-500 mb-2">Languages you offer</div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {langs.map((l) => {
                            const on = settings.languages.includes(l.code);
                            return (
                                <button key={l.code} onClick={() => toggleLang(l.code)} data-testid={`loc-lang-${l.code}`}
                                    className={`flex items-center justify-between px-3 py-2 rounded-lg border text-sm ${on ? "border-brand-copper bg-brand-cream/40 text-brand-ink" : "border-brand-line text-zinc-500"}`}>
                                    {l.name}{on && <Check className="w-4 h-4 text-brand-copper" />}
                                </button>
                            );
                        })}
                    </div>
                </div>
                <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={save} data-testid="loc-save">{busy ? "Saving…" : "Save languages"}</Button>
            </div>

            <div className={card + " space-y-3"}>
                <div className="text-sm font-medium text-brand-ink flex items-center gap-2"><Sparkles className="w-4 h-4 text-brand-copper" /> Try AI translation</div>
                <textarea value={sample} onChange={(e) => setSample(e.target.value)} rows={2} className="w-full border border-brand-line rounded-md p-2 text-sm" data-testid="loc-sample" />
                <div className="flex items-center gap-2 flex-wrap">
                    <select value={target} onChange={(e) => setTarget(e.target.value)} className="border border-brand-line rounded-md p-2 text-sm bg-white" data-testid="loc-target">
                        {langs.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
                    </select>
                    <Button variant="outline" className="border-brand-line" disabled={translating} onClick={translate} data-testid="loc-translate">{translating ? "Translating…" : "Translate"}</Button>
                </div>
                {result && <div className="rounded-lg bg-brand-cream/40 border border-brand-line p-3 text-sm text-brand-ink" data-testid="loc-result">{result}</div>}
            </div>

            <div className={card + " space-y-3"} data-testid="loc-authored-card">
                <div>
                    <div className="text-sm font-medium text-brand-ink flex items-center gap-2"><Languages className="w-4 h-4 text-brand-copper" /> Authored translations</div>
                    <p className="text-xs text-zinc-500 mt-1">Write exact wording for any phrase on your live site. Authored translations always override the automatic AI translation for that language.</p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                    <label className="text-xs text-zinc-500">Language</label>
                    <select value={authLang} onChange={(e) => setAuthLang(e.target.value)} className="border border-brand-line rounded-md p-2 text-sm bg-white" data-testid="loc-auth-lang">
                        {langs.filter((l) => l.code !== settings.default_language).map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
                    </select>
                    <Button variant="outline" className="border-brand-line" disabled={authSuggesting || authLoading} onClick={aiSuggest} data-testid="loc-auth-suggest">
                        <Sparkles className="w-4 h-4 mr-1" />{authSuggesting ? "Filling…" : "AI fill blanks"}
                    </Button>
                    <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={authSaving} onClick={saveOverrides} data-testid="loc-auth-save">{authSaving ? "Saving…" : "Save translations"}</Button>
                </div>
                {authLoading ? (
                    <div className="text-sm text-zinc-400 py-4">Loading site content…</div>
                ) : authSources.length === 0 ? (
                    <div className="text-sm text-zinc-400 py-4">Publish your website first — its text will appear here to translate.</div>
                ) : (
                    <div className="max-h-96 overflow-y-auto border border-brand-line rounded-lg divide-y divide-brand-line" data-testid="loc-auth-list">
                        {authSources.map((src, i) => (
                            <div key={i} className="grid grid-cols-1 sm:grid-cols-2 gap-2 p-2.5">
                                <div className="text-sm text-zinc-600 leading-snug" data-no-translate>{src}</div>
                                <input
                                    value={authEntries[src] || ""}
                                    onChange={(e) => setAuthEntries((p) => ({ ...p, [src]: e.target.value }))}
                                    placeholder="Translation…"
                                    className="w-full border border-brand-line rounded-md px-2 py-1.5 text-sm"
                                    data-testid={`loc-auth-input-${i}`}
                                />
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}
