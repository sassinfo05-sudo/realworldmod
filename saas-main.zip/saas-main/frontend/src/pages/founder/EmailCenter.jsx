import React, { useEffect, useState, useCallback } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
    Mail, Shield, Megaphone, CreditCard, Headphones, DollarSign, Bell, MailOpen,
    Inbox, Send, Zap, LayoutTemplate, AtSign, Settings2, Reply, RefreshCw, CheckCircle2, Circle, Sparkles,
} from "lucide-react";

const ROLE_META = {
    support: { title: "Customer support", icon: Headphones, help: "Where users email for help. Shown in the footer + Contact links." },
    twofa: { title: "Two-factor codes", icon: Shield, help: "The 'From' address for 2FA codes and security notifications." },
    marketing: { title: "Marketing", icon: Megaphone, help: "Announcements, product updates and campaigns." },
    billing: { title: "Billing & receipts", icon: CreditCard, help: "Invoices, receipts, plan changes and billing failures." },
    noreply: { title: "Transactional / no-reply", icon: MailOpen, help: "System messages (welcome, verification, reset)." },
    sales: { title: "Sales", icon: DollarSign, help: "Sales enquiries and demo requests." },
    notifications: { title: "Notifications", icon: Bell, help: "Product alerts (new booking, new form submission)." },
};

const TABS = [
    { id: "inbox", label: "Inbox", icon: Inbox },
    { id: "compose", label: "Compose", icon: Send },
    { id: "automations", label: "Automations", icon: Zap },
    { id: "templates", label: "Templates", icon: LayoutTemplate },
    { id: "addresses", label: "Addresses", icon: AtSign },
    { id: "provider", label: "Provider", icon: Settings2 },
];

export default function EmailCenter() {
    const [tab, setTab] = useState("inbox");
    const [overview, setOverview] = useState(null);

    const loadOverview = useCallback(async () => {
        try { const { data } = await api.get("/staff/email/overview"); setOverview(data); }
        catch { /* staff perms */ }
    }, []);
    useEffect(() => { loadOverview(); }, [loadOverview]);

    return (
        <div className="p-6 md:p-10" data-testid="founder-emails-page">
            <div className="max-w-5xl">
                <div className="flex items-start justify-between flex-wrap gap-3">
                    <div>
                        <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Email center</div>
                        <h1 className="font-display text-3xl text-brand-ink">Send, receive & automate every email.</h1>
                    </div>
                    {overview && (
                        <span className={`text-xs px-3 py-1.5 rounded-full ${overview.mode === "live" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>
                            {overview.mode === "live" ? `Live · ${overview.provider}` : "Simulated — connect a provider"}
                        </span>
                    )}
                </div>

                {overview && (
                    <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
                        <MiniStat label="Sent" value={overview.counts.sent} />
                        <MiniStat label="Received" value={overview.counts.inbound} />
                        <MiniStat label="Unread" value={overview.counts.unread} />
                        <MiniStat label="Automations on" value={overview.counts.automations_on} />
                    </div>
                )}

                <div className="mt-8 flex gap-1 border-b border-brand-line overflow-x-auto">
                    {TABS.map((t) => (
                        <button key={t.id} onClick={() => setTab(t.id)}
                            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px whitespace-nowrap transition-colors ${tab === t.id ? "border-brand-copper text-brand-copper" : "border-transparent text-zinc-500 hover:text-brand-ink"}`}>
                            <t.icon className="w-4 h-4" /> {t.label}
                        </button>
                    ))}
                </div>

                <div className="mt-6">
                    {tab === "inbox" && <InboxTab onChange={loadOverview} />}
                    {tab === "compose" && <ComposeTab onSent={loadOverview} />}
                    {tab === "automations" && <AutomationsTab onChange={loadOverview} />}
                    {tab === "templates" && <TemplatesTab />}
                    {tab === "addresses" && <AddressesTab />}
                    {tab === "provider" && <ProviderTab onSaved={loadOverview} />}
                </div>
            </div>
        </div>
    );
}

function MiniStat({ label, value }) {
    return (
        <div className="rounded-xl border border-brand-line bg-white p-4">
            <div className="text-xs uppercase tracking-wide text-zinc-400">{label}</div>
            <div className="font-display text-2xl text-brand-ink mt-0.5">{value}</div>
        </div>
    );
}

function InboxTab({ onChange }) {
    const [msgs, setMsgs] = useState([]);
    const [active, setActive] = useState(null);
    const [reply, setReply] = useState("");
    const [busy, setBusy] = useState(false);
    const load = useCallback(async () => {
        const { data } = await api.get("/staff/email/inbox"); setMsgs(data.messages || []);
    }, []);
    useEffect(() => { load(); }, [load]);

    const open = async (m) => {
        setActive(m); setReply("");
        if (!m.read) { try { await api.post(`/staff/email/inbox/${m.id}/read`); load(); onChange?.(); } catch { /* */ } }
    };
    const sendReply = async () => {
        if (!reply.trim()) return;
        setBusy(true);
        try {
            const { data } = await api.post(`/staff/email/inbox/${active.id}/reply`, { message: reply, role: active.to_email?.includes("sales") ? "sales" : "support" });
            toast.success(data.simulated ? "Reply queued (simulated)" : "Reply sent");
            setReply(""); load(); onChange?.();
        } catch { toast.error("Reply failed"); } finally { setBusy(false); }
    };
    const simulate = async () => { await api.post("/staff/email/inbox/simulate"); load(); onChange?.(); toast.success("Sample inbound added"); };

    return (
        <div className="grid md:grid-cols-[320px_1fr] gap-4">
            <div className="rounded-2xl border border-brand-line bg-white overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-brand-line">
                    <span className="text-sm font-medium text-brand-ink">Inbox ({msgs.length})</span>
                    <button onClick={simulate} title="Add a sample inbound" className="text-xs text-brand-copper hover:underline flex items-center gap-1"><RefreshCw className="w-3 h-3" /> Simulate</button>
                </div>
                <div className="max-h-[440px] overflow-auto divide-y divide-brand-line">
                    {msgs.length === 0 && <div className="p-6 text-center text-sm text-zinc-400">No messages yet.<br />Real inbound needs your DNS/MX set. Tap Simulate to preview.</div>}
                    {msgs.map((m) => (
                        <button key={m.id} onClick={() => open(m)} className={`w-full text-left p-4 hover:bg-brand-cream/40 ${active?.id === m.id ? "bg-brand-cream/60" : ""}`}>
                            <div className="flex items-center gap-2">
                                {!m.read && <span className="w-2 h-2 rounded-full bg-brand-copper shrink-0" />}
                                <span className="font-medium text-sm text-brand-ink truncate">{m.from_name || m.from_email}</span>
                                <span className="ml-auto text-[10px] text-zinc-400">{(m.to_email || "").split("@")[0]}@</span>
                            </div>
                            <div className="text-sm text-brand-ink/80 truncate mt-0.5">{m.subject}</div>
                            <div className="text-xs text-zinc-400 truncate">{m.text}</div>
                        </button>
                    ))}
                </div>
            </div>
            <div className="rounded-2xl border border-brand-line bg-white p-6 min-h-[300px]">
                {!active ? <div className="text-zinc-400 text-sm h-full flex items-center justify-center">Select a message to read & reply.</div> : (
                    <>
                        <div className="text-lg font-display text-brand-ink">{active.subject}</div>
                        <div className="text-sm text-zinc-500 mt-1">From <b>{active.from_name || active.from_email}</b> &lt;{active.from_email}&gt; → {active.to_email}</div>
                        <div className="mt-4 text-sm text-brand-ink/80 whitespace-pre-wrap border-t border-brand-line pt-4">{active.text}</div>
                        {active.replied && <div className="mt-3 text-xs text-emerald-600 flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> Replied</div>}
                        <div className="mt-5 border-t border-brand-line pt-4">
                            <div className="text-xs text-zinc-500 mb-1 flex items-center gap-1"><Reply className="w-3.5 h-3.5" /> Reply from {active.to_email?.includes("sales") ? "sales@" : "support@"}</div>
                            <textarea value={reply} onChange={(e) => setReply(e.target.value)} rows={5} placeholder="Write a professional reply…" className="w-full border border-brand-line rounded-lg px-3 py-2 text-sm" />
                            <Button onClick={sendReply} disabled={busy} className="mt-2 bg-brand-copper hover:bg-brand-copperHover text-white"><Send className="w-4 h-4 mr-1" /> {busy ? "Sending…" : "Send reply"}</Button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

function ComposeTab({ onSent }) {
    const [form, setForm] = useState({ to: "", subject: "", message: "", role: "support" });
    const [busy, setBusy] = useState(false);
    const [aiPrompt, setAiPrompt] = useState("");
    const [aiTone, setAiTone] = useState("friendly");
    const [aiBusy, setAiBusy] = useState(false);
    const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
    const send = async () => {
        if (!form.to || !form.subject) return toast.error("To + subject required");
        setBusy(true);
        try {
            const { data } = await api.post("/staff/email/send", form);
            toast.success(data.simulated ? "Queued (simulated)" : "Sent");
            setForm({ to: "", subject: "", message: "", role: form.role }); onSent?.();
        } catch { toast.error("Send failed"); } finally { setBusy(false); }
    };
    const aiDraft = async () => {
        if (!aiPrompt.trim()) return toast.error("Tell the AI what to write about");
        setAiBusy(true);
        try {
            const { data } = await api.post("/staff/email/ai-draft", {
                prompt: aiPrompt, tone: aiTone, existing: form.message || "",
            });
            setForm((p) => ({ ...p, subject: data.subject || p.subject, message: data.message || p.message }));
            toast.success("AI draft ready — review & edit before sending");
        } catch (e) { toast.error(e?.response?.data?.detail || "AI draft failed"); }
        finally { setAiBusy(false); }
    };
    const input = "w-full border border-brand-line rounded-lg px-3 py-2 text-sm";
    return (
        <div className="rounded-2xl border border-brand-line bg-white p-6 max-w-2xl">
            <div className="mb-5 rounded-xl border border-indigo-100 bg-gradient-to-br from-indigo-50 to-fuchsia-50 p-4" data-testid="ai-compose-panel">
                <div className="flex items-center gap-2 text-sm font-medium text-indigo-900">
                    <Sparkles className="w-4 h-4" /> Write with AI
                </div>
                <textarea className={`${input} mt-2 bg-white`} rows={2} value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="e.g. Apologize for a shipping delay and offer 10% off their next order" />
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                    <select className="border border-brand-line rounded-lg px-2 py-1.5 text-xs bg-white" value={aiTone} onChange={(e) => setAiTone(e.target.value)}>
                        {["friendly", "professional", "warm", "urgent", "concise"].map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <Button onClick={aiDraft} disabled={aiBusy} size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-white" data-testid="ai-draft-btn">
                        <Sparkles className="w-3.5 h-3.5 mr-1" /> {aiBusy ? "Writing…" : (form.message ? "Improve draft" : "Generate draft")}
                    </Button>
                    <span className="text-[11px] text-indigo-700/70">Fills subject + message below · counts toward AI usage</span>
                </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
                <label className="text-sm"><div className="text-xs text-zinc-500 mb-1">From</div>
                    <select className={input} value={form.role} onChange={(e) => set("role", e.target.value)}>
                        <option value="support">support@ (Support)</option>
                        <option value="sales">sales@ (Sales)</option>
                    </select></label>
                <label className="text-sm"><div className="text-xs text-zinc-500 mb-1">To</div>
                    <input className={input} value={form.to} onChange={(e) => set("to", e.target.value)} placeholder="customer@example.com" /></label>
            </div>
            <label className="text-sm block mt-4"><div className="text-xs text-zinc-500 mb-1">Subject</div>
                <input className={input} value={form.subject} onChange={(e) => set("subject", e.target.value)} placeholder="How can we help?" /></label>
            <label className="text-sm block mt-4"><div className="text-xs text-zinc-500 mb-1">Message</div>
                <textarea className={input} rows={8} value={form.message} onChange={(e) => set("message", e.target.value)} placeholder="Write a professional message — it's wrapped in your branded template automatically." /></label>
            <Button onClick={send} disabled={busy} className="mt-4 bg-brand-copper hover:bg-brand-copperHover text-white"><Send className="w-4 h-4 mr-1" /> {busy ? "Sending…" : "Send email"}</Button>
        </div>
    );
}

function AutomationsTab({ onChange }) {
    const [items, setItems] = useState([]);
    const load = useCallback(async () => { const { data } = await api.get("/staff/email/automations"); setItems(data.automations || []); }, []);
    useEffect(() => { load(); }, [load]);
    const toggle = async (kind, enabled) => {
        try { await api.post(`/staff/email/automations/${kind}`, { enabled }); load(); onChange?.(); }
        catch { toast.error("Failed"); }
    };
    return (
        <div className="space-y-3">
            <p className="text-sm text-zinc-500">Emails that fire automatically on key events. Each sends from its dedicated address.</p>
            {items.map((a) => (
                <div key={a.kind} className="rounded-2xl border border-brand-line bg-white p-4 flex items-center gap-4">
                    <button onClick={() => toggle(a.kind, !a.enabled)} className="shrink-0">
                        {a.enabled ? <CheckCircle2 className="w-6 h-6 text-emerald-500" /> : <Circle className="w-6 h-6 text-zinc-300" />}
                    </button>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-brand-ink">{a.label}</span>
                            <code className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-500">{a.role}@</code>
                            <span className="text-[11px] text-zinc-400">· {a.when}</span>
                        </div>
                        <p className="text-sm text-zinc-500 mt-0.5">{a.desc}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${a.enabled ? "bg-emerald-100 text-emerald-700" : "bg-zinc-100 text-zinc-500"}`}>{a.enabled ? "On" : "Off"}</span>
                </div>
            ))}
        </div>
    );
}

function TemplatesTab() {
    const [items, setItems] = useState([]);
    const [preview, setPreview] = useState(null);
    useEffect(() => { api.get("/staff/email/templates").then(({ data }) => setItems(data.templates || [])); }, []);
    return (
        <div className="grid md:grid-cols-[300px_1fr] gap-4">
            <div className="space-y-2">
                {items.map((t) => (
                    <button key={t.kind} onClick={() => setPreview(t)} className={`w-full text-left rounded-xl border p-3 transition-colors ${preview?.kind === t.kind ? "border-brand-copper bg-brand-cream/40" : "border-brand-line bg-white hover:bg-brand-cream/30"}`}>
                        <div className="font-medium text-sm text-brand-ink">{t.label}</div>
                        <div className="text-xs text-zinc-400 truncate">{t.subject}</div>
                    </button>
                ))}
            </div>
            <div className="rounded-2xl border border-brand-line bg-white overflow-hidden min-h-[420px]">
                {!preview ? <div className="h-full flex items-center justify-center text-zinc-400 text-sm">Select a template to preview.</div> : (
                    <>
                        <div className="px-4 py-3 border-b border-brand-line text-sm"><b>Subject:</b> {preview.subject}</div>
                        <iframe title="preview" srcDoc={preview.html} sandbox="" referrerPolicy="no-referrer" className="w-full h-[520px] bg-white" />
                    </>
                )}
            </div>
        </div>
    );
}

function AddressesTab() {
    const [emails, setEmails] = useState({});
    const [saving, setSaving] = useState(false);
    useEffect(() => { api.get("/founder/settings").then(({ data }) => setEmails(data.emails || {})).catch(() => { }); }, []);
    const setField = (role, field, value) => setEmails((p) => ({ ...p, [role]: { ...(p[role] || {}), [field]: value } }));
    const save = async () => {
        setSaving(true);
        try { await api.put("/founder/settings", { emails }); toast.success("Addresses saved"); }
        catch { toast.error("Save failed"); } finally { setSaving(false); }
    };
    return (
        <div className="space-y-3 max-w-3xl">
            {Object.entries(ROLE_META).map(([role, meta]) => {
                const cfg = emails[role] || { address: "", display_name: "" };
                return (
                    <div key={role} className="rounded-2xl border border-brand-line bg-white p-4">
                        <div className="flex items-start gap-3">
                            <div className="w-9 h-9 rounded-lg bg-brand-cream flex items-center justify-center text-brand-copper shrink-0"><meta.icon className="w-4 h-4" /></div>
                            <div className="flex-1">
                                <div className="flex items-center gap-2"><span className="font-medium text-sm text-brand-ink">{meta.title}</span><code className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-500">{role}</code></div>
                                <div className="mt-2 grid sm:grid-cols-2 gap-3">
                                    <input type="email" value={cfg.address || ""} onChange={(e) => setField(role, "address", e.target.value)} placeholder={`${role}@yourdomain.com`} className="border border-brand-line rounded-md px-3 py-2 text-sm" />
                                    <input type="text" value={cfg.display_name || ""} onChange={(e) => setField(role, "display_name", e.target.value)} placeholder="Display name" className="border border-brand-line rounded-md px-3 py-2 text-sm" />
                                </div>
                            </div>
                        </div>
                    </div>
                );
            })}
            <Button onClick={save} disabled={saving} className="bg-brand-copper hover:bg-brand-copperHover text-white">{saving ? "Saving…" : "Save all addresses"}</Button>
        </div>
    );
}

function ProviderTab({ onSaved }) {
    const [cfg, setCfg] = useState(null);
    const [providers, setProviders] = useState([]);
    const [form, setForm] = useState({});
    const [saving, setSaving] = useState(false);
    const load = useCallback(async () => {
        const { data } = await api.get("/staff/email/config");
        setCfg(data.email || {}); setProviders(data.providers || []);
        setForm({ provider: (data.email || {}).provider || "none" });
    }, []);
    useEffect(() => { load(); }, [load]);
    const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
    const save = async () => {
        setSaving(true);
        try { await api.put("/staff/email/config", form); toast.success("Provider saved"); load(); onSaved?.(); }
        catch { toast.error("Save failed"); } finally { setSaving(false); }
    };
    const test = async () => {
        const to = window.prompt("Send a test welcome email to which address?");
        if (!to) return;
        try { const { data } = await api.post("/staff/email/test", { to, kind: "welcome" }); toast.success(data.simulated ? "Test queued (simulated)" : "Test sent"); }
        catch { toast.error("Test failed"); }
    };
    if (!cfg) return <div className="text-zinc-400 text-sm">Loading…</div>;
    const input = "w-full border border-brand-line rounded-lg px-3 py-2 text-sm";
    const p = form.provider;
    return (
        <div className="rounded-2xl border border-brand-line bg-white p-6 max-w-2xl">
            <div className="text-sm text-zinc-500 mb-4">Choose how emails are actually delivered. Keys are stored securely and never shown again. Until you connect one, everything runs in simulated mode.</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-5">
                {["none", "resend", "sendgrid", "smtp"].map((key) => (
                    <button key={key} onClick={() => set("provider", key)} className={`rounded-xl border p-3 text-sm capitalize ${p === key ? "border-brand-copper bg-brand-cream/40 text-brand-copper font-medium" : "border-brand-line text-zinc-600 hover:bg-brand-cream/30"}`}>{key === "none" ? "Simulated" : key}</button>
                ))}
            </div>
            {p === "resend" && (
                <label className="text-sm block"><div className="text-xs text-zinc-500 mb-1">Resend API key</div>
                    <input className={input} type="password" placeholder={cfg.resend_api_key ? "•••• saved — leave blank to keep" : "re_..."} onChange={(e) => set("resend_api_key", e.target.value)} /></label>
            )}
            {p === "sendgrid" && (
                <label className="text-sm block"><div className="text-xs text-zinc-500 mb-1">SendGrid API key (Mail Send)</div>
                    <input className={input} type="password" placeholder={cfg.sendgrid_api_key ? "•••• saved — leave blank to keep" : "SG...."} onChange={(e) => set("sendgrid_api_key", e.target.value)} /></label>
            )}
            {p === "smtp" && (
                <div className="grid sm:grid-cols-2 gap-3">
                    <input className={input} placeholder="SMTP host" onChange={(e) => set("smtp_host", e.target.value)} />
                    <input className={input} placeholder="Port (587 / 465)" type="number" onChange={(e) => set("smtp_port", parseInt(e.target.value) || 587)} />
                    <input className={input} placeholder="Username" onChange={(e) => set("smtp_username", e.target.value)} />
                    <input className={input} type="password" placeholder="Password" onChange={(e) => set("smtp_password", e.target.value)} />
                </div>
            )}
            <label className="text-sm block mt-4"><div className="text-xs text-zinc-500 mb-1">Inbound webhook secret (optional)</div>
                <input className={input} type="password" placeholder="Shared secret to secure inbound email webhooks" onChange={(e) => set("inbound_secret", e.target.value)} /></label>
            <div className="mt-5 flex items-center gap-3">
                <Button onClick={save} disabled={saving} className="bg-brand-copper hover:bg-brand-copperHover text-white">{saving ? "Saving…" : "Save provider"}</Button>
                <button onClick={test} className="text-sm text-zinc-500 hover:text-brand-ink">Send a test email →</button>
            </div>
            <div className="mt-6 rounded-xl bg-brand-cream/40 border border-brand-line p-4 text-xs text-zinc-500 flex gap-2">
                <Mail className="w-4 h-4 text-brand-copper shrink-0" />
                <span>For real sending & receiving, verify your domain (SPF/DKIM) with the provider and point inbound MX at their webhook. Until then, sends are simulated and logged.</span>
            </div>
        </div>
    );
}
