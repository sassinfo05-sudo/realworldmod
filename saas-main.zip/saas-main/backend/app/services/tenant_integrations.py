"""Per-tenant (per-org) integration credentials.

Same shape as `services/integrations.py` but scoped to a customer's org
(single-row doc in `tenant_integrations`, key=org_id).

Customers connect THEIR OWN accounts here:
- payments (Stripe / PayPal) — for taking money on their site
- email (SMTP / SendGrid / Resend) — for sending from their domain
- analytics/pixels (GA4 / Meta / TikTok) — connected on the SEO page separately
- ecommerce/dropshipping supplier feeds (AliExpress / CJ Dropshipping)
- messaging (Twilio for their own SMS, Retell for their own AI voice)

Secrets are stored server-side and returned MASKED via {set, hint}. Downstream
feature flows call `get_secret(org_id, section, field)` and act only when
`is_configured(org_id, section)` is true (otherwise stay honest "not connected").
"""
from __future__ import annotations

from typing import Any, Dict

from ..db import get_db, utc_now_iso

SECRET_FIELDS = {
    "stripe_secret_key", "stripe_webhook_secret", "paypal_secret",
    "smtp_password", "sendgrid_api_key", "resend_api_key",
    "twilio_auth_token", "retell_api_key",
    "ecommerce_api_secret", "ecommerce_api_key",
}

DEFAULTS: Dict[str, Any] = {
    "payments": {
        "provider": "none",             # none | stripe | paypal
        "store_mode": "test",           # test | live  (flip to 'live' for real charges)
        "stripe_secret_key": "",
        "stripe_publishable_key": "",   # public
        "stripe_webhook_secret": "",
        "paypal_client_id": "",         # public
        "paypal_secret": "",
    },
    "email": {
        "provider": "none",             # none | smtp | sendgrid | resend
        "from_email": "",
        "from_name": "",
        "smtp_host": "",
        "smtp_port": 587,
        "smtp_username": "",
        "smtp_password": "",
        "smtp_use_tls": True,
        "sendgrid_api_key": "",
        "resend_api_key": "",
    },
    "messaging": {
        "provider": "none",             # none | twilio | retell
        "twilio_account_sid": "",       # public-ish
        "twilio_auth_token": "",
        "twilio_from_number": "",
        "retell_api_key": "",
    },
    "ecommerce": {
        "provider": "none",             # none | aliexpress | cj_dropshipping
        "ecommerce_api_key": "",
        "ecommerce_api_secret": "",
    },
}


def _mask(val: str) -> Dict[str, Any]:
    val = val or ""
    return {"set": bool(val), "hint": (f"…{val[-4:]}" if len(val) >= 4 else ("set" if val else ""))}


def _merge(doc: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {k: dict(v) if isinstance(v, dict) else v for k, v in DEFAULTS.items()}
    for section, val in (doc or {}).items():
        if section in out and isinstance(out[section], dict) and isinstance(val, dict):
            out[section] = {**out[section], **val}
    return out


def _configured(section: str, cfg: Dict[str, Any]) -> bool:
    if section == "payments":
        # Round 15: only a Stripe Connect connected account whose capabilities Stripe has verified counts.
        # Raw tenant secret keys are no longer accepted (see TENANT_SECRET_KEYS_REJECTED) and PayPal stays
        # unavailable until a signed sandbox flow passes.
        return bool(cfg.get("stripe_account_id") and cfg.get("charges_enabled"))
    if section == "email":
        p = cfg.get("provider")
        if p == "smtp":
            return bool(cfg.get("smtp_host") and cfg.get("smtp_username") and cfg.get("smtp_password"))
        if p == "sendgrid":
            return bool(cfg.get("sendgrid_api_key") and cfg.get("from_email"))
        if p == "resend":
            return bool(cfg.get("resend_api_key") and cfg.get("from_email"))
        return False
    if section == "messaging":
        p = cfg.get("provider")
        if p == "twilio":
            return bool(cfg.get("twilio_account_sid") and cfg.get("twilio_auth_token"))
        if p == "retell":
            return bool(cfg.get("retell_api_key"))
        return False
    if section == "ecommerce":
        return cfg.get("provider") not in (None, "none") and bool(cfg.get("ecommerce_api_key"))
    return False


async def _raw(org_id: str) -> Dict[str, Any]:
    db = get_db()
    doc = await db.tenant_integrations.find_one({"org_id": org_id}, {"_id": 0})
    if not doc:
        doc = _merge({})
        doc["org_id"] = org_id
        await db.tenant_integrations.update_one(
            {"org_id": org_id},
            {"$set": {**doc, "created_at": utc_now_iso(), "updated_at": utc_now_iso()}},
            upsert=True,
        )
        return doc
    from . import secretbox
    for section, cfg in list(doc.items()):
        if isinstance(cfg, dict):
            doc[section] = {k: (secretbox.decrypt(v) if k in SECRET_FIELDS and isinstance(v, str) else v)
                            for k, v in cfg.items()}
    return _merge(doc)


async def get_public(org_id: str) -> Dict[str, Any]:
    raw = await _raw(org_id)
    out: Dict[str, Any] = {}
    for section, cfg in raw.items():
        if section in {"org_id", "created_at", "updated_at"} or not isinstance(cfg, dict):
            continue
        masked = {}
        for k, v in cfg.items():
            if k in SECRET_FIELDS:
                masked[k] = _mask(v)
            else:
                masked[k] = v
        masked["configured"] = _configured(section, cfg)
        out[section] = masked
    return out


def _auto_detect(section: str, cfg: Dict[str, Any], patch_cfg: Dict[str, Any]) -> None:
    """Auto-toggle sim→live: the moment an owner pastes a key we detect the provider
    (unless they explicitly chose one in the same request) and flip the go-live switch
    automatically, so there are NO extra manual steps. Only fires when a relevant
    secret/credential is present IN THIS PATCH — so unrelated saves and the manual
    Test/Live override are never clobbered. Mutates cfg in place."""
    provider_explicit = "provider" in patch_cfg
    touched = set(patch_cfg.keys())
    if section == "payments":
        added_stripe = "stripe_secret_key" in touched and bool(cfg.get("stripe_secret_key"))
        added_paypal = ("paypal_secret" in touched or "paypal_client_id" in touched) and bool(
            cfg.get("paypal_secret") and cfg.get("paypal_client_id"))
        if not provider_explicit:
            if added_stripe:
                cfg["provider"] = "stripe"
            elif added_paypal:
                cfg["provider"] = "paypal"
        # Round 15: NO auto go-live from key patterns. Live mode requires a Stripe-verified connected
        # account (charges_enabled) and an explicit owner action (store go-live endpoint).
    elif section == "email":
        if not provider_explicit:
            if "resend_api_key" in touched and cfg.get("resend_api_key"):
                cfg["provider"] = "resend"
            elif "sendgrid_api_key" in touched and cfg.get("sendgrid_api_key"):
                cfg["provider"] = "sendgrid"
            elif "smtp_password" in touched and cfg.get("smtp_host") and cfg.get("smtp_username") and cfg.get("smtp_password"):
                cfg["provider"] = "smtp"
    elif section == "messaging":
        if not provider_explicit:
            if "twilio_auth_token" in touched and cfg.get("twilio_account_sid") and cfg.get("twilio_auth_token"):
                cfg["provider"] = "twilio"
            elif "retell_api_key" in touched and cfg.get("retell_api_key"):
                cfg["provider"] = "retell"


# Tenants must connect merchant accounts through provider OAuth / connected-account flows.
# These raw live secrets are refused at the API boundary (P0: no tenant-pasted secret keys).
TENANT_SECRET_KEYS_REJECTED = {
    "payments": {"stripe_secret_key", "stripe_webhook_secret", "stripe_publishable_key",
                 "paypal_secret", "paypal_client_id", "store_mode_auto"},
}


async def update(org_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    raw = await _raw(org_id)
    for section, cfg in (patch or {}).items():
        if section not in DEFAULTS or not isinstance(cfg, dict):
            continue
        rejected = TENANT_SECRET_KEYS_REJECTED.get(section, set()) & set(cfg.keys())
        if rejected:
            from fastapi import HTTPException
            raise HTTPException(400, {
                "error": "raw_secret_not_accepted",
                "fields": sorted(rejected),
                "message": "Zanelvo does not accept pasted payment secret keys. Connect your Stripe account "
                           "through Settings → Payments → Connect with Stripe (Stripe Connect).",
            })
        cur = raw.get(section, {})
        for k, v in cfg.items():
            if k in SECRET_FIELDS:
                if isinstance(v, str) and v.strip():
                    cur[k] = v.strip()
            else:
                cur[k] = v
        _auto_detect(section, cur, cfg)
        raw[section] = cur
    raw["updated_at"] = utc_now_iso()
    from . import secretbox
    stored = dict(raw)
    for section, cfg in raw.items():
        if isinstance(cfg, dict):
            stored[section] = {k: (secretbox.encrypt(v) if k in SECRET_FIELDS and isinstance(v, str) and v else v)
                               for k, v in cfg.items()}
    await get_db().tenant_integrations.update_one(
        {"org_id": org_id}, {"$set": stored}, upsert=True
    )
    return await get_public(org_id)


async def get_secret(org_id: str, section: str, field: str) -> str:
    raw = await _raw(org_id)
    return (raw.get(section) or {}).get(field, "") or ""


async def is_configured(org_id: str, section: str) -> bool:
    raw = await _raw(org_id)
    return _configured(section, raw.get(section, {}))
