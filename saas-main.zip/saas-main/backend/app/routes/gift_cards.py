"""Gift cards — stored-value codes (owner-scoped /api/store + public balance check).

Round 12. A gift card is a code with a cents balance in the store currency. Owners can
issue cards manually; cards are also issued automatically when a shopper buys a product of
`product_type == "gift_card"` (see store.py::_finalize_paid_order). At checkout a shopper may
apply a gift-card code as tender — it reduces the order total and is decremented (once) when
the order is paid. All balance math is server-side; the client never sets amounts.
"""
from __future__ import annotations

import logging
import secrets
import uuid
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User

logger = logging.getLogger("app.gift_cards")

router = APIRouter(prefix="/store", tags=["gift-cards"])
public_router = APIRouter(prefix="/public/store", tags=["gift-cards-public"])

_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no ambiguous chars


def gen_code() -> str:
    raw = "".join(secrets.choice(_ALPHABET) for _ in range(16))
    return f"{raw[:4]}-{raw[4:8]}-{raw[8:12]}-{raw[12:]}"


def _out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": d["_id"],
        "code": d.get("code"),
        "initial_cents": int(d.get("initial_cents", 0)),
        "balance_cents": int(d.get("balance_cents", 0)),
        "currency": d.get("currency", "USD"),
        "active": bool(d.get("active", True)),
        "recipient_email": d.get("recipient_email", ""),
        "note": d.get("note", ""),
        "source": d.get("source", "manual"),  # manual | purchase
        "order_id": d.get("order_id"),
        "history": d.get("history", []),
        "created_at": d.get("created_at"),
        "updated_at": d.get("updated_at"),
    }


class GiftCardIn(BaseModel):
    amount_cents: int = Field(gt=0, le=100_000_00)
    code: str = Field(default="", max_length=32)
    currency: str = "USD"
    recipient_email: str = ""
    note: str = Field(default="", max_length=200)


class AdjustIn(BaseModel):
    delta_cents: int  # positive to top up, negative to deduct
    reason: str = Field(default="", max_length=200)


@router.get("/gift-cards")
async def list_gift_cards(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = [_out(g) async for g in db.gift_cards.find({"org_id": org_id}).sort("created_at", -1)]
    total = sum(r["balance_cents"] for r in rows if r["active"])
    return {"gift_cards": rows, "outstanding_cents": total}


@router.post("/gift-cards")
async def create_gift_card(req: GiftCardIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    code = (req.code.strip().upper() or gen_code())
    if await db.gift_cards.find_one({"org_id": org_id, "code": code}):
        raise HTTPException(409, "A gift card with that code already exists")
    now = utc_now_iso()
    doc = {
        "_id": uuid.uuid4().hex, "org_id": org_id, "code": code,
        "initial_cents": int(req.amount_cents), "balance_cents": int(req.amount_cents),
        "currency": (req.currency or "USD").upper(), "active": True,
        "recipient_email": req.recipient_email.strip().lower(), "note": req.note.strip(),
        "source": "manual", "order_id": None,
        "history": [{"at": now, "delta_cents": int(req.amount_cents), "balance_cents": int(req.amount_cents),
                     "reason": "issued", "actor": user.id}],
        "created_at": now, "updated_at": now,
    }
    await db.gift_cards.insert_one(doc)
    return _out(doc)


@router.post("/gift-cards/{gid}/adjust")
async def adjust_gift_card(gid: str, req: AdjustIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    g = await db.gift_cards.find_one({"_id": gid, "org_id": org_id})
    if not g:
        raise HTTPException(404, "Gift card not found")
    new_bal = int(g.get("balance_cents", 0)) + int(req.delta_cents)
    if new_bal < 0:
        raise HTTPException(400, "Adjustment would make the balance negative")
    now = utc_now_iso()
    entry = {"at": now, "delta_cents": int(req.delta_cents), "balance_cents": new_bal,
             "reason": req.reason.strip() or "manual adjustment", "actor": user.id}
    await db.gift_cards.update_one({"_id": gid, "org_id": org_id},
                                   {"$set": {"balance_cents": new_bal, "updated_at": now},
                                    "$push": {"history": entry}})
    g = await db.gift_cards.find_one({"_id": gid, "org_id": org_id})
    return _out(g)


@router.post("/gift-cards/{gid}/deactivate")
async def deactivate_gift_card(gid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.gift_cards.update_one({"_id": gid, "org_id": org_id},
                                       {"$set": {"active": False, "updated_at": utc_now_iso()}})
    if not r.matched_count:
        raise HTTPException(404, "Gift card not found")
    return {"ok": True}


@router.post("/gift-cards/{gid}/activate")
async def activate_gift_card(gid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.gift_cards.update_one({"_id": gid, "org_id": org_id},
                                       {"$set": {"active": True, "updated_at": utc_now_iso()}})
    if not r.matched_count:
        raise HTTPException(404, "Gift card not found")
    return {"ok": True}


# ============================ PUBLIC (storefront) ============================

@public_router.get("/{org_id}/gift-card/{code}")
async def public_check_balance(org_id: str, code: str):
    db = get_db()
    g = await db.gift_cards.find_one({"org_id": org_id, "code": code.strip().upper()})
    if not g or not g.get("active", True):
        return {"valid": False, "balance_cents": 0, "message": "Gift card not found or inactive."}
    return {"valid": True, "balance_cents": int(g.get("balance_cents", 0)),
            "currency": g.get("currency", "USD"),
            "message": "Gift card is valid." if g.get("balance_cents", 0) > 0 else "This gift card has no balance left."}


# ============================ helpers used by checkout ============================

async def preview_gift_card(db, org_id: str, code: str, total_cents: int) -> Dict[str, Any]:
    """How much of `total_cents` this card would cover (no mutation)."""
    if not code:
        return {"valid": False, "applied_cents": 0, "code": "", "message": ""}
    g = await db.gift_cards.find_one({"org_id": org_id, "code": code.strip().upper()})
    if not g or not g.get("active", True):
        return {"valid": False, "applied_cents": 0, "code": code.strip().upper(), "message": "Gift card not found or inactive."}
    bal = int(g.get("balance_cents", 0))
    if bal <= 0:
        return {"valid": False, "applied_cents": 0, "code": g["code"], "message": "This gift card has no balance left."}
    applied = min(bal, max(0, int(total_cents)))
    return {"valid": True, "applied_cents": applied, "code": g["code"], "gift_card_id": g["_id"],
            "balance_cents": bal, "message": "Gift card applied."}


async def redeem_gift_card(db, org_id: str, code: str, amount_cents: int, order_id: str) -> int:
    """Redeem up to `amount_cents` from a gift card. Race-safe (optimistic compare-and-swap on
    the balance, retried), conditional on the remaining balance (never oversells the card) and
    idempotent + uniquely linked per order. Returns the cents actually redeemed."""
    if not code or amount_cents <= 0:
        return 0
    code = code.strip().upper()
    for _ in range(6):
        g = await db.gift_cards.find_one({"org_id": org_id, "code": code})
        if not g or not g.get("active", True):
            return 0
        # Idempotency: if a redemption for THIS order already landed, return that amount.
        for h in g.get("history", []):
            if h.get("order_id") == order_id and h.get("reason") == "redeemed":
                return abs(int(h.get("delta_cents", 0)))
        bal = int(g.get("balance_cents", 0))
        take = min(bal, int(amount_cents))
        if take <= 0:
            return 0
        now = utc_now_iso()
        new_bal = bal - take
        # CAS: only succeed if the balance is still `bal` AND no prior redemption for this order.
        r = await db.gift_cards.update_one(
            {"_id": g["_id"], "org_id": org_id, "balance_cents": bal,
             "history": {"$not": {"$elemMatch": {"order_id": order_id, "reason": "redeemed"}}}},
            {"$set": {"balance_cents": new_bal, "updated_at": now},
             "$push": {"history": {"at": now, "delta_cents": -take, "balance_cents": new_bal,
                                   "reason": "redeemed", "order_id": order_id}}})
        if r.modified_count == 1:
            return take
        # Balance changed under us (concurrent redemption) or order already applied → retry.
    logger.warning("redeem_gift_card: exhausted CAS retries for code on order %s", order_id)
    return 0


async def issue_gift_card_for_purchase(db, org_id: str, amount_cents: int, currency: str,
                                       recipient_email: str, order_id: str) -> Dict[str, Any]:
    """Create a new gift card when a `gift_card` product is purchased."""
    now = utc_now_iso()
    code = gen_code()
    doc = {
        "_id": uuid.uuid4().hex, "org_id": org_id, "code": code,
        "initial_cents": int(amount_cents), "balance_cents": int(amount_cents),
        "currency": (currency or "USD").upper(), "active": True,
        "recipient_email": (recipient_email or "").strip().lower(), "note": "Purchased gift card",
        "source": "purchase", "order_id": order_id,
        "history": [{"at": now, "delta_cents": int(amount_cents), "balance_cents": int(amount_cents),
                     "reason": "issued", "order_id": order_id}],
        "created_at": now, "updated_at": now,
    }
    await db.gift_cards.insert_one(doc)
    return _out(doc)
