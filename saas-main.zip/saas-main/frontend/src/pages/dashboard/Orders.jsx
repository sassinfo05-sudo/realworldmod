import InsightsDashboard from "@/components/InsightsDashboard";
import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { PackageCheck, ShoppingBag, RotateCcw, XCircle, MailWarning, Truck, Printer, FileText, History, Undo2 } from "lucide-react";

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}
const STATUS_STYLE = {
    pending: "bg-amber-100 text-amber-800",
    paid: "bg-emerald-100 text-emerald-800",
    fulfilled: "bg-blue-100 text-blue-800",
    shipped: "bg-indigo-100 text-indigo-800",
    refunded: "bg-rose-100 text-rose-800",
    cancelled: "bg-zinc-100 text-zinc-600",
};

function OrdersBase() {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState("");
    const [detail, setDetail] = useState(null);
    const [busy, setBusy] = useState(false);
    const [refundFor, setRefundFor] = useState(null);
    const [refundReason, setRefundReason] = useState("");
    const [restock, setRestock] = useState(true);
    const [sweeping, setSweeping] = useState(false);
    const [shipFor, setShipFor] = useState(null);
    const [shipForm, setShipForm] = useState({ carrier: "", tracking_number: "", tracking_url: "", notify: true });

    async function load() {
        setLoading(true);
        try {
            const { data } = await api.get("/store/orders" + (filter ? `?status=${filter}` : ""));
            setOrders(data.orders || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, [filter]);

    async function fulfill(o) {
        setBusy(true);
        try {
            await api.post(`/store/orders/${o.id}/fulfill`);
            toast.success("Marked fulfilled");
            setDetail(null); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not fulfill"); }
        finally { setBusy(false); }
    }

    async function cancel(o) {
        setBusy(true);
        try {
            await api.post(`/store/orders/${o.id}/cancel`);
            toast.success("Order cancelled");
            setDetail(null); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not cancel"); }
        finally { setBusy(false); }
    }

    async function doRefund() {
        if (!refundFor) return;
        setBusy(true);
        try {
            const { data } = await api.post(`/store/orders/${refundFor.id}/refund`, {
                reason: refundReason, restock,
            });
            const items = (data.restocked || []).reduce((n, r) => n + (r.qty || 0), 0);
            toast.success(restock ? `Refunded — ${items} item(s) restocked` : "Refunded");
            setRefundFor(null); setRefundReason(""); setRestock(true); setDetail(null); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not refund"); }
        finally { setBusy(false); }
    }

    async function recoverAbandoned() {
        setSweeping(true);
        try {
            const { data } = await api.post("/store/abandoned/sweep", { older_than_min: 30 });
            if (data.nudged > 0) toast.success(`Sent ${data.nudged} recovery email(s)`);
            else toast.info("No abandoned checkouts to recover right now");
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not run recovery"); }
        finally { setSweeping(false); }
    }

    const filters = ["", "pending", "paid", "fulfilled", "shipped", "refunded"];
    const canRefund = (s) => s === "paid" || s === "fulfilled" || s === "shipped";
    const canShip = (s) => s === "paid" || s === "fulfilled";

    async function doShip() {
        if (!shipFor) return;
        setBusy(true);
        try {
            await api.post(`/store/orders/${shipFor.id}/ship`, shipForm);
            toast.success(shipForm.notify ? "Marked shipped — buyer notified" : "Marked shipped");
            setShipFor(null); setShipForm({ carrier: "", tracking_number: "", tracking_url: "", notify: true });
            setDetail(null); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not ship"); }
        finally { setBusy(false); }
    }

    async function printDoc(o, doc) {
        try {
            const { data } = await api.get(`/store/orders/${o.id}/invoice?doc=${doc}`);
            const w = window.open("", "_blank");
            if (!w) return toast.error("Allow pop-ups to print");
            w.document.write(data.html);
            w.document.close();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not generate document"); }
    }

    return (
        <div className="p-6" data-testid="orders-page">
            <div className="flex items-start justify-between mb-4 gap-3 flex-wrap">
                <div>
                    <h2 className="text-lg font-medium text-brand-ink flex items-center gap-2"><ShoppingBag className="w-5 h-5 text-brand-copper" /> Orders</h2>
                    <p className="text-sm text-zinc-500">Fulfil paid orders, refund with automatic restock, and recover abandoned carts.</p>
                </div>
                <div className="flex gap-2 items-center flex-wrap">
                    <Button size="sm" variant="outline" className="border-brand-line" disabled={sweeping}
                        onClick={recoverAbandoned} data-testid="orders-recover-abandoned">
                        <MailWarning className="w-3.5 h-3.5 mr-1" /> {sweeping ? "Sending…" : "Recover abandoned carts"}
                    </Button>
                    <div className="flex gap-1">
                        {filters.map((f) => (
                            <Button key={f || "all"} size="sm" variant={filter === f ? "default" : "outline"}
                                className={filter === f ? "bg-brand-copper hover:bg-brand-copperHover text-white" : "border-brand-line"}
                                onClick={() => setFilter(f)} data-testid={`orders-filter-${f || "all"}`}>{f ? f : "All"}</Button>
                        ))}
                    </div>
                </div>
            </div>

            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Order</TableHead>
                        <TableHead>Buyer</TableHead>
                        <TableHead>Items</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {orders.map((o) => (
                            <TableRow key={o.id} className="cursor-pointer" onClick={() => setDetail(o)} data-testid={`order-row-${o.id}`}>
                                <TableCell className="font-mono text-xs">{o.id.slice(0, 8)}</TableCell>
                                <TableCell className="text-sm">{o.buyer?.name || o.buyer?.email || "—"}</TableCell>
                                <TableCell className="text-sm">{(o.items || []).reduce((n, i) => n + i.qty, 0)}</TableCell>
                                <TableCell className="font-mono text-sm">{money(o.subtotal_cents, o.currency)}</TableCell>
                                <TableCell><span className={`inline-flex px-2 py-0.5 rounded-full text-xs ${STATUS_STYLE[o.status] || ""}`}>{o.status}</span></TableCell>
                                <TableCell className="text-right space-x-1 whitespace-nowrap">
                                    {o.status === "paid" && <Button size="sm" variant="outline" className="border-brand-line" onClick={(e) => { e.stopPropagation(); fulfill(o); }} data-testid={`order-fulfill-${o.id}`}><PackageCheck className="w-3.5 h-3.5 mr-1" /> Fulfill</Button>}
                                    {canShip(o.status) && <Button size="sm" variant="outline" className="border-brand-line text-indigo-600" onClick={(e) => { e.stopPropagation(); setShipFor(o); }} data-testid={`order-ship-${o.id}`}><Truck className="w-3.5 h-3.5 mr-1" /> Ship</Button>}
                                    {o.status !== "pending" && o.status !== "cancelled" && <Button size="sm" variant="outline" className="border-brand-line" onClick={(e) => { e.stopPropagation(); printDoc(o, "invoice"); }} data-testid={`order-invoice-${o.id}`}><Printer className="w-3.5 h-3.5 mr-1" /> Invoice</Button>}
                                    {canRefund(o.status) && <Button size="sm" variant="outline" className="border-brand-line text-rose-600 hover:text-rose-700" onClick={(e) => { e.stopPropagation(); setRefundFor(o); }} data-testid={`order-refund-${o.id}`}><RotateCcw className="w-3.5 h-3.5 mr-1" /> Refund</Button>}
                                    {o.status === "pending" && <Button size="sm" variant="outline" className="border-brand-line text-zinc-600" onClick={(e) => { e.stopPropagation(); cancel(o); }} data-testid={`order-cancel-${o.id}`}><XCircle className="w-3.5 h-3.5 mr-1" /> Cancel</Button>}
                                </TableCell>
                            </TableRow>
                        ))}
                        {!loading && !orders.length && (
                            <TableRow><TableCell colSpan={6} className="text-center text-zinc-500 py-10" data-testid="orders-empty">No orders yet.</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Detail dialog */}
            <Dialog open={!!detail} onOpenChange={(v) => !v && setDetail(null)}>
                <DialogContent className="max-w-lg">
                    <DialogHeader><DialogTitle>Order {detail?.id?.slice(0, 8)}</DialogTitle></DialogHeader>
                    {detail && (
                        <div className="space-y-4">
                            <div>
                                <div className="text-xs uppercase tracking-wide text-zinc-400 mb-1">Buyer</div>
                                <div className="text-sm text-brand-ink">{detail.buyer?.name || "—"}</div>
                                <div className="text-sm text-zinc-500">{detail.buyer?.email}</div>
                                <div className="text-sm text-zinc-500">{detail.buyer?.phone}</div>
                                {detail.buyer?.address && <div className="text-sm text-zinc-500 mt-1">Ship to: {detail.buyer.address}</div>}
                            </div>
                            <div>
                                <div className="text-xs uppercase tracking-wide text-zinc-400 mb-1">Items</div>
                                {(detail.items || []).map((it, i) => (
                                    <div key={i} className="flex justify-between text-sm py-1 border-b border-brand-line last:border-0">
                                        <span>{it.name} × {it.qty}</span>
                                        <span className="font-mono">{money(it.price_cents * it.qty, detail.currency)}</span>
                                    </div>
                                ))}
                                <div className="flex justify-between text-sm pt-2 text-zinc-500">
                                    <span>Subtotal</span><span className="font-mono">{money(detail.subtotal_cents, detail.currency)}</span>
                                </div>
                                {(detail.shipping_cents > 0 || detail.shipping_method) && (
                                    <div className="flex justify-between text-sm text-zinc-500">
                                        <span>Shipping{detail.shipping_method ? ` · ${detail.shipping_method}` : ""}</span>
                                        <span className="font-mono">{money(detail.shipping_cents || 0, detail.currency)}</span>
                                    </div>
                                )}
                                <div className="flex justify-between text-sm font-medium pt-1 border-t border-brand-line mt-1">
                                    <span>Total</span><span className="font-mono">{money(detail.total_cents || detail.subtotal_cents, detail.currency)}</span>
                                </div>
                            </div>
                            {detail.fulfillment?.tracking_number && (
                                <div className="text-sm text-indigo-700 bg-indigo-50 rounded-lg px-3 py-2">
                                    <Truck className="w-4 h-4 inline mr-1" /> {detail.fulfillment.carrier || "Carrier"} · Tracking {detail.fulfillment.tracking_number}
                                </div>
                            )}
                            {detail.status === "refunded" && detail.refund_reason && (
                                <div className="text-sm text-rose-600">Refund reason: {detail.refund_reason}</div>
                            )}
                            <OrderHistoryPanel order={detail} onChanged={(fresh) => { setDetail(fresh); load(); }} />
                            <div className="flex items-center justify-between flex-wrap gap-2">
                                <span className={`inline-flex px-2 py-0.5 rounded-full text-xs ${STATUS_STYLE[detail.status] || ""}`}>{detail.status}</span>
                                <div className="flex gap-2 flex-wrap">
                                    {detail.status !== "pending" && detail.status !== "cancelled" && (
                                        <>
                                            <Button variant="outline" className="border-brand-line" onClick={() => printDoc(detail, "invoice")} data-testid="order-detail-invoice"><Printer className="w-4 h-4 mr-1" /> Invoice</Button>
                                            <Button variant="outline" className="border-brand-line" onClick={() => printDoc(detail, "packing")} data-testid="order-detail-packing"><FileText className="w-4 h-4 mr-1" /> Packing slip</Button>
                                        </>
                                    )}
                                    {detail.status === "pending" && <Button variant="outline" className="border-brand-line" disabled={busy} onClick={() => cancel(detail)} data-testid="order-detail-cancel"><XCircle className="w-4 h-4 mr-1" /> Cancel</Button>}
                                    {canRefund(detail.status) && <Button variant="outline" className="border-brand-line text-rose-600" disabled={busy} onClick={() => setRefundFor(detail)} data-testid="order-detail-refund"><RotateCcw className="w-4 h-4 mr-1" /> Refund</Button>}
                                    {detail.status === "paid" && <Button variant="outline" className="border-brand-line" disabled={busy} onClick={() => fulfill(detail)} data-testid="order-detail-fulfill"><PackageCheck className="w-4 h-4 mr-1" /> Fulfill</Button>}
                                    {canShip(detail.status) && <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={() => setShipFor(detail)} data-testid="order-detail-ship"><Truck className="w-4 h-4 mr-1" /> Ship</Button>}
                                </div>
                            </div>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            {/* Refund confirm dialog */}
            <Dialog open={!!refundFor} onOpenChange={(v) => !v && setRefundFor(null)}>
                <DialogContent className="max-w-md">
                    <DialogHeader><DialogTitle>Refund order {refundFor?.id?.slice(0, 8)}</DialogTitle></DialogHeader>
                    <div className="space-y-3">
                        <p className="text-sm text-zinc-500">Refund {refundFor && money(refundFor.subtotal_cents, refundFor.currency)} to the buyer. The buyer will receive a refund confirmation email.</p>
                        <label className="flex items-center gap-2 text-sm text-brand-ink cursor-pointer">
                            <input type="checkbox" checked={restock} onChange={(e) => setRestock(e.target.checked)} data-testid="refund-restock" />
                            Restock items back to inventory
                        </label>
                        <textarea value={refundReason} onChange={(e) => setRefundReason(e.target.value)}
                            placeholder="Reason (optional, shown internally + in the buyer email)"
                            className="w-full border border-brand-line rounded-md p-2 text-sm h-20" data-testid="refund-reason" />
                    </div>
                    <DialogFooter>
                        <Button variant="outline" className="border-brand-line" onClick={() => setRefundFor(null)}>Cancel</Button>
                        <Button className="bg-rose-600 hover:bg-rose-700 text-white" disabled={busy} onClick={doRefund} data-testid="refund-confirm">
                            <RotateCcw className="w-4 h-4 mr-1" /> {busy ? "Refunding…" : "Refund"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Ship / add tracking dialog */}
            <Dialog open={!!shipFor} onOpenChange={(v) => !v && setShipFor(null)}>
                <DialogContent className="max-w-md">
                    <DialogHeader><DialogTitle>Ship order {shipFor?.id?.slice(0, 8)}</DialogTitle></DialogHeader>
                    <div className="space-y-3">
                        <p className="text-sm text-zinc-500">Record the carrier and tracking. If enabled, the buyer gets a shipping email with the tracking link.</p>
                        <div>
                            <label className="text-xs text-zinc-500">Carrier</label>
                            <input list="carrier-list" value={shipForm.carrier} onChange={(e) => setShipForm((p) => ({ ...p, carrier: e.target.value }))}
                                placeholder="e.g. DHL Express, USPS, UPS" className="w-full border border-brand-line rounded-md p-2 text-sm" data-testid="ship-carrier" />
                            <datalist id="carrier-list">
                                {["DHL Express", "FedEx", "UPS", "USPS", "Royal Mail", "Canada Post", "Australia Post", "DPD", "GLS", "Aramex", "Shippo", "EasyPost"].map((c) => <option key={c} value={c} />)}
                            </datalist>
                        </div>
                        <div>
                            <label className="text-xs text-zinc-500">Tracking number</label>
                            <input value={shipForm.tracking_number} onChange={(e) => setShipForm((p) => ({ ...p, tracking_number: e.target.value }))}
                                placeholder="1Z999AA10123456784" className="w-full border border-brand-line rounded-md p-2 text-sm" data-testid="ship-tracking" />
                        </div>
                        <div>
                            <label className="text-xs text-zinc-500">Tracking URL (optional)</label>
                            <input value={shipForm.tracking_url} onChange={(e) => setShipForm((p) => ({ ...p, tracking_url: e.target.value }))}
                                placeholder="https://…" className="w-full border border-brand-line rounded-md p-2 text-sm" />
                        </div>
                        <label className="flex items-center gap-2 text-sm text-brand-ink cursor-pointer">
                            <input type="checkbox" checked={shipForm.notify} onChange={(e) => setShipForm((p) => ({ ...p, notify: e.target.checked }))} data-testid="ship-notify" />
                            Email the buyer a shipping confirmation
                        </label>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" className="border-brand-line" onClick={() => setShipFor(null)}>Cancel</Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={doShip} data-testid="ship-confirm">
                            <Truck className="w-4 h-4 mr-1" /> {busy ? "Shipping…" : "Mark shipped"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}


// Dashboard wrapper: real stat cards + trend chart on top of the feature page.
export default function Orders() {
    return (
        <>
            <div className="px-4 md:px-8 pt-6">
                <InsightsDashboard area="store" title="Orders" subtitle="Store revenue, order volume and best sellers." color="#8B5CF6" seriesKey="revenue" seriesFormat="usd" breakdownTitle="Top products" breakdownFormat="int" />
            </div>
            <OrdersBase />
        </>
    );
}


/** Status timeline + internal notes + return (RMA) for one order. */
function OrderHistoryPanel({ order, onChanged }) {
    const [hist, setHist] = useState(null);
    const [note, setNote] = useState("");
    const [busy, setBusy] = useState(false);
    const [returnOpen, setReturnOpen] = useState(false);
    const [returnReason, setReturnReason] = useState("");
    const [restock, setRestock] = useState(true);
    const reload = async () => {
        try { const { data } = await api.get(`/store/orders/${order.id}/history`); setHist(data); } catch { setHist({ status_history: [], notes: [], returns: [] }); }
    };
    useEffect(() => { reload(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [order.id, order.status]);
    const addNote = async () => {
        if (!note.trim() || busy) return;
        setBusy(true);
        try { await api.post(`/store/orders/${order.id}/notes`, { text: note.trim() }); setNote(""); toast.success("Note added"); reload(); }
        catch { toast.error("Could not add note"); } finally { setBusy(false); }
    };
    const doReturn = async () => {
        setBusy(true);
        try {
            const { data } = await api.post(`/store/orders/${order.id}/return`, { reason: returnReason, restock });
            toast.success(`${data.return.id} recorded${restock ? " · stock restored" : ""}`);
            setReturnOpen(false); setReturnReason("");
            const { data: fresh } = await api.get(`/store/orders/${order.id}/history`);
            setHist(fresh); onChanged?.({ ...order, status: fresh.status, returns: fresh.returns });
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not record return"); } finally { setBusy(false); }
    };
    const canReturn = ["paid", "fulfilled", "shipped", "refunded"].includes(order.status);
    return (
        <div className="rounded-xl border border-brand-line p-3 space-y-3" data-testid="order-history-panel">
            <div className="flex items-center justify-between">
                <div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1.5"><History className="w-3.5 h-3.5" /> History & notes</div>
                {canReturn && <Button size="sm" variant="outline" className="border-brand-line" onClick={() => setReturnOpen((v) => !v)} data-testid="order-return-toggle"><Undo2 className="w-3.5 h-3.5 mr-1" /> Record return</Button>}
            </div>
            {returnOpen && (
                <div className="rounded-lg bg-zinc-50 border border-brand-line p-3 space-y-2" data-testid="order-return-form">
                    <Input placeholder="Reason (e.g. wrong size)" value={returnReason} onChange={(e) => setReturnReason(e.target.value)} data-testid="order-return-reason" />
                    <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={restock} onChange={(e) => setRestock(e.target.checked)} /> Restock returned items</label>
                    <div className="text-xs text-zinc-500">Money is refunded separately via “Refund”.</div>
                    <Button size="sm" disabled={busy} onClick={doReturn} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="order-return-submit">Save return</Button>
                </div>
            )}
            <ol className="space-y-1 text-sm">
                {(hist?.status_history || []).map((h, i) => (
                    <li key={i} className="flex items-center gap-2" data-testid="order-history-item">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] ${STATUS_STYLE[h.status] || "bg-zinc-100 text-zinc-600"}`}>{h.status}</span>
                        <span className="text-zinc-500 text-xs">{new Date(h.at).toLocaleString()} · {h.actor}{h.note ? ` · ${h.note}` : ""}</span>
                    </li>
                ))}
                {hist && hist.status_history?.length === 0 && <li className="text-xs text-zinc-400">No status changes recorded yet (older order).</li>}
            </ol>
            {(hist?.returns || []).map((r) => (
                <div key={r.id} className="text-xs text-amber-700 bg-amber-50 rounded px-2 py-1">{r.id} · {r.reason || "no reason"} · {r.restock ? "restocked" : "not restocked"}</div>
            ))}
            <div className="space-y-1">
                {(hist?.notes || []).map((n) => (
                    <div key={n.id} className="text-sm bg-zinc-50 rounded px-2 py-1.5"><span className="text-zinc-800">{n.text}</span> <span className="text-xs text-zinc-400">— {n.author}, {new Date(n.at).toLocaleString()}</span></div>
                ))}
                <div className="flex gap-2">
                    <Input placeholder="Add an internal note…" value={note} onChange={(e) => setNote(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addNote()} data-testid="order-note-input" />
                    <Button size="sm" variant="outline" className="border-brand-line" disabled={busy || !note.trim()} onClick={addNote} data-testid="order-note-add">Add</Button>
                </div>
            </div>
        </div>
    );
}
