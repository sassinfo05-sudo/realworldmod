"""Provider connection status for the Staff Setup Center.

One truthful card per provider: connected | sandbox | not_connected | error, with last_checked,
a SAFE test result (no paid calls unless ?probe=true, and never any secret in the response) and
the missing owner action. Results are persisted in `provider_checks` so the panel shows the last
known state even without re-testing.
"""
from __future__ import annotations

import os
import time
from typing import Any, Dict, List

from fastapi import APIRouter, Depends

from ..db import get_db, utc_now_iso
from ..deps import require_staff
from ..models import User
from ..services import integrations as integ
from .. import config

router = APIRouter(prefix="/api/staff/providers", tags=["staff-providers"])


def _card(key: str, label: str, status: str, *, detail: str = "", owner_action: str = "",
          test: Dict[str, Any] | None = None, sandbox_note: str = "") -> Dict[str, Any]:
    return {"key": key, "label": label, "status": status, "detail": detail,
            "owner_action": owner_action, "test": test or {"ran": False},
            "sandbox_note": sandbox_note, "last_checked": utc_now_iso()}


async def _check_llm(probe: bool) -> Dict[str, Any]:
    from .. import config
    if not config.EMERGENT_LLM_KEY:
        return _card("llm", "AI models (Emergent universal key)", "not_connected",
                     detail="EMERGENT_LLM_KEY missing", owner_action="Set EMERGENT_LLM_KEY in the backend environment.")
    test: Dict[str, Any] = {"ran": False, "note": "Add ?probe=true to run a 1-token paid ping."}
    status = "connected"
    if probe:
        t0 = time.monotonic()
        try:
            from ..services import llm, usage
            usage.set_context(feature="platform/provider-probe")
            out = await llm.generate_text("Reply with the single word OK.", "ping")
            test = {"ran": True, "ok": bool(out), "latency_ms": int((time.monotonic() - t0) * 1000)}
        except Exception as e:  # noqa: BLE001
            status = "error"
            test = {"ran": True, "ok": False, "error": type(e).__name__}
    return _card("llm", "AI models (Emergent universal key)", status,
                 detail=f"text {config.LLM_PROVIDER}/{config.LLM_MODEL} · image {config.IMAGE_PROVIDER}/{config.IMAGE_MODEL}",
                 test=test)


async def _check_email() -> Dict[str, Any]:
    raw = (await integ._raw()).get("email") or {}
    provider = raw.get("provider") or "simulated"
    if not await integ.is_configured("email"):
        return _card("email", "Transactional email", "sandbox", detail="Simulated sender — nothing is delivered",
                     owner_action="Connect Resend, SendGrid or SMTP in Staff → Email → Provider.",
                     sandbox_note="Emails are logged, metered at $0 and not sent.")
    try:
        from ..services.email_providers import build_provider_from_config
        p = build_provider_from_config(raw)
        r = await p.verify_config()
        ok = bool(r.get("ok"))
        return _card("email", f"Transactional email ({provider})", "connected" if ok else "error",
                     detail=r.get("message", ""), test={"ran": True, "ok": ok},
                     owner_action="" if ok else "Re-check the API key / SMTP settings in Staff → Email.")
    except Exception as e:  # noqa: BLE001
        return _card("email", f"Transactional email ({provider})", "error", detail=type(e).__name__,
                     test={"ran": True, "ok": False})


async def _check_payments() -> List[Dict[str, Any]]:
    raw = (await integ._raw()).get("payments") or {}
    out = []
    stripe_ok = integ.stripe_ready(raw)
    live = str(raw.get("stripe_secret_key") or "").startswith("sk_live_")
    if stripe_ok:
        test: Dict[str, Any] = {"ran": False}
        status = "connected" if live else "sandbox"
        try:
            import httpx
            async with httpx.AsyncClient(timeout=8) as c:
                r = await c.get("https://api.stripe.com/v1/balance",
                                headers={"Authorization": f"Bearer {raw['stripe_secret_key']}"})
            test = {"ran": True, "ok": r.status_code == 200}
            if r.status_code != 200:
                status = "error"
        except Exception as e:  # noqa: BLE001
            test = {"ran": True, "ok": False, "error": type(e).__name__}
            status = "error"
        out.append(_card("stripe", "Stripe", status, detail="live keys" if live else "test-mode keys", test=test,
                         owner_action="" if raw.get("stripe_webhook_secret") else "Add the Stripe webhook signing secret.",
                         sandbox_note="" if live else "Test-mode: no real money moves."))
    else:
        out.append(_card("stripe", "Stripe", "not_connected", owner_action="Add Stripe keys in Staff → Payments."))
    if integ.paypal_ready(raw):
        out.append(_card("paypal", "PayPal", "sandbox" if (raw.get("paypal_mode") or "sandbox") != "live" else "connected",
                         detail=f"mode {raw.get('paypal_mode') or 'sandbox'}"))
    else:
        out.append(_card("paypal", "PayPal", "not_connected", owner_action="Add PayPal client id/secret in Staff → Payments."))
    return out


async def _check_voice() -> Dict[str, Any]:
    raw = (await integ._raw()).get("voice") or {}
    provider = raw.get("provider") or "none"
    if provider == "none" or not await integ.is_configured("voice"):
        return _card("voice", "Phone numbers & AI voice", "sandbox", detail="No carrier connected — numbers and calls are simulated",
                     owner_action="Connect Telnyx (recommended) or Twilio in Staff → Integrations → Voice, then set a webhook secret.",
                     sandbox_note="Number purchases and calls are simulated; nothing is billed by a carrier.")
    return _card("voice", f"Phone numbers & AI voice ({provider})", "connected" if raw.get("webhook_secret") else "error",
                 detail="carrier key present" + ("" if raw.get("webhook_secret") else " · webhook secret missing"),
                 owner_action="" if raw.get("webhook_secret") else "Set voice.webhook_secret so carrier webhooks are authenticated.")


def _check_shipping() -> Dict[str, Any]:
    return _card("shipping", "Live carrier rates & labels", "not_connected",
                 detail="Native zone/rate engine is live; live carrier quotes need an aggregator key",
                 owner_action="Provide a Shippo or EasyPost API key to enable real-time rates and labels.")


def _check_ads() -> Dict[str, Any]:
    return _card("ads", "Ad platforms (Google / Meta)", "not_connected",
                 detail="Creative studio works offline; no ad account connected — no spend is possible",
                 owner_action="Connect an ad account via OAuth when ready; live spend always requires explicit activation.")


def _check_domains() -> Dict[str, Any]:
    prov = os.environ.get("DOMAIN_PROVIDER", "simulated")
    return _card("domains", "Custom domains / SSL", "connected" if prov != "simulated" else "sandbox",
                 detail=f"provider adapter: {prov}",
                 owner_action="" if prov != "simulated" else "DNS records + verification are real; automated SSL issuance needs a hosting provider adapter (Cloudflare for SaaS / Vercel).",
                 sandbox_note="Custom domains show DNS records and verify ownership; certificates are provisioned when the adapter is connected.")


@router.get("/status")
async def provider_status(probe: bool = False, _staff: User = Depends(require_staff("integrations.read", "health", "audit"))):
    cards: List[Dict[str, Any]] = [await _check_llm(probe), await _check_email(), *await _check_payments(),
                                   await _check_voice(), _check_shipping(), _check_ads(), _check_domains()]
    try:
        db = get_db()
        for c in cards:
            await db.provider_checks.update_one({"key": c["key"]}, {"$set": c}, upsert=True)
    except Exception:  # noqa: BLE001
        pass
    summary = {s: sum(1 for c in cards if c["status"] == s) for s in ("connected", "sandbox", "not_connected", "error")}
    return {"cards": cards, "summary": summary, "checked_at": utc_now_iso()}



# ============================= OWNER GO-LIVE WIZARD =============================
# A single ordered, guided readiness checklist for the platform owner. Reuses the same truthful,
# non-destructive checks as the provider panel (no paid probes) plus DB / public-URL / object-storage
# readiness, and tells the owner exactly what to do next and where. "live_ready" turns green only when
# every REQUIRED essential is genuinely Connected (Sandbox counts as works-but-simulated, not live).

async def _db_step() -> Dict[str, str]:
    try:
        await get_db().command("ping")
        return {"status": "connected", "detail": "Database reachable", "owner_action": ""}
    except Exception as e:  # noqa: BLE001
        return {"status": "error", "detail": type(e).__name__,
                "owner_action": "Check MONGO_URL and that the database is reachable."}


async def _public_url_step() -> Dict[str, str]:
    origin = ""
    try:
        from ..services import platform_settings as ps
        settings = await ps.get_settings()
        origin = (settings.get("product_url") or os.environ.get("PUBLIC_BASE_URL") or "").strip()
    except Exception:  # noqa: BLE001
        origin = (os.environ.get("PUBLIC_BASE_URL") or "").strip()
    if origin:
        return {"status": "connected", "detail": origin, "owner_action": ""}
    return {"status": "not_connected", "detail": "No public product URL set",
            "owner_action": "Set the public product URL so customer links, emails and OAuth callbacks resolve."}


async def _storage_step() -> Dict[str, str]:
    try:
        from ..services import storage as st
        s = await st.provider_status()
    except Exception as e:  # noqa: BLE001
        return {"status": "error", "detail": type(e).__name__,
                "owner_action": "Storage adapter failed to initialise — check the storage configuration."}
    if s.get("configured"):
        label = " · ".join([x for x in [s.get("provider"), s.get("bucket")] if x])
        return {"status": "connected", "detail": label or "Connected", "owner_action": ""}
    if s.get("is_production"):
        return {"status": "not_connected", "detail": "No object storage connected",
                "owner_action": "Connect S3, Cloudflare R2, Backblaze B2 or MinIO so uploads persist durably."}
    return {"status": "sandbox", "detail": "Local disk storage (development)",
            "owner_action": "Connect S3/R2/B2/MinIO before production so assets are durable and served via CDN."}


@router.get("/go-live")
async def go_live(_staff: User = Depends(require_staff("integrations.read", "health", "audit"))):
    db_s = await _db_step()
    url_s = await _public_url_step()
    sto_s = await _storage_step()
    email = await _check_email()
    stripe = next((c for c in await _check_payments() if c["key"] == "stripe"), {})
    dom = _check_domains()
    llm = await _check_llm(False)

    steps: List[Dict[str, Any]] = [
        {"key": "database", "title": "Database", "group": "Foundation", "required": True,
         "link": "/staff/health", **db_s},
        {"key": "public_url", "title": "Public address", "group": "Foundation", "required": True,
         "link": "/staff/controls", **url_s},
        {"key": "storage", "title": "Object storage & CDN", "group": "Storage", "required": True,
         "configurable": True, "link": "/staff/go-live",
         "status": sto_s["status"], "detail": sto_s["detail"], "owner_action": sto_s["owner_action"]},
        {"key": "email", "title": "Transactional email", "group": "Messaging", "required": True,
         "link": "/staff/payments", "status": email["status"], "detail": email.get("detail", ""),
         "owner_action": email.get("owner_action", "")},
        {"key": "stripe", "title": "Payments (Stripe)", "group": "Money", "required": True,
         "link": "/staff/payments", "status": stripe.get("status", "not_connected"),
         "detail": stripe.get("detail", ""),
         "owner_action": stripe.get("owner_action", "") or "Add Stripe keys in Staff → Payments & email."},
        {"key": "domains", "title": "Custom domain & SSL", "group": "Domains", "required": False,
         "link": "/staff/integrations", "status": dom["status"], "detail": dom.get("detail", ""),
         "owner_action": dom.get("owner_action", "")},
        {"key": "llm", "title": "AI models", "group": "AI", "required": False,
         "link": "/staff/health", "status": llm["status"], "detail": llm.get("detail", ""),
         "owner_action": llm.get("owner_action", "")},
    ]
    req = [s for s in steps if s["required"]]
    counts = {k: sum(1 for s in steps if s["status"] == k)
              for k in ("connected", "sandbox", "not_connected", "error")}
    req_connected = sum(1 for s in req if s["status"] == "connected")
    app_ready = db_s["status"] == "connected" and url_s["status"] == "connected"
    live_ready = all(s["status"] == "connected" for s in req)
    return {
        "generated_at": utc_now_iso(),
        "environment": "production" if config.is_production() else config.APP_ENV,
        "steps": steps,
        "summary": {"total": len(steps), **counts,
                    "required_total": len(req), "required_connected": req_connected},
        "app_ready": app_ready,
        "live_ready": live_ready,
        "pending": [s["key"] for s in req if s["status"] != "connected"],
    }
