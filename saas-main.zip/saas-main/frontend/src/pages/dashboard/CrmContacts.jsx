import InsightsDashboard from "@/components/InsightsDashboard";
import { useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Search, Upload, UserPlus } from "lucide-react";
import { toast } from "sonner";

function LeadScoreBadge({ score }) {
    if (score == null) return <span className="text-xs text-zinc-400">—</span>;
    const tone = score >= 70 ? "bg-emerald-100 text-emerald-800"
        : score >= 40 ? "bg-amber-100 text-amber-800"
        : "bg-zinc-100 text-zinc-700";
    return <span data-testid="lead-score-chip"
                 className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-mono ${tone}`}>
        {Math.round(score)}
    </span>;
}

function CrmContactsBase() {
    const [contacts, setContacts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [q, setQ] = useState("");
    const [selected, setSelected] = useState({});
    const navigate = useNavigate();

    async function load() {
        setLoading(true);
        try {
            const { data } = await api.get(`/crm/contacts${q ? `?q=${encodeURIComponent(q)}` : ""}`);
            setContacts(data.contacts || []);
        } finally {
            setLoading(false);
        }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

    const selectedIds = useMemo(() => Object.entries(selected).filter(([, v]) => v).map(([k]) => k), [selected]);

    async function bulkTag(tag) {
        if (!selectedIds.length) return;
        await api.post("/crm/contacts/bulk", { ids: selectedIds, action: "tag", payload: { tag } });
        toast.success(`Tagged ${selectedIds.length} with "${tag}"`);
        setSelected({});
        load();
    }

    async function bulkDelete() {
        if (!selectedIds.length) return;
        if (!window.confirm(`Delete ${selectedIds.length} contacts? This cannot be undone.`)) return;
        await api.post("/crm/contacts/bulk", { ids: selectedIds, action: "delete" });
        toast.success(`Deleted ${selectedIds.length}`);
        setSelected({});
        load();
    }

    return (
        <div className="p-6" data-testid="crm-contacts-page">
            <div className="flex items-center justify-between mb-4">
                <div>
                    <h1 className="font-display text-2xl font-semibold">Contacts</h1>
                    <p className="text-sm text-zinc-500">Every person your business talks to. Auto-populated from forms and imports.</p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" onClick={() => navigate("/app/crm/import")} data-testid="crm-import-link">
                        <Upload className="w-4 h-4 mr-2" /> Import CSV
                    </Button>
                    <Button variant="outline" data-testid="crm-add-contact">
                        <UserPlus className="w-4 h-4 mr-2" /> New contact
                    </Button>
                </div>
            </div>

            <div className="flex items-center gap-3 mb-3">
                <div className="relative w-80">
                    <Search className="absolute left-2 top-2.5 w-4 h-4 text-zinc-400" />
                    <Input value={q} onChange={(e) => setQ(e.target.value)}
                           onKeyDown={(e) => e.key === "Enter" && load()}
                           placeholder="Search contacts…" className="pl-8"
                           data-testid="crm-search-input" />
                </div>
                <Button variant="ghost" onClick={load} data-testid="crm-search-btn">Search</Button>
                {selectedIds.length > 0 && (
                    <div className="ml-auto flex items-center gap-2" data-testid="crm-bulk-bar">
                        <span className="text-xs text-zinc-500">{selectedIds.length} selected</span>
                        <Button size="sm" variant="outline" onClick={() => bulkTag("hot")} data-testid="crm-bulk-tag-hot">Tag hot</Button>
                        <Button size="sm" variant="outline" onClick={() => bulkTag("priority")} data-testid="crm-bulk-tag-priority">Tag priority</Button>
                        <Button size="sm" variant="destructive" onClick={bulkDelete} data-testid="crm-bulk-delete">Delete</Button>
                    </div>
                )}
            </div>

            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-8"></TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Phone</TableHead>
                            <TableHead>Source</TableHead>
                            <TableHead>Tags</TableHead>
                            <TableHead>Score</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {contacts.map((c) => (
                            <TableRow key={c.id} data-testid={`crm-contact-row-${c.id}`}
                                        className="cursor-pointer hover:bg-brand-cream/40"
                                        onClick={() => navigate(`/app/crm/contacts/${c.id}`)}>
                                <TableCell onClick={(e) => e.stopPropagation()}>
                                    <input type="checkbox"
                                           checked={!!selected[c.id]}
                                           data-testid={`crm-contact-select-${c.id}`}
                                           onChange={(e) => setSelected({ ...selected, [c.id]: e.target.checked })} />
                                </TableCell>
                                <TableCell className="font-medium">{c.display_name || `${c.first_name || ""} ${c.last_name || ""}`.trim() || "—"}</TableCell>
                                <TableCell className="font-mono text-xs">{(c.emails || [])[0] || "—"}</TableCell>
                                <TableCell className="font-mono text-xs">{(c.phones || [])[0] || "—"}</TableCell>
                                <TableCell><Badge variant="secondary" className="text-[10px] uppercase">{c.source || "—"}</Badge></TableCell>
                                <TableCell>
                                    <div className="flex gap-1 flex-wrap">
                                        {(c.tags || []).map((t) => <Badge key={t} variant="outline" className="text-[10px]">{t}</Badge>)}
                                    </div>
                                </TableCell>
                                <TableCell><LeadScoreBadge score={c.lead_score} /></TableCell>
                            </TableRow>
                        ))}
                        {!loading && !contacts.length && (
                            <TableRow><TableCell colSpan={7} className="text-center text-zinc-500 py-10">
                                No contacts yet. Form submissions on your site will auto-create contacts here.
                            </TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    );
}


// Dashboard wrapper: real stat cards + trend chart on top of the feature page.
export default function CrmContacts() {
    return (
        <>
            <div className="px-4 md:px-8 pt-6">
                <InsightsDashboard area="crm" title="Contacts" subtitle="Your customer base, pipeline value and win rate." color="#0EA5E9" seriesKey="contacts" seriesFormat="int" breakdownTitle="New contacts by source" breakdownFormat="int" />
            </div>
            <CrmContactsBase />
        </>
    );
}
