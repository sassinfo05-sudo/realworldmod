"""Round 15 — inbound email webhook: signature enforcement (401/403), atomic idempotent claims,
tenant routing only from VERIFIED identifiers (assigned mailbox / verified custom domain), platform-domain separation."""
from __future__ import annotations

import asyncio
import base64
import json
import time

import pytest

from app.routes import email_inbound as ei


def _loop():
    import app.db as _appdb
    _appdb._mongo_client = None
    return asyncio.new_event_loop()


def test_sendgrid_ecdsa_signature_roundtrip():
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    priv = ec.generate_private_key(ec.SECP256R1())
    pub_pem = priv.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()
    pub_b64 = "".join(l for l in pub_pem.splitlines() if "-----" not in l)
    body = json.dumps([{"event": "delivered", "email": "a@b.co"}]).encode()
    ts = str(int(time.time()))
    sig = base64.b64encode(priv.sign(ts.encode() + body, ec.ECDSA(hashes.SHA256()))).decode()
    h = {"x-twilio-email-event-webhook-signature": sig, "x-twilio-email-event-webhook-timestamp": ts}
    assert ei.verify_sendgrid_ecdsa(pub_b64, h, body) is True
    assert ei.verify_sendgrid_ecdsa(pub_b64, h, body + b"x") is False           # tampered body
    assert ei.verify_sendgrid_ecdsa(pub_b64, {**h, "x-twilio-email-event-webhook-timestamp": str(int(time.time()) - 900)}, body) is False  # stale
    assert ei.verify_sendgrid_ecdsa("bogus", h, body) is False


def test_atomic_event_claim_and_verified_routing():
    from app.db import get_db

    async def run():
        db = get_db()
        eid = f"evt-{time.time_ns()}"
        msg = {"from": "Someone <x@y.com>", "to": "nobody@nowhere-unmatched.test", "subject": "hi", "text": "t"}
        results = await asyncio.gather(*[ei._save(dict(msg), "resend", eid, "svix") for _ in range(6)])
        dups = sum(1 for r in results if r.get("duplicate"))
        assert dups == 5, results                       # exactly one delivery, five duplicates
        await db.inbox_messages.delete_many({"to_email": "nobody@nowhere-unmatched.test"})
        await db.webhook_events.delete_many({"event_id": eid})

        # Tenant-declared, UNVERIFIED addresses must NOT route mail to a tenant.
        r = await db.organizations.insert_one({"name": "Victim Org", "contact_email": "victim@attacker-claims.test"})
        try:
            await db.tenant_integrations.update_one({"org_id": "attacker-org"},
                                                    {"$set": {"email.from_email": "victim@attacker-claims.test"}}, upsert=True)
            assert await ei.resolve_org_for_address("victim@attacker-claims.test") is None
            # Platform-assigned mailbox → routes
            await db.organizations.update_one({"_id": r.inserted_id}, {"$set": {"inbound_email": "victim-inbox@mail.test"}})
            assert await ei.resolve_org_for_address("victim-inbox@mail.test") == str(r.inserted_id)
            # Platform domain is never a tenant domain
            assert await ei.resolve_org_for_address("anything@zanelvo.com") is None
            # Verified custom domain (state=connected) routes; pending does not
            await db.domains.insert_one({"_id": "dom-test-1", "hostname": "shop.verified.test", "org_id": str(r.inserted_id), "state": "connected"})
            await db.domains.insert_one({"_id": "dom-test-2", "hostname": "shop.pending.test", "org_id": str(r.inserted_id), "state": "pending"})
            assert await ei.resolve_org_for_address("hello@shop.verified.test") == str(r.inserted_id)
            assert await ei.resolve_org_for_address("hello@shop.pending.test") is None
        finally:
            await db.organizations.delete_one({"_id": r.inserted_id})
            await db.tenant_integrations.delete_one({"org_id": "attacker-org"})
            await db.domains.delete_many({"_id": {"$in": ["dom-test-1", "dom-test-2"]}})

    loop = _loop()
    try:
        loop.run_until_complete(run())
    finally:
        loop.close()


def test_unsigned_webhook_rejected_when_secret_configured():
    """Live API: with a Resend signing secret configured, an unsigned POST must be 403 (never 200)."""
    import os
    import requests
    from pymongo import MongoClient
    import _creds
    db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
    key = "primary"
    prev = (db.integrations.find_one({"key": key}) or {}).get("email", {}).get("resend_signing_secret")
    from app.services import secretbox
    db.integrations.update_one({"key": key}, {"$set": {"email.resend_signing_secret": secretbox.encrypt("whsec_" + base64.b64encode(b"x" * 24).decode())}}, upsert=True)
    try:
        r = requests.post(f"{_creds.api()}/webhooks/email/resend", json={"type": "email.received", "data": {}}, timeout=30)
        assert r.status_code == 403, (r.status_code, r.text)
    finally:
        if prev:
            db.integrations.update_one({"key": key}, {"$set": {"email.resend_signing_secret": prev}})
        else:
            db.integrations.update_one({"key": key}, {"$unset": {"email.resend_signing_secret": ""}})


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
