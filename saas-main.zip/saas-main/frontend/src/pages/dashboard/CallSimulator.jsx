import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Phone, PhoneOff, Send, Loader2, ArrowRight } from "lucide-react";

export default function CallSimulator() {
    const [providers, setProviders] = useState([]);
    const [calls, setCalls] = useState([]);
    const [callId, setCallId] = useState(null);
    const [convId, setConvId] = useState(null);
    const [msgs, setMsgs] = useState([]);
    const [input, setInput] = useState("");
    const [busy, setBusy] = useState(false);
    const [caller, setCaller] = useState({ name: "", phone: "" });
    const [started, setStarted] = useState(null);
    const scrollRef = useRef(null);

    async function load() {
        const [p, c] = await Promise.all([
            api.get("/ai/voice/providers"),
            api.get("/ai/calls?limit=20"),
        ]);
        setProviders(p.data.providers);
        setCalls(c.data.calls);
    }
    useEffect(() => { load(); }, []);
    useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [msgs, busy]);

    async function startCall() {
        try {
            const { data } = await api.post("/ai/call/start", { caller_name: caller.name || null, caller_phone: caller.phone || null });
            setCallId(data.call_record_id);
            setConvId(data.conversation_id);
            setStarted(Date.now());
            setMsgs([{ role: "ai", content: data.greeting, id: "g" }]);
        } catch (e) { toast.error("Failed to start call"); }
    }
    async function send() {
        if (!input.trim() || !callId) return;
        const text = input.trim();
        setInput(""); setBusy(true);
        setMsgs((m) => [...m, { role: "visitor", content: text, id: `v-${Date.now()}` }]);
        try {
            const { data } = await api.post("/ai/call/turn", { call_record_id: callId, caller_message: text });
            setMsgs((m) => [...m, { role: "ai", content: data.reply, id: `a-${Date.now()}`,
                confidence: data.confidence, action: data.action, tool_calls: data.tool_calls,
                booking_id: data.booking_id }]);
        } catch (e) { toast.error("Turn failed"); } finally { setBusy(false); }
    }
    async function endCall() {
        if (!callId) return;
        const dur = started ? Math.floor((Date.now() - started) / 1000) : 0;
        try {
            const { data } = await api.post("/ai/call/end", { call_record_id: callId, duration_seconds: dur });
            toast.success(`Call ended — outcome ${data.outcome}`);
            setCallId(null); setConvId(null); setStarted(null); setMsgs([]);
            load();
        } catch { toast.error("End call failed"); }
    }

    return (
        <div className="p-6 max-w-6xl" data-testid="call-sim-page">
            <div className="flex items-start justify-between flex-wrap gap-4">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Voice</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Call simulator</h1>
                    <p className="text-sm text-zinc-500 mt-1 max-w-2xl">
                        Test your receptionist as if it were answering a phone call. Every call produces
                        a transcript + AI summary + outcome, stored exactly like real calls will be.
                    </p>
                </div>
            </div>

            <div className="mt-4 rounded-xl border-2 border-dashed border-amber-300 bg-amber-50/50 p-3 text-xs text-amber-900" data-testid="call-sim-honesty-banner">
                Simulated call — <span className="font-medium">demo</span>. Real voice needs a provider connection (see below).
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                {providers.map((p) => (
                    <div key={p.key} className="rounded-xl border-2 border-brand-line bg-white p-4" data-testid={`voice-provider-${p.key}`}>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-medium text-brand-ink"><Phone className="w-4 h-4" /> {p.label}</div>
                            <Badge className="bg-zinc-100 text-zinc-600">Not connected</Badge>
                        </div>
                        <div className="text-xs text-zinc-600 mt-2">{p.honest_status}</div>
                        <div className="text-[10px] text-zinc-400 mt-1">{p.docs}</div>
                    </div>
                ))}
            </div>

            <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2 rounded-2xl border border-brand-line bg-white overflow-hidden flex flex-col h-[560px]">
                    <div className="px-4 py-3 border-b border-brand-line flex items-center justify-between">
                        <div className="text-xs text-zinc-500">
                            {callId ? <>Live: <span className="font-mono">{callId.slice(-6)}</span></> : "No call in progress"}
                        </div>
                        {callId ? (
                            <Button size="sm" variant="destructive" onClick={endCall} data-testid="call-end-btn"><PhoneOff className="w-3.5 h-3.5 mr-1" /> End call</Button>
                        ) : null}
                    </div>
                    {!callId ? (
                        <div className="flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
                            <Phone className="w-8 h-8 text-brand-copper" />
                            <div className="text-sm text-zinc-500">Start a simulated call to test the receptionist.</div>
                            <div className="grid grid-cols-2 gap-2 w-full max-w-sm">
                                <Input placeholder="Caller name (opt.)" value={caller.name} onChange={(e) => setCaller({ ...caller, name: e.target.value })} data-testid="caller-name" />
                                <Input placeholder="Caller phone (opt.)" value={caller.phone} onChange={(e) => setCaller({ ...caller, phone: e.target.value })} data-testid="caller-phone" />
                            </div>
                            <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={startCall} data-testid="call-start-btn">
                                <Phone className="w-4 h-4 mr-1" /> Start simulated call
                            </Button>
                        </div>
                    ) : (
                        <>
                            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 bg-brand-surface" data-testid="call-messages">
                                {msgs.map((m) => (
                                    <div key={m.id} className={`flex ${m.role === "visitor" ? "justify-end" : "justify-start"}`}>
                                        <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${m.role === "visitor" ? "bg-brand-ink text-white" : "bg-white border border-brand-line whitespace-pre-wrap"}`}>
                                            <div className="text-[10px] uppercase tracking-widest text-zinc-400 mb-0.5">{m.role === "visitor" ? "Caller" : "Agent"}</div>
                                            {m.content}
                                            {m.booking_id && <div className="text-[10px] mt-1 text-emerald-700">→ booked #{m.booking_id.slice(-6)}</div>}
                                        </div>
                                    </div>
                                ))}
                                {busy && <div className="text-xs text-zinc-500 flex items-center gap-1"><Loader2 className="w-3.5 h-3.5 animate-spin" /> processing…</div>}
                            </div>
                            <form onSubmit={(e) => { e.preventDefault(); send(); }} className="border-t border-brand-line p-2 bg-white flex gap-1.5">
                                <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="What the caller says…" disabled={busy} data-testid="call-input" />
                                <Button size="sm" type="submit" disabled={busy || !input.trim()} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="call-send-btn">
                                    <Send className="w-4 h-4" />
                                </Button>
                            </form>
                        </>
                    )}
                </div>
                <div className="rounded-2xl border border-brand-line bg-white overflow-hidden">
                    <div className="px-4 py-3 border-b border-brand-line text-xs uppercase tracking-widest text-zinc-500">Recent calls</div>
                    <div className="divide-y divide-brand-line max-h-[520px] overflow-y-auto" data-testid="calls-list">
                        {calls.map((c) => (
                            <Link key={c.id} to={`/app/ai/conversations/${c.conversation_id}`} className="block px-4 py-3 hover:bg-brand-cream/40" data-testid={`call-row-${c.id}`}>
                                <div className="flex items-center justify-between">
                                    <div className="text-xs font-mono text-brand-copper">{c.id.slice(-6)}</div>
                                    <Badge className={c.outcome === "booked" ? "bg-emerald-100 text-emerald-800" : c.outcome === "escalated" ? "bg-amber-100 text-amber-800" : "bg-zinc-100 text-zinc-600"}>{c.outcome}</Badge>
                                </div>
                                <div className="text-xs text-zinc-500 mt-1 line-clamp-2">{c.ai_summary || "—"}</div>
                                <div className="text-[10px] text-zinc-400 mt-1">{c.duration_seconds}s · ${((c.cost_cents || 0) / 100).toFixed(2)}</div>
                            </Link>
                        ))}
                        {!calls.length && <div className="p-6 text-xs text-zinc-500 text-center">No calls yet.</div>}
                    </div>
                </div>
            </div>
        </div>
    );
}
