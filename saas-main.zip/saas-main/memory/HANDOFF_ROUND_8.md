# ZANELVO — HANDOFF ROUND 8 (for a NEW chat)

_Written 2026-09-06 at the end of the "second continuation". Supersedes HANDOFF_ROUND_7.md.
Read this file first, then `SECOND_RUN_AUDIT.md`, then `WHATS_LEFT.md`. Everything else in
`/app/memory` is reference (PRD, SECURITY, ENVIRONMENT_VARIABLES, COMPETITOR_COMPARISON, TESTING…)._

---------------------------------------------------------------------------------------------------
## 0. HOW TO CONTINUE THIS PROJECT (do this in the first 10 minutes of the new chat)
---------------------------------------------------------------------------------------------------

### 0.1 The environment is WIPED on import — rebuild it
Both `.env` files are empty after import and `node_modules` / pip packages are gone.

```bash
# 1. Preview host (do NOT guess it; it changes per job)
env | grep -i preview_endpoint          # e.g. https://bootstrap-fix-2.preview.emergentagent.com

# 2. backend/.env  (MONGO_URL + DB_NAME are the only protected ones; the rest is ours)
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
EMERGENT_LLM_KEY=<call the emergent_integrations_manager tool to get it>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
CORS_ORIGINS=*
EOF

# 3. frontend/.env
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host from step 1>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF

# 4. deps (emergentintegrations needs the extra index; it is in requirements.txt)
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile
sudo supervisorctl restart backend frontend && sleep 30 && curl -s localhost:8001/api/health
```

- Seeding runs on startup (dev only). If `/app/memory/test_credentials.md` is empty it is regenerated with
  FRESH random passwords (founder + owner) — always send the user the new file contents, never old ones.
- Image model used by `services/llm.py`: `IMAGE_PROVIDER/IMAGE_MODEL` from `config.py` (Gemini "nano banana"
  `gemini-3.1-flash-image-preview` by default). All LLM calls go through `services/llm.py` → `services/usage.py`.
- Frontend dev server sometimes misses new files → if a new component is not in the bundle:
  `sudo supervisorctl restart frontend`.

### 0.2 Logins
| Who | UI | API | Notes |
|---|---|---|---|
| Customer owner | `/login` → `/app` | `POST /api/auth/login` | org "Demo Home Services"; creds in test_credentials.md |
| Founder / staff | `/staff/login` → click **"Staff sign in"** | `POST /api/staff/auth/login` | SEPARATE collection `staff_accounts`; 2FA auto-skipped until an email provider is connected |
| Public demo site | `/site/demo-home-services` | `GET /api/public/sites/demo-home-services` | language switcher enabled (en/es/fr/he) |
| Storefront | `/store/<org_id>` | `/api/public/store/{org_id}/…` | org_id is in the public site payload |

### 0.3 Architecture map (where things live)
- `backend/server.py` — app, hardening middleware (413, X-Request-Id, security headers, global soft rate limit,
  InvalidId→400, LlmError→503), CORS (credentials only with explicit origins), startup seeds gated by `SEED_DEMO`.
- `backend/app/routes/*.py` — one router per area (see table in §2). Owner routes use `Depends(require_org)`;
  staff routes use `require_staff("<perm>")` (perms defined in `routes/staff.py::STAFF_ROLES`); founder-only uses
  `require_role("platform_founder")`.
- `backend/app/services/usage.py` — **THE cost gate** (enforce → reserve → settle/release; controls; ledger; margin).
- `backend/app/services/llm.py` — `generate_text / generate_json / generate_image` (metered).
- `backend/app/services/email_providers.py` — `MeteredProvider` wraps every email adapter.
- `backend/app/services/integrations.py` + `tenant_integrations.py` — Staff Setup Center secrets, encrypted at rest
  via `services/secretbox.py`. Read plaintext with `integ.get_secret(section, field)`; NEVER return raw values.
- `backend/app/services/netsafe.py` — SSRF guard for any outbound URL a user supplies.
- `frontend/src/App.js` — all routes. Customer dashboard `pages/dashboard/*`, website editor `pages/editor/*`,
  staff panel `pages/staff/*` (nav in `StaffShell.jsx`), public `pages/public/*`, marketing site `pages/Home.jsx`,
  `pages/Pricing.jsx`.
- Testing protocol: `/app/test_result.md` (append a `backend_roundN:` / `frontend_roundN:` block before calling the
  testing agents; they read it). Use `deep_testing_backend_v2` first, then `auto_frontend_testing_agent`.

### 0.4 Non-negotiable rules carried forward
1. Any new paid/variable-cost operation MUST call `usage.enforce_budget()` + `usage.reserve()`/`settle()` (or
   `record_usage()` for fixed-unit things like SMS). Public flows must catch the 402/503 and return an honest fallback.
2. Never store prompts, secrets or PII in the ledger. Never display secrets (Staff Setup Center masks them).
3. Prices come ONLY from `db.plans` (`GET /api/plans`); plan edits go through `PUT /api/founder/plans-admin/{code}`
   (validated + versioned). Checkout/invoice snapshots are immutable.
4. Customer-facing copy: brand "Zanelvo" only, no competitor names/tables, no dev-progress language ("Phase 3",
   "coming soon" for shipped things), no fake testimonials/stats, no lorem ipsum, one dominant **Build my website** CTA.
5. Truthful integration states everywhere: Connected / Sandbox / Not connected / Error (never simulate success in prod).
6. Production (`APP_ENV` not in dev/test/demo): no demo seed, founder bootstrapped from `FOUNDER_INITIAL_PASSWORD`,
   reset tokens never returned, inbound-email/voice webhooks require secrets.
7. Do not mark anything "live" in docs without a passing test.

---------------------------------------------------------------------------------------------------
## 1. WHAT ROUND 8 SHIPPED (all tested: backend 23/23 after fix, re-verify 5/5, frontend 10/10)
---------------------------------------------------------------------------------------------------
- Central cost & usage service + founder controls (pause-all, provider kill switches, global monthly budget,
  per-user share, per-feature caps, visitor daily cap), reservations/settlement, universal ledger, CSV export,
  gross-margin view, traffic observation. UI `/staff/ai-usage`.
- P0 security list (hashed single-use reset tokens + session invalidation, invite via set-password link, CORS,
  413 limits, InvalidId→400, SSRF guard, secrets encrypted at rest, Mongo-backed auth rate limits, authenticated
  inbound-email + voice webhooks, atomic order finalize, production seed gating, security headers, redacted creds).
- Pricing versioning (`plan_pricing_history`, `GET /api/founder/plans-admin/{code}/history`) + validation.
- Provider status cards (`GET /api/staff/providers/status`, on `/staff/payments`).
- Internal competitor matrix (`/staff/competitive`, `routes/competitive.py`, `memory/COMPETITOR_COMPARISON.md`).
- Public site / storefront language switcher with Hebrew RTL (`components/public/LanguageSwitcher.jsx`,
  `GET /api/public/localization/{org}/settings`; translate refuses non-enabled languages).
- Truth sweep: Home testimonials → labelled example scenarios; generator truth rule; brand strings; dev copy removed.

---------------------------------------------------------------------------------------------------
## 2. STATUS OF EVERY ITEM IN THE SECOND-CONTINUATION PROMPT (A → N)
---------------------------------------------------------------------------------------------------
Legend: ✅ done & tested · 🟡 partial (what exists / what's missing) · ❌ not built · 🔒 blocked on owner credential/action.
For every 🟡/❌ item there is a "How to build" note with the exact files to touch and how to test it.

### A. Completion audit — ✅
`SECOND_RUN_AUDIT.md` written (features, partials, simulated integrations, bugs, security, cost leaks, parity gaps,
order, verification). Keep it updated at the end of every round.

### B. P0 reliability / security / cost
| Item | Status | Detail / how to finish |
|---|---|---|
| One central cost service | ✅ | `services/usage.py`. Wired: text/JSON/website generation/profile extraction/rewriting/translation/chat-agent/support-agent/lead scoring/email generation (all via `llm.py`), image + logo generation (`generate_image`), email delivery (`MeteredProvider`), public chat/translate/voice (public=True). |
| Research / embeddings / video generation | ❌ | Not implemented as features at all. When added: call `usage.estimate_cost(kind="embedding_1k"…)`, `enforce_budget`, `reserve`, `settle`. Unit rates already exist in `COST_RATES` (`unit/embedding_1k`). |
| Voice minutes / phone numbers metering | 🟡 | Voice LLM turns are metered (`public_voice`). Carrier minutes and monthly number rent are NOT recorded because the carrier is simulated. How: in `services/numbers.py` after a real purchase/call-end webhook call `usage.record_usage(kind="phone_number_month", units=1, provider="telnyx")` / `kind="voice_second", units=<seconds>`. Test: buy a number in sandbox → row appears in `GET /api/usage/ledger`. |
| SMS / WhatsApp metering | ❌ | No SMS/WhatsApp sender exists yet. Build `services/sms_providers.py` (Twilio/Telnyx/Meta adapters + `Simulated`) mirroring `email_providers.py`, wrap in a `MeteredProvider`-style class with `kind="sms"`/`"whatsapp"`. |
| Shipping-rate / label calls metering | 🟡 | Native rate engine is free (no external call). When Shippo/EasyPost adapter is connected (`services/shipping.py` aggregators), wrap the HTTP call with `record_usage(kind="shipping_rate"/"shipping_label")`. |
| Ad-platform calls / paid spend | ❌ | No ad account integration. When built, every API call → `kind="ad_api_call"`, spend → `kind="ad_spend_usd", units=<usd>`; require `enforce_budget` + explicit owner activation flag. |
| Background jobs & retries accounting | 🟡 | LLM retries are metered (`retry_count`). Abandoned-checkout sweep + scheduled sends are metered as email. Missing: per-job cost caps and a job-level `request_id` grouping. How: pass `usage.set_context(request_id=job_id, feature="job/<name>")` at job start in `routes/store.py::abandoned sweep`, `routes/inbox.py` scheduled sender, `routes/marketing.py` automations runner. |
| Ledger fields | ✅ | org, user, feature, operation, provider, model, request_id, idempotency_key, tokens in/out, images + resolution, units (chars/seconds/messages), retry_count, cache_hit, estimated + actual cost, currency, latency, status, error, created_at, billing_period. No prompts/PII. |
| Reservations, reconciliation, release, idempotency, cache | ✅ | `usage.reserve/settle/release/find_idempotent/remember_idempotent`; stale holds expire after 300 s. Idempotent text calls: pass `idempotency_key=` to `generate_text`. |
| Per-plan / per-user / per-feature / org hard caps / founder global cap / warnings / hard stops | ✅ | Plan cap = `entitlements.ai_budget_usd(plan)`; controls in `platform_settings.usage_controls`. 402 codes: `ai_budget_reached`, `user_ai_budget_reached`, `feature_budget_reached`, `public_daily_cap_reached`; 503: `usage_paused`, `provider_disabled`, `platform_budget_reached`. |
| Pause-all / provider kill switches | ✅ | `POST /api/staff/usage/pause-all|resume-all`, `PUT /api/staff/usage/controls {"provider_kill":{"anthropic":true}}`. Also legacy `PUT /api/founder/global-controls/kill` (AI agents). |
| Usage / cost / gross-margin dashboards, exportable ledger, audit history | ✅ | Owner: Billing page panel + `/api/usage/ledger(.csv)`. Staff: `/staff/ai-usage` (+ `/api/staff/usage/margin`, `ledger.csv`, `controls.audit`). |
| Budget warning notifications | ❌ | `warn` flag is computed but nobody is emailed. How: a daily job (or on `settle`) that, when `org_usage_summary.warn` flips true, sends `platform_mail.send("noreply", owner_email, …)` once per month (store `warned_month` on org). Test: set `feature_caps_usd` low → trigger → mail row in `email_logs`. |
| Public visitors can't consume tenant quota unmetered | ✅ | Widget/translate/voice set `public=True`; visitor daily cap control; translate refuses languages the owner didn't enable. |
| CRUD/auth never metered, but rate-limited + observed | ✅ | Global soft limit `API_GLOBAL_RPM`, `GET /api/staff/usage/traffic`. |
| Password reset exposure / hashing / atomic consume / expiry / session invalidation | ✅ | `routes/auth.py`, `deps.py` (`sessions_invalidated_at`, iat `<=`). Emails go out via `platform_mail` when a provider is connected. |
| Invitation temp-password exposure | ✅ | `routes/auth_ext.py::invite` (set-password link) and `routes/staff.py::create_member`. **No frontend page consumes `/api/team/invite` yet** → build a Team page (`pages/dashboard/Staff.jsx` exists for tenant staff; check whether it uses `/team/*`). |
| Production auto-seeding / demo creds in docs / keys in memory+tests | ✅ | Gated in `server.py` + `seed.py`; old creds + LLM key redacted; `backend_test.py` reads `TEST_OWNER_PASSWORD`. |
| Wildcard CORS with credentials | ✅ | `server.py`. For production set `CORS_ORIGINS=https://zanelvo.com,https://app.zanelvo.com`. |
| Invalid ObjectId 500s | ✅ | middleware + handler. |
| Request-size limits / unbounded uploads / CSV reads | 🟡 | Global 2 MB JSON / 25 MB multipart. Missing: chunked uploads (`routes/media_forms_analytics.py::upload` is single-shot) and CSV row caps in `routes/crm.py` import + `routes/store.py::products/import/analyze`. How: cap rows (e.g. 5 000) and bytes before parsing; implement chunk endpoints `POST /api/media/upload/init|chunk|complete` writing to `/app/backend/uploads`. |
| Public endpoint abuse | ✅/🟡 | Rate limits on widget, translate, forms, reset, login. Add `rl.check` to any new public route. |
| Shared/in-memory-only rate limits | 🟡 | Auth buckets Mongo-backed (`check_persistent`). Others in-process. For multi-worker prod add Redis-backed `check` (env `REDIS_URL`). |
| Webhook signatures / idempotency / cross-tenant resolution | ✅/🟡 | Stripe: signature + `webhook_events` idempotency, tenant resolved from metadata. PayPal webhook signature verification is NOT implemented (adapter only) — implement `verify-webhook-signature` API call in `services/payment_providers.py` before going live. Inbound email + voice authenticated. |
| SSRF / private-IP / DNS-rebinding | ✅ | `services/netsafe.py` used by import + outbound webhooks + webhook creation. Reuse for any new fetch of a user URL (product sourcing `services/product_sourcing.py` still uses plain httpx — wrap it). |
| Unsanitised SVG | ❌ | AI logos are generated as SVG strings and rendered with `dangerouslySetInnerHTML` in `pages/dashboard/LogoStudio.jsx` / branding. How: add `pip install defusedxml` or a strict allow-list sanitiser in `services/images.py::sanitize_svg()` (strip `<script>`, `on*=`, `<foreignObject>`, external `href`), run on save in `routes/branding.py` and on upload. Test: upload SVG with `<script>` → stored without it. |
| Plaintext integration secrets | ✅ | `services/secretbox.py` (Fernet; `SECRETS_ENC_KEY` or derived from JWT_SECRET). Legacy plaintext values are re-encrypted on next save. |
| Unsafe public host overrides | 🟡 | `GET /api/public/sites/by-host` resolves hostname → site only for verified domains (check `routes/public_sites.py`). Confirm the frontend never lets `?host=` override on non-preview builds; add an allow-list env `PUBLIC_HOST_OVERRIDE_ALLOWED=false` for prod. |
| Non-atomic inventory updates | ✅ | `routes/store.py::_finalize_paid_order` atomic claim + guarded `$inc`, oversold flag. Stock *reservations at checkout start* are not implemented (see E). |

### C. Pricing consistency
| Item | Status | Detail |
|---|---|---|
| DB is the only pricing source | ✅ | `db.plans`, `GET /api/plans`; Home/Pricing/Billing/Checkout read it. `config.py` DEFAULT_PLANS only seed when missing. |
| Hardcoded prices removed from homepage/pricing/checkout/billing/invoices/emails/help/entitlements/founder analytics/marketing/tests/frontend constants | ✅ (verified by grep) | Only illustrative UI mock numbers remain in the Home hero mock ("$1,240 collected") — they are a product-screenshot mock, not a price. If the user objects, replace with neutral placeholders. |
| Validate, version, history | ✅ | `PUT /api/founder/plans-admin/{code}` (422 rules) + `plan_pricing_history` + `/history`. Staff UI `StaffPlans.jsx` does NOT yet show the history table → add a "Pricing history" drawer reading `/api/founder/plans-admin/{code}/history`. |
| Update public displays immediately | ✅ | Pricing page fetches on load (no cache). |
| New price for future purchases, preserve snapshots + historical invoices | ✅ | checkout sessions store `price_cents`; invoices immutable. |
| Monthly + annual | ✅ | `price_usd`, `annual_price_usd`, `annual_discount_pct`. |
| Entitlements/usage limits update with plan | ✅ | `limits` on plan doc → `services/entitlements.py`. |
| Final amount before payment, no client-side manipulation | ✅ | server computes amount from plan; client sends only plan code + interval. |

### D. Core website product
| Item | Status | Detail / how to finish |
|---|---|---|
| Adaptive onboarding interview | 🟡 | `routes/onboarding.py` interview → BusinessProfile works. Round-7 wish "interview out of signup + build-from-scratch + template gallery" NOT done. How: new route `/app/website/new` with 3 cards (Interview / From scratch / From template); from-scratch = `POST /api/editor/website/pages` + empty hero; template = copy of a `db.site_templates` doc (seed 6 industry templates from `generation.py` variants). |
| Build-from-scratch path | ❌ | See above. |
| Tailored AI generation, distinct industry layouts, block JSON | ✅ | `services/generation.py` (industry variant hints), 24 block types in `routes/editor.py::BLOCK_LIBRARY`. |
| Visual click-to-edit editor, drag-reorder, duplicate/delete, inline text, image/logo replace, theme, responsive previews, autosave, undo/redo | ✅ (exists) | `pages/editor/*` (dnd-kit Canvas, InlineText contentEditable, Inspector, MediaPicker, device switch, reducer undo/redo, 900 ms autosave). **Not regression-tested this round** → include in next frontend test run. |
| Drafts / revisions / rollback / publish | ✅ | `routes/editor.py` revisions + rollback; publish snapshots. |
| Section regeneration | ❌ | How: `POST /api/editor/blocks/{block_id}/regenerate` → `generation.regenerate_block(profile, block)` (small prompt, `feature="section_regenerate"`), replace props, keep id. Inspector button "Regenerate copy". Test: block headline changes, ledger row recorded. |
| Reusable sections | ❌ | How: `db.saved_sections` {org_id, name, block}; `POST /api/editor/blocks/{id}/save-as-section`, list in `AddSectionMenu.jsx`. |
| Template library | ❌ | See build-from-scratch. |
| Media library | 🟡 | `routes/media_forms_analytics.py` upload/list/delete + `MediaPicker.jsx`. Missing: chunked upload, alt-text editing, folders. |
| Forms / booking / product / pricing / testimonials / FAQ blocks | ✅ | `form`, `store`, `pricing_table`, `testimonials`, `faq`, `gallery`, `video`, `map`, `stats`, `team`, `countdown`… Booking block: `store`/`cta_band` link to booking page — a dedicated `booking` block with live availability is ❌ (how: block type `booking` rendering `pages/public/BookingWidget` using `/api/public/bookings/availability`). |
| Blog / articles | ❌ | How: `db.posts` {org_id, slug, title, body_blocks, seo, published_at}; owner CRUD `/api/blog/*`; public `/api/public/sites/{slug}/blog`; block `blog_list`; sitemap entries. |
| SEO fields / metadata / Open Graph | ✅ | page `seo` dict; `public_sites.py` emits title/description/OG. |
| Schema markup | 🟡 | LocalBusiness JSON-LD exists in public renderer; Product/FAQ/Article schema ❌ (add in `PublicSite.jsx` per block type). |
| Sitemap / redirects / alt text | ✅/🟡 | sitemap + redirects in `routes/sites.py`/`public_sites.py`; alt text stored on image props, no editor UI to edit it (add field in Inspector image controls). |
| Performance / accessibility / mobile | 🟡 | Tailwind responsive; no Lighthouse run this round. Run `auto_frontend_testing_agent` with an axe check request. |
| Multilingual content / Hebrew RTL | ✅ (switcher) / 🟡 | Runtime translation switcher live. Per-language *authored* content (editing Hebrew copy manually) ❌ — how: `page.translations[lang].blocks` overlay in editor, served when `?lang=` set. |
| AI truth rule | ✅ | `generation.py` prompts. |
| Hosting: `/site/{slug}`, hostname routing, custom domains, DNS records, ownership verification, DNS polling, states | ✅ | `routes/domains.py` + `services/domain_providers.py` (Pending/Verifying/Connected/Error + troubleshooting). |
| SSL states / real certificate issuance | 🔒 | Adapter is `simulated`. Implement `CloudflareForSaaSProvider` or Vercel domains API in `domain_providers.py` (env `DOMAIN_PROVIDER=cloudflare`, token via Staff Setup Center). Until then the card says **Sandbox**. |
| Import/rebuild secondary, connect-only advanced | ✅ | `routes/import_site.py` (SSRF-safe), `routes/sites.py` binding. |

### E. Commerce parity
| Item | Status | Detail / how to finish |
|---|---|---|
| Products, variants, SKU, tags, product media, collections, discount codes, inventory, low-stock alerts, digital products, product CSV import (with column mapping) | ✅ | `routes/store.py`, `routes/ecommerce.py`, `routes/shipping.py` (inventory). |
| Options (size/colour matrices), barcode | 🟡/❌ | Variants are flat {name, stock, price}. Add `options: [{name, values}]` + generated variant matrix + `barcode` field in `ProductIn`/`_product_out`; Products.jsx form. |
| Stock reservations at checkout | ❌ | How: on buy-now create `stock_reservations` {product_id, qty, expires_at 30 min}; available = stock − active reservations; release on expiry/cancel; consume on paid. |
| Bundles / upsells / cross-sells / related products | ❌ | `product.related_ids`, `bundle_items`; storefront "You may also like" via shared tags. |
| Subscriptions (recurring products) | ❌ | Needs Stripe Billing: `price_recurring` on product, `mode=subscription` in `payment_providers.stripe_checkout`, webhook `invoice.paid`. |
| Gift cards | ❌ | `db.gift_cards` {code, balance_cents, org_id}; redeem at checkout as a discount line; issue on purchase of a `gift_card` product. |
| Automatic discounts | 🟡 | Codes exist; add `auto: true` rule evaluation in `ecommerce.py::validate` when no code entered. |
| Customer groups | ❌ | CRM tags exist; add `customer_group` on contact + discount `eligible_groups`. |
| Tax configuration / tax display by region | ❌ | `db.tax_rates` {country, region, pct, inclusive}; apply in buy-now; show incl/excl on storefront by `country_code`. |
| Shipping zones / methods / tracking / packing slips | ✅ | `routes/shipping.py`. |
| Live carrier-rate adapter / label generation | 🔒 | Shippo/EasyPost adapters listed in `services/shipping.py` but need an API key via Staff Setup Center; then implement `rates()`/`buy_label()` HTTP calls + `record_usage(kind="shipping_rate"/"shipping_label")`. |
| Fulfilment / refunds / cancellations | ✅ | `POST /orders/{id}/fulfill|refund|cancel` (refund via provider when connected). |
| Partial fulfilment / returns (RMA) / order notes / status history | 🟡 | Status set directly; add `status_history[]` push on every transition, `notes[]` with author, `returns` collection + `/orders/{id}/return`. |
| Guest checkout / checkout recovery / receipts / invoices / transactional notifications | ✅ | buy-now is guest; abandoned sweep; order emails via `services/transactional.py`. |
| Customer accounts / saved carts | ❌ | Public auth for shoppers (`db.shop_customers`, magic-link login), cart persisted server-side by customer id. |
| Webhooks (order events) | ✅ | `services/webhooks.py` emits signed events (`X-Zanelvo-Signature`). |
| Product CSV export / safe migration tools | 🟡 | Import ✅, export ❌ (`GET /api/store/products/export.csv`). Migration from Shopify via CSV mapping works. |
| Payment behaviour (configured provider, sandbox unless live, no simulated success in prod, signatures, idempotency, snapshots, no client prices, tenant funds) | ✅ / 🔒 | Code path verified; Stripe **Not connected** until keys are entered in Staff Setup Center. PayPal webhook signature ❌ (see B). Tenant funds separation = Stripe Connect ❌ (currently platform account collects for tenants via `metadata.org_id`; for real marketplaces implement Connect Express onboarding in `payment_providers.py`). |

### F. Automation & marketing
| Item | Status | Detail / how to finish |
|---|---|---|
| Visual workflow builder (triggers, conditions, branches, delays, schedules, actions, templates, versions, drafts, publish/pause, test mode, run history, retries, failure handling, logs, approval gates, cost limits) | 🟡 | `routes/marketing.py` automations: trigger + steps (delay/email/sms-placeholder), publish/pause, runs, test-run. Missing: conditions/branches, schedules, version history, retries/dead-letter, approval gates, per-workflow cost limits, and a **visual canvas UI** (Marketing.jsx is a list). How: model `workflow.graph = {nodes:[{id,type,config}], edges:[{from,to,when}]}`; runner in `services/workflows.py` executes node by node persisting `workflow_runs.steps[]`; UI with `@xyflow/react` (add to package.json) in `pages/dashboard/Workflows.jsx`. Meter every AI/email node via `usage`. |
| Trigger coverage | 🟡 | Have: booking_created, booking_cancelled, form_submitted, quote_accepted, review_request, abandoned checkout (separate sweep). Missing: new_lead, new_customer, abandoned_cart (pre-checkout), booking_reminder (bookings have their own reminders), quote_sent, quote_not_answered, payment_failed, order_completed, win-back, birthday/anniversary, low_stock, new_campaign, support_escalation. How: emit `events.publish(org_id, "quote.sent", payload)` from the relevant routes (`bookings.py`, `store.py`, `shipping.py` low stock, `support.py`) and register them in the trigger list. |
| Email capabilities | 🟡 | Have: templates (campaign body), AI copy assist, personalization tokens, segmentation by tags, scheduling, A/B, delivery logs, opens/clicks, replies (inbox), conversion attribution, unsubscribe + suppression, consent flags, metering. Missing: drag-and-drop email editor (use a block-based body like the site editor), localization of campaigns, quiet hours, send-time testing, bounce webhooks (Resend/SendGrid inbound events → `email_logs.bounced`), retries + dead-letter for sends (`scheduled_sends.attempts`, `dead_letter` flag). |
| SMS / WhatsApp | ❌ | See B (no provider). Build adapters first, then automation node "send_sms". |
| Separation of Zanelvo's own marketing vs tenant marketing | ✅ | Staff email center (`routes/staff_email.py`, platform provider) vs tenant campaigns (`routes/marketing.py`, tenant provider in `tenant_integrations`). Contacts/campaigns/credentials are in different collections. Keep it that way. |

### G. Advertising & creative tools
| Item | Status | Detail |
|---|---|---|
| Multiple concepts, copy, variants, export bundles | ✅ | `POST /api/marketing/creative/generate`, bundles + export (JSON/CSV). |
| Images (generate or import), video scripts/storyboards, aspect ratios, multilingual + RTL, brand voice, asset provenance, scoring vs goals, approvals, budget caps, pause-all campaigns | ❌ | How: extend `creative/generate` with `formats:["1:1","4:5","9:16","16:9"]` (image via `generate_image`, `feature="ads_creative"`), `languages`, `video_script: true` (text), store `provenance: "ai"|"uploaded"|"placeholder"` per asset (never claim AI for placeholders), `score` = LLM rubric vs `goal`; `ad_campaigns` with `approval_status`, `budget_cap_usd`, `paused`. UI: new `pages/dashboard/AdsStudio.jsx`. |
| Ad-account integrations (Google/Meta) clearly marked | ✅ (status card "Not connected") / 🔒 | OAuth apps + tokens via Staff Setup Center; never auto-spend — require explicit `activate_live_spend` with owner confirmation and `usage.enforce_budget`. |

### H. Analytics & attribution
| Item | Status | Detail |
|---|---|---|
| Page views, sessions, CTA clicks, form submits, email opens/clicks, campaign + variant attribution, revenue attribution (last touch) | ✅ | `routes/media_forms_analytics.py::track/summary`, `routes/tracking.py`, `services/campaign_tracking.py`, `GET /api/marketing/analytics/overview`. |
| UTM source/medium/campaign/content/term persisted through funnel, customer_id | 🟡 | UTMs generated for campaign links; storefront/public site do not yet persist arbitrary inbound UTMs to the contact. How: on first public page view store `utm_*` + `landing` in a cookie (`zv_attr`), attach to form submits, bookings, buy-now (`attribution` sub-doc on contact/order). |
| Impressions, refunds/cancellations, quotes/checkouts/payments as funnel events | 🟡 | Orders/quotes exist as records; add `analytics_events` emission on each state change (`services/events.py`). |
| Funnel / channel / campaign reports, A/B allocation, conversion rate | 🟡 | Campaign report ✅, A/B ✅; funnel + channel reports ❌ (aggregate `analytics_events` by `attribution.source`). |
| CAC, ROAS, AOV, LTV, churn, retention, contribution margin, cohorts, export | ❌ | AOV/LTV from `store_orders` + invoices per contact; churn/retention from `subscriptions` (platform) and repeat orders (tenant); CAC/ROAS need ad spend (G). New `routes/analytics.py` + `pages/dashboard/SeoAnalytics.jsx` extension; CSV export. |
| Consent-aware tracking | 🟡 | `consent` on contacts for email; add cookie banner + `analytics_consent` gate in `PublicSite.jsx` before firing `/api/analytics/track`. |
| Campaign/workflow/analytics status mismatch | ✅ | Verified statuses align (campaign `sent` ↔ analytics). |

### I. Discovery, integrations, extensibility
| Item | Status | Detail |
|---|---|---|
| Storefront search / filters / sorting | 🟡 | Storefront.jsx has collection filter; add text search + price sort (`GET /api/public/store/{org}/products?q=&sort=`). |
| Recommendations / recently viewed | ❌ | Related products (E) + localStorage recently viewed in Storefront.jsx. |
| Product feeds (Google Merchant / social / marketplace export) | ❌ | `GET /api/public/store/{org}/feed.xml` (Google Shopping RSS spec), `feed.csv` for Meta; owner toggle. |
| OAuth connection flows (ad accounts, Google Business, etc.) | ❌ | Generic `routes/oauth_connect.py` with state param + encrypted token storage in `tenant_integrations`. |
| Scoped API keys | ✅ | `routes/setup.py` api-keys + `routes/public_api.py` (scopes read/write). |
| Outbound webhooks + retries + dead-letter + replay | ✅ | `services/webhooks.py`, founder dead-letter + retry. Replay by event id ❌ (add `POST /api/setup/webhooks/{wid}/replay/{delivery_id}`). |
| Inbound webhooks | ✅ | Stripe, email inbound, voice (authenticated). |
| API documentation | 🟡 | FastAPI `/docs` exists (internal). Public developer page with the `/api/v1/*` examples ❌ (`pages/Developers.jsx`). |
| Integration health / audit logs / integration catalog architecture | ✅ | `GET /api/staff/providers/status`, `services/audit.py`, Setup cards (`routes/setup.py::cards`). |

### J. International & support
| Item | Status | Detail |
|---|---|---|
| Storefront language switcher, RTL, accessible selection, translated nav/product/service content (runtime) | ✅ | `LanguageSwitcher.jsx` (owner-enabled languages only, metered). |
| Translated emails / localized SEO | ❌ | Campaign `language` field + `_translate` on send; per-language `seo` on pages. |
| Currencies + formatting | 🟡 | Store has `currency` per org (`store/settings`); formatting via `Intl.NumberFormat` in Storefront. Multi-currency display/FX ❌. |
| Timezone support | 🟡 | Bookings use org timezone; dashboard dates are browser-local. Add `org.timezone` everywhere emails render times. |
| Tax display by region | ❌ | See E tax configuration. |
| Support: tickets, knowledge base (help articles), AI support grounded in docs, escalation to human, status endpoint, activation checklist | ✅ | `routes/support.py`, `services/help_articles.py`, `pages/dashboard/Support.jsx`. |
| Unified support inbox, assignments, internal notes, collision prevention, support analytics, public status page | ❌ | Staff side: `pages/staff/StaffSupport.jsx` (list tickets across tenants, assign `assignee_staff_id`, `internal_notes[]`, `locked_by` with 60 s heartbeat); public `/status` page reading `GET /api/support/status` + incidents collection. |
| Help articles generated from actual features | 🟡 | Static list in `help_articles.py`; regenerate when features ship. |

### K. Founder / staff operations
| Item | Status | Detail |
|---|---|---|
| Tenants, plans, pricing history API, subscriptions, MRR, usage, LLM + provider costs, gross margin, kill switches, global budget, provider setup, audited impersonation, exports, approvals, feature flags, dead-letter, health | ✅ | `/staff/*` pages + `routes/founder.py`, `platform_admin.py`, `usage.py`. |
| Pricing history UI | ❌ | Add table to `StaffPlans.jsx` (API exists). |
| API errors / failed jobs views | 🟡 | `GET /api/founder/health` + dead-letter. Add `error_events` capture in `server.py::_unhandled` → `db.error_events` and a staff list. |
| Email health / webhook health | 🟡 | Email center shows logs; add bounce/complaint rates once provider webhooks exist. Webhook delivery success % → founder health. |
| Fraud/abuse actions | 🟡 | `StaffFraud.jsx` lists signals; suspend exists; blocklist (IP/email domain) ❌. |
| Support (staff) | ❌ | See J. |
| Deployment health | 🟡 | `/api/health` + founder health; add build SHA + uptime + DB ping latency. |
| Integration cards: connected/sandbox/not connected/error, last checked, test result, missing owner action | ✅ | `GET /api/staff/providers/status`, `ProviderStatusPanel.jsx` (on `/staff/payments`). Consider also mounting it on `/staff/integrations`. |

### L. Customer-facing quality
| Item | Status |
|---|---|
| Zanelvo brand only, no old names, no dev-progress copy, no competitor tables, no fake testimonials, no lorem, one dominant CTA, DB pricing | ✅ (grep + frontend test) |
| Unsupported statistics | 🟡 — hero mock shows illustrative dashboard numbers; label them "example" if challenged |
| Mobile, accessibility, load speed | 🟡 — not measured this round; run Lighthouse/axe via the frontend testing agent and fix findings |
| Real or clearly labelled demo examples | ✅ ("Example scenario" labels; demo site is a seeded demo org) |
| Home + Pricing "wow" redesign (Round-7 wish) | ❌ — keep CTA rule; use `vision_expert_agent` for imagery |

### M. Verification performed this round
Backend agent Round 8: 21/23 → 23/23 after fixing `deps.py` (iat `<=`); re-verify 5/5 (session invalidation, controls
persistence, public localization gating, public metering, smoke). Frontend agent: 10/10, no console errors.
Covered: auth, reset, invitations API, RBAC (owner→staff 403), invalid ids, rate limits, public abuse, reservations +
reconciliation, plan/global caps, pricing changes, CORS, SSRF, upload limits, secret scan, competitive/provider pages,
language switcher + RTL, home/pricing rules, dashboard smoke.
**Not re-tested this round (rely on earlier rounds → re-run next time):** website generation/editor/publish/rollback,
custom domains, forms, CRM, inbox, staff email, campaigns, automations, bookings/quotes/invoices, payments checkout,
inventory/shipping, AI employees + human takeover, marketing attribution/A-B, accessibility, performance.

### N. Final delivery checklist (state at end of Round 8)
- Preview healthy: yes (URL printed in the final report; changes per import — see §0.1).
- Fresh credentials in `test_credentials.md`: yes (rotated; old ones redacted everywhere).
- Provider status: LLM Live · Email Sandbox · Stripe/PayPal Not connected · Voice Sandbox · Carriers Not connected ·
  Ads Not connected · Domains/SSL Sandbox (DNS verify real).
- Recurring provider cost: LLM only, metered (~$0.003–0.015 per text call; ~$0.04 per image). Everything else $0 until connected.
- Plan-limit behaviour: plan AI budget → 402 `ai_budget_reached` with upgrade hint; founder global cap → 503; pause → 503.
- Cost & margin: `/staff/ai-usage` (demo MRR $0 → margin shown as "—" until real subscriptions).
- No secrets in source/logs/public files: verified by grep (`sk-emergent-`, old passwords) — 0 hits outside `.env`.

---------------------------------------------------------------------------------------------------
## 3. RECOMMENDED ORDER FOR THE NEXT ROUND
---------------------------------------------------------------------------------------------------
1. Regression of the untested areas in §M (backend then frontend) — fix anything broken first.
2. Website: build-from-scratch + template gallery + section regeneration + blog (D).
3. Visual workflow builder + trigger coverage (F) — biggest parity gap with a clear architecture.
4. Commerce: options/barcode, stock reservations, tax config, status history/returns, CSV export (E).
5. Analytics: UTM persistence + funnel/channel reports + AOV/LTV (H).
6. Staff: pricing-history UI, support inbox, error/failed-jobs views, budget warning emails (K/B).
7. SVG sanitiser, chunked uploads, PayPal webhook verification, Redis rate limits (B leftovers).
8. Ads Creative Studio depth (G) — only after F/H, and never with auto-spend.
Always finish a round with: SECOND_RUN_AUDIT.md + CHANGELOG.md + this handoff (rename to ROUND_9) + test_result.md.
