import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { MessageCircle, Phone, ArrowLeft, Send, UserCog, PlayCircle, AlertTriangle, Cpu } from "lucide-react";

function fmtTime(iso) {
    return iso ? new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "";
}

export default function AiConversations() {
    const { convId } = useParams();
    const navigate = useNavigate();
    const [list, setList] = useState([]);
    const [selected, setSelected] = useState(null);
    const [messages, setMessages] = useState([]);
    const [interactions, setInteractions] = useState([]);
    const [reply, setReply] = useState("");
    const [busy, setBusy] = useState(false);
    const scrollRef = useRef(null);

    async function loadList() {
        try {
            const { data } = await api.get("/ai/conversations");
            setList(data.conversations || []);
        } catch { /* ignore */ }
    }
    async function loadConv(id) {
        try {
            const { data } = await api.get(`/ai/conversations/${id}`);
            setSelected(data.conversation);
            setMessages(data.messages || []);
            setInteractions(data.interactions || []);
        } catch { toast.error("Failed to load conversation"); }
    }
    useEffect(() => { loadList(); }, []);
    useEffect(() => { if (convId) loadConv(convId); }, [convId]);
    useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages]);

    async function takeover() {
        try {
            await api.post(`/ai/conversations/${convId}/takeover`, {});
            toast.success("You've taken over — AI paused server-side");
            loadConv(convId); loadList();
        } catch { toast.error("Takeover failed"); }
    }
    async function resume() {
        try {
            await api.post(`/ai/conversations/${convId}/resume`, {});
            toast.success("Resumed — AI is back on");
            loadConv(convId); loadList();
        } catch { toast.error("Resume failed"); }
    }
    async function sendReply() {
        if (!reply.trim()) return;
        setBusy(true);
        try {
            await api.post(`/ai/conversations/${convId}/reply`, { reply });
            setReply("");
            loadConv(convId); loadList();
        } catch { toast.error("Send failed"); } finally { setBusy(false); }
    }

    const costTotal = useMemo(() => (interactions || []).reduce((s, i) => s + (i.cost_cents || 0), 0), [interactions]);

    return (
        <div className="p-6" data-testid="ai-conversations-page">
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Conversations</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Chat + call transcripts</h1>
                    <p className="text-sm text-zinc-500 mt-1">Take over any conversation with one click — AI stops responding, server-side.</p>
                </div>
                <Link to="/app/ai"><Button variant="outline"><ArrowLeft className="w-4 h-4 mr-1" /> AI Employees</Button></Link>
            </div>

            <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
                <aside className="rounded-2xl border border-brand-line bg-white overflow-hidden">
                    <div className="px-4 py-3 border-b border-brand-line text-xs uppercase tracking-widest text-zinc-500">All conversations</div>
                    <div className="divide-y divide-brand-line max-h-[600px] overflow-y-auto" data-testid="conv-list">
                        {list.map((c) => {
                            const active = c.id === convId;
                            return (
                                <button key={c.id} onClick={() => navigate(`/app/ai/conversations/${c.id}`)}
                                     className={`w-full text-left px-4 py-3 hover:bg-brand-cream/40 ${active ? "bg-brand-cream/60" : ""}`}
                                     data-testid={`conv-row-${c.id}`}>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-1 text-xs font-mono text-brand-copper">
                                            {c.channel === "call" ? <Phone className="w-3.5 h-3.5" /> : <MessageCircle className="w-3.5 h-3.5" />}
                                            {c.id.slice(-6)}
                                        </div>
                                        {c.needs_human && <Badge className="bg-amber-100 text-amber-800 text-[10px]">needs human</Badge>}
                                        {c.status === "human" && <Badge className="bg-blue-100 text-blue-800 text-[10px]">human</Badge>}
                                    </div>
                                    <div className="text-xs text-brand-ink mt-1 truncate">{c.visitor_meta?.name || "Anonymous"}</div>
                                    <div className="text-[10px] text-zinc-500 mt-0.5 line-clamp-1">{c.last_message}</div>
                                </button>
                            );
                        })}
                        {!list.length && <div className="p-6 text-xs text-zinc-500 text-center">No conversations yet.</div>}
                    </div>
                </aside>

                <div className="lg:col-span-2">
                    {!convId ? (
                        <div className="rounded-2xl border border-dashed border-brand-line bg-white/50 p-10 text-center text-sm text-zinc-500">
                            Pick a conversation to view.
                        </div>
                    ) : selected ? (
                        <div className="rounded-2xl border border-brand-line bg-white overflow-hidden flex flex-col h-[600px]">
                            <div className="px-4 py-3 border-b border-brand-line flex items-center justify-between flex-wrap gap-2">
                                <div>
                                    <div className="text-sm font-medium text-brand-ink">{selected.visitor_meta?.name || "Anonymous"}</div>
                                    <div className="text-xs text-zinc-500">
                                        {selected.channel === "call" ? "Call" : "Chat"} · started {fmtTime(selected.started_at)}
                                    </div>
                                </div>
                                <div className="flex gap-2 items-center flex-wrap">
                                    <span className="text-[10px] uppercase tracking-widest text-zinc-400" data-testid="conv-cost">${(costTotal / 100).toFixed(2)}</span>
                                    <Badge className={selected.status === "ai" ? "bg-emerald-100 text-emerald-800" :
                                          selected.status === "human" ? "bg-blue-100 text-blue-800" :
                                          selected.status === "needs_human" ? "bg-amber-100 text-amber-800" : "bg-zinc-100 text-zinc-600"} data-testid="conv-status-badge">
                                        {selected.status}
                                    </Badge>
                                    {selected.status !== "human" ? (
                                        <Button size="sm" variant="outline" onClick={takeover} data-testid="conv-takeover-btn">
                                            <UserCog className="w-3.5 h-3.5 mr-1" /> Take over
                                        </Button>
                                    ) : (
                                        <Button size="sm" variant="outline" onClick={resume} data-testid="conv-resume-btn">
                                            <PlayCircle className="w-3.5 h-3.5 mr-1" /> Resume AI
                                        </Button>
                                    )}
                                </div>
                            </div>
                            {selected.needs_human && selected.escalation_reason && (
                                <div className="px-4 py-2 bg-amber-50 border-b border-amber-200 text-amber-900 text-xs flex items-center gap-1" data-testid="conv-escalation-banner">
                                    <AlertTriangle className="w-3.5 h-3.5" /> Escalation reason: {selected.escalation_reason}
                                </div>
                            )}
                            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 bg-brand-surface">
                                {messages.map((m) => (
                                    <div key={m.id} className={`flex ${m.role === "visitor" ? "justify-end" : "justify-start"}`} data-testid={`conv-msg-${m.role}`}>
                                        <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${
                                            m.role === "visitor" ? "bg-brand-ink text-white" :
                                            m.role === "human" ? "bg-blue-100 border border-blue-200 text-blue-900" :
                                            "bg-white border border-brand-line whitespace-pre-wrap"
                                        }`}>
                                            <div className="text-[10px] uppercase tracking-widest text-zinc-400 mb-0.5">{m.role}</div>
                                            {m.content}
                                            {m.citations?.length > 0 && (
                                                <div className="mt-1 text-[10px] text-brand-copper flex flex-wrap gap-1">
                                                    {m.citations.map((c, idx) => <span key={idx} className="rounded bg-brand-cream px-1.5 py-0.5">{c.kind === "structured_facts" ? "✓ facts" : c.kind + ": " + (c.title || "").slice(0, 24)}</span>)}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            {selected.status === "human" && (
                                <form onSubmit={(e) => { e.preventDefault(); sendReply(); }} className="border-t border-brand-line p-2 bg-white flex gap-1.5" data-testid="conv-human-reply-form">
                                    <Input value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Reply as human…" disabled={busy} data-testid="conv-reply-input" />
                                    <Button type="submit" size="sm" disabled={busy || !reply.trim()} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="conv-reply-send-btn">
                                        <Send className="w-4 h-4" />
                                    </Button>
                                </form>
                            )}
                            {/* Audit trail */}
                            {interactions.length > 0 && (
                                <details className="border-t border-brand-line bg-white/60 px-4 py-2 text-xs text-zinc-600">
                                    <summary className="cursor-pointer flex items-center gap-1"><Cpu className="w-3.5 h-3.5" /> Agent audit ({interactions.length} calls · ${(costTotal / 100).toFixed(2)})</summary>
                                    <div className="mt-2 space-y-1 max-h-40 overflow-y-auto">
                                        {interactions.map((i) => (
                                            <div key={i.id} className="flex items-center gap-3 text-[11px] font-mono" data-testid={`audit-row-${i.id}`}>
                                                <span className="text-zinc-400">{fmtTime(i.created_at)}</span>
                                                <span className="text-brand-ink w-16">{i.action}</span>
                                                <span className="text-zinc-500 w-24">{i.model}</span>
                                                <span className="text-zinc-500">{i.total_tokens || 0} tok</span>
                                                <span className="text-zinc-500">{i.latency_ms || 0}ms</span>
                                                <span className="text-zinc-500">${((i.cost_cents || 0) / 100).toFixed(4)}</span>
                                                {i.tools_used?.length ? <span className="text-brand-copper">{i.tools_used.map((t) => t.name).join(",")}</span> : null}
                                            </div>
                                        ))}
                                    </div>
                                </details>
                            )}
                        </div>
                    ) : <div className="p-10 text-zinc-500">Loading…</div>}
                </div>
            </div>
        </div>
    );
}
