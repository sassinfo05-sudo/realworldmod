import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Database, Upload, Search, Trash2, RotateCcw, ImageIcon, FileText, Pencil, X } from "lucide-react";
import {
    usage as getUsage, listAssets, updateAsset, references, trashAsset, restoreAsset,
    purgeAsset, uploadFile, CATEGORIES, humanBytes, apiErr,
} from "@/lib/assets";

export default function AssetLibrary() {
    const [u, setU] = useState(null);
    const [items, setItems] = useState([]);
    const [cat, setCat] = useState("all");
    const [q, setQ] = useState("");
    const [view, setView] = useState("active"); // active | trash | unused
    const [loading, setLoading] = useState(false);
    const [edit, setEdit] = useState(null);
    const fileRef = useRef(null);

    const loadUsage = useCallback(async () => { try { setU(await getUsage()); } catch (e) { /* noop */ } }, []);
    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await listAssets({
                category: cat !== "all" ? cat : undefined, q: q || undefined,
                trashed: view === "trash", unused: view === "unused", page_size: 60,
            });
            setItems(res.assets || []);
        } catch (e) { toast.error(apiErr(e)); }
        setLoading(false);
    }, [cat, q, view]);
    useEffect(() => { loadUsage(); }, [loadUsage]);
    useEffect(() => { load(); }, [load]);

    const doUpload = async (files) => {
        for (const f of files) {
            try { await uploadFile(f, { category: cat !== "all" ? cat : "photo" }); toast.success(`Uploaded ${f.name}`); }
            catch (e) { toast.error(apiErr(e)); }
        }
        load(); loadUsage();
    };

    const onDrop = (e) => { e.preventDefault(); doUpload(Array.from(e.dataTransfer.files || [])); };

    const act = async (fn, id) => { try { await fn(id); load(); loadUsage(); } catch (e) { toast.error(apiErr(e)); } };

    return (
        <div className="max-w-6xl mx-auto p-6 space-y-5" data-testid="asset-library"
             onDragOver={(e) => e.preventDefault()} onDrop={onDrop}>
            <div className="flex items-center justify-between flex-wrap gap-3">
                <h1 className="text-2xl font-semibold flex items-center gap-2"><Database className="w-6 h-6 text-brand-copper" /> Asset Library</h1>
                <div>
                    <input ref={fileRef} type="file" hidden multiple onChange={(e) => doUpload(Array.from(e.target.files || []))} />
                    <Button onClick={() => fileRef.current?.click()} data-testid="upload-btn"><Upload className="w-4 h-4 mr-1" />Upload</Button>
                </div>
            </div>

            {/* storage usage bar */}
            {u && (
                <Card className="p-4" data-testid="storage-usage">
                    <div className="flex items-center justify-between text-sm mb-2">
                        <span className="font-medium">{humanBytes(u.used_bytes)} of {humanBytes(u.limit_bytes)} used ({u.percent}%)</span>
                        <span className="text-zinc-500">Reserved {humanBytes(u.reserved_bytes)} · Trash {humanBytes(u.trashed_bytes)} · Free {humanBytes(u.available_bytes)}</span>
                    </div>
                    <Progress value={Math.min(100, u.percent)} className={u.critical ? "[&>div]:bg-red-500" : u.warn ? "[&>div]:bg-amber-500" : ""} />
                    {u.warn && <p className={`text-xs mt-2 ${u.critical ? "text-red-600" : "text-amber-600"}`}>
                        {u.full ? "Storage full — free space or upgrade to upload more." : u.critical ? "You're running low on storage." : "You've used 70% of your storage."}
                        {" "}<a href="/app/billing" className="underline">Upgrade</a></p>}
                </Card>
            )}

            <div className="flex flex-wrap items-center gap-2">
                <Select value={cat} onValueChange={setCat}>
                    <SelectTrigger className="w-48" data-testid="category-filter"><SelectValue /></SelectTrigger>
                    <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
                <div className="flex rounded-lg border overflow-hidden text-sm">
                    {["active", "unused", "trash"].map((v) => (
                        <button key={v} onClick={() => setView(v)} data-testid={`view-${v}`}
                                className={`px-3 py-1.5 capitalize ${view === v ? "bg-brand-copper text-white" : "bg-transparent"}`}>{v}</button>
                    ))}
                </div>
                <div className="relative flex-1 min-w-[200px]">
                    <Search className="w-4 h-4 absolute left-2.5 top-2.5 text-zinc-400" />
                    <Input className="pl-8" placeholder="Search filename, tag, alt text…" value={q} onChange={(e) => setQ(e.target.value)} data-testid="asset-search" />
                </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
                {items.map((a) => (
                    <Card key={a.id} className="overflow-hidden group relative" data-testid={`asset-${a.id}`}>
                        <div className="aspect-square bg-zinc-50 dark:bg-zinc-800 flex items-center justify-center">
                            {a.media_type === "image"
                                ? <img src={a.url} alt={a.alt_text || ""} className="w-full h-full object-cover" loading="lazy" />
                                : <FileText className="w-10 h-10 text-zinc-400" />}
                        </div>
                        <div className="p-2">
                            <div className="text-xs font-medium truncate">{a.display_name || a.filename}</div>
                            <div className="text-[10px] text-zinc-500">{humanBytes(a.size_bytes)} · {a.category}</div>
                        </div>
                        <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition">
                            {view === "trash" ? (
                                <>
                                    <Button size="icon" variant="secondary" className="h-7 w-7" title="Restore" onClick={() => act(restoreAsset, a.id)}><RotateCcw className="w-3.5 h-3.5" /></Button>
                                    <Button size="icon" variant="destructive" className="h-7 w-7" title="Delete forever" onClick={() => act(purgeAsset, a.id)}><X className="w-3.5 h-3.5" /></Button>
                                </>
                            ) : (
                                <>
                                    <Button size="icon" variant="secondary" className="h-7 w-7" title="Edit" onClick={() => setEdit(a)}><Pencil className="w-3.5 h-3.5" /></Button>
                                    <Button size="icon" variant="secondary" className="h-7 w-7" title="Trash" onClick={() => act(trashAsset, a.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                                </>
                            )}
                        </div>
                    </Card>
                ))}
                {!loading && items.length === 0 && (
                    <div className="col-span-full text-center text-zinc-500 py-12">
                        <ImageIcon className="w-10 h-10 mx-auto mb-2 opacity-40" />
                        <p>{view === "trash" ? "Trash is empty." : "No assets here yet — drag & drop or click Upload."}</p>
                    </div>
                )}
            </div>

            <EditDialog asset={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); load(); }} />
        </div>
    );
}

function EditDialog({ asset, onClose, onSaved }) {
    const [form, setForm] = useState({});
    const [refs, setRefs] = useState(null);
    useEffect(() => {
        if (asset) {
            setForm({ display_name: asset.display_name || "", alt_text: asset.alt_text || "",
                      caption: asset.caption || "", tags: (asset.tags || []).join(", "), category: asset.category });
            references(asset.id).then(setRefs).catch(() => setRefs({ count: 0, references: [] }));
        }
    }, [asset]);
    const save = async () => {
        try {
            await updateAsset(asset.id, {
                display_name: form.display_name, alt_text: form.alt_text, caption: form.caption,
                category: form.category, tags: form.tags.split(",").map((s) => s.trim()).filter(Boolean),
            });
            toast.success("Saved"); onSaved();
        } catch (e) { toast.error(apiErr(e)); }
    };
    return (
        <Dialog open={!!asset} onOpenChange={(o) => !o && onClose()}>
            <DialogContent className="max-w-lg">
                <DialogHeader><DialogTitle>Asset details</DialogTitle></DialogHeader>
                {asset && (
                    <div className="space-y-3">
                        {asset.media_type === "image" && <img src={asset.url} alt="" className="max-h-40 rounded-lg mx-auto" />}
                        <div className="text-xs text-zinc-500">{asset.mime} · {humanBytes(asset.size_bytes)}{asset.width ? ` · ${asset.width}×${asset.height}` : ""}</div>
                        <div><label className="text-sm">Name</label><Input value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} /></div>
                        <div><label className="text-sm">Alt text</label><Input value={form.alt_text} onChange={(e) => setForm({ ...form, alt_text: e.target.value })} data-testid="edit-alt" /></div>
                        <div><label className="text-sm">Caption</label><Input value={form.caption} onChange={(e) => setForm({ ...form, caption: e.target.value })} /></div>
                        <div><label className="text-sm">Tags (comma-separated)</label><Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} /></div>
                        {refs && <div className="text-xs"><Badge variant="outline">Used in {refs.count} place{refs.count === 1 ? "" : "s"}</Badge></div>}
                    </div>
                )}
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Close</Button>
                    <Button onClick={save} data-testid="save-asset-btn">Save</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
