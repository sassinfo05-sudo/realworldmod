"""Thin LLM provider adapter over emergentintegrations.

Design: model name / provider come from config, NOT scattered in feature code.
Later phases will add per-agent model config; the shape here is intentionally minimal.

`emergentintegrations` ships only from the Emergent public CDN wheel index (not PyPI), so it is an
OPTIONAL runtime dependency isolated behind this adapter and imported lazily. The application and its
CI/Docker builds install cleanly from the public `requirements.txt` WITHOUT it; a clear runtime error is
raised only if an LLM call is attempted while the package is absent. Install it in the runtime via
`requirements-emergent.txt` (see that file + SECURITY.md / ENVIRONMENT_VARIABLES.md).
"""
import json
import logging
import re
import time
import uuid
from typing import Any, Dict, Optional

from fastapi import HTTPException

from .. import config

logger = logging.getLogger(__name__)


class LlmError(Exception):
    pass


def _emergent():
    """Lazily import the optional emergentintegrations LLM client. Raises a clear LlmError if the
    package is not installed in this environment (keeps app boot / CI / Docker build independent of the
    private CDN wheel index)."""
    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage
        return LlmChat, UserMessage
    except ImportError as e:  # noqa: BLE001
        raise LlmError(
            "emergentintegrations is not installed in this environment. Install the optional runtime "
            "dependency: pip install -r requirements-emergent.txt "
            "--extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/"
        ) from e


def _new_chat(system_message: str, session_id: Optional[str] = None):
    if not config.EMERGENT_LLM_KEY:
        raise LlmError("EMERGENT_LLM_KEY not configured")
    LlmChat, _UserMessage = _emergent()
    return LlmChat(
        api_key=config.EMERGENT_LLM_KEY,
        session_id=session_id or f"zanelvo-{uuid.uuid4()}",
        system_message=system_message,
    ).with_model(config.LLM_PROVIDER, config.LLM_MODEL)


async def generate_text(system: str, user_text: str, *, feature: Optional[str] = None,
                        idempotency_key: Optional[str] = None, retry_count: int = 0) -> str:
    """Every text call: enforce → reserve → call → settle (or release on failure)."""
    from . import usage

    ctx = usage.get_context()
    feature = feature or ctx.get("feature")
    cached = await usage.find_idempotent(idempotency_key)
    if cached and cached.get("output"):
        await usage.record_usage(kind="text", provider=config.LLM_PROVIDER, model=config.LLM_MODEL,
                                 feature=feature, cache_hit=True, idempotency_key=idempotency_key)
        return cached["output"]
    full_in = (system or "") + "\n" + (user_text or "")
    est = await usage.estimate_cost(kind="text", provider=config.LLM_PROVIDER, model=config.LLM_MODEL,
                                    input_text=full_in)
    await usage.enforce_budget(ctx.get("org_id"), provider=config.LLM_PROVIDER, feature=feature,
                               user_id=ctx.get("user_id"), est_cost=est, public=bool(ctx.get("public")),
                               kind="text")
    res = await usage.reserve(kind="text", provider=config.LLM_PROVIDER, model=config.LLM_MODEL,
                              est_cost=est, feature=feature, idempotency_key=idempotency_key)
    await usage.confirm_reservation(res, org_id=ctx.get("org_id"))
    chat = _new_chat(system)
    _LlmChat, UserMessage = _emergent()
    out = ""
    err = None
    t0 = time.monotonic()
    try:
        out = await chat.send_message(UserMessage(text=user_text))
        if idempotency_key:
            await usage.remember_idempotent(idempotency_key, out)
        return out
    except Exception as e:  # noqa: BLE001
        err = f"{type(e).__name__}: {e}"
        raise
    finally:
        try:
            await usage.settle(
                res, kind="text", provider=config.LLM_PROVIDER, model=config.LLM_MODEL,
                input_text=full_in, output_text=out or "", ok=err is None, error=err,
                latency_ms=int((time.monotonic() - t0) * 1000), retry_count=retry_count,
            )
        except Exception:  # noqa: BLE001
            pass


async def generate_image(prompt: str, session_id: Optional[str] = None,
                          provider: Optional[str] = None, model: Optional[str] = None,
                          feature: Optional[str] = None) -> Optional[str]:
    """Generate one image. Defaults to configured Gemini Nano Banana; provider/model override
    supported (e.g. provider='openai', model='gpt-image-1'). Returns base64 PNG data or None."""
    from . import usage

    if not config.EMERGENT_LLM_KEY:
        raise LlmError("EMERGENT_LLM_KEY not configured")
    ctx = usage.get_context()
    img_provider = provider or config.IMAGE_PROVIDER
    img_model = model or config.IMAGE_MODEL
    feature = feature or ctx.get("feature") or "logo_generation"
    est = await usage.estimate_cost(kind="image", provider=img_provider, model=img_model, images=1)
    await usage.enforce_budget(ctx.get("org_id"), provider=img_provider, feature=feature,
                               user_id=ctx.get("user_id"), est_cost=est, public=bool(ctx.get("public")),
                               kind="image")
    res = await usage.reserve(kind="image", provider=img_provider, model=img_model, est_cost=est,
                              feature=feature)
    await usage.confirm_reservation(res, org_id=ctx.get("org_id"))
    LlmChat, UserMessage = _emergent()
    chat = LlmChat(
        api_key=config.EMERGENT_LLM_KEY,
        session_id=session_id or f"zanelvo-img-{uuid.uuid4()}",
        system_message="You are a world-class brand logo designer.",
    ).with_model(img_provider, img_model).with_params(modalities=["image", "text"])
    err = None
    data = None
    t0 = time.monotonic()
    try:
        _text, images = await chat.send_message_multimodal_response(UserMessage(text=prompt))
        if images:
            data = images[0].get("data")  # base64 string
        return data
    except Exception as e:  # noqa: BLE001
        err = f"{type(e).__name__}: {e}"
        raise
    finally:
        try:
            await usage.settle(
                res, kind="image", provider=img_provider, model=img_model,
                input_text=prompt or "", images=1 if data else 0, image_resolution="1024x1024",
                ok=err is None and data is not None, error=err, feature=feature,
                latency_ms=int((time.monotonic() - t0) * 1000),
            )
        except Exception:  # noqa: BLE001
            pass


_JSON_BLOCK_RE = re.compile(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", re.DOTALL)


def _extract_json(raw: str) -> Any:
    """Extract JSON from possibly fenced or preambled model output. Raise on failure."""
    # 1) try direct parse
    try:
        return json.loads(raw)
    except Exception:
        pass
    # 2) try fenced code block
    m = _JSON_BLOCK_RE.search(raw)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    # 3) heuristic: first { ... last }
    first = raw.find("{")
    last = raw.rfind("}")
    if first != -1 and last != -1 and last > first:
        try:
            return json.loads(raw[first : last + 1])
        except Exception:
            pass
    raise LlmError("Model did not return valid JSON")


async def generate_json(system: str, user_text: str, max_retries: int = 2,
                        feature: Optional[str] = None) -> Dict[str, Any]:
    """Ask the model for JSON. Retries with a stricter reminder on parse failure (retries are metered)."""
    prompt = user_text
    last_err: Optional[str] = None
    for attempt in range(max_retries + 1):
        try:
            raw = await generate_text(system, prompt, feature=feature, retry_count=attempt)
            data = _extract_json(raw)
            if not isinstance(data, dict):
                raise LlmError("Top-level JSON must be an object")
            return data
        except HTTPException:
            raise  # budget / pause / kill-switch decisions are final — never retried
        except Exception as e:  # noqa: BLE001
            last_err = f"{type(e).__name__}: {e}"
            logger.warning("LLM JSON parse failed (attempt %d): %s", attempt + 1, last_err)
            prompt = (
                user_text
                + "\n\nIMPORTANT: Your previous response could not be parsed as JSON. "
                "Return ONLY a single valid JSON object. No prose, no code fences, no explanation."
            )
    raise LlmError(f"LLM failed to produce valid JSON after {max_retries + 1} attempts: {last_err}")
