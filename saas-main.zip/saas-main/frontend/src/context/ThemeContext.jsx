import React, { createContext, useContext, useEffect, useState, useCallback } from "react";

const ThemeContext = createContext(null);
const STORAGE_KEY = "zanelvo.theme"; // 'system' | 'light' | 'dark'

function systemPrefersDark() {
    return typeof window !== "undefined" &&
        window.matchMedia &&
        window.matchMedia("(prefers-color-scheme: dark)").matches;
}

function resolve(mode) {
    if (mode === "dark") return "dark";
    if (mode === "light") return "light";
    return systemPrefersDark() ? "dark" : "light";
}

function apply(effective) {
    const el = document.documentElement;
    if (effective === "dark") el.classList.add("dark");
    else el.classList.remove("dark");
    el.style.colorScheme = effective;
}

export function ThemeProvider({ children }) {
    const [mode, setModeState] = useState(() => localStorage.getItem(STORAGE_KEY) || "system");
    const [effective, setEffective] = useState(() => resolve(localStorage.getItem(STORAGE_KEY) || "system"));

    useEffect(() => {
        const eff = resolve(mode);
        setEffective(eff);
        apply(eff);
    }, [mode]);

    // React to system changes while in 'system' mode.
    useEffect(() => {
        if (!window.matchMedia) return;
        const mq = window.matchMedia("(prefers-color-scheme: dark)");
        const onChange = () => {
            if ((localStorage.getItem(STORAGE_KEY) || "system") === "system") {
                const eff = systemPrefersDark() ? "dark" : "light";
                setEffective(eff);
                apply(eff);
            }
        };
        mq.addEventListener ? mq.addEventListener("change", onChange) : mq.addListener(onChange);
        return () => {
            mq.removeEventListener ? mq.removeEventListener("change", onChange) : mq.removeListener(onChange);
        };
    }, []);

    const setMode = useCallback((m) => {
        localStorage.setItem(STORAGE_KEY, m);
        setModeState(m);
    }, []);

    const toggle = useCallback(() => {
        setMode(resolve(mode) === "dark" ? "light" : "dark");
    }, [mode, setMode]);

    return (
        <ThemeContext.Provider value={{ mode, effective, isDark: effective === "dark", setMode, toggle }}>
            {children}
        </ThemeContext.Provider>
    );
}

export function useTheme() {
    return useContext(ThemeContext) || { mode: "system", effective: "light", isDark: false, setMode: () => {}, toggle: () => {} };
}
