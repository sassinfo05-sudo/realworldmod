"""Managed phone-number platform.

Zanelvo owns the upstream carrier account (Telnyx recommended — cheapest per-min
voice + per-number/mo; Twilio supported as an alternative). Customers browse a
country-filtered catalog of numbers *for sale*, buy through our site, and the
number is instantly provisioned + ownership assigned to their org. Each plan
includes a number of FREE numbers; extra numbers bill monthly at our retail rate
(retail - wholesale = platform profit).

Everything runs in an honest SIMULATED mode until the founder connects a real
carrier (Setup → Integrations, platform `voice`/`messaging` section). When
connected, the exact same endpoints provision REAL numbers.

Per-number voice control: greeting + default messages (voicemail / after-hours /
hold), the AI persona + speaking style, spoken LANGUAGE (the AI answers callers
in that language), call forwarding, SMS auto-reply, and call recording.
"""
from __future__ import annotations

import random
import secrets
from typing import Any, Dict, List, Optional

from ..db import get_db, utc_now_iso

# ---------------------------------------------------------------------------
# Carrier economics (wholesale = what WE pay upstream; retail = what the customer
# pays us / mo for numbers beyond their free allotment). All USD.
# Benchmarked 2026: Telnyx local from ~$1/mo & ~$0.007/min; Twilio ~$1.15/mo &
# ~$0.014/min. We recommend Telnyx as default (cheaper + lower latency).
# ---------------------------------------------------------------------------
CARRIERS: Dict[str, Dict[str, Any]] = {
    "telnyx": {
        "label": "Telnyx", "recommended": True,
        "wholesale_number_month": 1.00, "wholesale_voice_min": 0.007,
        "wholesale_sms": 0.004,
    },
    "twilio": {
        "label": "Twilio", "recommended": False,
        "wholesale_number_month": 1.15, "wholesale_voice_min": 0.014,
        "wholesale_sms": 0.0083,
    },
}
DEFAULT_CARRIER = "telnyx"

# What the customer pays us per extra number / mo, by country tier.
RETAIL_NUMBER_MONTH = 3.00        # local numbers
RETAIL_TOLLFREE_MONTH = 6.00      # toll-free
RETAIL_VOICE_MIN = 0.03           # per AI voice minute (metered)
RETAIL_SMS = 0.02                 # per SMS segment (metered)

# Free numbers bundled with each plan (extra numbers = paid).
PLAN_FREE_NUMBERS = {
    "free": 0, "launch": 0, "revenue": 1, "autopilot": 1, "scale": 3,
}

COUNTRIES: List[Dict[str, Any]] = [
    {"code": "US", "name": "United States", "flag": "🇺🇸", "dial": "+1", "tollfree": True},
    {"code": "CA", "name": "Canada", "flag": "🇨🇦", "dial": "+1", "tollfree": True},
    {"code": "GB", "name": "United Kingdom", "flag": "🇬🇧", "dial": "+44", "tollfree": True},
    {"code": "AU", "name": "Australia", "flag": "🇦🇺", "dial": "+61", "tollfree": True},
    {"code": "DE", "name": "Germany", "flag": "🇩🇪", "dial": "+49", "tollfree": False},
    {"code": "FR", "name": "France", "flag": "🇫🇷", "dial": "+33", "tollfree": False},
    {"code": "ES", "name": "Spain", "flag": "🇪🇸", "dial": "+34", "tollfree": False},
    {"code": "IT", "name": "Italy", "flag": "🇮🇹", "dial": "+39", "tollfree": False},
    {"code": "NL", "name": "Netherlands", "flag": "🇳🇱", "dial": "+31", "tollfree": False},
    {"code": "IE", "name": "Ireland", "flag": "🇮🇪", "dial": "+353", "tollfree": False},
    {"code": "MX", "name": "Mexico", "flag": "🇲🇽", "dial": "+52", "tollfree": False},
    {"code": "BR", "name": "Brazil", "flag": "🇧🇷", "dial": "+55", "tollfree": False},
]
COUNTRY_BY_CODE = {c["code"]: c for c in COUNTRIES}

# Languages the AI receptionist can speak to callers/texters in.
SUPPORTED_LANGUAGES = [
    {"code": "en-US", "name": "English (US)"},
    {"code": "en-GB", "name": "English (UK)"},
    {"code": "es-ES", "name": "Spanish"},
    {"code": "es-MX", "name": "Spanish (Mexico)"},
    {"code": "fr-FR", "name": "French"},
    {"code": "de-DE", "name": "German"},
    {"code": "it-IT", "name": "Italian"},
    {"code": "pt-BR", "name": "Portuguese (Brazil)"},
    {"code": "nl-NL", "name": "Dutch"},
    {"code": "he-IL", "name": "Hebrew"},
    {"code": "ar", "name": "Arabic"},
    {"code": "hi-IN", "name": "Hindi"},
]
LANG_NAME = {l["code"]: l["name"] for l in SUPPORTED_LANGUAGES}

VOICE_PERSONAS = [
    {"id": "friendly_female", "label": "Friendly · Female"},
    {"id": "friendly_male", "label": "Friendly · Male"},
    {"id": "professional_female", "label": "Professional · Female"},
    {"id": "professional_male", "label": "Professional · Male"},
    {"id": "energetic", "label": "Energetic & upbeat"},
    {"id": "calm", "label": "Calm & reassuring"},
]


def default_voice_config(lang: str = "en-US") -> Dict[str, Any]:
    return {
        "enabled": True,
        "persona": "friendly_female",
        "language": lang,
        "speaking_style": "Warm, concise, and helpful. Confirm details back to the caller.",
        "greeting": "Thanks for calling! How can I help you today?",
        "messages": {
            "voicemail": "Sorry we missed you — please leave your name and number and we'll call you right back.",
            "after_hours": "Thanks for calling. We're currently closed, but I can take a message or book you in.",
            "hold": "One moment please while I pull that up.",
        },
        "forwarding": {"enabled": False, "forward_to": "", "ring_seconds": 20},
        "sms_auto_reply": {"enabled": True, "message": "Thanks for texting! How can we help?"},
        "record_calls": False,
        "voicemail_transcription": True,
    }


def carrier_summary() -> List[Dict[str, Any]]:
    out = []
    for cid, c in CARRIERS.items():
        out.append({
            "id": cid, "label": c["label"], "recommended": c["recommended"],
            "wholesale_number_month": c["wholesale_number_month"],
            "wholesale_voice_min": c["wholesale_voice_min"],
            "wholesale_sms": c["wholesale_sms"],
        })
    return out


async def platform_carrier() -> Dict[str, Any]:
    """Which upstream carrier the founder connected (platform-managed), or None.

    We reuse the founder/platform integrations `voice` section. Honest simulated
    mode when not connected.
    """
    from . import integrations as platform_integrations
    try:
        cfg = await platform_integrations.get_raw()  # type: ignore[attr-defined]
    except Exception:
        cfg = None
    provider = None
    connected = False
    if cfg:
        voice = cfg.get("voice") or {}
        provider = voice.get("provider")
        if provider == "twilio":
            connected = bool(voice.get("twilio_account_sid") and voice.get("twilio_auth_token"))
        elif provider == "telnyx":
            connected = bool(voice.get("telnyx_api_key"))
    return {
        "provider": provider if provider not in (None, "none") else DEFAULT_CARRIER,
        "connected": connected,
        "mode": "live" if connected else "simulated",
    }


def _rand_number(country: Dict[str, Any], tollfree: bool = False) -> str:
    dial = country["dial"]
    if tollfree and country["code"] in ("US", "CA"):
        area = random.choice(["800", "833", "844", "855", "888"])
        return f"{dial} {area} {random.randint(200,999)} {random.randint(1000,9999)}"
    if country["code"] in ("US", "CA"):
        return f"{dial} ({random.randint(200,989)}) {random.randint(200,999)}-{random.randint(1000,9999)}"
    return f"{dial} {random.randint(10,99)} {random.randint(100,999)} {random.randint(1000,9999)}"


def generate_catalog(country_code: str, kind: str = "local", limit: int = 12,
                       area_code: str = "") -> List[Dict[str, Any]]:
    """A stable-ish browsable pool of purchasable numbers for a country."""
    country = COUNTRY_BY_CODE.get(country_code)
    if not country:
        return []
    tollfree = kind == "tollfree"
    if tollfree and not country.get("tollfree"):
        return []
    rng = random.Random(f"{country_code}:{kind}:{area_code}")
    numbers = []
    for _ in range(limit):
        # deterministic-ish per seed by consuming rng
        random.seed(rng.random())
        e164 = _rand_number(country, tollfree)
        monthly = RETAIL_TOLLFREE_MONTH if tollfree else RETAIL_NUMBER_MONTH
        numbers.append({
            "catalog_id": secrets.token_hex(6),
            "number": e164,
            "country": country_code,
            "kind": kind,
            "monthly_price": monthly,
            "capabilities": ["voice", "sms"] + (["mms"] if country_code in ("US", "CA") else []),
        })
    return numbers


async def allotment(org_id: str) -> Dict[str, Any]:
    from .entitlements import get_org_plan
    db = get_db()
    plan = await get_org_plan(org_id)
    free = PLAN_FREE_NUMBERS.get(plan, 0)
    owned = await db.phone_numbers.count_documents({"org_id": org_id, "status": {"$ne": "released"}})
    extra = max(0, owned - free)
    return {
        "plan": plan,
        "free_included": free,
        "owned": owned,
        "free_used": min(owned, free),
        "extra_count": extra,
        "monthly_extra_cost": round(extra * RETAIL_NUMBER_MONTH, 2),
        "retail_number_month": RETAIL_NUMBER_MONTH,
        "retail_tollfree_month": RETAIL_TOLLFREE_MONTH,
    }


async def list_numbers(org_id: str) -> List[Dict[str, Any]]:
    db = get_db()
    docs = await db.phone_numbers.find(
        {"org_id": org_id, "status": {"$ne": "released"}}
    ).sort("purchased_at", 1).to_list(200)
    for d in docs:
        d["id"] = str(d.pop("_id"))
    return docs


async def get_number(org_id: str, number_id: str) -> Optional[Dict[str, Any]]:
    from bson import ObjectId
    db = get_db()
    try:
        d = await db.phone_numbers.find_one({"_id": ObjectId(number_id), "org_id": org_id})
    except Exception:
        d = None
    if not d:
        return None
    d["id"] = str(d.pop("_id"))
    return d


async def buy_number(org_id: str, number: str, country: str, kind: str = "local",
                      catalog_id: str = "") -> Dict[str, Any]:
    db = get_db()
    carrier = await platform_carrier()
    allot = await allotment(org_id)
    is_free = allot["owned"] < allot["free_included"]
    monthly = 0.0 if is_free else (RETAIL_TOLLFREE_MONTH if kind == "tollfree" else RETAIL_NUMBER_MONTH)
    doc = {
        "org_id": org_id,
        "number": number,
        "country": country,
        "kind": kind,
        "provider": carrier["provider"],
        "provisioning_mode": carrier["mode"],
        "status": "active" if carrier["mode"] == "live" else "active_simulated",
        "is_free_allotment": is_free,
        "monthly_price": monthly,
        "capabilities": ["voice", "sms"] + (["mms"] if country in ("US", "CA") else []),
        "voice_config": default_voice_config(),
        "purchased_at": utc_now_iso(),
        "provider_number_id": catalog_id or secrets.token_hex(8),
    }
    r = await db.phone_numbers.insert_one(doc)
    doc["id"] = str(r.inserted_id)
    doc.pop("_id", None)
    return doc


async def update_voice_config(org_id: str, number_id: str, patch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    from bson import ObjectId
    db = get_db()
    cur = await get_number(org_id, number_id)
    if not cur:
        return None
    vc = {**default_voice_config(), **(cur.get("voice_config") or {})}
    # deep-merge nested dicts
    for k, v in (patch or {}).items():
        if isinstance(v, dict) and isinstance(vc.get(k), dict):
            vc[k] = {**vc[k], **v}
        else:
            vc[k] = v
    await db.phone_numbers.update_one(
        {"_id": ObjectId(number_id), "org_id": org_id},
        {"$set": {"voice_config": vc, "updated_at": utc_now_iso()}},
    )
    return await get_number(org_id, number_id)


async def release_number(org_id: str, number_id: str) -> bool:
    from bson import ObjectId
    db = get_db()
    try:
        oid = ObjectId(number_id)
    except Exception:
        return False
    r = await db.phone_numbers.update_one(
        {"_id": oid, "org_id": org_id},
        {"$set": {"status": "released", "released_at": utc_now_iso()}},
    )
    return r.modified_count > 0


async def voice_config_for_org(org_id: str) -> Optional[Dict[str, Any]]:
    """Return the primary number's voice_config (used by the voice webhooks)."""
    db = get_db()
    d = await db.phone_numbers.find_one(
        {"org_id": org_id, "status": {"$ne": "released"}, "voice_config.enabled": True}
    )
    return (d or {}).get("voice_config") if d else None


async def voice_config_for_number(number_e164: str) -> Optional[Dict[str, Any]]:
    db = get_db()
    d = await db.phone_numbers.find_one({"number": number_e164, "status": {"$ne": "released"}})
    if d:
        return {"org_id": d["org_id"], "voice_config": d.get("voice_config") or default_voice_config()}
    return None
