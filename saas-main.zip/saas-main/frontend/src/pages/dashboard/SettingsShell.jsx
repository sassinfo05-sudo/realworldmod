import { Outlet, NavLink, useLocation } from "react-router-dom";

const TABS = [
    { to: "/app/settings", label: "Email", end: true, testid: "settings-tab-email" },
    { to: "/app/settings/services", label: "Services", testid: "settings-tab-services" },
    { to: "/app/settings/staff", label: "Staff", testid: "settings-tab-staff" },
    { to: "/app/settings/payments", label: "Payments", testid: "settings-tab-payments" },
];

export default function SettingsShell() {
    return (
        <div data-testid="settings-shell">
            <div className="px-6 pt-6">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Settings</div>
                <h1 className="font-display text-3xl text-brand-ink font-medium">Workspace settings</h1>
                <p className="text-sm text-zinc-500 mt-1">Business email, bookable services, staff and payments.</p>
                <div className="mt-4 flex items-center gap-1 border-b border-brand-line" data-testid="settings-tabs">
                    {TABS.map((t) => (
                        <NavLink
                            key={t.to}
                            to={t.to}
                            end={!!t.end}
                            data-testid={t.testid}
                            className={({ isActive }) =>
                                `px-3 py-2 text-sm border-b-2 -mb-px transition-colors ${
                                    isActive
                                        ? "border-brand-copper text-brand-ink font-medium"
                                        : "border-transparent text-zinc-500 hover:text-brand-ink"
                                }`
                            }
                        >
                            {t.label}
                        </NavLink>
                    ))}
                </div>
            </div>
            <Outlet />
        </div>
    );
}
