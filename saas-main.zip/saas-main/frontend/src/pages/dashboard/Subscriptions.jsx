import React, { useEffect, useState, useCallback } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Repeat, XCircle, RefreshCw, DollarSign } from "lucide-react";

const card = "rounded-2xl border border-brand-line bg-white p-5 shadow-sm";
function money(c, cur = "USD") { return new Intl.NumberFormat(undefined, { style: "currency", currency: cur }).format((c || 0) / 100); }

export default function Subscriptions() {
    const [data, setData] = useState({ subscriptions: [], active: 0, mrr_cents: 0 });
    const [loading, setLoading] = useState(true);
    const load = useCallback(async () => {
        try { const { data } = await api.get("/store/subscriptions"); setData(data); }
        catch { /* empty */ } finally { setLoading(false); }
    }, []);
    useEffect(() => { load(); }, [load]);

    const cancel = async (id) => {
        if (!window.confirm("Cancel this subscription? No further renewals will be charged.")) return;
        try { await api.post(`/store/subscriptions/${id}/cancel`); toast.success("Subscription cancelled"); load(); }
        catch { toast.error("Could not cancel"); }
    };
    const runRenewal = async (id) => {
        try { const { data } = await api.post(`/store/subscriptions/${id}/run-renewal`); toast.success(`Renewed (order ${data.order_id.slice(0, 8)})`); load(); }
        catch (e) { toast.error(e?.response?.data?.detail?.message || e?.response?.data?.detail || "Could not renew"); }
    };

    const subs = data.subscriptions || [];
    return (
        <div className="max-w-4xl mx-auto p-6 space-y-6">
            <div>
                <h1 className="font-display text-2xl text-brand-ink flex items-center gap-2"><Repeat className="w-6 h-6 text-brand-copper" /> Subscriptions</h1>
                <p className="text-brand-ink/60 mt-1 text-sm">Recurring revenue from your subscription products. Renewals run automatically.</p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div className={card}><div className="text-xs uppercase tracking-widest text-zinc-500">Active</div><div className="text-2xl font-display text-brand-ink mt-1" data-testid="subs-active">{data.active || 0}</div></div>
                <div className={card}><div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1"><DollarSign className="w-3 h-3" /> MRR</div><div className="text-2xl font-display text-brand-ink mt-1" data-testid="subs-mrr">{money(data.mrr_cents)}</div></div>
                <div className={card}><div className="text-xs uppercase tracking-widest text-zinc-500">Total</div><div className="text-2xl font-display text-brand-ink mt-1">{subs.length}</div></div>
            </div>
            <div className="space-y-2">
                {loading && <div className={`${card} text-center text-sm text-zinc-400 py-10`}>Loading…</div>}
                {!loading && subs.length === 0 && (
                    <div className={`${card} text-center text-sm text-zinc-400 py-12`} data-testid="subs-empty">
                        No subscriptions yet. Create a product and toggle “Sell as a subscription” to start recurring revenue.
                    </div>
                )}
                {subs.map((s) => (
                    <div key={s.id} className={`${card} flex items-center gap-4`} data-testid={`subs-row-${s.id}`}>
                        <div className="w-10 h-10 rounded-lg bg-brand-copper/10 text-brand-copper flex items-center justify-center"><Repeat className="w-5 h-5" /></div>
                        <div className="flex-1 min-w-0">
                            <div className="font-medium text-brand-ink truncate">{s.product_name}</div>
                            <div className="text-xs text-zinc-500">{money(s.price_cents, s.currency)}/{s.interval === "year" ? "yr" : "mo"} · {s.buyer?.email || "—"} · {s.renewal_count} payment{s.renewal_count === 1 ? "" : "s"}{s.next_renewal_at ? ` · next ${new Date(s.next_renewal_at).toLocaleDateString()}` : ""}</div>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${s.status === "active" ? "bg-emerald-100 text-emerald-700" : s.status === "pending" ? "bg-amber-100 text-amber-700" : "bg-zinc-100 text-zinc-500"}`}>{s.status}</span>
                        {s.status === "active" && (
                            <>
                                <button onClick={() => runRenewal(s.id)} title="Run a renewal now (demo)" className="text-zinc-500 hover:text-brand-copper" data-testid={`subs-renew-${s.id}`}><RefreshCw className="w-4 h-4" /></button>
                                <button onClick={() => cancel(s.id)} title="Cancel" className="text-zinc-500 hover:text-red-500" data-testid={`subs-cancel-${s.id}`}><XCircle className="w-4 h-4" /></button>
                            </>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
}
