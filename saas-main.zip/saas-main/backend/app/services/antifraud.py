"""Lightweight, real anti-fraud checks for signup.

Not a full fraud stack — but real, not simulated:
- Blocks known disposable / throwaway email domains.
- Per-IP signup velocity (in addition to the coarse rate limiter).
- Records a fraud signal document for every rejected attempt so the founder
  can review patterns.

All checks are best-effort and fail-open on infrastructure errors (never block a
legitimate signup because Mongo hiccuped).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Request

from ..db import get_db, utc_now_iso

# A compact, high-signal blocklist of disposable email providers.
DISPOSABLE_DOMAINS = {
    "mailinator.com", "guerrillamail.com", "10minutemail.com", "tempmail.com",
    "temp-mail.org", "throwawaymail.com", "yopmail.com", "getnada.com",
    "trashmail.com", "sharklasers.com", "guerrillamail.info", "grr.la",
    "dispostable.com", "maildrop.cc", "mailnesia.com", "fakeinbox.com",
    "tempmailo.com", "moakt.com", "emailondeck.com", "mohmal.com",
    "spam4.me", "mytemp.email", "tmpmail.org", "burnermail.io",
}

# Max signups allowed from one IP within the window.
_IP_WINDOW_MIN = 60
_IP_MAX_SIGNUPS = 5
# Max signups from one device fingerprint within 24h.
_DEVICE_MAX_SIGNUPS = 3


def _client_ip(request: Optional[Request]) -> Optional[str]:
    if not request:
        return None
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    return request.client.host if request.client else None


def _device_id(request: Optional[Request]) -> Optional[str]:
    return request.headers.get("x-device-id") if request else None


def _user_agent(request: Optional[Request]) -> Optional[str]:
    return (request.headers.get("user-agent") or "")[:300] if request else None


def email_domain(email: str) -> str:
    return email.split("@")[-1].lower().strip() if "@" in email else ""


async def _record_signal(kind: str, email: str, ip: Optional[str], detail: str,
                         device_id: Optional[str] = None, user_agent: Optional[str] = None) -> None:
    try:
        await get_db().fraud_signals.insert_one({
            "kind": kind,
            "email": email,
            "ip": ip,
            "device_id": device_id,
            "user_agent": user_agent,
            "detail": detail,
            "created_at": utc_now_iso(),
        })
    except Exception:  # noqa: BLE001 — never let logging break signup
        pass


async def assess_signup(email: str, request: Optional[Request]) -> None:
    """Raise ValueError(message) if the signup looks fraudulent. Otherwise return."""
    email = (email or "").lower().strip()
    ip = _client_ip(request)
    device_id = _device_id(request)
    user_agent = _user_agent(request)
    domain = email_domain(email)

    # 0) Staff-managed blocklist (Round 11): exact email, email domain, or IP.
    try:
        hits = [{"kind": "email", "value": email}, {"kind": "email_domain", "value": domain}]
        if ip:
            hits.append({"kind": "ip", "value": ip})
        blocked = await get_db().fraud_blocklist.find_one({"$or": hits, "active": True})
        if blocked:
            await _record_signal("blocklist", email, ip, f"{blocked.get('kind')}={blocked.get('value')}", device_id, user_agent)
            await get_db().fraud_blocklist.update_one({"_id": blocked["_id"]}, {"$inc": {"hits": 1}})
            raise ValueError("Sign-ups from this address or network are not allowed. Please contact support.")
    except ValueError:
        raise
    except Exception:  # noqa: BLE001 — fail open on infra errors
        pass

    # 1) Disposable email domains
    if domain in DISPOSABLE_DOMAINS:
        await _record_signal("disposable_email", email, ip, domain, device_id, user_agent)
        raise ValueError(
            "Please sign up with a permanent email address — "
            "disposable inboxes aren't supported."
        )

    # 2) Per-IP velocity
    if ip:
        try:
            since = (datetime.now(timezone.utc) - timedelta(minutes=_IP_WINDOW_MIN))
            since_iso = since.isoformat().replace("+00:00", "Z")
            recent = await get_db().signup_attempts.count_documents({
                "ip": ip, "created_at": {"$gte": since_iso},
            })
            if recent >= _IP_MAX_SIGNUPS:
                await _record_signal("ip_velocity", email, ip, f"{recent} in {_IP_WINDOW_MIN}m", device_id, user_agent)
                raise ValueError(
                    "Too many signups from your network recently. "
                    "Please try again later or contact support."
                )
        except ValueError:
            raise
        except Exception:  # noqa: BLE001 — fail open on infra errors
            pass

    # 3) Per-device velocity (device fingerprint from client)
    if device_id:
        try:
            since = (datetime.now(timezone.utc) - timedelta(hours=24))
            since_iso = since.isoformat().replace("+00:00", "Z")
            recent = await get_db().signup_attempts.count_documents({
                "device_id": device_id, "created_at": {"$gte": since_iso},
            })
            if recent >= _DEVICE_MAX_SIGNUPS:
                await _record_signal("device_velocity", email, ip, f"{recent} in 24h", device_id, user_agent)
                raise ValueError(
                    "This device has created several accounts recently. "
                    "Please contact support if you need another workspace."
                )
        except ValueError:
            raise
        except Exception:  # noqa: BLE001
            pass


async def note_signup_attempt(email: str, request: Optional[Request]) -> None:
    """Record an attempt (used for velocity). Fail-open."""
    try:
        await get_db().signup_attempts.insert_one({
            "email": (email or "").lower().strip(),
            "ip": _client_ip(request),
            "device_id": _device_id(request),
            "user_agent": _user_agent(request),
            "created_at": utc_now_iso(),
        })
    except Exception:  # noqa: BLE001
        pass
