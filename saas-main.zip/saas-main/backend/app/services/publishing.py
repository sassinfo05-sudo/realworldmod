"""Publishing helpers: snapshot draft → published, revisions, rollback, slug management."""
import re
from typing import Optional

from bson import ObjectId

from ..db import get_db, utc_now_iso
from ..models import Revision, Website


def slugify(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return s or "site"


# --- Customer site address rules: zanelvo.com/site/<name> — <name> must be
#     4–12 letters, unique, and never collide with a reserved platform name. ---
RESERVED_SUBDOMAINS = {
    "app", "www", "api", "admin", "administrator", "mail", "email", "smtp", "imap",
    "blog", "help", "helpcenter", "support", "status", "dashboard", "docs", "doc",
    "cdn", "assets", "static", "media", "login", "signup", "signin", "auth", "oauth",
    "billing", "pay", "payment", "payments", "checkout", "store", "shop", "cart",
    "zanelvo", "demo", "test", "testing", "staging", "stage", "dev", "develop",
    "ftp", "ns", "ns1", "ns2", "mx", "webmail", "portal", "account", "accounts",
    "my", "go", "get", "info", "news", "about", "team", "careers", "legal",
    "privacy", "terms", "security", "founder", "owner", "root", "system", "internal",
    "public", "private", "console", "control", "manage", "settings", "setup",
}

SUBDOMAIN_RE = re.compile(r"^[a-z]{4,12}$")


def normalize_subdomain(text: str) -> str:
    """Strip to letters-only, lowercase, capped at 12 chars."""
    return re.sub(r"[^a-z]", "", (text or "").lower())[:12]


def validate_subdomain(sub: str) -> Optional[str]:
    """Return a human error message if invalid, else None."""
    if not sub:
        return "Choose a web address."
    if not SUBDOMAIN_RE.match(sub):
        return "Your address must be 4–12 letters (a–z only) — no spaces, numbers, or symbols."
    if sub in RESERVED_SUBDOMAINS:
        return "That address is reserved. Please choose another."
    return None


async def is_subdomain_available(sub: str, exclude_website_id: Optional[str] = None) -> bool:
    """True if no other website uses this slug now or historically (redirect sources)."""
    db = get_db()
    excl = {"_id": {"$ne": ObjectId(exclude_website_id)}} if exclude_website_id else {}
    if await db.websites.find_one({"slug": sub, **excl}):
        return False
    if await db.websites.find_one({"slug_history": sub, **excl}):
        return False
    return True


async def ensure_unique_slug(base: str, exclude_website_id: Optional[str] = None) -> str:
    db = get_db()
    slug = base
    n = 1
    while True:
        q = {"slug": slug}
        if exclude_website_id:
            q["_id"] = {"$ne": ObjectId(exclude_website_id)}
        existing = await db.websites.find_one(q)
        # also check slug_history so we never reissue a redirect-source
        history = await db.websites.find_one({
            "slug_history": slug,
            **({"_id": {"$ne": ObjectId(exclude_website_id)}} if exclude_website_id else {}),
        })
        if not existing and not history:
            return slug
        n += 1
        slug = f"{base}-{n}"


async def snapshot_publish(website: Website, note: Optional[str], author_user_id: Optional[str]) -> Revision:
    """Copy draft pages/theme/nav_order into `published_*`, write a Revision, and link it."""
    db = get_db()
    revision = Revision(
        org_id=website.org_id,
        website_id=website.id,
        kind="publish",
        theme=website.theme,
        pages=website.pages,
        nav_order=website.nav_order or [p.slug for p in website.pages],
        note=note,
        author_user_id=author_user_id,
    )
    rev_doc = revision.to_mongo()
    res = await db.revisions.insert_one(rev_doc)
    revision.id = str(res.inserted_id)

    await db.websites.update_one(
        {"_id": ObjectId(website.id)},
        {"$set": {
            "published_theme": website.theme.model_dump(),
            "published_pages": [p.model_dump() for p in website.pages],
            "published_nav_order": website.nav_order or [p.slug for p in website.pages],
            "published_at": utc_now_iso(),
            "published_revision_id": revision.id,
            "status": "published",
            "updated_at": utc_now_iso(),
        }},
    )
    return revision


async def rollback_to_revision(website: Website, revision: Revision, author_user_id: Optional[str]) -> Revision:
    """Restore a revision into draft AND published state; record a new Revision (kind='rollback')."""
    db = get_db()
    new_rev = Revision(
        org_id=website.org_id,
        website_id=website.id,
        kind="rollback",
        theme=revision.theme,
        pages=revision.pages,
        nav_order=revision.nav_order,
        note=f"Rolled back to revision {revision.id}",
        author_user_id=author_user_id,
        rolled_back_from_id=revision.id,
    )
    res = await db.revisions.insert_one(new_rev.to_mongo())
    new_rev.id = str(res.inserted_id)

    await db.websites.update_one(
        {"_id": ObjectId(website.id)},
        {"$set": {
            "theme": revision.theme.model_dump(),
            "pages": [p.model_dump() for p in revision.pages],
            "nav_order": revision.nav_order,
            "published_theme": revision.theme.model_dump(),
            "published_pages": [p.model_dump() for p in revision.pages],
            "published_nav_order": revision.nav_order,
            "published_at": utc_now_iso(),
            "published_revision_id": new_rev.id,
            "status": "published",
            "updated_at": utc_now_iso(),
            "draft_updated_at": utc_now_iso(),
        }},
    )
    return new_rev
