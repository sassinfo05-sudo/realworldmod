# INTERNAL — Competitor comparison (never publish on customer-facing pages)
_Source of truth for the Staff → Competitive (internal) page is `backend/app/routes/competitive.py` (MATRIX + POSITIONING). Keep both in sync._

Status legend: live (test-proven) · partial · sandbox (works, provider not connected) · planned · no · n/a

| Area | Capability | Zanelvo | Wix | Shopify | Squarespace | Webflow | GoDaddy Airo |
|---|---|---|---|---|---|---|---|
| Website | AI site generation from interview | live | live | partial | live | partial | live |
| Website | Visual editor w/ drafts, revisions, rollback | partial | live | live | live | live | partial |
| Website | Custom domain + DNS verification + SSL states | partial | live | live | live | live | live |
| Website | Multilingual + RTL (Hebrew) | partial→live switcher | live | live | partial | live | no |
| Commerce | Products/variants/collections/discounts/inventory | live | live | live | live | partial | partial |
| Commerce | Shipping zones/rates/tracking/packing slips | live | live | live | live | partial | partial |
| Commerce | Payments w/ signed idempotent webhooks | sandbox | live | live | live | live | live |
| Commerce | Abandoned-checkout recovery | live | live | live | live | no | partial |
| Bookings/CRM | Bookings + quotes + invoices + jobs native | live | partial | no | partial | no | no |
| Bookings/CRM | CRM w/ lead scoring + unified inbox | live | partial | partial | no | no | no |
| AI | Grounded AI receptionist (chat) | live | partial | partial | no | no | partial |
| AI | AI voice receptionist + managed numbers | sandbox | no | no | no | no | no |
| AI | Human takeover | live | partial | partial | no | no | no |
| AI | Logo generation (SVG + image) | live | live | partial | no | no | live |
| Marketing | Email campaigns w/ opens/clicks/A-B/attribution | live | live | live | live | no | partial |
| Marketing | Visual branching automations | partial | live | live | partial | no | no |
| Marketing | Ads creative studio + export | partial | partial | partial | no | no | partial |
| Platform | Per-tenant AI metering, plan budgets, kill switches, margin | live | n/a | n/a | n/a | n/a | n/a |
| Platform | Staff panel, impersonation audit, fraud view | live | n/a | n/a | n/a | n/a | n/a |
| Platform | Public API keys + signed webhooks | live | live | live | partial | live | no |
| Pricing | Entry paid plan (public list, USD/mo, research date this run) | DB-driven | $17 | $39 | $16 | $14 | $10 |

## Positioning
Zanelvo = AI website + bookings/quotes/invoices + commerce/shipping + AI receptionist (chat/voice) + marketing attribution, in ONE metered, margin-aware platform for small service businesses and shops.

**Win:** native service-business ops, AI employees with honest takeover and cost caps, founder economics, truthful integration states.
**Lag:** editor depth, commerce long tail, visual automation builder, live provider connections (sandbox until keys).

## Rules
- No competitor names/tables on public pages (BRAND_SCREEN.md).
- Re-check competitor prices the same day before quoting anywhere.
- Mark Zanelvo cells `live` only with a passing test.
