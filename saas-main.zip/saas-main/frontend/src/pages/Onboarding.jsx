import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { useBrand } from "@/context/BrandContext";
import { Wordmark } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowRight, ArrowLeft, Check } from "lucide-react";
import { toast } from "sonner";

function IndustryPicker({ value, onChange }) {
    const [industries, setIndustries] = useState([]);
    useEffect(() => { api.get("/industries").then((r) => setIndustries(r.data)); }, []);
    return (
        <div className="grid sm:grid-cols-2 gap-3" data-testid="industry-picker">
            {industries.map((it) => {
                const active = value === it.key;
                return (
                    <button
                        type="button"
                        key={it.key}
                        onClick={() => onChange(it.key)}
                        data-testid={`industry-${it.key}`}
                        className={`text-left rounded-xl border p-4 transition-all ${
                            active
                                ? "border-brand-copper bg-brand-cream/60 ring-1 ring-brand-copper/30"
                                : "border-brand-line bg-white hover:border-zinc-300"
                        }`}
                    >
                        <div className="font-medium text-brand-ink">{it.label}</div>
                        {it.examples && (
                            <div className="mt-1 text-xs text-zinc-500">{it.examples}</div>
                        )}
                    </button>
                );
            })}
        </div>
    );
}

function ChoiceGroup({ options, value, onChange, testidPrefix }) {
    return (
        <div className="grid sm:grid-cols-2 gap-3">
            {options.map((o) => {
                const active = value === o.value;
                return (
                    <button
                        type="button"
                        key={o.value}
                        onClick={() => onChange(o.value)}
                        data-testid={`${testidPrefix}-${o.value}`}
                        className={`text-left rounded-xl border p-4 transition-all ${
                            active
                                ? "border-brand-copper bg-brand-cream/60 ring-1 ring-brand-copper/30"
                                : "border-brand-line bg-white hover:border-zinc-300"
                        }`}
                    >
                        <div className="font-medium text-brand-ink">{o.label}</div>
                        {o.note && <div className="mt-1 text-xs text-zinc-500">{o.note}</div>}
                    </button>
                );
            })}
        </div>
    );
}

function MultiGroup({ options, values = [], onChange, testidPrefix }) {
    function toggle(v) {
        const set = new Set(values);
        if (set.has(v)) set.delete(v); else set.add(v);
        onChange(Array.from(set));
    }
    return (
        <div className="grid sm:grid-cols-2 gap-3">
            {options.map((o) => {
                const active = values.includes(o.value);
                return (
                    <button
                        type="button"
                        key={o.value}
                        onClick={() => toggle(o.value)}
                        data-testid={`${testidPrefix}-${o.value}`}
                        className={`flex items-center justify-between rounded-xl border p-4 transition-all ${
                            active
                                ? "border-brand-copper bg-brand-cream/60"
                                : "border-brand-line bg-white hover:border-zinc-300"
                        }`}
                    >
                        <span className="font-medium text-brand-ink">{o.label}</span>
                        {active && <Check className="w-4 h-4 text-brand-copper" />}
                    </button>
                );
            })}
        </div>
    );
}

function ContactBlock({ answers, onPatch }) {
    return (
        <div className="space-y-4">
            <div>
                <Label htmlFor="contact-email">Email</Label>
                <Input
                    id="contact-email"
                    type="email"
                    value={answers.contact_email || ""}
                    onChange={(e) => onPatch("contact_email", e.target.value)}
                    className="mt-1"
                    data-testid="answer-contact-email"
                />
            </div>
            <div>
                <Label htmlFor="contact-phone">Phone (optional)</Label>
                <Input
                    id="contact-phone"
                    value={answers.contact_phone || ""}
                    onChange={(e) => onPatch("contact_phone", e.target.value)}
                    className="mt-1"
                    data-testid="answer-contact-phone"
                />
            </div>
        </div>
    );
}

export default function Onboarding() {
    const [steps, setSteps] = useState([]);
    const [answers, setAnswers] = useState({});
    const [index, setIndex] = useState(0);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const brand = useBrand();
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                const [s, sess] = await Promise.all([
                    api.get("/onboarding/steps"),
                    api.get("/onboarding/session"),
                ]);
                setSteps(s.data.steps);
                setAnswers(sess.data.answers || {});
                setIndex(sess.data.step_index || 0);
            } catch (err) {
                toast.error("Failed to load interview");
            } finally {
                setLoading(false);
            }
        })();
    }, []);

    const step = steps[index];
    const total = steps.length;
    const progress = useMemo(() => (total ? Math.round(((index) / total) * 100) : 0), [index, total]);

    async function patchAnswer(field, value) {
        setAnswers((a) => ({ ...a, [field]: value }));
        try {
            await api.patch("/onboarding/session/answer", { field, value, step_index: index });
        } catch (err) {
            // silent on transient network hiccups is fine, but surface auth errors
            if (err?.response?.status === 401) {
                toast.error("Your session expired. Please log in again.");
            }
        }
    }

    function isStepValid(s) {
        if (!s) return false;
        if (!s.required) return true;
        if (s.kind === "contact") return !!(answers.contact_email && String(answers.contact_email).includes("@"));
        if (s.kind === "multi") return (answers[s.field] || []).length > 0;
        const val = answers[s.field];
        return typeof val === "string" ? val.trim().length > 0 : !!val;
    }

    async function next() {
        if (!isStepValid(step)) {
            toast.error("Please answer this before continuing.");
            return;
        }
        if (index < total - 1) {
            setIndex(index + 1);
            await api.patch("/onboarding/session/answer", { field: step.field, value: answers[step.field], step_index: index + 1 }).catch(() => {});
            return;
        }
        // last step: kick off generation
        setSaving(true);
        try {
            await api.post("/onboarding/generate");
            navigate("/generating");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Generation failed to start");
        } finally {
            setSaving(false);
        }
    }

    function back() {
        if (index > 0) setIndex(index - 1);
    }

    if (loading) {
        return (
            <div className="min-h-screen bg-brand-surface flex items-center justify-center">
                <div className="text-zinc-500">Loading your interview…</div>
            </div>
        );
    }

    if (!step) return null;

    return (
        <div className="min-h-screen bg-brand-surface" data-testid="onboarding-page">
            <div className="border-b border-brand-line bg-white">
                <div className="mx-auto max-w-3xl px-6 h-16 flex items-center justify-between">
                    <Wordmark />
                    <div className="text-xs text-zinc-500 font-mono uppercase tracking-widest">
                        Step {index + 1} of {total}
                    </div>
                </div>
                <div className="h-1 bg-brand-line">
                    <div className="h-full bg-brand-copper transition-all duration-500" style={{ width: `${progress}%` }} />
                </div>
            </div>

            <main className="mx-auto max-w-2xl px-6 py-14">
                <div className="text-xs uppercase tracking-[0.24em] text-brand-copper mb-3">
                    {brand?.name || "Zanelvo"} interview
                </div>
                <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium leading-tight"
                    data-testid="step-title">
                    {step.title}
                </h1>
                {step.hint && (
                    <p className="mt-2 text-zinc-600" data-testid="step-hint">{step.hint}</p>
                )}

                <div className="mt-8" data-testid={`step-${step.id}`}>
                    {step.kind === "text" && (
                        <Input
                            value={answers[step.field] || ""}
                            onChange={(e) => patchAnswer(step.field, e.target.value)}
                            placeholder={step.placeholder}
                            className="text-lg py-6"
                            data-testid={`answer-${step.field}`}
                            autoFocus
                        />
                    )}
                    {step.kind === "textarea" && (
                        <Textarea
                            value={answers[step.field] || ""}
                            onChange={(e) => patchAnswer(step.field, e.target.value)}
                            placeholder={step.placeholder}
                            rows={7}
                            className="text-base"
                            data-testid={`answer-${step.field}`}
                            autoFocus
                        />
                    )}
                    {step.kind === "industry" && (
                        <IndustryPicker
                            value={answers[step.field]}
                            onChange={(v) => patchAnswer(step.field, v)}
                        />
                    )}
                    {step.kind === "choice" && (
                        <ChoiceGroup
                            options={step.options}
                            value={answers[step.field]}
                            onChange={(v) => patchAnswer(step.field, v)}
                            testidPrefix={`answer-${step.field}`}
                        />
                    )}
                    {step.kind === "multi" && (
                        <MultiGroup
                            options={step.options}
                            values={answers[step.field] || []}
                            onChange={(v) => patchAnswer(step.field, v)}
                            testidPrefix={`answer-${step.field}`}
                        />
                    )}
                    {step.kind === "contact" && (
                        <ContactBlock answers={answers} onPatch={patchAnswer} />
                    )}
                </div>

                <div className="mt-10 flex items-center justify-between">
                    <Button
                        type="button"
                        variant="ghost"
                        onClick={back}
                        disabled={index === 0}
                        data-testid="onboarding-back"
                    >
                        <ArrowLeft className="w-4 h-4 mr-1" /> Back
                    </Button>
                    <Button
                        type="button"
                        onClick={next}
                        disabled={saving}
                        className="bg-brand-copper hover:bg-brand-copperHover text-white"
                        data-testid="onboarding-next"
                    >
                        {index === total - 1 ? (saving ? "Starting…" : "Generate my site") : "Continue"}
                        <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                </div>
            </main>
        </div>
    );
}
