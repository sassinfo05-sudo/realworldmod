"""Professional HTML email templates + transactional automation registry.

- `render(template_key, brand, variables)` -> {subject, html, text}
- `AUTOMATIONS` -> the catalog of auto-emails wired to platform events, each with
  a from-role (resolved to a real From address via platform_settings.email_for)
  and the template it uses.
- `send_transactional(kind, to, variables, to_name)` renders + sends via
  platform_mail (honest simulated mode until a provider is connected) and logs
  a rich entry to db.system_mail_log.

Every send is logged so the staff panel can show sent logs.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from ..db import get_db, utc_now_iso
from . import platform_mail
from . import platform_settings as ps

# --- automation catalog: event -> {from role, template, subject, description} ---
AUTOMATIONS: Dict[str, Dict[str, str]] = {
    "welcome": {"role": "marketing", "template": "welcome", "default_on": True,
                 "label": "Welcome email", "when": "New account created",
                 "desc": "Warm welcome from hello@ with first steps."},
    "verify_email": {"role": "noreply", "template": "verify", "default_on": True,
                      "label": "Email verification", "when": "Signup / email change",
                      "desc": "Sends a verification link/code from no-reply@."},
    "twofa_code": {"role": "twofa", "template": "code", "default_on": True,
                    "label": "2FA / login code", "when": "Login step-up",
                    "desc": "One-time security code from security@."},
    "password_reset": {"role": "twofa", "template": "reset", "default_on": True,
                        "label": "Password reset", "when": "Reset requested",
                        "desc": "Secure reset link from security@."},
    "security_alert": {"role": "twofa", "template": "security_alert", "default_on": True,
                        "label": "Security alert", "when": "New device / suspicious login",
                        "desc": "Notifies the user of new-device sign-ins from security@."},
    "receipt": {"role": "billing", "template": "receipt", "default_on": True,
                 "label": "Payment receipt", "when": "Successful charge",
                 "desc": "Itemised receipt from billing@."},
    "payment_failed": {"role": "billing", "template": "payment_failed", "default_on": True,
                        "label": "Payment failed", "when": "Charge declined",
                        "desc": "Dunning notice + update-card link from billing@."},
    "trial_ending": {"role": "billing", "template": "trial_ending", "default_on": True,
                      "label": "Trial ending", "when": "3 days before trial ends",
                      "desc": "Reminder to pick a plan from billing@."},
    "support_reply": {"role": "support", "template": "support_reply", "default_on": True,
                       "label": "Support reply", "when": "Agent replies in inbox",
                       "desc": "Threaded reply sent from support@."},
}

# --- shared HTML shell ---
BRAND_GRADIENT = "linear-gradient(135deg,#4F46E5 0%,#D6289B 55%,#F59E0B 100%)"

_SHELL = """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>{subject}</title></head>
<body style="margin:0;padding:0;background:#f4f4f7;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#15151b;-webkit-font-smoothing:antialiased;">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;font-size:1px;line-height:1px;color:#f4f4f7;">{preheader}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f7;">
<tr><td align="center" style="padding:32px 16px;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;">
    <tr><td style="padding:0 4px 20px;">
      <table role="presentation" cellpadding="0" cellspacing="0"><tr>
        <td style="vertical-align:middle;">
          <span style="display:inline-block;width:30px;height:30px;border-radius:9px;background:#4F46E5;background-image:{gradient};vertical-align:middle;"></span>
        </td>
        <td style="vertical-align:middle;padding-left:10px;">
          <span style="font-size:19px;font-weight:700;letter-spacing:-0.02em;color:#15151b;">{brand}</span>
        </td>
      </tr></table>
    </td></tr>
    <tr><td>
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ffffff;border:1px solid #ececf1;border-radius:18px;overflow:hidden;box-shadow:0 8px 30px rgba(20,20,40,0.06);">
        <tr><td style="height:4px;background:#4F46E5;background-image:{gradient};font-size:0;line-height:0;">&nbsp;</td></tr>
        <tr><td style="padding:36px 36px 32px;">{body}</td></tr>
      </table>
    </td></tr>
    <tr><td style="padding:22px 8px 0;text-align:center;color:#9a9aa4;font-size:12px;line-height:1.7;">
      {footer}<br>
      <a href="{product_url}" style="color:#8a8a95;text-decoration:none;">{product_url_label}</a>
      &nbsp;·&nbsp;<a href="mailto:{support_email}" style="color:#8a8a95;text-decoration:none;">{support_email}</a><br>
      <span style="color:#b5b5be;">&copy; {year} {company}. All rights reserved.</span>
    </td></tr>
  </table>
</td></tr></table>
</body></html>"""

_BTN = ('<table role="presentation" cellpadding="0" cellspacing="0" style="margin:20px 0 8px;"><tr>'
        '<td style="border-radius:11px;background:#4F46E5;background-image:{gradient};">'
        '<a href="{url}" style="display:inline-block;color:#ffffff;text-decoration:none;'
        'padding:13px 30px;border-radius:11px;font-weight:600;font-size:15px;">{label}&nbsp;&rarr;</a>'
        '</td></tr></table>').replace("{gradient}", BRAND_GRADIENT)

_H = '<h1 style="font-size:24px;line-height:1.25;margin:0 0 14px;font-weight:700;letter-spacing:-0.02em;color:#15151b;">{t}</h1>'
_P = '<p style="font-size:15px;line-height:1.7;color:#43434d;margin:0 0 16px;">{t}</p>'
_MUTED = '<p style="font-size:13px;line-height:1.6;color:#8a8a95;margin:16px 0 0;">{t}</p>'
_DIVIDER = '<div style="height:1px;background:#ececf1;margin:24px 0;"></div>'
_CODE = ('<div style="font-size:34px;letter-spacing:10px;font-weight:700;text-align:center;color:#15151b;'
         'background:#f7f5ff;border:1px dashed #c9c2f0;border-radius:14px;padding:20px;margin:18px 0;">{code}</div>')
_INFO = ('<div style="background:#f7f5ff;border:1px solid #e7e3fb;border-radius:12px;padding:14px 16px;margin:16px 0;'
         'font-size:14px;line-height:1.6;color:#43434d;">{t}</div>')


def _v(variables: Dict[str, Any], key: str, default: str = "") -> str:
    val = variables.get(key, default)
    return "" if val is None else str(val)


def _body_for(template: str, brand: str, product_url: str, v: Dict[str, Any]) -> Dict[str, str]:
    """Return {subject, body_html} for a template."""
    name = _v(v, "name", "there")
    if template == "welcome":
        return {"subject": f"Welcome to {brand} — let's build something great", "preheader":
                f"Your {brand} workspace is ready. Here's how to launch in minutes.", "body": (
            _H.format(t=f"Welcome aboard, {name}!") +
            _P.format(t=f"Your {brand} account is ready. In just a few minutes you can have a real website, online store, bookings and an AI receptionist — all working together in one place.") +
            _BTN.format(url=product_url + "/app", label="Open my dashboard") +
            _INFO.format(t="<b>Your first 5 minutes:</b> answer a few questions, watch your site build itself, then publish. That's it.") +
            _MUTED.format(t="Need a hand? Just reply to this email — a real human will help."))}
    if template == "verify":
        return {"subject": f"Confirm your email · {brand}", "preheader":
                "One quick tap to verify your email and secure your account.", "body": (
            _H.format(t="Confirm your email") +
            _P.format(t="Tap the button below to verify your email address and finish securing your account.") +
            _BTN.format(url=_v(v, "verify_url", product_url), label="Verify email") +
            (_INFO.format(t=f"Prefer a code? Use <b>{_v(v,'code')}</b>") if v.get("code") else "") +
            _MUTED.format(t="If you didn't create this account, you can safely ignore this email."))}
    if template == "code":
        return {"subject": f"{_v(v,'code','Your code')} is your {brand} code", "preheader":
                "Your one-time sign-in code (expires in 10 minutes).", "body": (
            _H.format(t="Your one-time code") +
            _P.format(t="Use this code to finish signing in. It expires in 10 minutes.") +
            _CODE.format(code=_v(v, "code", "------")) +
            _MUTED.format(t="Didn't try to sign in? You can safely ignore this email — your account is still secure."))}
    if template == "reset":
        return {"subject": f"Reset your {brand} password", "preheader":
                "Choose a new password — this secure link expires in 30 minutes.", "body": (
            _H.format(t="Reset your password") +
            _P.format(t="We received a request to reset your password. Click below to choose a new one. This link expires in 30 minutes.") +
            _BTN.format(url=_v(v, "reset_url", product_url), label="Choose a new password") +
            _MUTED.format(t="Didn't request this? No action is needed and your password stays the same."))}
    if template == "security_alert":
        return {"subject": f"New sign-in to your {brand} account", "preheader":
                "We noticed a sign-in from a new device.", "body": (
            _H.format(t="New device signed in") +
            _P.format(t=f"We noticed a sign-in from a new device{(' — ' + _v(v,'device')) if v.get('device') else ''}{(' in ' + _v(v,'location')) if v.get('location') else ''}.") +
            _INFO.format(t="<b>Was this you?</b> Great — no action needed. <b>Not you?</b> Secure your account right away.") +
            _BTN.format(url=product_url + "/app/account", label="Review account security"))}
    if template == "receipt":
        amount = _v(v, "amount", "0.00")
        return {"subject": f"Receipt from {brand} — ${amount}", "preheader":
                f"Thanks for your payment of ${amount}.", "body": (
            _H.format(t="Payment received") +
            _P.format(t=f"Thanks{(', ' + name) if name != 'there' else ''}! We've received your payment. Here's your receipt.") +
            f'<table role="presentation" style="width:100%;font-size:14px;border-collapse:collapse;margin:8px 0 4px;">'
            f'<tr><td style="padding:10px 0;color:#6a6a72;">{_v(v,"item","Subscription")}</td>'
            f'<td style="padding:10px 0;text-align:right;font-weight:600;">${amount}</td></tr>'
            f'<tr><td style="padding:12px 0;border-top:1px solid #ececf1;font-weight:600;">Total paid</td>'
            f'<td style="padding:12px 0;border-top:1px solid #ececf1;text-align:right;font-weight:700;font-size:16px;">${amount}</td></tr></table>' +
            _BTN.format(url=product_url + "/app/billing", label="View billing"))}
    if template == "payment_failed":
        return {"subject": f"Action needed: your {brand} payment didn't go through", "preheader":
                "Update your card to keep your account active.", "body": (
            _H.format(t="We couldn't process your payment") +
            _P.format(t="Your latest payment was declined — this usually just means an expired or maxed-out card. Update your payment method to keep everything running.") +
            _BTN.format(url=product_url + "/app/billing", label="Update payment method") +
            _MUTED.format(t="We'll automatically retry over the next few days, so there's no rush — but sooner is safer."))}
    if template == "trial_ending":
        return {"subject": f"Your {brand} trial ends in {_v(v,'days','3')} days", "preheader":
                "Pick a plan to keep your site, store and AI running.", "body": (
            _H.format(t="Your trial is ending soon") +
            _P.format(t=f"Your free trial ends in {_v(v,'days','3')} days. Choose a plan now to keep your website, store, bookings and AI employees running without any interruption.") +
            _BTN.format(url=product_url + "/pricing", label="Choose a plan") +
            _MUTED.format(t="Questions about which plan fits? Just reply — we're happy to help you pick."))}
    if template == "support_reply":
        return {"subject": _v(v, "subject", f"Re: your message · {brand}"), "body": (
            _P.format(t=_v(v, "message", "")))}
    # generic
    return {"subject": _v(v, "subject", brand), "body": _P.format(t=_v(v, "message", ""))}


async def render(template: str, variables: Dict[str, Any]) -> Dict[str, str]:
    s = await ps.get_settings()
    brand = s.get("brand_name", "Zanelvo")
    product_url = (s.get("product_url") or "https://zanelvo.com").rstrip("/")
    company = s.get("company_name", brand)
    support_email = s.get("support_email") or f"support@{brand.lower()}.com"
    footer = s.get("footer_note") or f"You're receiving this because you have a {brand} account."
    parts = _body_for(template, brand, product_url, variables or {})
    preheader = parts.get("preheader") or parts["subject"]
    product_url_label = product_url.replace("https://", "").replace("http://", "")
    html = _SHELL.format(
        subject=parts["subject"], preheader=preheader, gradient=BRAND_GRADIENT,
        brand=brand, body=parts["body"], footer=footer,
        product_url=product_url, product_url_label=product_url_label,
        support_email=support_email, year=utc_now_iso()[:4], company=company,
    )
    # crude text fallback
    import re
    text = re.sub(r"<[^>]+>", " ", parts["body"])
    text = re.sub(r"\s+", " ", text).strip()
    return {"subject": parts["subject"], "html": html, "text": text}


async def automation_state() -> Dict[str, bool]:
    db = get_db()
    doc = await db.email_automations.find_one({"key": "primary"}) or {}
    overrides = doc.get("states") or {}
    return {k: bool(overrides.get(k, meta["default_on"])) for k, meta in AUTOMATIONS.items()}


async def set_automation(kind: str, enabled: bool) -> Dict[str, bool]:
    db = get_db()
    if kind not in AUTOMATIONS:
        raise ValueError("unknown automation")
    await db.email_automations.update_one(
        {"key": "primary"}, {"$set": {f"states.{kind}": bool(enabled), "updated_at": utc_now_iso()}},
        upsert=True)
    return await automation_state()


async def send_transactional(kind: str, to: str, variables: Optional[Dict[str, Any]] = None,
                              to_name: str = "") -> Dict[str, Any]:
    """Fire an automated transactional email if that automation is enabled."""
    meta = AUTOMATIONS.get(kind)
    if not meta:
        return {"ok": False, "error": f"unknown automation {kind}", "skipped": True}
    states = await automation_state()
    if not states.get(kind, meta["default_on"]):
        return {"ok": False, "skipped": True, "reason": "automation disabled"}
    rendered = await render(meta["template"], variables or {})
    result = await platform_mail.send(role=meta["role"], to=to, subject=rendered["subject"],
                                      text=rendered["text"], html=rendered["html"])
    # enrich the most-recent log row with kind/template so the panel can show it
    try:
        db = get_db()
        await db.system_mail_log.update_one(
            {"role": meta["role"], "to": to, "subject": rendered["subject"]},
            {"$set": {"kind": kind, "template": meta["template"], "to_name": to_name,
                      "direction": "outbound"}},
            sort=[("created_at", -1)]) if False else None
        # simpler: insert a dedicated rich row is already done by platform_mail.send;
        # we tag by updating the newest matching row.
        newest = await db.system_mail_log.find_one(
            {"role": meta["role"], "to": to, "subject": rendered["subject"]}, sort=[("created_at", -1)])
        if newest:
            await db.system_mail_log.update_one({"_id": newest["_id"]},
                {"$set": {"kind": kind, "template": meta["template"], "to_name": to_name, "direction": "outbound"}})
    except Exception:  # noqa: BLE001
        pass
    return result
