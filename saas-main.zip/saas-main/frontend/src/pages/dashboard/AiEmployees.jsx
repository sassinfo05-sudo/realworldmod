import InsightsDashboard from "@/components/InsightsDashboard";
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Bot, Phone, MessageCircle, Sparkles, ShieldAlert, Cpu, ArrowRight, Activity, DollarSign, Users2 } from "lucide-react";

const AGENT_ICON = {
    receptionist: MessageCircle,
    sales: Sparkles,
    reactivation: Users2,
    support: ShieldAlert,
    admin: Cpu,
};

function AiEmployeesBase() {
    const [agents, setAgents] = useState([]);
    const [killSwitch, setKillSwitch] = useState({ ai_enabled: true });
    const [usage, setUsage] = useState({ total: {}, per_agent: [] });
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    async function load() {
        setLoading(true);
        try {
            const [a, k, u] = await Promise.all([
                api.get("/ai/agents"),
                api.get("/ai/kill-switch"),
                api.get("/ai/usage?days=30").catch(() => ({ data: { total: {}, per_agent: [] } })),
            ]);
            setAgents(a.data.agents || []);
            setKillSwitch(k.data);
            setUsage(u.data);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    async function toggleAgent(id, enabled) {
        try {
            await api.patch(`/ai/agents/${id}`, { enabled });
            toast.success(enabled ? "Agent enabled" : "Agent paused");
            load();
        } catch { toast.error("Update failed"); }
    }
    async function toggleKillSwitch() {
        try {
            const next = !killSwitch.ai_enabled;
            await api.put("/ai/kill-switch", { ai_enabled: next, reason: next ? null : "Owner disabled from dashboard" });
            toast.success(next ? "AI enabled" : "AI paused for the whole org");
            load();
        } catch { toast.error("Update failed"); }
    }

    const usageByAgent = useMemo(() => Object.fromEntries((usage.per_agent || []).map((a) => [a.id, a])), [usage]);

    return (
        <div className="p-6" data-testid="ai-employees-page">
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">AI Employees</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Your AI team</h1>
                    <p className="text-sm text-zinc-500 mt-1 max-w-2xl">
                        Five agents, each grounded on your actual services, hours and policies.
                        They never invent facts and always cite their sources.
                    </p>
                </div>
                <Link to="/app/knowledge">
                    <Button variant="outline" data-testid="link-knowledge-btn">
                        Knowledge base <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                </Link>
            </div>

            {/* Master kill switch */}
            <div className={`mt-6 rounded-2xl border-2 p-4 flex items-center justify-between gap-4 flex-wrap ${killSwitch.ai_enabled ? "border-emerald-200 bg-emerald-50/40" : "border-red-300 bg-red-50/60"}`} data-testid="kill-switch-card">
                <div className="flex items-center gap-3">
                    <Bot className={`w-5 h-5 ${killSwitch.ai_enabled ? "text-emerald-700" : "text-red-700"}`} />
                    <div>
                        <div className="font-medium text-brand-ink">Master AI kill switch</div>
                        <div className="text-xs text-zinc-600">
                            {killSwitch.ai_enabled
                                ? "All enabled agents are live and responding."
                                : `AI is paused for the whole org${killSwitch.reason ? ` — ${killSwitch.reason}` : ""}. Chat widget falls back to a contact form message.`}
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-xs uppercase tracking-widest text-zinc-500">{killSwitch.ai_enabled ? "Live" : "Paused"}</span>
                    <Switch checked={killSwitch.ai_enabled} onCheckedChange={toggleKillSwitch} data-testid="kill-switch-toggle" />
                </div>
            </div>

            {/* Usage totals */}
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="rounded-xl border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1"><Activity className="w-3.5 h-3.5" /> Interactions (30d)</div>
                    <div className="text-2xl font-mono text-brand-ink mt-1" data-testid="usage-interactions">{usage.total?.interactions || 0}</div>
                </div>
                <div className="rounded-xl border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1"><Cpu className="w-3.5 h-3.5" /> Tokens</div>
                    <div className="text-2xl font-mono text-brand-ink mt-1" data-testid="usage-tokens">{(usage.total?.tokens || 0).toLocaleString()}</div>
                </div>
                <div className="rounded-xl border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1"><DollarSign className="w-3.5 h-3.5" /> Est. cost</div>
                    <div className="text-2xl font-mono text-brand-ink mt-1" data-testid="usage-cost">${((usage.total?.cost_cents || 0) / 100).toFixed(2)}</div>
                </div>
            </div>

            {/* Agents */}
            <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-3">
                {agents.map((a) => {
                    const Icon = AGENT_ICON[a.agent_type] || Bot;
                    const u = usageByAgent[a.id] || {};
                    const running = a.enabled && killSwitch.ai_enabled;
                    return (
                        <div key={a.id} className="rounded-2xl border border-brand-line bg-white p-5" data-testid={`agent-card-${a.agent_type}`}>
                            <div className="flex items-start justify-between gap-3">
                                <div className="flex items-start gap-3 min-w-0">
                                    <div className="w-10 h-10 rounded-lg bg-brand-cream flex items-center justify-center shrink-0">
                                        <Icon className="w-4 h-4 text-brand-copper" />
                                    </div>
                                    <div className="min-w-0">
                                        <div className="font-medium text-brand-ink truncate">{a.name}</div>
                                        <div className="text-xs text-zinc-500 mt-0.5 line-clamp-2">{a.live_version?.purpose || "—"}</div>
                                    </div>
                                </div>
                                <Switch checked={a.enabled} onCheckedChange={(v) => toggleAgent(a.id, v)} data-testid={`agent-toggle-${a.agent_type}`} />
                            </div>
                            <div className="mt-3 flex items-center gap-2 flex-wrap">
                                <Badge className={running ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-600"} data-testid={`agent-status-${a.agent_type}`}>
                                    {running ? "Live" : (killSwitch.ai_enabled ? "Paused" : "Org-paused")}
                                </Badge>
                                <span className="text-[10px] uppercase tracking-widest text-zinc-400">{a.live_version?.allowed_tools?.length || 0} tools</span>
                                <span className="text-[10px] uppercase tracking-widest text-zinc-400">{u.interactions || 0} calls · ${((u.cost_cents || 0) / 100).toFixed(2)}</span>
                            </div>
                            <div className="mt-4 flex gap-2">
                                <Button size="sm" variant="outline" onClick={() => navigate(`/app/ai/${a.id}`)} data-testid={`agent-open-${a.agent_type}`}>
                                    Open studio <ArrowRight className="w-3.5 h-3.5 ml-1" />
                                </Button>
                            </div>
                        </div>
                    );
                })}
                {!loading && !agents.length && (
                    <div className="col-span-2 text-center text-zinc-500 py-10">No AI agents configured yet.</div>
                )}
            </div>

            <div className="mt-8 grid md:grid-cols-2 gap-3">
                <Link to="/app/ai/calls" className="rounded-xl border border-brand-line bg-white p-4 hover:bg-brand-cream/40 transition" data-testid="link-call-sim">
                    <div className="flex items-center gap-2 text-brand-ink font-medium"><Phone className="w-4 h-4" /> Call simulator</div>
                    <div className="text-xs text-zinc-500 mt-1">Test the receptionist as if it answered a real phone call. Retell + Twilio adapters are honest "not connected".</div>
                </Link>
                <Link to="/app/ai/conversations" className="rounded-xl border border-brand-line bg-white p-4 hover:bg-brand-cream/40 transition" data-testid="link-conversations">
                    <div className="flex items-center gap-2 text-brand-ink font-medium"><MessageCircle className="w-4 h-4" /> Conversations</div>
                    <div className="text-xs text-zinc-500 mt-1">Live chat + call transcripts. Take over any conversation with one click — AI pauses server-side.</div>
                </Link>
            </div>
        </div>
    );
}


// Dashboard wrapper: real stat cards + trend chart on top of the feature page.
export default function AiEmployees() {
    return (
        <>
            <div className="px-4 md:px-8 pt-6">
                <InsightsDashboard area="ai" title="AI employees" subtitle="How your AI agents handle chats, calls and hand-offs." color="#14B8A6" seriesKey="conversations" seriesFormat="int" breakdownTitle="By agent" breakdownFormat="int" />
            </div>
            <AiEmployeesBase />
        </>
    );
}
