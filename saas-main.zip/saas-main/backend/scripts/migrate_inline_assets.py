"""Idempotent migration of legacy inline/base64 media into the new asset storage.

Migrates Mongo `media` docs whose `url` is a base64 data URL into object storage + the `assets`
collection, recording a rollback map in `asset_migration_map`. Legacy blobs are retained until a
separate cleanup stage. Safe to re-run (skips already-migrated docs).

Usage:
  python -m scripts.migrate_inline_assets --dry-run        # inventory only
  python -m scripts.migrate_inline_assets --limit 200      # migrate up to N
  python -m scripts.migrate_inline_assets --cleanup        # remove verified legacy blobs
"""
import argparse
import asyncio
import base64
import hashlib
import re
import uuid

from dotenv import load_dotenv as _load
_load("/app/backend/.env")

from app.db import get_db, utc_now_iso
from app.services import assets as A
from app.services import storage as S

_DATA_URL = re.compile(r"^data:([-\w.+/]+);base64,(.+)$", re.DOTALL)


async def inventory():
    db = get_db()
    total = migrated = inline = bytes_ = 0
    async for m in db.media.find({}, {"url": 1, "org_id": 1, "mime": 1}):
        total += 1
        if await db.asset_migration_map.find_one({"legacy_id": str(m["_id"])}):
            migrated += 1
            continue
        mm = _DATA_URL.match(m.get("url") or "")
        if mm:
            inline += 1
            bytes_ += len(base64.b64decode(mm.group(2), validate=False))
    return {"total_media": total, "already_migrated": migrated, "inline_to_migrate": inline,
            "estimated_bytes": bytes_}


async def migrate(limit: int):
    db = get_db()
    done = failed = skipped = 0
    async for m in db.media.find({}):
        if done >= limit:
            break
        legacy_id = str(m["_id"])
        if await db.asset_migration_map.find_one({"legacy_id": legacy_id}):
            skipped += 1
            continue
        mm = _DATA_URL.match(m.get("url") or "")
        if not mm:
            skipped += 1
            continue
        org_id = m.get("org_id")
        mime = mm.group(1)
        try:
            raw = base64.b64decode(mm.group(2), validate=False)
            asset_id = uuid.uuid4().hex
            key = S.object_key(org_id, asset_id, "original")
            prov = await S.get_provider()
            await prov.put(key, raw, content_type=mime)
            head = await prov.head(key)
            if not head.get("exists") or head.get("size") not in (None, len(raw)):
                raise RuntimeError("verify_failed")
            sha = hashlib.sha256(raw).hexdigest()
            doc = {"id": asset_id, "org_id": org_id, "provider": getattr(prov, "provider", "local"),
                   "bucket": getattr(prov, "bucket", None), "object_key": key,
                   "filename": m.get("filename") or "asset", "display_name": m.get("filename") or "asset",
                   "mime": mime, "media_type": A._media_type(mime), "size_bytes": len(raw), "sha256": sha,
                   "width": m.get("width"), "height": m.get("height"), "duration": None,
                   "visibility": "public", "category": "website", "folder": None, "tags": [],
                   "alt_text": m.get("alt_text"), "caption": None, "source": "migration",
                   "provenance": {"legacy_id": legacy_id}, "original_asset_id": None,
                   "variants": {}, "thumb": None, "uploaded_by": m.get("uploaded_by_user_id"),
                   "processing_status": "ready", "scan_status": "skipped",
                   "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
                   "trashed_at": None, "purge_at": None}
            await db.assets.insert_one(dict(doc))
            await db.storage_usage.update_one({"org_id": org_id},
                {"$inc": {"active_bytes": len(raw), "file_count": 1}}, upsert=True)
            await db.asset_migration_map.insert_one({"legacy_id": legacy_id, "asset_id": asset_id,
                "object_key": key, "org_id": org_id, "migrated_at": utc_now_iso(), "cleaned": False})
            done += 1
        except Exception as e:  # noqa: BLE001
            failed += 1
            await db.asset_migration_failures.insert_one({"legacy_id": legacy_id, "error": str(e)[:200],
                                                          "at": utc_now_iso()})
    return {"migrated": done, "skipped": skipped, "failed": failed}


async def cleanup(limit: int):
    """Remove legacy base64 blob (keep the media doc; blank the inline url) after verification."""
    db = get_db()
    cleaned = 0
    async for mp in db.asset_migration_map.find({"cleaned": {"$ne": True}}):
        if cleaned >= limit:
            break
        prov = await S.get_provider()
        if (await prov.head(mp["object_key"])).get("exists"):
            from bson import ObjectId
            await db.media.update_one({"_id": ObjectId(mp["legacy_id"])},
                                      {"$set": {"migrated_asset_id": mp["asset_id"]}, "$unset": {"url": ""}})
            await db.asset_migration_map.update_one({"_id": mp["_id"]}, {"$set": {"cleaned": True}})
            cleaned += 1
    return {"cleaned": cleaned}


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--cleanup", action="store_true")
    ap.add_argument("--limit", type=int, default=500)
    args = ap.parse_args()
    if args.dry_run:
        print(await inventory())
    elif args.cleanup:
        print(await cleanup(args.limit))
    else:
        print("inventory:", await inventory())
        print("migrate:", await migrate(args.limit))


if __name__ == "__main__":
    asyncio.run(main())
