"""Blog / articles (Round 10, Gate 3).

Owner routes (org-scoped): /api/blog/posts CRUD + publish + optional AI draft (metered, feature=blog_draft).
Public routes: /api/public/sites/{slug}/blog (list) and /blog/{post_slug} (article) — published posts only,
resolved through the same website-slug resolver the public site uses. The `blog_list` block on a page
renders the latest N posts; sitemap.xml includes /blog/<slug> entries.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User

router = APIRouter(prefix="/blog", tags=["blog"])
public_router = APIRouter(prefix="/public", tags=["public-blog"])


def _slugify(s: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")
    return s[:80] or "post"


def _out(d: Dict[str, Any]) -> Dict[str, Any]:
    d = dict(d)
    d["id"] = str(d.pop("_id"))
    return d


class PostIn(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    slug: Optional[str] = None
    excerpt: str = Field(default="", max_length=400)
    body: str = Field(default="", max_length=60000)          # markdown-ish plain text (paragraphs by blank line)
    cover_image: str = ""
    tags: List[str] = Field(default_factory=list)
    seo: Dict[str, Any] = Field(default_factory=dict)
    status: str = "draft"                                     # draft | published
    language: str = "en"


class PostPatch(BaseModel):
    title: Optional[str] = Field(default=None, max_length=160)
    slug: Optional[str] = None
    excerpt: Optional[str] = Field(default=None, max_length=400)
    body: Optional[str] = Field(default=None, max_length=60000)
    cover_image: Optional[str] = None
    tags: Optional[List[str]] = None
    seo: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    language: Optional[str] = None


async def _unique_slug(db, org_id: str, want: str, exclude_id: Optional[str] = None) -> str:
    base = _slugify(want)
    slug, n = base, 1
    while True:
        q: Dict[str, Any] = {"org_id": org_id, "slug": slug}
        if exclude_id:
            q["_id"] = {"$ne": ObjectId(exclude_id)}
        if not await db.posts.find_one(q, {"_id": 1}):
            return slug
        n += 1
        slug = f"{base}-{n}"


@router.get("/posts")
async def list_posts(status: Optional[str] = None, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if status in ("draft", "published"):
        q["status"] = status
    rows = await db.posts.find(q).sort("updated_at", -1).to_list(500)
    return {"posts": [_out(r) for r in rows]}


@router.post("/posts", status_code=201)
async def create_post(req: PostIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    if req.status not in ("draft", "published"):
        raise HTTPException(422, "status must be draft|published")
    now = utc_now_iso()
    doc = {**req.model_dump(), "org_id": org_id, "author_id": user.id,
           "slug": await _unique_slug(db, org_id, req.slug or req.title),
           "published_at": now if req.status == "published" else None,
           "created_at": now, "updated_at": now}
    r = await db.posts.insert_one(doc)
    doc["_id"] = r.inserted_id
    return _out(doc)


@router.get("/posts/{post_id}")
async def get_post(post_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    d = await db.posts.find_one({"_id": ObjectId(post_id), "org_id": org_id})
    if not d:
        raise HTTPException(404, "Post not found")
    return _out(d)


@router.patch("/posts/{post_id}")
async def patch_post(post_id: str, req: PostPatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    d = await db.posts.find_one({"_id": ObjectId(post_id), "org_id": org_id})
    if not d:
        raise HTTPException(404, "Post not found")
    patch = {k: v for k, v in req.model_dump().items() if v is not None}
    if "status" in patch and patch["status"] not in ("draft", "published"):
        raise HTTPException(422, "status must be draft|published")
    if "slug" in patch:
        patch["slug"] = await _unique_slug(db, org_id, patch["slug"], exclude_id=post_id)
    if patch.get("status") == "published" and not d.get("published_at"):
        patch["published_at"] = utc_now_iso()
    patch["updated_at"] = utc_now_iso()
    await db.posts.update_one({"_id": d["_id"]}, {"$set": patch})
    return _out(await db.posts.find_one({"_id": d["_id"]}))


@router.delete("/posts/{post_id}")
async def delete_post(post_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.posts.delete_one({"_id": ObjectId(post_id), "org_id": org_id})
    if not r.deleted_count:
        raise HTTPException(404, "Post not found")
    return {"ok": True}


class DraftReq(BaseModel):
    topic: str = Field(min_length=3, max_length=200)
    tone: Optional[str] = Field(default=None, max_length=60)
    language: str = "en"


_DRAFT_SYSTEM = """You write helpful, honest blog articles for a small business website. Return ONLY JSON:
{"title": str, "excerpt": str (<=200 chars), "body": str (600-900 words, plain text paragraphs separated by blank
lines, may include short '## ' subheadings), "tags": [str], "seo": {"title": str, "description": str}}.
Truth rule: no invented statistics, prices, reviews, awards or guarantees. Write in the requested language."""


@router.post("/posts/ai-draft")
async def ai_draft(req: DraftReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Metered AI draft (feature=blog_draft). Returns a post payload the owner can edit and save."""
    from ..services.llm import generate_json
    from ..services.generation import _profile_prompt
    from ..models import BusinessProfile
    db = get_db()
    pdoc = await db.business_profiles.find_one({"org_id": org_id})
    ctx = ""
    if pdoc:
        try:
            ctx = _profile_prompt(BusinessProfile.from_mongo(pdoc))
        except Exception:  # noqa: BLE001
            ctx = f"Business: {pdoc.get('business_name', '')}"
    prompt = f"{ctx}\nTOPIC: {req.topic}\nTONE: {req.tone or 'clear, friendly, expert'}\nLANGUAGE: {req.language}"
    raw = await generate_json(_DRAFT_SYSTEM, prompt, max_retries=1, feature="blog_draft")
    if not isinstance(raw, dict) or not raw.get("title"):
        raise HTTPException(502, "The AI returned an unusable draft — please try again.")
    return {"title": str(raw.get("title", ""))[:160], "excerpt": str(raw.get("excerpt", ""))[:400],
            "body": str(raw.get("body", ""))[:60000], "tags": [str(t)[:40] for t in (raw.get("tags") or [])][:8],
            "seo": raw.get("seo") if isinstance(raw.get("seo"), dict) else {}, "status": "draft",
            "language": req.language}


# ---------------- public ----------------

def _public_post(d: Dict[str, Any], full: bool = False) -> Dict[str, Any]:
    out = {"slug": d.get("slug"), "title": d.get("title"), "excerpt": d.get("excerpt", ""),
           "cover_image": d.get("cover_image", ""), "tags": d.get("tags", []),
           "published_at": d.get("published_at"), "language": d.get("language", "en")}
    if full:
        out["body"] = d.get("body", "")
        out["seo"] = d.get("seo", {})
    return out


async def _org_for_site(slug: str) -> Optional[str]:
    from .public_sites import _resolve_by_slug
    resolved = await _resolve_by_slug(slug)
    if not resolved or "__redirect_to__" in resolved:
        return None
    return resolved.get("org_id")


@public_router.get("/sites/{slug}/blog")
async def public_blog_list(slug: str, limit: int = 20, tag: Optional[str] = None):
    org_id = await _org_for_site(slug)
    if not org_id:
        raise HTTPException(404, "No published site at this slug")
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id, "status": "published"}
    if tag:
        q["tags"] = tag
    rows = await db.posts.find(q).sort("published_at", -1).to_list(max(1, min(int(limit), 100)))
    return {"posts": [_public_post(r) for r in rows]}


@public_router.get("/sites/{slug}/blog/{post_slug}")
async def public_blog_post(slug: str, post_slug: str):
    org_id = await _org_for_site(slug)
    if not org_id:
        raise HTTPException(404, "No published site at this slug")
    db = get_db()
    d = await db.posts.find_one({"org_id": org_id, "status": "published", "slug": post_slug})
    if not d:
        raise HTTPException(404, "Article not found")
    return _public_post(d, full=True)


async def published_post_slugs(org_id: str) -> List[str]:
    db = get_db()
    rows = await db.posts.find({"org_id": org_id, "status": "published"}, {"slug": 1}).to_list(500)
    return [r["slug"] for r in rows]
