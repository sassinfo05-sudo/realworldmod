"""Outbound-request safety (SSRF / DNS-rebinding guard) shared by the website importer and
outbound webhooks. Only public http(s) hosts on standard ports are allowed; every resolved
address must be public (no loopback, RFC1918, link-local/metadata, multicast, reserved)."""
from __future__ import annotations

import asyncio
import ipaddress
import socket
from typing import Optional
from urllib.parse import urlparse


def is_public_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
                or ip.is_reserved or ip.is_unspecified or getattr(ip, "is_site_local", False))


async def resolve_public(host: str) -> Optional[str]:
    if not host or host.lower() == "localhost" or host.endswith((".local", ".internal", ".localhost")):
        return None
    try:
        infos = await asyncio.get_event_loop().getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except Exception:  # noqa: BLE001
        return None
    ips = {i[4][0] for i in infos}
    if not ips or any(not is_public_ip(ip) for ip in ips):
        return None
    return sorted(ips)[0]


def url_shape_ok(url: str, allow_http: bool = True) -> bool:
    p = urlparse(url or "")
    schemes = ("http", "https") if allow_http else ("https",)
    return p.scheme in schemes and bool(p.hostname) and p.port in (None, 80, 443)


async def url_is_safe(url: str, allow_http: bool = True) -> bool:
    if not url_shape_ok(url, allow_http=allow_http):
        return False
    return await resolve_public(urlparse(url).hostname or "") is not None
