# STORAGE & ASSET AUDIT (pre-migration) — Round 17

_Audit of every place that stores/uploads/imports/generates/displays/references/deletes media,
and the map to the new provider-neutral storage service + unified Asset Library._

## Findings — where media currently lives

| Path | Storage today | Problem | New home |
|------|---------------|---------|----------|
| `POST /api/media/upload` (`media_forms_analytics.py`) | Mongo `media` doc with **base64 data URL** inline (`url=data:...`) | Full binary in Mongo; ObjectId; no plan limit; no references; no trash | `assets` + object storage via upload/init+finalize |
| `POST /api/media/upload/init|chunk|complete` | disk `UPLOAD_DIR/chunks/*` then base64 into Mongo | temp container disk; base64 in Mongo | new atomic upload flow |
| Branding logos (`routes/branding.py`, `services/images.py`) | base64/SVG inline in org branding + published_theme | inline blobs; SVG XSS risk (sanitised) | asset with category `brand`; theme stores `asset_id` (compat resolver keeps data URL working) |
| Product images (`store`/`ecommerce`) | image_url strings (data URL or remote) | raw URLs not stable IDs | asset `product`; product stores asset_id |
| Blog / Dynamic CMS media | image URLs / rich_text inline | raw URLs | asset `cms`; media field returns asset_id |
| AI-generated images (`services/images.py`, branding ai-logo) | base64 inline; metered via usage | not stored as assets; no storage metering | reserve storage before generation; store as asset `ai` |
| Email-template images / attachments | inline / provider | inline blobs | asset `email` (private for attachments) |
| Knowledge base docs (`routes/inbox`/`knowledge`) | text/records | n/a binary yet | asset `document` private |
| Form/customer uploads (`forms submit`) | none/limited | would be private | asset `private`, never in reusable picker |
| Remote image URLs (import_site) | stored as external URLs | SSRF on import (existing netsafe) | optional owned import applies existing SSRF guard |

## Risks identified
* **Full base64 files in Mongo** (`media`, branding, some product/theme) — bloats DB, no CDN, no quota.
* **No plan storage limits** — uploads bypass entitlements entirely.
* **Assets referenced by raw URL**, not stable IDs — deleting/replacing silently breaks published content.
* **No reference tracking / no trash / no orphan detection.**
* `DELETE /api/media/{id}` uses Mongo ObjectId (not UUID) and has no reference check.
* AI image generation is metered for the LLM call but storage bytes were never counted.

## Migration requirements
1. Idempotent dry-run inventory of `media` (base64 data URLs) + branding logos + product images.
2. For each: decode → upload to storage → create `assets` doc → keep a rollback map → update the
   consuming reference → only remove the legacy blob in a separate cleanup stage after verification.
3. Compatibility resolver: existing data-URL fields keep rendering during migration (assets are additive).
4. Never auto-import arbitrary remote/private URLs; apply existing SSRF protections (`services/netsafe`).

## Implementation map (this round)
* `services/storage.py` — provider-neutral service (S3-compatible + local dev + disabled-in-prod).
* `services/assets.py` — asset model, atomic quota reservation, CRUD, references, trash lifecycle, usage.
* `routes/assets.py` — `/api/assets/*`, `/api/public/assets/*`, `/api/founder/storage`.
* `scripts/migrate_inline_assets.py` — dry-run + bounded, idempotent migration of `media` base64.
* Frontend Asset Library (`/app/assets`) + reusable `AssetPicker`.

## Status of legacy systems
The legacy `media` endpoints remain in place (backward-compatible) and are NOT deleted this round;
migration moves their blobs into the new system while the old records keep rendering until cleanup.
