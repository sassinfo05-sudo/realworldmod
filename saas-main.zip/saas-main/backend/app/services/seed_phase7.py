"""Phase 7 seed: 2 automation templates, 2 more thin demo orgs (automotive + beauty)
at reasonable parity, and Cedar Lane receptionist so the Free-plan chat fallback
path is exercisable out of the box.
"""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

from bson import ObjectId

from ..db import get_db, utc_now_iso
from ..security import generate_readable_password, hash_password

logger = logging.getLogger(__name__)


AUTO_TEMPLATES = [
    {
        "name": "Welcome new leads",
        "trigger": "form_submitted",
        "condition": {},
        "actions": [
            {"type": "send_email", "subject": "Thanks for reaching out",
              "body_text": "Hi! Thanks for your message — we'll be in touch within one business day."},
            {"type": "add_tag", "tag": "new_lead"},
        ],
        "is_template": True,
    },
    {
        "name": "Request a review when job is done",
        "trigger": "job_completed",
        "condition": {},
        "actions": [
            {"type": "request_review", "link": "https://g.page/r/YOUR-BUSINESS/review"},
            {"type": "send_email", "subject": "How did we do?",
              "body_text": "Thanks for choosing us. Would you leave a quick review? It really helps."},
        ],
        "is_template": True,
    },
]


DEMO_ORGS_PHASE7 = [
    {
        "email": "owner@auto-demo.zanelvo.com",
        "org_name": "Ridgeline Auto Service",
        "org_slug": "ridgeline-auto-service",
        "industry": "automotive",
        "industry_label": "Automotive",
        "plan": "revenue",
        "services": [
            {"name": "Oil change + inspection", "duration_minutes": 45, "price_cents": 6900,
              "buffer_before_minutes": 5, "buffer_after_minutes": 10},
            {"name": "Brake job (per axle)", "duration_minutes": 120, "price_cents": 32000,
              "buffer_before_minutes": 10, "buffer_after_minutes": 20},
        ],
    },
    {
        "email": "owner@beauty-demo.zanelvo.com",
        "org_name": "Mira & Co. Beauty",
        "org_slug": "mira-co-beauty",
        "industry": "beauty_wellness",
        "industry_label": "Beauty & Wellness",
        "plan": "autopilot",
        "services": [
            {"name": "Signature cut + style", "duration_minutes": 60, "price_cents": 8500,
              "buffer_before_minutes": 0, "buffer_after_minutes": 15},
            {"name": "Full color + gloss", "duration_minutes": 120, "price_cents": 22500,
              "buffer_before_minutes": 0, "buffer_after_minutes": 20},
        ],
    },
]


async def _ensure_user_org(email: str, org_name: str, org_slug: str, industry: str) -> Dict[str, Any]:
    db = get_db()
    u = await db.users.find_one({"email": email})
    if u:
        org = await db.organizations.find_one({"_id": ObjectId(u["org_id"])})
        return {"user": u, "org": org, "password": None}
    org = await db.organizations.find_one({"slug": org_slug})
    if not org:
        r = await db.organizations.insert_one({
            "slug": org_slug, "name": org_name, "industry": industry,
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        org = await db.organizations.find_one({"_id": r.inserted_id})
    pw = generate_readable_password(16)
    r = await db.users.insert_one({
        "email": email, "password_hash": hash_password(pw),
        "full_name": f"{org_name} Owner",
        "org_id": str(org["_id"]), "role": "owner",
        "email_verified": True,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    return {"user": await db.users.find_one({"_id": r.inserted_id}),
             "org": org, "password": pw}


def _minimal_home_blocks(name: str, industry_label: str) -> List[Dict[str, Any]]:
    return [
        {"id": "hero-1", "kind": "hero", "props": {
            "eyebrow": industry_label,
            "heading": f"Welcome to {name}.",
            "subheading": "Local, trusted, easy to book. Get started in under a minute.",
            "cta_label": "Book now", "cta_href": "#book",
        }, "style": {"align": "left"}},
        {"id": "services-1", "kind": "text", "props": {
            "heading": "What we do",
            "body": "See our services below and pick a time that works.",
        }, "style": {}},
        {"id": "booking-1", "kind": "booking", "props": {"heading": "Book a slot"}, "style": {}},
        {"id": "contact-1", "kind": "contact_form", "props": {
            "heading": "Get in touch",
            "fields": [{"key": "name", "label": "Name", "required": True},
                        {"key": "email", "label": "Email", "required": True},
                        {"key": "message", "label": "Message", "required": False}],
        }, "style": {}},
    ]


async def _seed_org_data(spec: Dict[str, Any], org_id: str) -> None:
    db = get_db()
    # Business profile
    if not await db.business_profiles.find_one({"org_id": org_id}):
        await db.business_profiles.insert_one({
            "org_id": org_id,
            "business_name": spec["org_name"],
            "industry": spec["industry"],
            "industry_label": spec["industry_label"],
            "tagline": "Reliable service. Simple booking.",
            "about": "Seeded synthetic demo tenant for Phase 8 parity.",
            "services": [], "hours": [], "locations": [],
            "differentiators": ["Fast turnaround", "Locally owned"],
            "policies": [], "goals": ["more_bookings"],
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
    # Services (idempotent: also backfills bookable/active on legacy rows)
    service_ids: List[str] = []
    for svc in spec["services"]:
        existing = await db.service_offerings.find_one({"org_id": org_id, "name": svc["name"]})
        if existing:
            # backfill missing publicly-required flags on legacy seeded rows
            upd: Dict[str, Any] = {}
            if not existing.get("bookable"):
                upd["bookable"] = True
            if not existing.get("active"):
                upd["active"] = True
            if upd:
                upd["updated_at"] = utc_now_iso()
                await db.service_offerings.update_one({"_id": existing["_id"]}, {"$set": upd})
            service_ids.append(str(existing["_id"]))
            continue
        r = await db.service_offerings.insert_one({
            "org_id": org_id, **svc, "active": True, "bookable": True,
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        service_ids.append(str(r.inserted_id))
    # Staff (1 default worker)
    staff = await db.staff.find_one({"org_id": org_id})
    if not staff:
        r = await db.staff.insert_one({
            "org_id": org_id,
            "display_name": "Owner",
            "email": spec["email"],
            "active": True,
            "working_hours": [
                {"weekday": 0, "start": "09:00", "end": "17:00"},
                {"weekday": 1, "start": "09:00", "end": "17:00"},
                {"weekday": 2, "start": "09:00", "end": "17:00"},
                {"weekday": 3, "start": "09:00", "end": "17:00"},
                {"weekday": 4, "start": "09:00", "end": "17:00"},
            ],
            "service_ids": service_ids,
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        staff_id = str(r.inserted_id)
    else:
        staff_id = str(staff["_id"])
    # Website (published)
    if not await db.websites.find_one({"org_id": org_id}):
        await db.websites.insert_one({
            "org_id": org_id, "slug": spec["org_slug"], "name": spec["org_name"],
            "status": "published",
            "published_pages": [{"slug": "home", "title": "Home",
                                    "blocks": _minimal_home_blocks(spec["org_name"],
                                                                        spec["industry_label"]),
                                    "seo": {}, "hidden": False}],
            "published_nav_order": ["home"],
            "published_theme": {"primary": "#B85C38", "ink": "#1F1F1F",
                                    "surface": "#F7F3EE"},
            "published_at": utc_now_iso(),
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
    # 8 synthetic contacts
    if await db.contacts.count_documents({"org_id": org_id}) < 5:
        first_names = ["Alex", "Jordan", "Taylor", "Sam", "Riley", "Casey", "Morgan", "Drew"]
        last_names = ["Fox", "Rivera", "Chen", "Nguyen", "Patel", "Kim", "Diaz", "Cohen"]
        for fn, ln in zip(first_names, last_names):
            existing = await db.contacts.find_one({"org_id": org_id, "emails": f"{fn.lower()}.{ln.lower()}@example.com"})
            if existing:
                continue
            await db.contacts.insert_one({
                "org_id": org_id,
                "display_name": f"{fn} {ln} (demo)",
                "first_name": fn, "last_name": ln,
                "emails": [f"{fn.lower()}.{ln.lower()}@example.com"],
                "phones": [], "tags": ["demo"],
                "source": "seed_demo", "custom_fields": {},
                "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
                "last_activity_at": utc_now_iso(),
            })
    # 2 bookings (future)
    if await db.bookings.count_documents({"org_id": org_id}) < 2 and service_ids:
        base = datetime.now(timezone.utc) + timedelta(days=2)
        for i in range(2):
            start = base + timedelta(hours=i * 3)
            end = start + timedelta(minutes=spec["services"][0]["duration_minutes"])
            await db.bookings.insert_one({
                "org_id": org_id, "service_id": service_ids[0], "staff_id": staff_id,
                "start_at": start.isoformat().replace("+00:00", "Z"),
                "end_at": end.isoformat().replace("+00:00", "Z"),
                "buffer_before_minutes": 5, "buffer_after_minutes": 10,
                "status": "confirmed", "source": "manual",
                "booking_number": f"B-2026-{secrets.token_hex(2).upper()}",
                "customer_name": "Demo Customer", "customer_email": f"demo{i}@example.com",
                "tokens": {"cancel": secrets.token_urlsafe(24),
                             "reschedule": secrets.token_urlsafe(24)},
                "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
            })
    # 1 quote + 1 invoice (light)
    if await db.quotes.count_documents({"org_id": org_id}) < 1 and service_ids:
        q_total = spec["services"][0]["price_cents"]
        await db.quotes.insert_one({
            "org_id": org_id, "number": f"Q-2026-{secrets.token_hex(2).upper()}",
            "status": "sent", "customer_email": "demo0@example.com",
            "customer_name": "Demo Customer",
            "line_items": [{"description": spec["services"][0]["name"],
                              "quantity": 1, "unit_price_cents": q_total}],
            "global_discount_percent": 0, "tax_rate": 0,
            "totals": {"subtotal_cents": q_total, "total_cents": q_total},
            "portal_token": secrets.token_urlsafe(24),
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
    if await db.invoices.count_documents({"org_id": org_id}) < 1 and service_ids:
        inv_total = spec["services"][0]["price_cents"]
        await db.invoices.insert_one({
            "org_id": org_id, "number": f"INV-2026-{secrets.token_hex(2).upper()}",
            "status": "open", "customer_email": "demo0@example.com",
            "customer_name": "Demo Customer",
            "line_items": [{"description": spec["services"][0]["name"],
                              "quantity": 1, "unit_price_cents": inv_total}],
            "global_discount_percent": 0, "tax_rate": 0,
            "totals": {"subtotal_cents": inv_total, "total_cents": inv_total},
            "amount_paid_cents": 0,
            "portal_token": secrets.token_urlsafe(24),
            "due_at": (datetime.now(timezone.utc) + timedelta(days=14)).isoformat().replace("+00:00", "Z"),
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
    # Receptionist agent
    if not await db.agents.find_one({"org_id": org_id, "agent_type": "receptionist"}):
        agent_r = await db.agents.insert_one({
            "org_id": org_id, "agent_type": "receptionist", "enabled": True,
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        v_r = await db.agent_versions.insert_one({
            "org_id": org_id, "agent_id": str(agent_r.inserted_id),
            "version_number": 1, "label": "v1", "is_live": True,
            "system_prompt_seed": ("You are a friendly receptionist for a small business. "
                                        "Only quote prices, hours, and availability that come from tools. "
                                        "If you don't know, say so."),
            "tone": "friendly", "escalation_threshold": 0.4,
            "tools_allowed": ["get_services", "get_hours", "get_availability",
                                 "create_booking", "escalate_to_human"],
            "model": "claude-sonnet-4-6",
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        await db.agents.update_one({"_id": agent_r.inserted_id},
                                        {"$set": {"live_version_id": str(v_r.inserted_id)}})


async def seed_phase7() -> None:
    db = get_db()
    logger.info("Phase 7 seed starting…")

    # 1. Cedar Lane receptionist (Free demo — over-cap chat fallback path)
    cedar_org = await db.organizations.find_one({"slug": "cedar-lane-landscaping"})
    if cedar_org:
        oid = str(cedar_org["_id"])
        if not await db.agents.find_one({"org_id": oid, "agent_type": "receptionist"}):
            agent = await db.agents.insert_one({
                "org_id": oid, "agent_type": "receptionist", "enabled": True,
                "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
            })
            v = await db.agent_versions.insert_one({
                "org_id": oid, "agent_id": str(agent.inserted_id),
                "version_number": 1, "label": "v1", "is_live": True,
                "system_prompt_seed": "Friendly receptionist. Ground answers in tools only.",
                "tone": "friendly", "escalation_threshold": 0.4,
                "tools_allowed": ["get_services", "get_hours", "get_availability",
                                     "create_booking", "escalate_to_human"],
                "model": "claude-sonnet-4-6",
                "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
            })
            await db.agents.update_one({"_id": agent.inserted_id},
                                            {"$set": {"live_version_id": str(v.inserted_id)}})
            logger.info("Cedar Lane receptionist seeded.")

    # 2. Extra demo orgs
    created = []
    for spec in DEMO_ORGS_PHASE7:
        r = await _ensure_user_org(spec["email"], spec["org_name"],
                                        spec["org_slug"], spec["industry"])
        org_id = str(r["org"]["_id"])
        # Subscription
        from .entitlements import get_or_create_subscription
        sub = await db.subscriptions.find_one({"org_id": org_id})
        if not sub:
            await get_or_create_subscription(org_id, spec["plan"])
        elif sub.get("plan_code") != spec["plan"]:
            await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
                "plan_code": spec["plan"], "status": "active"}})
        await _seed_org_data(spec, org_id)
        if r.get("password"):
            created.append((spec["email"], r["password"], spec["plan"], spec["org_name"]))

    # 3. Automation templates
    templates_org = await db.organizations.find_one({"slug": "demo-home-services"})
    if templates_org:
        oid = str(templates_org["_id"])
        for t in AUTO_TEMPLATES:
            existing = await db.automations.find_one({"org_id": oid, "name": t["name"]})
            if existing:
                continue
            await db.automations.insert_one({
                "org_id": oid, **t, "status": "published", "version": 1,
                "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
            })

    # Persist creds
    if created:
        with open("/app/memory/test_credentials.md", "r") as f:
            content = f.read()
        appendix_lines = ["", "## Phase 7 additional demo orgs", ""]
        for email, pw, plan, orgn in created:
            appendix_lines.append(f"- **{email}** — `{pw}` (role: owner, plan: {plan}, org: {orgn})")
        if "Phase 7 additional demo orgs" not in content:
            with open("/app/memory/test_credentials.md", "a") as f:
                f.write("\n".join(appendix_lines) + "\n")
    logger.info("Phase 7 seed complete.")
