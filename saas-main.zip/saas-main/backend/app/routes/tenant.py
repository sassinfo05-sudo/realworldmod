"""Customer-facing (tenant-scoped) endpoints:
- Per-org integrations (payments, email, messaging, ecommerce) with masked secrets.
- Per-website SEO defaults + analytics pixels.
Every route is org-scoped via `require_org`.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..services import tenant_integrations as tenant_integ

from ..services.sites import active_filter as _active_filter

router = APIRouter(prefix="/tenant", tags=["tenant"])


# ---------- integrations ----------

@router.get("/integrations")
async def get_integrations(user: User = Depends(current_user),
                           org_id: str = Depends(require_org)):
    return await tenant_integ.get_public(org_id)


@router.put("/integrations")
async def update_integrations(patch: Dict[str, Any] = Body(...),
                              user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    return await tenant_integ.update(org_id, patch or {})


# ---------- SEO defaults + pixels for the org's website ----------

class SeoAndPixelsPatch(BaseModel):
    seo_defaults: Optional[Dict[str, Any]] = None   # title_template, description, og_image, favicon_url
    pixels: Optional[Dict[str, Any]] = None         # ga4_id, meta_pixel_id, tiktok_pixel_id, gtm_id
    allow_indexing: Optional[bool] = None           # if False, add robots noindex


_SEO_KEYS = {"title_template", "description", "og_image", "favicon_url", "keywords"}
# Only validated analytics identifiers are accepted. Arbitrary `custom_head_html`
# is intentionally NOT allowed — it would execute attacker-controlled script on the
# public site origin (XSS). Tenants configure tracking via these typed IDs only.
_PIXEL_KEYS = {"ga4_id", "meta_pixel_id", "tiktok_pixel_id", "gtm_id", "hotjar_id",
               "linkedin_partner_id", "pinterest_tag_id"}

# Strict allow-list formats for each analytics identifier.
_PIXEL_FORMATS = {
    "ga4_id": re.compile(r"^(G-[A-Z0-9]{4,20}|UA-\d{4,12}-\d{1,4}|AW-\d{6,15})$"),
    "gtm_id": re.compile(r"^GTM-[A-Z0-9]{4,12}$"),
    "meta_pixel_id": re.compile(r"^\d{6,20}$"),
    "tiktok_pixel_id": re.compile(r"^[A-Z0-9]{10,30}$", re.IGNORECASE),
    "hotjar_id": re.compile(r"^\d{5,12}$"),
    "linkedin_partner_id": re.compile(r"^\d{4,12}$"),
    "pinterest_tag_id": re.compile(r"^\d{6,20}$"),
}


def _clean_pixel_value(key: str, value: Any) -> str:
    """Return the value only if it matches the strict format for that key; else ''."""
    v = ("" if value is None else str(value)).strip()
    if not v:
        return ""
    rx = _PIXEL_FORMATS.get(key)
    if rx and not rx.match(v):
        raise HTTPException(422, {"error": "invalid_pixel_id",
                                  "message": f"'{key}' is not a valid identifier format."})
    return v


@router.get("/website/seo-and-pixels")
async def get_seo(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.websites.find_one(await _active_filter(org_id), {"_id": 1, "seo_defaults": 1,
                                                            "pixels": 1, "allow_indexing": 1,
                                                            "slug": 1})
    if not doc:
        raise HTTPException(404, "No website yet")
    return {
        "seo_defaults": doc.get("seo_defaults") or {},
        "pixels": doc.get("pixels") or {},
        "allow_indexing": doc.get("allow_indexing", True),
        "slug": doc.get("slug"),
    }


@router.patch("/website/seo-and-pixels")
async def patch_seo(patch: SeoAndPixelsPatch,
                    user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    website = await db.websites.find_one(await _active_filter(org_id), {"_id": 1, "seo_defaults": 1, "pixels": 1})
    if not website:
        raise HTTPException(404, "No website yet")
    upd: Dict[str, Any] = {"updated_at": utc_now_iso()}
    if patch.seo_defaults is not None:
        cur = website.get("seo_defaults") or {}
        clean = {**cur, **{k: v for k, v in patch.seo_defaults.items() if k in _SEO_KEYS}}
        upd["seo_defaults"] = clean
    if patch.pixels is not None:
        cur = website.get("pixels") or {}
        cur.pop("custom_head_html", None)  # purge any legacy raw HTML on write
        clean = {**cur, **{k: _clean_pixel_value(k, v)
                            for k, v in patch.pixels.items() if k in _PIXEL_KEYS}}
        upd["pixels"] = clean
    if patch.allow_indexing is not None:
        upd["allow_indexing"] = bool(patch.allow_indexing)
    await db.websites.update_one({"_id": website["_id"]}, {"$set": upd})
    fresh = await db.websites.find_one({"_id": website["_id"]},
                                        {"_id": 0, "seo_defaults": 1, "pixels": 1, "allow_indexing": 1, "slug": 1})
    return {
        "seo_defaults": fresh.get("seo_defaults") or {},
        "pixels": fresh.get("pixels") or {},
        "allow_indexing": fresh.get("allow_indexing", True),
        "slug": fresh.get("slug"),
    }


# ---------- Live analytics for a specific site (owner view) ----------

@router.get("/website/analytics")
async def website_analytics(days: int = 30,
                             user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from datetime import datetime, timedelta, timezone
    db = get_db()
    site = await db.websites.find_one(await _active_filter(org_id), {"_id": 1})
    if not site:
        raise HTTPException(404, "No website yet")
    days = max(1, min(365, int(days)))
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    q = {"org_id": org_id}
    q_recent = {**q, "created_at": {"$gte": since}}

    total_pv = await db.analytics_events.count_documents({**q, "kind": "pageview"})
    total_submits = await db.analytics_events.count_documents({**q, "kind": "form_submit"})
    total_clicks = await db.analytics_events.count_documents({**q, "kind": "cta_click"})
    recent_pv = await db.analytics_events.count_documents({**q_recent, "kind": "pageview"})
    recent_submits = await db.analytics_events.count_documents({**q_recent, "kind": "form_submit"})

    by_page = [{"page_slug": r["_id"], "views": r["count"]}
               async for r in db.analytics_events.aggregate([
                   {"$match": {**q, "kind": "pageview"}},
                   {"$group": {"_id": "$page_slug", "count": {"$sum": 1}}},
                   {"$sort": {"count": -1}},
                   {"$limit": 10},
               ])]

    # simple per-day timeseries for a chart
    pipe_daily = [
        {"$match": {**q_recent, "kind": "pageview"}},
        {"$group": {"_id": {"$substr": ["$created_at", 0, 10]}, "count": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
    ]
    daily = [{"day": r["_id"], "views": r["count"]}
             async for r in db.analytics_events.aggregate(pipe_daily)]

    return {
        "days": days,
        "totals": {"pageviews": total_pv, "form_submits": total_submits, "cta_clicks": total_clicks},
        "recent": {"pageviews": recent_pv, "form_submits": recent_submits},
        "by_page": by_page,
        "daily": daily,
    }
