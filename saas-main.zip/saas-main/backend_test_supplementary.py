#!/usr/bin/env python3
"""
Supplementary CMS Backend Tests
Tests additional requirements from the review request.
"""
import requests
import json
import random
import string

BASE_URL = "https://bootstrap-fix-2.preview.emergentagent.com/api"
import os
OWNER_EMAIL = os.environ.get("TEST_OWNER_EMAIL", "owner@demo.zanelvo.com")


def _cred(email, env_key):
    """Load a test password from env or the gitignored creds file — never hardcoded in git."""
    v = os.environ.get(env_key)
    if v:
        return v
    try:
        import re
        txt = open("/app/memory/test_credentials.md", encoding="utf-8").read()
        m = re.search(re.escape(email) + r"[^`]*`([^`]+)`", txt)
        if m:
            return m.group(1)
    except Exception:
        pass
    return ""


OWNER_PASSWORD = _cred(OWNER_EMAIL, "TEST_OWNER_PASSWORD")
DEMO_SITE_SLUG = "demo-home-services"

def login_owner():
    """Login as owner and return access token"""
    resp = requests.post(f"{BASE_URL}/auth/login", json={
        "email": OWNER_EMAIL,
        "password": OWNER_PASSWORD
    })
    if resp.status_code != 200:
        print(f"❌ Login failed: {resp.text}")
        return None
    return resp.json().get("access_token")

def random_email():
    rand = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"test+{rand}@example.com"

def test_schema_version_bump(token):
    """Test that PATCH collection with changed fields bumps schema_version"""
    print("\n" + "="*80)
    print("TEST: Schema Version Bump")
    print("="*80)
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Create collection
    print("\n--- Step 1: Create collection ---")
    resp = requests.post(f"{BASE_URL}/cms/collections", json={
        "name": "Schema Test",
        "fields": [{"label": "Name", "type": "short_text"}]
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create", "response": resp.json()}
    
    coll = resp.json()
    cid = coll["id"]
    initial_version = coll["schema_version"]
    print(f"✅ Collection created: schema_version={initial_version}")
    
    # Update fields
    print("\n--- Step 2: Update fields (add new field) ---")
    resp = requests.patch(f"{BASE_URL}/cms/collections/{cid}", json={
        "fields": [
            {"label": "Name", "type": "short_text"},
            {"label": "Email", "type": "email"}
        ]
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "update", "response": resp.json()}
    
    updated = resp.json()
    new_version = updated["schema_version"]
    print(f"✅ Collection updated: schema_version={new_version}")
    
    if new_version != initial_version + 1:
        return {"status": "FAIL", "step": "version_bump", "expected": initial_version + 1, "actual": new_version}
    
    print(f"✅ Schema version correctly bumped from {initial_version} to {new_version}")
    return {"status": "PASS", "collection_id": cid}

def test_invalid_field_type(token):
    """Test that invalid field type returns 400"""
    print("\n" + "="*80)
    print("TEST: Invalid Field Type")
    print("="*80)
    
    headers = {"Authorization": f"Bearer {token}"}
    
    print("\n--- Attempt to create collection with invalid field type ---")
    resp = requests.post(f"{BASE_URL}/cms/collections", json={
        "name": "Invalid Test",
        "fields": [{"label": "Bad Field", "type": "invalid_type_xyz"}]
    }, headers=headers)
    
    print(f"POST /api/cms/collections (invalid field type) → {resp.status_code}")
    print(f"Response: {json.dumps(resp.json(), indent=2)}")
    
    if resp.status_code != 400:
        return {"status": "FAIL", "expected_status": 400, "actual_status": resp.status_code}
    
    print(f"✅ Invalid field type correctly rejected with 400")
    return {"status": "PASS"}

def test_unique_field_duplicate(token):
    """Test that duplicate item with unique field returns 409"""
    print("\n" + "="*80)
    print("TEST: Unique Field Duplicate")
    print("="*80)
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Create collection with unique field
    print("\n--- Step 1: Create collection with unique field ---")
    resp = requests.post(f"{BASE_URL}/cms/collections", json={
        "name": "Unique Test",
        "fields": [
            {"label": "Email", "type": "email", "unique": True},
            {"label": "Name", "type": "short_text"}
        ]
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_collection", "response": resp.json()}
    
    cid = resp.json()["id"]
    print(f"✅ Collection created with unique email field")
    
    # Create first item
    print("\n--- Step 2: Create first item ---")
    test_email = random_email()
    resp = requests.post(f"{BASE_URL}/cms/collections/{cid}/items", json={
        "values": {"email": test_email, "name": "First"}
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_first", "response": resp.json()}
    
    print(f"✅ First item created with email={test_email}")
    
    # Attempt to create duplicate
    print("\n--- Step 3: Attempt to create duplicate (MUST be 409) ---")
    resp = requests.post(f"{BASE_URL}/cms/collections/{cid}/items", json={
        "values": {"email": test_email, "name": "Second"}
    }, headers=headers)
    
    print(f"POST /api/cms/collections/{cid}/items (duplicate email) → {resp.status_code}")
    print(f"Response: {json.dumps(resp.json(), indent=2)}")
    
    if resp.status_code != 409:
        return {"status": "FAIL", "expected_status": 409, "actual_status": resp.status_code}
    
    detail = resp.json().get("detail", {})
    if detail.get("error") != "unique_violation":
        return {"status": "FAIL", "expected_error": "unique_violation", "actual": detail}
    
    print(f"✅ Duplicate unique field correctly rejected with 409 unique_violation")
    return {"status": "PASS"}

def test_csv_import(token):
    """Test CSV import (small CSV creates rows, >5MB => 413)"""
    print("\n" + "="*80)
    print("TEST: CSV Import")
    print("="*80)
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Create collection
    print("\n--- Step 1: Create collection ---")
    resp = requests.post(f"{BASE_URL}/cms/collections", json={
        "name": "CSV Test",
        "fields": [
            {"label": "Name", "type": "short_text"},
            {"label": "Email", "type": "email"}
        ]
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_collection", "response": resp.json()}
    
    cid = resp.json()["id"]
    print(f"✅ Collection created")
    
    # Test small CSV
    print("\n--- Step 2: Import small CSV ---")
    small_csv = "Name,Email\nAlice,alice@example.com\nBob,bob@example.com"
    resp = requests.post(f"{BASE_URL}/cms/collections/{cid}/import", json={
        "csv_text": small_csv,
        "mapping": {"Name": "name", "Email": "email"}
    }, headers=headers)
    
    print(f"POST /api/cms/collections/{cid}/import (small CSV) → {resp.status_code}")
    print(f"Response: {json.dumps(resp.json(), indent=2)}")
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "small_csv", "response": resp.json()}
    
    result = resp.json()
    if result.get("created") != 2:
        return {"status": "FAIL", "step": "created_count", "expected": 2, "actual": result.get("created")}
    
    print(f"✅ Small CSV imported: created={result['created']} items")
    
    # Test large CSV (>5MB)
    print("\n--- Step 3: Attempt to import >5MB CSV (MUST be 413) ---")
    # Create a CSV that's >5MB
    large_csv = "Name,Email\n" + ("Test,test@example.com\n" * 300000)  # ~6MB
    resp = requests.post(f"{BASE_URL}/cms/collections/{cid}/import", json={
        "csv_text": large_csv,
        "mapping": {"Name": "name", "Email": "email"}
    }, headers=headers)
    
    print(f"POST /api/cms/collections/{cid}/import (>5MB CSV) → {resp.status_code}")
    
    if resp.status_code != 413:
        return {"status": "FAIL", "expected_status": 413, "actual_status": resp.status_code}
    
    try:
        detail = resp.json().get("detail", {})
        if isinstance(detail, dict) and detail.get("error") != "csv_too_large":
            return {"status": "FAIL", "expected_error": "csv_too_large", "actual": detail}
    except:
        # 413 response may not have JSON body, which is acceptable
        pass
    
    print(f"✅ Large CSV correctly rejected with 413 csv_too_large")
    return {"status": "PASS"}

def test_template_route_conflict(token):
    """Test that duplicate route_base per site returns 409"""
    print("\n" + "="*80)
    print("TEST: Template Route Conflict")
    print("="*80)
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Create collection
    print("\n--- Step 1: Create collection ---")
    resp = requests.post(f"{BASE_URL}/cms/collections", json={
        "name": "Route Test",
        "fields": [{"label": "Name", "type": "short_text"}]
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_collection", "response": resp.json()}
    
    cid = resp.json()["id"]
    print(f"✅ Collection created")
    
    # Create first template
    print("\n--- Step 2: Create first template ---")
    route_base = f"test-route-{random.randint(1000, 9999)}"
    resp = requests.post(f"{BASE_URL}/cms/templates", json={
        "collection_id": cid,
        "site_slug": DEMO_SITE_SLUG,
        "route_base": route_base
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_first_template", "response": resp.json()}
    
    print(f"✅ First template created with route_base={route_base}")
    
    # Attempt to create duplicate
    print("\n--- Step 3: Attempt to create duplicate route_base (MUST be 409) ---")
    resp = requests.post(f"{BASE_URL}/cms/templates", json={
        "collection_id": cid,
        "site_slug": DEMO_SITE_SLUG,
        "route_base": route_base
    }, headers=headers)
    
    print(f"POST /api/cms/templates (duplicate route_base) → {resp.status_code}")
    print(f"Response: {json.dumps(resp.json(), indent=2)}")
    
    if resp.status_code != 409:
        return {"status": "FAIL", "expected_status": 409, "actual_status": resp.status_code}
    
    detail = resp.json().get("detail", {})
    if detail.get("error") != "route_conflict":
        return {"status": "FAIL", "expected_error": "route_conflict", "actual": detail}
    
    print(f"✅ Duplicate route_base correctly rejected with 409 route_conflict")
    return {"status": "PASS"}

def test_private_field_stripping(token):
    """Test that public endpoints strip private fields"""
    print("\n" + "="*80)
    print("TEST: Private Field Stripping")
    print("="*80)
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Create collection with private field
    print("\n--- Step 1: Create collection with private field ---")
    resp = requests.post(f"{BASE_URL}/cms/collections", json={
        "name": "Private Test",
        "fields": [
            {"label": "Name", "type": "short_text", "searchable": True},
            {"label": "Email", "type": "email", "private": True},
            {"label": "Phone", "type": "phone", "private": True}
        ]
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_collection", "response": resp.json()}
    
    coll = resp.json()
    cid = coll["id"]
    print(f"✅ Collection created with private fields: email, phone")
    
    # Create item
    print("\n--- Step 2: Create item with private data ---")
    resp = requests.post(f"{BASE_URL}/cms/collections/{cid}/items", json={
        "values": {
            "name": "John Doe",
            "email": "john@secret.com",
            "phone": "+15551234567"
        },
        "status": "published"
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_item", "response": resp.json()}
    
    item = resp.json()
    item_slug = item["slug"]
    print(f"✅ Item created with private data")
    
    # Create and publish template
    print("\n--- Step 3: Create and publish template ---")
    route_base = f"private-test-{random.randint(1000, 9999)}"
    resp = requests.post(f"{BASE_URL}/cms/templates", json={
        "collection_id": cid,
        "site_slug": DEMO_SITE_SLUG,
        "route_base": route_base,
        "slug_field": "slug"
    }, headers=headers)
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "create_template", "response": resp.json()}
    
    tid = resp.json()["id"]
    
    resp = requests.patch(f"{BASE_URL}/cms/templates/{tid}", json={"status": "published"}, headers=headers)
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "publish_template", "response": resp.json()}
    
    print(f"✅ Template published")
    
    # Test public detail endpoint
    print("\n--- Step 4: Test public detail endpoint (MUST strip private fields) ---")
    resp = requests.get(f"{BASE_URL}/public/cms/{DEMO_SITE_SLUG}/{route_base}/{item_slug}")
    
    print(f"GET /api/public/cms/{DEMO_SITE_SLUG}/{route_base}/{item_slug} → {resp.status_code}")
    print(f"Response: {json.dumps(resp.json(), indent=2)}")
    
    if resp.status_code != 200:
        return {"status": "FAIL", "step": "public_detail", "response": resp.json()}
    
    detail = resp.json()
    item_values = detail.get("item", {}).get("values", {})
    
    # Check that private fields are NOT present
    if "email" in item_values:
        return {"status": "FAIL", "step": "email_not_stripped", "values": item_values}
    
    if "phone" in item_values:
        return {"status": "FAIL", "step": "phone_not_stripped", "values": item_values}
    
    # Check that public field IS present
    if "name" not in item_values:
        return {"status": "FAIL", "step": "name_missing", "values": item_values}
    
    print(f"✅ Private fields correctly stripped from public endpoint")
    print(f"   Public values: {list(item_values.keys())}")
    return {"status": "PASS"}

def test_sitemap(token):
    """Test that sitemap includes dynamic page URLs"""
    print("\n" + "="*80)
    print("TEST: Sitemap Includes Dynamic Pages")
    print("="*80)
    
    # Note: This test assumes there are already published templates from previous tests
    print("\n--- Test sitemap.xml ---")
    resp = requests.get(f"{BASE_URL}/public/sites/{DEMO_SITE_SLUG}/sitemap.xml")
    
    print(f"GET /api/public/sites/{DEMO_SITE_SLUG}/sitemap.xml → {resp.status_code}")
    
    if resp.status_code != 200:
        return {"status": "FAIL", "status_code": resp.status_code, "response": resp.text[:500]}
    
    sitemap_xml = resp.text
    print(f"Sitemap length: {len(sitemap_xml)} bytes")
    
    # Check if sitemap contains dynamic page URLs
    # Look for /site/{slug}/{route_base}/ pattern
    if f"/site/{DEMO_SITE_SLUG}/" in sitemap_xml:
        print(f"✅ Sitemap contains dynamic page URLs")
        # Count how many dynamic URLs
        count = sitemap_xml.count(f"/site/{DEMO_SITE_SLUG}/")
        print(f"   Found {count} dynamic page URL(s)")
        return {"status": "PASS", "dynamic_urls_count": count}
    else:
        print(f"⚠️  Sitemap does not contain dynamic page URLs (may be expected if no published templates)")
        return {"status": "PASS", "note": "No dynamic URLs found (may be expected)"}

def main():
    """Run all supplementary tests"""
    print("="*80)
    print("CMS SUPPLEMENTARY BACKEND TESTS")
    print("="*80)
    
    token = login_owner()
    if not token:
        print("\n❌ FATAL: Could not login as owner")
        return
    
    results = {}
    
    # Test 1: Schema version bump
    try:
        results["schema_version_bump"] = test_schema_version_bump(token)
    except Exception as e:
        results["schema_version_bump"] = {"status": "ERROR", "error": str(e)}
    
    # Test 2: Invalid field type
    try:
        results["invalid_field_type"] = test_invalid_field_type(token)
    except Exception as e:
        results["invalid_field_type"] = {"status": "ERROR", "error": str(e)}
    
    # Test 3: Unique field duplicate
    try:
        results["unique_field_duplicate"] = test_unique_field_duplicate(token)
    except Exception as e:
        results["unique_field_duplicate"] = {"status": "ERROR", "error": str(e)}
    
    # Test 4: CSV import
    try:
        results["csv_import"] = test_csv_import(token)
    except Exception as e:
        results["csv_import"] = {"status": "ERROR", "error": str(e)}
    
    # Test 5: Template route conflict
    try:
        results["template_route_conflict"] = test_template_route_conflict(token)
    except Exception as e:
        results["template_route_conflict"] = {"status": "ERROR", "error": str(e)}
    
    # Test 6: Private field stripping
    try:
        results["private_field_stripping"] = test_private_field_stripping(token)
    except Exception as e:
        results["private_field_stripping"] = {"status": "ERROR", "error": str(e)}
    
    # Test 7: Sitemap
    try:
        results["sitemap"] = test_sitemap(token)
    except Exception as e:
        results["sitemap"] = {"status": "ERROR", "error": str(e)}
    
    # Print summary
    print("\n" + "="*80)
    print("SUPPLEMENTARY TEST SUMMARY")
    print("="*80)
    
    for test_name, result in results.items():
        status = result.get("status", "UNKNOWN")
        emoji = "✅" if status == "PASS" else "❌"
        print(f"{emoji} {test_name.upper()}: {status}")
        if status != "PASS":
            print(f"   Details: {json.dumps(result, indent=2)}")
    
    passed = sum(1 for r in results.values() if r.get("status") == "PASS")
    failed = sum(1 for r in results.values() if r.get("status") == "FAIL")
    errors = sum(1 for r in results.values() if r.get("status") == "ERROR")
    
    print(f"\nTotal: {passed} PASS, {failed} FAIL, {errors} ERROR out of {len(results)} tests")
    
    return results

if __name__ == "__main__":
    main()
