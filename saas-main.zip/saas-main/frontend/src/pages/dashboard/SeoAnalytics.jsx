import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Search, Chrome, Facebook, MessageSquare, Zap, EyeOff, Activity, BarChart3 } from "lucide-react";

const PIXEL_META = {
    ga4_id:              { label: "Google Analytics 4", placeholder: "G-XXXXXXX", icon: Chrome,        get: "https://analytics.google.com/ → Admin → Data streams → Web → Measurement ID" },
    gtm_id:              { label: "Google Tag Manager", placeholder: "GTM-XXXXX", icon: Chrome,        get: "https://tagmanager.google.com/ → your container → Container ID" },
    meta_pixel_id:       { label: "Meta / Facebook Pixel", placeholder: "1234567890", icon: Facebook, get: "https://business.facebook.com/events_manager/ → Data sources → Pixel ID" },
    tiktok_pixel_id:     { label: "TikTok Pixel", placeholder: "CXXXXXXXXX", icon: MessageSquare,     get: "https://ads.tiktok.com/i18n/events_manager/ → Web Events → Pixel Code" },
    hotjar_id:           { label: "Hotjar", placeholder: "1234567", icon: Activity,                    get: "https://insights.hotjar.com/ → Sites & Organizations → Site ID" },
    linkedin_partner_id: { label: "LinkedIn Insight", placeholder: "1234567", icon: Zap,               get: "https://www.linkedin.com/campaignmanager/ → Analyze → Insight Tag → Partner ID" },
    pinterest_tag_id:    { label: "Pinterest Tag", placeholder: "2612345678901", icon: Zap,           get: "https://ads.pinterest.com/ → Conversions → Pinterest Tag ID" },
};

export default function SeoAnalytics() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [seo, setSeo] = useState({});
    const [pixels, setPixels] = useState({});
    const [allowIndexing, setAllowIndexing] = useState(true);
    const [slug, setSlug] = useState(null);
    const [stats, setStats] = useState(null);

    useEffect(() => {
        (async () => {
            try {
                const [seoRes, statsRes] = await Promise.allSettled([
                    api.get("/tenant/website/seo-and-pixels"),
                    api.get("/tenant/website/analytics"),
                ]);
                if (seoRes.status === "fulfilled") {
                    setSeo(seoRes.value.data.seo_defaults || {});
                    setPixels(seoRes.value.data.pixels || {});
                    setAllowIndexing(seoRes.value.data.allow_indexing !== false);
                    setSlug(seoRes.value.data.slug);
                }
                if (statsRes.status === "fulfilled") setStats(statsRes.value.data);
            } catch (e) { /* silent */ }
            finally { setLoading(false); }
        })();
    }, []);

    async function save() {
        setSaving(true);
        try {
            await api.patch("/tenant/website/seo-and-pixels", {
                seo_defaults: seo, pixels, allow_indexing: allowIndexing,
            });
            toast.success("SEO & pixel settings saved");
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Save failed");
        } finally { setSaving(false); }
    }

    if (loading) return <div className="p-10 text-zinc-500">Loading SEO & analytics…</div>;

    return (
        <div className="p-6 md:p-10" data-testid="seo-page">
            <div className="max-w-5xl">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">SEO & Analytics</div>
                <h1 className="font-display text-3xl text-brand-ink">Own your search presence and your data.</h1>
                <p className="mt-3 text-zinc-600 max-w-2xl">
                    Set default title/description, connect your analytics pixels, and control whether search
                    engines index your site.
                </p>

                {/* Live stats */}
                <div className="mt-8 grid sm:grid-cols-3 gap-4" data-testid="seo-stats">
                    <StatCard label="Total pageviews" value={stats?.totals?.pageviews ?? 0} icon={BarChart3} />
                    <StatCard label={`Views (last ${stats?.days || 30}d)`} value={stats?.recent?.pageviews ?? 0} icon={Activity} />
                    <StatCard label="Form submissions" value={stats?.totals?.form_submits ?? 0} icon={Zap} />
                </div>

                {slug && (
                    <div className="mt-4 text-sm text-zinc-500">
                        Public site: <a className="underline hover:text-brand-copper" href={`/site/${slug}`} target="_blank" rel="noreferrer">/site/{slug}</a> ·{" "}
                        Sitemap: <a className="underline hover:text-brand-copper" target="_blank" rel="noreferrer"
                                    href={`${process.env.REACT_APP_BACKEND_URL}/api/public/sites/${slug}/sitemap.xml`}>sitemap.xml</a>
                    </div>
                )}

                {/* SEO defaults */}
                <div className="mt-10 rounded-2xl border border-brand-line bg-white p-6">
                    <div className="flex items-center gap-2 text-brand-ink font-medium">
                        <Search className="w-4 h-4 text-brand-copper" /> Default SEO
                    </div>
                    <p className="text-sm text-zinc-500 mt-1">Applied to any page that doesn't set its own SEO in the editor.</p>
                    <div className="mt-5 grid md:grid-cols-2 gap-4">
                        <TextField label="Title template" placeholder="{page} — Your Business"
                                    value={seo.title_template || ""}
                                    onChange={(v) => setSeo({ ...seo, title_template: v })}
                                    testid="seo-title-template" />
                        <TextField label="Default description" placeholder="A short sentence that appears under your site name in Google."
                                    value={seo.description || ""}
                                    onChange={(v) => setSeo({ ...seo, description: v })}
                                    testid="seo-description" />
                        <TextField label="Social share image URL" placeholder="https://…/og.jpg"
                                    value={seo.og_image || ""}
                                    onChange={(v) => setSeo({ ...seo, og_image: v })}
                                    testid="seo-og-image" />
                        <TextField label="Favicon URL" placeholder="https://…/favicon.ico"
                                    value={seo.favicon_url || ""}
                                    onChange={(v) => setSeo({ ...seo, favicon_url: v })}
                                    testid="seo-favicon" />
                    </div>
                    <div className="mt-5 flex items-center gap-3">
                        <label className="inline-flex items-center gap-2 text-sm text-zinc-700 cursor-pointer" data-testid="seo-allow-indexing">
                            <input type="checkbox" checked={allowIndexing}
                                    onChange={(e) => setAllowIndexing(e.target.checked)} />
                            Allow search engines (Google, Bing) to index this site
                        </label>
                        {!allowIndexing && <span className="inline-flex items-center gap-1 text-xs text-amber-700 bg-amber-50 px-2 py-1 rounded"><EyeOff className="w-3 h-3" /> Site is hidden from search</span>}
                    </div>
                </div>

                {/* Pixels */}
                <div className="mt-6 rounded-2xl border border-brand-line bg-white p-6">
                    <div className="flex items-center gap-2 text-brand-ink font-medium">
                        <Activity className="w-4 h-4 text-brand-copper" /> Analytics pixels
                    </div>
                    <p className="text-sm text-zinc-500 mt-1">Connect the tracking tools you already use. IDs are safe to expose; they're loaded on the public site only.</p>
                    <div className="mt-5 grid md:grid-cols-2 gap-4">
                        {Object.entries(PIXEL_META).map(([key, meta]) => {
                            const Icon = meta.icon;
                            return (
                                <div key={key} className="rounded-xl border border-brand-line/70 p-4">
                                    <div className="flex items-center gap-2">
                                        <Icon className="w-4 h-4 text-brand-copper" />
                                        <div className="text-sm font-medium text-brand-ink">{meta.label}</div>
                                    </div>
                                    <input type="text" placeholder={meta.placeholder}
                                           value={pixels[key] || ""}
                                           onChange={(e) => setPixels({ ...pixels, [key]: e.target.value })}
                                           data-testid={`pixel-${key}`}
                                           className="mt-2 w-full border border-brand-line rounded-md px-3 py-2 text-sm" />
                                    <p className="mt-2 text-[11px] text-zinc-500">Where to get it: {meta.get}</p>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Per-page views */}
                {stats?.by_page?.length > 0 && (
                    <div className="mt-6 rounded-2xl border border-brand-line bg-white p-6" data-testid="seo-by-page">
                        <div className="flex items-center gap-2 text-brand-ink font-medium">
                            <BarChart3 className="w-4 h-4 text-brand-copper" /> Top pages
                        </div>
                        <div className="mt-4 divide-y divide-brand-line">
                            {stats.by_page.map((r) => (
                                <div key={r.page_slug || "home"} className="py-2 flex items-center justify-between text-sm">
                                    <span className="text-zinc-700">/{r.page_slug || "home"}</span>
                                    <span className="text-zinc-500 font-mono">{r.views}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                <div className="mt-8 flex items-center gap-3 sticky bottom-6">
                    <Button onClick={save} disabled={saving}
                            data-testid="seo-save-btn"
                            className="bg-brand-copper hover:bg-brand-copperHover text-white shadow-lg">
                        {saving ? "Saving…" : "Save changes"}
                    </Button>
                </div>
            </div>
        </div>
    );
}

function TextField({ label, placeholder, value, onChange, testid }) {
    return (
        <div>
            <label className="text-xs text-zinc-500">{label}</label>
            <input type="text" placeholder={placeholder} value={value}
                    onChange={(e) => onChange(e.target.value)}
                    data-testid={testid}
                    className="mt-1 w-full border border-brand-line rounded-md px-3 py-2 text-sm" />
        </div>
    );
}

function StatCard({ label, value, icon: Icon }) {
    return (
        <div className="rounded-2xl border border-brand-line bg-white p-4">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-brand-copper">
                <Icon className="w-3.5 h-3.5" /> {label}
            </div>
            <div className="mt-2 font-display text-3xl text-brand-ink">{Number(value).toLocaleString()}</div>
        </div>
    );
}
