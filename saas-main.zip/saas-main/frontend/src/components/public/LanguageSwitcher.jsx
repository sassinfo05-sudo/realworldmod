import { useEffect, useRef, useState } from "react";
import api from "@/lib/api";
import { Globe } from "lucide-react";

/**
 * Public storefront / site language switcher.
 * - Reads the tenant's enabled languages from GET /api/public/localization/{orgId}/settings
 *   (renders nothing when the owner hasn't enabled languages).
 * - On change, walks visible text nodes inside `containerRef`, translates them in batches via the
 *   public translate endpoint (metered against the tenant, cached server-side + localStorage) and
 *   swaps the text in place. Switching back to the default restores the originals.
 * - Sets dir="rtl" + lang on the container for Hebrew / Arabic.
 */
const RTL = new Set(["he", "ar"]);
const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "CODE", "PRE", "SVG"]);

function cacheKey(orgId, lang, text) { return `zt:${orgId}:${lang}:${text}`; }

export default function LanguageSwitcher({ orgId, containerRef, className = "" }) {
    const [settings, setSettings] = useState(null);
    const [lang, setLang] = useState(null);
    const [busy, setBusy] = useState(false);
    const originals = useRef(new Map()); // Text node -> original string
    const overridesRef = useRef(new Map()); // lang -> {source: authoredTranslation}

    useEffect(() => {
        if (!orgId) return;
        api.get(`/public/localization/${orgId}/settings`).then((r) => {
            setSettings(r.data);
            const saved = localStorage.getItem(`zlang:${orgId}`);
            const def = r.data?.default_language || "en";
            setLang(saved && (r.data?.languages || []).some((l) => l.code === saved) ? saved : def);
        }).catch(() => setSettings({ enabled: false }));
    }, [orgId]);

    function collectNodes() {
        const root = containerRef?.current || document.body;
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(n) {
                const t = n.nodeValue; if (!t || !t.trim() || t.trim().length < 2) return NodeFilter.FILTER_REJECT;
                const p = n.parentElement; if (!p || SKIP_TAGS.has(p.tagName)) return NodeFilter.FILTER_REJECT;
                if (p.closest("[data-no-translate]")) return NodeFilter.FILTER_REJECT;
                if (/^[\d\s.,:;$€£₪%()+-]+$/.test(t.trim())) return NodeFilter.FILTER_REJECT; // numbers / prices
                return NodeFilter.FILTER_ACCEPT;
            },
        });
        const nodes = []; let n; while ((n = walker.nextNode())) nodes.push(n);
        return nodes;
    }

    async function apply(target) {
        if (!settings?.enabled) return;
        const def = settings.default_language || "en";
        const root = containerRef?.current || document.documentElement;
        setBusy(true);
        try {
            const nodes = collectNodes();
            // remember originals once
            nodes.forEach((n) => { if (!originals.current.has(n)) originals.current.set(n, n.nodeValue); });
            if (target === def) {
                originals.current.forEach((orig, node) => { node.nodeValue = orig; });
            } else {
                // Owner-authored translations override machine translation, keyed by source string.
                let overrides = overridesRef.current.get(target);
                if (!overrides) {
                    try {
                        const { data } = await api.get(`/public/localization/${orgId}/overrides`, { params: { lang: target } });
                        overrides = data?.entries || {};
                    } catch { overrides = {}; }
                    overridesRef.current.set(target, overrides);
                }
                const texts = nodes.map((n) => (originals.current.get(n) || n.nodeValue));
                const trimmed = texts.map((t) => t.trim());
                const unique = [...new Set(trimmed)];
                const result = new Map();
                const missing = [];
                unique.forEach((t) => {
                    if (overrides[t]) { result.set(t, overrides[t]); return; } // authored wins
                    const c = localStorage.getItem(cacheKey(orgId, target, t)); if (c) result.set(t, c); else missing.push(t);
                });
                for (let i = 0; i < missing.length; i += 40) {
                    const batch = missing.slice(i, i + 40);
                    const { data } = await api.post(`/public/localization/${orgId}/translate`, { texts: batch, target, source: def });
                    if (data?.over_limit) break;
                    (data?.translations || []).forEach((tr, j) => { result.set(batch[j], tr); try { localStorage.setItem(cacheKey(orgId, target, batch[j]), tr); } catch { /* quota */ } });
                }
                nodes.forEach((n, i) => {
                    const orig = texts[i]; const tr = result.get(orig.trim());
                    if (tr) n.nodeValue = orig.replace(orig.trim(), tr);
                });
            }
            root.setAttribute("dir", RTL.has(target) ? "rtl" : "ltr");
            root.setAttribute("lang", target);
            localStorage.setItem(`zlang:${orgId}`, target);
            setLang(target);
        } finally { setBusy(false); }
    }

    // Apply a remembered non-default language once content has rendered.
    useEffect(() => {
        if (settings?.enabled && lang && lang !== (settings.default_language || "en")) {
            const t = setTimeout(() => apply(lang), 400); return () => clearTimeout(t);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [settings, lang]);

    if (!settings?.enabled || !(settings.languages || []).length) return null;
    return (
        <label className={`inline-flex items-center gap-1.5 text-sm ${className}`} data-no-translate data-testid="language-switcher">
            <Globe className="w-4 h-4 text-zinc-500" aria-hidden="true" />
            <span className="sr-only">Language</span>
            <select aria-label="Choose language" value={lang || ""} disabled={busy} onChange={(e) => apply(e.target.value)}
                    className="bg-transparent border border-brand-line rounded-md px-2 py-1 text-sm text-zinc-700 focus:outline-none focus:ring-2 focus:ring-brand-copper"
                    data-testid="language-select">
                {settings.languages.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
            </select>
            {busy && <span className="text-xs text-zinc-400">…</span>}
        </label>
    );
}
