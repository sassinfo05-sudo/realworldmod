# Deployment

## What's here
- Backend: FastAPI + Motor + uvicorn on `0.0.0.0:8001` (supervisor-managed).
- Frontend: React (yarn) hot-reload dev server on `:3000`.
- MongoDB via `MONGO_URL`.
- Kubernetes ingress rewrites `/api/*` → backend, everything else → frontend.

## Rules
1. Never start your own server — supervisor handles it. Restart on `.env` change:  
   `sudo supervisorctl restart backend` / `sudo supervisorctl restart frontend`.
2. **All backend routes MUST live under `/api`.** Ingress will not route them otherwise.
3. Frontend must always call `${process.env.REACT_APP_BACKEND_URL}/api/…`.
4. `MONGO_URL` and `DB_NAME` in `backend/.env` are set by the platform — do not overwrite.
5. Never use npm. Yarn only.

## Local restart quickstart
```bash
sudo supervisorctl restart backend
sudo supervisorctl restart frontend
tail -n 100 /var/log/supervisor/backend.err.log
```

## Deploy readiness
Before deploy:
- `deployment_agent` static check (hardcoded secrets, ports, CORS, compile errors).
- `sudo supervisorctl status` returns both services RUNNING.
- `GET /api/health` returns `{"ok": true}`.
- `GET /api/openapi.json` accessible.
