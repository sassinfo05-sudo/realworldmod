"""Phase 2 backend E2E tests: editor, publish/rollback, domains, forms, analytics, import, isolation."""
import os
import time
import uuid
import pytest
import requests
from tests import _creds as _CREDS  # creds from env / test_credentials.md

BASE_URL = _CREDS.BASE_URL
API = _CREDS.API

OWNER_EMAIL = _CREDS.OWNER_EMAIL
OWNER_PASSWORD = _CREDS.OWNER_PASSWORD


# ---------------- fixtures ----------------

@pytest.fixture(scope="module")
def owner_token():
    r = requests.post(f"{API}/auth/login", json={"email": OWNER_EMAIL, "password": OWNER_PASSWORD}, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def owner_headers(owner_token):
    return {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def other_org():
    """Fresh signup — used for isolation checks."""
    email = f"iso_{uuid.uuid4().hex[:10]}@example.com"
    r = requests.post(f"{API}/auth/signup", json={
        "email": email, "password": "TestPass!23",
        "full_name": "Iso Tester", "business_name": "Iso Test Biz"
    }, timeout=15)
    assert r.status_code == 200, r.text
    tok = r.json()["access_token"]
    return {"email": email, "token": tok, "headers": {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}}


@pytest.fixture(scope="module")
def demo_website(owner_headers):
    r = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["website"]


# ---------------- basic state ----------------

class TestEditorState:
    def test_get_editor_state(self, owner_headers):
        r = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15)
        assert r.status_code == 200
        d = r.json()
        w = d["website"]
        assert w["slug"] == "demo-home-services"
        assert w["status"] == "published"
        assert len(w["pages"]) == 4
        assert d["public_url_path"] == "/site/demo-home-services"

    def test_block_library(self, owner_headers):
        r = requests.get(f"{API}/editor/block-library", headers=owner_headers, timeout=15)
        assert r.status_code == 200
        blocks = r.json()["blocks"]
        assert len(blocks) >= 12
        for b in blocks:
            assert "type" in b and "variant" in b and "label" in b

    def test_revisions_initial(self, owner_headers):
        r = requests.get(f"{API}/editor/website/revisions", headers=owner_headers, timeout=15)
        assert r.status_code == 200
        revs = r.json()["revisions"]
        assert len(revs) >= 1


# ---------------- draft vs published ----------------

class TestDraftVsPublished:
    def test_snapshot_set_does_not_leak_to_live(self, owner_headers, demo_website):
        # Load current draft
        r = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15)
        w = r.json()["website"]
        # Save original published state
        pub_before = requests.get(f"{API}/public/sites/demo-home-services", timeout=15).json()
        orig_pub_theme = pub_before["theme"]["primary"]
        orig_pub_headline = pub_before["pages"][0]["blocks"][0]["props"].get("headline")

        # Modify draft: change theme.primary and first hero headline
        new_theme = {**w["theme"], "primary": "#000000"}
        new_pages = [dict(p) for p in w["pages"]]
        # find home page
        home_idx = next(i for i, p in enumerate(new_pages) if p["slug"] == "home")
        home = dict(new_pages[home_idx])
        blocks = [dict(b) for b in home["blocks"]]
        blocks[0] = {**blocks[0], "props": {**blocks[0]["props"], "headline": "AUTOSAVE TEST HEADLINE"}}
        home["blocks"] = blocks
        new_pages[home_idx] = home

        r2 = requests.post(f"{API}/editor/website/snapshot-set",
                           headers=owner_headers,
                           json={"theme": new_theme, "pages": new_pages, "nav_order": w["nav_order"]},
                           timeout=15)
        assert r2.status_code == 200, r2.text

        # Draft should reflect changes
        r3 = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15)
        w3 = r3.json()["website"]
        assert w3["theme"]["primary"] == "#000000"
        home3 = next(p for p in w3["pages"] if p["slug"] == "home")
        assert home3["blocks"][0]["props"]["headline"] == "AUTOSAVE TEST HEADLINE"

        # Public should NOT
        r4 = requests.get(f"{API}/public/sites/demo-home-services", timeout=15)
        assert r4.status_code == 200
        pub = r4.json()
        assert pub["theme"]["primary"] == orig_pub_theme, "Draft leaked to published theme!"
        pub_home = next(p for p in pub["pages"] if p["slug"] == "home")
        assert pub_home["blocks"][0]["props"].get("headline") == orig_pub_headline, "Draft leaked to published pages!"


# ---------------- publish + rollback ----------------

class TestPublishRollback:
    def test_publish_then_rollback(self, owner_headers):
        # Publish current draft (which has AUTOSAVE TEST HEADLINE)
        r = requests.post(f"{API}/editor/website/publish", headers=owner_headers,
                          json={"note": "test publish"}, timeout=20)
        assert r.status_code == 200, r.text
        pub_rev_id = r.json()["revision_id"]

        # Live must now show new state
        pub = requests.get(f"{API}/public/sites/demo-home-services", timeout=15).json()
        assert pub["theme"]["primary"] == "#000000"
        pub_home = next(p for p in pub["pages"] if p["slug"] == "home")
        assert pub_home["blocks"][0]["props"]["headline"] == "AUTOSAVE TEST HEADLINE"

        # Revisions increased, top should be publish kind
        revs = requests.get(f"{API}/editor/website/revisions", headers=owner_headers, timeout=15).json()["revisions"]
        assert any(rv["id"] == pub_rev_id and rv["kind"] == "publish" for rv in revs)

        # Pick the OLDEST publish (before AUTOSAVE change) — it's the last item sorted desc
        publish_revs = [rv for rv in revs if rv["kind"] == "publish"]
        oldest = publish_revs[-1]
        assert oldest["id"] != pub_rev_id

        # Rollback to oldest
        r2 = requests.post(f"{API}/editor/website/revisions/{oldest['id']}/rollback",
                           headers=owner_headers, json={"note": "rollback test"}, timeout=20)
        assert r2.status_code == 200, r2.text
        new_rev_id = r2.json()["new_revision_id"]

        # New revision should have kind='rollback' and rolled_back_from_id = oldest['id']
        revs2 = requests.get(f"{API}/editor/website/revisions", headers=owner_headers, timeout=15).json()["revisions"]
        new_rev = next((rv for rv in revs2 if rv["id"] == new_rev_id), None)
        assert new_rev is not None
        assert new_rev["kind"] == "rollback"
        assert new_rev["rolled_back_from_id"] == oldest["id"]

        # Live public must now reflect old content
        pub2 = requests.get(f"{API}/public/sites/demo-home-services", timeout=15).json()
        pub2_home = next(p for p in pub2["pages"] if p["slug"] == "home")
        assert pub2_home["blocks"][0]["props"].get("headline") != "AUTOSAVE TEST HEADLINE"

        # Draft too
        w = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15).json()["website"]
        home = next(p for p in w["pages"] if p["slug"] == "home")
        assert home["blocks"][0]["props"].get("headline") != "AUTOSAVE TEST HEADLINE"


# ---------------- block CRUD + reorder ----------------

class TestBlockCRUD:
    def test_create_reorder_delete_block(self, owner_headers):
        # Create block
        r = requests.post(f"{API}/editor/website/pages/home/blocks",
                          headers=owner_headers,
                          json={"type": "cta_band", "variant": "a",
                                "props": {"headline": "Reorder Test CTA",
                                          "primary_cta": {"label": "Book"}}},
                          timeout=15)
        assert r.status_code == 200, r.text
        new_block = r.json()
        new_id = new_block["id"]

        # Verify appended at end
        w = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15).json()["website"]
        home = next(p for p in w["pages"] if p["slug"] == "home")
        assert home["blocks"][-1]["id"] == new_id
        block_ids = [b["id"] for b in home["blocks"]]
        assert len(block_ids) >= 2

        # Reverse
        reversed_ids = list(reversed(block_ids))
        r2 = requests.post(f"{API}/editor/website/pages/home/reorder",
                           headers=owner_headers, json={"block_ids": reversed_ids}, timeout=15)
        assert r2.status_code == 200
        assert r2.json()["block_order"] == reversed_ids

        # Verify persisted
        w2 = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15).json()["website"]
        home2 = next(p for p in w2["pages"] if p["slug"] == "home")
        assert [b["id"] for b in home2["blocks"]] == reversed_ids

        # Delete
        r3 = requests.delete(f"{API}/editor/website/blocks/{new_id}", headers=owner_headers, timeout=15)
        assert r3.status_code == 200
        w3 = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15).json()["website"]
        home3 = next(p for p in w3["pages"] if p["slug"] == "home")
        assert new_id not in [b["id"] for b in home3["blocks"]]


# ---------------- pages CRUD ----------------

class TestPagesCRUD:
    def test_page_crud(self, owner_headers):
        # Create FAQ page
        r = requests.post(f"{API}/editor/website/pages", headers=owner_headers,
                          json={"title": "FAQ"}, timeout=15)
        assert r.status_code == 200
        assert r.json()["slug"] == "faq"

        w = requests.get(f"{API}/editor/website", headers=owner_headers, timeout=15).json()["website"]
        assert any(p["slug"] == "faq" for p in w["pages"])
        assert "faq" in w["nav_order"]

        # Duplicate
        r2 = requests.post(f"{API}/editor/website/pages/faq/duplicate", headers=owner_headers, timeout=15)
        assert r2.status_code == 200
        assert r2.json()["slug"] == "faq-copy"

        # Delete both
        r3 = requests.delete(f"{API}/editor/website/pages/faq-copy", headers=owner_headers, timeout=15)
        assert r3.status_code == 200
        r4 = requests.delete(f"{API}/editor/website/pages/faq", headers=owner_headers, timeout=15)
        assert r4.status_code == 200


# ---------------- domains ----------------

class TestDomains:
    def test_providers_list(self, owner_headers):
        r = requests.get(f"{API}/domains/providers", headers=owner_headers, timeout=15)
        assert r.status_code == 200
        providers = {p["key"]: p for p in r.json()["providers"]}
        assert "simulated" in providers
        assert providers["simulated"]["is_connected"] is True
        assert "cloudflare" in providers
        assert providers["cloudflare"]["is_connected"] is False
        honest = providers["cloudflare"]["honest_status"]
        assert "Not connected" in honest
        assert "Cloudflare API token" in honest

    def test_domain_wizard_state_machine(self, owner_headers, demo_website):
        hostname = f"test-{uuid.uuid4().hex[:10]}.example.com"
        r = requests.post(f"{API}/domains", headers=owner_headers,
                          json={"hostname": hostname, "website_id": demo_website["id"],
                                "provider": "simulated"}, timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["state"] == "pending"
        assert d["provider_ref"].startswith("sim_")
        # DNS records present
        assert len(d["dns_records"]) >= 1
        cname = next((rec for rec in d["dns_records"] if rec.get("type") == "CNAME"), None)
        assert cname is not None and "zanelvo.com" in cname.get("value", "")
        txt = next((rec for rec in d["dns_records"] if rec.get("type") == "TXT"), None)
        assert txt is not None

        did = d["id"]
        # Poll 1 → verifying
        s1 = requests.get(f"{API}/domains/{did}/status", headers=owner_headers, timeout=15).json()
        assert s1["state"] == "verifying"
        # Poll 2 → verifying still (per prompt)
        s2 = requests.get(f"{API}/domains/{did}/status", headers=owner_headers, timeout=15).json()
        # Poll 3 → connected
        s3 = requests.get(f"{API}/domains/{did}/status", headers=owner_headers, timeout=15).json()
        assert s3["state"] == "connected", f"Expected connected after 3 polls, got {s3['state']}"
        assert s3["ssl_status"] == "active"

        # Host-based routing
        r_host = requests.get(f"{API}/public/sites/by-host", params={"host": hostname}, timeout=15)
        assert r_host.status_code == 200
        assert r_host.json()["slug"] == demo_website["slug"]

        # Set primary
        rp = requests.patch(f"{API}/domains/{did}", headers=owner_headers,
                            json={"primary": True}, timeout=15)
        assert rp.status_code == 200
        assert rp.json()["primary"] is True

        # Delete
        rd = requests.delete(f"{API}/domains/{did}", headers=owner_headers, timeout=15)
        assert rd.status_code == 200

        # List excludes removed
        lst = requests.get(f"{API}/domains", headers=owner_headers, timeout=15).json()["domains"]
        assert not any(x["id"] == did for x in lst)

    def test_invalid_hostname(self, owner_headers, demo_website):
        r = requests.post(f"{API}/domains", headers=owner_headers,
                          json={"hostname": "not a valid hostname!",
                                "website_id": demo_website["id"], "provider": "simulated"}, timeout=15)
        assert r.status_code == 400

    def test_duplicate_hostname(self, owner_headers, demo_website):
        hostname = f"dup-{uuid.uuid4().hex[:10]}.example.com"
        r1 = requests.post(f"{API}/domains", headers=owner_headers,
                           json={"hostname": hostname, "website_id": demo_website["id"], "provider": "simulated"}, timeout=15)
        assert r1.status_code == 200
        r2 = requests.post(f"{API}/domains", headers=owner_headers,
                           json={"hostname": hostname, "website_id": demo_website["id"], "provider": "simulated"}, timeout=15)
        assert r2.status_code == 409
        # cleanup
        did = r1.json()["id"]
        requests.delete(f"{API}/domains/{did}", headers=owner_headers, timeout=15)


# ---------------- public endpoints ----------------

class TestPublicEndpoints:
    def test_public_site(self):
        r = requests.get(f"{API}/public/sites/demo-home-services", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert d["slug"] == "demo-home-services"
        assert "theme" in d and "pages" in d and "nav_order" in d
        assert d["business_name"]

    def test_public_page(self):
        r = requests.get(f"{API}/public/sites/demo-home-services/pages/home", timeout=15)
        assert r.status_code == 200
        assert "site" in r.json() and "page" in r.json()

    def test_sitemap(self):
        r = requests.get(f"{API}/public/sites/demo-home-services/sitemap.xml", timeout=15)
        assert r.status_code == 200
        assert "xml" in r.headers.get("content-type", "").lower()
        assert "/site/demo-home-services" in r.text

    def test_robots(self):
        r = requests.get(f"{API}/public/sites/demo-home-services/robots.txt", timeout=15)
        assert r.status_code == 200
        assert "text/plain" in r.headers.get("content-type", "").lower()
        assert "Sitemap:" in r.text


# ---------------- slug redirect ----------------

class TestSlugRedirect:
    def test_slug_history_redirect(self, owner_headers):
        # publish under a new (valid: 4-12 letters) address; the old slug must redirect
        r = requests.post(f"{API}/editor/website/publish", headers=owner_headers,
                          json={"slug": "demorenamed", "note": "rename test"}, timeout=20)
        assert r.status_code == 200, r.text
        r2 = requests.get(f"{API}/public/sites/demo-home-services", timeout=15)
        assert r2.status_code == 200
        assert "demorenamed" in str(r2.json().get("redirect_to"))
        # Restore the seeded slug directly (the seed slug pre-dates the 4-12 letter rule, so the API
        # would normalize it) — harness-only cleanup.
        import os
        from pymongo import MongoClient
        db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
        db.websites.update_one({"slug": "demorenamed"}, {"$set": {"slug": "demo-home-services"},
                                                          "$addToSet": {"slug_history": "demorenamed"}})
        assert requests.get(f"{API}/public/sites/demo-home-services", timeout=15).json().get("slug") == "demo-home-services"


# ---------------- forms & analytics ----------------

class TestFormsAnalytics:
    def test_form_submission_flow(self, owner_headers, other_org):
        r = requests.post(f"{API}/forms/submit", json={
            "website_slug": "demo-home-services", "page_slug": "contact",
            "fields": {"name": "Test User", "email": "test@example.com", "message": "From form test"}
        }, timeout=15)
        assert r.status_code == 200
        sub_id = r.json()["submission_id"]

        # Owner sees
        subs = requests.get(f"{API}/forms/submissions", headers=owner_headers, timeout=15).json()["submissions"]
        assert any(s["id"] == sub_id for s in subs)

        # Mark read
        rm = requests.post(f"{API}/forms/submissions/{sub_id}/mark-read", headers=owner_headers, timeout=15)
        assert rm.status_code == 200

        # Other org doesn't see
        other_subs = requests.get(f"{API}/forms/submissions", headers=other_org["headers"], timeout=15).json()["submissions"]
        assert not any(s["id"] == sub_id for s in other_subs)

    def test_analytics_track(self, owner_headers):
        r = requests.post(f"{API}/analytics/track",
                          json={"website_slug": "demo-home-services", "kind": "pageview", "page_slug": "home"}, timeout=15)
        assert r.status_code == 200
        summary = requests.get(f"{API}/analytics/summary", headers=owner_headers, timeout=15).json()
        assert summary["totals"]["pageviews"] >= 1
        assert any(x["page_slug"] == "home" for x in summary["by_page"])

    def test_analytics_invalid_kind(self):
        r = requests.post(f"{API}/analytics/track",
                          json={"website_slug": "demo-home-services", "kind": "invalid"}, timeout=15)
        assert r.status_code == 400


# ---------------- multi-tenant isolation ----------------

class TestTenantIsolation:
    def test_other_org_sees_own_website(self, other_org):
        r = requests.get(f"{API}/editor/website", headers=other_org["headers"], timeout=15)
        # Other org may not have a website yet — that's expected 404. Let's check:
        # But signup does NOT auto-create website. Test import flow will make one. Skip if 404.
        if r.status_code == 404:
            pytest.skip("New org has no website yet — expected")
        assert r.status_code == 200
        assert r.json()["website"]["slug"] != "demo-home-services"

    def test_cannot_modify_other_org_block(self, other_org, demo_website):
        # Pick any block id from demo
        home = next(p for p in demo_website["pages"] if p["slug"] == "home")
        target_block_id = home["blocks"][0]["id"]
        r = requests.patch(f"{API}/editor/website/blocks/{target_block_id}",
                           headers=other_org["headers"], json={"props": {"headline": "HAX"}}, timeout=15)
        # No matter what website that org has (or doesn't), the block belongs to demo.
        assert r.status_code == 404

    def test_cannot_bind_domain_to_other_org_site(self, other_org, demo_website):
        hostname = f"iso-{uuid.uuid4().hex[:10]}.example.com"
        r = requests.post(f"{API}/domains", headers=other_org["headers"],
                          json={"hostname": hostname, "website_id": demo_website["id"], "provider": "simulated"}, timeout=15)
        # Free-plan org: the custom-domain entitlement (402) fires before the ownership lookup (404);
        # either way the other org can never bind a domain to our site.
        assert r.status_code in (402, 404)


# ---------------- openapi ----------------

class TestOpenAPI:
    def test_openapi_paths(self):
        r = requests.get(f"{API}/openapi.json", timeout=15)
        assert r.status_code == 200
        data = r.json()
        assert data["info"]["title"] == "Zanelvo API"
        paths = data["paths"]
        for p in [
            "/api/editor/website",
            "/api/editor/website/publish",
            "/api/editor/website/revisions",
            "/api/editor/website/revisions/{rev_id}/rollback",
            "/api/public/sites/by-host",
            "/api/domains",
            "/api/domains/providers",
            "/api/domains/{domain_id}/status",
            "/api/forms/submit",
            "/api/analytics/track",
            "/api/import/start",
        ]:
            assert p in paths, f"Missing path {p}"


# ---------------- import flow ----------------

class TestImport:
    def test_import_start_and_poll(self, other_org):
        r = requests.post(f"{API}/import/start", headers=other_org["headers"],
                          json={"source_url": "https://example.com"}, timeout=15)
        assert r.status_code == 200
        run_id = r.json()["import_run_id"]

        # Poll up to 60s
        status = None
        for _ in range(30):
            time.sleep(2)
            rr = requests.get(f"{API}/import/runs/{run_id}", headers=other_org["headers"], timeout=15)
            assert rr.status_code == 200
            status = rr.json()["status"]
            if status in ("ready", "failed"):
                break
        assert status in ("ready", "failed"), f"Import stuck in {status}"
        if status == "failed":
            pytest.skip(f"Import LLM failed (P1): {rr.json().get('error')}")
        data = rr.json()
        assert data.get("extracted_facts")
        assert data.get("planned_redirects")

        # List
        lst = requests.get(f"{API}/import/runs", headers=other_org["headers"], timeout=15).json()["runs"]
        assert any(x["id"] == run_id for x in lst)

    def test_cannot_read_other_org_import_run(self, other_org, owner_headers):
        # Start a run as other_org, ensure owner can't read
        r = requests.post(f"{API}/import/start", headers=other_org["headers"],
                          json={"source_url": "https://example.org"}, timeout=20)
        if r.status_code != 200:
            # transient (rate limit / warmup under full-suite load) — retry once
            time.sleep(2)
            r = requests.post(f"{API}/import/start", headers=other_org["headers"],
                              json={"source_url": "https://example.org"}, timeout=20)
        assert r.status_code == 200, f"import/start failed: {r.status_code} {r.text}"
        run_id = r.json()["import_run_id"]
        # THE ISOLATION INVARIANT (hard — never relaxed): another org's owner cannot read it.
        r2 = requests.get(f"{API}/import/runs/{run_id}", headers=owner_headers, timeout=15)
        assert r2.status_code == 404
