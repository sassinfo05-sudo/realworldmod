"""Deterministic test: outbound-webhook durable retries → dead-letter → replay.

Offline (uses a private URL that netsafe rejects, so no real HTTP is made).
Run: cd /app/backend && python tests/test_webhook_retry.py
"""
import asyncio
import os
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))
except Exception:  # noqa: BLE001
    pass

from app.db import get_db, utc_now_iso  # noqa: E402
from app.services import webhooks as wh, secretbox  # noqa: E402


async def main():
    db = get_db()
    org = f"wh-{uuid.uuid4()}"
    wid = uuid.uuid4().hex
    await db.webhooks.insert_one({
        "_id": wid, "org_id": org, "active": True, "events": ["*"],
        "url": "http://127.0.0.1:9/hook",              # private → netsafe rejects → offline fail
        "secret_enc": secretbox.encrypt("whsec_test_secret")})
    did = uuid.uuid4().hex
    import base64
    body = b'{"event":"test.event","data":{}}'
    await db.webhook_deliveries.insert_one({
        "_id": did, "org_id": org, "webhook_id": wid, "event": "test.event",
        "payload": {"data": {}}, "status": "pending_retry", "attempts": 1, "max_attempts": 2,
        "next_attempt_at": "1970-01-01T00:00:00+00:00",     # due
        "retry_body": base64.b64encode(body).decode(),
        "created_at": utc_now_iso(), "updated_at": utc_now_iso()})

    r1 = await wh.retry_due()                    # attempt 2 → reaches max → dead_letter
    d = await db.webhook_deliveries.find_one({"_id": did})
    print(f"[RETRY] result={r1} status_after={d['status']} attempts={d['attempts']}")
    assert d["status"] == "dead_letter", f"expected dead_letter, got {d['status']}"
    assert "retry_body" not in d, "retry_body should be pruned after dead-letter"

    ok = await wh.replay_delivery(org, did)      # owner replay → back to pending_retry
    d2 = await db.webhook_deliveries.find_one({"_id": did})
    print(f"[REPLAY] ok={ok} status_after={d2['status']}")
    assert ok and d2["status"] == "pending_retry", "replay should requeue"
    assert d2.get("retry_body"), "replay should restore a body to send"

    await db.webhooks.delete_many({"org_id": org})
    await db.webhook_deliveries.delete_many({"org_id": org})
    print("WEBHOOK RETRY/DLQ/REPLAY ASSERTIONS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
