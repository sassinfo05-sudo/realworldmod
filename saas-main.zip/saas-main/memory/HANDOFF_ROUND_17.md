# ZANELVO — HANDOFF ROUND 17 (Production Storage, Unified Asset Library & Bandwidth Controls)

_Read `CURRENT_STATUS.md`, then `HANDOFF_ROUND_16.md`. Source code + fresh tests override older claims.
Env is WIPED on import — rebuild `.env` per HANDOFF_ROUND_15 §0, then restart supervisor._

## 1. WHAT ROUND 17 SHIPPED & VERIFIED
Goal: production-grade object storage + a unified Asset Library + plan-enforced storage allowances,
safe migration of legacy inline media, and honest bandwidth/cost controls. Domain/mailbox resale remain
out of scope (untouched).

### Backend (new)
- `services/storage.py` — provider-neutral service. Adapters: `S3CompatibleAdapter` (R2/S3/B2/MinIO,
  boto3 lazy), `LocalFilesystemAdapter` (dev/test only), `_DisabledProvider` (production without creds
  → writes raise `storage_not_configured`). Tenant keys `org/{org_id}/{asset_id}/{variant}`. Config in
  `platform_settings.storage` (encrypted via secretbox, masked, status Connected/Sandbox/Not connected/Error).
- `services/assets.py` — assets + atomic quota. Collections: `assets`, `asset_references`,
  `upload_reservations`, `storage_usage`, `storage_overrides` (+ indexes at startup). Atomic reserve
  (`find_one_and_update` with `$expr` sum ≤ allowance), MIME allowlist + magic-byte sniff, SVG sanitise,
  PIL decompression-bomb + dimension guard + EXIF strip (re-encode), per-tenant SHA-256 dedup, trash/restore/
  purge with accurate accounting + delete dead-letter, reconcile, breakdown. DB-backed founder-editable
  allowances (free 500MB/launch 5GB/revenue 50GB/autopilot 200GB/scale 500GB) + per-tenant override; 70/90/100%.
- `routes/assets.py` — `/api/assets/*` (upload init/finalize/cancel, list/search/paginate, get, patch,
  references +add, trash/restore, purge, usage, breakdown, reconcile, staff/overview, staff/override),
  `/api/public/assets/{key}` (public serve), `/api/assets/blob/{key}` (HMAC-signed private serve),
  `/api/founder/storage` (GET/PUT/test). Registered in server.py.
- `scripts/migrate_inline_assets.py` — idempotent dry-run + bounded migrate + separate cleanup for legacy
  base64 `media`; rollback map in `asset_migration_map`; legacy blob retained until verified. Dry-run verified.

### Frontend (new)
- `pages/dashboard/AssetLibrary.jsx` (`/app/assets`) — usage bar (used/reserved/trash/free/%), category
  filter, Active/Unused/Trash views, search, drag-drop + button upload, grid, edit metadata (alt/caption/
  tags/category) + reference count, trash/restore/purge. Nav item under "Build".
- `components/AssetPicker.jsx` — reusable picker (browse/search/upload/select → returns stable asset).
  Wired into the CMS media field (`components/cms/FieldsEditor.jsx`). `lib/assets.js` API client.

### Tests / build
- `tests/test_storage_assets.py` — 10/10 PASS (upload+usage, MIME/size, content-mismatch, SVG sanitise,
  dedup, tenant isolation 404, trash/restore/purge accounting, atomic quota 402, signed private URL, no-500).
- CMS regression still 16 passed / 1 skipped. Frontend production build: SUCCESS (warnings only).
- NOTE: running multiple API suites together trips the wanted per-IP signup limiter — run suites individually.

## 2. GATES
- **CODE_GATE: PASS** — all credential-independent implementation + internal tests pass.
- **PRODUCTION_GATE: PENDING_EXTERNAL_SETUP** — no real object-storage/CDN credentials connected yet
  (owner/founder action via Setup Center → Storage). In dev the local adapter is used (Sandbox).

## 3. REMAINING (next increments / owner actions)
- Owner: connect R2/S3 creds in Setup Center → run test → run migration.
- Responsive image variants (thumb/small/medium/large + WebP/AVIF) + `srcset` on public sites (source-only now).
- Presigned DIRECT browser→provider upload for large files (current finalize is base64 single-shot ≤25MB;
  legacy chunked media endpoints still available).
- Bandwidth reconciliation from real provider/CDN logs (currently Estimated/Unavailable, labelled honestly).
- Auto reference-tracking + "replace everywhere" from every editor (references API + CMS picker done; other
  editors resolve/store URLs today). Staff margin dashboard rows for storage/bandwidth cost.
- Purge cron + abandoned-reservation sweeper as scheduled jobs.

## 4. TEST COMMANDS (from /app/backend)
```
python -m pytest -n 0 -q tests/test_storage_assets.py     # 10 passed
python -m pytest -n 0 -q tests/test_cms_foundation.py      # 16 passed / 1 skipped
python -m scripts.migrate_inline_assets --dry-run          # legacy media inventory
```
Login: owner `/login` (owner@zanelvo.com), founder `/staff/login`. Creds in gitignored
`memory/test_credentials.md`. Do NOT push from agent — use chat "Save to Github".
