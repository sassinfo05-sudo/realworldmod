import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Database, Plus, Sparkles, Plug, ArrowRight, Archive, RefreshCw, CheckCircle2, XCircle } from "lucide-react";
import FieldsEditor from "@/components/cms/FieldsEditor";
import {
    listCollections, createCollection, updateCollection, cmsLimits,
    listConnectors, createConnector, testConnector, aiPropose, aiApply, apiErr, typeLabel,
} from "@/lib/cms";

export default function ContentManager() {
    const [tab, setTab] = useState("collections");
    const [collections, setCollections] = useState([]);
    const [limits, setLimits] = useState(null);
    const [loading, setLoading] = useState(true);

    const reload = async () => {
        setLoading(true);
        try {
            const [c, l] = await Promise.all([listCollections(true), cmsLimits()]);
            setCollections(c);
            setLimits(l);
        } catch (e) { toast.error(apiErr(e)); }
        setLoading(false);
    };
    useEffect(() => { reload(); }, []);

    const activeCount = collections.filter((c) => !c.archived).length;

    return (
        <div className="max-w-6xl mx-auto p-6 space-y-6" data-testid="content-manager">
            <div className="flex items-start justify-between flex-wrap gap-3">
                <div>
                    <h1 className="text-2xl font-semibold flex items-center gap-2">
                        <Database className="w-6 h-6 text-brand-copper" /> Content Manager
                    </h1>
                    <p className="text-sm text-zinc-500 mt-1 max-w-2xl">
                        Build custom data collections, dynamic pages and forms — no code. Bind your data to any page and it stays in sync.
                    </p>
                </div>
                {limits && (
                    <Badge variant="outline" className="text-xs" data-testid="cms-plan-limits">
                        {activeCount}/{limits.max_collections} collections · plan: {limits.plan}
                    </Badge>
                )}
            </div>

            <Tabs value={tab} onValueChange={setTab}>
                <TabsList>
                    <TabsTrigger value="collections" data-testid="tab-collections"><Database className="w-4 h-4 mr-1" />Collections</TabsTrigger>
                    <TabsTrigger value="ai" data-testid="tab-ai"><Sparkles className="w-4 h-4 mr-1" />AI create</TabsTrigger>
                    <TabsTrigger value="connectors" data-testid="tab-connectors"><Plug className="w-4 h-4 mr-1" />Connectors</TabsTrigger>
                </TabsList>

                <TabsContent value="collections" className="mt-4">
                    <CollectionsTab collections={collections} loading={loading} limits={limits} reload={reload} activeCount={activeCount} />
                </TabsContent>
                <TabsContent value="ai" className="mt-4">
                    <AiCreateTab reload={reload} />
                </TabsContent>
                <TabsContent value="connectors" className="mt-4">
                    <ConnectorsTab limits={limits} />
                </TabsContent>
            </Tabs>
        </div>
    );
}

function CollectionsTab({ collections, loading, limits, reload, activeCount }) {
    const [open, setOpen] = useState(false);
    const [name, setName] = useState("");
    const [fields, setFields] = useState([{ label: "Name", type: "short_text", required: true, searchable: true }]);
    const [saving, setSaving] = useState(false);
    const atLimit = limits && activeCount >= limits.max_collections;

    const save = async () => {
        if (!name.trim()) return toast.error("Name your collection");
        if (!fields.length) return toast.error("Add at least one field");
        setSaving(true);
        try {
            await createCollection({ name: name.trim(), fields });
            toast.success("Collection created");
            setOpen(false); setName(""); setFields([{ label: "Name", type: "short_text", required: true, searchable: true }]);
            reload();
        } catch (e) { toast.error(apiErr(e)); }
        setSaving(false);
    };

    const archive = async (c) => {
        try { await updateCollection(c.id, { archived: !c.archived }); reload(); }
        catch (e) { toast.error(apiErr(e)); }
    };

    return (
        <div>
            <div className="flex justify-end mb-4">
                <Button onClick={() => setOpen(true)} disabled={atLimit} data-testid="new-collection-btn">
                    <Plus className="w-4 h-4 mr-1" /> New collection
                </Button>
            </div>
            {atLimit && <p className="text-xs text-amber-600 mb-3 text-right">You've reached your plan's collection limit. Upgrade to add more.</p>}

            {loading ? <p className="text-sm text-zinc-500">Loading…</p> : (
                collections.length === 0 ? (
                    <Card className="p-10 text-center text-zinc-500">
                        <Database className="w-10 h-10 mx-auto mb-3 opacity-40" />
                        <p className="font-medium">No collections yet</p>
                        <p className="text-sm mt-1">Create your first data collection, or describe one on the AI create tab.</p>
                    </Card>
                ) : (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {collections.map((c) => (
                            <Card key={c.id} className={`p-4 ${c.archived ? "opacity-60" : ""}`} data-testid={`collection-card-${c.internal_id}`}>
                                <div className="flex items-start justify-between">
                                    <div>
                                        <div className="font-medium">{c.name}</div>
                                        <div className="text-xs text-zinc-500">{c.internal_id}</div>
                                    </div>
                                    {c.archived && <Badge variant="outline" className="text-[10px]">Archived</Badge>}
                                </div>
                                <div className="text-xs text-zinc-500 mt-3">
                                    {(c.fields || []).length} fields · {c.item_count ?? 0} items
                                </div>
                                <div className="flex flex-wrap gap-1 mt-2">
                                    {(c.fields || []).slice(0, 4).map((f) => (
                                        <Badge key={f.key} variant="secondary" className="text-[10px]">{typeLabel(f.type)}</Badge>
                                    ))}
                                </div>
                                <div className="flex items-center justify-between mt-4">
                                    <Button asChild size="sm" variant="ghost" className="text-brand-copper px-0">
                                        <Link to={`/app/content/${c.id}`} data-testid={`open-collection-${c.internal_id}`}>Manage <ArrowRight className="w-3.5 h-3.5 ml-1" /></Link>
                                    </Button>
                                    <Button size="icon" variant="ghost" onClick={() => archive(c)} title={c.archived ? "Restore" : "Archive"}>
                                        <Archive className="w-4 h-4" />
                                    </Button>
                                </div>
                            </Card>
                        ))}
                    </div>
                )
            )}

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
                    <DialogHeader><DialogTitle>New collection</DialogTitle></DialogHeader>
                    <div className="space-y-4">
                        <div>
                            <Label>Display name</Label>
                            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Team, Locations, Listings" data-testid="collection-name-input" />
                        </div>
                        <div>
                            <Label className="mb-2 block">Fields</Label>
                            <FieldsEditor value={fields} onChange={setFields} />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                        <Button onClick={save} disabled={saving} data-testid="save-collection-btn">{saving ? "Creating…" : "Create collection"}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}

function AiCreateTab({ reload }) {
    const [prompt, setPrompt] = useState("");
    const [busy, setBusy] = useState(false);
    const [proposal, setProposal] = useState(null);

    const propose = async () => {
        if (!prompt.trim()) return;
        setBusy(true); setProposal(null);
        try {
            const res = await aiPropose(prompt.trim());
            setProposal(res.will_create);
        } catch (e) { toast.error(apiErr(e, "AI is unavailable right now")); }
        setBusy(false);
    };

    const apply = async () => {
        const c = proposal?.collection;
        if (!c) return;
        setBusy(true);
        try {
            await aiApply({ name: c.name, fields: c.fields, display_field: c.display_field });
            toast.success("Collection created from your description");
            setProposal(null); setPrompt(""); reload();
        } catch (e) { toast.error(apiErr(e)); }
        setBusy(false);
    };

    return (
        <div className="max-w-3xl space-y-4">
            <Card className="p-5">
                <div className="flex items-center gap-2 mb-2"><Sparkles className="w-5 h-5 text-brand-copper" /><h3 className="font-medium">Describe what you want to build</h3></div>
                <Textarea rows={3} value={prompt} onChange={(e) => setPrompt(e.target.value)} data-testid="ai-prompt"
                          placeholder="e.g. Create a team directory with a page for each employee and a contact form." />
                <div className="flex items-center justify-between mt-3">
                    <p className="text-xs text-zinc-500">AI proposes a structure. Nothing is created until you confirm. Metered as AI usage.</p>
                    <Button onClick={propose} disabled={busy} data-testid="ai-propose-btn">{busy ? "Thinking…" : "Propose"}</Button>
                </div>
            </Card>

            {proposal && (
                <Card className="p-5 space-y-3" data-testid="ai-proposal">
                    <div className="text-xs uppercase tracking-wide text-zinc-500">Proposed — review before creating</div>
                    <div>
                        <div className="font-medium">Collection: {proposal.collection?.name}</div>
                        <div className="mt-2 space-y-1">
                            {(proposal.collection?.fields || []).map((f, i) => (
                                <div key={i} className="text-sm flex items-center gap-2">
                                    <Badge variant="secondary" className="text-[10px]">{typeLabel(f.type)}</Badge>
                                    <span>{f.label}</span>
                                    {f.required && <span className="text-[10px] text-amber-600">required</span>}
                                    {f.private && <span className="text-[10px] text-zinc-400">private</span>}
                                </div>
                            ))}
                        </div>
                    </div>
                    {proposal.dynamic_pages?.route_base && (
                        <div className="text-sm text-zinc-500">Suggested dynamic route: <code>/{proposal.dynamic_pages.route_base}</code></div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setProposal(null)}>Discard</Button>
                        <Button onClick={apply} disabled={busy} data-testid="ai-apply-btn">Create collection</Button>
                    </DialogFooter>
                </Card>
            )}
        </div>
    );
}

function ConnectorsTab({ limits }) {
    const [conns, setConns] = useState([]);
    const [open, setOpen] = useState(false);
    const [form, setForm] = useState({ name: "", url: "", headersText: "" });
    const [busy, setBusy] = useState(false);
    const allowed = limits && limits.max_connectors > 0;

    const reload = async () => { try { setConns(await listConnectors()); } catch (e) { /* noop */ } };
    useEffect(() => { if (allowed) reload(); }, [allowed]);

    const save = async () => {
        const headers = {};
        (form.headersText || "").split("\n").forEach((l) => {
            const i = l.indexOf(":");
            if (i > 0) headers[l.slice(0, i).trim()] = l.slice(i + 1).trim();
        });
        setBusy(true);
        try {
            await createConnector({ name: form.name, url: form.url, headers });
            toast.success("Connector added");
            setOpen(false); setForm({ name: "", url: "", headersText: "" }); reload();
        } catch (e) { toast.error(apiErr(e)); }
        setBusy(false);
    };

    const test = async (id) => {
        try { const r = await testConnector(id); toast.success(`Connected · HTTP ${r.status_code}`); reload(); }
        catch (e) { toast.error(apiErr(e, "Connection failed")); reload(); }
    };

    if (!allowed) {
        return (
            <Card className="p-8 text-center text-zinc-500">
                <Plug className="w-9 h-9 mx-auto mb-3 opacity-40" />
                <p className="font-medium">External data connectors aren't in your current plan</p>
                <p className="text-sm mt-1">Upgrade to connect a secure external REST API (HTTPS only, SSRF-protected).</p>
            </Card>
        );
    }

    return (
        <div>
            <div className="flex justify-end mb-4">
                <Button onClick={() => setOpen(true)} data-testid="new-connector-btn"><Plus className="w-4 h-4 mr-1" /> New connector</Button>
            </div>
            <div className="space-y-3">
                {conns.map((c) => (
                    <Card key={c.id} className="p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                            <div className="font-medium truncate">{c.name}</div>
                            <div className="text-xs text-zinc-500 truncate">{c.url}</div>
                            {c.header_keys?.length > 0 && <div className="text-[10px] text-zinc-400 mt-1">Headers: {c.header_keys.join(", ")} (values encrypted)</div>}
                            {c.last_error && <div className="text-[11px] text-red-500 mt-1">{c.last_error}</div>}
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                            {c.status === "connected" ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : c.status === "error" ? <XCircle className="w-4 h-4 text-red-500" /> : null}
                            <Badge variant="outline" className="text-[10px]">{c.status}</Badge>
                            <Button size="sm" variant="outline" onClick={() => test(c.id)}><RefreshCw className="w-3.5 h-3.5 mr-1" />Test</Button>
                        </div>
                    </Card>
                ))}
                {conns.length === 0 && <p className="text-sm text-zinc-500">No connectors yet.</p>}
            </div>

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent>
                    <DialogHeader><DialogTitle>New external connector</DialogTitle></DialogHeader>
                    <div className="space-y-3">
                        <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="connector-name" /></div>
                        <div><Label>HTTPS URL</Label><Input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="https://api.example.com/v1/data" data-testid="connector-url" /></div>
                        <div>
                            <Label>Headers (one per line, <code>Key: Value</code>)</Label>
                            <Textarea rows={3} value={form.headersText} onChange={(e) => setForm({ ...form, headersText: e.target.value })} placeholder="Authorization: Bearer xxxx" />
                            <p className="text-[11px] text-zinc-400 mt-1">Secrets are encrypted at rest and never shown again.</p>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                        <Button onClick={save} disabled={busy} data-testid="save-connector-btn">{busy ? "Saving…" : "Add connector"}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
