"""One-shot cleanup: remove past-dated bookings (with their contacts if orphaned) and
prune stale agent-version clutter that was created during Phase 5 testing.

Idempotent — safe to run multiple times. Prints a summary.
"""
import asyncio
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from bson import ObjectId
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
load_dotenv(Path(__file__).resolve().parents[1] / ".env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("cleanup")


async def main() -> None:
    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    db = client[os.environ["DB_NAME"]]
    now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    # 1. Past-dated bookings (from before "now"). Also delete the "AI chat"/"reschedule" sourced
    #    tester leftovers we know about by id.
    known_leftover_ids = [
        "6a99cce21dee22d98cc6b201",
        "6a99ce371dee22d98cc6b21f",
    ]
    tester_contact_names = {"Alex Tester", "Rollback Tester"}

    to_delete: list[dict] = []
    async for b in db.bookings.find({"start_at": {"$lt": now_iso}}):
        to_delete.append(b)
    for oid_str in known_leftover_ids:
        if ObjectId.is_valid(oid_str):
            b = await db.bookings.find_one({"_id": ObjectId(oid_str)})
            if b and b not in to_delete:
                to_delete.append(b)

    booking_ids = [b["_id"] for b in to_delete]
    contact_ids_touched: set[str] = set()
    for b in to_delete:
        if b.get("contact_id"):
            contact_ids_touched.add(b["contact_id"])

    if booking_ids:
        r = await db.bookings.delete_many({"_id": {"$in": booking_ids}})
        log.info("Deleted %d past-dated bookings.", r.deleted_count)
    else:
        log.info("No past-dated bookings to delete.")

    # 2. Delete tester contacts by name (their bookings are now gone).
    r = await db.contacts.delete_many({"display_name": {"$in": list(tester_contact_names)}})
    log.info("Deleted %d tester contacts.", r.deleted_count)

    # 3. Delete interactions that pointed to deleted bookings.
    if booking_ids:
        r = await db.interactions.delete_many({"ref_type": "booking",
                                                "ref_id": {"$in": [str(x) for x in booking_ids]}})
        log.info("Deleted %d dangling booking interactions.", r.deleted_count)

    # 4. Prune agent versions that were created only for testing (labels startswith 'TEST').
    #    Never delete a version that is currently live.
    async for a in db.agents.find({}):
        live_vid = a.get("live_version_id")
        r = await db.agent_versions.delete_many({
            "agent_id": str(a["_id"]),
            "label": {"$regex": "^TEST", "$options": "i"},
            "is_live": {"$ne": True},
            **({"_id": {"$ne": ObjectId(live_vid)}} if live_vid and ObjectId.is_valid(live_vid) else {}),
        })
        if r.deleted_count:
            log.info("Pruned %d TEST agent versions on agent %s (%s).",
                     r.deleted_count, a.get("agent_type"), str(a["_id"]))

    log.info("Cleanup complete.")


if __name__ == "__main__":
    asyncio.run(main())
