"""Dynamic CMS & Extensions routes.

Owner routes  → /api/cms/*        (require_org; org_id ONLY from auth context)
Public routes → /api/public/cms/* (safe projections; published+non-archived only)

Public forms write ONLY through the controlled form service (routes/media_forms_analytics)
which calls cms.create_item — there is no generic unauthenticated DB-write endpoint here.
"""
from __future__ import annotations

import base64
import hashlib
import os
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org, require_role
from ..models import User
from ..services import cms
from ..services import usage

router = APIRouter(prefix="/cms", tags=["cms"])
public_router = APIRouter(prefix="/public/cms", tags=["cms-public"])


# ---- connector secret encryption (Fernet key derived from SECRETS_ENC_KEY) ----
def _fernet():
    from cryptography.fernet import Fernet
    seed = (os.environ.get("SECRETS_ENC_KEY") or os.environ.get("JWT_SECRET") or "zanelvo").encode()
    key = base64.urlsafe_b64encode(hashlib.sha256(seed).digest())
    return Fernet(key)


def _enc(v: str) -> str:
    return _fernet().encrypt((v or "").encode()).decode()


def _dec(v: str) -> str:
    try:
        return _fernet().decrypt((v or "").encode()).decode()
    except Exception:  # noqa: BLE001
        return ""


# ============================= COLLECTIONS =============================
class FieldIn(BaseModel):
    key: Optional[str] = None
    label: str
    type: str
    required: bool = False
    unique: bool = False
    searchable: bool = False
    private: bool = False
    default: Any = None
    options: List[str] = Field(default_factory=list)
    ref_collection: Optional[str] = None
    validation: Dict[str, Any] = Field(default_factory=dict)


class CollectionIn(BaseModel):
    name: str
    fields: List[FieldIn] = Field(default_factory=list)
    display_field: Optional[str] = None


@router.post("/collections")
async def create_collection(body: CollectionIn, user: User = Depends(require_role("owner", "manager")),
                            org_id: str = Depends(require_org)):
    return await cms.create_collection(org_id, user.id, body.name,
                                       [f.model_dump() for f in body.fields], body.display_field)


@router.get("/collections")
async def list_collections(include_archived: bool = False, user: User = Depends(current_user),
                           org_id: str = Depends(require_org)):
    return {"collections": await cms.list_collections(org_id, include_archived)}


@router.get("/collections/{cid}")
async def get_collection(cid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await cms.get_collection(org_id, cid)


class CollectionPatch(BaseModel):
    name: Optional[str] = None
    display_field: Optional[str] = None
    archived: Optional[bool] = None
    fields: Optional[List[FieldIn]] = None


@router.patch("/collections/{cid}")
async def update_collection(cid: str, body: CollectionPatch,
                            user: User = Depends(require_role("owner", "manager")),
                            org_id: str = Depends(require_org)):
    patch = body.model_dump(exclude_none=True)
    if body.fields is not None:
        patch["fields"] = [f.model_dump() for f in body.fields]
    return await cms.update_collection(org_id, user.id, cid, patch)


@router.get("/limits")
async def get_limits(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await cms.cms_limits(org_id)


# ============================= ITEMS =============================
class ItemIn(BaseModel):
    values: Dict[str, Any] = Field(default_factory=dict)
    status: str = "published"


@router.post("/collections/{cid}/items")
async def create_item(cid: str, body: ItemIn, user: User = Depends(require_role("owner", "manager", "staff")),
                      org_id: str = Depends(require_org)):
    return await cms.create_item(org_id, user.id, cid, body.values, body.status)


@router.get("/collections/{cid}/items")
async def list_items(cid: str, q: Optional[str] = None, page: int = 1, page_size: int = 50,
                     sort: str = "-created_at", include_archived: bool = False,
                     user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await cms.list_items(org_id, cid, q=q, page=page, page_size=page_size,
                                sort=sort, include_archived=include_archived)


class ItemPatch(BaseModel):
    values: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    archived: Optional[bool] = None


@router.patch("/items/{item_id}")
async def update_item(item_id: str, body: ItemPatch,
                      user: User = Depends(require_role("owner", "manager", "staff")),
                      org_id: str = Depends(require_org)):
    return await cms.update_item(org_id, user.id, item_id, body.model_dump(exclude_none=True))


@router.post("/items/{item_id}/duplicate")
async def duplicate_item(item_id: str, user: User = Depends(require_role("owner", "manager", "staff")),
                         org_id: str = Depends(require_org)):
    item = await get_db()[cms.ITEMS].find_one({"org_id": org_id, "id": item_id}, {"_id": 0})
    if not item:
        raise HTTPException(404, "Item not found")
    return await cms.create_item(org_id, user.id, item["collection_id"], dict(item.get("values") or {}), "draft")


@router.get("/items/{item_id}/revisions")
async def item_revisions(item_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"revisions": await cms.item_revisions(org_id, item_id)}


class RollbackIn(BaseModel):
    revision_id: str


@router.post("/items/{item_id}/rollback")
async def rollback_item(item_id: str, body: RollbackIn,
                        user: User = Depends(require_role("owner", "manager")),
                        org_id: str = Depends(require_org)):
    return await cms.rollback_item(org_id, user.id, item_id, body.revision_id)


# ---- CSV import (bounded) ----
class CsvImportIn(BaseModel):
    csv_text: str
    mapping: Dict[str, str] = Field(default_factory=dict)  # column -> field_key


@router.post("/collections/{cid}/import")
async def csv_import(cid: str, body: CsvImportIn, user: User = Depends(require_role("owner", "manager")),
                     org_id: str = Depends(require_org)):
    import csv as _csv
    import io
    if len(body.csv_text.encode("utf-8")) > cms.CSV_MAX_BYTES:
        raise HTTPException(413, {"error": "csv_too_large", "max_bytes": cms.CSV_MAX_BYTES})
    reader = _csv.DictReader(io.StringIO(body.csv_text))
    if not reader.fieldnames or len(reader.fieldnames) > cms.CSV_MAX_COLS:
        raise HTTPException(400, {"error": "too_many_columns", "max": cms.CSV_MAX_COLS})
    created, errors = 0, []
    for i, row in enumerate(reader):
        if i >= cms.CSV_MAX_ROWS:
            errors.append({"row": i, "error": "row limit reached"})
            break
        values = {}
        for col, fkey in (body.mapping or {}).items():
            if fkey and col in row:
                values[fkey] = row[col]
        try:
            await cms.create_item(org_id, user.id, cid, values, "published")
            created += 1
        except HTTPException as e:
            errors.append({"row": i, "error": e.detail})
            if isinstance(e.detail, dict) and e.detail.get("error", "").endswith("_limit"):
                break
    return {"created": created, "errors": errors}


# ============================= DYNAMIC PAGE TEMPLATES =============================
class TemplateIn(BaseModel):
    collection_id: str
    site_slug: str
    route_base: Optional[str] = None
    slug_field: Optional[str] = None
    list_layout: Dict[str, Any] = Field(default_factory=lambda: {"blocks": []})
    detail_layout: Dict[str, Any] = Field(default_factory=lambda: {"blocks": []})
    seo: Dict[str, Any] = Field(default_factory=dict)


@router.post("/templates")
async def create_template(body: TemplateIn, user: User = Depends(require_role("owner", "manager")),
                          org_id: str = Depends(require_org)):
    return await cms.create_template(org_id, user.id, body.model_dump())


@router.get("/templates")
async def list_templates(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"templates": await cms.list_templates(org_id)}


class TemplatePatch(BaseModel):
    route_base: Optional[str] = None
    slug_field: Optional[str] = None
    list_layout: Optional[Dict[str, Any]] = None
    detail_layout: Optional[Dict[str, Any]] = None
    seo: Optional[Dict[str, Any]] = None
    status: Optional[str] = None


@router.patch("/templates/{tid}")
async def update_template(tid: str, body: TemplatePatch,
                          user: User = Depends(require_role("owner", "manager")),
                          org_id: str = Depends(require_org)):
    return await cms.update_template(org_id, user.id, tid, body.model_dump(exclude_none=True))


# ============================= EXTERNAL CONNECTOR =============================
class ConnectorIn(BaseModel):
    name: str
    url: str
    headers: Dict[str, str] = Field(default_factory=dict)
    params: Dict[str, str] = Field(default_factory=dict)


@router.post("/connectors")
async def create_connector(body: ConnectorIn, user: User = Depends(require_role("owner", "manager")),
                           org_id: str = Depends(require_org)):
    lim = await cms.cms_limits(org_id)
    if lim["max_connectors"] <= 0:
        raise HTTPException(402, {"error": "cms_connector_not_in_plan", "plan": lim.get("plan"),
                                  "upgrade_url": "/app/billing",
                                  "message": "External data connectors require a higher plan."})
    count = await get_db()[cms.CONNECTIONS].count_documents({"org_id": org_id})
    if count >= lim["max_connectors"]:
        raise HTTPException(402, {"error": "cms_connector_limit", "limit": lim["max_connectors"]})
    cms._assert_safe_url(body.url)  # reject SSRF at creation time too
    doc = {"id": uuid.uuid4().hex, "org_id": org_id, "name": body.name[:120], "url": body.url,
           "headers_enc": {k: _enc(v) for k, v in (body.headers or {}).items()},
           "params": body.params or {}, "status": "not_tested", "last_success": None,
           "last_error": None, "created_by": user.id, "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    await get_db()[cms.CONNECTIONS].insert_one(dict(doc))
    return _connector_public(doc)


def _connector_public(doc: Dict[str, Any]) -> Dict[str, Any]:
    return {"id": doc["id"], "name": doc["name"], "url": doc["url"],
            "header_keys": list((doc.get("headers_enc") or {}).keys()),  # keys only, never values
            "params": doc.get("params"), "status": doc.get("status"),
            "last_success": doc.get("last_success"), "last_error": doc.get("last_error"),
            "created_at": doc.get("created_at")}


@router.get("/connectors")
async def list_connectors(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    out = []
    async for d in get_db()[cms.CONNECTIONS].find({"org_id": org_id}):
        out.append(_connector_public(d))
    return {"connectors": out}


@router.post("/connectors/{conn_id}/test")
async def test_connector(conn_id: str, user: User = Depends(require_role("owner", "manager")),
                         org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db[cms.CONNECTIONS].find_one({"org_id": org_id, "id": conn_id})
    if not doc:
        raise HTTPException(404, "Connector not found")
    # Any connector op passes through central cost controls (metered as a small variable op).
    await usage.enforce_budget(org_id, feature="cms_connector", kind="json", est_cost=0.0)
    headers = {k: _dec(v) for k, v in (doc.get("headers_enc") or {}).items()}
    try:
        result = await cms.connector_fetch(doc["url"], headers, doc.get("params") or {})
        await db[cms.CONNECTIONS].update_one({"id": conn_id, "org_id": org_id},
                                             {"$set": {"status": "connected", "last_success": utc_now_iso(),
                                                       "last_error": None, "updated_at": utc_now_iso()}})
        await usage.record_usage(kind="json", provider="connector", model="rest", units=1,
                                 org_id=org_id, feature="cms_connector", actual_cost_usd=0.0)
        preview = result.get("data")
        return {"ok": True, "status_code": result.get("status_code"),
                "sample": (preview if not isinstance(preview, list) else preview[:5])}
    except HTTPException as e:
        await db[cms.CONNECTIONS].update_one({"id": conn_id, "org_id": org_id},
                                             {"$set": {"status": "error",
                                                       "last_error": str(e.detail)[:300],
                                                       "updated_at": utc_now_iso()}})
        raise


# ============================= AI-NATIVE CREATION (metered) =============================
class AiProposeIn(BaseModel):
    prompt: str


@router.post("/ai/propose")
async def ai_propose(body: AiProposeIn, user: User = Depends(require_role("owner", "manager")),
                     org_id: str = Depends(require_org)):
    """Propose (NOT apply) a collection schema + dynamic page plan. Fully metered; returns a
    structured preview for explicit confirmation before anything is created."""
    prompt = (body.prompt or "").strip()[:2000]
    if not prompt:
        raise HTTPException(400, "prompt required")
    usage.set_context(org_id=org_id, user_id=user.id, feature="cms_ai_schema")
    await usage.enforce_budget(org_id, provider="anthropic", feature="cms_ai_schema", kind="json",
                               est_cost=0.02, user_id=user.id)
    res = await usage.reserve(kind="json", provider="anthropic", model="claude-sonnet-4-6",
                              est_cost=0.02, org_id=org_id, user_id=user.id, feature="cms_ai_schema")
    await usage.confirm_reservation(res, org_id)
    out_text = ""
    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage
        sys = ("You design no-code data collections. Return STRICT JSON only, no prose. Schema: "
               '{"collection":{"name":str,"display_field":str,"fields":[{"key":str,"label":str,'
               '"type":one of ' + ",".join(sorted(cms.FIELD_TYPES)) + ',"required":bool,"private":bool,'
               '"searchable":bool,"options":[str]}]},"dynamic_pages":{"route_base":str,"slug_field":str},'
               '"form":{"maps_to_collection":bool,"fields":[str]}}. '
               "Never invent real business facts, prices, testimonials or people.")
        chat = (LlmChat(api_key=os.environ["EMERGENT_LLM_KEY"], session_id=f"cms-{uuid.uuid4().hex[:8]}",
                        system_message=sys).with_model("anthropic", "claude-sonnet-4-6"))
        resp = await chat.send_message(UserMessage(text=prompt))
        out_text = str(resp)
    except Exception as e:  # noqa: BLE001
        await usage.release(res, reason="provider_error")
        raise HTTPException(502, {"error": "ai_unavailable", "message": str(e)[:200]})
    finally:
        await usage.settle(res, kind="json", provider="anthropic", model="claude-sonnet-4-6",
                           input_text=prompt, output_text=out_text, org_id=org_id, feature="cms_ai_schema")
    import json as _json
    import re as _re
    m = _re.search(r"\{.*\}", out_text, _re.DOTALL)
    if not m:
        raise HTTPException(502, {"error": "ai_parse_failed"})
    try:
        proposal = _json.loads(m.group(0))
    except Exception:  # noqa: BLE001
        raise HTTPException(502, {"error": "ai_parse_failed"})
    # normalise + present a preview (nothing created yet)
    coll = proposal.get("collection") or {}
    fields = [cms._norm_field(f) for f in (coll.get("fields") or []) if f.get("type") in cms.FIELD_TYPES]
    return {"preview": True,
            "will_create": {"collection": {"name": coll.get("name"), "display_field": coll.get("display_field"),
                                            "fields": fields},
                            "dynamic_pages": proposal.get("dynamic_pages") or {},
                            "form": proposal.get("form") or {}},
            "note": "Nothing was created. Call /cms/ai/apply to confirm."}


class AiApplyIn(BaseModel):
    name: str
    fields: List[FieldIn]
    display_field: Optional[str] = None


@router.post("/ai/apply")
async def ai_apply(body: AiApplyIn, user: User = Depends(require_role("owner", "manager")),
                   org_id: str = Depends(require_org)):
    """Apply a confirmed AI proposal (create the collection). Schema changes require confirmation."""
    return await cms.create_collection(org_id, user.id, body.name,
                                       [f.model_dump() for f in body.fields], body.display_field)


# ============================= PUBLIC (safe) =============================
async def _resolve_org_for_site(site_slug: str) -> Optional[str]:
    doc = await get_db().websites.find_one({"slug": site_slug}, {"org_id": 1})
    return (doc or {}).get("org_id")


@public_router.get("/{site_slug}/{route_base}")
async def public_list_page(site_slug: str, route_base: str, q: Optional[str] = None,
                           page: int = 1, page_size: int = 24):
    org_id = await _resolve_org_for_site(site_slug)
    if not org_id:
        raise HTTPException(404, "Not found")
    tpl = await cms.public_template_by_route(org_id, site_slug, route_base)
    if not tpl:
        raise HTTPException(404, "Not found")
    data = await cms.public_list(org_id, tpl, q, page, page_size)
    return {"route_base": route_base, "list_layout": tpl.get("list_layout"), **data}


@public_router.get("/{site_slug}/{route_base}/{slug}")
async def public_detail_page(site_slug: str, route_base: str, slug: str):
    org_id = await _resolve_org_for_site(site_slug)
    if not org_id:
        raise HTTPException(404, "Not found")
    tpl = await cms.public_template_by_route(org_id, site_slug, route_base)
    if not tpl:
        raise HTTPException(404, "Not found")
    detail = await cms.public_detail(org_id, tpl, slug)
    if not detail:
        raise HTTPException(404, "Not found")
    return detail
