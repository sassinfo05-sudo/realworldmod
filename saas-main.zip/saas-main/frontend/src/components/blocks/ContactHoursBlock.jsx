import { Mail, Phone, MapPin, Clock } from "lucide-react";

export default function ContactHoursBlock({ block, theme }) {
    const { props = {} } = block;
    const { headline, subheadline, hours = [], locations = [], email, phone } = props;
    return (
        <section className="py-20" style={{ backgroundColor: theme?.background }}>
            <div className="mx-auto max-w-6xl px-6">
                <div className="max-w-2xl">
                    {headline && (
                        <h2 data-heading className="text-3xl md:text-4xl font-semibold leading-tight">
                            {headline}
                        </h2>
                    )}
                    {subheadline && (
                        <p className="mt-3" style={{ color: `${theme?.foreground}A0` }}>{subheadline}</p>
                    )}
                </div>

                <div className="mt-10 grid md:grid-cols-2 gap-8">
                    {/* Reach us */}
                    <div className="rounded-2xl p-6 border"
                         style={{ background: theme?.surface, borderColor: `${theme?.foreground}14` }}>
                        <h3 data-heading className="text-lg font-semibold">Reach us</h3>
                        <div className="mt-4 space-y-3 text-sm">
                            {phone && (
                                <div className="flex items-center gap-3">
                                    <Phone className="w-4 h-4" style={{ color: theme?.primary }} />
                                    <a href={`tel:${phone}`}>{phone}</a>
                                </div>
                            )}
                            {email && (
                                <div className="flex items-center gap-3">
                                    <Mail className="w-4 h-4" style={{ color: theme?.primary }} />
                                    <a href={`mailto:${email}`}>{email}</a>
                                </div>
                            )}
                            {locations.map((l, i) => (
                                <div key={l.id || i} className="flex items-start gap-3">
                                    <MapPin className="w-4 h-4 mt-0.5" style={{ color: theme?.primary }} />
                                    <div>
                                        {l.name && <div className="font-medium">{l.name}</div>}
                                        <div>{[l.address, l.city, l.region].filter(Boolean).join(", ")}</div>
                                        {l.phone && <div style={{ color: `${theme?.foreground}90` }}>{l.phone}</div>}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Hours */}
                    <div className="rounded-2xl p-6 border"
                         style={{ background: theme?.surface, borderColor: `${theme?.foreground}14` }}>
                        <h3 data-heading className="text-lg font-semibold flex items-center gap-2">
                            <Clock className="w-4 h-4" style={{ color: theme?.primary }} />
                            Hours
                        </h3>
                        <dl className="mt-4 text-sm divide-y" style={{ borderColor: `${theme?.foreground}14` }}>
                            {hours.map((h) => (
                                <div key={h.day} className="flex items-center justify-between py-2"
                                     style={{ borderColor: `${theme?.foreground}14` }}>
                                    <dt className="font-medium w-16">{h.day}</dt>
                                    <dd style={{ color: h.closed ? `${theme?.foreground}70` : `${theme?.foreground}` }}>
                                        {h.closed ? "Closed" : `${h.open || ""}${h.open ? " – " : ""}${h.close || ""}`}
                                    </dd>
                                </div>
                            ))}
                        </dl>
                    </div>
                </div>
            </div>
        </section>
    );
}
