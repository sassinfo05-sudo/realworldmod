"""Central config. Everything the founder will eventually edit lives here or in DB."""
import os
from typing import Any, Dict

# --- Brand (Phase 1: hardcoded defaults; founder editable via DB in later phases) ---
BRAND_DEFAULT: Dict[str, Any] = {
    "name": "Zanelvo",
    "status": "provisional_pending_registration",
    "tagline": "The quiet operating system for service businesses.",
    "promise": "Build a website that actually books work — in under a minute.",
    "cta_label": "Build my website",
    "colors": {
        "primary": "#4F46E5",
        "primary_hover": "#4338CA",
        "accent": "#D6289B",
        "accent_2": "#F59E0B",
        "foreground": "#0B0A16",
        "background": "#FAFAFB",
        "surface": "#FFFFFF",
        "border": "#E6E5EF",
        "gradient": "linear-gradient(135deg, #4F46E5 0%, #D6289B 55%, #F59E0B 100%)",
    },
    "typography": {
        "heading": "Fraunces, Cabinet Grotesk, serif",
        "body": "DM Sans, IBM Plex Sans, sans-serif",
        "mono": "JetBrains Mono, monospace",
    },
    "logo_svg": (
        # Zanelvo mark: a bold geometric "Z" in a rounded-square tile with a
        # signature indigo -> magenta -> amber gradient. Self-colored (own gradient),
        # scales crisply, works on light or dark. width/height fill the container.
        '<svg viewBox="0 0 40 40" width="100%" height="100%" '
        'xmlns="http://www.w3.org/2000/svg" aria-label="Zanelvo mark">'
        '<defs>'
        '<linearGradient id="zvg" x1="0" y1="0" x2="40" y2="40" '
        'gradientUnits="userSpaceOnUse">'
        '<stop offset="0" stop-color="#4F46E5"/>'
        '<stop offset="0.55" stop-color="#D6289B"/>'
        '<stop offset="1" stop-color="#F59E0B"/>'
        '</linearGradient>'
        '</defs>'
        '<rect x="2" y="2" width="36" height="36" rx="11" fill="url(#zvg)"/>'
        '<path d="M13 13 H27 L14 27 H27" fill="none" stroke="#FFFFFF" '
        'stroke-width="3.1" stroke-linecap="round" stroke-linejoin="round"/>'
        '</svg>'
    ),
}

# --- LLM ---
LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "anthropic")
LLM_MODEL = os.environ.get("LLM_MODEL", "claude-sonnet-4-6")
IMAGE_PROVIDER = os.environ.get("IMAGE_PROVIDER", "gemini")
IMAGE_MODEL = os.environ.get("IMAGE_MODEL", "gemini-3.1-flash-image-preview")
EMERGENT_LLM_KEY = os.environ.get("EMERGENT_LLM_KEY", "")

# --- Auth ---
JWT_SECRET = os.environ["JWT_SECRET"]
JWT_ALG = os.environ.get("JWT_ALG", "HS256")
JWT_ACCESS_TTL_MIN = int(os.environ.get("JWT_ACCESS_TTL_MIN", "1440"))

# --- Seed accounts (emails only; passwords generated at seed time) ---
FOUNDER_EMAIL = os.environ.get("FOUNDER_EMAIL", "founder@zanelvo.com")
DEMO_OWNER_EMAIL = os.environ.get("DEMO_OWNER_EMAIL", "owner@demo.zanelvo.com")

# Emails that MAY be treated as platform founders for CONVENIENCE in non-production only.
# There is NO hardcoded default: an address is never a founder just because it appears in source.
# In production, founder access is granted ONLY via explicit provisioning (scripts.bootstrap_founder /
# staff invite) — email-match auto-promotion is disabled (see auth_oauth + is_founder_autopromote_allowed).
FOUNDER_EMAILS = {
    e.strip().lower()
    for e in os.environ.get("FOUNDER_EMAILS", "").split(",")
    if e.strip()
}

APP_ENV = os.environ.get("APP_ENV", "dev").strip().lower()

# Environments where simulated/sandbox money flows and demo seeding are permitted.
SIMULATION_ENVS = {"dev", "test", "demo"}


def simulation_allowed() -> bool:
    """True only in explicit non-production environments. Production (any APP_ENV
    not in SIMULATION_ENVS) must NEVER accept simulated payments/completions."""
    return APP_ENV in SIMULATION_ENVS


def is_production() -> bool:
    return not simulation_allowed()


def is_founder_autopromote_allowed() -> bool:
    """Email-match founder auto-promotion is a NON-PRODUCTION convenience only. In production,
    founder access must be provisioned explicitly (scripts.bootstrap_founder / staff invite)."""
    return simulation_allowed()


# --- Plans (seeded into DB on startup) ---
PLANS_SEED_VERSION = 6   # bump to force-refresh plan copy/prices in the DB (founder edits otherwise persist)

# Pricing benchmarked against Wix (Light $17 / Core $29 / Business $36 / Elite $159) and
# Shopify (Basic $39 / Grow $105 / Advanced $399). Annual = ~2 months free.
PLANS_SEED = [
    {
        "code": "free", "name": "Free", "price_usd": 0, "annual_price_usd": 0,
        "limits": {"ai_credits_usd_per_month": 0.10, "variable_provider_cap_usd": 0.25},
        "tagline": "Launch a one-page AI site in minutes.",
        "audience": "Testing the waters",
        "features": [
            "AI-generated one-page website",
            "Free zanelvo.com/site address",
            "Simple store — up to 10 products",
            "Contact form + inbox (100 emails/mo)",
            "1 team seat · 100 contacts",
            "Zanelvo badge in footer",
        ],
        "cta": "Start free", "highlight": False, "order": 1,
    },
    {
        "code": "launch", "name": "Starter", "price_usd": 17, "annual_price_usd": 170,
        "limits": {"ai_credits_usd_per_month": 1.00, "variable_provider_cap_usd": 2.04},
        "tagline": "A real multi-page site on your own domain.",
        "audience": "Solo businesses & freelancers",
        "features": [
            "Full multi-page AI website + visual editor",
            "Custom domain + SSL (when the platform DNS provider is connected)",
            "Store with up to 100 products",
            "Multi-language storefront + authored translations",
            "Remove Zanelvo badge · SEO tools & analytics",
            "2 team seats · 1,000 contacts · 2,500 emails/mo",
        ],
        "cta": "Choose Starter", "highlight": False, "order": 2,
    },
    {
        "code": "revenue", "name": "Business", "price_usd": 39, "annual_price_usd": 390,
        "limits": {"ai_credits_usd_per_month": 3.00, "variable_provider_cap_usd": 4.68},
        "tagline": "Sell, book and get paid from one dashboard.",
        "audience": "Growing service businesses",
        "features": [
            "Everything in Starter",
            "2 websites · up to 2,000 products",
            "Online store with Stripe checkout (via Stripe Connect)",
            "Bookings, quotes, invoices & payments",
            "Email marketing (block editor), automations & A/B testing",
            "Abandoned-cart recovery · advanced analytics",
            "5 seats · 10,000 contacts · 15,000 emails/mo · API keys",
        ],
        "badge": "Most popular", "cta": "Choose Business", "highlight": True, "order": 3,
    },
    {
        "code": "autopilot", "name": "Commerce + AI", "price_usd": 99, "annual_price_usd": 990,
        "limits": {"ai_credits_usd_per_month": 8.00, "variable_provider_cap_usd": 11.88},
        "tagline": "AI employees handle chat, email and follow-ups.",
        "audience": "Teams that want to automate",
        "features": [
            "Everything in Business",
            "3 websites · up to 10,000 products · staging & rollback",
            "AI receptionist (chat + email) & quote drafter",
            "Reviews & reputation management",
            "AI voice receptionist add-on (pass-through minutes, when a voice provider is connected)",
            "10 seats · 25,000 contacts · 50,000 emails/mo",
        ],
        "cta": "Choose Commerce + AI", "highlight": False, "order": 4,
    },
    {
        "code": "scale", "name": "Scale", "price_usd": 249, "annual_price_usd": 2490,
        "limits": {"ai_credits_usd_per_month": 20.00, "variable_provider_cap_usd": 29.88},
        "tagline": "Multi-location, multi-brand operations.",
        "audience": "Agencies & multi-location operators",
        "features": [
            "Everything in Commerce + AI",
            "10 websites · up to 100k products",
            "Multi-location dashboards & roles",
            "Priority support + SLA + white-glove onboarding",
            "100 seats · 250,000 contacts · 250,000 emails/mo",
            "AI voice receptionist add-on (pass-through minutes, when a voice provider is connected)",
        ],
        "cta": "Talk to sales", "highlight": False, "order": 5,
    },
]

# --- Industry catalog (used by interview + generation) ---
INDUSTRIES = [
    {"key": "home_services", "label": "Home services", "examples": "plumbing, HVAC, electrical, roofing, landscaping"},
    {"key": "automotive", "label": "Automotive", "examples": "mechanic, detailing, tires, body shop"},
    {"key": "beauty_wellness", "label": "Beauty & wellness", "examples": "hair salon, spa, nails, massage"},
    {"key": "professional_services", "label": "Professional services", "examples": "accounting, legal, consulting, coaching"},
    {"key": "fitness", "label": "Fitness & training", "examples": "personal training, yoga, martial arts"},
    {"key": "cleaning", "label": "Cleaning", "examples": "residential, commercial, carpet"},
    {"key": "events", "label": "Events & catering", "examples": "catering, photography, DJ, planners"},
    {"key": "other", "label": "Something else", "examples": ""},
]
