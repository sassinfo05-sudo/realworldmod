"""Strict, dependency-light SVG sanitiser.

SVGs are rendered on the client via `dangerouslySetInnerHTML` (logos, brand marks).
Any untrusted SVG must be scrubbed of executable content BEFORE it is stored or
returned. This uses a conservative allow-list approach: unknown/dangerous elements
and attributes are removed rather than escaped.

Removed:
  * <script>, <foreignObject>, <iframe>, <object>, <embed>, <animate*> with
    javascript, <handler>, <set>, <use>/<image> that reference external/remote/data
  * on* event-handler attributes (onload, onclick, …)
  * href / xlink:href / src values using javascript:, vbscript:, or non-image data: URIs
  * external http(s):// references inside href/src (SSRF / tracking)
  * <style> blocks containing expression()/javascript:/@import/url(http…)
"""
from __future__ import annotations

import re
from typing import Optional

# Elements that must never survive in a stored SVG.
_FORBIDDEN_ELEMENTS = [
    "script", "foreignobject", "iframe", "object", "embed", "handler",
    "set", "audio", "video", "annotation-xml",
]

# Regexes (case-insensitive, dotall for element bodies).
_RE_FORBIDDEN = {
    el: re.compile(rf"<\s*{el}\b.*?(?:>.*?<\s*/\s*{el}\s*>|/\s*>)", re.IGNORECASE | re.DOTALL)
    for el in _FORBIDDEN_ELEMENTS
}
# Also strip any orphan opening/closing tags of forbidden elements.
_RE_FORBIDDEN_TAGS = re.compile(
    r"<\s*/?\s*(?:" + "|".join(_FORBIDDEN_ELEMENTS) + r")\b[^>]*>",
    re.IGNORECASE,
)
# on*="..." / on*='...' / on*=bare event handlers.
_RE_EVENT_ATTR = re.compile(r"""\s+on[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)""", re.IGNORECASE)
# href / xlink:href / src / xlink:src with dangerous or remote values.
_RE_DANGEROUS_URL_ATTR = re.compile(
    r"""\s+(?:xlink:)?(?:href|src)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))""",
    re.IGNORECASE,
)
_RE_STYLE_BLOCK = re.compile(r"<\s*style\b[^>]*>.*?<\s*/\s*style\s*>", re.IGNORECASE | re.DOTALL)
_RE_JS_IN_STYLE = re.compile(r"(expression\s*\(|javascript:|@import|url\s*\(\s*['\"]?https?:)", re.IGNORECASE)
_RE_STYLE_ATTR_JS = re.compile(r"""\s+style\s*=\s*(?:"[^"]*"|'[^']*')""", re.IGNORECASE)


def _safe_url(value: str) -> bool:
    """Allow only local anchors (#id) and inline image data URIs."""
    v = (value or "").strip().lower()
    if v.startswith("#"):
        return True
    if v.startswith("data:image/") and "script" not in v:
        return True
    # Reject everything else: http(s), //, javascript:, vbscript:, data:text, file:, etc.
    return False


def _strip_dangerous_urls(svg: str) -> str:
    def repl(m: re.Match) -> str:
        value = m.group(1) or m.group(2) or m.group(3) or ""
        if _safe_url(value):
            return m.group(0)
        return ""  # drop the whole attribute
    return _RE_DANGEROUS_URL_ATTR.sub(repl, svg)


def _clean_style_attrs(svg: str) -> str:
    def repl(m: re.Match) -> str:
        return "" if _RE_JS_IN_STYLE.search(m.group(0)) else m.group(0)
    return _RE_STYLE_ATTR_JS.sub(repl, svg)


def _clean_style_blocks(svg: str) -> str:
    def repl(m: re.Match) -> str:
        return "" if _RE_JS_IN_STYLE.search(m.group(0)) else m.group(0)
    return _RE_STYLE_BLOCK.sub(repl, svg)


def sanitize_svg(svg: Optional[str], *, max_len: int = 200_000) -> str:
    """Return a sanitised SVG string safe to render. Non-SVG input returns ""."""
    if not svg or not isinstance(svg, str):
        return ""
    s = svg.strip()
    if len(s) > max_len:
        s = s[:max_len]
    # Must actually look like an SVG; otherwise reject entirely.
    if "<svg" not in s.lower():
        return ""
    # 1) Remove forbidden element bodies, then any stray forbidden tags.
    for rx in _RE_FORBIDDEN.values():
        s = rx.sub("", s)
    s = _RE_FORBIDDEN_TAGS.sub("", s)
    # 2) Remove event-handler attributes.
    s = _RE_EVENT_ATTR.sub("", s)
    # 3) Neutralise dangerous/remote URL references.
    s = _strip_dangerous_urls(s)
    # 4) Scrub <style> blocks and style="" attributes containing JS/remote urls.
    s = _clean_style_blocks(s)
    s = _clean_style_attrs(s)
    # 5) Belt-and-braces: kill any lingering javascript:/vbscript: token.
    s = re.sub(r"(javascript|vbscript)\s*:", "", s, flags=re.IGNORECASE)
    return s.strip()



# ---------------------------------------------------------------------------
# Rich-text HTML sanitiser (nh3 / ammonia) for tenant-authored legal/about copy
# rendered via dangerouslySetInnerHTML on public pages. Strict allow-list only.
# ---------------------------------------------------------------------------
try:
    import nh3  # type: ignore
    _HAS_NH3 = True
except Exception:  # noqa: BLE001
    _HAS_NH3 = False

_ALLOWED_TAGS = {
    "p", "br", "hr", "h1", "h2", "h3", "h4", "h5", "h6",
    "strong", "b", "em", "i", "u", "s", "small", "sub", "sup",
    "ul", "ol", "li", "blockquote", "pre", "code",
    "a", "span", "div", "table", "thead", "tbody", "tr", "th", "td",
}
_ALLOWED_ATTRS = {"a": {"href", "title", "target"}, "*": {"class"}}


def sanitize_html(html: Optional[str], *, max_len: int = 200_000) -> str:
    """Sanitise tenant/AI-authored HTML with a strict allow-list.

    Strips <script>/<style>/<iframe>/event-handlers/javascript: URLs etc. Links are
    forced to safe schemes and rel="noopener noreferrer nofollow". Falls back to a
    regex scrub only if nh3 is somehow unavailable (should never happen in prod)."""
    if not html:
        return ""
    s = str(html)[:max_len]
    if _HAS_NH3:
        return nh3.clean(
            s,
            tags=_ALLOWED_TAGS,
            attributes=_ALLOWED_ATTRS,
            url_schemes={"http", "https", "mailto", "tel"},
            link_rel="noopener noreferrer nofollow",
            strip_comments=True,
        )
    # Defensive fallback (dependency missing): remove scripts/handlers/js urls.
    s = re.sub(r"(?is)<\s*(script|style|iframe|object|embed|link|meta)[^>]*>.*?<\s*/\s*\1\s*>", "", s)
    s = re.sub(r"(?is)<\s*(script|style|iframe|object|embed|link|meta)[^>]*/?>", "", s)
    s = re.sub(r'(?is)\son\w+\s*=\s*"[^"]*"', "", s)
    s = re.sub(r"(?is)\son\w+\s*=\s*'[^']*'", "", s)
    s = re.sub(r"(?i)(javascript|vbscript|data)\s*:", "", s)
    return s.strip()
