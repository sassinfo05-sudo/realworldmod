import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Wordmark } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const STEPS = [
    "Understanding your business",
    "Structuring services & prices",
    "Choosing a tone and palette",
    "Writing pages that read like you",
    "Assembling your workspace",
];

export default function Generating() {
    const [status, setStatus] = useState("generating");
    const [error, setError] = useState(null);
    const [stepIndex, setStepIndex] = useState(0);
    const navigate = useNavigate();

    useEffect(() => {
        // animate the labels while we wait for status
        const timer = setInterval(() => {
            setStepIndex((i) => (i < STEPS.length - 1 ? i + 1 : i));
        }, 3800);

        const poll = setInterval(async () => {
            try {
                const { data } = await api.get("/onboarding/session/status");
                setStatus(data.status);
                if (data.status === "ready") {
                    clearInterval(poll);
                    clearInterval(timer);
                    navigate("/review");
                } else if (data.status === "failed") {
                    setError(data.error || "Generation failed");
                    clearInterval(poll);
                    clearInterval(timer);
                }
            } catch (err) {
                // keep polling
            }
        }, 2000);

        return () => { clearInterval(poll); clearInterval(timer); };
    }, [navigate]);

    async function retry() {
        setError(null);
        setStatus("generating");
        setStepIndex(0);
        try {
            await api.post("/onboarding/generate");
        } catch (e) {
            toast.error("Could not restart generation");
        }
    }

    return (
        <div className="min-h-screen bg-brand-surface flex items-center justify-center" data-testid="generating-page">
            <div className="mx-auto max-w-lg px-6">
                <div className="flex items-center justify-center mb-8">
                    <Wordmark />
                </div>
                <div className="rounded-2xl border border-brand-line bg-white p-8 shadow-sm">
                    {!error ? (
                        <>
                            <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">
                                Generating with Claude Sonnet 4.6
                            </div>
                            <h1 className="mt-3 font-display text-2xl text-brand-ink font-medium">
                                Writing a site that reads like your business.
                            </h1>
                            <p className="mt-2 text-sm text-zinc-500">
                                We're keeping every fact you gave us. Nothing invented.
                            </p>

                            <ul className="mt-6 space-y-2">
                                {STEPS.map((s, i) => {
                                    const done = i < stepIndex;
                                    const active = i === stepIndex;
                                    return (
                                        <li
                                            key={s}
                                            className={`flex items-center gap-3 text-sm rounded-md px-3 py-2 transition-all ${
                                                active ? "bg-brand-cream text-brand-ink font-medium"
                                                       : done ? "text-brand-ink" : "text-zinc-400"
                                            }`}
                                            data-testid={`generating-step-${i}`}
                                        >
                                            <span className={`inline-block w-2 h-2 rounded-full ${
                                                done ? "bg-brand-copper" : active ? "bg-brand-copper animate-pulse" : "bg-zinc-300"
                                            }`} />
                                            {s}
                                        </li>
                                    );
                                })}
                            </ul>

                            <div className="mt-6 h-1 rounded-full bg-brand-line overflow-hidden relative">
                                <div className="absolute inset-y-0 w-1/3 bg-brand-copper animate-shimmer" />
                            </div>
                        </>
                    ) : (
                        <>
                            <div className="text-xs uppercase tracking-[0.28em] text-red-600">Generation failed</div>
                            <h1 className="mt-3 font-display text-2xl text-brand-ink font-medium">
                                We couldn't finish this run.
                            </h1>
                            <p className="mt-2 text-sm text-zinc-600 break-words">{error}</p>
                            <div className="mt-6 flex gap-3">
                                <Button onClick={retry} className="bg-brand-copper hover:bg-brand-copperHover text-white"
                                        data-testid="generating-retry">
                                    Try again
                                </Button>
                                <Button variant="ghost" onClick={() => navigate("/onboarding")}
                                        data-testid="generating-back-to-interview">
                                    Back to the interview
                                </Button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}
