import { useEffect, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { Cpu, DollarSign, Layers, Building2, ShieldAlert, Pause, Play, Download, Percent, Zap } from "lucide-react";

function Stat({ label, value, icon: Icon, tone = "" }) {
    return (
        <div className="rounded-xl border border-white/10 bg-white/5 p-4">
            <div className="flex items-center gap-2 text-white/50 text-xs uppercase tracking-widest">
                {Icon && <Icon className="w-3.5 h-3.5" />}{label}
            </div>
            <div className={`mt-2 text-2xl font-semibold ${tone}`}>{value}</div>
        </div>
    );
}

function Bars({ rows, valueKey = "cost_usd", labelKey = "key", prefix = "$", decimals = 4 }) {
    const max = Math.max(1e-9, ...rows.map((r) => r[valueKey] || 0));
    return (
        <div className="space-y-2">
            {rows.length === 0 && <div className="text-white/40 text-sm">No usage yet this month.</div>}
            {rows.map((r, i) => (
                <div key={i} className="text-sm">
                    <div className="flex justify-between mb-1">
                        <span className="text-white/70 truncate font-mono text-xs">
                            {(r.name || r[labelKey] || "unknown").replace(/^\/api\//, "")}
                        </span>
                        <span className="text-white/90 whitespace-nowrap ml-2">
                            {prefix}{Number(r[valueKey] || 0).toFixed(decimals)} · {r.calls}×{r.errors ? ` · ${r.errors} err` : ""}
                        </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-indigo-400 to-fuchsia-400"
                             style={{ width: `${Math.max(2, ((r[valueKey] || 0) / max) * 100)}%` }} />
                    </div>
                </div>
            ))}
        </div>
    );
}

const PROVIDERS = ["anthropic", "openai", "gemini", "email", "sms", "voice", "shipping", "ads"];

export default function StaffAiUsage() {
    const [data, setData] = useState(null);
    const [margin, setMargin] = useState(null);
    const [controls, setControls] = useState(null);
    const [audit, setAudit] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [budgetDraft, setBudgetDraft] = useState("");
    const [visitorCapDraft, setVisitorCapDraft] = useState("");

    async function load() {
        setLoading(true);
        try {
            const [u, m, c] = await Promise.all([
                api.get("/staff/usage/ai"), api.get("/staff/usage/margin"), api.get("/staff/usage/controls"),
            ]);
            setData(u.data); setMargin(m.data); setControls(c.data.controls); setAudit(c.data.audit || []);
            setBudgetDraft(String(c.data.controls?.global_monthly_budget_usd ?? 0));
            setVisitorCapDraft(String(c.data.controls?.public_visitor_daily_cap_usd ?? 0));
        } catch (e) { toast.error(e?.response?.data?.detail || "Cannot load (needs audit permission)"); }
        finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    async function saveControls(patch) {
        setSaving(true);
        try {
            const res = await api.put("/staff/usage/controls", patch);
            setControls(res.data.controls);
            toast.success("Controls updated");
            const c = await api.get("/staff/usage/controls"); setAudit(c.data.audit || []);
        } catch (e) { toast.error(e?.response?.data?.detail || "Update failed (needs controls permission)"); }
        finally { setSaving(false); }
    }

    async function togglePause() {
        setSaving(true);
        try {
            const res = await api.post(controls?.pause_all ? "/staff/usage/resume-all" : "/staff/usage/pause-all");
            setControls(res.data.controls);
            toast.success(res.data.controls.pause_all ? "All paid operations PAUSED" : "Paid operations resumed");
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); }
        finally { setSaving(false); }
    }

    async function exportCsv() {
        try {
            const res = await api.get("/staff/usage/ledger.csv", { responseType: "blob" });
            const url = URL.createObjectURL(res.data);
            const a = document.createElement("a"); a.href = url; a.download = `zanelvo-usage-ledger-${data?.month || "month"}.csv`; a.click();
            URL.revokeObjectURL(url);
        } catch (e) { toast.error("Export failed"); }
    }

    const gm = margin?.gross_margin_pct;

    return (
        <div className="px-4 md:px-8 py-6 max-w-6xl mx-auto" data-testid="staff-ai-usage"><div className="rounded-2xl bg-[#0d1017] text-white p-6 space-y-6 shadow-lg">
            <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                    <h1 className="text-2xl font-semibold flex items-center gap-2">
                        <Cpu className="w-6 h-6 text-fuchsia-400" /> Cost, usage & margin
                    </h1>
                    <p className="text-white/50 text-sm mt-1">
                        Every paid operation (LLM, images, email, messaging…) across all tenants — metered, reserved and reconciled. Month {data?.month || ""}.
                    </p>
                </div>
                <div className="flex gap-2">
                    <button onClick={exportCsv} className="bg-white/10 border border-white/15 rounded-md px-3 py-1.5 text-sm flex items-center gap-1.5" data-testid="ai-usage-export">
                        <Download className="w-4 h-4" /> Export ledger (CSV)
                    </button>
                    <button onClick={load} className="bg-white/10 border border-white/15 rounded-md px-3 py-1.5 text-sm" data-testid="ai-usage-refresh">
                        Refresh
                    </button>
                </div>
            </div>

            {loading ? (
                <div className="text-white/40">Loading…</div>
            ) : (
                <>
                    {controls?.pause_all && (
                        <div className="rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm flex items-center gap-2" data-testid="pause-banner">
                            <ShieldAlert className="w-4 h-4 text-red-300" /> Emergency pause is ON — every paid operation is refusing with 503 until resumed.
                        </div>
                    )}
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                        <Stat label="Metered cost (mo)" value={`$${Number(data?.total_cost_usd || 0).toFixed(2)}`} icon={DollarSign} />
                        <Stat label="MRR" value={`$${Number(margin?.mrr_usd || 0).toFixed(0)}`} icon={Building2} />
                        <Stat label="Gross margin" value={gm == null ? "—" : `${gm}%`} icon={Percent}
                              tone={gm == null ? "" : gm < 50 ? "text-amber-300" : "text-emerald-300"} />
                        <Stat label="Calls / errors" value={`${(data?.total_calls || 0).toLocaleString()} / ${data?.total_errors || 0}`} icon={Cpu} />
                        <Stat label="In-flight holds" value={`$${Number(data?.held_usd || 0).toFixed(3)}`} icon={Zap} />
                    </div>

                    {/* Controls */}
                    <div className="rounded-xl border border-white/10 bg-white/5 p-5 space-y-4" data-testid="usage-controls">
                        <div className="flex items-center justify-between flex-wrap gap-3">
                            <div className="text-sm font-medium flex items-center gap-2"><ShieldAlert className="w-4 h-4" /> Spend controls</div>
                            <button onClick={togglePause} disabled={saving}
                                    className={`rounded-md px-3 py-1.5 text-sm font-medium flex items-center gap-1.5 ${controls?.pause_all ? "bg-emerald-500 text-black" : "bg-red-500/90 text-white"}`}
                                    data-testid="pause-all-toggle">
                                {controls?.pause_all ? <><Play className="w-4 h-4" /> Resume all paid operations</> : <><Pause className="w-4 h-4" /> Emergency pause ALL</>}
                            </button>
                        </div>
                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                            <div>
                                <label className="text-white/50 text-xs uppercase tracking-widest">Founder global budget / month (USD, 0 = off)</label>
                                <div className="flex gap-2 mt-1">
                                    <input value={budgetDraft} onChange={(e) => setBudgetDraft(e.target.value)} type="number" min="0"
                                           className="bg-black/30 border border-white/15 rounded-md px-2 py-1.5 w-full" data-testid="global-budget-input" />
                                    <button onClick={() => saveControls({ global_monthly_budget_usd: Number(budgetDraft || 0) })} disabled={saving}
                                            className="bg-white/10 border border-white/15 rounded-md px-3 text-sm" data-testid="global-budget-save">Save</button>
                                </div>
                                <div className="text-white/40 text-xs mt-1">Used {data?.global_pct || 0}% · warning at {controls?.warn_pct}%</div>
                            </div>
                            <div>
                                <label className="text-white/50 text-xs uppercase tracking-widest">Visitor daily cap per tenant (USD, 0 = plan only)</label>
                                <div className="flex gap-2 mt-1">
                                    <input value={visitorCapDraft} onChange={(e) => setVisitorCapDraft(e.target.value)} type="number" min="0" step="0.1"
                                           className="bg-black/30 border border-white/15 rounded-md px-2 py-1.5 w-full" data-testid="visitor-cap-input" />
                                    <button onClick={() => saveControls({ public_visitor_daily_cap_usd: Number(visitorCapDraft || 0) })} disabled={saving}
                                            className="bg-white/10 border border-white/15 rounded-md px-3 text-sm">Save</button>
                                </div>
                                <div className="text-white/40 text-xs mt-1">Stops abusive public chat/translate from draining a tenant's quota.</div>
                            </div>
                            <div>
                                <label className="text-white/50 text-xs uppercase tracking-widest">Provider kill switches</label>
                                <div className="flex flex-wrap gap-1.5 mt-1">
                                    {PROVIDERS.map((p) => {
                                        const killed = !!controls?.provider_kill?.[p];
                                        return (
                                            <button key={p} disabled={saving}
                                                    onClick={() => saveControls({ provider_kill: { ...(controls?.provider_kill || {}), [p]: !killed } })}
                                                    className={`rounded-full px-2.5 py-1 text-xs border ${killed ? "bg-red-500/20 border-red-400/50 text-red-200" : "bg-white/5 border-white/15 text-white/70"}`}
                                                    data-testid={`kill-${p}`}>
                                                {p}{killed ? " · OFF" : ""}
                                            </button>
                                        );
                                    })}
                                </div>
                                <div className="text-white/40 text-xs mt-1">Red = disabled. Calls to that provider refuse with 503.</div>
                            </div>
                        </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="rounded-xl border border-white/10 bg-white/5 p-5">
                            <div className="text-sm font-medium mb-3 flex items-center gap-2"><Layers className="w-4 h-4" /> By feature</div>
                            <Bars rows={data?.by_feature || []} />
                        </div>
                        <div className="rounded-xl border border-white/10 bg-white/5 p-5">
                            <div className="text-sm font-medium mb-3 flex items-center gap-2"><Cpu className="w-4 h-4" /> By provider / model</div>
                            <Bars rows={[...(data?.by_provider || []), ...(data?.by_model || [])]} />
                        </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="rounded-xl border border-white/10 bg-white/5 p-5">
                            <div className="text-sm font-medium mb-3 flex items-center gap-2"><Building2 className="w-4 h-4" /> By tenant (cost)</div>
                            <Bars rows={data?.by_org || []} />
                        </div>
                        <div className="rounded-xl border border-white/10 bg-white/5 p-5" data-testid="margin-panel">
                            <div className="text-sm font-medium mb-3 flex items-center gap-2"><Percent className="w-4 h-4" /> Margin by tenant · {margin?.loss_making_orgs || 0} loss-making</div>
                            <div className="space-y-1.5 text-xs font-mono max-h-64 overflow-auto">
                                {(margin?.orgs || []).slice(0, 40).map((o) => (
                                    <div key={o.org_id} className="flex justify-between gap-2">
                                        <span className="text-white/60 truncate">{o.org_id}</span>
                                        <span className={o.loss_making ? "text-red-300" : "text-emerald-300"}>
                                            ${o.mrr_usd.toFixed(2)} − ${o.cost_usd.toFixed(4)} = ${o.margin_usd.toFixed(2)}
                                        </span>
                                    </div>
                                ))}
                                {(margin?.orgs || []).length === 0 && <div className="text-white/40">No subscriptions or usage yet.</div>}
                            </div>
                        </div>
                    </div>

                    <div className="rounded-xl border border-white/10 bg-white/5 p-5" data-testid="controls-audit">
                        <div className="text-sm font-medium mb-3">Controls audit history</div>
                        <div className="space-y-1 text-xs font-mono text-white/60 max-h-48 overflow-auto">
                            {audit.length === 0 && <div className="text-white/40">No changes recorded yet.</div>}
                            {audit.map((a) => (
                                <div key={a.id}>{a.created_at?.slice(0, 19)} · {a.actor || "system"} · pause={String(a.after?.pause_all)} · budget=${a.after?.global_monthly_budget_usd} · kills={Object.entries(a.after?.provider_kill || {}).filter(([, v]) => v).map(([k]) => k).join(",") || "none"}</div>
                            ))}
                        </div>
                    </div>
                </>
            )}
        </div></div>
    );
}
