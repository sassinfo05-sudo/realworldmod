"""Phase 7 models: Campaigns, Automations, Ad Creative bundles, Review-request config."""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import Field

from .db import BaseDocument


class Campaign(BaseDocument):
    org_id: str
    name: str
    subject: str
    body_text: str = ""
    body_html: Optional[str] = None
    from_name: Optional[str] = None
    segment: Dict[str, Any] = Field(default_factory=dict)   # {"tag": "hot", "consent": True, ...}
    status: Literal["draft", "scheduled", "sending", "sent", "failed", "paused"] = "draft"
    scheduled_at: Optional[str] = None
    sent_at: Optional[str] = None
    metrics: Dict[str, int] = Field(default_factory=dict)   # {"sent": n, "delivered": n, "replies": n, ...}
    review_request: bool = False                             # is this a review-request template
    review_link: Optional[str] = None
    # Ads/marketing extension
    budget_cap_cents: int = 0
    requires_approval: bool = False
    approved: bool = True
    paused: bool = False


class Automation(BaseDocument):
    org_id: str
    name: str
    trigger: str                       # form_submitted, booking_created, invoice_overdue, job_completed, tag_added
    condition: Dict[str, Any] = Field(default_factory=dict)
    actions: List[Dict[str, Any]] = Field(default_factory=list)  # [{"type": "send_email", ...}, ...]
    status: Literal["draft", "published", "paused"] = "draft"
    version: int = 1
    is_template: bool = False


class AutomationRun(BaseDocument):
    org_id: str
    automation_id: str
    trigger: str
    context: Dict[str, Any] = Field(default_factory=dict)
    step_results: List[Dict[str, Any]] = Field(default_factory=list)   # per action
    status: Literal["running", "completed", "failed"] = "running"
    error: Optional[str] = None


class AdBundle(BaseDocument):
    org_id: str
    name: str
    offer: str
    audience: str
    languages: List[str] = Field(default_factory=lambda: ["en"])
    copy_variants: List[Dict[str, Any]] = Field(default_factory=list)  # {lang, headline, body, cta}
    storyboard: List[Dict[str, str]] = Field(default_factory=list)     # [{scene, visual, voiceover, caption}]
    video_script: str = ""
    image_placeholders: List[Dict[str, str]] = Field(default_factory=list)  # DEMO-labeled
    cost_cents: int = 0
    provider_state: Dict[str, str] = Field(default_factory=lambda: {
        "google_ads": "not_connected", "meta_ads": "not_connected",
        "image_gen": "demo",   # demo | connected | not_connected
        "video_gen": "not_connected",
    })
    provenance: Dict[str, Any] = Field(default_factory=dict)
