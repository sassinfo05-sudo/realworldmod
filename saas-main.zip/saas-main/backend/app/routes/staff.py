"""Zanelvo Staff panel — separate account database (`staff_accounts`), preset roles,
mandatory email 2FA (skipped only while the platform 2FA sender is unconfigured).

Mounted at /api/staff. Staff tokens carry `staff: true`; `deps.current_user` maps them to
a User with role `platform_founder` + `staff_role`, so every existing founder route keeps
working, while `require_staff(...)` gives fine-grained gating.
"""
from __future__ import annotations

import hashlib
import re
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr, Field

from .. import config
from ..db import get_db, utc_now_iso
from ..deps import current_user, require_staff
from ..models import User
from ..security import create_access_token, hash_password, verify_password
from ..services import audit, rate_limit, twofa
from ..services import platform_settings as ps

router = APIRouter(prefix="/api/staff", tags=["staff"])

# Preset roles. `perms` are coarse capability keys checked by require_staff().
STAFF_ROLES: Dict[str, Dict[str, Any]] = {
    "owner":     {"label": "Owner",     "desc": "Full control. Keys, billing, staff, everything.",
                  "perms": ["*"]},
    "admin":     {"label": "Admin",     "desc": "Everything except payment keys & deleting the owner.",
                  "perms": ["tenants", "pricing", "branding", "emails", "legal", "controls", "audit",
                            "health", "approvals", "staff", "integrations.read"]},
    "support":   {"label": "Support",   "desc": "Tenants, impersonation, approvals, audit.",
                  "perms": ["tenants", "approvals", "audit", "health"]},
    "finance":   {"label": "Finance",   "desc": "Pricing, plan economics, metrics, billing.",
                  "perms": ["pricing", "metrics", "audit"]},
    "developer": {"label": "Developer", "desc": "Integrations, health, controls, audit.",
                  "perms": ["integrations", "integrations.read", "health", "controls", "audit"]},
    "marketing": {"label": "Marketing", "desc": "Branding, emails, legal & about copy, metrics.",
                  "perms": ["branding", "emails", "legal", "metrics"]},
}


def role_has(role: str, perm: str) -> bool:
    perms = (STAFF_ROLES.get(role) or {}).get("perms", [])
    return "*" in perms or perm in perms


def _public(doc: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": str(doc["_id"]), "email": doc["email"], "full_name": doc.get("full_name"),
        "role": doc.get("role", "support"), "work_email": doc.get("work_email"),
        "active": doc.get("active", True), "last_login_at": doc.get("last_login_at"),
        "created_at": doc.get("created_at"), "mfa": "email (always on)",
        "invite_pending": bool(doc.get("invite_pending")),
        "perms": (STAFF_ROLES.get(doc.get("role", "")) or {}).get("perms", []),
    }


async def _brand_domain() -> str:
    s = await ps.get_settings()
    url = (s.get("product_url") or "https://zanelvo.com").replace("https://", "").replace("http://", "")
    return url.split("/")[0].replace("www.", "") or "zanelvo.com"


async def _unique_work_email(handle_src: str, exclude_id: Optional[ObjectId] = None) -> str:
    db = get_db()
    domain = await _brand_domain()
    base = re.sub(r"[^a-z0-9.]+", ".", (handle_src or "staff").lower().split("@")[0]).strip(".") or "staff"
    cand, n = f"{base}@{domain}", 1
    while await db.staff_accounts.find_one({"work_email": cand, **({"_id": {"$ne": exclude_id}} if exclude_id else {})}):
        n += 1
        cand = f"{base}{n}@{domain}"
    return cand


async def ensure_owner_seed() -> None:
    """Idempotent: mirror the founder user into staff_accounts as `owner` (same password)."""
    db = get_db()
    founder = await db.users.find_one({"email": config.FOUNDER_EMAIL})
    if not founder:
        return
    existing = await db.staff_accounts.find_one({"email": config.FOUNDER_EMAIL})
    if existing:
        if existing.get("password_hash") != founder["password_hash"]:
            await db.staff_accounts.update_one({"_id": existing["_id"]},
                                               {"$set": {"password_hash": founder["password_hash"]}})
        return
    await db.staff_accounts.insert_one({
        "email": config.FOUNDER_EMAIL, "password_hash": founder["password_hash"],
        "full_name": founder.get("full_name") or "Founder", "role": "owner",
        "work_email": await _unique_work_email("founder"), "active": True,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })


# ---------------- auth ----------------

class StaffLoginReq(BaseModel):
    email: EmailStr
    password: str


class Verify2faReq(BaseModel):
    challenge_id: str
    code: str


def _token_for(doc: Dict[str, Any]) -> Dict[str, Any]:
    token = create_access_token(str(doc["_id"]), None, "platform_founder",
                                extra={"staff": True, "staff_role": doc.get("role", "support")})
    return {"access_token": token, "token_type": "bearer", "staff": _public(doc)}


@router.post("/auth/login")
async def staff_login(req: StaffLoginReq, request: Request):
    # Distributed (Mongo-backed, multi-worker safe) limiter — in-memory counters differ per worker.
    await rate_limit.check_persistent("staff_login", request, limit=10, window_seconds=300)
    db = get_db()
    doc = await db.staff_accounts.find_one({"email": req.email.lower().strip()})
    if not doc or not doc.get("active", True) or not verify_password(req.password, doc["password_hash"]):
        raise HTTPException(401, "Invalid staff credentials")
    if await twofa.email_2fa_available():
        brand = (await ps.get_settings()).get("brand_name", "Zanelvo")
        return await twofa.create_challenge(str(doc["_id"]), doc["email"], "staff", brand)
    # FAIL CLOSED in production: if the MFA provider is not configured we must NOT issue an
    # authenticated session on password alone. Only dev/test/demo may skip MFA for convenience.
    if config.APP_ENV not in ("dev", "test", "demo"):
        raise HTTPException(503, detail={
            "error": "mfa_unavailable",
            "message": "Staff sign-in requires multi-factor authentication, which is not configured "
                       "yet. Connect a platform email provider in Staff Setup before signing in."})
    await db.staff_accounts.update_one({"_id": doc["_id"]}, {"$set": {"last_login_at": utc_now_iso()}})
    return {**_token_for(doc), "mfa_required": False, "mfa_skipped_reason": "2FA sender email not configured"}


@router.post("/auth/2fa/verify")
async def staff_verify(req: Verify2faReq, request: Request):
    await rate_limit.check_persistent("staff_2fa", request, limit=20, window_seconds=300)
    ch = await twofa.verify_challenge(req.challenge_id, req.code, "staff")
    db = get_db()
    doc = await db.staff_accounts.find_one({"_id": ObjectId(ch["subject_id"])})
    if not doc or not doc.get("active", True):
        raise HTTPException(401, "Account disabled")
    await db.staff_accounts.update_one({"_id": doc["_id"]}, {"$set": {"last_login_at": utc_now_iso()}})
    return {**_token_for(doc), "mfa_required": False}


@router.post("/auth/2fa/resend")
async def staff_resend(body: Dict[str, str] = Body(...)):
    brand = (await ps.get_settings()).get("brand_name", "Zanelvo")
    return await twofa.resend_challenge(body.get("challenge_id", ""), "staff", brand)


@router.get("/me")
async def staff_me(user: User = Depends(current_user)):
    if not getattr(user, "staff_role", None):
        raise HTTPException(403, "Not a staff session")
    db = get_db()
    doc = await db.staff_accounts.find_one({"_id": ObjectId(user.id)})
    if not doc:
        raise HTTPException(401, "Staff account not found")
    return {**_public(doc), "twofa_email_configured": await twofa.email_2fa_available()}


@router.get("/roles")
async def list_roles():
    return [{"key": k, **v} for k, v in STAFF_ROLES.items()]


# ---------------- members ----------------

class MemberCreate(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=1, max_length=80)
    role: str = "support"
    work_handle: Optional[str] = None   # → handle@zanelvo.com
    password: Optional[str] = None      # generated when omitted


class MemberPatch(BaseModel):
    full_name: Optional[str] = None
    role: Optional[str] = None
    work_handle: Optional[str] = None
    active: Optional[bool] = None
    new_password: Optional[str] = Field(default=None, min_length=10, max_length=128)


@router.get("/members")
async def list_members(_: User = Depends(require_staff("staff"))):
    db = get_db()
    return [_public(d) async for d in db.staff_accounts.find({}).sort("created_at", 1)]


@router.post("/members", status_code=201)
async def create_member(req: MemberCreate, request: Request, actor: User = Depends(require_staff("staff"))):
    db = get_db()
    if req.role not in STAFF_ROLES:
        raise HTTPException(400, f"Unknown role. Choose one of {list(STAFF_ROLES)}")
    if req.role == "owner" and actor.staff_role != "owner":
        raise HTTPException(403, "Only the owner can create another owner")
    email = req.email.lower().strip()
    if await db.staff_accounts.find_one({"email": email}):
        raise HTTPException(409, "A staff account with this email already exists")
    doc = {
        "email": email, "full_name": req.full_name.strip(),
        "role": req.role, "work_email": await _unique_work_email(req.work_handle or req.full_name),
        "active": True, "created_by": actor.id, "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    }
    if req.password:
        # Creator explicitly typed a password (e.g. bootstrap). Never echo it back.
        doc["password_hash"] = hash_password(req.password)
        doc["password_set_at"] = utc_now_iso()
    else:
        # No usable password until the invitee sets one via the short-lived invitation link.
        doc["password_hash"] = hash_password(secrets.token_urlsafe(32))
        doc["invite_pending"] = True
    r = await db.staff_accounts.insert_one(doc)
    doc["_id"] = r.inserted_id
    await audit.record(action="staff.create", actor_user_id=actor.id, actor_role="staff:" + (actor.staff_role or ""),
                       actor_email=actor.email, target_type="staff", target_id=str(r.inserted_id),
                       meta={"role": req.role, "invited": not bool(req.password)}, request=request)
    out = {**_public(doc), "emailed": False}
    if not req.password:
        inv = await _issue_invitation(db, doc, actor, request)
        out.update(inv)
    return out


# ---------------------------------------------------------------------------
# Set-password invitations (replaces emailed / API-returned temporary passwords).
# Token is random, stored ONLY as a SHA-256 hash, expires after INVITE_TTL_HOURS, single-use
# (atomic find_one_and_update claim). The raw token is only ever placed in the emailed link.
# ---------------------------------------------------------------------------
INVITE_TTL_HOURS = 48


def _hash_token(tok: str) -> str:
    return hashlib.sha256(tok.encode("utf-8")).hexdigest()


async def _issue_invitation(db, staff_doc: Dict[str, Any], actor: User, request: Request) -> Dict[str, Any]:
    raw = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    exp = now + timedelta(hours=INVITE_TTL_HOURS)
    # Supersede any previous unused invitation for this account.
    await db.staff_invitations.update_many(
        {"staff_id": str(staff_doc["_id"]), "used_at": None},
        {"$set": {"revoked_at": utc_now_iso()}})
    await db.staff_invitations.insert_one({
        "staff_id": str(staff_doc["_id"]), "email": staff_doc["email"], "token_hash": _hash_token(raw),
        "created_by": actor.id, "created_at": utc_now_iso(),
        "expires_at": exp.isoformat().replace("+00:00", "Z"), "used_at": None, "revoked_at": None,
    })
    origin = (request.headers.get("origin") or "").rstrip("/")
    link = f"{origin}/staff/set-password?token={raw}" if origin else f"/staff/set-password?token={raw}"
    from ..services import platform_mail
    mail = await platform_mail.send(
        "noreply", staff_doc["email"], "Set up your Zanelvo staff account",
        f"Hi {staff_doc.get('full_name') or ''},\n\nYou have been given a "
        f"{STAFF_ROLES.get(staff_doc.get('role'), {}).get('label', staff_doc.get('role'))} account on the Zanelvo staff panel.\n"
        f"Choose your password here (link valid for {INVITE_TTL_HOURS} hours, single use):\n{link}\n\n"
        f"Your work alias: {staff_doc.get('work_email')}\nIf you did not expect this, ignore this email.")
    emailed = bool(mail.get("ok") and not mail.get("simulated"))
    out: Dict[str, Any] = {"emailed": emailed, "invite_expires_at": exp.isoformat().replace("+00:00", "Z")}
    if not emailed:
        if config.APP_ENV in ("dev", "test", "demo"):
            # Dev/test convenience only — production never returns the link over the API.
            out["invite_link"] = link
        else:
            out["note"] = ("No platform email provider is connected — connect one in Staff Setup, "
                           "then use 'Resend invitation'.")
    return out


@router.post("/members/{mid}/reinvite")
async def reinvite_member(mid: str, request: Request, actor: User = Depends(require_staff("staff"))):
    db = get_db()
    try:
        oid = ObjectId(mid)
    except Exception:
        raise HTTPException(404, "Not found")
    doc = await db.staff_accounts.find_one({"_id": oid})
    if not doc:
        raise HTTPException(404, "Not found")
    if doc.get("role") == "owner" and actor.staff_role != "owner":
        raise HTTPException(403, "Only an owner can re-invite an owner")
    await audit.record(action="staff.reinvite", actor_user_id=actor.id, actor_role="staff:" + (actor.staff_role or ""),
                       actor_email=actor.email, target_type="staff", target_id=mid, request=request)
    return await _issue_invitation(db, doc, actor, request)


class AcceptInviteReq(BaseModel):
    token: str = Field(min_length=16, max_length=256)
    password: str = Field(min_length=10, max_length=256)


@router.post("/auth/accept-invite")
async def accept_invite(req: AcceptInviteReq, request: Request):
    """Public: consume a set-password invitation atomically and set the password."""
    await rate_limit.check_persistent("staff_invite_accept", request, limit=10, window_seconds=600)
    db = get_db()
    now_iso = utc_now_iso()
    # Atomic claim — the SAME token can never set a password twice, even under concurrency.
    inv = await db.staff_invitations.find_one_and_update(
        {"token_hash": _hash_token(req.token), "used_at": None, "revoked_at": None,
         "expires_at": {"$gt": now_iso}},
        {"$set": {"used_at": now_iso}})
    if not inv:
        # Generic response: do not reveal whether the token existed, expired or was used.
        raise HTTPException(400, "This invitation link is invalid or has expired. Ask an admin to re-invite you.")
    try:
        oid = ObjectId(inv["staff_id"])
    except Exception:
        raise HTTPException(400, "This invitation link is invalid or has expired.")
    inv_ts = int(datetime.now(timezone.utc).timestamp())
    r = await db.staff_accounts.update_one(
        {"_id": oid, "active": True},
        {"$set": {"password_hash": hash_password(req.password), "password_set_at": now_iso,
                  "updated_at": now_iso, "sessions_invalidated_at": inv_ts},
         "$unset": {"invite_pending": ""}})
    if r.matched_count == 0:
        raise HTTPException(400, "This invitation link is invalid or has expired.")
    if (inv.get("email") or "").lower() == (config.FOUNDER_EMAIL or "").lower():
        # Keep the legacy founder `users` record in lock-step (same password, sessions invalidated).
        _sd = await db.staff_accounts.find_one({"_id": oid}, {"password_hash": 1})
        if _sd:
            await db.users.update_one({"email": config.FOUNDER_EMAIL},
                                      {"$set": {"password_hash": _sd["password_hash"], "sessions_invalidated_at": inv_ts}})
    await audit.record(action="staff.invite_accepted", actor_user_id=inv["staff_id"], actor_role="staff",
                       actor_email=inv.get("email"), target_type="staff", target_id=inv["staff_id"], request=request)
    return {"ok": True, "message": "Password set. You can now sign in."}


@router.patch("/members/{mid}")
async def patch_member(mid: str, req: MemberPatch, request: Request, actor: User = Depends(require_staff("staff"))):
    db = get_db()
    try:
        oid = ObjectId(mid)
    except Exception:
        raise HTTPException(404, "Not found")
    doc = await db.staff_accounts.find_one({"_id": oid})
    if not doc:
        raise HTTPException(404, "Not found")
    if doc.get("role") == "owner" and actor.staff_role != "owner":
        raise HTTPException(403, "Only an owner can edit an owner")
    upd: Dict[str, Any] = {"updated_at": utc_now_iso()}
    if req.full_name is not None:
        upd["full_name"] = req.full_name.strip()
    if req.role is not None:
        if req.role not in STAFF_ROLES:
            raise HTTPException(400, "Unknown role")
        if req.role == "owner" and actor.staff_role != "owner":
            raise HTTPException(403, "Only the owner can promote to owner")
        if doc.get("role") == "owner" and req.role != "owner":
            owners = await db.staff_accounts.count_documents({"role": "owner", "active": True})
            if owners <= 1:
                raise HTTPException(400, "Cannot demote the last owner")
        upd["role"] = req.role
    if req.work_handle is not None:
        upd["work_email"] = await _unique_work_email(req.work_handle, exclude_id=oid)
    if req.active is not None:
        if doc.get("role") == "owner" and not req.active:
            raise HTTPException(400, "Owners cannot be deactivated — demote first")
        upd["active"] = req.active
    if req.new_password:
        upd["password_hash"] = hash_password(req.new_password)
        upd["password_set_at"] = utc_now_iso()
        # Credential change → every existing session for this staff account is invalidated.
        upd["sessions_invalidated_at"] = int(datetime.now(timezone.utc).timestamp())
        if doc["email"] == config.FOUNDER_EMAIL:
            await db.users.update_one({"email": config.FOUNDER_EMAIL}, {"$set": {"password_hash": upd["password_hash"]}})
    await db.staff_accounts.update_one({"_id": oid}, {"$set": upd})
    await audit.record(action="staff.update", actor_user_id=actor.id, actor_role="staff:" + (actor.staff_role or ""),
                       actor_email=actor.email, target_type="staff", target_id=mid,
                       meta={k: v for k, v in upd.items() if k != "password_hash"}, request=request)
    return _public(await db.staff_accounts.find_one({"_id": oid}))


@router.delete("/members/{mid}")
async def delete_member(mid: str, request: Request, actor: User = Depends(require_staff("staff"))):
    db = get_db()
    try:
        oid = ObjectId(mid)
    except Exception:
        raise HTTPException(404, "Not found")
    doc = await db.staff_accounts.find_one({"_id": oid})
    if not doc:
        raise HTTPException(404, "Not found")
    if doc.get("role") == "owner":
        raise HTTPException(400, "Owners cannot be deleted — demote first")
    if str(oid) == actor.id:
        raise HTTPException(400, "You cannot delete yourself")
    await db.staff_accounts.delete_one({"_id": oid})
    await audit.record(action="staff.delete", actor_user_id=actor.id, actor_role="staff:" + (actor.staff_role or ""),
                       actor_email=actor.email, target_type="staff", target_id=mid, request=request)
    return {"ok": True}


@router.get("/mail-log")
async def mail_log(_: User = Depends(require_staff("emails"))):
    db = get_db()
    return [{**d, "_id": str(d["_id"])} async for d in db.system_mail_log.find({}).sort("created_at", -1).limit(100)]



@router.get("/fraud/overview")
async def fraud_overview(days: int = 30, _: User = Depends(require_staff("audit"))):
    """Abuse dashboard: recent fraud signals, top IPs and repeat device fingerprints."""
    from datetime import datetime, timedelta, timezone
    db = get_db()
    days = max(1, min(days, 365))
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat().replace("+00:00", "Z")
    signals = await db.fraud_signals.find({"created_at": {"$gte": since}}).sort("created_at", -1).to_list(200)
    signals_out = [{
        "kind": s.get("kind"), "email": s.get("email"), "ip": s.get("ip"),
        "device_id": s.get("device_id"), "user_agent": s.get("user_agent"),
        "detail": s.get("detail"), "created_at": s.get("created_at"),
    } for s in signals]
    by_kind: Dict[str, int] = {}
    for s in signals:
        k = s.get("kind", "?")
        by_kind[k] = by_kind.get(k, 0) + 1
    attempts = await db.signup_attempts.find({"created_at": {"$gte": since}}).to_list(5000)
    ip_counts: Dict[str, int] = {}
    device_counts: Dict[str, int] = {}
    for a in attempts:
        if a.get("ip"):
            ip_counts[a["ip"]] = ip_counts.get(a["ip"], 0) + 1
        if a.get("device_id"):
            device_counts[a["device_id"]] = device_counts.get(a["device_id"], 0) + 1
    top_ips = sorted(({"ip": k, "count": v} for k, v in ip_counts.items()), key=lambda x: -x["count"])[:20]
    repeat_devices = sorted(({"device_id": k, "count": v} for k, v in device_counts.items() if v > 1),
                            key=lambda x: -x["count"])[:20]
    return {
        "since": since, "days": days,
        "totals": {"signals": len(signals), "attempts": len(attempts), "by_kind": by_kind},
        "signals": signals_out, "top_ips": top_ips, "repeat_devices": repeat_devices,
    }
