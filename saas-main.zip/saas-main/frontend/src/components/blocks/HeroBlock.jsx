import { ArrowRight } from "lucide-react";

/**
 * Hero block — 3 variants.
 * a: split (copy left, image right) — home_services / professional_services
 * b: dark, stats-forward — automotive / fitness
 * c: editorial serif center — beauty_wellness
 */
export default function HeroBlock({ block, theme }) {
    const { variant = "a", props = {} } = block;
    const { eyebrow, headline, subheadline, primary_cta, secondary_cta, stats = [], image } = props;

    if (variant === "b") {
        return (
            <section
                className="relative overflow-hidden"
                style={{ backgroundColor: theme?.secondary || "#0F172A", color: "#F8FAFC" }}
            >
                <div className="absolute inset-0 opacity-30">
                    {image && <img src={image} alt={props.image_alt || ""} className="w-full h-full object-cover" />}
                    <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.2), rgba(0,0,0,0.75))" }} />
                </div>
                <div className="relative mx-auto max-w-6xl px-6 py-24 md:py-32">
                    {eyebrow && (
                        <div className="text-xs uppercase tracking-[0.24em] mb-6 opacity-80">{eyebrow}</div>
                    )}
                    <h1 data-heading className="text-4xl md:text-6xl font-semibold leading-[1.05] max-w-3xl">
                        {headline}
                    </h1>
                    {subheadline && (
                        <p className="mt-6 max-w-xl text-base md:text-lg opacity-90">{subheadline}</p>
                    )}
                    <div className="mt-10 flex flex-wrap gap-3">
                        {primary_cta?.label && (
                            <a
                                href={primary_cta.href || "#"}
                                className="inline-flex items-center gap-2 px-5 py-3 rounded-md font-medium"
                                style={{ background: theme?.primary, color: "#fff" }}
                            >
                                {primary_cta.label} <ArrowRight className="w-4 h-4" />
                            </a>
                        )}
                        {secondary_cta?.label && (
                            <a
                                href={secondary_cta.href || "#"}
                                className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-white/40"
                            >
                                {secondary_cta.label}
                            </a>
                        )}
                    </div>
                    {stats.length > 0 && (
                        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
                            {stats.map((s, i) => (
                                <div key={i}>
                                    <div className="text-3xl font-semibold" data-heading>{s.value}</div>
                                    <div className="text-xs uppercase tracking-widest mt-1 opacity-70">{s.label}</div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </section>
        );
    }

    if (variant === "c") {
        return (
            <section style={{ backgroundColor: theme?.background }}>
                <div className="mx-auto max-w-4xl px-6 py-24 md:py-32 text-center">
                    {eyebrow && (
                        <div className="text-xs uppercase tracking-[0.28em] mb-6" style={{ color: theme?.primary }}>{eyebrow}</div>
                    )}
                    <h1 data-heading className="text-4xl md:text-6xl font-medium leading-tight">{headline}</h1>
                    {subheadline && (
                        <p className="mt-6 mx-auto max-w-xl text-lg" style={{ color: `${theme?.foreground}B0` }}>
                            {subheadline}
                        </p>
                    )}
                    <div className="mt-10 flex justify-center gap-3 flex-wrap">
                        {primary_cta?.label && (
                            <a
                                href={primary_cta.href || "#"}
                                className="inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium"
                                style={{ background: theme?.primary, color: "#fff" }}
                            >
                                {primary_cta.label} <ArrowRight className="w-4 h-4" />
                            </a>
                        )}
                        {secondary_cta?.label && (
                            <a
                                href={secondary_cta.href || "#"}
                                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border"
                                style={{ borderColor: `${theme?.foreground}33` }}
                            >
                                {secondary_cta.label}
                            </a>
                        )}
                    </div>
                    {image && (
                        <div className="mt-12 rounded-2xl overflow-hidden max-w-3xl mx-auto">
                            <img src={image} alt={props.image_alt || ""} className="w-full h-72 md:h-96 object-cover" />
                        </div>
                    )}
                </div>
            </section>
        );
    }

    // variant a — split
    return (
        <section style={{ backgroundColor: theme?.background }}>
            <div className="mx-auto max-w-6xl px-6 py-20 md:py-28 grid md:grid-cols-2 gap-12 items-center">
                <div>
                    {eyebrow && (
                        <div className="text-xs uppercase tracking-[0.24em] mb-4" style={{ color: theme?.primary }}>{eyebrow}</div>
                    )}
                    <h1 data-heading className="text-4xl md:text-5xl lg:text-6xl font-semibold leading-[1.05]">
                        {headline}
                    </h1>
                    {subheadline && (
                        <p className="mt-5 text-base md:text-lg" style={{ color: `${theme?.foreground}B0` }}>{subheadline}</p>
                    )}
                    <div className="mt-8 flex flex-wrap gap-3">
                        {primary_cta?.label && (
                            <a
                                href={primary_cta.href || "#"}
                                className="inline-flex items-center gap-2 px-5 py-3 rounded-md font-medium"
                                style={{ background: theme?.primary, color: "#fff" }}
                            >
                                {primary_cta.label} <ArrowRight className="w-4 h-4" />
                            </a>
                        )}
                        {secondary_cta?.label && (
                            <a
                                href={secondary_cta.href || "#"}
                                className="inline-flex items-center gap-2 px-5 py-3 rounded-md border"
                                style={{ borderColor: `${theme?.foreground}33`, color: theme?.foreground }}
                            >
                                {secondary_cta.label}
                            </a>
                        )}
                    </div>
                </div>
                {image && (
                    <div className="rounded-2xl overflow-hidden border" style={{ borderColor: `${theme?.foreground}14` }}>
                        <img src={image} alt={props.image_alt || ""} className="w-full h-80 md:h-[440px] object-cover" />
                    </div>
                )}
            </div>
        </section>
    );
}
