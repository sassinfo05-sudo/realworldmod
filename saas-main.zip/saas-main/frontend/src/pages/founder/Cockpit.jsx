import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { AlertTriangle, ShieldAlert, Webhook, Ticket, Zap, Users, ExternalLink } from "lucide-react";

function Card({ title, count, tone = "info", icon: Icon, action }) {
    const tones = {
        info: "border-brand-line bg-white",
        warn: "border-amber-200 bg-amber-50",
        alert: "border-red-200 bg-red-50",
        ok: "border-emerald-200 bg-emerald-50",
    };
    return (
        <div className={`rounded-lg border p-4 ${tones[tone]}`}>
            <div className="flex items-center justify-between">
                <div className="text-xs uppercase tracking-widest text-zinc-500">{title}</div>
                {Icon && <Icon className="w-4 h-4 text-zinc-400" />}
            </div>
            <div className="mt-2 font-display text-3xl text-brand-ink">{count}</div>
            {action && <div className="mt-2 text-xs">{action}</div>}
        </div>
    );
}

export default function Cockpit() {
    const [data, setData] = useState(null);
    useEffect(() => {
        api.get("/founder/cockpit").then((r) => setData(r.data));
    }, []);
    if (!data) return <div className="p-6 text-zinc-500">Loading cockpit…</div>;
    const anyIssue = data.orgs_over_limit.length || data.failing_webhooks || data.dead_webhooks
                        || data.pending_approvals || data.past_due_subscriptions || data.llm_errors_24h;
    return (
        <div className="p-6 max-w-6xl" data-testid="founder-cockpit">
            <div className="mb-4">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">What needs attention</div>
                <h1 className="mt-1 font-display text-2xl text-brand-ink">Operations cockpit</h1>
            </div>

            <div className="grid md:grid-cols-3 gap-3 mb-6">
                <Card title="Orgs over limit" count={data.orgs_over_limit.length}
                        tone={data.orgs_over_limit.length ? "warn" : "ok"} icon={ShieldAlert}
                        action={<Link to="/staff/tenants" className="text-brand-copper underline">View tenants →</Link>} />
                <Card title="Past-due subscriptions" count={data.past_due_subscriptions}
                        tone={data.past_due_subscriptions ? "alert" : "ok"} icon={AlertTriangle} />
                <Card title="Pending approvals" count={data.pending_approvals}
                        tone={data.pending_approvals ? "warn" : "ok"} icon={Ticket}
                        action={<Link to="/staff/approvals" className="text-brand-copper underline">Review →</Link>} />
                <Card title="Failing webhooks" count={data.failing_webhooks}
                        tone={data.failing_webhooks ? "warn" : "ok"} icon={Webhook}
                        action={<Link to="/staff/health" className="text-brand-copper underline">Health →</Link>} />
                <Card title="Dead-lettered webhooks" count={data.dead_webhooks}
                        tone={data.dead_webhooks ? "alert" : "ok"} icon={Webhook} />
                <Card title="LLM errors (24h)" count={data.llm_errors_24h}
                        tone={data.llm_errors_24h > 20 ? "alert" : data.llm_errors_24h > 0 ? "warn" : "ok"} icon={Zap} />
            </div>

            {!!data.orgs_over_limit.length && (
                <div className="rounded-lg border border-amber-200 bg-white p-4" data-testid="cockpit-over-limit-list">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-3">Tenants over one or more limits</div>
                    <div className="space-y-2">
                        {data.orgs_over_limit.slice(0, 30).map((o) => (
                            <div key={o.org_id} className="flex items-center justify-between border border-brand-line rounded-md px-3 py-2" data-testid={`cockpit-over-${o.org_id}`}>
                                <div>
                                    <div className="text-sm font-medium text-brand-ink">{o.org_name}</div>
                                    <div className="text-xs text-zinc-500">
                                        Plan <span className="uppercase font-mono">{o.plan}</span> · Over: {o.over.map((x) => `${x.meter} (${x.used}/${x.cap})`).join(", ")}
                                    </div>
                                </div>
                                <Link to={`/staff/tenants/${o.org_id}`} className="text-xs text-brand-copper hover:underline flex items-center gap-1" data-testid={`cockpit-open-${o.org_id}`}>
                                    Open <ExternalLink className="w-3 h-3" />
                                </Link>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {!anyIssue && (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-6 text-center text-emerald-900" data-testid="cockpit-all-clear">
                    All clear — no exceptions right now. Have a coffee.
                </div>
            )}

            {data.active_impersonations > 0 && (
                <div className="mt-4 text-xs text-zinc-500 border-t border-brand-line pt-3">
                    {data.active_impersonations} impersonation session(s) currently active.
                </div>
            )}
        </div>
    );
}
