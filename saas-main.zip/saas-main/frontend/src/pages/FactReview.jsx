import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Wordmark } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Check, Pencil, ArrowRight } from "lucide-react";
import { toast } from "sonner";

function VerifiedChip({ verified }) {
    return verified ? (
        <Badge className="bg-emerald-100 text-emerald-800 border border-emerald-200 hover:bg-emerald-100">
            <Check className="w-3 h-3 mr-1" /> Owner-verified
        </Badge>
    ) : (
        <Badge variant="outline" className="text-zinc-500 border-zinc-300">Needs review</Badge>
    );
}

function ServiceRow({ item, index, onChange, onVerify }) {
    const [editing, setEditing] = useState(false);
    const [draft, setDraft] = useState(item);

    function save() {
        onChange(index, { ...draft, verified: true });
        setEditing(false);
    }

    return (
        <div className="rounded-lg border border-brand-line bg-white p-4"
             data-testid={`fact-service-${index}`}>
            {!editing ? (
                <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                        <div className="font-medium text-brand-ink">{item.name}</div>
                        {item.description && <div className="text-sm text-zinc-600 mt-1">{item.description}</div>}
                        {item.price_display && (
                            <div className="mt-2 text-xs font-mono text-brand-copper">{item.price_display}</div>
                        )}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                        <VerifiedChip verified={item.verified} />
                        <Button variant="ghost" size="sm" onClick={() => { setDraft(item); setEditing(true); }}
                                data-testid={`fact-service-${index}-edit`}>
                            <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        {!item.verified && (
                            <Button variant="outline" size="sm" onClick={() => onVerify(index)}
                                    data-testid={`fact-service-${index}-verify`}>
                                Verify
                            </Button>
                        )}
                    </div>
                </div>
            ) : (
                <div className="space-y-2">
                    <Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                           data-testid={`fact-service-${index}-name-input`} />
                    <Textarea value={draft.description || ""} rows={2}
                              onChange={(e) => setDraft({ ...draft, description: e.target.value })}
                              data-testid={`fact-service-${index}-desc-input`} />
                    <Input value={draft.price_display || ""} placeholder="e.g., $120 or From $80/hr"
                           onChange={(e) => setDraft({ ...draft, price_display: e.target.value })}
                           data-testid={`fact-service-${index}-price-input`} />
                    <div className="flex gap-2">
                        <Button size="sm" onClick={save} className="bg-brand-copper hover:bg-brand-copperHover text-white"
                                data-testid={`fact-service-${index}-save`}>
                            Save
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>Cancel</Button>
                    </div>
                </div>
            )}
        </div>
    );
}

function HoursRow({ item, index, onChange }) {
    return (
        <div className="flex items-center gap-3 py-2" data-testid={`fact-hours-${item.day}`}>
            <div className="w-14 font-medium text-brand-ink">{item.day}</div>
            <label className="text-xs text-zinc-500 flex items-center gap-1">
                <input type="checkbox" checked={!!item.closed}
                       onChange={(e) => onChange(index, { ...item, closed: e.target.checked, verified: true })}
                       data-testid={`fact-hours-${item.day}-closed`} />
                Closed
            </label>
            {!item.closed && (
                <>
                    <Input value={item.open || ""} placeholder="9:00 AM" className="max-w-[110px]"
                           onChange={(e) => onChange(index, { ...item, open: e.target.value, verified: true })}
                           data-testid={`fact-hours-${item.day}-open`} />
                    <span className="text-zinc-400">–</span>
                    <Input value={item.close || ""} placeholder="5:00 PM" className="max-w-[110px]"
                           onChange={(e) => onChange(index, { ...item, close: e.target.value, verified: true })}
                           data-testid={`fact-hours-${item.day}-close`} />
                </>
            )}
            <div className="ml-auto"><VerifiedChip verified={item.verified} /></div>
        </div>
    );
}

function DiffRow({ item, index, onChange, onVerify }) {
    const [editing, setEditing] = useState(false);
    const [draft, setDraft] = useState(item.text);
    return (
        <div className="flex items-center gap-3 py-2" data-testid={`fact-diff-${index}`}>
            {!editing ? (
                <>
                    <div className="flex-1 text-sm text-brand-ink">{item.text}</div>
                    <VerifiedChip verified={item.verified} />
                    <Button variant="ghost" size="sm" onClick={() => { setDraft(item.text); setEditing(true); }}
                            data-testid={`fact-diff-${index}-edit`}>
                        <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    {!item.verified && (
                        <Button variant="outline" size="sm" onClick={() => onVerify(index)}
                                data-testid={`fact-diff-${index}-verify`}>Verify</Button>
                    )}
                </>
            ) : (
                <>
                    <Input value={draft} onChange={(e) => setDraft(e.target.value)}
                           data-testid={`fact-diff-${index}-input`} />
                    <Button size="sm" onClick={() => { onChange(index, { ...item, text: draft, verified: true }); setEditing(false); }}
                            className="bg-brand-copper hover:bg-brand-copperHover text-white"
                            data-testid={`fact-diff-${index}-save`}>
                        Save
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>Cancel</Button>
                </>
            )}
        </div>
    );
}

export default function FactReview() {
    const [profile, setProfile] = useState(null);
    const [busy, setBusy] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        api.get("/business-profile").then((r) => setProfile(r.data)).catch(() => {
            toast.error("No profile yet — finish the interview first.");
            navigate("/onboarding");
        });
    }, [navigate]);

    async function commit(field, value) {
        setBusy(true);
        try {
            const { data } = await api.patch("/business-profile", { field, value });
            setProfile(data);
        } catch (err) {
            toast.error("Save failed");
        } finally {
            setBusy(false);
        }
    }

    async function verifyItem(field, itemId) {
        try {
            await api.post("/business-profile/verify-item", { field, item_id: itemId });
            const { data } = await api.get("/business-profile");
            setProfile(data);
        } catch {}
    }

    if (!profile) {
        return (
            <div className="min-h-screen bg-brand-surface flex items-center justify-center">
                <div className="text-zinc-500">Loading your business profile…</div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-brand-surface" data-testid="fact-review-page">
            <div className="border-b border-brand-line bg-white">
                <div className="mx-auto max-w-4xl px-6 h-16 flex items-center justify-between">
                    <Wordmark />
                    <Button onClick={() => navigate("/app")}
                            className="bg-brand-ink hover:bg-black text-white"
                            data-testid="fact-review-continue">
                        Continue to my dashboard <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                </div>
            </div>

            <main className="mx-auto max-w-4xl px-6 py-12 space-y-10">
                <header>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Review your facts</div>
                    <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium leading-tight">
                        Everything we wrote about {profile.business_name}.
                    </h1>
                    <p className="mt-2 text-zinc-600">
                        Confirm what's right, fix what's not. Each edit is stamped owner-verified.
                    </p>
                </header>

                {/* Identity */}
                <section className="rounded-2xl border border-brand-line bg-white p-6" data-testid="fact-identity">
                    <h2 className="font-display text-xl text-brand-ink">Identity</h2>
                    <div className="mt-4 space-y-4">
                        <div>
                            <label className="text-xs uppercase tracking-widest text-zinc-500">Business name</label>
                            <Input defaultValue={profile.business_name}
                                   onBlur={(e) => e.target.value !== profile.business_name && commit("business_name", e.target.value)}
                                   className="mt-1" data-testid="fact-business-name" />
                        </div>
                        <div>
                            <label className="text-xs uppercase tracking-widest text-zinc-500">Tagline</label>
                            <Input defaultValue={profile.tagline}
                                   onBlur={(e) => e.target.value !== profile.tagline && commit("tagline", e.target.value)}
                                   className="mt-1" data-testid="fact-tagline" />
                        </div>
                        <div>
                            <label className="text-xs uppercase tracking-widest text-zinc-500">About</label>
                            <Textarea defaultValue={profile.about} rows={3}
                                      onBlur={(e) => e.target.value !== profile.about && commit("about", e.target.value)}
                                      className="mt-1" data-testid="fact-about" />
                        </div>
                    </div>
                </section>

                {/* Services */}
                <section data-testid="fact-services">
                    <h2 className="font-display text-xl text-brand-ink">Services & prices</h2>
                    <div className="mt-4 grid gap-3">
                        {profile.services.map((s, i) => (
                            <ServiceRow
                                key={s.id}
                                item={s}
                                index={i}
                                onChange={(idx, next) => {
                                    const arr = [...profile.services];
                                    arr[idx] = next;
                                    commit("services", arr);
                                }}
                                onVerify={() => verifyItem("services", s.id)}
                            />
                        ))}
                    </div>
                </section>

                {/* Hours */}
                <section className="rounded-2xl border border-brand-line bg-white p-6" data-testid="fact-hours">
                    <h2 className="font-display text-xl text-brand-ink">Hours</h2>
                    <div className="mt-3 divide-y divide-brand-line">
                        {profile.hours.map((h, i) => (
                            <HoursRow key={h.day} item={h} index={i} onChange={(idx, next) => {
                                const arr = [...profile.hours];
                                arr[idx] = next;
                                commit("hours", arr);
                            }} />
                        ))}
                    </div>
                </section>

                {/* Locations */}
                {profile.locations.length > 0 && (
                    <section className="rounded-2xl border border-brand-line bg-white p-6" data-testid="fact-locations">
                        <h2 className="font-display text-xl text-brand-ink">Locations & service area</h2>
                        <div className="mt-4 space-y-3">
                            {profile.locations.map((l, i) => (
                                <div key={l.id} className="grid sm:grid-cols-2 gap-2" data-testid={`fact-location-${i}`}>
                                    <Input defaultValue={l.city || ""} placeholder="City"
                                           onBlur={(e) => {
                                               const arr = [...profile.locations];
                                               arr[i] = { ...l, city: e.target.value, verified: true };
                                               commit("locations", arr);
                                           }} data-testid={`fact-location-${i}-city`} />
                                    <Input defaultValue={l.phone || ""} placeholder="Phone"
                                           onBlur={(e) => {
                                               const arr = [...profile.locations];
                                               arr[i] = { ...l, phone: e.target.value, verified: true };
                                               commit("locations", arr);
                                           }} data-testid={`fact-location-${i}-phone`} />
                                </div>
                            ))}
                        </div>
                    </section>
                )}

                {/* Differentiators */}
                {profile.differentiators.length > 0 && (
                    <section className="rounded-2xl border border-brand-line bg-white p-6" data-testid="fact-differentiators">
                        <h2 className="font-display text-xl text-brand-ink">Why customers pick you</h2>
                        <div className="mt-3 divide-y divide-brand-line">
                            {profile.differentiators.map((d, i) => (
                                <DiffRow
                                    key={d.id}
                                    item={d}
                                    index={i}
                                    onChange={(idx, next) => {
                                        const arr = [...profile.differentiators];
                                        arr[idx] = next;
                                        commit("differentiators", arr);
                                    }}
                                    onVerify={() => verifyItem("differentiators", d.id)}
                                />
                            ))}
                        </div>
                    </section>
                )}

                <div className="pt-4">
                    <Button onClick={() => navigate("/app")}
                            className="bg-brand-copper hover:bg-brand-copperHover text-white"
                            disabled={busy}
                            data-testid="fact-review-finish">
                        Take me to my workspace <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                </div>
            </main>
        </div>
    );
}
