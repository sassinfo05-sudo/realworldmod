"""Phase 3 domain models — CRM, Inbox, Email workspace.

Kept in a separate file so the Phase 1/2 models module stays readable. All models
inherit from BaseDocument and enforce org_id scoping at the route layer.
"""
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .db import BaseDocument


# =========== Contacts & Companies ===========

class ConsentRecord(BaseModel):
    channel: Literal["email", "sms", "phone", "postal"] = "email"
    status: Literal["granted", "withdrawn", "unknown"] = "unknown"
    ts: str  # iso
    source: Optional[str] = None  # form / import / manual
    note: Optional[str] = None


class Contact(BaseDocument):
    """A person. Emails/phones are lists to support secondary channels."""
    org_id: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    display_name: Optional[str] = None  # auto-computed if missing
    company_id: Optional[str] = None
    title: Optional[str] = None
    emails: List[str] = Field(default_factory=list)  # relaxed vs EmailStr — see note in seed_crm.py
    phones: List[str] = Field(default_factory=list)
    address: Optional[str] = None
    source: Optional[str] = None  # 'form' | 'import' | 'manual' | 'inbound_email'
    tags: List[str] = Field(default_factory=list)
    customer_group: Optional[str] = None  # Round 12: storefront customer group (for group-eligible discounts)
    custom_fields: Dict[str, Any] = Field(default_factory=dict)
    consents: List[ConsentRecord] = Field(default_factory=list)
    owner_user_id: Optional[str] = None  # assignee
    language: Optional[str] = None  # 'en', 'he', etc.
    lead_score: Optional[float] = None  # cached 0-100
    lead_score_updated_at: Optional[str] = None
    notes_count: int = 0
    last_activity_at: Optional[str] = None  # updated on any interaction insert


class Company(BaseDocument):
    org_id: str
    name: str
    domain: Optional[str] = None
    website: Optional[str] = None
    industry: Optional[str] = None
    size: Optional[str] = None  # '1-10', '11-50', ...
    tags: List[str] = Field(default_factory=list)


class CustomFieldDef(BaseDocument):
    """Org-defined custom fields for Contacts (Phase 3 scope) or Deals (future)."""
    org_id: str
    entity: Literal["contact", "company", "deal"] = "contact"
    key: str  # unique per (org_id, entity)
    label: str
    type: Literal["text", "number", "date", "select", "multi_select", "boolean", "url"] = "text"
    options: List[str] = Field(default_factory=list)  # for select types
    required: bool = False
    order: int = 0


# =========== Pipelines & Deals ===========

class Stage(BaseModel):
    id: str
    name: str
    order: int
    kind: Literal["open", "won", "lost"] = "open"
    color: Optional[str] = None


class Pipeline(BaseDocument):
    org_id: str
    name: str
    is_default: bool = False
    stages: List[Stage] = Field(default_factory=list)


class Deal(BaseDocument):
    org_id: str
    pipeline_id: str
    stage_id: str
    name: str
    value: Optional[float] = None
    currency: str = "USD"
    contact_id: Optional[str] = None
    company_id: Optional[str] = None
    owner_user_id: Optional[str] = None
    expected_close_at: Optional[str] = None
    stage_updated_at: Optional[str] = None  # for sort/aging


# =========== Notes & Tasks ===========

class Note(BaseDocument):
    org_id: str
    author_user_id: str
    entity_type: Literal["contact", "deal", "company", "conversation"] = "contact"
    entity_id: str
    body: str


class Task(BaseDocument):
    org_id: str
    title: str
    body: Optional[str] = None
    entity_type: Optional[Literal["contact", "deal", "company"]] = None
    entity_id: Optional[str] = None
    due_at: Optional[str] = None
    assignee_user_id: Optional[str] = None
    done: bool = False
    done_at: Optional[str] = None


# =========== Interactions Timeline (append-only) ===========

class Interaction(BaseDocument):
    """Generic timeline entry — Phases 3-7 append here (form_submission, email_sent,
    email_received, chat_message, stage_change, note_added, task_completed,
    booking_created (P4), quote_sent (P5), payment_received (P5), agent_action (P6)).
    """
    org_id: str
    contact_id: Optional[str] = None
    deal_id: Optional[str] = None
    type: str  # free-form event key (e.g., 'form_submitted', 'email_sent')
    ref_type: Optional[str] = None  # collection name of the referenced doc
    ref_id: Optional[str] = None
    summary: str
    meta: Dict[str, Any] = Field(default_factory=dict)
    author_user_id: Optional[str] = None  # who caused this (system if None)


# =========== Conversations / Messages / Inbox ===========

class Conversation(BaseDocument):
    org_id: str
    channel: Literal["email", "chat", "form"] = "email"
    contact_id: Optional[str] = None
    subject: Optional[str] = None
    status: Literal["open", "snoozed", "closed"] = "open"
    snooze_until: Optional[str] = None
    assignee_user_id: Optional[str] = None
    labels: List[str] = Field(default_factory=list)
    priority: Literal["low", "normal", "high", "urgent"] = "normal"
    unread: bool = True
    last_message_at: Optional[str] = None
    last_message_preview: Optional[str] = None
    first_owner_response_at: Optional[str] = None  # SLA metric
    # collision detection — user_ids currently viewing / typing, with expiry
    presence: Dict[str, str] = Field(default_factory=dict)  # user_id -> iso expiry


class MessageAddress(BaseModel):
    email: str
    name: Optional[str] = None


class Message(BaseDocument):
    org_id: str
    conversation_id: Optional[str] = None  # campaign/automation-sent messages have no conversation
    direction: Literal["inbound", "outbound", "internal_note"] = "inbound"
    channel: Literal["email", "chat", "form", "internal"] = "email"
    from_addr: Optional[MessageAddress] = None
    to_addrs: List[MessageAddress] = Field(default_factory=list)
    cc_addrs: List[MessageAddress] = Field(default_factory=list)
    subject: Optional[str] = None
    body_html: Optional[str] = None
    body_text: Optional[str] = None
    attachments: List[Dict[str, Any]] = Field(default_factory=list)  # {name, url, mime, size}
    in_reply_to: Optional[str] = None  # message id
    thread_key: Optional[str] = None  # provider-side thread reference
    ai_labels: Dict[str, Any] = Field(default_factory=dict)  # intent, urgency, sentiment, confidence
    sent_at: Optional[str] = None
    delivery: Dict[str, Any] = Field(default_factory=dict)  # per-provider events
    author_user_id: Optional[str] = None
    mentions: List[str] = Field(default_factory=list)  # @user_ids in internal notes


class ScheduledSend(BaseDocument):
    """A message that will be released at `release_at`. Cancellable before release."""
    org_id: str
    conversation_id: str
    author_user_id: str
    release_at: str
    payload: Dict[str, Any] = Field(default_factory=dict)  # {subject, body_html, body_text, to, cc}
    status: Literal["scheduled", "sent", "canceled", "failed"] = "scheduled"
    sent_message_id: Optional[str] = None
    error: Optional[str] = None


class Suppression(BaseDocument):
    """A bounced / complained / unsubscribed address. Checked before every send."""
    org_id: str
    email: str  # lowercased
    reason: Literal["bounce", "complaint", "unsubscribe", "manual"] = "manual"
    source_message_id: Optional[str] = None


class EmailSignature(BaseDocument):
    org_id: str
    user_id: str
    name: str = "Default"
    html: str = ""
    is_default: bool = True


class EmailProviderConfig(BaseDocument):
    """Per-org email sending provider selection & (optional) credentials.
    In this environment `provider='simulated'` is the working path; 'resend' and 'smtp'
    are honest 'Not connected' when credentials are unset.
    """
    org_id: str
    provider: Literal["simulated", "resend", "smtp"] = "simulated"
    from_email: Optional[str] = None
    from_name: Optional[str] = None
    reply_to: Optional[str] = None
    # provider config (never returned to non-owner routes)
    resend_api_key: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_use_tls: bool = True
    last_test_at: Optional[str] = None
    last_test_result: Optional[Dict[str, Any]] = None


# =========== CSV Import ===========

class ImportMapping(BaseModel):
    """A single column → contact field mapping."""
    column: str
    target: str  # 'email', 'first_name', 'phone', 'tag', 'skip', 'custom:<key>'
    custom_key: Optional[str] = None


class ContactImportRun(BaseDocument):
    org_id: str
    author_user_id: str
    filename: str
    total_rows: int = 0
    mapping: List[ImportMapping] = Field(default_factory=list)
    # execution results
    status: Literal["mapping", "previewing", "executing", "completed", "failed", "rolled_back"] = "mapping"
    duplicates: List[Dict[str, Any]] = Field(default_factory=list)
    created_contact_ids: List[str] = Field(default_factory=list)
    updated_contact_ids: List[str] = Field(default_factory=list)
    error_rows: List[Dict[str, Any]] = Field(default_factory=list)
    error: Optional[str] = None
    # keep the parsed rows so preview + execute + rollback can be a single flow
    rows_json: List[Dict[str, Any]] = Field(default_factory=list)  # trimmed <= 2000
    rollback_backup: Optional[List[Dict[str, Any]]] = None  # for reversing updates
