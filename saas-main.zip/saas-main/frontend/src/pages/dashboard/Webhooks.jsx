import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Trash2, Copy, Webhook, History, RotateCcw } from "lucide-react";

export default function Webhooks() {
    const [items, setItems] = useState([]);
    const [available, setAvailable] = useState([]);
    const [open, setOpen] = useState(false);
    const [url, setUrl] = useState("");
    const [events, setEvents] = useState([]);
    const [issued, setIssued] = useState(null);
    const [busy, setBusy] = useState(false);
    const [deliveriesFor, setDeliveriesFor] = useState(null);

    async function load() {
        const { data } = await api.get("/setup/webhooks");
        setItems(data.webhooks || []);
        setAvailable(data.available_events || []);
    }
    useEffect(() => { load(); }, []);

    async function create() {
        setBusy(true);
        try {
            const { data } = await api.post("/setup/webhooks", { url, events });
            setIssued(data);
            setUrl(""); setEvents([]);
            toast.success("Webhook created — copy the secret");
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Create failed");
        } finally { setBusy(false); }
    }
    async function del(id) {
        if (!window.confirm("Delete this webhook? Deliveries will stop.")) return;
        try {
            await api.delete(`/setup/webhooks/${id}`);
            toast.success("Deleted");
            load();
        } catch (e) { toast.error("Delete failed"); }
    }

    return (
        <div className="p-6 max-w-6xl" data-testid="webhooks-page">
            <div className="flex items-start justify-between mb-4">
                <div>
                    <h2 className="text-lg font-medium text-brand-ink">Webhooks</h2>
                    <p className="text-sm text-zinc-500 max-w-xl">Fire HMAC-SHA256-signed events to your endpoint. Timestamp <span className="font-mono">t</span> + 5-min replay window.</p>
                </div>
                <Button onClick={() => { setOpen(true); setIssued(null); }} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="webhooks-new-btn">
                    <Plus className="w-4 h-4 mr-1" /> New webhook
                </Button>
            </div>
            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>URL</TableHead>
                        <TableHead>Events</TableHead>
                        <TableHead>Last delivery</TableHead>
                        <TableHead>Last error</TableHead>
                        <TableHead></TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {items.map((w) => (
                            <TableRow key={w.id} data-testid={`webhook-${w.id}`}>
                                <TableCell className="font-mono text-xs">{w.url}</TableCell>
                                <TableCell>
                                    <div className="flex gap-1 flex-wrap">
                                        {(w.events || []).map((e) => <span key={e} className="text-[10px] bg-brand-cream text-brand-ink px-1.5 py-0.5 rounded">{e}</span>)}
                                    </div>
                                </TableCell>
                                <TableCell className="text-xs text-zinc-500">{w.last_delivery_at?.slice(0, 16) || "—"}</TableCell>
                                <TableCell className="text-xs text-red-700">{w.last_error?.slice(0, 60) || ""}</TableCell>
                                <TableCell>
                                    <Button size="sm" variant="ghost" onClick={() => setDeliveriesFor(deliveriesFor === w.id ? null : w.id)} data-testid={`webhook-${w.id}-deliveries`} title="Deliveries & replay"><History className="w-3.5 h-3.5" /></Button>
                                    <Button size="sm" variant="ghost" onClick={() => del(w.id)} data-testid={`webhook-${w.id}-del`}><Trash2 className="w-3.5 h-3.5" /></Button>
                                </TableCell>
                            </TableRow>
                        ))}
                        {!items.length && (
                            <TableRow><TableCell colSpan={5} className="text-center text-zinc-500 py-8" data-testid="webhooks-empty">No webhooks configured.</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
            {deliveriesFor && <Deliveries wid={deliveriesFor} />}

            <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setIssued(null); }}>
                <DialogContent className="max-w-lg">
                    <DialogHeader><DialogTitle>{issued ? "Copy your secret" : "New webhook"}</DialogTitle></DialogHeader>
                    {issued ? (
                        <div className="space-y-3">
                            <div className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded p-2">
                                Save this secret now. Use it to verify the <span className="font-mono">X-Zanelvo-Signature</span> header.
                            </div>
                            <div className="font-mono text-sm bg-brand-cream border border-brand-line rounded p-3 break-all" data-testid="webhook-issued-secret">
                                {issued.secret}
                            </div>
                            <Button onClick={() => { navigator.clipboard.writeText(issued.secret); toast.success("Copied"); }} className="w-full">
                                <Copy className="w-4 h-4 mr-1" /> Copy secret
                            </Button>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            <div>
                                <Label className="text-xs">Endpoint URL</Label>
                                <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com/hooks/zanelvo" data-testid="webhook-form-url" />
                            </div>
                            <div>
                                <Label className="text-xs">Events</Label>
                                <div className="grid grid-cols-2 gap-1.5 mt-1">
                                    {available.map((e) => (
                                        <label key={e} className="flex items-center gap-2 text-xs">
                                            <input
                                                type="checkbox"
                                                checked={events.includes(e)}
                                                onChange={(ev) => setEvents(ev.target.checked ? [...events, e] : events.filter((x) => x !== e))}
                                                data-testid={`webhook-event-${e.replace(".", "-")}`}
                                            />
                                            <span className="font-mono">{e}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                    <DialogFooter>
                        {issued ? (
                            <Button onClick={() => { setOpen(false); setIssued(null); }} data-testid="webhook-done-btn">Done</Button>
                        ) : (
                            <>
                                <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
                                <Button onClick={create} disabled={busy || !url || !events.length} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="webhook-create-btn">Create</Button>
                            </>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}

/** Round 11 — recent deliveries for one endpoint with one-click replay by delivery id. */
function Deliveries({ wid }) {
    const [rows, setRows] = useState([]);
    const [busyId, setBusyId] = useState(null);
    const load = async () => { try { const { data } = await api.get(`/setup/webhooks/${wid}/deliveries`); setRows(data.deliveries || []); } catch { toast.error("Could not load deliveries"); } };
    useEffect(() => { load(); }, [wid]); // eslint-disable-line react-hooks/exhaustive-deps
    const replay = async (id) => {
        setBusyId(id);
        try { const { data } = await api.post(`/setup/webhooks/${wid}/replay/${id}`); toast.success(`Replayed (${data.deliveries_created} new delivery)`); load(); }
        catch (e) { toast.error(e?.response?.data?.detail || "Replay failed"); } finally { setBusyId(null); }
    };
    return (
        <div className="mt-4 border border-brand-line rounded-lg bg-white p-4" data-testid="webhook-deliveries">
            <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-medium text-brand-ink">Recent deliveries</div>
                <Button size="sm" variant="ghost" onClick={load}>Refresh</Button>
            </div>
            {rows.length === 0 && <div className="text-xs text-zinc-500">No deliveries yet — fire an event (e.g. submit a form or create a booking) and it will appear here.</div>}
            <div className="divide-y divide-brand-line">
                {rows.map((d) => (
                    <div key={d.id} className="flex items-center gap-3 py-2 text-xs" data-testid={`delivery-${d.id}`}>
                        <span className="font-mono text-brand-ink w-40 truncate">{d.event}</span>
                        <span className={`px-1.5 py-0.5 rounded ${d.status === "success" || d.status === "delivered" ? "bg-emerald-50 text-emerald-700" : d.status === "pending" ? "bg-zinc-100 text-zinc-600" : "bg-red-50 text-red-700"}`}>{d.status}{d.last_response_code ? ` · ${d.last_response_code}` : ""}</span>
                        <span className="text-zinc-500">{d.attempts} attempt{d.attempts === 1 ? "" : "s"}</span>
                        <span className="text-zinc-400 flex-1 truncate">{d.replayed_from ? `replay of ${d.replayed_from.slice(-6)}` : d.error}</span>
                        <span className="text-zinc-500">{d.created_at?.slice(0, 16).replace("T", " ")}</span>
                        <Button size="sm" variant="outline" className="border-brand-line h-7" disabled={busyId === d.id} onClick={() => replay(d.id)} data-testid={`delivery-${d.id}-replay`}><RotateCcw className="w-3 h-3 mr-1" /> Replay</Button>
                    </div>
                ))}
            </div>
        </div>
    );
}
