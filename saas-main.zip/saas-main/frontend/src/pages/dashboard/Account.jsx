import React, { useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { User as UserIcon, Lock, ShieldCheck, Save, ArrowRight } from "lucide-react";

function Card({ title, icon: Icon, children }) {
    return (
        <div className="rounded-2xl border border-brand-line bg-white p-6 animate-fade-in-up">
            <div className="flex items-center gap-2 mb-4">
                <Icon className="w-4 h-4 text-brand-copper" />
                <h2 className="font-display text-lg text-brand-ink">{title}</h2>
            </div>
            {children}
        </div>
    );
}

function Field({ label, ...props }) {
    return (
        <div>
            <label className="block text-sm font-medium text-brand-ink mb-1">{label}</label>
            <input {...props}
                className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm text-brand-ink outline-none focus:ring-2 focus:ring-brand-copper/30 disabled:opacity-60" />
        </div>
    );
}

export default function Account() {
    const { user, refreshMe } = useAuth();
    const [fullName, setFullName] = useState(user?.full_name || "");
    const [orgName, setOrgName] = useState(user?.org_name || "");
    const [inboundEmail, setInboundEmail] = useState(user?.inbound_email || "");
    const [savingProfile, setSavingProfile] = useState(false);

    const [cur, setCur] = useState("");
    const [nw, setNw] = useState("");
    const [nw2, setNw2] = useState("");
    const [savingPw, setSavingPw] = useState(false);

    async function saveProfile() {
        setSavingProfile(true);
        try {
            await api.put("/auth/profile", { full_name: fullName, org_name: orgName, inbound_email: inboundEmail });
            await refreshMe();
            toast.success("Profile updated");
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Could not update profile");
        } finally { setSavingProfile(false); }
    }

    async function changePassword() {
        if (nw.length < 8) return toast.error("New password must be at least 8 characters");
        if (nw !== nw2) return toast.error("New passwords don't match");
        setSavingPw(true);
        try {
            await api.post("/auth/change-password", { current_password: cur, new_password: nw });
            toast.success("Password changed");
            setCur(""); setNw(""); setNw2("");
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Could not change password");
        } finally { setSavingPw(false); }
    }

    return (
        <div className="p-6 md:p-8 max-w-3xl" data-testid="account-page">
            <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Your account</div>
            <h1 className="font-display text-3xl text-brand-ink">Account &amp; security</h1>
            <p className="mt-2 text-sm text-zinc-500">Update your details, change your password, and manage two-factor authentication.</p>

            <div className="mt-8 space-y-5">
                <Card title="Profile" icon={UserIcon}>
                    <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="Full name" data-testid="account-fullname" value={fullName} onChange={(e) => setFullName(e.target.value)} />
                        <Field label="Business / workspace name" data-testid="account-orgname" value={orgName} onChange={(e) => setOrgName(e.target.value)} />
                        <Field label="Inbound email address (customer replies land in your Inbox)" data-testid="account-inbound-email" value={inboundEmail} onChange={(e) => setInboundEmail(e.target.value)} placeholder="hello@yourdomain.com" />
                        <Field label="Email" value={user?.email || ""} disabled />
                        <Field label="Role" value={user?.role || ""} disabled />
                    </div>
                    <div className="mt-4">
                        <Button onClick={saveProfile} disabled={savingProfile} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="account-save-profile">
                            <Save className="w-4 h-4 mr-1.5" /> {savingProfile ? "Saving…" : "Save profile"}
                        </Button>
                    </div>
                </Card>

                <Card title="Change password" icon={Lock}>
                    <div className="grid sm:grid-cols-3 gap-4">
                        <Field label="Current password" type="password" data-testid="account-current-pw" value={cur} onChange={(e) => setCur(e.target.value)} />
                        <Field label="New password" type="password" data-testid="account-new-pw" value={nw} onChange={(e) => setNw(e.target.value)} />
                        <Field label="Confirm new" type="password" data-testid="account-new-pw2" value={nw2} onChange={(e) => setNw2(e.target.value)} />
                    </div>
                    <div className="mt-4">
                        <Button onClick={changePassword} disabled={savingPw} className="bg-brand-ink hover:bg-black text-white" data-testid="account-save-pw">
                            {savingPw ? "Saving…" : "Update password"}
                        </Button>
                    </div>
                </Card>

                <Card title="Two-factor authentication (2FA)" icon={ShieldCheck}>
                    <p className="text-sm text-zinc-600">Add an authenticator-app code on top of your password for stronger protection.</p>
                    <Link to="/app/setup/security" className="inline-flex items-center gap-1 mt-3 text-sm text-brand-copper hover:underline" data-testid="account-2fa-link">
                        Manage 2FA <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                </Card>
            </div>
        </div>
    );
}
