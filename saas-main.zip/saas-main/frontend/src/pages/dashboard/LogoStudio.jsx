import React, { useState, useMemo, useEffect, useCallback } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Sparkles, Download, Save, RefreshCw, Palette, Type, Shapes } from "lucide-react";

const card = "rounded-2xl border border-brand-line bg-white p-5 shadow-sm";
const input = "w-full border border-brand-line rounded-lg px-3 py-2 text-sm bg-white";
const label = "text-xs font-medium text-zinc-500 block mb-1";

const PALETTES = [
    { name: "Copper", fg: "#1c1917", bg: "#ffffff", accent: "#b45309" },
    { name: "Ink", fg: "#ffffff", bg: "#0f172a", accent: "#6366f1" },
    { name: "Forest", fg: "#052e16", bg: "#ffffff", accent: "#16a34a" },
    { name: "Rose", fg: "#4c0519", bg: "#fff1f2", accent: "#e11d48" },
    { name: "Ocean", fg: "#082f49", bg: "#ffffff", accent: "#0284c7" },
    { name: "Mono", fg: "#111111", bg: "#ffffff", accent: "#111111" },
];
const FONTS = ["DM Sans", "Fraunces", "Georgia", "Poppins", "Space Grotesk"];
const ICONS = ["spark", "bolt", "leaf", "hex", "circle", "wave", "diamond", "arch"];
const STYLES = [
    { id: "monogram", label: "Monogram" },
    { id: "icontext", label: "Icon + name" },
    { id: "wordmark", label: "Wordmark" },
    { id: "badge", label: "Badge" },
];

function iconSvg(icon, color, cx = 40, cy = 40, s = 22) {
    switch (icon) {
        case "bolt": return `<path d="M${cx + 2} ${cy - s} L${cx - s + 4} ${cy + 3} H${cx} L${cx - 3} ${cy + s} L${cx + s - 2} ${cy - 2} H${cx + 1} Z" fill="${color}"/>`;
        case "leaf": return `<path d="M${cx - s} ${cy + s} C${cx - s} ${cy - s}, ${cx + s} ${cy - s}, ${cx + s} ${cy - s} C${cx + s} ${cy + s}, ${cx - s} ${cy + s}, ${cx - s} ${cy + s} Z" fill="${color}"/>`;
        case "hex": return `<path d="M${cx} ${cy - s} L${cx + s * 0.87} ${cy - s / 2} L${cx + s * 0.87} ${cy + s / 2} L${cx} ${cy + s} L${cx - s * 0.87} ${cy + s / 2} L${cx - s * 0.87} ${cy - s / 2} Z" fill="${color}"/>`;
        case "circle": return `<circle cx="${cx}" cy="${cy}" r="${s}" fill="none" stroke="${color}" stroke-width="6"/>`;
        case "wave": return `<path d="M${cx - s} ${cy} q${s / 2} -${s}, ${s} 0 q${s / 2} ${s}, ${s} 0" fill="none" stroke="${color}" stroke-width="6" stroke-linecap="round"/>`;
        case "diamond": return `<path d="M${cx} ${cy - s} L${cx + s} ${cy} L${cx} ${cy + s} L${cx - s} ${cy} Z" fill="${color}"/>`;
        case "arch": return `<path d="M${cx - s} ${cy + s} V${cy} a${s} ${s} 0 0 1 ${s * 2} 0 V${cy + s}" fill="none" stroke="${color}" stroke-width="6"/>`;
        default: return `<path d="M${cx} ${cy - s} L${cx + 5} ${cy - 5} L${cx + s} ${cy} L${cx + 5} ${cy + 5} L${cx} ${cy + s} L${cx - 5} ${cy + 5} L${cx - s} ${cy} L${cx - 5} ${cy - 5} Z" fill="${color}"/>`;
    }
}

function initialsOf(name) {
    const parts = (name || "").trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return "Z";
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
}

function buildLogo({ name, style, palette, font, icon }) {
    const { fg, bg, accent } = palette;
    const inits = initialsOf(name);
    const brandText = (name || "Your Brand").trim();
    const W = 360, H = 100;
    const txt = (x, size, color, weight = "700", anchor = "start") =>
        `<text x="${x}" y="58" font-family="${font}, sans-serif" font-size="${size}" font-weight="${weight}" fill="${color}" text-anchor="${anchor}" dominant-baseline="middle">${escapeXml(brandText)}</text>`;

    let inner = "";
    if (style === "wordmark") {
        inner = `<text x="${W / 2}" y="${H / 2}" font-family="${font}, sans-serif" font-size="40" font-weight="800" fill="${accent}" text-anchor="middle" dominant-baseline="middle">${escapeXml(brandText)}</text>`;
    } else if (style === "monogram") {
        inner = `<rect x="20" y="20" width="60" height="60" rx="16" fill="${accent}"/>
                 <text x="50" y="52" font-family="${font}, sans-serif" font-size="30" font-weight="800" fill="${bg === "#ffffff" ? "#ffffff" : bg}" text-anchor="middle" dominant-baseline="middle">${inits}</text>
                 ${txt(100, 30, fg, "700")}`;
    } else if (style === "badge") {
        inner = `<circle cx="${W / 2}" cy="${H / 2}" r="42" fill="none" stroke="${accent}" stroke-width="3"/>
                 <text x="${W / 2}" y="${H / 2}" font-family="${font}, sans-serif" font-size="24" font-weight="800" fill="${fg}" text-anchor="middle" dominant-baseline="middle">${escapeXml(brandText)}</text>`;
    } else { // icontext
        inner = `${iconSvg(icon, accent, 46, 50, 24)}${txt(90, 30, fg, "700")}`;
    }
    const bgRect = bg === "transparent" ? "" : `<rect width="${W}" height="${H}" fill="${bg}"/>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${bgRect}${inner}</svg>`;
}

function buildLogomark({ name, style, palette, icon, font }) {
    const { bg, accent } = palette;
    const inits = initialsOf(name);
    const S = 96;
    const bgRect = bg === "transparent" ? "" : `<rect width="${S}" height="${S}" rx="20" fill="${bg}"/>`;
    if (style === "monogram" || style === "wordmark" || style === "badge") {
        return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${S} ${S}" width="${S}" height="${S}">${bgRect}<rect x="8" y="8" width="80" height="80" rx="20" fill="${accent}"/><text x="48" y="52" font-family="${font}, sans-serif" font-size="40" font-weight="800" fill="#ffffff" text-anchor="middle" dominant-baseline="middle">${inits}</text></svg>`;
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${S} ${S}" width="${S}" height="${S}">${bgRect}${iconSvg(icon, accent, 48, 48, 30)}</svg>`;
}

function escapeXml(s) {
    return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function downloadBlob(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
}

function svgToPng(svg, filename) {
    const img = new Image();
    const svgBlob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(svgBlob);
    img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = img.width * 3; canvas.height = img.height * 3;
        const ctx = canvas.getContext("2d");
        ctx.scale(3, 3); ctx.drawImage(img, 0, 0);
        URL.revokeObjectURL(url);
        canvas.toBlob((blob) => {
            const purl = URL.createObjectURL(blob);
            const a = document.createElement("a"); a.href = purl; a.download = filename; a.click();
            URL.revokeObjectURL(purl);
        });
    };
    img.src = url;
}

export default function LogoStudio() {
    const [name, setName] = useState("");
    const [style, setStyle] = useState("monogram");
    const [pi, setPi] = useState(0);
    const [font, setFont] = useState("DM Sans");
    const [icon, setIcon] = useState("spark");
    const [saved, setSaved] = useState(null);
    const [busy, setBusy] = useState(false);
    const [mode, setMode] = useState("svg");
    const [ai, setAi] = useState({ name: "", industry: "", style: "modern minimalist", palette: "brand colors", count: 2 });
    const [aiImages, setAiImages] = useState([]);
    const [aiBusy, setAiBusy] = useState(false);
    const [provider, setProvider] = useState("gemini");
    const [providers, setProviders] = useState([{ key: "gemini", label: "Gemini (Nano Banana)" }]);
    const [logoAnim, setLogoAnim] = useState("none");

    const generateAi = async () => {
        setAiBusy(true); setAiImages([]);
        try {
            const { data } = await api.post("/branding/ai-logo", { ...ai, name: ai.name || name, provider, remember: true });
            setAiImages(data.images || []);
            if (data.provider) setProvider(data.provider);
            if (!data.images?.length) toast.error("No images returned, try again");
        } catch (e) { toast.error(e?.response?.data?.detail?.message || e?.response?.data?.detail || "Generation failed"); }
        finally { setAiBusy(false); }
    };

    const saveAiImage = async (img) => {
        setBusy(true);
        try {
            const { data } = await api.post("/branding/apply-logo", { logo_image: img, name: ai.name || name || "", logo_provider: provider, logo_animation: logoAnim });
            setSaved(data);
            toast.success("Logo applied — live on your dashboard, store & site");
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not apply"); }
        finally { setBusy(false); }
    };

    // Re-apply just the animation onto whatever logo is already live.
    const applyAnimation = async (anim) => {
        setLogoAnim(anim);
        if (!saved?.logo_image && !saved?.logo_svg) return;
        try {
            const { data } = await api.post("/branding/apply-logo", {
                logo_image: saved?.logo_image || "", logo_svg: saved?.logo_svg || "",
                name: saved?.name || name || "", logo_provider: provider, logo_animation: anim,
            });
            setSaved(data);
            toast.success(anim === "none" ? "Logo intro turned off" : `Logo intro set to "${anim}"`);
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not update animation"); }
    };

    const load = useCallback(async () => {
        try {
            const { data } = await api.get("/branding");
            setSaved(data);
            if (data.name && !name) setName(data.name);
            if (data.logo_provider) setProvider(data.logo_provider);
            if (data.logo_animation) setLogoAnim(data.logo_animation);
        } catch { /* noop */ }
        try {
            const { data } = await api.get("/branding/providers");
            if (data.providers?.length) setProviders(data.providers);
            if (data.selected) setProvider(data.selected);
        } catch { /* noop */ }
    }, [name]);
    useEffect(() => { load(); }, []);

    const palette = PALETTES[pi];
    const svg = useMemo(() => buildLogo({ name, style, palette, font, icon }), [name, style, palette, font, icon]);
    const mark = useMemo(() => buildLogomark({ name, style, palette, font, icon }), [name, style, palette, font, icon]);

    const save = async () => {
        setBusy(true);
        try {
            const { data } = await api.put("/branding", {
                logo_svg: svg, logomark_svg: mark, name: name || "",
                colors: palette, style, font, icon, logo_animation: logoAnim,
            });
            setSaved(data);
            toast.success("Logo saved to your brand");
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not save"); }
        finally { setBusy(false); }
    };

    return (
        <div className="max-w-5xl mx-auto p-6 space-y-6">
            <div>
                <h1 className="font-display text-2xl text-brand-ink flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-brand-copper" /> Logo studio
                </h1>
                <p className="text-brand-ink/60 mt-1 text-sm">
                    Make a clean, professional logo from your business name in seconds — no designer needed. Download the SVG/PNG or save it to your brand.
                </p>
            </div>

            <div className="inline-flex rounded-lg border border-brand-line p-1 bg-white">
                <button onClick={() => setMode("svg")} className={`px-4 py-1.5 rounded-md text-sm font-medium ${mode === "svg" ? "bg-brand-copper text-white" : "text-brand-ink/70"}`} data-testid="logo-mode-svg">Instant maker</button>
                <button onClick={() => setMode("ai")} className={`px-4 py-1.5 rounded-md text-sm font-medium ${mode === "ai" ? "bg-brand-copper text-white" : "text-brand-ink/70"}`} data-testid="logo-mode-ai">AI logo generator</button>
            </div>

            {mode === "ai" && (
                <div className="grid md:grid-cols-[320px_1fr] gap-5">
                    <div className="rounded-2xl border border-brand-line bg-white p-5 shadow-sm space-y-3">
                        <div>
                            <label className="text-xs text-zinc-500">Business name</label>
                            <input value={ai.name || name} onChange={(e) => setAi({ ...ai, name: e.target.value })} className="w-full border border-brand-line rounded-md p-2 text-sm" placeholder="Bloom & Co" data-testid="ai-name" />
                        </div>
                        <div>
                            <label className="text-xs text-zinc-500">Industry / what you do</label>
                            <input value={ai.industry} onChange={(e) => setAi({ ...ai, industry: e.target.value })} className="w-full border border-brand-line rounded-md p-2 text-sm" placeholder="florist, coffee shop, agency…" data-testid="ai-industry" />
                        </div>
                        <div>
                            <label className="text-xs text-zinc-500">Style</label>
                            <select value={ai.style} onChange={(e) => setAi({ ...ai, style: e.target.value })} className="w-full border border-brand-line rounded-md p-2 text-sm bg-white" data-testid="ai-style">
                                {["modern minimalist", "playful", "luxury", "bold", "vintage", "tech", "hand-drawn", "geometric"].map((s) => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-zinc-500">Colors</label>
                            <input value={ai.palette} onChange={(e) => setAi({ ...ai, palette: e.target.value })} className="w-full border border-brand-line rounded-md p-2 text-sm" placeholder="sage green and cream" />
                        </div>
                        <div>
                            <label className="text-xs text-zinc-500">How many ({ai.count})</label>
                            <input type="range" min="1" max="3" value={ai.count} onChange={(e) => setAi({ ...ai, count: +e.target.value })} className="w-full" />
                        </div>
                        <div>
                            <label className="text-xs text-zinc-500">AI engine (remembered)</label>
                            <select value={provider} onChange={(e) => setProvider(e.target.value)} className="w-full border border-brand-line rounded-md p-2 text-sm bg-white" data-testid="ai-provider">
                                {providers.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
                            </select>
                        </div>
                        <Button className="w-full bg-brand-copper hover:bg-brand-copperHover text-white" disabled={aiBusy} onClick={generateAi} data-testid="ai-generate">
                            <Sparkles className="w-4 h-4 mr-1" /> {aiBusy ? "Designing… (~15s)" : "Generate logos"}
                        </Button>
                        <p className="text-[11px] text-zinc-400">Your engine choice is remembered. Each generation uses AI image credits (tracked on your Billing page).</p>
                    </div>
                    <div className="rounded-2xl border border-brand-line bg-white p-5 shadow-sm min-h-[300px]">
                        {aiBusy && <div className="h-full flex items-center justify-center text-zinc-400"><RefreshCw className="w-5 h-5 mr-2 animate-spin" /> Designing your logos…</div>}
                        {!aiBusy && aiImages.length === 0 && <div className="h-full flex items-center justify-center text-zinc-400 text-sm text-center px-6">Describe your brand and hit Generate. You&apos;ll get unique AI logo concepts you can save or download.</div>}
                        <div className="grid grid-cols-2 gap-4">
                            {aiImages.map((img, i) => (
                                <div key={i} className="border border-brand-line rounded-xl overflow-hidden">
                                    <img src={img} alt={`AI logo ${i + 1}`} className="w-full aspect-square object-contain bg-white" data-testid={`ai-image-${i}`} />
                                    <div className="flex gap-1 p-2 border-t border-brand-line">
                                        <Button size="sm" className="flex-1 bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={() => saveAiImage(img)} data-testid={`ai-save-${i}`}><Save className="w-3.5 h-3.5 mr-1" /> Use &amp; apply</Button>
                                        <Button size="sm" variant="outline" className="border-brand-line" onClick={() => { const a = document.createElement("a"); a.href = img; a.download = `${(ai.name || name || "logo").toLowerCase().replace(/\s+/g, "-")}.png`; a.click(); }}><Download className="w-3.5 h-3.5" /></Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {mode === "svg" && (
            <div className="grid md:grid-cols-[320px_1fr] gap-5">
                {/* Controls */}
                <div className={card + " space-y-4 self-start"}>
                    <div>
                        <label className={label}>Business name</label>
                        <input className={input} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Cedar Lane Landscaping" data-testid="logo-name" />
                    </div>
                    <div>
                        <label className={label + " flex items-center gap-1"}><Shapes className="w-3.5 h-3.5" /> Style</label>
                        <div className="grid grid-cols-2 gap-2">
                            {STYLES.map((s) => (
                                <button key={s.id} onClick={() => setStyle(s.id)}
                                    className={`text-xs rounded-lg py-2 border ${style === s.id ? "bg-brand-copper text-white border-brand-copper" : "bg-white border-brand-line text-zinc-600 hover:border-brand-copper"}`}
                                    data-testid={`logo-style-${s.id}`}>{s.label}</button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label className={label + " flex items-center gap-1"}><Palette className="w-3.5 h-3.5" /> Color</label>
                        <div className="flex flex-wrap gap-2">
                            {PALETTES.map((p, i) => (
                                <button key={p.name} onClick={() => setPi(i)} title={p.name}
                                    className={`w-8 h-8 rounded-full border-2 ${pi === i ? "border-brand-copper" : "border-transparent"}`}
                                    style={{ background: p.accent }} data-testid={`logo-palette-${i}`} />
                            ))}
                        </div>
                    </div>
                    <div>
                        <label className={label + " flex items-center gap-1"}><Type className="w-3.5 h-3.5" /> Font</label>
                        <select className={input} value={font} onChange={(e) => setFont(e.target.value)} data-testid="logo-font">
                            {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
                        </select>
                    </div>
                    {style === "icontext" && (
                        <div>
                            <label className={label}>Icon</label>
                            <div className="flex flex-wrap gap-2">
                                {ICONS.map((ic) => (
                                    <button key={ic} onClick={() => setIcon(ic)}
                                        className={`w-10 h-10 rounded-lg border bg-white flex items-center justify-center ${icon === ic ? "border-brand-copper" : "border-brand-line"}`}
                                        dangerouslySetInnerHTML={{ __html: `<svg viewBox="0 0 80 80" width="28" height="28">${iconSvg(ic, palette.accent, 40, 40, 20)}</svg>` }} />
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {/* Preview */}
                <div className="space-y-4">
                    <div className={card}>
                        <div className="text-xs uppercase tracking-wide text-zinc-400 mb-3">Live preview</div>
                        <div className="rounded-xl border border-brand-line overflow-hidden flex items-center justify-center p-8 min-h-[180px]" style={{ background: palette.bg === "#ffffff" ? "#fafafa" : palette.bg }}>
                            <div dangerouslySetInnerHTML={{ __html: svg }} data-testid="logo-preview" />
                        </div>
                        <div className="flex items-center gap-4 mt-4">
                            <div className="rounded-xl border border-brand-line p-3 bg-white" dangerouslySetInnerHTML={{ __html: mark }} />
                            <div className="text-xs text-zinc-500">App icon / favicon mark — auto-generated from your logo.</div>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-5">
                            <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={save} data-testid="logo-save"><Save className="w-4 h-4 mr-1" /> {busy ? "Saving…" : "Save to my brand"}</Button>
                            <Button variant="outline" className="border-brand-line" onClick={() => downloadBlob(svg, `${(name || "logo").toLowerCase().replace(/\s+/g, "-")}.svg`, "image/svg+xml")} data-testid="logo-download-svg"><Download className="w-4 h-4 mr-1" /> SVG</Button>
                            <Button variant="outline" className="border-brand-line" onClick={() => svgToPng(svg, `${(name || "logo").toLowerCase().replace(/\s+/g, "-")}.png`)} data-testid="logo-download-png"><Download className="w-4 h-4 mr-1" /> PNG</Button>
                            <Button variant="ghost" onClick={() => setPi((pi + 1) % PALETTES.length)}><RefreshCw className="w-4 h-4 mr-1" /> Shuffle color</Button>
                        </div>
                    </div>

                    {saved?.logo_svg && (
                        <div className={card}>
                            <div className="text-xs uppercase tracking-wide text-zinc-400 mb-2">Currently saved logo</div>
                            <div className="rounded-lg border border-brand-line p-4 inline-block bg-white" dangerouslySetInnerHTML={{ __html: saved.logo_svg }} />
                        </div>
                    )}

                    {saved?.logo_image && (
                        <div className={card}>
                            <div className="text-xs uppercase tracking-wide text-zinc-400 mb-2">Saved AI logo</div>
                            <img src={saved.logo_image} alt="Saved AI logo" className="w-32 h-32 object-contain rounded-lg border border-brand-line bg-white" />
                        </div>
                    )}

                    {(saved?.logo_image || saved?.logo_svg) && (
                        <div className={card} data-testid="logo-animation-card">
                            <div className="text-xs uppercase tracking-wide text-zinc-400 mb-2">Site-header intro animation</div>
                            <p className="text-xs text-zinc-500 mb-3">Give your logo a short entrance every time a visitor loads your site.</p>
                            <div className="rounded-lg border border-brand-line bg-white p-6 flex items-center justify-center min-h-[96px] overflow-hidden">
                                {saved?.logo_image ? (
                                    <img key={logoAnim} src={saved.logo_image} alt="preview" className={`h-12 w-auto object-contain logo-intro logo-intro-${logoAnim}`} />
                                ) : (
                                    <span key={logoAnim} className={`h-12 flex items-center [&_svg]:h-12 [&_svg]:w-auto logo-intro logo-intro-${logoAnim}`} dangerouslySetInnerHTML={{ __html: saved.logo_svg }} />
                                )}
                            </div>
                            <div className="mt-3 grid grid-cols-3 gap-2">
                                {["none", "fade", "rise", "pop", "sweep", "glow"].map((a) => (
                                    <button key={a} onClick={() => applyAnimation(a)} data-testid={`logo-anim-${a}`}
                                            className={`px-2 py-1.5 rounded-md text-xs font-medium capitalize border transition-colors ${logoAnim === a ? "bg-brand-copper text-white border-brand-copper" : "border-brand-line text-brand-ink hover:border-brand-copper/40"}`}>
                                        {a}
                                    </button>
                                ))}
                            </div>
                            <p className="mt-2 text-[11px] text-zinc-400">Saved instantly and live on your public site header.</p>
                        </div>
                    )}

                    <div className={card + " bg-brand-cream/40"}>
                        <div className="text-sm font-medium text-brand-ink mb-1">Tip</div>
                        <p className="text-xs text-zinc-500">Use the <b>Instant maker</b> for a crisp scalable vector wordmark, or the <b>AI logo generator</b> for unique illustrated marks. Save either one to your brand.</p>
                    </div>
                </div>
            </div>
            )}
        </div>
    );
}
