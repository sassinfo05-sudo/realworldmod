# ZANELVO — HANDOFF ROUND 14 (for a NEW chat)

_Living document for Round 14. Read this first, then `HANDOFF_ROUND_13.md`, `HANDOFF_ROUND_12.md`,
`HANDOFF_ROUND_11.md`, `HANDOFF_ROUND_10.md`, then `HANDOFF_ROUND_8.md` §2 (authoritative A–N backlog).
Source code + fresh test evidence override any older ✅ claims._

---------------------------------------------------------------------------------------------------
## 0. HOW TO CONTINUE (first 10 minutes) — env is WIPED on import
---------------------------------------------------------------------------------------------------
```bash
env | grep -i preview_endpoint                       # preview host changes per job
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && \
SEK=$(python3 -c "import secrets;print(secrets.token_urlsafe(32))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
SECRETS_ENC_KEY=$SEK
EMERGENT_LLM_KEY=<emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
SEED_DEMO=true
CORS_ORIGINS=*
EOF
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
pip install emergentintegrations --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile
sudo supervisorctl restart backend frontend && sleep 35 && curl -s localhost:8001/api/health
cat /app/memory/test_credentials.md      # regenerated with FRESH passwords on seed; send the NEW ones
```
Logins: owner `/login` → `/app`; founder/staff `/staff/login`; public demo `/site/demo-home-services`;
storefront `/store/<org_id>`. A FRESH seed has NO demo products in the store — create some before testing
storefront/commerce. NOTE: use `auto_frontend_testing_agent` for logged-in UI (screenshot tool cannot fill
the React login form).

---------------------------------------------------------------------------------------------------
## 1. STATE AT ROUND 14 START (verified this round)
---------------------------------------------------------------------------------------------------
Import verified GREEN: backend+frontend RUNNING, `/api/health` ok (build 69cdaba50423, db ok),
owner + founder login 200, seed OK. All Round 8–13 features present.

---------------------------------------------------------------------------------------------------
## 2. ROUND 14 PROGRESS TRACKER (⬜ todo · 🟨 in progress · ✅ done & verified)
---------------------------------------------------------------------------------------------------
- ✅ **R14-1 Import + bring-up** — env rebuilt, deps installed, services green, creds verified.
- ✅ **R14-2 (was R13-4) Plan entitlements redo** — backend testing agent PASS (3/3). GET /api/billing/plans
  returns 5 plans (24 entitlement flags each) + matrix{groups:[4]}; owner(autopilot) can enable multi-language
  + create subscription products; free/launch gated (402 feature_not_in_plan). Frontend Pricing.jsx already
  endpoint-driven (built in R13). NOT yet run through the frontend testing agent.
- ✅ **R14-3 (was R13-5b) Integration auto-toggle (sim→live on key paste)** — backend testing agent PASS (7/7).
  Details §3.1. Frontend copy updated (StoreGoLive explains auto behaviour). NOT yet run through frontend agent.
- 🟨 **R14-4 (was R13-5 / R13-3) Home "wow" redesign** — Home.jsx is ALREADY a rich 743-line animated page
  (hero mock, rotating words, dashboard mocks, bento, timeline, testimonials, FAQ) from earlier rounds; Pricing
  already redone in R13. This item is SUBJECTIVE polish — confirm exact direction with the user before rebuilding
  (do not blindly rewrite a page that already looks strong). Lighthouse/axe pass still outstanding.
- ✅ **R14-5 (was R13-6) AI-image logo** — VERIFIED already fully built + working. `POST /api/branding/ai-logo`
  (routes/branding.py) generates via `llm.generate_image` (Gemini Nano Banana `gemini-3.1-flash-image-preview`,
  confirmed current by the integration playbook). Cost IS tracked (ledger row `llm_usage_events`, ~$0.039/gen,
  feature auto-tagged) AND limited (`usage.enforce_budget`: pause-all → provider kill → global cap → org plan cap
  → per-user → per-feature). Frontend `LogoStudio.jsx` has the "AI logo generator" tab (provider selector,
  generate, save/apply, saved-logo display). Provider = Gemini (best/default). End-to-end curl test: generated 1
  image OK. NOTHING to build here — it was already done in an earlier round.
- ✅ **R14-4 Home professional visual overhaul + light/dark** — DONE (details §3.2).
- ✅ **R14-7 Pricing matrix contrast fix** (user-reported) — DONE (details §3.3).
- ⬜ **R14-6 Docs refresh** — CHANGELOG / SECOND_RUN_AUDIT / PRD entries for Rounds 12–14.

### 🔒 BLOCKED ON OWNER CREDENTIALS (cannot finish without keys — ask user)
- PayPal live rail · real SSL issuance (Cloudflare for SaaS / Vercel) · live carrier rates (Shippo/EasyPost) ·
  ad-account OAuth (Google/Meta) · SMS/WhatsApp provider · Stripe Connect.

---------------------------------------------------------------------------------------------------
## 3. WHAT ROUND 14 SHIPPED (appended per task)
---------------------------------------------------------------------------------------------------
### 3.1 R14-3 Integration auto-toggle (sim→live, no extra steps)
Goal (user): "integration should go sim→live automatically when a key is added, no other steps."
- BACKEND `services/tenant_integrations.py`: new `_auto_detect(section, cfg, patch_cfg)` called from `update()`.
  It ONLY fires when the relevant secret is present IN THE SAME PATCH (so unrelated saves and the manual
  Test/Live override are never clobbered):
  - payments: pasting `stripe_secret_key` auto-sets `provider="stripe"` and `store_mode` = "live" if the key
    contains "live" (sk_live_…) else "test" (sk_test_…). Pasting `paypal_secret`+`paypal_client_id` auto-sets
    provider="paypal", store_mode="live". `provider` in the patch = explicit, respected (not overridden).
  - email: `resend_api_key` → provider=resend; `sendgrid_api_key` → sendgrid; smtp host+user+password → smtp.
  - messaging: twilio sid+token → twilio; `retell_api_key` → retell.
  The store checkout already reads `store_mode=="live" && provider=="stripe" && key` (`routes/store.py`
  `_resolve_store_provider`), so the storefront goes live the instant a live key is saved — no `/store/go-live`
  click needed. The manual `POST /api/store/go-live {live:false}` still works as a safety override.
- FRONTEND `pages/dashboard/TenantIntegrations.jsx` `StoreGoLive`: copy now explains it flips to Live
  automatically on saving a live key; Test button remains as an optional force-simulation override.
- VERIFIED: backend testing agent 7/7 (test key→test, live key→auto-live, manual override preserved, email
  auto-detect). Demo org payments reset to none/test afterwards (storefront stays simulated).

### 3.2 R14-4 Home page — full professional visual overhaul (all blocks redone)
Goal (user): "less gaming-like, more professional, impressive to the max, better light/dark, more animations, redo ALL blocks 100x better." Brand palette note: the `brand-copper` token is actually INDIGO (#4F46E5) with a magenta `brand-accent`; the old "gaming" feel came from rainbow multi-tints (fuchsia/amber/emerald/sky/rose) — now unified to the cohesive indigo palette.
- `pages/Home.jsx` rewritten block-by-block:
  - Hero: removed the fuchsia orb (now indigo/violet), rotating headline word uses a refined indigo→violet gradient with a slow animated `headline-sheen`; primary + final CTAs get a hover `cta-sheen` light-sweep.
  - Metrics band: replaced the static 4-stat strip with an animated **CountUp** component (counts up once on scroll-into-view, respects reduced-motion) + label + sub-label, in a divided glass card.
  - Feature bento: rebuilt as a real bento — a large featured cell ("AI website + hosting") containing a mini live website-preview mock, plus cohesive indigo icon-chip cards (chip fills indigo on hover, top accent bar wipes in). `data-testid="home-features"` preserved.
  - "Everything included" dark grid: each of the 12 rows now has a lucide icon chip (fills indigo on hover) + hover glow. `data-testid="home-included-grid"` preserved.
  - How it works: indigo step icons, gradient connector line, staggered reveal.
  - Testimonials/scenarios: added a 5-star row + a large quote-mark watermark; avatars unified to indigo family. `data-testid="scenario-card"` preserved.
  - Trust marquee, FAQ, final CTA, footer: polished (indigo dots, hover borders).
- `index.css`: added `@keyframes headline-sheen`/`.headline-sheen`, `@keyframes cta-sweep`/`.cta-sheen` (+ both disabled under `prefers-reduced-motion`). Added dark-mode overrides for opacity variants: `html.dark [class*="bg-brand-cream"]` and `html.dark [class*="bg-brand-surface"]` (fixes light bands in dark mode).
- All hero/section testids preserved (home-badge, home-hero-headline, home-hero-sub, home-primary-cta, home-secondary-cta, home-hero-note, home-features, home-compare-title, home-included-grid, scenario-card, home-faq-item, home-final-cta-btn).
- VERIFIED: frontend testing agent PASS 4/4 — Home + Pricing render correctly & legibly in BOTH light and dark; no invisible-text bands; count-up + stars + bento all render. Lint clean, webpack compiled.

### 3.3 R14-7 Pricing comparison-matrix contrast fix (user-reported)
User reported the matrix group-header row (`<td>` at Pricing.jsx ~line 168) was barely visible in dark mode and faint in light. Root cause: the group row used `bg-brand-surface/60` (an opacity variant with NO dark override → stayed light in dark mode) + tiny faint `text-zinc-500`. Fix: row now `bg-brand-cream/70` (covered by the new dark override) and the header text is `text-brand-copper font-bold` (indigo #4F46E5 — clearly legible on both light cream and dark #141418). VERIFIED by the frontend agent in both modes (all 4 group headers render rgb(79,70,229), 21 feature rows readable).

### 3.4 R14-8 Full verification sweep
- Import came up GREEN; owner + founder login 200; seed OK; `/api/health` ok.
- Smoke-tested every major feature router (all 200): store subscriptions, gift-cards, localization overrides, tax-rates, reservations, analytics reports, workflows, blog posts, store settings, branding + branding/providers, marketing campaigns, shipping (countries/settings/zones under `/api/store/shipping/*`), numbers marketplace; public billing/plans, support/status, storefront products. Combined with the per-round backend testing-agent PASS records in `test_result.md`, all Round 8–13 features are present and live.

### 3.5 Still blocked on OWNER external keys (UI + backend built as connect-and-go where wired)
The auto-toggle (§3.1) means pasting keys auto-detects the provider and flips live for the WIRED rails: **Stripe store checkout** (fully connect-and-go), **email** (Resend/SendGrid/SMTP), **messaging/SMS** (Twilio). Still needs work/keys to be truly one-paste:
- **PayPal**: webhook verification + billing webhook exist, and auto-toggle sets provider=paypal, BUT `routes/store.py::_resolve_store_provider` only builds a Stripe live provider — PayPal is NOT yet wired into store buy-now checkout. Wiring it (untested without sandbox creds) is the main remaining connect-and-go gap.
- **SSL / custom-domain issuance** (Cloudflare for SaaS / Vercel), **live carrier rates** (Shippo/EasyPost — directory + quote engine exist, live rate fetch on key not wired), **ad-account OAuth** (Google/Meta), **Stripe Connect** (platform is single-account). All refuse the live rail honestly until keys + wiring.

### 3.6 R14-9 AI Spend Caps (owner-set hard monthly $ limit) — DONE, tested
- `services/usage.py`: `owner_ai_cap`/`set_owner_ai_cap` (db.org_ai_settings). `enforce_budget` enforces the owner cap for ALL AI features EVEN on unlimited plans (early-return restructured; per-user-share block guarded by budget>0). `org_usage_summary` returns owner_cap_usd/pct/over. `routes/usage.py`: `GET/PUT /api/usage/cap`.
- BUG FIX `routes/branding.py::ai-logo`: was swallowing the 402 in a broad except → misleading 502; now re-raises HTTPException. Backend agent verified 402 `owner_ai_cap_reached`.
- `pages/dashboard/Billing.jsx`: "Hard monthly AI spend limit" card (`ai-spend-cap`/`ai-cap-input`/`ai-cap-save`/`ai-cap-remove`). Backend 7/7, frontend PASS.

### 3.7 R14-10 Logo Motion (animated logo intro on public site header) — DONE, tested
- `routes/branding.py`: `logo_animation` (none|fade|rise|pop|glow|sweep) in BrandingIn/_out; apply-logo + PUT persist it. `_mirror_logo` FIXED to write BOTH `website.theme` AND `website.published_theme` (logos now show on the LIVE public site — a long-standing gap). `models.py` WebsiteTheme gained logo_image + logo_animation.
- `pages/public/PublicSite.jsx` header renders the logo (`public-logo-image`/`public-logo-svg`) with `logo-intro-<anim>`. `pages/dashboard/LogoStudio.jsx` "Site-header intro animation" card (`logo-animation-card`, `logo-anim-*`) with live preview + instant re-apply. `index.css` has the keyframes. Backend 3/3, frontend PASS.

### 3.8 R14-11 Dark Mode Everywhere + hardening — DONE, tested
- `index.css`: dark overrides for opacity-variant tokens `[class*="bg-brand-cream"]`, `[class*="bg-brand-surface"]`, `[class*="bg-zinc-50/"]`. DashboardShell already had dark: variants; no page uses hardcoded hex bg. Frontend agent verified 6 owner pages render dark+readable. Fixed a pre-existing unescaped apostrophe in Billing.jsx. Health: all services RUNNING, /api/health ok, compileall clean, py+jsx lint clean on all touched files.


Do NOT push from the agent — use the chat's **Save to Github** button. Never modify `.env` MONGO_URL/DB_NAME,
never hardcode URLs, all backend routes under `/api`, UUIDs not ObjectId for new collections.
