import { useEffect, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { CreditCard, Mail, CheckCircle2, AlertCircle, ExternalLink } from "lucide-react";
import ProviderStatusPanel from "@/components/staff/ProviderStatusPanel";

function Status({ ok, label }) {
    return <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${ok ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-600"}`}>{ok ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}{label}</span>;
}

/** Staff → Payments & email: Stripe + PayPal (both can be live) and the platform mail provider used for 2FA codes. */
export default function StaffPayments() {
    const [data, setData] = useState(null);
    const [sec, setSec] = useState({});
    const [saving, setSaving] = useState("");
    const [probe, setProbe] = useState(null);
    async function runProbe() {
        setProbe({ loading: true });
        try { const { data } = await api.get("/founder/integrations/probe/stripe"); setProbe(data); }
        catch (e) { setProbe({ state: "error", message: e?.response?.data?.detail || "Probe failed" }); }
    }
    async function load() { try { const { data } = await api.get("/founder/integrations"); setData(data); } catch (e) { toast.error(e?.response?.data?.detail || "Cannot load (needs integrations.read)"); } }
    useEffect(() => { load(); }, []);
    const p = data?.payments || {}, em = data?.email || {};
    const setF = (section, k, v) => setData((d) => ({ ...d, [section]: { ...d[section], [k]: v } }));
    const ph = (section, k) => { const m = data?.[section]?.[k]; return m?.set ? `${m.hint} — leave blank to keep` : "Not set"; };
    async function save(section, fields, secrets) {
        setSaving(section);
        try {
            const payload = {}; fields.forEach((f) => { payload[f] = data[section][f]; }); secrets.forEach((f) => { const v = sec[`${section}.${f}`]; if (v) payload[f] = v; });
            const res = await api.put("/founder/integrations", { [section]: payload }); setData(res.data); setSec({}); toast.success("Saved");
        } catch (e) { toast.error(e?.response?.data?.detail || "Save failed (owner/developer role required)"); } finally { setSaving(""); }
    }
    if (!data) return <div className="p-8 text-sm text-zinc-500">Loading…</div>;
    const S = (section, k) => <Input type="password" value={sec[`${section}.${k}`] ?? ""} onChange={(e) => setSec({ ...sec, [`${section}.${k}`]: e.target.value })} placeholder={ph(section, k)} className="mt-1 font-mono" data-testid={`int-${section}-${k}`} />;

    return (
        <div className="px-4 md:px-8 py-6 max-w-[1100px] mx-auto space-y-6" data-testid="staff-payments-page">
            <div>
                <h2 className="font-display text-2xl md:text-3xl text-brand-ink dark:text-white">Payments & email</h2>
                <p className="text-sm text-zinc-500 mt-1">Connect the rails Zanelvo charges customers with. Both Stripe and PayPal can be live at once — customers pick at checkout. Keys are stored encrypted-at-rest in the platform database and never shown again.</p>
            </div>

            <ProviderStatusPanel />

            <div className="grid lg:grid-cols-2 gap-5">
                {/* Stripe */}
                <section className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5" data-testid="stripe-card">
                    <div className="flex items-center justify-between"><div className="flex items-center gap-2 font-medium"><span className="w-8 h-8 rounded-lg bg-[#635BFF] text-white grid place-items-center text-xs font-bold">S</span> Stripe</div><Status ok={p.stripe_ready} label={p.stripe_ready ? "Live" : "Not connected"} /></div>
                    <label className="mt-4 flex items-center justify-between text-sm"><span>Enable Stripe checkout</span><Switch checked={!!p.stripe_enabled} onCheckedChange={(v) => setF("payments", "stripe_enabled", v)} data-testid="stripe-enabled" /></label>
                    <div className="mt-3"><Label>Secret key (sk_live_… / sk_test_…)</Label>{S("payments", "stripe_secret_key")}</div>
                    <div className="mt-3"><Label>Publishable key (pk_…)</Label><Input value={p.stripe_publishable_key || ""} onChange={(e) => setF("payments", "stripe_publishable_key", e.target.value)} className="mt-1 font-mono" data-testid="int-payments-stripe_publishable_key" /></div>
                    <div className="mt-3"><Label>Webhook signing secret (whsec_…)</Label>{S("payments", "stripe_webhook_secret")}<p className="text-[11px] text-zinc-500 mt-1">Webhook URL: <code>{process.env.REACT_APP_BACKEND_URL}/api/billing/webhook/stripe</code></p></div>
                    <div className="mt-3 rounded-lg border border-dashed border-brand-line p-3 text-xs" data-testid="stripe-probe">
                        <div className="flex items-center justify-between gap-2">
                            <span className="font-medium">Connection probe (real API call — Live / Sandbox / Not connected / Error)</span>
                            <Button size="sm" variant="outline" onClick={runProbe} disabled={probe?.loading} data-testid="stripe-probe-run">{probe?.loading ? "Probing…" : "Run probe"}</Button>
                        </div>
                        {probe && !probe.loading && (
                            <div className="mt-2 space-y-1" data-testid="stripe-probe-result">
                                <div>State: <b className="uppercase">{probe.state === "not_connected" ? "Not connected" : probe.state}</b>{probe.account_id ? <span className="font-mono text-zinc-500"> · {probe.account_id} · {probe.country}</span> : null}</div>
                                <div>Stripe Connect (tenant onboarding): <b>{probe.connect_enabled ? "Enabled" : "Not enabled"}</b></div>
                                <div className="text-zinc-500">{probe.message}</div>
                            </div>
                        )}
                    </div>
                    <div className="mt-4 flex items-center justify-between"><a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noreferrer" className="text-xs text-brand-copper inline-flex items-center gap-1">Get keys <ExternalLink className="w-3 h-3" /></a>
                        <Button size="sm" disabled={saving === "payments"} onClick={() => save("payments", ["stripe_enabled", "stripe_publishable_key", "paypal_enabled", "paypal_client_id", "paypal_mode"], ["stripe_secret_key", "stripe_webhook_secret", "paypal_secret"])} data-testid="stripe-save">Save Stripe</Button></div>
                </section>

                {/* PayPal */}
                <section className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5" data-testid="paypal-card">
                    <div className="flex items-center justify-between"><div className="flex items-center gap-2 font-medium"><span className="w-8 h-8 rounded-lg bg-[#003087] text-white grid place-items-center text-xs font-bold">P</span> PayPal</div><Status ok={p.paypal_ready} label={p.paypal_ready ? (p.paypal_mode === "live" ? "Live" : "Sandbox") : "Not connected"} /></div>
                    <label className="mt-4 flex items-center justify-between text-sm"><span>Enable PayPal checkout</span><Switch checked={!!p.paypal_enabled} onCheckedChange={(v) => setF("payments", "paypal_enabled", v)} data-testid="paypal-enabled" /></label>
                    <div className="mt-3"><Label>Client ID</Label><Input value={p.paypal_client_id || ""} onChange={(e) => setF("payments", "paypal_client_id", e.target.value)} className="mt-1 font-mono" data-testid="int-payments-paypal_client_id" /></div>
                    <div className="mt-3"><Label>Client secret</Label>{S("payments", "paypal_secret")}</div>
                    <div className="mt-3"><Label>Mode</Label><div className="mt-1 inline-flex rounded-lg border border-brand-line p-0.5">{["sandbox", "live"].map((m) => <button key={m} type="button" onClick={() => setF("payments", "paypal_mode", m)} className={`px-3 py-1 text-xs rounded-md capitalize ${p.paypal_mode === m ? "bg-brand-copper text-white" : "text-zinc-500"}`} data-testid={`paypal-mode-${m}`}>{m}</button>)}</div></div>
                    <div className="mt-4 flex items-center justify-between"><a href="https://developer.paypal.com/dashboard/applications" target="_blank" rel="noreferrer" className="text-xs text-brand-copper inline-flex items-center gap-1">Get credentials <ExternalLink className="w-3 h-3" /></a>
                        <Button size="sm" disabled={saving === "payments"} onClick={() => save("payments", ["stripe_enabled", "stripe_publishable_key", "paypal_enabled", "paypal_client_id", "paypal_mode"], ["stripe_secret_key", "stripe_webhook_secret", "paypal_secret"])} data-testid="paypal-save">Save PayPal</Button></div>
                </section>
            </div>

            {/* Platform email (2FA) */}
            <section className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5" data-testid="platform-email-card">
                <div className="flex items-center justify-between"><div className="flex items-center gap-2 font-medium"><Mail className="w-5 h-5 text-brand-copper" /> Platform email — 2FA codes, staff invites, billing notices</div><Status ok={em.configured} label={em.configured ? `Connected (${em.provider})` : "Not connected — 2FA codes are skipped"} /></div>
                <p className="text-xs text-zinc-500 mt-1">Sender addresses (security@, billing@…) are managed under <b>Email addresses</b>. Until a provider is connected, every account signs in without the email code.</p>
                <div className="mt-4 grid md:grid-cols-3 gap-3">
                    <div><Label>Provider</Label><select value={em.provider || "none"} onChange={(e) => setF("email", "provider", e.target.value)} className="mt-1 w-full h-10 rounded-lg border border-brand-line bg-white dark:bg-zinc-900 px-3 text-sm" data-testid="email-provider"><option value="none">None (2FA off)</option><option value="resend">Resend</option><option value="smtp">SMTP</option></select></div>
                    {em.provider === "resend" && <div className="md:col-span-2"><Label>Resend API key</Label>{S("email", "resend_api_key")}</div>}
                    {em.provider === "smtp" && (<>
                        <div><Label>SMTP host</Label><Input value={em.smtp_host || ""} onChange={(e) => setF("email", "smtp_host", e.target.value)} className="mt-1" data-testid="email-smtp-host" /></div>
                        <div><Label>Port</Label><Input type="number" value={em.smtp_port || 587} onChange={(e) => setF("email", "smtp_port", Number(e.target.value))} className="mt-1" /></div>
                        <div><Label>Username</Label><Input value={em.smtp_username || ""} onChange={(e) => setF("email", "smtp_username", e.target.value)} className="mt-1" /></div>
                        <div><Label>Password</Label>{S("email", "smtp_password")}</div>
                        <label className="flex items-center gap-2 text-sm mt-6"><Switch checked={em.smtp_use_tls !== false} onCheckedChange={(v) => setF("email", "smtp_use_tls", v)} /> Use TLS</label>
                    </>)}
                </div>
                <div className="mt-4 flex justify-end"><Button size="sm" disabled={saving === "email"} onClick={() => save("email", ["provider", "smtp_host", "smtp_port", "smtp_username", "smtp_use_tls"], ["resend_api_key", "smtp_password"])} data-testid="email-save">Save email provider</Button></div>
            </section>

            <div className="rounded-2xl border border-dashed border-brand-line p-4 text-xs text-zinc-500 flex gap-2"><CreditCard className="w-4 h-4 shrink-0 text-brand-copper" /> Customers' own stores connect their own Stripe/PayPal under their Integrations page. These platform keys are for Zanelvo subscriptions.</div>
        </div>
    );
}
