"""Public site serving: JSON for the React public renderer, sitemap.xml, robots.txt.

These endpoints do NOT require auth. Every response uses the PUBLISHED snapshot.
Old slugs redirect (30x) via the slug_history array — enforced client-side via a
`redirect_to` field so the SPA can handle it.
"""
import xml.sax.saxutils as sax
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, HTTPException, Request, Response
from bson import ObjectId

from ..db import get_db
from ..security import verify_password
from ..services import rate_limit
from ..services import sites as site_svc

router = APIRouter(prefix="/public", tags=["public-sites"])


async def _resolve_by_slug(slug: str) -> Optional[Dict[str, Any]]:
    db = get_db()
    slug = slug.lower().strip()
    doc = await db.websites.find_one({"slug": slug, "status": "published"})
    if doc:
        return doc
    # slug redirect from history
    other = await db.websites.find_one({"slug_history": slug, "status": "published"})
    if other:
        return {"__redirect_to__": other.get("slug"), "_doc": other}
    return None


async def _resolve_by_hostname(hostname: str) -> Optional[Dict[str, Any]]:
    db = get_db()
    hostname = hostname.lower().strip().rstrip(".")
    domain = await db.domains.find_one({"hostname": hostname, "state": "connected"})
    if not domain:
        return None
    site = await db.websites.find_one({"_id": ObjectId(domain["website_id"]),
                                        "status": "published"})
    return site


def _page_is_protected(page: Dict[str, Any]) -> bool:
    seo = page.get("seo") or {}
    return bool(seo.get("password_hash") or seo.get("password"))


def _verify_page_password(page: Dict[str, Any], pw: str) -> bool:
    """Verify a submitted page password server-side. Accepts a stored hash, or a
    legacy plaintext value (compared in constant time) — the plaintext is NEVER
    returned to clients (it is stripped from every public payload)."""
    import hmac as _hmac
    seo = page.get("seo") or {}
    h = seo.get("password_hash")
    if h:
        return verify_password((pw or "").strip(), h)
    legacy = seo.get("password")
    if legacy is not None:
        return _hmac.compare_digest((pw or "").strip(), str(legacy).strip())
    return False


def _sanitize_page_for_public(page: Dict[str, Any], *, unlocked: bool) -> Dict[str, Any]:
    """Return a public-safe copy of a page: hidden blocks removed, password fields
    stripped from seo. If the page is protected and not unlocked, blocks are replaced
    with an empty list and `locked: true` is set so protected content never leaks."""
    p = dict(page)
    seo = dict(p.get("seo") or {})
    protected = bool(seo.get("password_hash") or seo.get("password"))
    seo.pop("password", None)
    seo.pop("password_hash", None)
    seo["password_protected"] = protected
    p["seo"] = seo
    if protected and not unlocked:
        p["blocks"] = []
        p["locked"] = True
    else:
        p["blocks"] = [b for b in (page.get("blocks") or []) if not b.get("hidden")]
        p["locked"] = False
    return p


def _public_payload(site_doc: Dict[str, Any], profile: Optional[Dict[str, Any]],
                     show_platform_branding: bool = True,
                     unlocked_pages: Optional[set] = None) -> Dict[str, Any]:
    """Strip Mongo internals; return only what the public renderer needs.

    Hidden blocks and hidden pages are filtered here so the API payload matches
    what the live BlockRenderer renders. Password-protected pages are stubbed
    (no blocks, no password) unless their slug is in `unlocked_pages`.
    """
    unlocked_pages = unlocked_pages or set()
    raw_pages = site_doc.get("published_pages") or []
    nav = site_doc.get("published_nav_order") or [p["slug"] for p in raw_pages]
    filtered_pages = [
        _sanitize_page_for_public(p, unlocked=(p.get("slug") in unlocked_pages))
        for p in raw_pages
    ]
    return {
        "slug": site_doc.get("slug"),
        "org_id": str(site_doc.get("org_id") or ""),   # public, non-secret; used for per-tenant public endpoints (translate, store)
        "business_name": (profile or {}).get("business_name") or "",
        "tagline": (profile or {}).get("tagline") or "",
        "theme": site_doc.get("published_theme"),
        "pages": filtered_pages,
        # hidden pages excluded from nav but still reachable by direct URL
        "nav_order": [s for s in nav if any(p["slug"] == s and not p.get("hidden") for p in raw_pages)],
        "published_at": site_doc.get("published_at"),
        "show_platform_branding": bool(show_platform_branding),
        "seo_defaults": site_doc.get("seo_defaults") or {},
        "pixels": site_doc.get("pixels") or {},
        "allow_indexing": site_doc.get("allow_indexing", True),
        # A per-site fingerprint so scraped clones can be identified.
        "site_fingerprint": str(site_doc.get("_id", ""))[-12:],
    }


def _anti_clone_headers(response: Response, site_doc: Dict[str, Any]) -> None:
    """Best-effort discouragement of cloning / hotlinking / iframe embedding.
    Not a hard block (public sites need to be public), but signals + rate-limit hooks."""
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Content-Security-Policy"] = "frame-ancestors 'self'"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # X-Robots-Tag: allow indexing when owner allows, else noindex
    if not site_doc.get("allow_indexing", True):
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
    else:
        # noai/noimageai discourage LLM crawler ingestion of tenant content
        response.headers["X-Robots-Tag"] = "index, follow, noai, noimageai"
    fp = str(site_doc.get("_id", ""))[-12:]
    response.headers["X-Content-Owner"] = f"zanelvo:{fp}"
    response.headers["X-Content-Type-Options"] = "nosniff"


async def _branding_flag(org_id: str) -> bool:
    """Compute whether the "Powered by Zanelvo" footer should show. Free plans do; paid don't."""
    try:
        from ..services.entitlements import branding_removed
        return not await branding_removed(org_id)
    except Exception:  # noqa: BLE001
        return True


@router.get("/sites/by-host")
async def by_host(request: Request):
    """Look up a site by the incoming Host header (or an override query param for testing)."""
    override = request.query_params.get("host")
    host = (override or request.headers.get("host") or "").split(":")[0].lower()
    if not host:
        raise HTTPException(400, "No host provided")
    site = await _resolve_by_hostname(host)
    if not site:
        raise HTTPException(404, "No published site is bound to this hostname")
    db = get_db()
    profile = await db.business_profiles.find_one({"org_id": site["org_id"]})
    gate = _maintenance_gate(site, request, profile)
    if gate:
        return gate
    payload = _public_payload(site, profile, show_platform_branding=await _branding_flag(site["org_id"]))
    dom = await db.domains.find_one({"hostname": host, "state": "connected"}, {"landing_page_slug": 1})
    payload["landing_page_slug"] = (dom or {}).get("landing_page_slug")
    return payload


@router.get("/payment-methods")
async def public_payment_methods():
    """Which checkout rails the platform offers right now (Stripe / PayPal / simulated)."""
    from ..services.integrations import payment_methods_public
    return await payment_methods_public()


def _maintenance_gate(site: Dict[str, Any], request: Request, profile: Optional[Dict[str, Any]]):
    """Return a maintenance payload when the site is private and the visitor holds no
    valid unlock token (query `?unlock=` or header `X-Site-Unlock`). Else None."""
    m = site.get("maintenance") or {}
    if not m.get("enabled"):
        return None
    token = request.query_params.get("unlock") or request.headers.get("X-Site-Unlock")
    if site_svc.unlock_token_valid(str(site["_id"]), token):
        return None
    return site_svc.maintenance_public(site, (profile or {}).get("business_name") or site.get("name") or "")


@router.post("/sites/{slug}/unlock")
async def unlock_site(slug: str, body: Dict[str, str] = Body(...), request: Request = None):
    """Visitor enters the maintenance password → 24h unlock token."""
    if request is not None:
        rate_limit.check("site_unlock", request, limit=15, window_seconds=300)
    resolved = await _resolve_by_slug(slug)
    if not resolved or "__redirect_to__" in resolved:
        raise HTTPException(404, "No published site at this slug")
    m = resolved.get("maintenance") or {}
    if not m.get("enabled"):
        return {"ok": True, "unlock_token": None, "open": True}
    if not m.get("password_hash"):
        raise HTTPException(403, "This site is private and has no visitor password")
    if not verify_password((body.get("password") or "").strip(), m["password_hash"]):
        raise HTTPException(401, "Incorrect password")
    return {"ok": True, "unlock_token": site_svc.make_unlock_token(str(resolved["_id"]))}


@router.get("/sites/{slug}")
async def get_public_site(slug: str, response: Response, request: Request):
    resolved = await _resolve_by_slug(slug)
    if not resolved:
        raise HTTPException(404, "No published site at this slug")
    if "__redirect_to__" in resolved:
        return {"redirect_to": resolved["__redirect_to__"]}
    db = get_db()
    profile = await db.business_profiles.find_one({"org_id": resolved["org_id"]})
    gate = _maintenance_gate(resolved, request, profile)
    if gate:
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
        return gate
    _anti_clone_headers(response, resolved)
    return _public_payload(resolved, profile, show_platform_branding=await _branding_flag(resolved["org_id"]))


@router.get("/sites/{slug}/pages/{page_slug}")
async def get_public_page(slug: str, page_slug: str, response: Response, request: Request):
    resolved = await _resolve_by_slug(slug)
    if not resolved:
        raise HTTPException(404, "No published site at this slug")
    if "__redirect_to__" in resolved:
        return {"redirect_to": f"/site/{resolved['__redirect_to__']}/{page_slug}"}
    db = get_db()
    profile = await db.business_profiles.find_one({"org_id": resolved["org_id"]})
    gate = _maintenance_gate(resolved, request, profile)
    if gate:
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
        return gate
    # Determine whether THIS page has a valid unlock token (page + site scoped).
    raw_page = next((p for p in (resolved.get("published_pages") or []) if p.get("slug") == page_slug), None)
    if not raw_page:
        raise HTTPException(404, "Page not found in published site")
    unlocked = set()
    if _page_is_protected(raw_page):
        token = request.query_params.get("unlock") or request.headers.get("X-Page-Unlock")
        if site_svc.page_unlock_token_valid(str(resolved["_id"]), page_slug, token):
            unlocked.add(page_slug)
        else:
            # Protected & locked: never index, never leak blocks.
            response.headers["X-Robots-Tag"] = "noindex, nofollow"
    payload = _public_payload(resolved, profile,
                              show_platform_branding=await _branding_flag(resolved["org_id"]),
                              unlocked_pages=unlocked)
    page = next((p for p in payload["pages"] if p["slug"] == page_slug), None)
    if not page:
        raise HTTPException(404, "Page not found in published site")
    _anti_clone_headers(response, resolved)
    if page.get("locked"):
        # Keep it noindex even if allow_indexing set the header above.
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
    return {"site": {"slug": payload["slug"], "business_name": payload["business_name"],
                     "theme": payload["theme"], "nav_order": payload["nav_order"],
                     "show_platform_branding": payload["show_platform_branding"],
                     "seo_defaults": payload["seo_defaults"], "pixels": payload["pixels"],
                     "allow_indexing": payload["allow_indexing"],
                     "site_fingerprint": payload["site_fingerprint"]},
            "page": page}


@router.post("/sites/{slug}/pages/{page_slug}/unlock")
async def unlock_page(slug: str, page_slug: str, body: Dict[str, str] = Body(...),
                      request: Request = None):
    """Visitor enters a per-page password → short-lived page+site-scoped unlock token.
    Rate-limited. The password is verified server-side against a hash; it is never
    returned in any payload."""
    if request is not None:
        rate_limit.check("page_unlock", request, limit=12, window_seconds=300)
    resolved = await _resolve_by_slug(slug)
    if not resolved or "__redirect_to__" in resolved:
        raise HTTPException(404, "No published site at this slug")
    raw_page = next((p for p in (resolved.get("published_pages") or []) if p.get("slug") == page_slug), None)
    if not raw_page:
        raise HTTPException(404, "Page not found")
    if not _page_is_protected(raw_page):
        return {"ok": True, "unlock_token": None, "open": True}
    if not _verify_page_password(raw_page, (body.get("password") or "").strip()):
        raise HTTPException(401, "Incorrect password")
    return {"ok": True,
            "unlock_token": site_svc.make_page_unlock_token(str(resolved["_id"]), page_slug)}


@router.get("/sites/{slug}/sitemap.xml")
async def sitemap(slug: str, request: Request):
    resolved = await _resolve_by_slug(slug)
    if not resolved or "__redirect_to__" in resolved:
        raise HTTPException(404, "No published site at this slug")
    pages = resolved.get("published_pages") or []
    base = str(request.url).split("/api/")[0].rstrip("/")  # e.g., https://host
    urls = []
    for p in pages:
        if p.get("hidden"):
            continue
        loc = f"{base}/site/{slug}" + ("" if p["slug"] == "home" else f"/{p['slug']}")
        urls.append(loc)
    try:
        from .blog import published_post_slugs
        for ps in await published_post_slugs(resolved["org_id"]):
            urls.append(f"{base}/site/{slug}/blog/{ps}")
    except Exception:  # noqa: BLE001
        pass
    # Published dynamic CMS pages (list route + each published item detail URL).
    try:
        from ..services import cms as _cms
        db = get_db()
        async for tpl in db[_cms.TEMPLATES].find(
                {"org_id": resolved["org_id"], "site_slug": slug, "status": "published"},
                {"_id": 0, "route_base": 1, "collection_id": 1}):
            rb = tpl.get("route_base")
            if not rb:
                continue
            urls.append(f"{base}/site/{slug}/{rb}")
            async for it in db[_cms.ITEMS].find(
                    {"org_id": resolved["org_id"], "collection_id": tpl["collection_id"],
                     "status": "published", "archived": {"$ne": True}},
                    {"_id": 0, "slug": 1}).limit(5000):
                if it.get("slug"):
                    urls.append(f"{base}/site/{slug}/{rb}/{it['slug']}")
    except Exception:  # noqa: BLE001
        pass
    body = ['<?xml version="1.0" encoding="UTF-8"?>',
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in urls:
        body.append(f"  <url><loc>{sax.escape(u)}</loc></url>")
    body.append("</urlset>")
    return Response(content="\n".join(body), media_type="application/xml")


@router.get("/sites/{slug}/robots.txt")
async def robots(slug: str, request: Request):
    resolved = await _resolve_by_slug(slug)
    if not resolved or "__redirect_to__" in resolved:
        raise HTTPException(404, "No published site at this slug")
    base = str(request.url).split("/api/")[0].rstrip("/")
    body = "\n".join([
        "User-agent: *",
        "Allow: /",
        f"Sitemap: {base}/api/public/sites/{slug}/sitemap.xml",
        "",
    ])
    return Response(content=body, media_type="text/plain")
