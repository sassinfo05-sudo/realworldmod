import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api from "@/lib/api";
import { setJsonLd } from "@/pages/public/PublicSite";

/** Public blog list + article pages for a tenant site: /site/:slug/blog and /site/:slug/blog/:postSlug */
export default function PublicBlog() {
    const { slug, postSlug } = useParams();
    const [site, setSite] = useState(null);
    const [posts, setPosts] = useState(null);
    const [post, setPost] = useState(null);
    const [err, setErr] = useState(null);

    useEffect(() => {
        setErr(null); setPost(null); setPosts(null);
        api.get(`/public/sites/${slug}`).then(({ data }) => setSite(data)).catch(() => setSite(null));
        if (postSlug) {
            api.get(`/public/sites/${slug}/blog/${postSlug}`).then(({ data }) => {
                setPost(data);
                document.title = data.seo?.title || data.title;
                try {
                    setJsonLd([{ "@context": "https://schema.org", "@type": "Article", headline: data.title,
                        description: data.excerpt || data.seo?.description || undefined,
                        image: data.cover_image || undefined, datePublished: data.published_at || undefined,
                        dateModified: data.updated_at || data.published_at || undefined,
                        author: { "@type": "Organization", name: data.author || site?.business_name || "" },
                        mainEntityOfPage: window.location.href }].map((o) => JSON.parse(JSON.stringify(o))), "zv-jsonld-article");
                } catch { /* non-fatal */ }
            }).catch(() => setErr("Article not found"));
        } else {
            api.get(`/public/sites/${slug}/blog`, { params: { limit: 50 } }).then(({ data }) => setPosts(data.posts || [])).catch(() => setErr("No published site at this address"));
        }
    }, [slug, postSlug]);

    const theme = site?.theme || {};
    const name = site?.business_name || site?.profile?.business_name || "";
    const vars = { "--tenant-primary": theme.primary || "#4F46E5", "--tenant-background": theme.background || "#fff",
        "--tenant-foreground": theme.foreground || "#0B0A16", "--tenant-surface": theme.surface || "#F6F6FA",
        background: theme.background || "#fff", color: theme.foreground || "#0B0A16", fontFamily: theme.font_body || "inherit", minHeight: "100vh" };

    return (
        <div style={vars} className="tenant-site" data-testid="public-blog">
            <header className="border-b" style={{ borderColor: "var(--tenant-surface)" }}>
                <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
                    <Link to={`/site/${slug}`} className="font-semibold" style={{ fontFamily: theme.font_heading || "inherit" }}>{name || "Home"}</Link>
                    <Link to={`/site/${slug}/blog`} className="text-sm opacity-80 hover:opacity-100">Blog</Link>
                </div>
            </header>
            <main className="max-w-3xl mx-auto px-6 py-12">
                {err && <div className="text-center opacity-70" data-testid="public-blog-error">{err}</div>}
                {!postSlug && posts && (
                    <>
                        <h1 className="text-4xl font-semibold" style={{ fontFamily: theme.font_heading || "inherit" }}>Articles</h1>
                        {posts.length === 0 && <p className="mt-4 opacity-70">No articles published yet.</p>}
                        <div className="mt-8 space-y-8">
                            {posts.map((p) => (
                                <article key={p.slug} className="border-b pb-8" style={{ borderColor: "var(--tenant-surface)" }} data-testid={`public-blog-item-${p.slug}`}>
                                    {p.published_at && <div className="text-xs opacity-60">{new Date(p.published_at).toLocaleDateString()}</div>}
                                    <Link to={`/site/${slug}/blog/${p.slug}`} className="block mt-1 text-2xl font-semibold hover:underline" style={{ fontFamily: theme.font_heading || "inherit" }}>{p.title}</Link>
                                    {p.excerpt && <p className="mt-2 opacity-80">{p.excerpt}</p>}
                                    {p.tags?.length > 0 && <div className="mt-3 flex gap-2 flex-wrap">{p.tags.map((t) => <span key={t} className="text-xs px-2 py-0.5 rounded-full" style={{ background: "var(--tenant-surface)" }}>{t}</span>)}</div>}
                                </article>
                            ))}
                        </div>
                    </>
                )}
                {postSlug && post && (
                    <article data-testid="public-blog-article">
                        {post.published_at && <div className="text-xs opacity-60">{new Date(post.published_at).toLocaleDateString()}</div>}
                        <h1 className="mt-2 text-4xl font-semibold leading-tight" style={{ fontFamily: theme.font_heading || "inherit" }}>{post.title}</h1>
                        {post.excerpt && <p className="mt-3 text-lg opacity-80">{post.excerpt}</p>}
                        {post.cover_image && <img src={post.cover_image} alt="" className="mt-6 w-full rounded-2xl object-cover max-h-[420px]" />}
                        <div className="mt-8 space-y-5 text-[17px] leading-relaxed">
                            {String(post.body || "").split(/\n\s*\n/).map((para, i) => para.startsWith("## ")
                                ? <h2 key={i} className="text-2xl font-semibold mt-8" style={{ fontFamily: theme.font_heading || "inherit" }}>{para.slice(3)}</h2>
                                : <p key={i}>{para.split("\n").map((l, j) => l.startsWith("## ") ? <strong key={j} className="block text-xl mt-4">{l.slice(3)}</strong> : <span key={j}>{l}{j < para.split("\n").length - 1 ? " " : ""}</span>)}</p>)}
                        </div>
                        <div className="mt-10"><Link to={`/site/${slug}/blog`} className="text-sm font-medium" style={{ color: "var(--tenant-primary)" }}>← All articles</Link></div>
                    </article>
                )}
            </main>
        </div>
    );
}
