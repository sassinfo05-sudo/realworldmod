# ZANELVO — HANDOFF ROUND 13 (for a NEW chat)

_Living document for Round 13. Read this first, then `HANDOFF_ROUND_12.md`, `HANDOFF_ROUND_11.md`,
`HANDOFF_ROUND_10.md`, then `HANDOFF_ROUND_8.md` §2 (authoritative A–N backlog). Source code + fresh
test evidence override any older ✅ claims._

---------------------------------------------------------------------------------------------------
## 0. HOW TO CONTINUE (first 10 minutes) — env is WIPED on import
---------------------------------------------------------------------------------------------------
```bash
env | grep -i preview_endpoint                       # preview host changes per job
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && \
SEK=$(python3 -c "import secrets;print(secrets.token_urlsafe(32))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
SECRETS_ENC_KEY=$SEK
EMERGENT_LLM_KEY=<emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
SEED_DEMO=true
CORS_ORIGINS=*
EOF
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
pip install emergentintegrations --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile
sudo supervisorctl restart backend frontend && sleep 35 && curl -s localhost:8001/api/health
cat /app/memory/test_credentials.md      # regenerated with FRESH passwords on seed; send the NEW ones
```
Logins: owner `/login` → `/app`; founder/staff `/staff/login`; public demo `/site/demo-home-services`;
storefront `/store/<org_id>`. A FRESH seed has NO demo products in the store — create some (owner Products
page or `POST /api/store/products`) before testing storefront/commerce.

NOTE (screenshot tool): the mcp_screenshot_tool does not reliably fill the login form's React controlled
inputs (fields stay empty). Use the `auto_frontend_testing_agent` for any logged-in UI verification — it
reads `/app/memory/test_credentials.md` and logs in correctly.

---------------------------------------------------------------------------------------------------
## 1. STATE AT ROUND 13 START (verified this round, corrects stale Round-12 claims)
---------------------------------------------------------------------------------------------------
Import verified green: backend+frontend RUNNING, `/api/health` ok, owner + founder login 200, seed OK.

Round-12 listed two items as "NOT started" that are ACTUALLY DONE & LIVE (built after R12 handoff written):
- ✅ **Subscriptions (recurring products)** — `routes/subscriptions.py` (owner list/get/cancel/run-renewal,
  public `/api/public/store/{org}/subscribe`, MRR calc, `activate_subscription_for_order`,
  `process_due_renewals`, background `_renewal_loop`). Registered in `server.py` (lines 175/176) +
  `start_renewal_loop()` (line 406). Frontend: `pages/dashboard/Subscriptions.jsx`, Storefront subscribe
  path, `pages/public/SimulatedSubscriptionCheckout.jsx`. `GET /api/store/subscriptions` returns 200.
- ✅ **Developer docs page** (Round 12 §2.2) — `pages/Developers.jsx`, route `/developers`.

---------------------------------------------------------------------------------------------------
## 2. ROUND 13 PROGRESS TRACKER (⬜ todo · 🟨 in progress · ✅ done & verified)
---------------------------------------------------------------------------------------------------
- ✅ **R13-1 Per-language AUTHORED site content** — DONE, backend curl-verified. (details §3.1)
- ✅ **R13-2 Block-based email editor** — DONE, backend curl-verified. (details §3.2)
- ⬜ **R13-3 Home + Pricing "wow" redesign + Lighthouse/axe pass** (subjective; confirm scope w/ user)
- ⬜ Docs: CHANGELOG / SECOND_RUN_AUDIT / PRD refresh for Round 12 + 13
- ✅ Backend testing agent PASS 43/43 for R13-1 + R13-2 (see test_result.md)
- ✅ **R13-AUTH CORS/credentials fix** — switched browser auth cookie→Bearer so it works cross-origin behind
  the wildcard-CORS ingress. Frontend testing PASS 20/20 for R13-1 + R13-2. (details §3.3)
- ⬜ **R13-4 Redo ALL plans** — reflect every new feature into plan tiers/entitlements/limits (user ask)
  · 🟨 backend DONE (entitlements flags + matrix + PLANS_SEED v4 + light enforcement, curl-verified) — needs backend testing agent
- 🟨 **R13-5 Home + Pricing redesign** — Pricing page DONE (new endpoint-driven design + comparison matrix). Home pending.
- ⬜ **R13-5b Integration auto-toggle** — sim→live automatically when a key is added, no other steps (user ask)
- ⬜ **R13-6 AI-image logo** — use Emergent key (provider choice pending: Gemini Nano Banana vs gpt-image-1)

### 🔒 BLOCKED ON OWNER CREDENTIALS (cannot finish without keys — ask user)
- PayPal live rail · real SSL issuance (Cloudflare for SaaS / Vercel) · live carrier rates (Shippo/EasyPost) ·
  ad-account OAuth (Google/Meta) · SMS/WhatsApp provider · Stripe Connect · AI-image logo (needs provider
  choice: Gemini Nano Banana vs OpenAI gpt-image-1, + Emergent key).

---------------------------------------------------------------------------------------------------
## 3. WHAT ROUND 13 SHIPPED (appended per task)
---------------------------------------------------------------------------------------------------
### 3.1 R13-1 Per-language authored site content
Goal: let owners author EXACT wording for their live site per language, overriding the automatic AI
translation done by the public `LanguageSwitcher` (which machine-translates DOM text keyed by source string).
- BACKEND `routes/localization.py` (owner `/api/localization/*`, public `/api/public/localization/*`),
  collection `db.org_translation_overrides` {org_id, lang, entries:{source→target}, updated_at}:
  - `GET /localization/overrides?lang=` → `{entries, sources}`; `sources` = visible copy extracted from the
    active/published site (`_collect_strings` walks block props, skips urls/hex/numbers/structural keys via
    `_SKIP_STRING_KEYS`, `_site_source_strings`).
  - `PUT /localization/overrides {lang, entries}` → `_clean_entries` (trim, drop identical, cap 800, 400/800
    char caps), upsert.
  - `POST /localization/overrides/auto {lang, sources?}` → machine-translate the NOT-yet-authored sources via
    existing `_translate` (returns suggestions, does NOT save).
  - `GET /public/localization/{org}/overrides?lang=` → `{entries}` only when that lang is enabled.
- FRONTEND `components/public/LanguageSwitcher.jsx`: before machine-translating, fetches authored overrides
  for the target lang once (`overridesRef`) and seeds them into the result map (authored wins), so those
  strings never hit the LLM. `pages/dashboard/Localization.jsx`: new "Authored translations" card
  (testids `loc-authored-card`, `loc-auth-lang`, `loc-auth-suggest`, `loc-auth-save`, `loc-auth-list`,
  `loc-auth-input-{i}`) — pick language, list of site source strings each with an input, "AI fill blanks"
  prefills empties (review then Save), Save persists.
- VERIFIED (curl): enable en+es → overrides GET returns 74 sources → PUT one override → public GET returns it;
  auto-fill returned correct Spanish for 3 phrases. Lint clean (py + both jsx). Frontend NOT yet run through
  the testing agent.

### 3.2 R13-2 Block-based email editor
Goal: replace the plain `body_text`-only marketing email with a block/section editor + live preview.
- BACKEND `services/campaign_tracking.py`: refactored the branded shell into `_wrap_email(...)`;
  added `_track_url`, `_linkify_tracked`, `build_email_blocks_html(...)` (renders block types
  heading/text/button/image/divider/spacer to email-safe table HTML; buttons + image links + inline URLs
  are click-tracked via `/api/t/c/<token>`; open pixel injected by the shell), and `blocks_to_text(...)`
  (plain-text fallback + provider `text=`). `EMAIL_BLOCK_TYPES` constant. `choose_variant` now also returns
  `blocks` (variant blocks → campaign blocks fallback).
- BACKEND `routes/marketing.py`: `CampaignCreate.blocks` + `"blocks"` in the update allow-list;
  `send_campaign` uses the block renderer when `blocks` present (else the legacy text path — fully backward
  compatible); NEW `POST /api/marketing/campaigns/preview {blocks?|body_text?}` → `{html, text}` for the editor.
- FRONTEND `pages/dashboard/Marketing.jsx`: `BlockEmailEditor` (add heading/text/button/image/divider/spacer,
  reorder up/down, delete, inline fields — testids `email-block-editor`, `email-add-<type>`, `email-block-<i>`,
  `email-block-up/down/del-<i>`, `email-field-*`) + `EmailPreview` (debounced iframe srcDoc of the preview
  endpoint, sandboxed). CampaignsTab gained a "Simple text | Blocks" toggle (`camp-design-toggle`,
  `camp-mode-text`, `camp-mode-blocks`); block mode sends `payload.blocks`.
- VERIFIED (curl): preview renders heading + tracked button (`/api/t/c/preview`) + open pixel
  (`/api/t/o/preview.gif`); create campaign with blocks persists `blocks`. Lint clean. Frontend NOT yet run
  through the testing agent.

### 3.3 R13-AUTH — CORS/credentials fix (cookie → Bearer)
Problem: the platform ingress answers CORS preflight with `Access-Control-Allow-Origin: *`. The Round-10
cookie auth used `withCredentials:true`, which the browser BLOCKS against a `*` origin — so any cross-origin
caller (the frontend testing agent loads the SPA from `handoff-central-1...` while the API host is the
`1f7c3c73...` preview; also any cross-domain deploy) could not log in. Same-origin real users were unaffected.
Fix (application-level, since ingress isn't editable):
- `backend/server.py` CORS now uses `allow_origin_regex=".*"` + `allow_credentials=True` when `CORS_ORIGINS=*`
  (echoes the request Origin instead of literal `*`) — harmless improvement; the real fix is the frontend:
- `frontend/src/context/AuthContext.jsx` `persist()` now STORES the JWT in `localStorage["revenue_os.token"]`
  (was cookie-only). `frontend/src/lib/api.js` axios `withCredentials:false`. The existing interceptor already
  sends `Authorization: Bearer <revenue_os.token>`; backend `deps._extract_token` prefers the Bearer header and
  Bearer requests bypass CSRF — so requests are now NON-credentialed and valid under `*` CORS.
- Tradeoff: JWT is back in localStorage (reverses R10 XSS-hardening). Acceptable for MVP + needed for
  testability & cross-domain deploy. Server still sets the HttpOnly cookie as a same-origin fallback.
- VERIFIED: frontend testing agent logged in cross-origin and passed R13-1 (8/8) + R13-2 (12/12) = 20/20.

### 3.4 R13-4 Redo plans + R13-5 Pricing redesign
Goal (user): "redo plans completely since there are lots of new features that aren't limited to certain plans/limits."
- BACKEND `services/entitlements.py`: `PlanLimits` gained flags `max_products, online_store, subscriptions,
  multi_language, automations, advanced_analytics, ad_campaigns, abandoned_cart, pos, priority_support`
  (defaults keep old callers safe). Populated across all 5 tiers (free→launch→revenue→autopilot→scale).
  autopilot (the demo owner's plan) has ALL of them, so gating never breaks the demo. Added to
  `entitlements_dict`, `_OVERRIDABLE_INT/_BOOL` (founder-editable), and NEW `feature_matrix(codes)` +
  `FEATURE_MATRIX_ROWS` (grouped: Websites & content / Online store / Marketing & AI / Team & limits).
- BACKEND `routes/billing.py` `GET /api/billing/plans` now returns per-plan `annual_price_usd, audience,
  badge, order, entitlements` PLUS a top-level `matrix` (the comparison grid).
- BACKEND `config.py`: refreshed all 5 plans' marketing `features` copy (store/subscriptions/multi-lang/
  automations/ads/POS/priority support) + bumped `PLANS_SEED_VERSION` 3→4 (re-seeds DB copy on restart).
- ENFORCEMENT (light, demo-safe): `localization.put_settings` requires `multi_language` when enabling >1 lang;
  `store.create_product` requires `subscriptions` when `is_subscription=true`. Both use existing
  `enforce_feature_enabled` (402 feature_not_in_plan). autopilot passes; free/launch get gated (intended).
- FRONTEND `pages/Pricing.jsx`: full rebuild off `/api/billing/plans` — premium hero, monthly/annual toggle
  with per-plan savings %, 5 plan cards (badge/audience/price/features/CTA, highlighted Business), trust strip,
  and a grouped comparison matrix (`capability-matrix`) rendering bool→check/number→allowance ("Unlimited"
  for ≥100k), plus a closing CTA. testids preserved: billing-toggle, toggle-monthly/annual, pricing-grid,
  plan-<code>, plan-<code>-cta, capability-matrix.
- VERIFIED (curl): /api/billing/plans → 5 plans + 4 matrix groups; autopilot owner still creates normal +
  subscription products + enables multi-language (200). Pricing page hero copy live. Lint clean.
  NOT yet run through backend/ frontend testing agents.

---------------------------------------------------------------------------------------------------
## 4. GIT / RULES
---------------------------------------------------------------------------------------------------
Do NOT push from the agent — use the chat's **Save to Github** button. Never modify `.env` MONGO_URL/DB_NAME,
never hardcode URLs, all backend routes under `/api`, UUIDs not ObjectId for new collections.
