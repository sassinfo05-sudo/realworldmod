import { useEffect, useMemo, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Zap, ShieldAlert, CheckCircle, ArrowUpRight, Ticket, AlertCircle } from "lucide-react";

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

function Meter({ meter, label, unit }) {
    const pct = Math.min(100, meter?.pct || 0);
    const color = meter?.over ? "bg-red-500" : meter?.warn ? "bg-amber-500" : "bg-brand-copper";
    return (
        <div data-testid={`meter-${label}`} className="rounded-lg border border-brand-line bg-white p-4">
            <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-medium text-brand-ink">{label}</div>
                <div className="text-xs font-mono text-zinc-500">{meter?.used ?? 0} / {meter?.cap ?? 0} {unit || ""}</div>
            </div>
            <div className="h-1.5 rounded-full bg-brand-cream overflow-hidden">
                <div className={`h-full ${color}`} style={{ width: `${pct}%` }} />
            </div>
            {meter?.over && (
                <div className="mt-2 text-[11px] uppercase tracking-widest text-red-700 flex items-center gap-1">
                    <ShieldAlert className="w-3 h-3" /> Over the plan limit — upgrade to continue
                </div>
            )}
            {meter?.warn && !meter?.over && (
                <div className="mt-2 text-[11px] uppercase tracking-widest text-amber-700 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> Nearing your plan limit
                </div>
            )}
        </div>
    );
}

export default function Billing() {
    const [subscription, setSubscription] = useState(null);
    const [entitlements, setEntitlements] = useState(null);
    const [usage, setUsage] = useState(null);
    const [plans, setPlans] = useState([]);
    const [invoices, setInvoices] = useState([]);
    const [aiUsage, setAiUsage] = useState(null);
    const [upgradeOpen, setUpgradeOpen] = useState(false);
    const [target, setTarget] = useState(null);
    const [coupon, setCoupon] = useState("");
    const [busy, setBusy] = useState(false);
    const [couponFeedback, setCouponFeedback] = useState(null);
    const [capInput, setCapInput] = useState("");
    const [capBusy, setCapBusy] = useState(false);

    async function saveCap(value) {
        setCapBusy(true);
        try {
            const v = Math.max(0, Number(value) || 0);
            await api.put("/usage/cap", { monthly_cap_usd: v });
            toast.success(v > 0 ? `AI spend limit set to $${v.toFixed(2)}/mo` : "AI spend limit removed");
            const { data } = await api.get("/usage/ai");
            setAiUsage(data);
            setCapInput("");
        } catch (e) {
            toast.error(e?.response?.data?.detail?.message || "Could not update spend limit");
        } finally { setCapBusy(false); }
    }

    async function loadAll() {
        try {
            const [s, u, p, i] = await Promise.all([
                api.get("/billing/subscription"),
                api.get("/billing/usage"),
                api.get("/billing/plans"),
                api.get("/billing/invoices"),
            ]);
            setSubscription(s.data.subscription);
            setEntitlements(s.data.entitlements);
            setUsage(u.data);
            setPlans(p.data.plans || []);
            setInvoices(i.data.invoices || []);
        } catch (e) { toast.error("Failed to load billing"); }
        try {
            const { data } = await api.get("/usage/ai");
            setAiUsage(data);
        } catch (e) { /* non-fatal */ }
    }
    useEffect(() => { loadAll(); }, []);

    const currentPlan = subscription?.plan_code;
    const [interval, setInterval_] = useState("monthly");
    async function startCheckout(planCode) {
        setBusy(true);
        try {
            const { data } = await api.post("/billing/checkout", {
                plan_code: planCode,
                coupon_code: coupon || null,
                provider: "simulated",
                interval,
            });
            window.location.href = data.checkout_url;
        } catch (e) {
            toast.error(e?.response?.data?.detail?.message || "Checkout failed");
        } finally { setBusy(false); }
    }
    async function cancelSub() {
        if (!window.confirm("Cancel at end of billing period? Your access continues until then.")) return;
        setBusy(true);
        try {
            const reason = window.prompt("Any feedback? (optional)", "") || "";
            await api.post("/billing/subscription/cancel", { reason });
            toast.success("Cancellation scheduled for end of period");
            loadAll();
        } catch (e) { toast.error("Cancel failed"); }
        finally { setBusy(false); }
    }
    async function resumeSub() {
        setBusy(true);
        try {
            await api.post("/billing/subscription/resume");
            toast.success("Resumed");
            loadAll();
        } finally { setBusy(false); }
    }
    async function triggerDunning() {
        setBusy(true);
        try {
            await api.post("/billing/subscription/simulate-payment-failure");
            toast.success("Marked past_due (simulated)");
            loadAll();
        } finally { setBusy(false); }
    }

    return (
        <div className="p-6 max-w-6xl" data-testid="billing-page">
            <div className="mb-6">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Billing</div>
                <h1 className="text-2xl font-display text-brand-ink">Plan, usage and invoices</h1>
            </div>

            {subscription?.status === "past_due" && (
                <div className="mb-4 rounded-lg border border-red-200 bg-red-50 text-red-900 p-4 flex items-center gap-3" data-testid="billing-past-due-banner">
                    <ShieldAlert className="w-5 h-5" />
                    <div className="flex-1">
                        <div className="font-medium">Your last payment failed.</div>
                        <div className="text-sm">Update your card or complete a fresh checkout — meters are still enforced.</div>
                    </div>
                    <Button size="sm" onClick={() => setUpgradeOpen(true)} className="bg-red-600 text-white hover:bg-red-700">Pay now</Button>
                </div>
            )}

            <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="md:col-span-1 rounded-lg border border-brand-line bg-white p-5" data-testid="billing-current-plan">
                    <div className="text-xs uppercase tracking-widest text-zinc-500">Current plan</div>
                    <div className="mt-2 font-display text-3xl text-brand-ink">{entitlements?.label || "—"}</div>
                    <div className="mt-1 text-sm text-zinc-500 capitalize">Status: {subscription?.status}</div>
                    {subscription?.cancel_at_period_end && (
                        <div className="mt-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1">
                            Cancels {subscription.current_period_end?.slice(0, 10)}. <button onClick={resumeSub} className="underline">Undo</button>
                        </div>
                    )}
                    <div className="mt-4 flex gap-2">
                        <Button onClick={() => setUpgradeOpen(true)} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="billing-change-plan-btn">
                            Change plan <ArrowUpRight className="w-4 h-4 ml-1" />
                        </Button>
                        {!subscription?.cancel_at_period_end && currentPlan !== "free" && (
                            <Button variant="ghost" onClick={cancelSub} data-testid="billing-cancel-btn">Cancel</Button>
                        )}
                    </div>
                </div>
                <div className="md:col-span-2 grid grid-cols-2 gap-3">
                    <Meter meter={usage?.meters?.ai_conversations} label="AI conversations" unit="/mo" />
                    <Meter meter={usage?.meters?.email_sends} label="Email sends" unit="/mo" />
                    <Meter meter={usage?.meters?.voice_minutes} label="Voice minutes" unit="/mo" />
                    <Meter meter={usage?.meters?.contacts} label="Contacts" />
                    <Meter meter={usage?.meters?.users} label="Team seats" />
                    <Meter meter={usage?.meters?.websites} label="Websites" />
                </div>
            </div>

            {/* AI usage & cost — every LLM call is metered and counted against your plan */}
            <div className="mb-6 rounded-lg border border-brand-line bg-white p-5" data-testid="ai-usage-panel">
                <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                        <div className="text-xs uppercase tracking-widest text-zinc-500">AI usage this month</div>
                        <div className="mt-1 text-sm text-zinc-500">
                            Every AI action — website generation, marketing copy, AI employees, chat, translation, logos — is metered.
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="font-display text-2xl text-brand-ink">
                            ${Number(aiUsage?.used_usd || 0).toFixed(2)}
                            <span className="text-sm text-zinc-400 font-sans">
                                {aiUsage?.budget_usd ? ` / $${Number(aiUsage.budget_usd).toFixed(2)}` : " used"}
                            </span>
                        </div>
                        <div className="text-xs text-zinc-500">{aiUsage?.totals?.calls || 0} AI calls · {(aiUsage?.totals?.tokens || 0).toLocaleString()} tokens</div>
                    </div>
                </div>
                {aiUsage?.budget_usd > 0 && (
                    <div className="mt-3">
                        <div className="h-2 rounded-full bg-brand-line overflow-hidden">
                            <div className={`h-full ${aiUsage?.over ? "bg-red-500" : aiUsage?.warn ? "bg-amber-500" : "bg-brand-copper"}`}
                                 style={{ width: `${Math.min(100, aiUsage?.pct || 0)}%` }} />
                        </div>
                        {aiUsage?.over && (
                            <div className="mt-2 text-xs text-red-600 flex items-center gap-1">
                                <ShieldAlert className="w-3 h-3" /> You&apos;ve used your monthly AI allowance — upgrade to keep AI features running.
                            </div>
                        )}
                        {aiUsage?.warn && !aiUsage?.over && (
                            <div className="mt-2 text-xs text-amber-600 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" /> Nearing your monthly AI allowance
                            </div>
                        )}
                    </div>
                )}
                {aiUsage && Object.keys(aiUsage.by_feature || {}).length > 0 && (
                    <div className="mt-4 grid sm:grid-cols-2 gap-2">
                        {Object.entries(aiUsage.by_feature)
                            .sort((a, b) => (b[1]?.cost_usd || 0) - (a[1]?.cost_usd || 0))
                            .slice(0, 8)
                            .map(([feat, v]) => (
                                <div key={feat} className="flex items-center justify-between text-xs border border-brand-line rounded px-3 py-2">
                                    <span className="text-zinc-600 truncate font-mono">{feat.replace(/^\/api\//, "")}</span>
                                    <span className="text-brand-ink font-medium ml-2 whitespace-nowrap">${Number(v.cost_usd || 0).toFixed(4)} · {v.calls}×</span>
                                </div>
                            ))}
                    </div>
                )}

                {/* Owner-set hard monthly AI spend cap */}
                <div className="mt-5 pt-5 border-t border-brand-line" data-testid="ai-spend-cap">
                    <div className="flex items-start justify-between flex-wrap gap-3">
                        <div>
                            <div className="text-sm font-medium text-brand-ink flex items-center gap-2">
                                <ShieldAlert className="w-4 h-4 text-brand-copper" /> Hard monthly AI spend limit
                            </div>
                            <div className="mt-1 text-xs text-zinc-500 max-w-md">
                                Set a dollar ceiling and we&apos;ll block every AI action once you hit it — logos, website copy,
                                AI employees, translation and chat. No surprise bills. Leave at $0 for no personal cap.
                            </div>
                        </div>
                        <div className="text-right">
                            <div className="text-xs uppercase tracking-widest text-zinc-500">Current limit</div>
                            <div className="font-display text-xl text-brand-ink">
                                {aiUsage?.owner_cap_usd > 0 ? `$${Number(aiUsage.owner_cap_usd).toFixed(2)}` : "None"}
                            </div>
                        </div>
                    </div>
                    {aiUsage?.owner_cap_usd > 0 && (
                        <div className="mt-3">
                            <div className="h-2 rounded-full bg-brand-line overflow-hidden">
                                <div className={`h-full ${aiUsage?.owner_cap_over ? "bg-red-500" : (aiUsage?.owner_cap_pct >= 80 ? "bg-amber-500" : "bg-brand-copper")}`}
                                     style={{ width: `${Math.min(100, aiUsage?.owner_cap_pct || 0)}%` }} />
                            </div>
                            <div className="mt-1.5 text-xs text-zinc-500">
                                ${Number(aiUsage?.used_usd || 0).toFixed(2)} used of your ${Number(aiUsage.owner_cap_usd).toFixed(2)} limit
                                {aiUsage?.owner_cap_over && <span className="text-red-600 font-medium"> — limit reached; AI is paused until you raise it.</span>}
                            </div>
                        </div>
                    )}
                    <div className="mt-3 flex items-center gap-2 flex-wrap">
                        <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm">$</span>
                            <input
                                type="number" min="0" step="1"
                                value={capInput}
                                onChange={(e) => setCapInput(e.target.value)}
                                placeholder={aiUsage?.owner_cap_usd > 0 ? String(aiUsage.owner_cap_usd) : "e.g. 25"}
                                data-testid="ai-cap-input"
                                className="w-36 pl-6 pr-3 py-2 text-sm rounded-lg border border-brand-line bg-white text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-copper/30" />
                        </div>
                        <span className="text-xs text-zinc-400">/ month</span>
                        <Button size="sm" disabled={capBusy || capInput === ""} onClick={() => saveCap(capInput)}
                                className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="ai-cap-save">
                            Set limit
                        </Button>
                        {aiUsage?.owner_cap_usd > 0 && (
                            <Button size="sm" variant="outline" disabled={capBusy} onClick={() => saveCap(0)}
                                    className="border-brand-line" data-testid="ai-cap-remove">
                                Remove limit
                            </Button>
                        )}
                    </div>
                </div>
            </div>

            <div className="mb-6">
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Invoices</div>
                <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                    <Table>
                        <TableHeader><TableRow>
                            <TableHead>Number</TableHead>
                            <TableHead>Plan</TableHead>
                            <TableHead>Period</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                            <TableHead>Status</TableHead>
                        </TableRow></TableHeader>
                        <TableBody>
                            {invoices.map((i) => (
                                <TableRow key={i.id} data-testid={`billing-inv-${i.id}`}>
                                    <TableCell className="font-mono text-xs">{i.number}</TableCell>
                                    <TableCell className="capitalize">{i.plan_code}</TableCell>
                                    <TableCell className="text-xs text-zinc-500">
                                        {i.period_start?.slice(0, 10)} → {i.period_end?.slice(0, 10)}
                                    </TableCell>
                                    <TableCell className="text-right font-mono">{money(i.total_cents)}</TableCell>
                                    <TableCell><Badge variant="outline" className="capitalize">{i.status}</Badge></TableCell>
                                </TableRow>
                            ))}
                            {!invoices.length && (
                                <TableRow><TableCell colSpan={5} className="text-center py-8 text-zinc-500" data-testid="billing-inv-empty">No invoices yet.</TableCell></TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
            </div>

            <div className="text-xs text-zinc-400 border-t border-brand-line pt-3">
                Payments run through the <span className="font-medium">simulated provider</span>. Stripe is a ready adapter — add STRIPE_SECRET_KEY to switch over.
                {" "}
                <button onClick={triggerDunning} className="underline hover:text-zinc-600" data-testid="billing-simulate-dunning-btn">Simulate a failed payment</button>
            </div>

            <Dialog open={upgradeOpen} onOpenChange={setUpgradeOpen}>
                <DialogContent className="max-w-3xl" data-testid="billing-upgrade-modal">
                    <DialogHeader><DialogTitle>Change plan</DialogTitle></DialogHeader>
                    <div className="grid md:grid-cols-5 gap-3">
                        {plans.map((p) => (
                            <button
                                key={p.code}
                                onClick={() => setTarget(p.code)}
                                data-testid={`billing-upgrade-plan-${p.code}`}
                                className={`text-left rounded-lg border p-3 transition-all ${
                                    target === p.code ? "border-brand-copper ring-2 ring-brand-copper/30" :
                                    currentPlan === p.code ? "border-brand-ink bg-brand-cream" :
                                    "border-brand-line hover:border-brand-copper"
                                }`}
                            >
                                <div className="text-xs uppercase tracking-widest text-zinc-500">{p.code === currentPlan ? "Current" : ""}</div>
                                <div className="font-display text-lg text-brand-ink">{p.name}</div>
                                <div className="mt-1 font-mono text-sm">{interval === "annual" && p.annual_price_usd ? <>${Math.round(p.annual_price_usd / 12)}/mo <span className="text-[10px] text-zinc-500">billed ${p.annual_price_usd}/yr</span></> : <>${p.price_usd}/mo</>}</div>
                                <div className="mt-2 text-[11px] text-zinc-500 line-clamp-3">{p.tagline}</div>
                            </button>
                        ))}
                    </div>
                    <div className="grid md:grid-cols-2 gap-3 mt-3">
                        <div>
                            <Label className="text-xs">Billing interval</Label>
                            <div className="mt-1 inline-flex rounded-lg border border-brand-line p-0.5" data-testid="billing-interval">
                                {["monthly", "annual"].map((iv) => <button key={iv} type="button" onClick={() => setInterval_(iv)} data-testid={`billing-interval-${iv}`} className={`px-3 py-1.5 text-xs rounded-md capitalize ${interval === iv ? "bg-brand-copper text-white" : "text-zinc-500"}`}>{iv}{iv === "annual" ? " · 2 months free" : ""}</button>)}
                            </div>
                        </div>
                        <div>
                            <Label className="text-xs">Coupon code (optional)</Label>
                            <Input value={coupon} onChange={(e) => setCoupon(e.target.value.toUpperCase())} placeholder="e.g. LAUNCH20" data-testid="billing-coupon-input" />
                            <div className="mt-1 text-[11px] text-zinc-500">Try LAUNCH20 — 20% off first month.</div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setUpgradeOpen(false)}>Close</Button>
                        <Button
                            disabled={!target || target === currentPlan || busy}
                            onClick={() => startCheckout(target)}
                            className="bg-brand-copper text-white hover:bg-brand-copperHover"
                            data-testid="billing-upgrade-confirm-btn"
                        >
                            {target === currentPlan ? "Already on this plan" : `Continue to checkout${target ? ` (${target})` : ""}`}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
