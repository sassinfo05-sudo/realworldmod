"""Round 15 — staff security regression:
  * no temporary passwords: member creation issues a hashed, single-use, 48h set-password invitation
  * invitation acceptance is atomic (same token cannot set a password twice)
  * credential change invalidates existing staff sessions
  * MFA challenge consumption is atomic single-use (concurrent verifies → exactly one success)
Runs against the live preview backend (dev mode: staff MFA skipped so a bearer token is issued directly).
"""
from __future__ import annotations

import asyncio
import os
import secrets
import time
import uuid

import pytest
import requests

import _creds

API = _creds.api()
_F = {"email": _creds.FOUNDER_EMAIL, "password": _creds.FOUNDER_PASSWORD}


def _reset_staff_limiter():
    """The distributed limiter (Mongo) persists across test runs — clear the staff buckets so this
    deterministic test isn't tripped by its own earlier runs (10 logins / 5 min per IP)."""
    from pymongo import MongoClient
    MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]].rate_limits.delete_many({"_id": {"$regex": "^staff_"}})


# Each test uses its own synthetic client IP (the limiter keys on X-Forwarded-For behind the proxy),
# so the in-process + distributed limiters never bleed between tests / repeated runs.
_IP = f"10.99.{secrets.randbelow(250)}.{secrets.randbelow(250)}"


def _staff_login(email, password, ip=None):
    r = requests.post(f"{API}/staff/auth/login", json={"email": email, "password": password},
                      headers={"X-Forwarded-For": ip or _IP}, timeout=30)
    return r


@pytest.fixture(scope="module")
def founder_token():
    _reset_staff_limiter()
    r = _staff_login(_F["email"], _F["password"])
    assert r.status_code == 200, r.text
    tok = r.json().get("access_token")
    assert tok, "dev staff login should issue a bearer token"
    return tok


def _h(tok):
    return {"Authorization": f"Bearer {tok}", "X-Forwarded-For": _IP}


def _accept_invite(token, password):
    return requests.post(f"{API}/staff/auth/accept-invite", json={"token": token, "password": password},
                         headers={"X-Forwarded-For": _IP}, timeout=30)


def test_member_create_issues_invitation_not_temp_password(founder_token):
    email = f"invitee-{uuid.uuid4().hex[:8]}@example.com"
    r = requests.post(f"{API}/staff/members", headers=_h(founder_token),
                      json={"email": email, "full_name": "Invite Test", "role": "support"}, timeout=30)
    assert r.status_code in (200, 201), r.text
    body = r.json()
    assert "temporary_password" not in body
    assert body.get("invite_pending") is True
    # dev/test only: link is returned since no real email provider is connected
    link = body.get("invite_link")
    assert link and "/staff/set-password?token=" in link
    token = link.split("token=", 1)[1]

    # Invalid token → generic 400
    bad = _accept_invite("x" * 40, "Str0ngPassw0rd!!")
    assert bad.status_code == 400

    # Weak password → 422 (validation), token NOT consumed
    weak = _accept_invite(token, "short")
    assert weak.status_code == 422

    # Two concurrent accepts with the same token → exactly one succeeds
    import concurrent.futures as cf
    def _accept(pw):
        return _accept_invite(token, pw).status_code
    with cf.ThreadPoolExecutor(max_workers=2) as ex:
        codes = list(ex.map(_accept, ["Str0ngPassw0rd!!A", "Str0ngPassw0rd!!B"]))
    assert sorted(codes) == [200, 400], codes

    # Replay after consumption → 400
    again = _accept_invite(token, "Str0ngPassw0rd!!C")
    assert again.status_code == 400

    # Exactly one of the two passwords works
    _reset_staff_limiter()
    ok = [pw for pw in ("Str0ngPassw0rd!!A", "Str0ngPassw0rd!!B") if _staff_login(email, pw).status_code == 200]
    assert len(ok) == 1
    new_pw = ok[0]

    # Member no longer invite_pending
    lst = requests.get(f"{API}/staff/members", headers=_h(founder_token), timeout=30).json()
    me = next(m for m in lst if m["email"] == email)
    assert me["invite_pending"] is False
    mid = me["id"]

    # Session invalidation: token issued now, then password change via admin → old token rejected
    _reset_staff_limiter()
    tok = _staff_login(email, new_pw).json()["access_token"]
    assert requests.get(f"{API}/staff/me", headers=_h(tok), timeout=30).status_code == 200
    time.sleep(1.1)  # iat is second-granular
    pr = requests.patch(f"{API}/staff/members/{mid}", headers=_h(founder_token),
                        json={"new_password": "An0therStr0ngPass!!"}, timeout=30)
    assert pr.status_code == 200, pr.text
    assert requests.get(f"{API}/staff/me", headers=_h(tok), timeout=30).status_code == 401
    _reset_staff_limiter()
    assert _staff_login(email, new_pw).status_code == 401
    assert _staff_login(email, "An0therStr0ngPass!!").status_code == 200

    # Re-invite issues a fresh link
    ri = requests.post(f"{API}/staff/members/{mid}/reinvite", headers=_h(founder_token), timeout=30)
    assert ri.status_code == 200 and "invite_link" in ri.json()

    # cleanup
    requests.delete(f"{API}/staff/members/{mid}", headers=_h(founder_token), timeout=30)


def test_staff_login_is_rate_limited_distributed():
    """11th bad attempt in the window → 429 from the Mongo-backed limiter (survives worker restarts)."""
    ip = f"10.98.{secrets.randbelow(250)}.{secrets.randbelow(250)}"
    codes = [_staff_login("nobody@example.com", "wrong-password-!!", ip=ip).status_code for _ in range(11)]
    assert codes[:10] == [401] * 10, codes
    assert codes[10] == 429, codes
    _reset_staff_limiter()


def test_mfa_challenge_consumption_is_atomic():
    """Insert a real challenge and verify it concurrently: exactly ONE verify may succeed."""
    from bson import ObjectId
    from app.db import get_db
    from app.services import twofa

    code = "123456"
    doc = {
        "subject_id": str(ObjectId()), "kind": "staff", "email": "x@example.com",
        "code_hash": twofa._hash_code(code), "attempts": 0, "consumed": False,
        "expires_at": (twofa._now() + twofa.timedelta(minutes=5)).isoformat().replace("+00:00", "Z"),
        "created_at": "now",
    }

    async def run():
        db = get_db()
        r = await db.mfa_challenges.insert_one(doc)
        cid = str(r.inserted_id)

        async def one():
            try:
                await twofa.verify_challenge(cid, code, "staff")
                return "ok"
            except Exception as e:  # noqa: BLE001
                return getattr(e, "status_code", "err")

        results = await asyncio.gather(*[one() for _ in range(8)])
        await db.mfa_challenges.delete_one({"_id": r.inserted_id})
        return results

    import app.db as _appdb
    _appdb._mongo_client = None  # bind a fresh motor client to THIS loop
    loop = asyncio.new_event_loop()
    try:
        results = loop.run_until_complete(run())
    finally:
        loop.close()
    assert results.count("ok") == 1, results
    assert all(x in ("ok", 400) for x in results), results


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
