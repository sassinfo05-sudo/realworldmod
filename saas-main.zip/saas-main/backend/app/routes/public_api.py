"""Public API — scoped-key authenticated endpoints. The Zapier / Make / n8n path."""
from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, Query, Request
from pydantic import BaseModel

from ..db import get_db, utc_now_iso
from ..services.webhooks import resolve_api_key, dispatch_event

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/public/v1", tags=["public-api"])


# ---------- Contacts ----------

@router.get("/contacts")
async def list_contacts(request: Request, limit: int = Query(50, ge=1, le=200)):
    key = await resolve_api_key(request, required_scope="contacts:read")
    db = get_db()
    out = []
    async for c in db.contacts.find({"org_id": key["org_id"]}).sort("created_at", -1).limit(limit):
        out.append({"id": str(c["_id"]), "display_name": c.get("display_name"),
                     "emails": c.get("emails") or [], "phones": c.get("phones") or [],
                     "tags": c.get("tags") or [], "created_at": c.get("created_at")})
    return {"contacts": out}


class ContactCreate(BaseModel):
    display_name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    tags: List[str] = []


@router.post("/contacts")
async def create_contact(req: ContactCreate, request: Request):
    key = await resolve_api_key(request, required_scope="contacts:write")
    db = get_db()
    doc = {"org_id": key["org_id"], "display_name": req.display_name,
             "emails": [req.email] if req.email else [],
             "phones": [req.phone] if req.phone else [],
             "tags": req.tags, "source": "public_api",
             "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
             "last_activity_at": utc_now_iso()}
    r = await db.contacts.insert_one(doc)
    cid = str(r.inserted_id)
    await dispatch_event(key["org_id"], "contact.created",
                            {"id": cid, "display_name": req.display_name,
                             "email": req.email, "phone": req.phone})
    return {"id": cid}


# ---------- Bookings ----------

@router.get("/bookings")
async def list_bookings(request: Request, limit: int = Query(50, ge=1, le=200)):
    key = await resolve_api_key(request, required_scope="bookings:read")
    db = get_db()
    out = []
    async for b in db.bookings.find({"org_id": key["org_id"]}).sort("start_at", -1).limit(limit):
        out.append({"id": str(b["_id"]), "booking_number": b.get("booking_number"),
                     "status": b.get("status"), "start_at": b.get("start_at"),
                     "end_at": b.get("end_at"),
                     "customer_email": b.get("customer_email"),
                     "customer_name": b.get("customer_name")})
    return {"bookings": out}


class BookingCreate(BaseModel):
    service_id: str
    start_at: str
    name: str
    email: str
    phone: Optional[str] = None
    staff_id: Optional[str] = None
    customer_notes: Optional[str] = None


@router.post("/bookings")
async def create_booking_via_api(req: BookingCreate, request: Request):
    """Server-side create with the same availability + past-date guards as the public site.
    Respects the caller's key scope + the org's plan entitlements."""
    key = await resolve_api_key(request, required_scope="bookings:write")
    org_id = key["org_id"]
    # Reuse the internal booking helper so validation stays in one place.
    from .bookings import _create_booking, BookingCreate as _InternalBookingCreate
    inner = _InternalBookingCreate(
        service_id=req.service_id, start_at=req.start_at, staff_id=req.staff_id,
        name=req.name, email=req.email, phone=req.phone,
        customer_notes=req.customer_notes,
    )
    db = get_db()
    result = await _create_booking(db, org_id, inner, source="public")
    await dispatch_event(org_id, "booking.created",
                            {"id": result.get("id"),
                             "booking_number": result.get("booking_number"),
                             "start_at": result.get("start_at"),
                             "customer_email": result.get("customer_email")})
    return result


# ---------- Invoices ----------

@router.get("/invoices")
async def list_invoices(request: Request, limit: int = Query(50, ge=1, le=200)):
    key = await resolve_api_key(request, required_scope="invoices:read")
    db = get_db()
    out = []
    async for i in db.invoices.find({"org_id": key["org_id"]}).sort("created_at", -1).limit(limit):
        out.append({"id": str(i["_id"]), "number": i.get("number"),
                     "status": i.get("status"),
                     "total_cents": i.get("total_cents"),
                     "amount_paid_cents": i.get("amount_paid_cents", 0),
                     "due_at": i.get("due_at")})
    return {"invoices": out}


# ---------- Quotes (read-only for now) ----------

@router.get("/quotes")
async def list_quotes(request: Request, limit: int = Query(50, ge=1, le=200)):
    key = await resolve_api_key(request, required_scope="quotes:read")
    db = get_db()
    out = []
    async for q in db.quotes.find({"org_id": key["org_id"]}).sort("created_at", -1).limit(limit):
        out.append({"id": str(q["_id"]), "number": q.get("number"),
                     "status": q.get("status"),
                     "total_cents": (q.get("totals") or {}).get("total_cents", 0)})
    return {"quotes": out}


# ---------- Meta / echo ----------

@router.get("/whoami")
async def whoami(request: Request):
    key = await resolve_api_key(request)
    return {"org_id": key["org_id"], "prefix": key.get("prefix"),
             "scopes": key.get("scopes") or []}
