import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Copy, Globe2, RefreshCw, Trash2, CheckCircle2, Loader2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

const STATE_COPY = {
    pending: { label: "Pending DNS", icon: Loader2, color: "text-amber-600 bg-amber-50 border-amber-200",
               hint: "Add the DNS records below at your registrar. We'll check every few seconds." },
    verifying: { label: "Verifying", icon: Loader2, color: "text-brand-copper bg-brand-cream border-brand-copper/30",
                 hint: "DNS is propagating. Grab a coffee — this usually takes 5-20 minutes." },
    connected: { label: "Connected", icon: CheckCircle2, color: "text-emerald-700 bg-emerald-50 border-emerald-200",
                 hint: "Your domain is live and issuing HTTPS certificates automatically." },
    error: { label: "Error", icon: AlertTriangle, color: "text-red-700 bg-red-50 border-red-200",
             hint: "" },
};

/** Point this domain at a specific site + landing page (e.g. book.acme.com → Site B /booking). */
function DomainBinding({ domain }) {
    const [sites, setSites] = useState([]);
    const [siteId, setSiteId] = useState(domain.website_id || "");
    const [landing, setLanding] = useState(domain.landing_page_slug || "");
    const [pages, setPages] = useState([]);
    useEffect(() => { api.get("/sites").then((r) => setSites(r.data.sites || [])).catch(() => {}); }, []);
    useEffect(() => {
        if (!siteId) return;
        api.get("/editor/website").then((r) => { if (r.data.website?.id === siteId) setPages(r.data.website.pages || []); else setPages([]); }).catch(() => setPages([]));
    }, [siteId]);
    async function save() {
        try { await api.put(`/sites/domains/${domain.id}/binding`, { website_id: siteId || null, landing_page_slug: landing || null }); toast.success("Domain routing saved"); }
        catch (e) { toast.error(e?.response?.data?.detail || "Could not save"); }
    }
    if (sites.length === 0) return null;
    return (
        <div className="flex flex-wrap items-center gap-2 text-xs border-b border-brand-line pb-3" data-testid={`domain-binding-${domain.hostname}`}>
            <span className="text-zinc-500">Routes to</span>
            <select value={siteId} onChange={(e) => setSiteId(e.target.value)} className="h-8 rounded-md border border-brand-line bg-white px-2 text-xs">
                {sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <span className="text-zinc-500">landing on</span>
            <input list={`pages-${domain.id}`} value={landing} onChange={(e) => setLanding(e.target.value)} placeholder="home (default)" className="h-8 w-36 rounded-md border border-brand-line px-2 text-xs" />
            <datalist id={`pages-${domain.id}`}>{pages.map((p) => <option key={p.slug} value={p.slug}>{p.title}</option>)}</datalist>
            <Button size="sm" variant="outline" onClick={save} data-testid={`domain-binding-save-${domain.hostname}`}>Save routing</Button>
        </div>
    );
}

function DomainCard({ domain, onRefresh, onDelete, onSetPrimary }) {
    const s = STATE_COPY[domain.state] || STATE_COPY.pending;
    const Icon = s.icon;
    return (
        <div className="rounded-xl border border-brand-line bg-white p-5 space-y-3" data-testid={`domain-card-${domain.hostname}`}>
            <DomainBinding domain={domain} />
            <div className="flex items-start justify-between gap-4">
                <div>
                    <div className="flex items-center gap-2">
                        <Globe2 className="w-4 h-4 text-brand-copper" />
                        <span className="font-mono text-brand-ink">{domain.hostname}</span>
                        {domain.primary && (
                            <span className="text-[10px] uppercase tracking-widest text-brand-copper bg-brand-cream rounded-full px-2 py-0.5">Primary</span>
                        )}
                    </div>
                    <div className="text-xs text-zinc-500 mt-0.5">
                        via {domain.provider} · SSL: {domain.ssl_status}
                    </div>
                </div>
                <div className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${s.color}`}>
                    <Icon className={`w-3.5 h-3.5 ${domain.state === "pending" || domain.state === "verifying" ? "animate-spin" : ""}`} />
                    {s.label}
                </div>
            </div>
            <div className="text-xs text-zinc-500">{domain.error_detail || s.hint}</div>
            {domain.error_hint && <div className="text-xs text-red-600">Hint: {domain.error_hint}</div>}

            {domain.dns_records?.length > 0 && domain.state !== "connected" && (
                <div className="border-t border-brand-line pt-3 space-y-2">
                    <div className="text-xs uppercase tracking-widest text-zinc-500">DNS records to add</div>
                    {domain.dns_records.map((r, i) => (
                        <div key={i} className="rounded-md bg-zinc-50 border border-brand-line p-3 grid grid-cols-[70px_1fr_auto] items-start gap-2 text-xs font-mono">
                            <div className="uppercase text-zinc-500">{r.type}</div>
                            <div>
                                <div className="text-brand-ink break-all">{r.name}</div>
                                <div className="text-zinc-600 break-all">{r.value}</div>
                                {r.note && <div className="mt-1 text-zinc-500 font-sans not-italic">{r.note}</div>}
                            </div>
                            <button
                                className="text-zinc-500 hover:text-brand-ink"
                                onClick={() => { navigator.clipboard.writeText(r.value); toast.success("Copied"); }}
                                data-testid={`domain-copy-${i}`}
                            >
                                <Copy className="w-3.5 h-3.5" />
                            </button>
                        </div>
                    ))}
                </div>
            )}

            <div className="flex gap-2 pt-2">
                <Button size="sm" variant="outline" onClick={() => onRefresh(domain.id)} data-testid={`domain-refresh-${domain.hostname}`}>
                    <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Check status
                </Button>
                {!domain.primary && domain.state === "connected" && (
                    <Button size="sm" variant="ghost" onClick={() => onSetPrimary(domain.id)}>Set as primary</Button>
                )}
                <Button size="sm" variant="ghost" className="text-red-600 ml-auto" onClick={() => onDelete(domain.id)}>
                    <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Remove
                </Button>
            </div>
        </div>
    );
}

export default function Domains() {
    const [providers, setProviders] = useState([]);
    const [domains, setDomains] = useState([]);
    const [website, setWebsite] = useState(null);
    const [open, setOpen] = useState(false);
    const [hostname, setHostname] = useState("");
    const [provider, setProvider] = useState("simulated");
    const [busy, setBusy] = useState(false);

    async function reload() {
        try {
            const [p, d, w] = await Promise.all([
                api.get("/domains/providers"),
                api.get("/domains"),
                api.get("/editor/website").catch(() => ({ data: { website: null } })),
            ]);
            setProviders(p.data.providers);
            setDomains(d.data.domains);
            setWebsite(w.data.website);
        } catch (e) { /* noop */ }
    }

    useEffect(() => { reload(); }, []);

    // Poll every 4s for domains in transient states
    useEffect(() => {
        const inTransition = domains.some((d) => d.state === "pending" || d.state === "verifying");
        if (!inTransition) return;
        const iv = setInterval(async () => {
            const updates = await Promise.all(domains.map((d) =>
                (d.state === "pending" || d.state === "verifying")
                    ? api.get(`/domains/${d.id}/status`).then((r) => r.data).catch(() => d)
                    : Promise.resolve(d)
            ));
            setDomains(updates);
        }, 4000);
        return () => clearInterval(iv);
    }, [domains]);

    async function onCreate() {
        if (!hostname.trim() || !website?.id) return;
        setBusy(true);
        try {
            await api.post("/domains", { hostname: hostname.trim(), website_id: website.id, provider });
            toast.success("Domain added — follow the DNS instructions.");
            setHostname("");
            setOpen(false);
            await reload();
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Could not add domain");
        } finally {
            setBusy(false);
        }
    }

    async function onRefresh(id) {
        try {
            const { data } = await api.get(`/domains/${id}/status`);
            setDomains((cur) => cur.map((d) => (d.id === id ? data : d)));
        } catch (e) { toast.error("Could not fetch status"); }
    }
    async function onDelete(id) {
        if (!window.confirm("Remove this domain? Traffic will stop resolving to your site.")) return;
        await api.delete(`/domains/${id}`);
        await reload();
    }
    async function onSetPrimary(id) {
        await api.patch(`/domains/${id}`, { primary: true });
        await reload();
    }

    return (
        <div className="p-6 md:p-10 max-w-4xl" data-testid="domains-page">
            <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Custom domains</div>
            <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium">Connect a domain you own.</h1>
            <p className="mt-3 text-zinc-600">
                Point your domain at your site. We handle SSL and renewal.
                {!website?.slug && " Publish your site first — then come back here."}
            </p>

            <div className="mt-6 grid md:grid-cols-2 gap-3" data-testid="domain-providers">
                {providers.map((p) => (
                    <div key={p.key} className={`rounded-xl border p-4 ${p.is_connected ? "bg-white border-brand-line" : "bg-zinc-50 border-brand-line"}`}
                         data-testid={`provider-${p.key}`}>
                        <div className="flex items-center justify-between">
                            <div className="font-medium">{p.label}</div>
                            <span className={`text-[10px] uppercase tracking-widest rounded-full px-2 py-0.5 ${
                                p.is_connected ? "bg-emerald-100 text-emerald-800" : "bg-zinc-200 text-zinc-700"
                            }`}>{p.is_connected ? "Connected" : "Not connected"}</span>
                        </div>
                        <p className="mt-2 text-xs text-zinc-600">{p.honest_status}</p>
                    </div>
                ))}
            </div>

            <div className="mt-8 flex items-center justify-between">
                <h2 className="font-display text-xl text-brand-ink">Your domains</h2>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={!website?.slug}
                                data-testid="domain-add-btn">
                            Add a domain
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>Attach a custom domain</DialogTitle></DialogHeader>
                        <div className="space-y-3">
                            <div>
                                <Label>Hostname</Label>
                                <Input value={hostname} onChange={(e) => setHostname(e.target.value)}
                                       placeholder="www.mybusiness.com" className="mt-1"
                                       data-testid="domain-hostname-input" />
                                <div className="text-xs text-zinc-500 mt-1">Both apex (mybusiness.com) and www subdomains supported.</div>
                            </div>
                            <div>
                                <Label>Provider</Label>
                                <select value={provider} onChange={(e) => setProvider(e.target.value)}
                                        className="mt-1 w-full border border-brand-line rounded-md px-3 py-2 text-sm"
                                        data-testid="domain-provider-select">
                                    {providers.map((p) => (
                                        <option key={p.key} value={p.key} disabled={!p.is_connected}>
                                            {p.label} {!p.is_connected ? "(not connected)" : ""}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
                            <Button className="bg-brand-copper hover:bg-brand-copperHover text-white"
                                    onClick={onCreate} disabled={busy}
                                    data-testid="domain-add-submit">
                                {busy ? "Adding…" : "Add domain"}
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>

            <div className="mt-4 space-y-3" data-testid="domains-list">
                {domains.length === 0 && (
                    <div className="rounded-lg border border-dashed border-brand-line p-6 text-center text-sm text-zinc-500">
                        No domains connected yet.
                    </div>
                )}
                {domains.map((d) => (
                    <DomainCard key={d.id} domain={d} onRefresh={onRefresh}
                                onDelete={onDelete} onSetPrimary={onSetPrimary} />
                ))}
            </div>
        </div>
    );
}
