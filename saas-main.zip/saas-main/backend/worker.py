"""Dedicated background worker — runs the recurring jobs OUT of the web process.

Run in production as a separate process/deployment:
    cd /app/backend && RUN_SCHEDULERS=true python worker.py

It owns the scheduler leader lock, so even if several worker replicas run, only the leader
fires jobs. The web deployment runs with RUN_SCHEDULERS=false and never starts these loops.

Jobs: scheduled email send, workflow scheduler, abandoned-cart sweep, subscription renewal.
Each job is individually idempotent + restart-safe.
"""
from __future__ import annotations

import asyncio
import logging
import os

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except Exception:  # noqa: BLE001
    pass

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("worker")


async def main() -> None:
    from app.services import leader_lock
    from app.routes import inbox as inbox_routes
    from app.routes import store as store_routes
    from app.routes import subscriptions as subscription_routes
    from app.services import workflows as wfs

    # Become leader (retry until we win, so a starting worker waits for a dying one to lapse).
    while not await leader_lock.acquire("schedulers"):
        logger.info("Another scheduler leader is active — waiting to take over…")
        await asyncio.sleep(30)

    asyncio.create_task(leader_lock.maintain("schedulers"))
    inbox_routes.start_scheduled_send_loop()
    asyncio.create_task(wfs.scheduler_loop())
    store_routes.start_abandoned_sweep_loop()
    subscription_routes.start_renewal_loop()
    from app.services import webhooks as wh
    asyncio.create_task(wh.retry_loop())
    logger.info("Worker started recurring schedulers (leader=%s)", leader_lock.INSTANCE_ID)

    # Keep the process alive.
    while True:
        await asyncio.sleep(3600)


if __name__ == "__main__":
    asyncio.run(main())
