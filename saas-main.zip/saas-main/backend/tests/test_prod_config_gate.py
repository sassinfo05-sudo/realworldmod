"""Deterministic proof that the production config gate fails closed.

Runs server._validate_production_config() in subprocesses under different APP_ENV/config so we
never disturb the live dev server. Proves a misconfigured production deploy CANNOT start.

Run: cd /app/backend && python tests/test_prod_config_gate.py
"""
import subprocess
import sys
import os

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SNIPPET = (
    "import server; "
    "server._validate_production_config(); "
    "print('VALIDATION_OK')"
)


def _run(env_extra):
    env = dict(os.environ)
    env.update(env_extra)
    p = subprocess.run([sys.executable, "-c", SNIPPET], cwd=BACKEND, env=env,
                       capture_output=True, text=True, timeout=90)
    return p.returncode, (p.stdout + p.stderr)


def main():
    # 1. Bad prod config (wildcard CORS, no enc key, weak secret, seeding on) → must FAIL startup.
    rc, out = _run({
        "APP_ENV": "production", "CORS_ORIGINS": "*", "SECRETS_ENC_KEY": "",
        "JWT_SECRET": "short", "SEED_DEMO_DATA": "true", "MONGO_URL": "mongodb://localhost:27017",
        "DB_NAME": "zanelvo_db",
    })
    bad_failed = ("Production configuration incomplete" in out) and ("VALIDATION_OK" not in out)
    print(f"[BAD PROD CONFIG]  failed_closed={bad_failed}")
    assert bad_failed, f"expected prod validation to raise; got rc={rc}\n{out[-500:]}"

    # 2. Good prod config → must PASS validation.
    rc, out = _run({
        "APP_ENV": "production",
        "CORS_ORIGINS": "https://app.zanelvo.com,https://zanelvo.com",
        "SECRETS_ENC_KEY": "x" * 40,
        "JWT_SECRET": "y" * 48,
        "SEED_DEMO_DATA": "false",
        "MONGO_URL": "mongodb://localhost:27017", "DB_NAME": "zanelvo_db",
    })
    good_ok = "VALIDATION_OK" in out
    print(f"[GOOD PROD CONFIG] validation_ok={good_ok}")
    assert good_ok, f"expected prod validation to pass; got rc={rc}\n{out[-500:]}"

    print("PRODUCTION CONFIG GATE ASSERTIONS PASSED")


if __name__ == "__main__":
    main()
