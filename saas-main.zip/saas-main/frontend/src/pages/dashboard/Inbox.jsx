import InsightsDashboard from "@/components/InsightsDashboard";
import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
    Sparkles, Send, Clock, Bell, BellOff, Reply, Loader2, CheckCircle2, MessageCircle, Users,
} from "lucide-react";
import { toast } from "sonner";

function ConversationRow({ conv, active, onClick }) {
    const channelColor = { email: "bg-blue-50 text-blue-700", chat: "bg-emerald-50 text-emerald-700", form: "bg-amber-50 text-amber-700" }[conv.channel] || "bg-zinc-50";
    return (
        <button onClick={onClick} data-testid={`conv-row-${conv.id}`}
                className={`w-full text-left p-3 border-b border-brand-line hover:bg-brand-cream/40 transition-colors ${active ? "bg-brand-cream" : ""} ${conv.unread ? "font-medium" : ""}`}>
            <div className="flex items-center justify-between">
                <div className="text-sm truncate max-w-[220px]">{conv.subject}</div>
                <span className={`text-[9px] uppercase tracking-widest px-1.5 py-0.5 rounded ${channelColor}`}>{conv.channel}</span>
            </div>
            <div className="text-xs text-zinc-500 mt-1 truncate max-w-[280px]">{conv.last_message_preview}</div>
            {conv.status === "snoozed" && (
                <div className="text-[10px] text-brand-copper mt-1">Snoozed</div>
            )}
        </button>
    );
}

function Message({ m }) {
    const isOutbound = m.direction === "outbound";
    const isInternal = m.channel === "internal";
    const bg = isInternal ? "bg-amber-50 border-amber-200"
        : isOutbound ? "bg-brand-cream border-brand-line"
        : "bg-white border-brand-line";
    return (
        <div className={`rounded-lg border ${bg} p-4`} data-testid={`msg-${m.id}`}>
            <div className="flex items-center justify-between mb-2">
                <div className="text-xs text-zinc-500">
                    <span className="font-medium text-zinc-700">
                        {m.from_addr?.name || m.from_addr?.email || "—"}
                    </span>
                    {" · "}
                    <span className="uppercase tracking-widest text-[10px]">{isInternal ? "internal note" : m.direction}</span>
                    {m.delivery?.simulated && <Badge variant="outline" className="ml-2 text-[9px]">simulated</Badge>}
                </div>
                <span className="text-[10px] text-zinc-400 font-mono">{m.sent_at || m.created_at}</span>
            </div>
            {m.subject && !isOutbound && <div className="text-sm font-medium mb-1">{m.subject}</div>}
            <div className="text-sm whitespace-pre-wrap">{m.body_text || (m.body_html || "").replace(/<[^>]+>/g,"")}</div>
            {(m.ai_labels && m.ai_labels.intent) && (
                <div className="mt-2 flex gap-1 flex-wrap" data-testid={`msg-labels-${m.id}`}>
                    <Badge variant="secondary" className="text-[10px]">intent: {m.ai_labels.intent}</Badge>
                    <Badge variant="secondary" className="text-[10px]">urgency: {m.ai_labels.urgency}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{Math.round((m.ai_labels.confidence||0) * 100)}% confidence</Badge>
                </div>
            )}
        </div>
    );
}

function InboxBase() {
    const navigate = useNavigate();
    const { convId } = useParams();
    const [conversations, setConversations] = useState([]);
    const [filter, setFilter] = useState({ status: "open", channel: null, unread: null });
    const [selected, setSelected] = useState(null); // { conversation, messages, scheduled }
    const [busy, setBusy] = useState(false);
    const [aiSummary, setAiSummary] = useState(null);
    const [aiDraft, setAiDraft] = useState(null);
    const [aiLoading, setAiLoading] = useState(false);
    const [reply, setReply] = useState({ subject: "", body: "", to: "", schedule: "" });
    const [othersViewing, setOthersViewing] = useState([]);

    async function loadList() {
        const params = new URLSearchParams();
        if (filter.status) params.set("status", filter.status);
        if (filter.channel) params.set("channel", filter.channel);
        if (filter.unread) params.set("unread", "true");
        const { data } = await api.get(`/inbox/conversations?${params}`);
        setConversations(data.conversations || []);
        return data.conversations || [];
    }

    async function loadConversation(id) {
        const { data } = await api.get(`/inbox/conversations/${id}`);
        setSelected(data);
        setAiSummary(null); setAiDraft(null);
        // prefill reply
        const inbound = (data.messages || []).find((m) => m.direction === "inbound");
        setReply({
            subject: `Re: ${data.conversation.subject}`,
            body: "",
            to: inbound?.from_addr?.email || "",
            schedule: "",
        });
        // presence ping every 15s
    }

    useEffect(() => { loadList().then((list) => { if (convId) loadConversation(convId); else if (list[0]) navigate(`/app/inbox/${list[0].id}`); }); /* eslint-disable-next-line */ }, [filter]);
    useEffect(() => { if (convId) loadConversation(convId); /* eslint-disable-next-line */ }, [convId]);

    // Presence heartbeat
    useEffect(() => {
        if (!convId) return;
        let cancelled = false;
        async function ping() {
            try {
                const { data } = await api.post(`/inbox/conversations/${convId}/presence`, { action: "viewing" });
                if (!cancelled) setOthersViewing(data.others_viewing || []);
            } catch {}
        }
        ping();
        const t = setInterval(ping, 15000);
        return () => { cancelled = true; clearInterval(t); };
    }, [convId]);

    async function runSummarize() {
        setAiLoading(true);
        try {
            const { data } = await api.post(`/inbox/conversations/${convId}/ai/summarize`);
            setAiSummary(data);
        } catch { toast.error("AI summarize failed"); } finally { setAiLoading(false); }
    }

    async function runDraft() {
        setAiLoading(true);
        try {
            const { data } = await api.post(`/inbox/conversations/${convId}/ai/draft-reply`, {});
            setAiDraft(data);
            if (data.body_text) setReply((r) => ({ ...r, subject: data.subject || r.subject, body: data.body_text }));
            toast.info("AI draft ready — review before sending", { duration: 4000 });
        } catch (e) { toast.error("AI draft failed"); } finally { setAiLoading(false); }
    }

    async function runClassify(msgId) {
        setAiLoading(true);
        try {
            await api.post(`/inbox/messages/${msgId}/ai/classify`);
            await loadConversation(convId);
            toast.success("Classified");
        } catch { toast.error("Classify failed"); } finally { setAiLoading(false); }
    }

    async function sendReply() {
        setBusy(true);
        const payload = {
            conversation_id: convId,
            to: reply.to.split(",").map((s) => s.trim()).filter(Boolean),
            subject: reply.subject,
            body_text: reply.body,
        };
        if (reply.schedule) payload.schedule_at = reply.schedule;
        try {
            const { data } = await api.post("/inbox/send", payload);
            if (payload.schedule_at) {
                toast.success(`Scheduled for ${payload.schedule_at}`);
            } else {
                toast.success(`Sent${data.simulated ? " (simulated)" : ""}`);
            }
            setReply({ ...reply, body: "" });
            loadList();
            loadConversation(convId);
        } catch (e) {
            const detail = e?.response?.data?.detail;
            if (detail?.error === "suppressed_recipients") {
                toast.error(`Blocked: recipient(s) on suppression list — ${detail.suppressed.map(s => s.email + " (" + s.reason + ")").join(", ")}`);
            } else if (detail?.error === "collision") {
                if (window.confirm(detail.detail + "\n\nSend anyway?")) {
                    try {
                        await api.post("/inbox/send", { ...payload, force: true });
                        toast.success("Sent (forced through collision)");
                        loadConversation(convId);
                    } catch { toast.error("Send failed even with force"); }
                }
            } else {
                toast.error(detail?.detail || detail || "Send failed");
            }
        } finally { setBusy(false); }
    }

    async function cancelScheduled(id) {
        try {
            await api.post(`/inbox/scheduled/${id}/cancel`);
            toast.success("Canceled");
            loadConversation(convId);
        } catch { toast.error("Cancel failed"); }
    }

    async function snooze() {
        const iso = prompt("Snooze until (ISO, e.g. 2026-02-14T10:00:00Z)?", "");
        if (!iso) return;
        await api.patch(`/inbox/conversations/${convId}`, { status: "snoozed", snooze_until: iso });
        toast.success("Snoozed");
        loadConversation(convId); loadList();
    }

    async function markClosed() {
        await api.patch(`/inbox/conversations/${convId}`, { status: "closed" });
        toast.success("Closed");
        loadList();
    }

    return (
        <div className="flex h-[calc(100vh-1rem)] md:h-screen" data-testid="inbox-page">
            {/* Left rail: filters + list */}
            <div className="w-72 border-r border-brand-line bg-white flex flex-col">
                <div className="p-4 border-b border-brand-line">
                    <h1 className="font-display text-xl font-semibold">Inbox</h1>
                    <div className="flex gap-1 mt-3">
                        {["open", "snoozed", "closed"].map((s) => (
                            <button key={s} onClick={() => setFilter((f) => ({ ...f, status: s }))}
                                    data-testid={`filter-status-${s}`}
                                    className={`text-xs px-2 py-1 rounded ${filter.status === s ? "bg-brand-ink text-white" : "bg-zinc-100 text-zinc-600"}`}>
                                {s}
                            </button>
                        ))}
                    </div>
                    <div className="flex gap-1 mt-2">
                        {["email", "chat", "form"].map((c) => (
                            <button key={c} onClick={() => setFilter((f) => ({ ...f, channel: f.channel === c ? null : c }))}
                                    data-testid={`filter-channel-${c}`}
                                    className={`text-[10px] uppercase tracking-widest px-2 py-0.5 rounded ${filter.channel === c ? "bg-brand-copper text-white" : "bg-zinc-100 text-zinc-500"}`}>
                                {c}
                            </button>
                        ))}
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto" data-testid="conv-list">
                    {conversations.map((c) => (
                        <ConversationRow key={c.id} conv={c}
                                            active={c.id === convId}
                                            onClick={() => navigate(`/app/inbox/${c.id}`)} />
                    ))}
                    {!conversations.length && <div className="p-4 text-xs text-zinc-500">No conversations here.</div>}
                </div>
            </div>

            {/* Right: thread + composer + AI */}
            <div className="flex-1 flex flex-col overflow-hidden">
                {!selected ? (
                    <div className="p-10 text-zinc-500">Select a conversation</div>
                ) : (
                    <>
                        <div className="p-4 border-b border-brand-line flex items-center justify-between bg-white">
                            <div>
                                <div className="text-lg font-medium" data-testid="conv-subject">{selected.conversation.subject}</div>
                                <div className="text-xs text-zinc-500">
                                    Channel: {selected.conversation.channel} · Status: {selected.conversation.status}
                                </div>
                            </div>
                            <div className="flex gap-2">
                                {othersViewing.length > 0 && (
                                    <Badge variant="secondary" data-testid="others-viewing"><Users className="w-3 h-3 mr-1"/>{othersViewing.length} viewing</Badge>
                                )}
                                <Button size="sm" variant="ghost" onClick={snooze} data-testid="snooze-btn"><Clock className="w-4 h-4 mr-1"/>Snooze</Button>
                                <Button size="sm" variant="ghost" onClick={markClosed} data-testid="close-btn"><CheckCircle2 className="w-4 h-4 mr-1"/>Close</Button>
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-zinc-50" data-testid="messages-scroll">
                            {(selected.messages || []).map((m) => (
                                <div key={m.id}>
                                    <Message m={m} />
                                    {m.direction === "inbound" && !m.ai_labels?.intent && (
                                        <div className="mt-1 text-right">
                                            <Button size="sm" variant="ghost" onClick={() => runClassify(m.id)}
                                                    data-testid={`classify-btn-${m.id}`}>
                                                <Sparkles className="w-3 h-3 mr-1" /> Classify
                                            </Button>
                                        </div>
                                    )}
                                </div>
                            ))}
                            {(selected.scheduled || []).map((s) => (
                                <div key={s.id} className="rounded-lg border-2 border-dashed border-brand-copper bg-white p-4"
                                     data-testid={`scheduled-${s.id}`}>
                                    <div className="text-xs text-brand-copper uppercase tracking-widest">Scheduled for {s.release_at}</div>
                                    <div className="text-sm mt-1 font-medium">{s.payload.subject}</div>
                                    <div className="text-sm text-zinc-600 mt-1 whitespace-pre-wrap">{s.payload.body_text}</div>
                                    <Button size="sm" variant="destructive" className="mt-2"
                                            onClick={() => cancelScheduled(s.id)} data-testid={`cancel-scheduled-${s.id}`}>
                                        Cancel scheduled send
                                    </Button>
                                </div>
                            ))}
                        </div>

                        {/* AI panel + composer */}
                        <div className="border-t border-brand-line bg-white p-4">
                            <div className="flex gap-2 mb-3">
                                <Button size="sm" variant="outline" onClick={runSummarize} disabled={aiLoading} data-testid="ai-summarize-btn">
                                    {aiLoading ? <Loader2 className="w-4 h-4 animate-spin mr-1"/> : <Sparkles className="w-4 h-4 mr-1"/>}
                                    Summarize
                                </Button>
                                <Button size="sm" variant="outline" onClick={runDraft} disabled={aiLoading} data-testid="ai-draft-btn">
                                    {aiLoading ? <Loader2 className="w-4 h-4 animate-spin mr-1"/> : <Sparkles className="w-4 h-4 mr-1"/>}
                                    Suggested reply
                                </Button>
                            </div>
                            {aiSummary && (
                                <div className="mb-3 rounded-md border border-brand-line bg-brand-cream/40 p-3" data-testid="ai-summary-panel">
                                    <div className="text-[10px] uppercase tracking-widest text-brand-copper mb-1">AI summary</div>
                                    <div className="text-sm">{aiSummary.summary}</div>
                                    {aiSummary.next_action && <div className="text-xs mt-1 text-zinc-600">Next: {aiSummary.next_action}</div>}
                                </div>
                            )}
                            {aiDraft && (
                                <div className="mb-3 rounded-md border-2 border-brand-copper/40 bg-brand-cream/40 p-3" data-testid="ai-draft-panel">
                                    <div className="text-[10px] uppercase tracking-widest text-brand-copper mb-1">AI draft — review before sending</div>
                                    {(aiDraft.facts_used || []).length > 0 && (
                                        <div className="text-[10px] text-zinc-500 mb-1">Grounded on: {aiDraft.facts_used.join(", ")}</div>
                                    )}
                                    {(aiDraft.facts_missing || []).length > 0 && (
                                        <div className="text-[10px] text-amber-700 mb-1">Owner will confirm: {aiDraft.facts_missing.join(", ")}</div>
                                    )}
                                </div>
                            )}
                            <div className="space-y-2">
                                <Input value={reply.to} onChange={(e) => setReply({ ...reply, to: e.target.value })}
                                       placeholder="to@example.com" className="text-xs font-mono" data-testid="reply-to-input" />
                                <Input value={reply.subject} onChange={(e) => setReply({ ...reply, subject: e.target.value })}
                                       placeholder="Subject" data-testid="reply-subject-input" />
                                <Textarea rows={5} value={reply.body} onChange={(e) => setReply({ ...reply, body: e.target.value })}
                                          placeholder="Type your reply…" data-testid="reply-body-input" />
                                <div className="flex items-center gap-2">
                                    <Input type="datetime-local" value={reply.schedule}
                                           onChange={(e) => setReply({ ...reply, schedule: e.target.value ? new Date(e.target.value).toISOString() : "" })}
                                           className="w-56 text-xs" data-testid="reply-schedule-input" />
                                    <div className="ml-auto flex gap-2">
                                        <Button variant="outline" onClick={() => sendReply()} disabled={busy || !reply.body || !reply.to}
                                                data-testid="reply-send-btn">
                                            {reply.schedule ? <Clock className="w-4 h-4 mr-2"/> : <Send className="w-4 h-4 mr-2" />}
                                            {reply.schedule ? "Schedule" : "Send"}
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}


// Dashboard wrapper: real stat cards + trend chart on top of the feature page.
export default function Inbox() {
    return (
        <>
            <div className="px-4 md:px-8 pt-6">
                <InsightsDashboard area="inbox" title="Inbox" subtitle="Every conversation across email, chat and forms." color="#D6289B" seriesKey="messages" seriesFormat="int" breakdownTitle="By channel" breakdownFormat="int" />
            </div>
            <InboxBase />
        </>
    );
}
