import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { AlertTriangle, Clock, Calendar as CalIcon, ArrowRight } from "lucide-react";

function isoDate(d) { return d.toISOString().slice(0, 10); }
function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

export default function NeedsAttention() {
    const [data, setData] = useState({ pending: [], overdue: [], today: [] });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        (async () => {
            try {
                const today = new Date(); today.setHours(0, 0, 0, 0);
                const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
                const [pending, overdue, todayBookings] = await Promise.all([
                    api.get("/quotes?status=pending_approval").catch(() => ({ data: { quotes: [] } })),
                    api.get("/invoices?status=overdue").catch(() => ({ data: { invoices: [] } })),
                    api.get(`/booking/bookings?date_from=${isoDate(today)}&date_to=${isoDate(tomorrow)}`).catch(() => ({ data: { bookings: [] } })),
                ]);
                setData({
                    pending: pending.data.quotes || [],
                    overdue: overdue.data.invoices || [],
                    today: (todayBookings.data.bookings || []).filter((b) => b.status !== "cancelled"),
                });
            } finally { setLoading(false); }
        })();
    }, []);

    const total = data.pending.length + data.overdue.length + data.today.length;
    if (loading) return null;
    if (total === 0) return null;

    return (
        <div className="mb-6 rounded-2xl border border-brand-line bg-white overflow-hidden" data-testid="needs-attention">
            <div className="px-5 py-3 border-b border-brand-line flex items-center justify-between">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">Needs attention</div>
                <div className="text-xs text-zinc-500">{total} item{total !== 1 ? "s" : ""}</div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-brand-line">
                <Link to="/app/quotes?tab=pending_approval" className="p-5 hover:bg-brand-cream/30 transition-colors group" data-testid="needs-attention-pending">
                    <div className="flex items-center gap-2 text-amber-800 mb-2">
                        <Clock className="w-4 h-4" />
                        <span className="text-xs uppercase tracking-widest">Pending approval</span>
                    </div>
                    <div className="text-3xl font-mono text-brand-ink" data-testid="needs-attention-pending-count">{data.pending.length}</div>
                    <div className="text-xs text-zinc-500 mt-1 truncate">{data.pending[0]?.number || "quotes waiting"}</div>
                    <div className="mt-2 inline-flex items-center gap-1 text-xs text-brand-copper opacity-0 group-hover:opacity-100 transition-opacity">
                        Review <ArrowRight className="w-3 h-3" />
                    </div>
                </Link>
                <Link to="/app/payments?tab=overdue" className="p-5 hover:bg-brand-cream/30 transition-colors group" data-testid="needs-attention-overdue">
                    <div className="flex items-center gap-2 text-red-700 mb-2">
                        <AlertTriangle className="w-4 h-4" />
                        <span className="text-xs uppercase tracking-widest">Overdue invoices</span>
                    </div>
                    <div className="text-3xl font-mono text-brand-ink" data-testid="needs-attention-overdue-count">{data.overdue.length}</div>
                    <div className="text-xs text-zinc-500 mt-1 truncate">
                        {data.overdue.length ? money(data.overdue.reduce((s, i) => s + (i.total_cents - (i.amount_paid_cents || 0)), 0), data.overdue[0]?.currency) : "all clear"}
                    </div>
                    <div className="mt-2 inline-flex items-center gap-1 text-xs text-brand-copper opacity-0 group-hover:opacity-100 transition-opacity">
                        Nudge them <ArrowRight className="w-3 h-3" />
                    </div>
                </Link>
                <Link to="/app/calendar" className="p-5 hover:bg-brand-cream/30 transition-colors group" data-testid="needs-attention-today">
                    <div className="flex items-center gap-2 text-brand-copper mb-2">
                        <CalIcon className="w-4 h-4" />
                        <span className="text-xs uppercase tracking-widest">Today's bookings</span>
                    </div>
                    <div className="text-3xl font-mono text-brand-ink" data-testid="needs-attention-today-count">{data.today.length}</div>
                    <div className="text-xs text-zinc-500 mt-1 truncate">
                        {data.today[0] ? new Date(data.today[0].start_at).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" }) + " first" : "no bookings"}
                    </div>
                    <div className="mt-2 inline-flex items-center gap-1 text-xs text-brand-copper opacity-0 group-hover:opacity-100 transition-opacity">
                        See day <ArrowRight className="w-3 h-3" />
                    </div>
                </Link>
            </div>
        </div>
    );
}
