"""Website read (block JSON)."""
from fastapi import APIRouter, Depends, HTTPException

from ..db import get_db
from ..deps import current_user, require_org
from ..models import User, Website

from ..services.sites import active_filter as _active_filter

router = APIRouter(prefix="/website", tags=["website"])


@router.get("")
async def get_website(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.websites.find_one(await _active_filter(org_id))
    if not doc:
        raise HTTPException(status_code=404, detail="No website yet")
    return Website.from_mongo(doc).model_dump()


@router.get("/pages/{slug}")
async def get_page(slug: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.websites.find_one(await _active_filter(org_id))
    if not doc:
        raise HTTPException(status_code=404, detail="No website yet")
    website = Website.from_mongo(doc)
    page = next((p for p in website.pages if p.slug == slug), None)
    if not page:
        raise HTTPException(status_code=404, detail=f"Page '{slug}' not found")
    return {"page": page.model_dump(), "theme": website.theme.model_dump()}
