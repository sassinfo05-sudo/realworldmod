import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Trash2, Copy, Key } from "lucide-react";

const AVAILABLE_SCOPES = [
    "contacts:read", "contacts:write",
    "bookings:read", "bookings:write",
    "invoices:read", "invoices:write",
    "quotes:read", "quotes:write",
];

export default function ApiKeys() {
    const [keys, setKeys] = useState([]);
    const [open, setOpen] = useState(false);
    const [name, setName] = useState("");
    const [scopes, setScopes] = useState(["contacts:read"]);
    const [env, setEnv] = useState("live");
    const [busy, setBusy] = useState(false);
    const [issuedKey, setIssuedKey] = useState(null);

    async function load() {
        const { data } = await api.get("/setup/api-keys");
        setKeys(data.api_keys || []);
    }
    useEffect(() => { load(); }, []);

    async function create() {
        setBusy(true);
        try {
            const { data } = await api.post("/setup/api-keys", { name, scopes, env });
            setIssuedKey(data);
            setName(""); setScopes(["contacts:read"]);
            toast.success("Key created — copy it now");
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail?.message || e?.response?.data?.detail || "Create failed");
        } finally { setBusy(false); }
    }
    async function revoke(id) {
        if (!window.confirm("Revoke this key? Any integration using it stops working immediately.")) return;
        try {
            await api.post(`/setup/api-keys/${id}/revoke`);
            toast.success("Revoked");
            load();
        } catch (e) { toast.error("Revoke failed"); }
    }

    return (
        <div className="p-6 max-w-6xl" data-testid="apikeys-page">
            <div className="flex items-start justify-between mb-4">
                <div>
                    <h2 className="text-lg font-medium text-brand-ink">Scoped API keys</h2>
                    <p className="text-sm text-zinc-500 max-w-xl">Give integrations (Zapier, Make, n8n, custom code) least-privilege access. Full key is shown once at creation — only the SHA-256 hash is stored.</p>
                </div>
                <Button onClick={() => { setOpen(true); setIssuedKey(null); }} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="apikeys-new-btn">
                    <Plus className="w-4 h-4 mr-1" /> New key
                </Button>
            </div>

            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Prefix</TableHead>
                        <TableHead>Scopes</TableHead>
                        <TableHead>Last used</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead></TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {keys.map((k) => (
                            <TableRow key={k.id} data-testid={`apikey-${k.id}`}>
                                <TableCell className="font-medium text-brand-ink">{k.name}</TableCell>
                                <TableCell className="font-mono text-xs">{k.prefix}…</TableCell>
                                <TableCell>
                                    <div className="flex gap-1 flex-wrap">
                                        {(k.scopes || []).map((s) => <span key={s} className="text-[10px] bg-brand-cream text-brand-ink px-1.5 py-0.5 rounded">{s}</span>)}
                                    </div>
                                </TableCell>
                                <TableCell className="text-xs text-zinc-500">{k.last_used_at?.slice(0, 16) || "—"}</TableCell>
                                <TableCell>
                                    <span className={`text-[11px] uppercase tracking-widest ${k.revoked ? "text-zinc-400" : "text-emerald-600"}`}>
                                        {k.revoked ? "Revoked" : "Active"}
                                    </span>
                                </TableCell>
                                <TableCell>
                                    {!k.revoked && <Button size="sm" variant="ghost" onClick={() => revoke(k.id)} data-testid={`apikey-${k.id}-revoke`}><Trash2 className="w-3.5 h-3.5" /></Button>}
                                </TableCell>
                            </TableRow>
                        ))}
                        {!keys.length && (
                            <TableRow><TableCell colSpan={6} className="text-center text-zinc-500 py-8" data-testid="apikeys-empty">No API keys yet — create one to enable integrations.</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setIssuedKey(null); }}>
                <DialogContent className="max-w-lg">
                    <DialogHeader><DialogTitle>{issuedKey ? "Copy your key" : "New API key"}</DialogTitle></DialogHeader>
                    {issuedKey ? (
                        <div className="space-y-3">
                            <div className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded p-2">
                                This is the only time we'll show the full key. Copy it now — we only store its hash.
                            </div>
                            <div className="font-mono text-sm bg-brand-cream border border-brand-line rounded p-3 break-all" data-testid="apikey-issued-value">
                                {issuedKey.key}
                            </div>
                            <Button onClick={() => { navigator.clipboard.writeText(issuedKey.key); toast.success("Copied"); }} className="w-full" data-testid="apikey-issued-copy-btn">
                                <Copy className="w-4 h-4 mr-1" /> Copy to clipboard
                            </Button>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            <div>
                                <Label className="text-xs">Name</Label>
                                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Zapier - contacts sync" data-testid="apikey-form-name" />
                            </div>
                            <div>
                                <Label className="text-xs">Environment</Label>
                                <select value={env} onChange={(e) => setEnv(e.target.value)} className="w-full mt-1 border border-brand-line rounded px-2 py-1.5 text-sm bg-white">
                                    <option value="live">Live (yv_live_)</option>
                                    <option value="test">Test (yv_test_)</option>
                                </select>
                            </div>
                            <div>
                                <Label className="text-xs">Scopes</Label>
                                <div className="grid grid-cols-2 gap-1.5 mt-1">
                                    {AVAILABLE_SCOPES.map((s) => (
                                        <label key={s} className="flex items-center gap-2 text-xs">
                                            <input
                                                type="checkbox"
                                                checked={scopes.includes(s)}
                                                onChange={(e) => setScopes(e.target.checked ? [...scopes, s] : scopes.filter((x) => x !== s))}
                                                data-testid={`apikey-scope-${s.replace(":", "-")}`}
                                            />
                                            <span className="font-mono">{s}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                    <DialogFooter>
                        {issuedKey ? (
                            <Button onClick={() => { setOpen(false); setIssuedKey(null); }} data-testid="apikey-done-btn">Done</Button>
                        ) : (
                            <>
                                <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
                                <Button onClick={create} disabled={busy || !name || !scopes.length} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="apikey-create-btn">Create</Button>
                            </>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
