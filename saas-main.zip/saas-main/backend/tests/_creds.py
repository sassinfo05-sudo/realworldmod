"""Shared test credential/config resolution.

Replaces the old HARDCODED stale creds (owner@demo.revenueos.com, founder@revenueos.com) and
missing BASE_URL. Resolution order:
  1. Environment: TEST_OWNER_EMAIL/TEST_OWNER_PASSWORD, TEST_FOUNDER_EMAIL/TEST_FOUNDER_PASSWORD,
     REACT_APP_BACKEND_URL / BASE_URL.
  2. /app/memory/test_credentials.md (the live seed's regenerated passwords).
  3. Sensible Zanelvo defaults for email addresses (passwords must come from the creds file/env).
"""
import os
import re

_CREDS_MD = os.environ.get("TEST_CREDENTIALS_FILE", "/app/memory/test_credentials.md")


def _load_env():
    for p in ("/app/backend/.env",):
        if os.path.exists(p):
            try:
                from dotenv import load_dotenv
                load_dotenv(p)
            except Exception:
                pass


_load_env()


def base_url() -> str:
    return (os.environ.get("REACT_APP_BACKEND_URL")
            or os.environ.get("BASE_URL")
            or "http://localhost:8001").rstrip("/")


def api() -> str:
    return f"{base_url()}/api"


def _parse_creds_md():
    """Return {email: password} parsed from test_credentials.md bullet lines like:
       - **owner@zanelvo.com** — `password`  (role: owner ...)
    """
    out = {}
    if not os.path.exists(_CREDS_MD):
        return out
    text = open(_CREDS_MD, encoding="utf-8", errors="ignore").read()
    for m in re.finditer(r"\*\*([^*]+@[^*]+)\*\*\s*[\u2014-]\s*`([^`]+)`", text):
        out[m.group(1).strip().lower()] = m.group(2).strip()
    return out


_MD = _parse_creds_md()


def _resolve(role_email_default, env_email, env_pw):
    email = (os.environ.get(env_email) or role_email_default).lower()
    pw = os.environ.get(env_pw)
    if not pw:
        # exact match, else first credential whose local part starts with the role
        pw = _MD.get(email)
    if not pw and _MD:
        # fall back to any owner/founder entry
        for e, p in _MD.items():
            if role_email_default.split("@")[0] in e:
                email, pw = e, p
                break
    return email, (pw or "")


OWNER_EMAIL, OWNER_PASSWORD = _resolve("owner@zanelvo.com", "TEST_OWNER_EMAIL", "TEST_OWNER_PASSWORD")
FOUNDER_EMAIL, FOUNDER_PASSWORD = _resolve("founder@zanelvo.com", "TEST_FOUNDER_EMAIL", "TEST_FOUNDER_PASSWORD")
BASE_URL = base_url()
API = api()

# All parsed {email: password} pairs from test_credentials.md (for extra demo orgs).
ALL = dict(_MD)


def password_for(email: str) -> str:
    """Best-effort password lookup for any seeded demo account (env override wins)."""
    email = (email or "").lower()
    return _MD.get(email, "")
