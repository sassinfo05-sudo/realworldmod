import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva } from "class-variance-authority";

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-copper/40 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 select-none",
  {
    variants: {
      variant: {
        default:
          "bg-brand-copper text-white shadow-[0_1px_2px_rgba(0,0,0,0.08),0_6px_16px_-6px_rgba(79,70,229,0.55)] hover:bg-brand-copperHover hover:shadow-[0_8px_22px_-6px_rgba(79,70,229,0.6)] hover:-translate-y-px",
        gradient:
          "text-white bg-[linear-gradient(135deg,#4F46E5_0%,#D6289B_60%,#F59E0B_100%)] bg-[length:160%_160%] shadow-[0_8px_22px_-8px_rgba(214,40,155,0.55)] hover:bg-right hover:-translate-y-px",
        destructive:
          "bg-red-600 text-white shadow-sm hover:bg-red-700",
        outline:
          "border border-brand-line bg-white text-brand-ink shadow-sm hover:bg-zinc-50 hover:border-zinc-300 dark:bg-transparent dark:hover:bg-white/5",
        secondary:
          "bg-brand-cream text-brand-ink hover:bg-brand-cream/70 border border-transparent",
        ghost: "text-zinc-600 hover:bg-zinc-100 hover:text-brand-ink dark:hover:bg-white/10",
        soft: "bg-brand-copper/10 text-brand-copper hover:bg-brand-copper/15",
        link: "text-brand-copper underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-12 rounded-xl px-7 text-base",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"
  return (
    (<Comp
      className={cn(buttonVariants({ variant, size, className }))}
      ref={ref}
      {...props} />)
  );
})
Button.displayName = "Button"

export { Button, buttonVariants }
