"""Real email marketing analytics: open + click tracking, UTM tagging, A/B split,
and last-touch revenue attribution.

Flow:
- On campaign send we create one `campaign_sends` doc per recipient with a unique
  opaque `token`, the chosen A/B `variant`, and the recipient contact/email.
- The email HTML embeds a 1x1 open pixel (GET /api/t/o/{token}.gif) and rewrites
  every link through a click redirect (GET /api/t/c/{token}?u=<url>) that also
  appends UTM params. Public tracking endpoints live in routes/tracking.py.
- Opens/clicks update the send doc (first-touch timestamps) + increment campaign
  and per-variant metrics. A click also stamps the contact's `last_campaign` for
  last-touch revenue attribution when they later place a paid order.
"""
from __future__ import annotations

import html as _html
import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from urllib.parse import quote, urlencode

from bson import ObjectId

from ..db import utc_now_iso

_URL_RE = re.compile(r"(https?://[^\s<>\"')]+)")
ATTRIBUTION_WINDOW_DAYS = 7


def slugify(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (text or "campaign").lower()).strip("-")
    return s[:40] or "campaign"


def utm_params(campaign_slug: str, variant: str = "") -> Dict[str, str]:
    p = {"utm_source": "zanelvo", "utm_medium": "email", "utm_campaign": campaign_slug}
    if variant:
        p["utm_content"] = f"variant-{variant}".lower()
    return p


def _with_utm(url: str, campaign_slug: str, variant: str = "") -> str:
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}{urlencode(utm_params(campaign_slug, variant))}"


def new_token() -> str:
    return uuid.uuid4().hex


def build_tracked_html(*, base_url: str, token: str, subject: str, body_text: str,
                        campaign_slug: str, variant: str = "",
                        brand: str = "Zanelvo", unsubscribe_url: str = "") -> str:
    """Turn a plain-text campaign body into a clean, click+open tracked HTML email."""
    base = (base_url or "").rstrip("/")
    paras: List[str] = []
    for block in (body_text or "").split("\n\n"):
        block = block.strip()
        if not block:
            continue
        # linkify + click-wrap
        def _repl(m):
            raw = m.group(1)
            tracked = f"{base}/api/t/c/{token}?u={quote(_with_utm(raw, campaign_slug, variant), safe='')}"
            return f'<a href="{tracked}" style="color:#4F46E5;text-decoration:underline;">{_html.escape(raw)}</a>'
        safe = _html.escape(block)
        # unescape the URLs we want to linkify (escape first, then inject anchors)
        safe = _URL_RE.sub(lambda m: _repl(m), safe)
        safe = safe.replace("\n", "<br>")
        paras.append(f'<p style="font-size:15px;line-height:1.7;color:#2f2f37;margin:0 0 16px;">{safe}</p>')
    return _wrap_email("".join(paras), base=base, token=token, brand=brand, unsubscribe_url=unsubscribe_url)


def _track_url(base: str, token: str, raw: str, campaign_slug: str, variant: str) -> str:
    """Wrap an outbound URL in the click-tracking redirect (with UTM)."""
    return f"{base}/api/t/c/{token}?u={quote(_with_utm(raw, campaign_slug, variant), safe='')}"


def _wrap_email(inner_html: str, *, base: str, token: str, brand: str, unsubscribe_url: str) -> str:
    """Shared branded shell + open pixel used by the plain-text and block email renderers."""
    pixel = f'<img src="{base}/api/t/o/{token}.gif" width="1" height="1" alt="" style="display:none;width:1px;height:1px;">'
    unsub = ""
    if unsubscribe_url:
        unsub = (f'<p style="font-size:11px;color:#9a9aa4;margin-top:22px;">'
                 f'<a href="{unsubscribe_url}" style="color:#9a9aa4;">Unsubscribe</a></p>')
    return (
        '<!DOCTYPE html><html><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1"></head>'
        '<body style="margin:0;background:#f4f4f7;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f7;">'
        '<tr><td align="center" style="padding:28px 16px;">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#fff;border:1px solid #ececf1;border-radius:16px;">'
        '<tr><td style="height:4px;background-image:linear-gradient(135deg,#4F46E5,#D6289B,#F59E0B);font-size:0;">&nbsp;</td></tr>'
        f'<tr><td style="padding:14px 30px 0;font-weight:700;color:#15151b;">{_html.escape(brand)}</td></tr>'
        f'<tr><td style="padding:18px 30px 30px;">{inner_html}{unsub}</td></tr>'
        '</table></td></tr></table>' + pixel + '</body></html>'
    )


# ---- Block-based email editor (Round 13) ----
# A campaign may carry `blocks` (a list of typed content blocks) instead of / in addition to plain
# body_text. Supported types: heading, text, button, image, divider, spacer. Links + buttons are
# click-tracked; the open pixel is injected by the shared shell.
EMAIL_BLOCK_TYPES = {"heading", "text", "button", "image", "divider", "spacer"}


def _linkify_tracked(text: str, base: str, token: str, campaign_slug: str, variant: str) -> str:
    safe = _html.escape(text or "")
    safe = _URL_RE.sub(
        lambda m: f'<a href="{_track_url(base, token, m.group(1), campaign_slug, variant)}" '
                  f'style="color:#4F46E5;text-decoration:underline;">{_html.escape(m.group(1))}</a>',
        safe)
    return safe.replace("\n", "<br>")


def build_email_blocks_html(*, base_url: str, token: str, blocks: List[Dict[str, Any]],
                            campaign_slug: str, variant: str = "", brand: str = "Zanelvo",
                            unsubscribe_url: str = "") -> str:
    base = (base_url or "").rstrip("/")
    parts: List[str] = []
    for b in (blocks or []):
        t = (b.get("type") or "text").lower()
        if t == "heading":
            txt = _html.escape((b.get("text") or "").strip())
            if txt:
                parts.append(f'<h2 style="font-size:22px;line-height:1.3;color:#15151b;margin:0 0 14px;font-weight:700;">{txt}</h2>')
        elif t == "text":
            body = _linkify_tracked((b.get("text") or "").strip(), base, token, campaign_slug, variant)
            if body:
                parts.append(f'<p style="font-size:15px;line-height:1.7;color:#2f2f37;margin:0 0 16px;">{body}</p>')
        elif t == "button":
            label = _html.escape((b.get("text") or "Learn more").strip())
            href = (b.get("href") or "").strip()
            if href:
                tracked = _track_url(base, token, href, campaign_slug, variant)
                parts.append(
                    '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:6px 0 20px;"><tr><td '
                    'style="border-radius:10px;background-image:linear-gradient(135deg,#4F46E5,#D6289B);">'
                    f'<a href="{tracked}" style="display:inline-block;padding:12px 26px;color:#fff;font-weight:600;'
                    f'font-size:15px;text-decoration:none;border-radius:10px;">{label}</a></td></tr></table>')
        elif t == "image":
            src = (b.get("src") or "").strip()
            if src and src.lower().startswith(("http://", "https://")):
                alt = _html.escape((b.get("alt") or "").strip())
                img = (f'<img src="{_html.escape(src)}" alt="{alt}" style="max-width:100%;height:auto;'
                       'border-radius:10px;display:block;margin:0 0 18px;">')
                href = (b.get("href") or "").strip()
                if href:
                    img = f'<a href="{_track_url(base, token, href, campaign_slug, variant)}">{img}</a>'
                parts.append(img)
        elif t == "divider":
            parts.append('<hr style="border:none;border-top:1px solid #ececf1;margin:6px 0 22px;">')
        elif t == "spacer":
            try:
                size = max(4, min(80, int(b.get("size", 24))))
            except (TypeError, ValueError):
                size = 24
            parts.append(f'<div style="height:{size}px;line-height:{size}px;font-size:0;">&nbsp;</div>')
    return _wrap_email("".join(parts), base=base, token=token, brand=brand, unsubscribe_url=unsubscribe_url)


def blocks_to_text(blocks: List[Dict[str, Any]]) -> str:
    """Plain-text fallback (also the `text=` payload for the provider)."""
    lines: List[str] = []
    for b in (blocks or []):
        t = (b.get("type") or "text").lower()
        if t in ("heading", "text"):
            v = (b.get("text") or "").strip()
            if v:
                lines.append(v)
        elif t == "button":
            label = (b.get("text") or "Learn more").strip()
            href = (b.get("href") or "").strip()
            if href:
                lines.append(f"{label}: {href}")
        elif t == "image":
            href = (b.get("href") or "").strip()
            if href:
                lines.append(href)
        elif t == "divider":
            lines.append("—")
    return "\n\n".join(lines)


def choose_variant(campaign: Dict[str, Any], index: int) -> Dict[str, Any]:
    """Return {key, subject, body_text, blocks} for the recipient. Round-robins A/B when enabled."""
    variants = campaign.get("variants") or []
    if campaign.get("ab_test") and len(variants) >= 2:
        v = variants[index % len(variants)]
        return {
            "key": v.get("key") or chr(65 + (index % len(variants))),
            "subject": v.get("subject") or campaign.get("subject") or "",
            "body_text": v.get("body_text") or campaign.get("body_text") or "",
            "blocks": v.get("blocks") or campaign.get("blocks") or [],
        }
    return {"key": "", "subject": campaign.get("subject") or "",
            "body_text": campaign.get("body_text") or "", "blocks": campaign.get("blocks") or []}


async def record_send(db, *, org_id: str, campaign_id: str, token: str, variant: str,
                       email: str, contact_id: Optional[str]) -> None:
    await db.campaign_sends.insert_one({
        "org_id": org_id, "campaign_id": campaign_id, "token": token, "variant": variant,
        "email": email, "contact_id": contact_id,
        "opened_at": None, "clicked_at": None, "open_count": 0, "click_count": 0,
        "created_at": utc_now_iso(),
    })


def _variant_inc(variant: str, field: str) -> Dict[str, int]:
    inc = {f"metrics.{field}": 1}
    if variant:
        inc[f"variant_metrics.{variant}.{field}"] = 1
    return inc


async def record_open(db, token: str) -> Optional[Dict[str, Any]]:
    send = await db.campaign_sends.find_one({"token": token})
    if not send:
        return None
    now = utc_now_iso()
    first = send.get("opened_at") is None
    await db.campaign_sends.update_one({"_id": send["_id"]},
        {"$inc": {"open_count": 1}, "$set": {"opened_at": send.get("opened_at") or now}})
    inc = {"metrics.opens": 1}
    if first:
        inc["metrics.unique_opens"] = 1
    v = send.get("variant") or ""
    if v:
        inc[f"variant_metrics.{v}.opens"] = 1
        if first:
            inc[f"variant_metrics.{v}.unique_opens"] = 1
    await db.campaigns.update_one({"_id": ObjectId(send["campaign_id"])}, {"$inc": inc})
    return send


async def record_click(db, token: str) -> Optional[Dict[str, Any]]:
    send = await db.campaign_sends.find_one({"token": token})
    if not send:
        return None
    now = utc_now_iso()
    first = send.get("clicked_at") is None
    await db.campaign_sends.update_one({"_id": send["_id"]},
        {"$inc": {"click_count": 1}, "$set": {"clicked_at": send.get("clicked_at") or now}})
    inc = {"metrics.clicks": 1}
    if first:
        inc["metrics.unique_clicks"] = 1
        # an open is implied by a click
        if send.get("opened_at") is None:
            inc["metrics.opens"] = 1
            inc["metrics.unique_opens"] = 1
            await db.campaign_sends.update_one({"_id": send["_id"]}, {"$set": {"opened_at": now}})
    v = send.get("variant") or ""
    if v:
        inc[f"variant_metrics.{v}.clicks"] = 1
        if first:
            inc[f"variant_metrics.{v}.unique_clicks"] = 1
    await db.campaigns.update_one({"_id": ObjectId(send["campaign_id"])}, {"$inc": inc})
    # last-touch attribution stamp on the contact
    if send.get("contact_id"):
        try:
            await db.contacts.update_one({"_id": ObjectId(send["contact_id"]), "org_id": send["org_id"]},
                {"$set": {"last_campaign": {"campaign_id": send["campaign_id"], "variant": v, "at": now}}})
        except Exception:  # noqa: BLE001
            pass
    if send.get("email"):
        await db.campaign_last_touch.update_one(
            {"org_id": send["org_id"], "email": send["email"].lower()},
            {"$set": {"campaign_id": send["campaign_id"], "variant": v, "at": now}}, upsert=True)
    return send


async def attribute_conversion(db, *, org_id: str, email: str, amount_cents: int) -> bool:
    """Last-touch: if this buyer clicked a campaign within the window, credit revenue to it."""
    if not email or amount_cents <= 0:
        return False
    lt = await db.campaign_last_touch.find_one({"org_id": org_id, "email": email.lower()})
    if not lt:
        return False
    try:
        at = datetime.fromisoformat(str(lt.get("at")).replace("Z", "+00:00"))
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - at > timedelta(days=ATTRIBUTION_WINDOW_DAYS):
            return False
    except Exception:  # noqa: BLE001
        pass
    v = lt.get("variant") or ""
    inc = {"metrics.conversions": 1, "metrics.revenue_cents": int(amount_cents)}
    if v:
        inc[f"variant_metrics.{v}.conversions"] = 1
        inc[f"variant_metrics.{v}.revenue_cents"] = int(amount_cents)
    try:
        await db.campaigns.update_one({"_id": ObjectId(lt["campaign_id"]), "org_id": org_id}, {"$inc": inc})
        return True
    except Exception:  # noqa: BLE001
        return False


def compute_analytics(campaign: Dict[str, Any]) -> Dict[str, Any]:
    """Derive rates + pick an A/B winner (by unique-click rate, fallback open rate)."""
    m = campaign.get("metrics") or {}
    sent = max(0, int(m.get("sent") or 0))
    def rate(n):
        return round((int(n or 0) / sent) * 100, 1) if sent else 0.0
    out = {
        "sent": sent,
        "opens": int(m.get("opens") or 0),
        "unique_opens": int(m.get("unique_opens") or 0),
        "clicks": int(m.get("clicks") or 0),
        "unique_clicks": int(m.get("unique_clicks") or 0),
        "conversions": int(m.get("conversions") or 0),
        "revenue_cents": int(m.get("revenue_cents") or 0),
        "open_rate": rate(m.get("unique_opens")),
        "click_rate": rate(m.get("unique_clicks")),
        "ctr": round((int(m.get("unique_clicks") or 0) / max(1, int(m.get("unique_opens") or 0))) * 100, 1),
        "conversion_rate": rate(m.get("conversions")),
        "revenue": round(int(m.get("revenue_cents") or 0) / 100, 2),
    }
    vm = campaign.get("variant_metrics") or {}
    variants = []
    for key, met in vm.items():
        vsent = max(1, int(met.get("sent") or 0))
        variants.append({
            "key": key,
            "sent": int(met.get("sent") or 0),
            "unique_opens": int(met.get("unique_opens") or 0),
            "unique_clicks": int(met.get("unique_clicks") or 0),
            "conversions": int(met.get("conversions") or 0),
            "revenue": round(int(met.get("revenue_cents") or 0) / 100, 2),
            "open_rate": round(int(met.get("unique_opens") or 0) / vsent * 100, 1),
            "click_rate": round(int(met.get("unique_clicks") or 0) / vsent * 100, 1),
        })
    winner = None
    if len(variants) >= 2:
        ranked = sorted(variants, key=lambda x: (x["click_rate"], x["open_rate"], x["conversions"]), reverse=True)
        if ranked[0]["click_rate"] > 0 or ranked[0]["open_rate"] > 0:
            winner = ranked[0]["key"]
    out["variants"] = variants
    out["ab_winner"] = winner
    return out
