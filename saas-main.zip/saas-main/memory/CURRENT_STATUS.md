# Zanelvo — CURRENT STATUS (Round 18, storage/build/bootstrap remediation)

## ROUND 18 DELTA — CODE_GATE: PASS / PRODUCTION_GATE: PENDING_OWNER_SETUP (this session)
- Environment was WIPED on import; rebuilt `.env` + deps → all services RUNNING, `/api/health` 200,
  `/api/readiness` app_ready:true / external_ready:false (pending: storage, platform_email), founder +
  demo-owner login 200. Fresh creds in gitignored `memory/test_credentials.md`.
- Verified from the rebuilt checkout: frozen frontend install PASS; frontend prod build PASS; ruff EXIT 0;
  backend compile EXIT 0; storage/founder/config test suites 47 passed / 1 skipped; pip-audit 0 vulns
  (21 documented ignores); secret scan clean; no "Revenue OS" in customer-facing `frontend/src`.
- Storage invariants (actual-size bypass, reservation leak, signed-URL expiry, provider-switch
  readability) fixed + tested. Bootstrap CLI single-use/hashed/48h/audited; founder email de-hardcoded;
  readiness surfaces db/origin/storage/email; MFA copy accurate (prod fails closed). CI fail-open removed.
- **Honest gaps:** full backend suite = 193 passed / 6 failed / 18 skipped. The 6 failures are all
  LLM-grounding integration tests failing because the shared **EMERGENT_LLM_KEY budget is exhausted**
  (`Max budget: 0.001` exceeded) — external billing, NOT a code regression; needs an owner-funded key.
  Docker image builds can't run here (no daemon). Asset-Library cross-editor wiring (D) + expanded staff
  storage dashboards (E) remain increments. See `ROUND_18_AUDIT.md` + `HANDOFF_ROUND_18.md`.

---

# Zanelvo — CURRENT STATUS (Round 15, production-gate, pass 5)

## POST-ROUND-15 (Round 16) DELTA — DYNAMIC CMS & EXTENSIONS FOUNDATION (this session)
- Backend CMS (`/api/cms/*` + `/api/public/cms/*`) verified: 16/17 acceptance journeys PASS via the
  backend testing agent; new deterministic suite `backend/tests/test_cms_foundation.py` = 16 passed /
  1 skipped. Covers collections/items CRUD, 17 field types, validation, unique+slug, revisions/rollback,
  bounded CSV, dynamic list+detail public pages, private-field projection, tenant isolation (404),
  stored-XSS sanitised, SSRF blocked, plan limits, form→collection+CRM, metered AI propose.
- Added published dynamic CMS pages to `sitemap.xml` (routes/public_sites.py).
- NEW frontend Content Manager (was entirely missing): `/app/content` (collections + visual field
  builder + AI create + connectors) and `/app/content/:cid` (spreadsheet items, CSV import/export,
  revisions/rollback, schema editor, dynamic-pages wizard). Public dynamic rendering at
  `/site/:slug/:routeBase[/:itemSlug]`. Nav item under "Build". Lint clean, prod compile OK, UI verified.
- Home light-mode fix: hero DashboardMock + showcase ActivitySlider are now theme-adaptive (scoped
  `.mock-light` + light-mode CSS in index.css); dark mode preserved. Verified by screenshot.
- No new P0. Remaining CMS brief items (visual editor binding, scheduled connector sync, safe scoped CSS,
  system-collection adapters, AI layout generation) are future increments — see HANDOFF_ROUND_16.md.

---

_Last updated: Round 15 pass 6 (continuation). Source code + fresh evidence override any older ✅ claims._

## PASS 6 DELTAS (funded LLM key + legal gate UI + 2 visual bug fixes)
- Swapped in a FUNDED EMERGENT_LLM_KEY. The 5 previously budget-blocked AI tests now **PASS 5/5**,
  including BOTH distinct website-generation journeys (plumber + salon), AI grounding, grounded
  pricing, and booking-via-chat. LLM-budget blocker CLEARED.
- Legal Review Gate: backend already had /founder/launch-gate (legal_reviewed). Added the missing
  OWNER UI in founder LegalEditor.jsx (status pill + confirm/withdraw checkbox, records identity+time,
  audit-logged). Verified end-to-end: confirm → public /api/brand legal_reviewed=true (clears the
  public "not confirmed by legal review" banner); withdraw resets. This is the explicit launch gate.
- Non-key staging drills: backup/restore rehearsal PASS (mongodump→mongorestore, counts match);
  leader-lock / duplicate-scheduler drill PASS (second process denied while leader alive, takeover
  only after TTL lapse).
- Two reported visual bugs FIXED + frontend-agent verified: (1) Home page now light in bright mode
  (hero/features/CTA theme-adaptive); (2) Developers "API keys" links fixed /app/api-keys →
  /app/setup/api-keys (no more 404).
- REMAINING = ONLY owner key-paste / merchant actions: connect Stripe (Stripe Connect), Cloudflare-for-
  SaaS credentials, optional email/voice providers, and the owner's own legal-review confirmation click.

## PASS 5 FRESH RE-VERIFICATION (env rebuilt from wiped import)
- Rebuilt env; **rotated** JWT_SECRET + SECRETS_ENC_KEY (all prior owner/staff/impersonation sessions invalid).
- Secret scan of tracked files: **clean** (no live secrets); `tmp_r11` absent; `memory/test_credentials.md` NOT git-tracked.
- Deterministic P0 suite: **32/32 PASS** (metering/reservation atomicity, staff security, entitlement tiers,
  inbound-email security, visitor caps, commerce concurrency, leader lock, webhook retry/signature, XSS sanitizer,
  prod-config gate, domain-provider prod guard, reservation concurrency).
- Legacy regression: **154 passed / 17 skipped / 5 blocked**. The 5 blocked are 100% the shared EMERGENT_LLM_KEY
  hitting its **$1.00 budget cap** (litellm "Budget exceeded: cost 1.041 / max 1.0") — an EXTERNAL provider limit,
  proven not a code defect (same tests passed earlier in the run before the budget drained).
- Fixed 6 stale/flaky test-harness issues (product behavior already correct) — see test_result.md pass-5 note.
- Reproducible frontend build: `yarn install --frozen-lockfile` then `yarn build` → **SUCCESS**.
- Browser E2E (frontend agent, non-AI scope): **6.5/7 PASS**. Flow 1 (cookie-auth security) PASS — no raw JWT in
  any JS-accessible storage; `zv_access` cookie HttpOnly+Secure (not JS-readable); `zv_csrf` = readable double-submit
  token. Owner dashboard, published site, storefront, staff panel, dark-mode, mobile all PASS. Editor UI automation
  inconclusive (selectors) but publish/rollback are backend-verified by passing phase2 API tests.
- **Still FAIL** — external blockers unchanged: LLM budget top-up needed to verify the 2 live website-generation
  journeys; Stripe Connect enablement; Cloudflare-for-SaaS creds; legal review; production-mode staging sweep.

## PRODUCTION_GATE: FAIL (honest)
Every code-fixable P0 in the Round-15 brief is now implemented and covered by a deterministic test.
The remaining blockers are **owner/merchant actions** (enable Stripe Connect on the platform Stripe
account, Cloudflare for SaaS credentials, legal review) plus the browser E2E / axe / Lighthouse sweep
on a production-mode staging host. A PASS is correctly NOT claimed while any of those is open.

## Environment
- Preview: `env | grep preview_endpoint`. Backend+frontend via supervisor; `GET /api/health` ok.
- APP_ENV=dev, SEED_DEMO_DATA=true. Creds in gitignored `memory/test_credentials.md` (regenerated per seed).
- JWT_SECRET + SECRETS_ENC_KEY rotated on this import (all prior sessions invalid).
- Platform Stripe credentials: a **claimable test sandbox** (Emergent Flow A) is stored ENCRYPTED in the
  Staff Setup Center (`integrations.payments`). State = **Sandbox**; Connect **not enabled** (owner action).

## ✅ DONE & VERIFIED — this session (pass 4)
| # | Item | Evidence |
|---|------|----------|
| 16 | Receipts use the **grand total**; real-provider orders are never labelled "simulated" (`_order_is_simulated`) | `tests/test_store_stripe_webhook.py` 6/6 |
| 17 | **Staff security**: atomic single-use MFA consumption (`find_one_and_update`), staff `sessions_invalidated_at` checked in `deps.py`, Mongo-backed distributed limiter on staff login/2FA/invite, **hashed 48h single-use set-password invitations** replace temp passwords (`POST /api/staff/members` → invite; `/members/{id}/reinvite`; public `POST /api/staff/auth/accept-invite`), password change invalidates sessions. Frontend `/staff/set-password` page + StaffTeam dialog | `tests/test_staff_security.py` 3/3 (concurrent accept → exactly one 200; 11th login → 429; 8 concurrent MFA verifies → exactly one success) |
| 18 | **Founder bootstrap is an explicit one-time CLI** `python -m scripts.bootstrap_founder` (invite-link based, no plaintext); implicit startup bootstrap + `FOUNDER_INITIAL_PASSWORD` removed | manual run on scratch DB: create OK, re-run REFUSED |
| 19 | **Server-side entitlement audit**: custom_domain (domains create), automations (workflow create/template/publish), campaigns_enabled (campaign create/send), ai_receptionist (voice config), abandoned_cart (owner sweep + background sweep skips non-entitled orgs), `products` meter (create + CSV import), subscriptions (create + update bypass) | `tests/test_entitlements_tiers.py` 2/2 (free denied ×10, revenue/autopilot allowed) |
| 20 | **Stripe Connect design** (`services/stripe_connect.py`): platform key only from Setup Center; tenant onboarding via Express Account Links (`POST /api/store/payments/stripe/connect/start`, `GET …/status`); direct charges with `Stripe-Account`; **raw tenant secret keys rejected with 400** (`raw_secret_not_accepted`); no auto go-live from key patterns; go-live requires Stripe-verified `charges_enabled`; **real probe** `GET /api/founder/integrations/probe/stripe` (Live/Sandbox/Not connected/Error + Connect enabled, cached); PayPal + recurring billing explicitly **unavailable** in `/api/store/settings`. Frontend TenantIntegrations → Connect panel; StaffPayments → probe button | live API run: paste-key 400, connect start 503 (honest), probe = sandbox / connect_enabled=false |
| 21 | **Platform Stripe webhook**: secret from Setup Center, atomic idempotency (unique `_id` insert), **tenant-ownership check** via Connect `account` (403 on mismatch) | `tests/test_store_stripe_webhook.py` |
| 22 | **Inbound email**: 401/403 on bad/missing signature (was 200), SendGrid ECDSA signed-event verification, atomic `webhook_events` claim, tenant resolution ONLY from platform-assigned mailbox or **verified** custom domain (unverified `contact_email/from_email/reply_to` removed), platform email domain never routes to a tenant | `tests/test_email_inbound_security.py` 3/3 |
| 23 | **Custom domains**: Cloudflare creds loaded from Setup Center (`integrations.domains`), real probe `GET /api/founder/integrations/probe/cloudflare`, honest Connected/Not connected/Error, entitlement enforced server-side | `tests/test_domain_providers.py`, entitlement test |
| 24 | **Public visitor anti-exhaustion caps** (per-session 5%, per-IP 10%, tenant public/day 40% of AI cap; founder-editable) — a visitor can't drain the tenant quota; owner AI unaffected | `tests/test_public_visitor_caps.py` 1/1 |
| 25 | **Truthful pricing**: plan bullets rewritten (no PayPal/POS/paid-ads/voice-minutes/unlimited-domains claims), `PLANS_SEED_VERSION=6`; feature matrix marks provider-gated rows "Not yet available" from real availability; help article no longer lists prices; legal pages carry a **legal-review notice** until the launch gate is confirmed; Privacy matches cookie-auth, Stripe Connect, AI subprocessor, audit logging; internal `revenue_os` names removed from frontend storage keys/loggers; voice provider cards no longer say "Configured" without creds and no longer advertise `?org_id=` | `/api/billing/plans` inspected |
| 26 | Test harness: per-module synthetic client IP in `tests/conftest.py` (so the login limiter isn't a false failure), `test_phase2_fixes.py` rebound to `_creds`, stale brand/plan/slug expectations fixed, demo slug restored | legacy suites: 134+ passed |
| 27 | CI: deterministic pytest set + `pip-audit` added | `.github/workflows/ci.yml` |

## ✅ DONE earlier in Round 15 (passes 1–3) — see HANDOFF_ROUND_15.md §1
Credential cleanup + JWT rotation + secret scan; cookie auth (HttpOnly + CSRF, no JWT in localStorage);
CORS fail-closed; production seeding gate + config validation; atomic two-cap metering (DB-backed plan
caps, 60/80/95 warnings); XSS sanitizers + escaped markdown; gift-card/inventory concurrency; worker +
leader lock; outbound webhook retries/DLQ/replay + `t=…,v1=…` docs; inbound `status→state` fix; deploy
manifests + nginx CSP; MFA fail-closed in prod.

## ⬜ LEFT (blocked on owner action or needs the staging sweep)
1. **Stripe Connect enablement** — owner signs up for Connect on the platform Stripe account
   (dashboard.stripe.com/connect). Until then tenants see "Online payments not available yet" (503) and
   storefronts stay in labelled test mode. Then: complete one Express onboarding + one $1 sandbox charge
   through a connected account and record the webhook.
2. **Recurring Stripe Billing** for subscription products — not built; labelled unavailable everywhere.
3. **PayPal** — unavailable until a signed sandbox flow passes (adapter verifies signatures only).
4. **Cloudflare for SaaS** credentials → Setup Center → run probe → first real hostname + SSL issuance.
5. **Legal review** of Terms/Privacy → founder confirms `PUT /api/founder/launch-gate` (removes the notice).
6. **Fresh production-mode regression on a staging host** (APP_ENV=production, dedicated DB): browser
   E2E (owner/staff/storefront/published site), axe, Lighthouse mobile, worker restart + duplicate-scheduler,
   backup/restore rehearsal. Backend deterministic + legacy suites already run green here in dev mode.
7. Minor: frontend `no-unescaped-entities` lint warnings (stylistic); `test_phase2` import test is
   load-sensitive when the LLM import test runs first.

## Login paths
owner `/login` → `/app`; founder/staff `/staff/login` (invite: `/staff/set-password?token=…`);
public demo `/site/demo-home-services`; storefront `/store/<org_id>`. Credentials: gitignored
`memory/test_credentials.md`. Founder bootstrap in prod: `python -m scripts.bootstrap_founder`.

## ROUND 17 DELTA — PRODUCTION STORAGE & UNIFIED ASSET LIBRARY
- Provider-neutral object storage service (S3-compatible + local dev; production refuses local permanent storage).
- Unified Asset Library (/app/assets) + reusable Asset Picker (wired into CMS media field). Nav under "Build".
- Atomic upload flow with quota reservation, MIME/magic/size validation, SVG sanitise, image-bomb guard,
  EXIF strip, per-tenant SHA-256 dedup; trash/restore/purge with accurate accounting; signed private URLs.
- DB-backed founder-editable storage allowances (500MB/5GB/50GB/200GB/500GB) + per-tenant overrides; 70/90/100%.
- Idempotent legacy-media migration (dry-run verified). Backend tests 10/10; CMS regression still 16/1.
- Frontend production build: SUCCESS (warnings only). Bandwidth honestly Estimated/Unavailable until provider connected.
- CODE_GATE: PASS. PRODUCTION_GATE: PENDING_EXTERNAL_SETUP (no real object-storage/CDN creds connected yet).

## AUTH FIX — preview host rotation (verified)
Root cause: the preview hostname rotated (849b93f2 → cms-foundation-2). When the app was opened from a
stale hostname, the bundled REACT_APP_BACKEND_URL pointed at the other emergent host, so every /api call
was cross-origin → CORS-blocked → cookie auth failed ("Failed to load interview" + split-second dashboard
then logout). Fix: `frontend/src/lib/api.js` resolveBase() now falls back to the current page origin when
the configured backend is a DIFFERENT emergent host (ingress always routes /api on the current host to the
backend). Normal same-origin case unchanged. Frontend testing agent: 4/4 auth checks PASS (signup→interview,
dashboard persistence, login, Google OAuth redirect); zero CORS/401/403.
