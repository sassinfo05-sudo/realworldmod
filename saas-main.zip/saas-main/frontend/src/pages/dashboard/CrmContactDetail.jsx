import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, RefreshCw, StickyNote, ListTodo, Sparkles } from "lucide-react";
import { toast } from "sonner";

function Factor({ f }) {
    return (
        <div className="flex items-start justify-between gap-3 py-1.5 border-b border-brand-line last:border-b-0" data-testid={`score-factor-${f.key}`}>
            <div>
                <div className="text-sm">{f.note}</div>
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 mt-0.5">
                    {f.key} {f.source === "ai" ? "· AI-assessed" : "· rule"}
                </div>
            </div>
            <div className="text-sm font-mono">{f.points > 0 ? "+" : ""}{f.points}</div>
        </div>
    );
}

export default function CrmContactDetail() {
    const { id } = useParams();
    const [contact, setContact] = useState(null);
    const [timeline, setTimeline] = useState([]);
    const [score, setScore] = useState(null);
    const [scoring, setScoring] = useState(false);
    const [notes, setNotes] = useState([]);
    const [newNote, setNewNote] = useState("");
    const navigate = useNavigate();

    async function load() {
        const [c, tl, s, nn] = await Promise.all([
            api.get(`/crm/contacts/${id}`),
            api.get(`/crm/contacts/${id}/timeline`),
            api.get(`/crm/contacts/${id}/lead-score`).catch(() => ({ data: null })),
            api.get(`/crm/notes?entity_type=contact&entity_id=${id}`),
        ]);
        setContact(c.data);
        setTimeline(tl.data.interactions || []);
        setScore(s.data);
        setNotes(nn.data.notes || []);
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [id]);

    async function refreshScore() {
        setScoring(true);
        try {
            const { data } = await api.get(`/crm/contacts/${id}/lead-score?refresh=true`);
            setScore(data);
            toast.success(`Score refreshed: ${data.score}`);
        } catch (e) {
            toast.error("Could not refresh score");
        } finally { setScoring(false); }
    }

    async function addNote() {
        if (!newNote.trim()) return;
        await api.post("/crm/notes", { entity_type: "contact", entity_id: id, body: newNote });
        setNewNote("");
        toast.success("Note added");
        load();
    }

    if (!contact) return <div className="p-6 text-zinc-500">Loading…</div>;
    const email = (contact.emails || [])[0];
    const phone = (contact.phones || [])[0];

    return (
        <div className="p-6 space-y-6" data-testid="crm-contact-detail-page">
            <Button variant="ghost" size="sm" onClick={() => navigate("/app/crm")} data-testid="contact-back-btn">
                <ArrowLeft className="w-4 h-4 mr-1" /> Contacts
            </Button>

            <div className="grid lg:grid-cols-3 gap-6">
                {/* Left: contact card */}
                <div className="lg:col-span-1 space-y-4">
                    <div className="rounded-lg border border-brand-line bg-white p-5">
                        <h1 className="font-display text-2xl font-semibold" data-testid="contact-name">
                            {contact.display_name || `${contact.first_name || ""} ${contact.last_name || ""}`}
                        </h1>
                        <div className="text-sm text-zinc-500 mt-1 font-mono">{email}</div>
                        <div className="text-sm text-zinc-500 mt-0.5 font-mono">{phone}</div>
                        <div className="flex gap-1 flex-wrap mt-3">
                            {(contact.tags || []).map((t) => <Badge key={t} variant="outline">{t}</Badge>)}
                        </div>
                        <div className="mt-3 text-xs text-zinc-500">Source: {contact.source || "unknown"}</div>
                        <div className="mt-3 pt-3 border-t border-brand-line">
                            <label className="text-[11px] uppercase tracking-widest text-zinc-500">Customer group</label>
                            <div className="flex items-center gap-2 mt-1">
                                <input
                                    defaultValue={contact.customer_group || ""}
                                    placeholder="e.g. vip, wholesale"
                                    className="flex-1 border border-brand-line rounded-lg px-2 py-1 text-sm"
                                    data-testid="contact-group-input"
                                    onBlur={async (e) => {
                                        const v = e.target.value.trim();
                                        if (v === (contact.customer_group || "")) return;
                                        try { await api.patch(`/crm/contacts/${id}`, { customer_group: v }); toast.success("Group updated"); load(); }
                                        catch { toast.error("Could not update group"); }
                                    }}
                                />
                            </div>
                            <p className="text-[11px] text-zinc-400 mt-1">Used for group-only discounts at your storefront.</p>
                        </div>
                    </div>

                    <div className="rounded-lg border border-brand-line bg-white p-5" data-testid="lead-score-card">
                        <div className="flex items-center justify-between">
                            <div className="text-sm font-medium">Lead score</div>
                            <Button variant="ghost" size="sm" onClick={refreshScore} disabled={scoring}
                                    data-testid="refresh-score-btn">
                                <RefreshCw className={`w-4 h-4 mr-1 ${scoring ? "animate-spin" : ""}`} />
                                {scoring ? "Scoring…" : "Refresh"}
                            </Button>
                        </div>
                        <div className="mt-3 flex items-baseline gap-2">
                            <div className="text-4xl font-display font-semibold" data-testid="lead-score-value">
                                {score?.score ?? "—"}
                            </div>
                            <div className="text-xs text-zinc-500">/ {score?.breakdown?.max_possible ?? 100}</div>
                        </div>
                        <div className="text-[10px] uppercase tracking-widest text-zinc-500 mt-1">
                            {score?.breakdown && `${score.breakdown.rule_score} rules + ${score.breakdown.ai_fit_score} AI fit`}
                        </div>
                        <div className="mt-4 border-t border-brand-line pt-3" data-testid="lead-score-factors">
                            {(score?.factors || []).map((f, i) => <Factor key={i} f={f} />)}
                            {!score?.factors?.length && <div className="text-xs text-zinc-500">No factors yet — refresh to compute.</div>}
                        </div>
                    </div>
                </div>

                {/* Right: timeline + notes */}
                <div className="lg:col-span-2 space-y-4">
                    <div className="rounded-lg border border-brand-line bg-white p-5" data-testid="notes-card">
                        <div className="flex items-center gap-2 text-sm font-medium mb-2">
                            <StickyNote className="w-4 h-4" /> Add a note
                        </div>
                        <Textarea rows={3} value={newNote} onChange={(e) => setNewNote(e.target.value)}
                                  placeholder="What did you learn?" data-testid="new-note-input" />
                        <div className="flex justify-end mt-2">
                            <Button size="sm" onClick={addNote} data-testid="save-note-btn">Save note</Button>
                        </div>
                    </div>

                    <div className="rounded-lg border border-brand-line bg-white p-5">
                        <div className="text-sm font-medium mb-3">Timeline</div>
                        <ol className="space-y-3" data-testid="contact-timeline">
                            {timeline.map((t) => (
                                <li key={t.id} className="flex gap-3" data-testid={`timeline-${t.id}`}>
                                    <div className="w-2 h-2 rounded-full bg-brand-copper mt-2" />
                                    <div className="flex-1">
                                        <div className="text-[10px] uppercase tracking-widest text-brand-copper">{t.type.replace(/_/g," ")}</div>
                                        <div className="text-sm mt-0.5">{t.summary}</div>
                                        <div className="text-[10px] text-zinc-500 font-mono mt-0.5">{t.created_at}</div>
                                    </div>
                                </li>
                            ))}
                            {!timeline.length && <div className="text-xs text-zinc-500">No activity yet.</div>}
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    );
}
