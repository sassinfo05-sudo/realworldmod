"""Pytest shared fixtures — credentials resolved from env / test_credentials.md (never hardcoded)."""
import asyncio

import pytest

from tests import _creds


# ---------------------------------------------------------------------------
# Harness-only: give every test a FRESH asyncio event loop and rebind the
# global motor client to it. Tests that drive the async services directly
# (atomic metering, reservation concurrency, domain providers) call
# `asyncio.get_event_loop().run_until_complete(...)`; motor's AsyncIOMotorClient
# is a process-global bound to whatever loop was current at first use. Without
# this, the second such test reuses a closed loop → "RuntimeError: Event loop
# is closed". This changes nothing in production (the app owns its own loop).
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _fresh_event_loop():
    try:
        import app.db as _appdb
    except Exception:  # noqa: BLE001 — requests-only tests don't import app.db
        _appdb = None
    if _appdb is not None:
        _appdb._mongo_client = None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        yield
    finally:
        try:
            loop.close()
        except Exception:  # noqa: BLE001
            pass
        if _appdb is not None:
            _appdb._mongo_client = None


@pytest.fixture(scope="session")
def base_url():
    return _creds.BASE_URL


@pytest.fixture(scope="session")
def api_url():
    return _creds.API


@pytest.fixture(scope="session")
def owner_creds():
    return {"email": _creds.OWNER_EMAIL, "password": _creds.OWNER_PASSWORD}


@pytest.fixture(scope="session")
def founder_creds():
    return {"email": _creds.FOUNDER_EMAIL, "password": _creds.FOUNDER_PASSWORD}


# ---------------------------------------------------------------------------
# Harness-only: give every test MODULE its own synthetic client IP (X-Forwarded-For).
# The production login limiter (10 attempts / 5 min per IP, in-process + Mongo-backed) is a
# security control we WANT; without this, ~20 modules logging in from one IP trip it and the
# suite reports false failures. Behind the real proxy X-Forwarded-For is set by the ingress, so
# this changes nothing in production.
# ---------------------------------------------------------------------------
import secrets as _secrets  # noqa: E402

import requests as _requests  # noqa: E402

_ORIG_REQUEST = _requests.Session.request
_MODULE_IPS: dict = {}


def _module_ip():
    import inspect
    for fr in inspect.stack():
        mod = fr.frame.f_globals.get("__name__", "")
        if mod.startswith("test_") or mod.startswith("tests."):
            return _MODULE_IPS.setdefault(mod, f"10.200.{_secrets.randbelow(250)}.{_secrets.randbelow(250)}")
    return _MODULE_IPS.setdefault("__default__", f"10.201.{_secrets.randbelow(250)}.{_secrets.randbelow(250)}")


def _patched_request(self, method, url, **kwargs):
    headers = dict(kwargs.get("headers") or {})
    if not any(k.lower() == "x-forwarded-for" for k in headers):
        headers["X-Forwarded-For"] = _module_ip()
    kwargs["headers"] = headers
    return _ORIG_REQUEST(self, method, url, **kwargs)


_requests.Session.request = _patched_request
