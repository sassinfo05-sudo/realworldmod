"""Revenue OS Phase 1 rebrand + regression tests."""
import os
import time
import uuid
import pytest
import requests
from tests import _creds as _CREDS  # creds from env / test_credentials.md

BASE_URL = _CREDS.BASE_URL
API = _CREDS.API

FOUNDER_EMAIL = _CREDS.FOUNDER_EMAIL
FOUNDER_PW = _CREDS.FOUNDER_PASSWORD
OWNER_EMAIL = _CREDS.OWNER_EMAIL
OWNER_PW = _CREDS.OWNER_PASSWORD


# --- Brand / meta endpoints ---
class TestBrandAndMeta:
    def test_root(self):
        r = requests.get(f"{API}/")
        assert r.status_code == 200
        assert r.json().get("service") == "zanelvo" and r.json().get("status") == "ok"

    def test_brand(self):
        r = requests.get(f"{API}/brand")
        assert r.status_code == 200
        d = r.json()
        assert d["name"] == "Zanelvo"
        assert d["status"] == "provisional_pending_registration"
        assert "quiet operating system" in d["tagline"].lower()
        assert d.get("logo_svg", "") or d.get("name") == "Zanelvo"

    def test_openapi(self):
        r = requests.get(f"{API}/openapi.json")
        assert r.status_code == 200
        d = r.json()
        assert d["info"]["title"] == "Zanelvo API"
        api_paths = [p for p in d["paths"] if p.startswith("/api/")]
        assert len(api_paths) >= 20, f"Expected 20+ /api/ paths, got {len(api_paths)}"


# --- Auth: new creds work, old ones do not ---
class TestAuth:
    def test_founder_login(self):
        r = requests.post(f"{API}/auth/login", json={"email": FOUNDER_EMAIL, "password": FOUNDER_PW})
        assert r.status_code == 200, r.text
        tok = r.json()["access_token"]
        me = requests.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {tok}"})
        assert me.status_code == 200
        j = me.json()
        assert j["email"] == FOUNDER_EMAIL
        assert j.get("org_id") in (None, "")

    def test_owner_login(self):
        r = requests.post(f"{API}/auth/login", json={"email": OWNER_EMAIL, "password": OWNER_PW})
        assert r.status_code == 200, r.text
        tok = r.json()["access_token"]
        me = requests.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {tok}"})
        assert me.status_code == 200
        assert me.json()["email"] == OWNER_EMAIL
        assert me.json().get("org_id")

    def test_old_founder_rejected(self):
        r = requests.post(f"{API}/auth/login", json={"email": "founder@onvara.com", "password": "anything"})
        assert r.status_code == 401

    def test_old_owner_rejected(self):
        r = requests.post(f"{API}/auth/login", json={"email": "owner@demo.onvara.com", "password": "anything"})
        assert r.status_code == 401


# --- Pricing plans (still 5) ---
class TestPricing:
    def test_plans(self):
        r = requests.get(f"{API}/plans")
        assert r.status_code == 200
        plans = r.json()
        names = [p.get("name", "").lower() for p in plans]
        for want in ["free", "starter", "business", "commerce", "scale"]:
            assert any(want in n for n in names), f"missing plan {want} in {names}"
        # Revenue OS subdomain string should appear in at least one plan's features
        all_feats = " ".join(f for p in plans for f in (p.get("features") or []))
        assert "zanelvo.com/site" in all_feats, f"site address not found in any plan: {all_feats}"


# --- Tenant isolation via fresh signups ---
def _signup(email, industry="plumbing"):
    r = requests.post(f"{API}/auth/signup", json={
        "email": email,
        "password": "TestPass!23",
        "business_name": f"Biz {email}",
    })
    return r


class TestTenantIsolation:
    def test_isolation(self):
        e1 = f"iso1_{uuid.uuid4().hex[:8]}@example.com"
        e2 = f"iso2_{uuid.uuid4().hex[:8]}@example.com"
        r1 = _signup(e1)
        r2 = _signup(e2)
        assert r1.status_code in (200, 201), r1.text
        assert r2.status_code in (200, 201), r2.text
        t1 = r1.json().get("access_token") or requests.post(f"{API}/auth/login", json={"email": e1, "password": "TestPass!23"}).json()["access_token"]
        t2 = r2.json().get("access_token") or requests.post(f"{API}/auth/login", json={"email": e2, "password": "TestPass!23"}).json()["access_token"]

        # each user should be able to access their own resources
        h1 = {"Authorization": f"Bearer {t1}"}
        h2 = {"Authorization": f"Bearer {t2}"}
        # cross-tenant lookup by id if endpoint accepts an id param — we test list-scope isolation
        p1 = requests.get(f"{API}/business-profile", headers=h1)
        p2 = requests.get(f"{API}/business-profile", headers=h2)
        assert p1.status_code in (200, 404)
        assert p2.status_code in (200, 404)
        if p1.status_code == 200 and p2.status_code == 200:
            assert p1.json() != p2.json()


# --- Phase 1 happy path (interview -> LLM generation -> fact review) ---
PLUMBER_ANSWERS = {
    "business_name": "Revenue OS Test Plumbing",
    "industry": "plumbing",
    "services_text": "Leak repair — 24/7 callout — $180 first hour\nDrain unblock — most in one visit — $220\nWater heater install — includes haul-away — from $1200",
    "service_area": "Austin, Round Rock — (512) 555-1234",
    "hours_text": "Mon-Fri 8am-6pm, Sat 9am-2pm. 24/7 emergency.",
    "differentiators": "Licensed & insured 18 years\nFlat-rate quotes\nSame-day service",
    "tone": "trusted_neighbor",
    "goals": ["get_calls", "book_jobs"],
    "contact_email": "hello@example.com",
    "contact_phone": "(512) 555-1234",
    "color_pref": "warm",
}

SALON_ANSWERS = {**PLUMBER_ANSWERS,
                 "business_name": "Revenue OS Test Salon",
                 "industry": "hair_salon",
                 "services_text": "Cut — modern styles — $65\nColor — single-process — $120\nBalayage — full head — from $220",
                 "differentiators": "Master colorist\nOrganic products\nNo double-booking"}


def _do_onboarding(token, answers):
    h = {"Authorization": f"Bearer {token}"}
    # init session
    init = requests.get(f"{API}/onboarding/session", headers=h)
    assert init.status_code in (200, 201), f"init session -> {init.status_code} {init.text[:200]}"
    for field, value in answers.items():
        r = requests.patch(f"{API}/onboarding/session/answer",
                           json={"field": field, "value": value}, headers=h)
        assert r.status_code in (200, 204), f"answer {field} -> {r.status_code} {r.text[:200]}"
    gen = requests.post(f"{API}/onboarding/generate", headers=h)
    assert gen.status_code in (200, 201, 202), f"generate -> {gen.status_code} {gen.text[:300]}"
    # poll status
    ready = False
    last = None
    for _ in range(60):
        s = requests.get(f"{API}/onboarding/session/status", headers=h)
        last = s
        if s.status_code == 200:
            data = s.json()
            st = (data.get("status") or data.get("state") or "").lower()
            if st in ("ready", "complete", "done", "generated", "success"):
                ready = True
                break
        time.sleep(2)
    return ready, last, h


class TestPhase1HappyPath:
    def test_plumber_flow(self):
        email = f"pl_{uuid.uuid4().hex[:8]}@example.com"
        r = _signup(email, industry="plumbing")
        assert r.status_code in (200, 201), r.text
        tok = r.json()["access_token"]
        ready, last, h = _do_onboarding(tok, PLUMBER_ANSWERS)
        assert ready, f"not ready: {last.status_code} {last.text[:300]}"
        # Website blocks
        w = requests.get(f"{API}/website", headers=h)
        assert w.status_code == 200, w.text[:300]
        wj = w.json()
        assert wj, "empty website payload"

    def test_salon_flow_variant(self):
        email = f"sa_{uuid.uuid4().hex[:8]}@example.com"
        r = _signup(email, industry="hair_salon")
        assert r.status_code in (200, 201), r.text
        tok = r.json()["access_token"]
        ready, last, h = _do_onboarding(tok, SALON_ANSWERS)
        assert ready, f"not ready: {last.status_code} {last.text[:300]}"
