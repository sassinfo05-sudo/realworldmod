"""Business profile: read + patch (fact correction)."""
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import BusinessProfile, User

router = APIRouter(prefix="/business-profile", tags=["business-profile"])


@router.get("")
async def get_profile(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.business_profiles.find_one({"org_id": org_id})
    if not doc:
        raise HTTPException(status_code=404, detail="No profile yet")
    return BusinessProfile.from_mongo(doc).model_dump()


class ProfilePatch(BaseModel):
    """Patch a single field or list of fact objects. Server marks touched facts verified=True."""
    field: str  # dotted: "business_name" | "services" | "hours" | "locations" | "differentiators" | "policies" | "about" | "tagline" | "contact_email" | "contact_phone"
    value: Any


VERIFIABLE_LIST_FIELDS = {"services", "hours", "locations", "differentiators", "policies"}
SCALAR_FIELDS = {"business_name", "about", "tagline", "contact_email", "contact_phone", "tone"}


@router.patch("")
async def patch_profile(patch: ProfilePatch,
                         user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    if patch.field not in VERIFIABLE_LIST_FIELDS and patch.field not in SCALAR_FIELDS:
        raise HTTPException(status_code=400, detail=f"Unknown field: {patch.field}")

    db = get_db()
    doc = await db.business_profiles.find_one({"org_id": org_id})
    if not doc:
        raise HTTPException(status_code=404, detail="No profile yet")

    value = patch.value
    if patch.field in VERIFIABLE_LIST_FIELDS and isinstance(value, list):
        for item in value:
            if isinstance(item, dict):
                item["verified"] = True

    await db.business_profiles.update_one(
        {"_id": doc["_id"]},
        {"$set": {patch.field: value, "updated_at": utc_now_iso()}},
    )
    fresh = await db.business_profiles.find_one({"_id": doc["_id"]})
    return BusinessProfile.from_mongo(fresh).model_dump()


class VerifyReq(BaseModel):
    field: str  # e.g. "services"
    item_id: str


@router.post("/verify-item")
async def verify_item(req: VerifyReq,
                       user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    if req.field not in VERIFIABLE_LIST_FIELDS:
        raise HTTPException(status_code=400, detail="Field is not a verifiable list")

    db = get_db()
    doc = await db.business_profiles.find_one({"org_id": org_id})
    if not doc:
        raise HTTPException(status_code=404, detail="No profile yet")

    items = doc.get(req.field, [])
    found = False
    for it in items:
        if it.get("id") == req.item_id:
            it["verified"] = True
            found = True
            break
    if not found:
        raise HTTPException(status_code=404, detail="Item not found")

    await db.business_profiles.update_one(
        {"_id": doc["_id"]},
        {"$set": {req.field: items, "updated_at": utc_now_iso()}},
    )
    return {"ok": True}
