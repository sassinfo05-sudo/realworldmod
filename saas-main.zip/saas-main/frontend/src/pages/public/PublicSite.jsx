import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "@/lib/api";
import LanguageSwitcher from "@/components/public/LanguageSwitcher";
import BlockRenderer from "@/components/BlockRenderer";
import DynamicCollectionPage from "@/pages/public/DynamicCollectionPage";
import { useBrand } from "@/context/BrandContext";
import { letterFavicon } from "@/hooks/usePageMeta";
import MaintenancePage from "@/pages/public/MaintenancePage";
import { captureAttribution, getAttribution } from "@/lib/attribution";

/** Round 11 — structured data. Emits one <script type="application/ld+json" id="zv-jsonld"> per page view,
 *  built ONLY from content the owner published (no invented ratings/prices). */
export function buildJsonLd(site, page, url) {
    if (!site || !page) return [];
    const blocks = page.blocks || [];
    const contact = blocks.find((b) => b.type === "contact_hours")?.props || {};
    const footer = blocks.find((b) => b.type === "footer")?.props || {};
    const biz = {
        "@context": "https://schema.org", "@type": "LocalBusiness",
        name: site.business_name || page.title, url,
        description: site.tagline || undefined,
        telephone: contact.phone || footer.phone || undefined,
        email: contact.email || footer.email || undefined,
        address: contact.address ? { "@type": "PostalAddress", streetAddress: contact.address } : undefined,
    };
    const out = [biz];
    const faqs = blocks.filter((b) => b.type === "faq").flatMap((b) => b.props?.items || []).filter((i) => i?.question && i?.answer);
    if (faqs.length) out.push({ "@context": "https://schema.org", "@type": "FAQPage",
        mainEntity: faqs.map((i) => ({ "@type": "Question", name: i.question, acceptedAnswer: { "@type": "Answer", text: i.answer } })) });
    const services = blocks.filter((b) => b.type === "services_grid").flatMap((b) => b.props?.services || []).filter((sv) => sv?.name);
    if (services.length) out.push({ "@context": "https://schema.org", "@type": "ItemList",
        itemListElement: services.map((sv, i) => ({ "@type": "ListItem", position: i + 1,
            item: { "@type": "Service", name: sv.name, description: sv.description || undefined, provider: { "@type": "LocalBusiness", name: site.business_name || "" } } })) });
    return out.map((o) => JSON.parse(JSON.stringify(o))); // strip undefined
}

export function setJsonLd(schemas, id = "zv-jsonld") {
    let el = document.getElementById(id);
    if (!schemas || !schemas.length) { if (el) el.remove(); return; }
    if (!el) { el = document.createElement("script"); el.type = "application/ld+json"; el.id = id; document.head.appendChild(el); }
    el.textContent = JSON.stringify(schemas.length === 1 ? schemas[0] : schemas);
}

function setSeo(title, description, socialImage, favicon) {
    if (title) document.title = title;
    const setMeta = (name, content) => {
        if (!content) return;
        let m = document.querySelector(`meta[name="${name}"]`);
        if (!m) { m = document.createElement("meta"); m.setAttribute("name", name); document.head.appendChild(m); }
        m.setAttribute("content", content);
    };
    const setOG = (property, content) => {
        if (!content) return;
        let m = document.querySelector(`meta[property="${property}"]`);
        if (!m) { m = document.createElement("meta"); m.setAttribute("property", property); document.head.appendChild(m); }
        m.setAttribute("content", content);
    };
    if (description) setMeta("description", description);
    if (title) setOG("og:title", title);
    if (description) setOG("og:description", description);
    if (socialImage) setOG("og:image", socialImage);
    if (favicon) {
        let l = document.querySelector("link[rel~='icon']");
        if (!l) { l = document.createElement("link"); l.setAttribute("rel", "icon"); document.head.appendChild(l); }
        l.setAttribute("href", favicon.trim().startsWith("<svg") ? `data:image/svg+xml;utf8,${encodeURIComponent(favicon)}` : favicon);
    }
}

// Idempotent pixel loaders — each keyed by data-attr so hot-reload doesn't stack scripts.
function loadPixels(pixels) {
    if (!pixels) return;
    const inject = (id, html) => {
        if (document.querySelector(`[data-pixel="${id}"]`)) return;
        const wrapper = document.createElement("div");
        wrapper.setAttribute("data-pixel", id);
        wrapper.innerHTML = html;
        // Re-create scripts so they actually execute (innerHTML doesn't run them).
        wrapper.querySelectorAll("script").forEach((old) => {
            const s = document.createElement("script");
            for (const a of old.attributes) s.setAttribute(a.name, a.value);
            s.text = old.text;
            old.replaceWith(s);
        });
        document.head.appendChild(wrapper);
    };
    if (pixels.gtm_id) {
        inject("gtm", `
            <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
            var f=d.getElementsByTagName(s)[0],j=d.createElement(s);j.async=true;
            j.src='https://www.googletagmanager.com/gtm.js?id='+i;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','${pixels.gtm_id}');</script>`);
    }
    if (pixels.ga4_id) {
        inject("ga4", `
            <script async src="https://www.googletagmanager.com/gtag/js?id=${pixels.ga4_id}"></script>
            <script>window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);} gtag('js', new Date());
            gtag('config', '${pixels.ga4_id}');</script>`);
    }
    if (pixels.meta_pixel_id) {
        inject("meta", `
            <script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
            n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '${pixels.meta_pixel_id}'); fbq('track', 'PageView');</script>`);
    }
    if (pixels.tiktok_pixel_id) {
        inject("tiktok", `
            <script>!function (w, d, t) { w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];
            ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"];
            ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};
            for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);
            ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";
            ttq._i=ttq._i||{};ttq._i[e]=[];ttq._i[e]._u=i;ttq._t=ttq._t||{};ttq._t[e]=+new Date;
            ttq._o=ttq._o||{};ttq._o[e]=n||{};var o=document.createElement("script");
            o.type="text/javascript";o.async=!0;o.src=i+"?sdkid="+e+"&lib="+t;
            var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};
            ttq.load('${pixels.tiktok_pixel_id}');ttq.page();}(window, document, 'ttq');</script>`);
    }
    if (pixels.hotjar_id) {
        inject("hotjar", `
            <script>(function(h,o,t,j,a,r){h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:${pixels.hotjar_id},hjsv:6};a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;a.appendChild(r);
            })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');</script>`);
    }
    if (pixels.linkedin_partner_id) {
        inject("linkedin", `
            <script>_linkedin_partner_id="${pixels.linkedin_partner_id}";window._linkedin_data_partner_ids=window._linkedin_data_partner_ids||[];window._linkedin_data_partner_ids.push(_linkedin_partner_id);
            (function(l){if(!l){window.lintrk=function(a,b){window.lintrk.q.push([a,b])};window.lintrk.q=[]}
            var s=document.getElementsByTagName("script")[0];var b=document.createElement("script");b.type="text/javascript";b.async=true;
            b.src="https://snap.licdn.com/li.lms-analytics/insight.min.js";s.parentNode.insertBefore(b,s);})(window.lintrk);</script>`);
    }
    if (pixels.pinterest_tag_id) {
        inject("pinterest", `
            <script>!function(e){if(!window.pintrk){window.pintrk = function () {window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var n=window.pintrk;n.queue=[],n.version="3.0";var t=document.createElement("script");t.async=!0,t.src=e;var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(t,r)}}("https://s.pinimg.com/ct/core.js");
            pintrk('load', '${pixels.pinterest_tag_id}');pintrk('page');</script>`);
    }
    // NOTE: arbitrary `custom_head_html` injection was removed (XSS risk). Only the
    // validated analytics pixels above are supported.
}

function trackPageview(slug, pageSlug) {
    const attribution = captureAttribution();
    fetch(`${process.env.REACT_APP_BACKEND_URL}/api/analytics/track`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ website_slug: slug, kind: "pageview", page_slug: pageSlug, meta: { attribution } }),
        keepalive: true,
    }).catch(() => {});
}

function trackCtaClick(slug, pageSlug, label, href, blockId) {
    fetch(`${process.env.REACT_APP_BACKEND_URL}/api/analytics/track`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ website_slug: slug, kind: "cta_click", page_slug: pageSlug,
            meta: { label: (label || "").slice(0, 80), href: (href || "").slice(0, 200), block_id: blockId || "", attribution: getAttribution() } }),
        keepalive: true,
    }).catch(() => {});
}

export default function PublicSite() {
    const { slug, pageSlug } = useParams();
    const navigate = useNavigate();
    const brand = useBrand();
    const [site, setSite] = useState(null);
    const siteRootRef = useRef(null);
    const [page, setPage] = useState(null);
    // Round 11 — CTA click tracking (delegated; hero / cta_band / pricing / services links + buttons only)
    useEffect(() => {
        const root = siteRootRef.current;
        if (!root || !page) return undefined;
        const handler = (e) => {
            const el = e.target?.closest?.("a, button");
            if (!el) return;
            const blockEl = el.closest("[data-block-type]");
            const type = blockEl?.getAttribute("data-block-type");
            if (!["hero", "cta_band", "pricing_table", "services_grid", "contact_hours", "store", "booking"].includes(type)) return;
            trackCtaClick(slug, page.slug, el.textContent, el.getAttribute("href"), blockEl?.getAttribute("data-block-id"));
        };
        root.addEventListener("click", handler);
        return () => root.removeEventListener("click", handler);
    }, [slug, page]);
    const [maintenance, setMaintenance] = useState(null);
    const [reloadKey, setReloadKey] = useState(0);
    const [error, setError] = useState(null);
    const [passwordOk, setPasswordOk] = useState(false);
    const [pwd, setPwd] = useState("");
    const [pwError, setPwError] = useState(false);
    const [notAPage, setNotAPage] = useState(false);
    const active = pageSlug || "home";

    useEffect(() => {
        (async () => {
            try {
                const unlock = sessionStorage.getItem(`zanelvo.unlock.${slug}`) || "";
                const { data } = await api.get(`/public/sites/${slug}`, { params: unlock ? { unlock } : {} });
                if (data.redirect_to) {
                    navigate(`/site/${data.redirect_to}${pageSlug ? `/${pageSlug}` : ""}`, { replace: true });
                    return;
                }
                if (data.maintenance) {
                    setMaintenance(data);
                    document.title = `${data.title} — ${data.business_name || ""}`;
                    return;
                }
                setMaintenance(null);
                setSite(data);
                loadPixels(data.pixels);
            } catch (e) {
                setError(e?.response?.status === 404 ? "notfound" : "error");
            }
        })();
    }, [slug, pageSlug, navigate, reloadKey]);

    useEffect(() => {
        if (!site) return;
        const exact = site.pages.find((x) => x.slug === active);
        // A pageSlug that matches no real page may be a dynamic CMS route (list/directory).
        if (pageSlug && !exact) { setNotAPage(true); return; }
        setNotAPage(false);
        const p = exact || site.pages[0];
        const enriched = p ? {
            ...p,
            blocks: (p.blocks || []).map((b) =>
                ["form", "store", "booking"].includes(b.type)
                    ? { ...b, props: { ...(b.props || {}), website_slug: slug, page_slug: p.slug } }
                    : b
            ),
        } : null;
        setPage(enriched);
        if (p) {
            const seo = p.seo || {};
            const defaults = site.seo_defaults || {};
            const tpl = defaults.title_template || `{page} — ${site.business_name}`;
            const computed = tpl.replace("{page}", p.title).replace("{site}", site.business_name);
            setSeo(seo.title || computed,
                     seo.description || defaults.description || site.tagline,
                     seo.social_image || defaults.og_image,
                     defaults.favicon_url || letterFavicon(site.business_name || p.title, site.theme?.primary));
            // robots meta
            const robots = document.querySelector("meta[name='robots']") || (() => {
                const m = document.createElement("meta"); m.setAttribute("name", "robots"); document.head.appendChild(m); return m;
            })();
            robots.setAttribute("content", site.allow_indexing === false ? "noindex, nofollow" : "index, follow");
            try { setJsonLd(buildJsonLd(site, p, window.location.href)); } catch { /* non-fatal */ }
            trackPageview(slug, p.slug);
            const protectedPage = !!(seo.password_protected || p.locked);
            if (!protectedPage) {
                setPasswordOk(true);
            } else {
                // Try a previously stored per-page unlock token.
                const stored = sessionStorage.getItem(`zanelvo.punlock.${slug}.${p.slug}`) || "";
                if (stored) {
                    api.get(`/public/sites/${slug}/pages/${p.slug}`, { params: { unlock: stored } })
                        .then(({ data }) => {
                            if (data?.page && !data.page.locked) {
                                setPage((cur) => ({ ...(cur || {}), ...data.page,
                                    blocks: (data.page.blocks || []).map((b) =>
                                        ["form", "store", "booking"].includes(b.type)
                                            ? { ...b, props: { ...(b.props || {}), website_slug: slug, page_slug: p.slug } }
                                            : b) }));
                                setPasswordOk(true);
                            } else {
                                setPasswordOk(false);
                            }
                        })
                        .catch(() => setPasswordOk(false));
                } else {
                    setPasswordOk(false);
                }
            }
        }
    }, [site, active, slug]);

    async function submitPagePassword(e) {
        e.preventDefault();
        setPwError(false);
        try {
            const { data } = await api.post(`/public/sites/${slug}/pages/${active}/unlock`, { password: pwd });
            const token = data?.unlock_token;
            if (!token) { setPasswordOk(true); return; }
            sessionStorage.setItem(`zanelvo.punlock.${slug}.${active}`, token);
            const res = await api.get(`/public/sites/${slug}/pages/${active}`, { params: { unlock: token } });
            if (res.data?.page) {
                const p = res.data.page;
                setPage((cur) => ({ ...(cur || {}), ...p,
                    blocks: (p.blocks || []).map((b) =>
                        ["form", "store", "booking"].includes(b.type)
                            ? { ...b, props: { ...(b.props || {}), website_slug: slug, page_slug: p.slug } }
                            : b) }));
            }
            setPwd("");
            setPasswordOk(true);
        } catch (err) {
            setPwError(true);
        }
    }

    if (maintenance) return <MaintenancePage data={maintenance} slug={slug} onUnlocked={() => setReloadKey((k) => k + 1)} />;

    if (error === "notfound") return (
        <div className="min-h-screen flex items-center justify-center bg-brand-surface p-6">
            <div className="max-w-md text-center">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">404</div>
                <h1 className="font-display text-3xl text-brand-ink">This site isn't published.</h1>
                <p className="mt-3 text-zinc-600">The address might be wrong or the owner un-published.</p>
            </div>
        </div>
    );
    if (error) return <div className="min-h-screen flex items-center justify-center text-zinc-500">Couldn't load this site.</div>;
    if (site && notAPage) return <DynamicCollectionPage mode="list" />;
    if (!site || !page) return <div className="min-h-screen flex items-center justify-center text-zinc-500">Loading…</div>;

    if (!passwordOk) {
        return (
            <div className="min-h-screen flex items-center justify-center p-6">
                <form className="max-w-sm w-full rounded-2xl border border-brand-line bg-white p-6 shadow-sm"
                      onSubmit={submitPagePassword}
                      data-testid="site-password-form">
                    <div className="text-xs uppercase tracking-widest text-brand-copper">Password required</div>
                    <h1 className="font-display text-2xl mt-1">{page.title}</h1>
                    <input type="password" value={pwd} onChange={(e) => { setPwd(e.target.value); setPwError(false); }}
                           className="mt-4 w-full border border-brand-line rounded-md px-3 py-2"
                           placeholder="Enter page password" data-testid="site-password-input" />
                    {pwError && <p className="mt-2 text-sm text-red-600" data-testid="site-password-error">Incorrect password. Please try again.</p>}
                    <button className="mt-3 w-full bg-brand-ink text-white rounded-md py-2 text-sm" type="submit">Unlock</button>
                </form>
            </div>
        );
    }

    const brandName = brand?.name || "Zanelvo";
    const brandUrl = brand?.product_url || "/";

    return (
        <div className="min-h-screen" data-testid="public-site" ref={siteRootRef}
             data-site-fp={site.site_fingerprint /* anti-clone marker */}>
            {/* Simple public nav */}
            <nav className="border-b border-brand-line bg-white/95 backdrop-blur-md sticky top-0 z-10">
                <div className="mx-auto max-w-6xl px-6 h-14 flex items-center justify-between">
                    <a href={`/site/${slug}`} className="flex items-center gap-2.5 group" data-testid="public-site-logo">
                        {site.theme?.logo_image ? (
                            <img src={site.theme.logo_image} alt={site.business_name || "Logo"}
                                 className={`h-9 w-auto object-contain logo-intro logo-intro-${site.theme?.logo_animation || "none"}`}
                                 data-testid="public-logo-image" />
                        ) : site.theme?.logo_svg ? (
                            <span className={`h-9 flex items-center [&_svg]:h-9 [&_svg]:w-auto logo-intro logo-intro-${site.theme?.logo_animation || "none"}`}
                                  dangerouslySetInnerHTML={{ __html: site.theme.logo_svg }} data-testid="public-logo-svg" />
                        ) : (
                            <span className="font-display text-lg font-semibold text-brand-ink">{site.business_name}</span>
                        )}
                    </a>
                    <div className="flex items-center gap-6 text-sm text-zinc-600">
                        {site.nav_order.map((s) => {
                            const target = s === "home" ? `/site/${slug}` : `/site/${slug}/${s}`;
                            const pg = site.pages.find((p) => p.slug === s);
                            return (
                                <a key={s} href={target}
                                   className={s === active ? "text-brand-ink font-medium" : "hover:text-brand-ink"}
                                   data-testid={`public-nav-${s}`}>
                                    {pg?.title || s}
                                </a>
                            );
                        })}
                        {site.org_id && <LanguageSwitcher orgId={site.org_id} containerRef={siteRootRef} />}
                    </div>
                </div>
            </nav>
            <BlockRenderer page={page} theme={site.theme} testidPrefix="public-block" />
            {site.show_platform_branding && (
                <footer className="border-t border-brand-line bg-white py-6 text-center text-xs text-zinc-500" data-testid="public-site-branding-footer">
                    <a href={brandUrl} target="_blank" rel="noreferrer" className="hover:text-brand-ink" data-testid="public-site-branding-link">
                        Powered by <span className="font-medium text-brand-ink">{brandName}</span>
                    </a>
                </footer>
            )}
        </div>
    );
}
