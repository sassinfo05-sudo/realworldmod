"""Mongo-backed distributed leader lock.

Recurring background jobs (scheduled email, workflow scheduler, abandoned-cart sweep,
subscription renewal) must run as a SINGLETON across every web replica and the dedicated
worker — otherwise N replicas fire the same job N times. This TTL lock lets exactly one
process win leadership and renew it; if the leader dies, the TTL lapses and another process
takes over. Combined with the per-job idempotency guards this makes recurring work
restart-safe and duplicate-safe.

Usage:
    from app.services import leader_lock
    if await leader_lock.acquire("schedulers"):
        # start the loops; also start leader_lock.maintain("schedulers") to renew.
"""
from __future__ import annotations

import asyncio
import logging
import os
import socket
import uuid
from datetime import datetime, timedelta, timezone

from ..db import get_db

logger = logging.getLogger("app.leader_lock")

LOCK_COLL = "leader_locks"
INSTANCE_ID = f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:6]}"
_held: dict[str, bool] = {}


def _now():
    return datetime.now(timezone.utc)


async def acquire(name: str, ttl_s: int = 90) -> bool:
    """Try to become leader for `name`. Returns True if this instance holds the lock.

    Wins when: the lock is unheld/expired, or already held by THIS instance (renewal).
    """
    db = get_db()
    now = _now()
    expiry = (now + timedelta(seconds=ttl_s)).isoformat()
    now_iso = now.isoformat()
    # Atomic: only update if expired or already ours.
    res = await db[LOCK_COLL].find_one_and_update(
        {"_id": name, "$or": [{"expires_at": {"$lt": now_iso}}, {"holder": INSTANCE_ID}]},
        {"$set": {"holder": INSTANCE_ID, "expires_at": expiry, "renewed_at": now_iso}},
        return_document=True,
    )
    if res:
        _held[name] = True
        return True
    # No existing/expired doc matched — try to create it (first-ever acquisition).
    try:
        await db[LOCK_COLL].insert_one(
            {"_id": name, "holder": INSTANCE_ID, "expires_at": expiry, "renewed_at": now_iso})
        _held[name] = True
        return True
    except Exception:  # duplicate key → someone else holds a live lock
        _held[name] = False
        return False


def is_leader(name: str) -> bool:
    return bool(_held.get(name))


async def maintain(name: str, renew_s: int = 30, ttl_s: int = 90) -> None:
    """Background task: keep renewing leadership. If we ever lose it, keep trying to re-acquire
    so a recovered/faster instance can take over cleanly."""
    while True:
        try:
            await acquire(name, ttl_s)
        except Exception as e:  # noqa: BLE001
            logger.warning("leader_lock maintain(%s) error: %s", name, e)
            _held[name] = False
        await asyncio.sleep(renew_s)
