import { useEffect, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { Swords, Lock } from "lucide-react";

const TONE = {
    live: "bg-emerald-500/20 text-emerald-200 border-emerald-400/40",
    partial: "bg-amber-500/20 text-amber-200 border-amber-400/40",
    sandbox: "bg-sky-500/20 text-sky-200 border-sky-400/40",
    planned: "bg-white/5 text-white/60 border-white/15",
    no: "bg-red-500/15 text-red-200 border-red-400/30",
    "n/a": "bg-white/5 text-white/40 border-white/10",
};

function Cell({ v }) {
    const cls = TONE[v] || "bg-white/5 text-white/80 border-white/15";
    return <span className={`inline-block rounded-md border px-2 py-0.5 text-xs ${cls}`}>{v}</span>;
}

export default function StaffCompetitive() {
    const [data, setData] = useState(null);
    useEffect(() => {
        api.get("/staff/competitive").then((r) => setData(r.data))
            .catch((e) => toast.error(e?.response?.data?.detail || "Cannot load"));
    }, []);
    if (!data) return <div className="p-6 text-zinc-500">Loading…</div>;
    const areas = [...new Set(data.rows.map((r) => r.area))];
    return (
        <div className="px-4 md:px-8 py-6 max-w-7xl mx-auto" data-testid="staff-competitive"><div className="rounded-2xl bg-[#0d1017] text-white p-6 space-y-6 shadow-lg">
            <div>
                <h1 className="text-2xl font-semibold flex items-center gap-2"><Swords className="w-6 h-6 text-fuchsia-400" /> Competitive positioning</h1>
                <p className="text-white/50 text-sm mt-1 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5" /> Internal only — competitor names never appear on customer-facing pages.
                    Zanelvo: {data.summary.live} live · {data.summary.partial_or_sandbox} partial/sandbox of {data.summary.total}.
                </p>
            </div>

            <div className="rounded-xl border border-white/10 bg-white/5 p-5 text-sm space-y-3">
                <p className="text-white/90">{data.positioning.one_liner}</p>
                <div className="grid md:grid-cols-2 gap-4">
                    <div>
                        <div className="text-emerald-300 text-xs uppercase tracking-widest mb-1">Where we win</div>
                        <ul className="list-disc pl-5 text-white/70 space-y-1">{data.positioning.where_we_win.map((t, i) => <li key={i}>{t}</li>)}</ul>
                    </div>
                    <div>
                        <div className="text-amber-300 text-xs uppercase tracking-widest mb-1">Where we lag</div>
                        <ul className="list-disc pl-5 text-white/70 space-y-1">{data.positioning.where_we_lag.map((t, i) => <li key={i}>{t}</li>)}</ul>
                    </div>
                </div>
            </div>

            {areas.map((area) => (
                <div key={area} className="rounded-xl border border-white/10 bg-white/5 overflow-x-auto">
                    <div className="px-4 py-2 text-xs uppercase tracking-widest text-white/50 border-b border-white/10">{area}</div>
                    <table className="w-full text-sm">
                        <thead>
                            <tr className="text-left text-white/50 text-xs">
                                <th className="px-4 py-2 font-normal">Capability</th>
                                {data.competitors.map((c) => <th key={c} className={`px-3 py-2 font-normal ${c === "Zanelvo" ? "text-fuchsia-300" : ""}`}>{c}</th>)}
                            </tr>
                        </thead>
                        <tbody>
                            {data.rows.filter((r) => r.area === area).map((r, i) => (
                                <tr key={i} className="border-t border-white/5 align-top">
                                    <td className="px-4 py-2 text-white/85">{r.capability}{r.note && <div className="text-white/40 text-xs mt-0.5">{r.note}</div>}</td>
                                    {data.competitors.map((c) => <td key={c} className="px-3 py-2"><Cell v={r[c]} /></td>)}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ))}
            <div className="text-xs text-white/40">Rules: {data.positioning.rules.join(" · ")}</div>
        </div></div>
    );
}
