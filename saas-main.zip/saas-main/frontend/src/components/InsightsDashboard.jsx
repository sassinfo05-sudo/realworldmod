import { useEffect, useState } from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import api from "@/lib/api";

export const fmtValue = (v, format) => {
    if (v === null || v === undefined) return "—";
    if (format === "usd") return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: v % 1 ? 2 : 0 }).format(v);
    if (format === "pct") return `${v}%`;
    return new Intl.NumberFormat("en-US").format(v);
};

export function StatCard({ card, accent = "#4F46E5" }) {
    const d = card.delta_pct;
    const Trend = d === null || d === undefined ? Minus : d >= 0 ? ArrowUpRight : ArrowDownRight;
    const trendColor = d === null || d === undefined ? "text-zinc-400" : d >= 0 ? "text-emerald-600" : "text-red-600";
    return (
        <div className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-4 md:p-5 relative overflow-hidden group hover:shadow-[0_12px_30px_-16px_rgba(79,70,229,0.4)] transition-shadow" data-testid={`stat-${card.key}`}>
            <div className="absolute -right-6 -top-6 w-20 h-20 rounded-full opacity-[0.07] group-hover:opacity-[0.12] transition" style={{ background: accent }} />
            <div className="text-[11px] uppercase tracking-widest text-zinc-500">{card.label}</div>
            <div className="mt-2 font-display text-2xl md:text-3xl text-brand-ink dark:text-white tabular-nums">{fmtValue(card.value, card.format)}</div>
            <div className={`mt-1.5 text-xs flex items-center gap-1 ${trendColor}`}>
                <Trend className="w-3.5 h-3.5" />
                {d === null || d === undefined ? (card.hint || "no prior data") : `${d > 0 ? "+" : ""}${d}% vs previous period`}
            </div>
            {card.hint && d !== null && d !== undefined && <div className="text-[11px] text-zinc-400 mt-0.5 truncate">{card.hint}</div>}
        </div>
    );
}

export function TrendChart({ data = [], color = "#4F46E5", format = "int", height = 220, kind = "area", label = "" }) {
    const Chart = kind === "bar" ? BarChart : AreaChart;
    return (
        <ResponsiveContainer width="100%" height={height}>
            <Chart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
                <defs><linearGradient id={`g-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity={0.35} /><stop offset="100%" stopColor={color} stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ECECF3" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#A1A1AA" }} tickFormatter={(d) => d.slice(5)} minTickGap={24} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#A1A1AA" }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #E6E5EF", fontSize: 12 }} formatter={(v) => [fmtValue(v, format), label || "value"]} labelFormatter={(d) => d} />
                {kind === "bar" ? <Bar dataKey="value" fill={color} radius={[6, 6, 0, 0]} /> :
                    <Area type="monotone" dataKey="value" stroke={color} strokeWidth={2} fill={`url(#g-${color.replace("#", "")})`} />}
            </Chart>
        </ResponsiveContainer>
    );
}

export function Breakdown({ items = [], format = "int", color = "#4F46E5", title = "Breakdown" }) {
    const max = Math.max(1, ...items.map((i) => i.value || 0));
    return (
        <div className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5">
            <div className="text-sm font-medium mb-3">{title}</div>
            {items.length === 0 ? <div className="text-xs text-zinc-400 py-6 text-center">Nothing here yet.</div> : (
                <div className="space-y-2.5">
                    {items.map((it) => (
                        <div key={it.label}>
                            <div className="flex justify-between text-xs mb-1"><span className="truncate text-zinc-600 dark:text-zinc-300">{it.label}</span><span className="tabular-nums font-medium">{fmtValue(it.value, format)}</span></div>
                            <div className="h-1.5 rounded-full bg-zinc-100 dark:bg-white/10"><div className="h-full rounded-full" style={{ width: `${Math.max(3, (it.value / max) * 100)}%`, background: color }} /></div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

const RANGES = [7, 30, 90];

/**
 * InsightsDashboard — drop-in analytics header for any feature page.
 * <InsightsDashboard area="crm" title="Contacts" color="#0EA5E9" />
 */
export default function InsightsDashboard({ area, title, subtitle, color = "#4F46E5", seriesKey, seriesFormat, breakdownTitle = "Breakdown", breakdownFormat = "int", actions = null, children }) {
    const [days, setDays] = useState(30);
    const [data, setData] = useState(null);
    const [err, setErr] = useState(null);
    useEffect(() => {
        let alive = true;
        setErr(null);
        api.get(`/insights/${area}`, { params: { days } }).then((r) => alive && setData(r.data)).catch((e) => alive && setErr(e?.response?.data?.detail || "Could not load insights"));
        return () => { alive = false; };
    }, [area, days]);
    const series = data ? (data.series[seriesKey] || Object.values(data.series)[0] || []) : [];
    const total = series.reduce((a, b) => a + (b.value || 0), 0);
    return (
        <section className="mb-8" data-testid={`insights-${area}`}>
            <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
                <div>
                    {title && <h2 className="font-display text-2xl md:text-3xl text-brand-ink dark:text-white">{title}</h2>}
                    {subtitle && <p className="text-sm text-zinc-500 mt-1">{subtitle}</p>}
                </div>
                <div className="flex items-center gap-2">
                    {actions}
                    <div className="inline-flex rounded-lg border border-brand-line bg-white dark:bg-zinc-900 p-0.5" data-testid="insights-range">
                        {RANGES.map((r) => (
                            <button key={r} type="button" onClick={() => setDays(r)} data-testid={`insights-range-${r}`}
                                className={`px-3 py-1 text-xs rounded-md ${days === r ? "bg-brand-copper text-white" : "text-zinc-500 hover:text-brand-ink"}`}>{r}d</button>
                        ))}
                    </div>
                </div>
            </div>
            {err && <div className="text-sm text-red-600 mb-4">{err}</div>}
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3 md:gap-4">
                {(data?.cards || Array.from({ length: 5 }, (_, i) => ({ key: `s${i}`, label: "…", value: null }))).map((c) => <StatCard key={c.key} card={c} accent={color} />)}
            </div>
            <div className="grid lg:grid-cols-3 gap-4 mt-4">
                <div className="lg:col-span-2 rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5">
                    <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium capitalize">{(seriesKey || (data ? Object.keys(data.series)[0] : "trend") || "trend").replace(/_/g, " ")} · last {days} days</div>
                        <div className="text-xs text-zinc-500">Total {fmtValue(Math.round(total * 100) / 100, seriesFormat)}</div>
                    </div>
                    {data ? <TrendChart data={series} color={color} format={seriesFormat} /> : <div className="h-[220px] animate-pulse rounded-xl bg-zinc-50" />}
                </div>
                <Breakdown items={data?.breakdown || data?.utm?.map((u) => ({ label: u.source, value: u.visits })) || []} color={color} title={breakdownTitle} format={breakdownFormat} />
            </div>
            {children && data ? children(data) : null}
        </section>
    );
}
