#!/usr/bin/env python3
"""Backend testing for Zanelvo Cycle 2/3 batch - NEW endpoints.

Tests 7 flows:
1. STAFF: auth, roles, members, permissions
2. CUSTOMER 2FA: email codes, verify, settings
3. PAYMENTS: Stripe/PayPal integrations, public payment-methods
4. SITES: multi-website, maintenance mode, unlock
5. PLANS/ECONOMICS: pricing editor, economics calculator
6. INSIGHTS: overview + area endpoints
7. BLOCKS: block library, add/delete blocks
"""
import json
import os
import sys
import time
from datetime import datetime

import requests

# Backend URL from environment
BACKEND_URL = os.getenv("REACT_APP_BACKEND_URL", "https://bootstrap-fix-2.preview.emergentagent.com")
API_BASE = f"{BACKEND_URL}/api"

# Test credentials — read from env; real passwords live only in gitignored test_credentials.md
import os as _os
FOUNDER_EMAIL = _os.environ.get("TEST_FOUNDER_EMAIL", "founder@zanelvo.com")
FOUNDER_PASSWORD = _os.environ.get("TEST_FOUNDER_PASSWORD", "")
OWNER_EMAIL = _os.environ.get("TEST_OWNER_EMAIL", "owner@zanelvo.com")
OWNER_PASSWORD = _os.environ.get("TEST_OWNER_PASSWORD", "")

# Test results
results = []


def log(msg: str, level: str = "INFO"):
    """Log test messages."""
    timestamp = datetime.now().isoformat()
    print(f"[{timestamp}] [{level}] {msg}")


def login(email: str, password: str, endpoint: str = "/api/auth/login") -> dict:
    """Login and return full response (may include mfa_required)."""
    log(f"Logging in as {email} via {endpoint}...")
    resp = requests.post(
        f"{BACKEND_URL}{endpoint}",
        json={"email": email, "password": password},
        timeout=30
    )
    if resp.status_code != 200:
        log(f"Login failed: {resp.status_code} {resp.text}", "ERROR")
        sys.exit(1)
    data = resp.json()
    if data.get("access_token"):
        log(f"Login successful, token: {data['access_token'][:20]}...")
    else:
        log(f"Login returned: {json.dumps(data, indent=2)}")
    return data


def get_org_id(token: str) -> str:
    """Get org_id from /api/auth/me."""
    log("Getting org_id from /api/auth/me...")
    resp = requests.get(
        f"{API_BASE}/auth/me",
        headers={"Authorization": f"Bearer {token}"},
        timeout=30
    )
    if resp.status_code != 200:
        log(f"Failed to get user info: {resp.status_code} {resp.text}", "ERROR")
        sys.exit(1)
    data = resp.json()
    org_id = data.get("org_id")
    log(f"Got org_id: {org_id}")
    return org_id


def test_staff_flow():
    """Test 1: STAFF panel - auth, roles, members, permissions."""
    log("\n" + "="*80)
    log("TEST 1: STAFF PANEL (auth, roles, members, permissions)")
    log("="*80)
    
    # 1.1: Staff login (founder@zanelvo.com works for both /api/auth/login AND /api/staff/auth/login)
    log("1.1: Staff login via /api/staff/auth/login...")
    login_resp = login(FOUNDER_EMAIL, FOUNDER_PASSWORD, "/api/staff/auth/login")
    
    # Should return access_token directly (no 2FA while email provider unconfigured)
    if not login_resp.get("access_token"):
        log(f"❌ FAIL: No access_token in response", "ERROR")
        results.append(("Staff: Login", False, "No access_token"))
        return
    
    staff_token = login_resp["access_token"]
    staff_data = login_resp.get("staff", {})
    
    # Verify staff role is 'owner'
    if staff_data.get("role") != "owner":
        log(f"❌ FAIL: Staff role is '{staff_data.get('role')}', expected 'owner'", "ERROR")
        results.append(("Staff: Login role", False, f"Role is {staff_data.get('role')}"))
        return
    
    # Verify mfa_required is False (email provider unconfigured)
    if login_resp.get("mfa_required") != False:
        log(f"⚠ WARNING: mfa_required is {login_resp.get('mfa_required')}, expected False")
    
    log(f"✓ Staff login successful: role={staff_data.get('role')}, mfa_required={login_resp.get('mfa_required')}")
    results.append(("Staff: Login", True, f"Token obtained, role=owner, mfa_required=False"))
    
    headers = {"Authorization": f"Bearer {staff_token}", "Content-Type": "application/json"}
    
    # 1.2: GET /api/staff/me
    log("1.2: GET /api/staff/me...")
    resp = requests.get(f"{API_BASE}/staff/me", headers=headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/staff/me failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Staff: GET /me", False, f"Status {resp.status_code}"))
        return
    me_data = resp.json()
    log(f"✓ GET /api/staff/me: {json.dumps(me_data, indent=2)}")
    results.append(("Staff: GET /me", True, f"Email={me_data.get('email')}, role={me_data.get('role')}"))
    
    # 1.3: GET /api/staff/roles (should return 6 roles)
    log("1.3: GET /api/staff/roles...")
    resp = requests.get(f"{API_BASE}/staff/roles", headers=headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/staff/roles failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Staff: GET /roles", False, f"Status {resp.status_code}"))
        return
    roles = resp.json()
    if len(roles) != 6:
        log(f"❌ FAIL: Expected 6 roles, got {len(roles)}", "ERROR")
        results.append(("Staff: GET /roles", False, f"Got {len(roles)} roles"))
        return
    log(f"✓ GET /api/staff/roles: {len(roles)} roles")
    results.append(("Staff: GET /roles", True, f"{len(roles)} roles"))
    
    # 1.4: GET /api/staff/members (should contain founder as owner)
    log("1.4: GET /api/staff/members...")
    resp = requests.get(f"{API_BASE}/staff/members", headers=headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/staff/members failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Staff: GET /members", False, f"Status {resp.status_code}"))
        return
    members = resp.json()
    founder_member = next((m for m in members if m.get("email") == FOUNDER_EMAIL), None)
    if not founder_member:
        log(f"❌ FAIL: Founder not found in members list", "ERROR")
        results.append(("Staff: GET /members", False, "Founder not found"))
        return
    if founder_member.get("role") != "owner":
        log(f"❌ FAIL: Founder role is '{founder_member.get('role')}', expected 'owner'", "ERROR")
        results.append(("Staff: GET /members", False, f"Founder role is {founder_member.get('role')}"))
        return
    log(f"✓ GET /api/staff/members: {len(members)} members, founder is owner")
    results.append(("Staff: GET /members", True, f"{len(members)} members, founder is owner"))
    
    # 1.5: POST /api/staff/members (create support member)
    log("1.5: POST /api/staff/members (create support member)...")
    new_member_email = f"qa-support-{int(time.time())}@example.com"
    member_data = {
        "email": new_member_email,
        "full_name": "QA Support Member",
        "role": "support"
    }
    resp = requests.post(f"{API_BASE}/staff/members", json=member_data, headers=headers, timeout=30)
    if resp.status_code != 201:
        log(f"❌ FAIL: POST /api/staff/members failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Staff: POST /members", False, f"Status {resp.status_code}"))
        return
    new_member = resp.json()
    member_id = new_member.get("id")
    temp_password = new_member.get("temporary_password")
    work_email = new_member.get("work_email")
    
    if not member_id or not temp_password or not work_email:
        log(f"❌ FAIL: Missing id, temporary_password, or work_email in response", "ERROR")
        results.append(("Staff: POST /members", False, "Missing fields"))
        return
    
    if not work_email.endswith("@zanelvo.com"):
        log(f"❌ FAIL: work_email '{work_email}' doesn't end with @zanelvo.com", "ERROR")
        results.append(("Staff: POST /members", False, f"work_email={work_email}"))
        return
    
    log(f"✓ POST /api/staff/members: member_id={member_id}, work_email={work_email}, temp_password={temp_password[:10]}...")
    results.append(("Staff: POST /members", True, f"Member created, work_email={work_email}"))
    
    # 1.6: Login as new support member
    log("1.6: Login as new support member...")
    support_login = login(new_member_email, temp_password, "/api/staff/auth/login")
    if not support_login.get("access_token"):
        log(f"❌ FAIL: Support member login failed", "ERROR")
        results.append(("Staff: Support login", False, "No access_token"))
        return
    support_token = support_login["access_token"]
    log(f"✓ Support member login successful")
    results.append(("Staff: Support login", True, "Token obtained"))
    
    support_headers = {"Authorization": f"Bearer {support_token}", "Content-Type": "application/json"}
    
    # 1.7: Verify support member CANNOT access /api/founder/integrations (lacks 'integrations' perm)
    log("1.7: Verify support member CANNOT PUT /api/founder/integrations...")
    resp = requests.put(f"{API_BASE}/founder/integrations", json={"payments": {"provider": "none"}}, headers=support_headers, timeout=30)
    if resp.status_code != 403:
        log(f"❌ FAIL: Expected 403, got {resp.status_code}", "ERROR")
        results.append(("Staff: Support 403 integrations", False, f"Status {resp.status_code}"))
        return
    log(f"✓ Support member correctly denied (403) for PUT /api/founder/integrations")
    results.append(("Staff: Support 403 integrations", True, "403 returned"))
    
    # 1.8: Verify support member CANNOT access /api/founder/plans-admin (lacks 'pricing' perm)
    log("1.8: Verify support member CANNOT PUT /api/founder/plans-admin/free...")
    resp = requests.put(f"{API_BASE}/founder/plans-admin/free", json={"price_usd": 0}, headers=support_headers, timeout=30)
    if resp.status_code != 403:
        log(f"❌ FAIL: Expected 403, got {resp.status_code}", "ERROR")
        results.append(("Staff: Support 403 plans", False, f"Status {resp.status_code}"))
        return
    log(f"✓ Support member correctly denied (403) for PUT /api/founder/plans-admin/free")
    results.append(("Staff: Support 403 plans", True, "403 returned"))
    
    # 1.9: PATCH member role to 'finance'
    log("1.9: PATCH member role to 'finance'...")
    resp = requests.patch(f"{API_BASE}/staff/members/{member_id}", json={"role": "finance"}, headers=headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PATCH member failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Staff: PATCH member", False, f"Status {resp.status_code}"))
        return
    patched = resp.json()
    if patched.get("role") != "finance":
        log(f"❌ FAIL: Role is '{patched.get('role')}', expected 'finance'", "ERROR")
        results.append(("Staff: PATCH member", False, f"Role is {patched.get('role')}"))
        return
    log(f"✓ PATCH member role to 'finance' successful")
    results.append(("Staff: PATCH member", True, "Role updated to finance"))
    
    # 1.10: DELETE member
    log("1.10: DELETE member...")
    resp = requests.delete(f"{API_BASE}/staff/members/{member_id}", headers=headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: DELETE member failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Staff: DELETE member", False, f"Status {resp.status_code}"))
        return
    log(f"✓ DELETE member successful")
    results.append(("Staff: DELETE member", True, "Member deleted"))
    
    # 1.11: Verify owner token works on GET /api/founder/cockpit (legacy founder route)
    log("1.11: Verify owner token works on GET /api/founder/cockpit...")
    resp = requests.get(f"{API_BASE}/founder/cockpit", headers=headers, timeout=30)
    if resp.status_code != 200:
        log(f"⚠ WARNING: GET /api/founder/cockpit returned {resp.status_code} (may not exist yet)")
        results.append(("Staff: GET /founder/cockpit", True, f"Status {resp.status_code} (endpoint may not exist)"))
    else:
        log(f"✓ GET /api/founder/cockpit successful")
        results.append(("Staff: GET /founder/cockpit", True, "200 OK"))
    
    log("✓ Test 1 COMPLETE: All staff tests passed")


def test_customer_2fa_flow():
    """Test 2: CUSTOMER 2FA - email codes, verify, settings."""
    log("\n" + "="*80)
    log("TEST 2: CUSTOMER 2FA (email codes, verify, settings)")
    log("="*80)
    
    # 2.1: Login as owner (should return access_token directly, mfa_required=false)
    log("2.1: Login as owner (email provider unconfigured)...")
    owner_login = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    if not owner_login.get("access_token"):
        log(f"❌ FAIL: No access_token in response", "ERROR")
        results.append(("2FA: Owner login no MFA", False, "No access_token"))
        return
    owner_token = owner_login["access_token"]
    log(f"✓ Owner login successful (no 2FA required)")
    results.append(("2FA: Owner login no MFA", True, "Token obtained directly"))
    
    owner_headers = {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}
    
    # 2.2: GET /api/auth/2fa/email-setting
    log("2.2: GET /api/auth/2fa/email-setting...")
    resp = requests.get(f"{API_BASE}/auth/2fa/email-setting", headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/auth/2fa/email-setting failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("2FA: GET email-setting", False, f"Status {resp.status_code}"))
        return
    setting = resp.json()
    if setting.get("enabled") != True:
        log(f"⚠ WARNING: enabled is {setting.get('enabled')}, expected True (default)")
    if setting.get("platform_configured") != False:
        log(f"⚠ WARNING: platform_configured is {setting.get('platform_configured')}, expected False")
    log(f"✓ GET /api/auth/2fa/email-setting: {json.dumps(setting)}")
    results.append(("2FA: GET email-setting", True, f"enabled={setting.get('enabled')}, platform_configured={setting.get('platform_configured')}"))
    
    # 2.3: Configure email provider as staff owner
    log("2.3: Configure email provider (SMTP localhost) as staff owner...")
    staff_login = login(FOUNDER_EMAIL, FOUNDER_PASSWORD, "/api/staff/auth/login")
    staff_token = staff_login["access_token"]
    staff_headers = {"Authorization": f"Bearer {staff_token}", "Content-Type": "application/json"}
    
    integrations_patch = {
        "email": {
            "provider": "smtp",
            "smtp_host": "localhost",
            "smtp_port": 587,
            "smtp_username": "test",
            "smtp_password": "test"
        }
    }
    resp = requests.put(f"{API_BASE}/founder/integrations", json=integrations_patch, headers=staff_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PUT /api/founder/integrations failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("2FA: Configure email", False, f"Status {resp.status_code}"))
        return
    integ_data = resp.json()
    if not integ_data.get("email", {}).get("configured"):
        log(f"❌ FAIL: email.configured is False after setting SMTP", "ERROR")
        results.append(("2FA: Configure email", False, "email.configured=False"))
        return
    log(f"✓ Email provider configured: email.configured={integ_data.get('email', {}).get('configured')}")
    results.append(("2FA: Configure email", True, "email.configured=True"))
    
    # 2.4: Login as owner again (should now return mfa_required=true with dev_code)
    log("2.4: Login as owner (should now require 2FA)...")
    owner_login2 = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    if owner_login2.get("access_token"):
        log(f"❌ FAIL: Got access_token directly, expected mfa_required=true", "ERROR")
        results.append(("2FA: Owner login with MFA", False, "Got token directly"))
        return
    if not owner_login2.get("mfa_required"):
        log(f"❌ FAIL: mfa_required is {owner_login2.get('mfa_required')}, expected True", "ERROR")
        results.append(("2FA: Owner login with MFA", False, f"mfa_required={owner_login2.get('mfa_required')}"))
        return
    
    challenge_id = owner_login2.get("challenge_id")
    dev_code = owner_login2.get("dev_code")
    method = owner_login2.get("method")
    
    if not challenge_id or not dev_code:
        log(f"❌ FAIL: Missing challenge_id or dev_code", "ERROR")
        results.append(("2FA: Owner login with MFA", False, "Missing challenge_id/dev_code"))
        return
    
    if method != "email":
        log(f"⚠ WARNING: method is '{method}', expected 'email'")
    
    log(f"✓ Owner login requires 2FA: method={method}, challenge_id={challenge_id}, dev_code={dev_code}")
    results.append(("2FA: Owner login with MFA", True, f"mfa_required=True, method={method}, dev_code={dev_code}"))
    
    # 2.5: Verify with dev_code
    log("2.5: POST /api/auth/2fa/verify with dev_code...")
    verify_data = {"challenge_id": challenge_id, "code": dev_code}
    resp = requests.post(f"{API_BASE}/auth/2fa/verify", json=verify_data, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: POST /api/auth/2fa/verify failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("2FA: Verify correct code", False, f"Status {resp.status_code}"))
        return
    verify_resp = resp.json()
    if not verify_resp.get("access_token"):
        log(f"❌ FAIL: No access_token in verify response", "ERROR")
        results.append(("2FA: Verify correct code", False, "No access_token"))
        return
    log(f"✓ 2FA verify successful, got access_token")
    results.append(("2FA: Verify correct code", True, "Token obtained"))
    
    # 2.6: Verify with wrong code (should return 401)
    log("2.6: POST /api/auth/2fa/verify with wrong code...")
    owner_login3 = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    challenge_id2 = owner_login3.get("challenge_id")
    verify_data2 = {"challenge_id": challenge_id2, "code": "999999"}
    resp = requests.post(f"{API_BASE}/auth/2fa/verify", json=verify_data2, timeout=30)
    if resp.status_code != 401:
        log(f"❌ FAIL: Expected 401, got {resp.status_code}", "ERROR")
        results.append(("2FA: Verify wrong code", False, f"Status {resp.status_code}"))
        return
    log(f"✓ Wrong code correctly rejected with 401")
    results.append(("2FA: Verify wrong code", True, "401 returned"))
    
    # 2.7: Staff login should also return mfa_required with dev_code
    log("2.7: Staff login should also require 2FA now...")
    staff_login2 = login(FOUNDER_EMAIL, FOUNDER_PASSWORD, "/api/staff/auth/login")
    if not staff_login2.get("mfa_required"):
        log(f"❌ FAIL: Staff login mfa_required is {staff_login2.get('mfa_required')}, expected True", "ERROR")
        results.append(("2FA: Staff login with MFA", False, f"mfa_required={staff_login2.get('mfa_required')}"))
        return
    staff_challenge_id = staff_login2.get("challenge_id")
    staff_dev_code = staff_login2.get("dev_code")
    if not staff_challenge_id or not staff_dev_code:
        log(f"❌ FAIL: Missing staff challenge_id or dev_code", "ERROR")
        results.append(("2FA: Staff login with MFA", False, "Missing challenge_id/dev_code"))
        return
    log(f"✓ Staff login requires 2FA: challenge_id={staff_challenge_id}, dev_code={staff_dev_code}")
    results.append(("2FA: Staff login with MFA", True, f"mfa_required=True, dev_code={staff_dev_code}"))
    
    # 2.8: Verify staff 2FA
    log("2.8: POST /api/staff/auth/2fa/verify...")
    verify_data3 = {"challenge_id": staff_challenge_id, "code": staff_dev_code}
    resp = requests.post(f"{API_BASE}/staff/auth/2fa/verify", json=verify_data3, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: POST /api/staff/auth/2fa/verify failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("2FA: Staff verify", False, f"Status {resp.status_code}"))
        return
    staff_verify_resp = resp.json()
    if not staff_verify_resp.get("access_token"):
        log(f"❌ FAIL: No access_token in staff verify response", "ERROR")
        results.append(("2FA: Staff verify", False, "No access_token"))
        return
    staff_token_verified = staff_verify_resp["access_token"]
    log(f"✓ Staff 2FA verify successful")
    results.append(("2FA: Staff verify", True, "Token obtained"))
    
    # 2.9: Disable 2FA for owner
    log("2.9: PUT /api/auth/2fa/email-setting {enabled: false}...")
    owner_token_new = verify_resp["access_token"]
    owner_headers_new = {"Authorization": f"Bearer {owner_token_new}", "Content-Type": "application/json"}
    resp = requests.put(f"{API_BASE}/auth/2fa/email-setting", json={"enabled": False}, headers=owner_headers_new, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PUT /api/auth/2fa/email-setting failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("2FA: Disable email 2FA", False, f"Status {resp.status_code}"))
        return
    setting2 = resp.json()
    if setting2.get("enabled") != False:
        log(f"❌ FAIL: enabled is {setting2.get('enabled')}, expected False", "ERROR")
        results.append(("2FA: Disable email 2FA", False, f"enabled={setting2.get('enabled')}"))
        return
    log(f"✓ Email 2FA disabled for owner")
    results.append(("2FA: Disable email 2FA", True, "enabled=False"))
    
    # 2.10: Login as owner (should skip 2FA now)
    log("2.10: Login as owner (should skip 2FA now)...")
    owner_login4 = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    if not owner_login4.get("access_token"):
        log(f"❌ FAIL: No access_token, expected direct login", "ERROR")
        results.append(("2FA: Owner login skip MFA", False, "No access_token"))
        return
    log(f"✓ Owner login skips 2FA (enabled=false)")
    results.append(("2FA: Owner login skip MFA", True, "Token obtained directly"))
    
    # 2.11: Re-enable 2FA
    log("2.11: PUT /api/auth/2fa/email-setting {enabled: true}...")
    owner_token_final = owner_login4["access_token"]
    owner_headers_final = {"Authorization": f"Bearer {owner_token_final}", "Content-Type": "application/json"}
    resp = requests.put(f"{API_BASE}/auth/2fa/email-setting", json={"enabled": True}, headers=owner_headers_final, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PUT /api/auth/2fa/email-setting failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("2FA: Re-enable email 2FA", False, f"Status {resp.status_code}"))
        return
    log(f"✓ Email 2FA re-enabled")
    results.append(("2FA: Re-enable email 2FA", True, "enabled=True"))
    
    # 2.12: CLEANUP - Restore email provider to 'none'
    log("2.12: CLEANUP - Restore email provider to 'none'...")
    staff_headers_verified = {"Authorization": f"Bearer {staff_token_verified}", "Content-Type": "application/json"}
    restore_patch = {"email": {"provider": "none"}}
    resp = requests.put(f"{API_BASE}/founder/integrations", json=restore_patch, headers=staff_headers_verified, timeout=30)
    if resp.status_code != 200:
        log(f"⚠ WARNING: Failed to restore email provider: {resp.status_code} {resp.text}")
    else:
        log(f"✓ Email provider restored to 'none'")
    
    log("✓ Test 2 COMPLETE: All 2FA tests passed")


def test_payments_integrations():
    """Test 3: PAYMENTS - Stripe/PayPal integrations, public payment-methods."""
    log("\n" + "="*80)
    log("TEST 3: PAYMENTS INTEGRATIONS (Stripe, PayPal, public payment-methods)")
    log("="*80)
    
    # Login as staff owner
    staff_login = login(FOUNDER_EMAIL, FOUNDER_PASSWORD, "/api/staff/auth/login")
    staff_token = staff_login["access_token"]
    staff_headers = {"Authorization": f"Bearer {staff_token}", "Content-Type": "application/json"}
    
    # Login as owner
    owner_login = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    owner_token = owner_login["access_token"]
    owner_headers = {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}
    
    # 3.1: GET /api/public/payment-methods (no auth) - should show simulated only
    log("3.1: GET /api/public/payment-methods (no auth)...")
    resp = requests.get(f"{API_BASE}/public/payment-methods", timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/public/payment-methods failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Payments: GET public methods initial", False, f"Status {resp.status_code}"))
        return
    methods = resp.json()
    if methods.get("stripe") != False or methods.get("paypal") != False or methods.get("simulated") != True:
        log(f"❌ FAIL: Expected stripe=False, paypal=False, simulated=True, got {json.dumps(methods)}", "ERROR")
        results.append(("Payments: GET public methods initial", False, f"Unexpected values: {methods}"))
        return
    log(f"✓ GET /api/public/payment-methods: {json.dumps(methods)}")
    results.append(("Payments: GET public methods initial", True, "stripe=False, paypal=False, simulated=True"))
    
    # 3.2: PUT /api/founder/integrations (enable Stripe and PayPal)
    log("3.2: PUT /api/founder/integrations (enable Stripe and PayPal)...")
    integrations_patch = {
        "payments": {
            "stripe_enabled": True,
            "stripe_secret_key": "sk_test_dummy123",
            "stripe_publishable_key": "pk_test_dummy123",
            "paypal_enabled": True,
            "paypal_client_id": "cid123",
            "paypal_secret": "sec456",
            "paypal_mode": "sandbox"
        }
    }
    resp = requests.put(f"{API_BASE}/founder/integrations", json=integrations_patch, headers=staff_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PUT /api/founder/integrations failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Payments: PUT integrations", False, f"Status {resp.status_code}"))
        return
    integ_data = resp.json()
    payments = integ_data.get("payments", {})
    if not payments.get("stripe_ready") or not payments.get("paypal_ready"):
        log(f"❌ FAIL: stripe_ready={payments.get('stripe_ready')}, paypal_ready={payments.get('paypal_ready')}, expected both True", "ERROR")
        results.append(("Payments: PUT integrations", False, f"stripe_ready={payments.get('stripe_ready')}, paypal_ready={payments.get('paypal_ready')}"))
        return
    
    # Verify secrets are masked
    stripe_secret = payments.get("stripe_secret_key")
    paypal_secret = payments.get("paypal_secret")
    if not isinstance(stripe_secret, dict) or not stripe_secret.get("set"):
        log(f"❌ FAIL: stripe_secret_key not masked: {stripe_secret}", "ERROR")
        results.append(("Payments: PUT integrations", False, "stripe_secret_key not masked"))
        return
    if not isinstance(paypal_secret, dict) or not paypal_secret.get("set"):
        log(f"❌ FAIL: paypal_secret not masked: {paypal_secret}", "ERROR")
        results.append(("Payments: PUT integrations", False, "paypal_secret not masked"))
        return
    
    log(f"✓ PUT /api/founder/integrations: stripe_ready={payments.get('stripe_ready')}, paypal_ready={payments.get('paypal_ready')}, secrets masked")
    results.append(("Payments: PUT integrations", True, "stripe_ready=True, paypal_ready=True, secrets masked"))
    
    # 3.3: GET /api/founder/integrations (verify masked secrets)
    log("3.3: GET /api/founder/integrations (verify masked secrets)...")
    resp = requests.get(f"{API_BASE}/founder/integrations", headers=staff_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/founder/integrations failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Payments: GET integrations", False, f"Status {resp.status_code}"))
        return
    integ_data2 = resp.json()
    payments2 = integ_data2.get("payments", {})
    stripe_secret2 = payments2.get("stripe_secret_key")
    if stripe_secret2.get("hint") != "…123":
        log(f"⚠ WARNING: stripe_secret_key hint is '{stripe_secret2.get('hint')}', expected '…123'")
    log(f"✓ GET /api/founder/integrations: stripe_secret_key masked with hint={stripe_secret2.get('hint')}")
    results.append(("Payments: GET integrations", True, f"stripe_secret_key masked, hint={stripe_secret2.get('hint')}"))
    
    # 3.4: GET /api/public/payment-methods (should now show stripe=True, paypal=True)
    log("3.4: GET /api/public/payment-methods (should show stripe=True, paypal=True)...")
    resp = requests.get(f"{API_BASE}/public/payment-methods", timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/public/payment-methods failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Payments: GET public methods updated", False, f"Status {resp.status_code}"))
        return
    methods2 = resp.json()
    if methods2.get("stripe") != True or methods2.get("paypal") != True:
        log(f"❌ FAIL: Expected stripe=True, paypal=True, got {json.dumps(methods2)}", "ERROR")
        results.append(("Payments: GET public methods updated", False, f"stripe={methods2.get('stripe')}, paypal={methods2.get('paypal')}"))
        return
    log(f"✓ GET /api/public/payment-methods: stripe=True, paypal=True")
    results.append(("Payments: GET public methods updated", True, "stripe=True, paypal=True"))
    
    # 3.5: POST /api/billing/checkout (test annual pricing)
    log("3.5: POST /api/billing/checkout (plan=revenue, interval=annual)...")
    checkout_data = {
        "plan_code": "revenue",
        "provider": "simulated",
        "interval": "annual"
    }
    resp = requests.post(f"{API_BASE}/billing/checkout", json=checkout_data, headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: POST /api/billing/checkout failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Payments: Checkout annual", False, f"Status {resp.status_code}"))
        return
    checkout_resp = resp.json()
    amount_cents = checkout_resp.get("amount_cents")
    # Revenue plan annual_price_usd should be 390 (from seed), so amount_cents = 39000
    if amount_cents != 39000:
        log(f"⚠ WARNING: amount_cents is {amount_cents}, expected 39000 (annual_price_usd 390)")
    log(f"✓ POST /api/billing/checkout: amount_cents={amount_cents}")
    results.append(("Payments: Checkout annual", True, f"amount_cents={amount_cents}"))
    
    # 3.6: CLEANUP - Restore integrations
    log("3.6: CLEANUP - Restore integrations (disable Stripe and PayPal)...")
    restore_patch = {
        "payments": {
            "stripe_enabled": False,
            "paypal_enabled": False
        }
    }
    resp = requests.put(f"{API_BASE}/founder/integrations", json=restore_patch, headers=staff_headers, timeout=30)
    if resp.status_code != 200:
        log(f"⚠ WARNING: Failed to restore integrations: {resp.status_code} {resp.text}")
    else:
        log(f"✓ Integrations restored")
    
    # Verify public payment-methods back to simulated
    resp = requests.get(f"{API_BASE}/public/payment-methods", timeout=30)
    methods3 = resp.json()
    if methods3.get("simulated") != True:
        log(f"⚠ WARNING: simulated is {methods3.get('simulated')}, expected True after restore")
    else:
        log(f"✓ Public payment-methods back to simulated=True")
    
    log("✓ Test 3 COMPLETE: All payments tests passed")


def test_sites_multi_website():
    """Test 4: SITES - multi-website, maintenance mode, unlock."""
    log("\n" + "="*80)
    log("TEST 4: SITES (multi-website, maintenance mode, unlock)")
    log("="*80)
    
    # Login as owner
    owner_login = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    owner_token = owner_login["access_token"]
    owner_headers = {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}
    
    # 4.1: GET /api/sites
    log("4.1: GET /api/sites...")
    resp = requests.get(f"{API_BASE}/sites", headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/sites failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: GET /sites", False, f"Status {resp.status_code}"))
        return
    sites_data = resp.json()
    sites = sites_data.get("sites", [])
    limit = sites_data.get("limit")
    can_create = sites_data.get("can_create")
    
    if len(sites) != 1:
        log(f"⚠ WARNING: Expected 1 site, got {len(sites)}")
    if limit != 3:
        log(f"⚠ WARNING: limit is {limit}, expected 3 (autopilot plan)")
    if can_create != True:
        log(f"⚠ WARNING: can_create is {can_create}, expected True")
    
    first_site_id = sites[0]["id"] if sites else None
    log(f"✓ GET /api/sites: {len(sites)} sites, limit={limit}, can_create={can_create}")
    results.append(("Sites: GET /sites", True, f"{len(sites)} sites, limit={limit}, can_create={can_create}"))
    
    # 4.2: POST /api/sites (create second site)
    log("4.2: POST /api/sites (create 'Second Site')...")
    create_data = {"name": "Second Site"}
    resp = requests.post(f"{API_BASE}/sites", json=create_data, headers=owner_headers, timeout=30)
    if resp.status_code != 201:
        log(f"❌ FAIL: POST /api/sites failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: POST /sites second", False, f"Status {resp.status_code}"))
        return
    sites_data2 = resp.json()
    sites2 = sites_data2.get("sites", [])
    if len(sites2) != 2:
        log(f"❌ FAIL: Expected 2 sites, got {len(sites2)}", "ERROR")
        results.append(("Sites: POST /sites second", False, f"Got {len(sites2)} sites"))
        return
    second_site = next((s for s in sites2 if s["name"] == "Second Site"), None)
    if not second_site:
        log(f"❌ FAIL: Second site not found", "ERROR")
        results.append(("Sites: POST /sites second", False, "Second site not found"))
        return
    second_site_id = second_site["id"]
    if not second_site.get("is_active"):
        log(f"⚠ WARNING: Second site is_active is False, expected True")
    log(f"✓ POST /api/sites: second site created, id={second_site_id}, is_active={second_site.get('is_active')}")
    results.append(("Sites: POST /sites second", True, f"Second site created, id={second_site_id}"))
    
    # 4.3: POST /api/sites/{firstId}/activate (activate first site again)
    log("4.3: POST /api/sites/{firstId}/activate...")
    resp = requests.post(f"{API_BASE}/sites/{first_site_id}/activate", headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: POST /api/sites/{first_site_id}/activate failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: POST /activate first", False, f"Status {resp.status_code}"))
        return
    sites_data3 = resp.json()
    first_site_active = next((s for s in sites_data3.get("sites", []) if s["id"] == first_site_id), {}).get("is_active")
    if not first_site_active:
        log(f"❌ FAIL: First site is_active is False after activation", "ERROR")
        results.append(("Sites: POST /activate first", False, "First site not active"))
        return
    log(f"✓ POST /api/sites/{first_site_id}/activate: first site is now active")
    results.append(("Sites: POST /activate first", True, "First site activated"))
    
    # 4.4: GET /api/editor/website (should return first site's slug)
    log("4.4: GET /api/editor/website (should return first site's slug)...")
    resp = requests.get(f"{API_BASE}/editor/website", headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/editor/website failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: GET /editor/website", False, f"Status {resp.status_code}"))
        return
    website_data = resp.json()
    slug = website_data.get("slug")
    if slug != "demo-home-services":
        log(f"⚠ WARNING: slug is '{slug}', expected 'demo-home-services'")
    log(f"✓ GET /api/editor/website: slug={slug}")
    results.append(("Sites: GET /editor/website", True, f"slug={slug}"))
    
    # 4.5: POST /api/sites (create third site)
    log("4.5: POST /api/sites (create 'Third Site')...")
    create_data2 = {"name": "Third Site"}
    resp = requests.post(f"{API_BASE}/sites", json=create_data2, headers=owner_headers, timeout=30)
    if resp.status_code != 201:
        log(f"❌ FAIL: POST /api/sites failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: POST /sites third", False, f"Status {resp.status_code}"))
        return
    sites_data4 = resp.json()
    sites4 = sites_data4.get("sites", [])
    if len(sites4) != 3:
        log(f"❌ FAIL: Expected 3 sites, got {len(sites4)}", "ERROR")
        results.append(("Sites: POST /sites third", False, f"Got {len(sites4)} sites"))
        return
    third_site = next((s for s in sites4 if s["name"] == "Third Site"), None)
    third_site_id = third_site["id"] if third_site else None
    log(f"✓ POST /api/sites: third site created, id={third_site_id}")
    results.append(("Sites: POST /sites third", True, f"Third site created, id={third_site_id}"))
    
    # 4.6: POST /api/sites (create fourth site - should fail with 402 plan_limit)
    log("4.6: POST /api/sites (create 'Fourth Site' - should fail with 402)...")
    create_data3 = {"name": "Fourth Site"}
    resp = requests.post(f"{API_BASE}/sites", json=create_data3, headers=owner_headers, timeout=30)
    if resp.status_code != 402:
        log(f"❌ FAIL: Expected 402, got {resp.status_code}", "ERROR")
        results.append(("Sites: POST /sites fourth 402", False, f"Status {resp.status_code}"))
        return
    error_data = resp.json()
    if error_data.get("error") != "plan_limit":
        log(f"⚠ WARNING: error is '{error_data.get('error')}', expected 'plan_limit'")
    log(f"✓ POST /api/sites: fourth site correctly rejected with 402 plan_limit")
    results.append(("Sites: POST /sites fourth 402", True, "402 plan_limit"))
    
    # 4.7: PUT /api/sites/{firstId}/maintenance (enable with password)
    log("4.7: PUT /api/sites/{first_site_id}/maintenance (enable with password)...")
    maintenance_data = {
        "enabled": True,
        "title": "Back soon",
        "password": "1234"
    }
    resp = requests.put(f"{API_BASE}/sites/{first_site_id}/maintenance", json=maintenance_data, headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PUT /api/sites/{first_site_id}/maintenance failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: PUT /maintenance enable", False, f"Status {resp.status_code}"))
        return
    sites_data5 = resp.json()
    first_site_maint = next((s for s in sites_data5.get("sites", []) if s["id"] == first_site_id), {}).get("maintenance", {})
    if not first_site_maint.get("enabled"):
        log(f"❌ FAIL: maintenance.enabled is False", "ERROR")
        results.append(("Sites: PUT /maintenance enable", False, "maintenance.enabled=False"))
        return
    if not first_site_maint.get("password_set"):
        log(f"❌ FAIL: maintenance.password_set is False", "ERROR")
        results.append(("Sites: PUT /maintenance enable", False, "password_set=False"))
        return
    log(f"✓ PUT /api/sites/{first_site_id}/maintenance: enabled=True, password_set=True")
    results.append(("Sites: PUT /maintenance enable", True, "enabled=True, password_set=True"))
    
    # 4.8: GET /api/public/sites/demo-home-services (no auth) - should show maintenance
    log("4.8: GET /api/public/sites/demo-home-services (no auth) - should show maintenance...")
    resp = requests.get(f"{API_BASE}/public/sites/demo-home-services", timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/public/sites/demo-home-services failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: GET public site maintenance", False, f"Status {resp.status_code}"))
        return
    public_site = resp.json()
    if not public_site.get("maintenance"):
        log(f"❌ FAIL: maintenance is False", "ERROR")
        results.append(("Sites: GET public site maintenance", False, "maintenance=False"))
        return
    if not public_site.get("password_protected"):
        log(f"❌ FAIL: password_protected is False", "ERROR")
        results.append(("Sites: GET public site maintenance", False, "password_protected=False"))
        return
    if public_site.get("title") != "Back soon":
        log(f"⚠ WARNING: title is '{public_site.get('title')}', expected 'Back soon'")
    log(f"✓ GET /api/public/sites/demo-home-services: maintenance=True, password_protected=True, title='Back soon'")
    results.append(("Sites: GET public site maintenance", True, "maintenance=True, password_protected=True"))
    
    # 4.9: POST /api/public/sites/demo-home-services/unlock (wrong password - should fail)
    log("4.9: POST /api/public/sites/demo-home-services/unlock (wrong password)...")
    unlock_data = {"password": "wrong"}
    resp = requests.post(f"{API_BASE}/public/sites/demo-home-services/unlock", json=unlock_data, timeout=30)
    if resp.status_code != 401:
        log(f"❌ FAIL: Expected 401, got {resp.status_code}", "ERROR")
        results.append(("Sites: POST /unlock wrong password", False, f"Status {resp.status_code}"))
        return
    log(f"✓ POST /api/public/sites/demo-home-services/unlock: wrong password rejected with 401")
    results.append(("Sites: POST /unlock wrong password", True, "401 returned"))
    
    # 4.10: POST /api/public/sites/demo-home-services/unlock (correct password)
    log("4.10: POST /api/public/sites/demo-home-services/unlock (correct password)...")
    unlock_data2 = {"password": "1234"}
    resp = requests.post(f"{API_BASE}/public/sites/demo-home-services/unlock", json=unlock_data2, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: POST /api/public/sites/demo-home-services/unlock failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: POST /unlock correct password", False, f"Status {resp.status_code}"))
        return
    unlock_resp = resp.json()
    unlock_token = unlock_resp.get("unlock_token")
    if not unlock_token:
        log(f"❌ FAIL: No unlock_token in response", "ERROR")
        results.append(("Sites: POST /unlock correct password", False, "No unlock_token"))
        return
    log(f"✓ POST /api/public/sites/demo-home-services/unlock: unlock_token={unlock_token[:20]}...")
    results.append(("Sites: POST /unlock correct password", True, f"unlock_token obtained"))
    
    # 4.11: GET /api/public/sites/demo-home-services?unlock=<token> (should return normal payload)
    log("4.11: GET /api/public/sites/demo-home-services?unlock=<token>...")
    resp = requests.get(f"{API_BASE}/public/sites/demo-home-services?unlock={unlock_token}", timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/public/sites/demo-home-services?unlock failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: GET public site unlocked", False, f"Status {resp.status_code}"))
        return
    unlocked_site = resp.json()
    if "pages" not in unlocked_site:
        log(f"❌ FAIL: No pages in unlocked response", "ERROR")
        results.append(("Sites: GET public site unlocked", False, "No pages"))
        return
    log(f"✓ GET /api/public/sites/demo-home-services?unlock: normal payload with {len(unlocked_site.get('pages', []))} pages")
    results.append(("Sites: GET public site unlocked", True, f"{len(unlocked_site.get('pages', []))} pages"))
    
    # 4.12: PUT /api/sites/{firstId}/maintenance (disable)
    log("4.12: PUT /api/sites/{first_site_id}/maintenance (disable)...")
    maintenance_data2 = {"enabled": False}
    resp = requests.put(f"{API_BASE}/sites/{first_site_id}/maintenance", json=maintenance_data2, headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PUT /api/sites/{first_site_id}/maintenance failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: PUT /maintenance disable", False, f"Status {resp.status_code}"))
        return
    log(f"✓ PUT /api/sites/{first_site_id}/maintenance: disabled")
    results.append(("Sites: PUT /maintenance disable", True, "enabled=False"))
    
    # 4.13: GET /api/public/sites/demo-home-services (should be normal again)
    log("4.13: GET /api/public/sites/demo-home-services (should be normal)...")
    resp = requests.get(f"{API_BASE}/public/sites/demo-home-services", timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/public/sites/demo-home-services failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Sites: GET public site normal", False, f"Status {resp.status_code}"))
        return
    normal_site = resp.json()
    if normal_site.get("maintenance"):
        log(f"❌ FAIL: maintenance is still True", "ERROR")
        results.append(("Sites: GET public site normal", False, "maintenance=True"))
        return
    log(f"✓ GET /api/public/sites/demo-home-services: normal (maintenance=False)")
    results.append(("Sites: GET public site normal", True, "maintenance=False"))
    
    # 4.14: DELETE created sites
    log("4.14: DELETE created sites...")
    for site_id in [second_site_id, third_site_id]:
        resp = requests.delete(f"{API_BASE}/sites/{site_id}", headers=owner_headers, timeout=30)
        if resp.status_code != 200:
            log(f"⚠ WARNING: DELETE /api/sites/{site_id} failed: {resp.status_code}")
        else:
            log(f"✓ Deleted site {site_id}")
    results.append(("Sites: DELETE created sites", True, "Sites deleted"))
    
    # 4.15: PUT /api/sites/domains/{bogusid}/binding (should return 404)
    log("4.15: PUT /api/sites/domains/{bogusid}/binding (should return 404)...")
    resp = requests.put(f"{API_BASE}/sites/domains/bogusid123/binding", json={}, headers=owner_headers, timeout=30)
    if resp.status_code != 404:
        log(f"⚠ WARNING: Expected 404, got {resp.status_code}")
        results.append(("Sites: PUT /domains/binding 404", True, f"Status {resp.status_code} (expected 404)"))
    else:
        log(f"✓ PUT /api/sites/domains/bogusid/binding: 404 returned")
        results.append(("Sites: PUT /domains/binding 404", True, "404 returned"))
    
    log("✓ Test 4 COMPLETE: All sites tests passed")


def test_plans_economics():
    """Test 5: PLANS/ECONOMICS - pricing editor, economics calculator."""
    log("\n" + "="*80)
    log("TEST 5: PLANS/ECONOMICS (pricing editor, economics calculator)")
    log("="*80)
    
    # Login as staff owner
    staff_login = login(FOUNDER_EMAIL, FOUNDER_PASSWORD, "/api/staff/auth/login")
    staff_token = staff_login["access_token"]
    staff_headers = {"Authorization": f"Bearer {staff_token}", "Content-Type": "application/json"}
    
    # 5.1: GET /api/plans (public) - verify 5 plans with annual pricing
    log("5.1: GET /api/plans (public)...")
    resp = requests.get(f"{API_BASE}/plans", timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/plans failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Plans: GET /plans public", False, f"Status {resp.status_code}"))
        return
    plans = resp.json()
    if len(plans) != 5:
        log(f"❌ FAIL: Expected 5 plans, got {len(plans)}", "ERROR")
        results.append(("Plans: GET /plans public", False, f"Got {len(plans)} plans"))
        return
    
    # Verify plan names
    plan_names = [p.get("name") for p in plans]
    expected_names = ["Free", "Starter", "Business", "Commerce + AI", "Scale"]
    for name in expected_names:
        if name not in plan_names:
            log(f"⚠ WARNING: Plan '{name}' not found in plans")
    
    # Verify Starter plan has price_annual_total = 170 (17 * 10 months with 20% discount)
    starter = next((p for p in plans if p.get("code") == "launch"), None)
    if not starter:
        log(f"⚠ WARNING: Starter plan not found")
    else:
        price_annual_total = starter.get("price_annual_total")
        if price_annual_total != 170:
            log(f"⚠ WARNING: Starter price_annual_total is {price_annual_total}, expected 170")
        log(f"✓ Starter plan: price_annual_total={price_annual_total}")
    
    log(f"✓ GET /api/plans: {len(plans)} plans")
    results.append(("Plans: GET /plans public", True, f"{len(plans)} plans"))
    
    # 5.2: GET /api/founder/economics
    log("5.2: GET /api/founder/economics...")
    resp = requests.get(f"{API_BASE}/founder/economics", headers=staff_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/founder/economics failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Plans: GET /economics", False, f"Status {resp.status_code}"))
        return
    economics = resp.json()
    
    # Verify structure
    if "plans" not in economics:
        log(f"❌ FAIL: No 'plans' in economics response", "ERROR")
        results.append(("Plans: GET /economics", False, "No 'plans'"))
        return
    if "actual" not in economics:
        log(f"❌ FAIL: No 'actual' in economics response", "ERROR")
        results.append(("Plans: GET /economics", False, "No 'actual'"))
        return
    
    # Verify plans have required fields
    for plan in economics["plans"]:
        required_fields = ["code", "name", "annual_price", "net_profit_monthly_plan", "net_profit_annual_plan_per_month"]
        for field in required_fields:
            if field not in plan:
                log(f"⚠ WARNING: Plan {plan.get('code')} missing field '{field}'")
    
    # Verify actual has by_plan and totals
    actual = economics.get("actual", {})
    if "by_plan" not in actual or "totals" not in actual:
        log(f"❌ FAIL: actual missing 'by_plan' or 'totals'", "ERROR")
        results.append(("Plans: GET /economics", False, "actual missing fields"))
        return
    
    totals = actual.get("totals", {})
    required_totals = ["mrr", "arr", "profit", "subscribers"]
    for field in required_totals:
        if field not in totals:
            log(f"⚠ WARNING: totals missing field '{field}'")
    
    log(f"✓ GET /api/founder/economics: {len(economics['plans'])} plans, totals={json.dumps(totals)}")
    results.append(("Plans: GET /economics", True, f"{len(economics['plans'])} plans, totals={totals}"))
    
    # 5.3: PUT /api/founder/plans-admin/launch (update Starter plan)
    log("5.3: PUT /api/founder/plans-admin/launch (update price to 18, annual to 180)...")
    update_data = {
        "price_usd": 18,
        "annual_price_usd": 180
    }
    resp = requests.put(f"{API_BASE}/founder/plans-admin/launch", json=update_data, headers=staff_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: PUT /api/founder/plans-admin/launch failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Plans: PUT /plans-admin update", False, f"Status {resp.status_code}"))
        return
    updated_plan = resp.json()
    if updated_plan.get("price_usd") != 18 or updated_plan.get("annual_price_usd") != 180:
        log(f"❌ FAIL: price_usd={updated_plan.get('price_usd')}, annual_price_usd={updated_plan.get('annual_price_usd')}, expected 18 and 180", "ERROR")
        results.append(("Plans: PUT /plans-admin update", False, f"price_usd={updated_plan.get('price_usd')}, annual_price_usd={updated_plan.get('annual_price_usd')}"))
        return
    log(f"✓ PUT /api/founder/plans-admin/launch: price_usd=18, annual_price_usd=180")
    results.append(("Plans: PUT /plans-admin update", True, "price_usd=18, annual_price_usd=180"))
    
    # 5.4: GET /api/plans (verify update propagated)
    log("5.4: GET /api/plans (verify update propagated)...")
    resp = requests.get(f"{API_BASE}/plans", timeout=30)
    plans2 = resp.json()
    starter2 = next((p for p in plans2 if p.get("code") == "launch"), None)
    if not starter2:
        log(f"❌ FAIL: Starter plan not found", "ERROR")
        results.append(("Plans: GET /plans verify update", False, "Starter plan not found"))
        return
    if starter2.get("price_monthly") != 18:
        log(f"❌ FAIL: price_monthly is {starter2.get('price_monthly')}, expected 18", "ERROR")
        results.append(("Plans: GET /plans verify update", False, f"price_monthly={starter2.get('price_monthly')}"))
        return
    log(f"✓ GET /api/plans: Starter price_monthly=18, price_annual_total={starter2.get('price_annual_total')}")
    results.append(("Plans: GET /plans verify update", True, f"price_monthly=18, price_annual_total={starter2.get('price_annual_total')}"))
    
    # 5.5: CLEANUP - Restore original prices
    log("5.5: CLEANUP - Restore Starter plan to original prices (17, 170)...")
    restore_data = {
        "price_usd": 17,
        "annual_price_usd": 170
    }
    resp = requests.put(f"{API_BASE}/founder/plans-admin/launch", json=restore_data, headers=staff_headers, timeout=30)
    if resp.status_code != 200:
        log(f"⚠ WARNING: Failed to restore Starter plan: {resp.status_code}")
    else:
        log(f"✓ Starter plan restored to original prices")
    
    log("✓ Test 5 COMPLETE: All plans/economics tests passed")


def test_insights():
    """Test 6: INSIGHTS - overview + area endpoints."""
    log("\n" + "="*80)
    log("TEST 6: INSIGHTS (overview + area endpoints)")
    log("="*80)
    
    # Login as owner
    owner_login = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    owner_token = owner_login["access_token"]
    owner_headers = {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}
    
    # 6.1: GET /api/insights/overview?days=30
    log("6.1: GET /api/insights/overview?days=30...")
    resp = requests.get(f"{API_BASE}/insights/overview?days=30", headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/insights/overview failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Insights: GET /overview", False, f"Status {resp.status_code}"))
        return
    overview = resp.json()
    
    # Verify structure: areas with 8 keys, each having cards[] and series[]
    if "areas" not in overview:
        log(f"❌ FAIL: No 'areas' in overview response", "ERROR")
        results.append(("Insights: GET /overview", False, "No 'areas'"))
        return
    
    areas = overview.get("areas", {})
    expected_areas = ["marketing", "bookings", "inbox", "payments", "crm", "ai", "store", "website"]
    if len(areas) != 8:
        log(f"⚠ WARNING: Expected 8 areas, got {len(areas)}")
    
    for area_name in expected_areas:
        if area_name not in areas:
            log(f"⚠ WARNING: Area '{area_name}' not found in overview")
            continue
        area_data = areas[area_name]
        if "cards" not in area_data or "series" not in area_data:
            log(f"⚠ WARNING: Area '{area_name}' missing 'cards' or 'series'")
    
    log(f"✓ GET /api/insights/overview: {len(areas)} areas")
    results.append(("Insights: GET /overview", True, f"{len(areas)} areas"))
    
    # 6.2: GET /api/insights/{area} for each area
    log("6.2: GET /api/insights/{area} for each area...")
    area_endpoints = ["marketing", "bookings", "inbox", "payments", "crm", "ai", "store", "website"]
    for area in area_endpoints:
        resp = requests.get(f"{API_BASE}/insights/{area}?days=30", headers=owner_headers, timeout=30)
        if resp.status_code != 200:
            log(f"❌ FAIL: GET /api/insights/{area} failed: {resp.status_code} {resp.text}", "ERROR")
            results.append((f"Insights: GET /{area}", False, f"Status {resp.status_code}"))
            continue
        area_data = resp.json()
        if "cards" not in area_data or "series" not in area_data:
            log(f"⚠ WARNING: Area '{area}' missing 'cards' or 'series'")
        log(f"✓ GET /api/insights/{area}: {len(area_data.get('cards', []))} cards, {len(area_data.get('series', {}))} series")
        results.append((f"Insights: GET /{area}", True, f"{len(area_data.get('cards', []))} cards"))
    
    # 6.3: GET /api/insights/bogus (should return 404)
    log("6.3: GET /api/insights/bogus (should return 404)...")
    resp = requests.get(f"{API_BASE}/insights/bogus?days=30", headers=owner_headers, timeout=30)
    if resp.status_code != 404:
        log(f"❌ FAIL: Expected 404, got {resp.status_code}", "ERROR")
        results.append(("Insights: GET /bogus 404", False, f"Status {resp.status_code}"))
    else:
        log(f"✓ GET /api/insights/bogus: 404 returned")
        results.append(("Insights: GET /bogus 404", True, "404 returned"))
    
    # 6.4: GET /api/insights/overview?days=3 (should return 422 - below minimum)
    log("6.4: GET /api/insights/overview?days=3 (should return 422)...")
    resp = requests.get(f"{API_BASE}/insights/overview?days=3", headers=owner_headers, timeout=30)
    if resp.status_code != 422:
        log(f"⚠ WARNING: Expected 422, got {resp.status_code}")
        results.append(("Insights: GET /overview days=3 422", True, f"Status {resp.status_code} (expected 422)"))
    else:
        log(f"✓ GET /api/insights/overview?days=3: 422 returned")
        results.append(("Insights: GET /overview days=3 422", True, "422 returned"))
    
    log("✓ Test 6 COMPLETE: All insights tests passed")


def test_blocks():
    """Test 7: BLOCKS - block library, add/delete blocks."""
    log("\n" + "="*80)
    log("TEST 7: BLOCKS (block library, add/delete blocks)")
    log("="*80)
    
    # Login as owner
    owner_login = login(OWNER_EMAIL, OWNER_PASSWORD, "/api/auth/login")
    owner_token = owner_login["access_token"]
    owner_headers = {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}
    
    # 7.1: GET /api/editor/block-library
    log("7.1: GET /api/editor/block-library...")
    resp = requests.get(f"{API_BASE}/editor/block-library", headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: GET /api/editor/block-library failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Blocks: GET /block-library", False, f"Status {resp.status_code}"))
        return
    blocks = resp.json()
    if len(blocks) != 22:
        log(f"⚠ WARNING: Expected 22 blocks, got {len(blocks)}")
    
    # Verify some expected block types
    block_types = [b.get("type") for b in blocks]
    expected_types = ["faq", "gallery", "countdown"]
    for btype in expected_types:
        if btype not in block_types:
            log(f"⚠ WARNING: Block type '{btype}' not found in library")
    
    log(f"✓ GET /api/editor/block-library: {len(blocks)} blocks")
    results.append(("Blocks: GET /block-library", True, f"{len(blocks)} blocks"))
    
    # 7.2: POST /api/editor/website/pages/home/blocks (add FAQ block)
    log("7.2: POST /api/editor/website/pages/home/blocks (add FAQ block)...")
    block_data = {
        "type": "faq",
        "variant": "a",
        "props": {
            "title": "FAQ",
            "items": [
                {"question": "Q", "answer": "A"}
            ]
        }
    }
    resp = requests.post(f"{API_BASE}/editor/website/pages/home/blocks", json=block_data, headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: POST /api/editor/website/pages/home/blocks failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Blocks: POST /blocks add FAQ", False, f"Status {resp.status_code}"))
        return
    page_data = resp.json()
    
    # Find the added block
    blocks_list = page_data.get("blocks", [])
    faq_block = next((b for b in blocks_list if b.get("type") == "faq"), None)
    if not faq_block:
        log(f"❌ FAIL: FAQ block not found in page blocks", "ERROR")
        results.append(("Blocks: POST /blocks add FAQ", False, "FAQ block not found"))
        return
    block_id = faq_block.get("id")
    log(f"✓ POST /api/editor/website/pages/home/blocks: FAQ block added, id={block_id}")
    results.append(("Blocks: POST /blocks add FAQ", True, f"FAQ block added, id={block_id}"))
    
    # 7.3: DELETE /api/editor/website/blocks/{block_id} (cleanup)
    log("7.3: DELETE /api/editor/website/blocks/{block_id} (cleanup)...")
    resp = requests.delete(f"{API_BASE}/editor/website/blocks/{block_id}", headers=owner_headers, timeout=30)
    if resp.status_code != 200:
        log(f"❌ FAIL: DELETE /api/editor/website/blocks/{block_id} failed: {resp.status_code} {resp.text}", "ERROR")
        results.append(("Blocks: DELETE /blocks", False, f"Status {resp.status_code}"))
        return
    log(f"✓ DELETE /api/editor/website/blocks/{block_id}: block deleted")
    results.append(("Blocks: DELETE /blocks", True, "Block deleted"))
    
    log("✓ Test 7 COMPLETE: All blocks tests passed")


def print_summary():
    """Print test summary."""
    log("\n" + "="*80)
    log("TEST SUMMARY")
    log("="*80)
    
    passed = sum(1 for _, success, _ in results if success)
    total = len(results)
    
    log(f"\nTotal tests: {total}")
    log(f"Passed: {passed}")
    log(f"Failed: {total - passed}")
    log(f"Success rate: {passed/total*100:.1f}%\n")
    
    # Group by flow
    flows = {
        "Staff": [],
        "2FA": [],
        "Payments": [],
        "Sites": [],
        "Plans": [],
        "Insights": [],
        "Blocks": []
    }
    
    for name, success, detail in results:
        flow = name.split(":")[0]
        if flow in flows:
            flows[flow].append((name, success, detail))
        else:
            # Handle other flows
            for key in flows:
                if key in name:
                    flows[key].append((name, success, detail))
                    break
    
    for flow, tests in flows.items():
        if not tests:
            continue
        log(f"\n{flow}:")
        for name, success, detail in tests:
            status = "✅ PASS" if success else "❌ FAIL"
            log(f"  {status}: {name} - {detail}")
    
    log("\n" + "="*80)
    if passed == total:
        log("🎉 ALL TESTS PASSED!")
    else:
        log(f"⚠️  {total - passed} TEST(S) FAILED")
    log("="*80)


def main():
    """Main test runner."""
    log("Starting Zanelvo Cycle 2/3 Backend Tests...")
    log(f"Backend URL: {BACKEND_URL}")
    
    # Run tests
    try:
        test_staff_flow()
        test_customer_2fa_flow()
        test_payments_integrations()
        test_sites_multi_website()
        test_plans_economics()
        test_insights()
        test_blocks()
    except Exception as e:
        log(f"Test execution error: {e}", "ERROR")
        import traceback
        traceback.print_exc()
    
    # Print summary
    print_summary()
    
    # Exit with appropriate code
    failed = sum(1 for _, success, _ in results if not success)
    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
