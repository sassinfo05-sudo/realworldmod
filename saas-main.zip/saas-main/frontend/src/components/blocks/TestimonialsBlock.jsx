export default function TestimonialsBlock({ block, theme }) {
    const { props = {} } = block;
    const { eyebrow, headline, items = [] } = props;
    return (
        <section className="py-20" style={{ backgroundColor: `${theme?.foreground}05` }}>
            <div className="mx-auto max-w-6xl px-6">
                {eyebrow && (
                    <div className="text-xs uppercase tracking-[0.24em] mb-3" style={{ color: theme?.primary }}>
                        {eyebrow}
                    </div>
                )}
                {headline && (
                    <h2 data-heading className="text-3xl md:text-4xl font-semibold max-w-2xl">
                        {headline}
                    </h2>
                )}
                <div className="mt-10 grid md:grid-cols-3 gap-6">
                    {items.map((t, i) => (
                        <figure key={i} className="rounded-2xl p-6 border"
                                style={{ background: theme?.surface, borderColor: `${theme?.foreground}14` }}>
                            <blockquote className="text-base leading-relaxed" style={{ color: theme?.foreground }}>
                                “{t.quote}”
                            </blockquote>
                            <figcaption className="mt-4 text-sm" style={{ color: `${theme?.foreground}90` }}>
                                <span className="font-medium" style={{ color: theme?.foreground }}>{t.author}</span>
                                {t.role && <> · {t.role}</>}
                            </figcaption>
                        </figure>
                    ))}
                </div>
            </div>
        </section>
    );
}
