import React, { useEffect, useState, useCallback } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
    Truck, MapPin, Plus, Trash2, Globe2, Package, Building2, ExternalLink,
    Boxes, Save, DollarSign,
} from "lucide-react";

const card = "rounded-2xl border border-brand-line bg-white p-5 shadow-sm";
const input = "w-full border border-brand-line rounded-lg px-3 py-2 text-sm bg-white";
const label = "text-xs font-medium text-zinc-500 block mb-1";

const RATE_TYPES = [
    { id: "flat", label: "Flat rate" },
    { id: "free_over", label: "Free over amount" },
    { id: "weight", label: "By weight" },
    { id: "price", label: "By order value" },
];

export default function Shipping() {
    const [tab, setTab] = useState("zones");
    return (
        <div className="max-w-5xl mx-auto p-6 space-y-6">
            <div>
                <h1 className="font-display text-2xl text-brand-ink flex items-center gap-2">
                    <Truck className="w-6 h-6 text-brand-copper" /> Shipping & fulfillment
                </h1>
                <p className="text-brand-ink/60 mt-1 text-sm">
                    Ship anywhere in the world — set the countries you sell to, build rate zones, and find the right carrier.
                </p>
            </div>
            <div className="flex gap-1 border-b border-brand-line overflow-x-auto">
                {[["zones", "Zones & rates", MapPin], ["settings", "Settings", Building2], ["carriers", "Carriers", Truck]].map(([id, lbl, Icon]) => (
                    <button key={id} onClick={() => setTab(id)}
                        className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px whitespace-nowrap ${tab === id ? "border-brand-copper text-brand-copper" : "border-transparent text-zinc-500 hover:text-brand-ink"}`}>
                        <Icon className="w-4 h-4" /> {lbl}
                    </button>
                ))}
            </div>
            {tab === "zones" && <ZonesTab />}
            {tab === "settings" && <SettingsTab />}
            {tab === "carriers" && <CarriersTab />}
        </div>
    );
}

/* ------------------------------- Zones & rates ------------------------------ */
function blankRate() {
    return { name: "Standard", type: "flat", amount_dollars: 5.99, free_over_dollars: 50, tiers: [] };
}
function toRatePayload(r) {
    const base = {
        name: r.name || "Shipping", type: r.type,
        amount_cents: Math.round(Number(r.amount_dollars || 0) * 100),
        free_over_cents: Math.round(Number(r.free_over_dollars || 0) * 100),
        tiers: (r.tiers || []).map((t) => ({
            up_to: t.up_to === "" || t.up_to === null ? null : Number(t.up_to),
            amount_cents: Math.round(Number(t.amount_dollars || 0) * 100),
        })),
    };
    return base;
}
function fromRate(r) {
    return {
        name: r.name, type: r.type,
        amount_dollars: (r.amount_cents || 0) / 100,
        free_over_dollars: (r.free_over_cents || 0) / 100,
        tiers: (r.tiers || []).map((t) => ({
            up_to: t.up_to == null ? "" : t.up_to,
            amount_dollars: (t.amount_cents || 0) / 100,
        })),
    };
}

function ZonesTab() {
    const [zones, setZones] = useState([]);
    const [countries, setCountries] = useState([]);
    const [editing, setEditing] = useState(null); // zone form
    const [busy, setBusy] = useState(false);

    const load = useCallback(async () => {
        const [z, c] = await Promise.all([api.get("/store/shipping/zones"), api.get("/store/shipping/countries")]);
        setZones(z.data.zones || []);
        setCountries(c.data.countries || []);
    }, []);
    useEffect(() => { load(); }, [load]);

    const startNew = () => setEditing({ id: null, name: "", country_codes: [], rates: [blankRate()] });
    const startEdit = (z) => setEditing({ id: z.id, name: z.name, country_codes: z.country_codes || [], rates: (z.rates || []).map(fromRate) });

    const save = async () => {
        if (!editing.name.trim()) return toast.error("Zone name required");
        if (!editing.country_codes.length) return toast.error("Pick at least one country (or 'Rest of world')");
        setBusy(true);
        try {
            const payload = { name: editing.name, country_codes: editing.country_codes, rates: editing.rates.map(toRatePayload) };
            if (editing.id) await api.put(`/store/shipping/zones/${editing.id}`, payload);
            else await api.post("/store/shipping/zones", payload);
            toast.success("Zone saved"); setEditing(null); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); } finally { setBusy(false); }
    };
    const del = async (id) => { if (!window.confirm("Delete this zone?")) return; await api.delete(`/store/shipping/zones/${id}`); load(); };

    const regions = [...new Set(countries.map((c) => c.region))];
    const toggleCountry = (code) => setEditing((p) => ({
        ...p, country_codes: p.country_codes.includes(code) ? p.country_codes.filter((x) => x !== code) : [...p.country_codes, code],
    }));

    return (
        <div className="space-y-4">
            {!editing && (
                <>
                    <div className="flex justify-between items-center">
                        <p className="text-sm text-zinc-500">{zones.length} shipping zone{zones.length === 1 ? "" : "s"}</p>
                        <Button onClick={startNew} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="shipping-new-zone"><Plus className="w-4 h-4 mr-1" /> New zone</Button>
                    </div>
                    {zones.length === 0 && <div className={`${card} text-center text-sm text-zinc-400 py-10`}>No shipping zones yet. Create one to start charging for delivery.</div>}
                    {zones.map((z) => (
                        <div key={z.id} className={card} data-testid={`zone-${z.id}`}>
                            <div className="flex items-start justify-between gap-3">
                                <div className="min-w-0">
                                    <div className="font-medium text-brand-ink flex items-center gap-2"><MapPin className="w-4 h-4 text-brand-copper" /> {z.name}</div>
                                    <div className="text-xs text-zinc-500 mt-1">
                                        {z.country_codes.includes("*") ? "Rest of the world" : z.country_codes.join(", ") || "No countries"}
                                    </div>
                                    <div className="flex flex-wrap gap-2 mt-3">
                                        {z.rates.map((r) => (
                                            <span key={r.id} className="inline-flex items-center gap-1 text-xs bg-brand-cream border border-brand-line rounded-full px-2.5 py-1 text-brand-ink">
                                                {r.name}: {r.type === "free_over" ? `free over $${(r.free_over_cents / 100).toFixed(0)}` : r.type === "flat" ? `$${(r.amount_cents / 100).toFixed(2)}` : `${r.type}`}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                                <div className="flex gap-2 shrink-0">
                                    <Button size="sm" variant="outline" className="border-brand-line" onClick={() => startEdit(z)}>Edit</Button>
                                    <Button size="sm" variant="outline" className="border-brand-line text-rose-600" onClick={() => del(z.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                                </div>
                            </div>
                        </div>
                    ))}
                </>
            )}

            {editing && (
                <div className={card} data-testid="zone-editor">
                    <div className="flex justify-between items-center mb-4">
                        <div className="font-medium text-brand-ink">{editing.id ? "Edit zone" : "New zone"}</div>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
                    </div>
                    <label className={label}>Zone name</label>
                    <input className={input} placeholder="e.g. United States, Europe, Rest of world" value={editing.name} onChange={(e) => setEditing((p) => ({ ...p, name: e.target.value }))} data-testid="zone-name" />

                    <div className="mt-4">
                        <label className={label}>Countries in this zone</label>
                        <label className="flex items-center gap-2 text-sm text-brand-ink mb-2 cursor-pointer">
                            <input type="checkbox" checked={editing.country_codes.includes("*")} onChange={() => toggleCountry("*")} />
                            <Globe2 className="w-4 h-4 text-brand-copper" /> Rest of the world (everywhere not in another zone)
                        </label>
                        {!editing.country_codes.includes("*") && (
                            <div className="max-h-56 overflow-y-auto border border-brand-line rounded-lg p-3 space-y-3">
                                {regions.map((region) => (
                                    <div key={region}>
                                        <div className="text-[11px] uppercase tracking-wide text-zinc-400 mb-1">{region}</div>
                                        <div className="flex flex-wrap gap-1.5">
                                            {countries.filter((c) => c.region === region).map((c) => (
                                                <button key={c.code} type="button" onClick={() => toggleCountry(c.code)}
                                                    className={`text-xs rounded-full px-2.5 py-1 border ${editing.country_codes.includes(c.code) ? "bg-brand-copper text-white border-brand-copper" : "bg-white border-brand-line text-zinc-600 hover:border-brand-copper"}`}>
                                                    {c.name}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    <div className="mt-5">
                        <div className="flex justify-between items-center mb-2">
                            <label className={label + " mb-0"}>Rates</label>
                            <Button size="sm" variant="outline" className="border-brand-line" onClick={() => setEditing((p) => ({ ...p, rates: [...p.rates, blankRate()] }))}><Plus className="w-3.5 h-3.5 mr-1" /> Add rate</Button>
                        </div>
                        <div className="space-y-3">
                            {editing.rates.map((r, i) => (
                                <RateEditor key={i} rate={r}
                                    onChange={(nr) => setEditing((p) => ({ ...p, rates: p.rates.map((x, j) => j === i ? nr : x) }))}
                                    onRemove={() => setEditing((p) => ({ ...p, rates: p.rates.filter((_, j) => j !== i) }))} />
                            ))}
                        </div>
                    </div>

                    <Button onClick={save} disabled={busy} className="mt-5 bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="zone-save"><Save className="w-4 h-4 mr-1" /> {busy ? "Saving…" : "Save zone"}</Button>
                </div>
            )}
        </div>
    );
}

function RateEditor({ rate, onChange, onRemove }) {
    const set = (k, v) => onChange({ ...rate, [k]: v });
    const setTier = (i, k, v) => onChange({ ...rate, tiers: rate.tiers.map((t, j) => j === i ? { ...t, [k]: v } : t) });
    const unit = rate.type === "weight" ? "g" : "$";
    return (
        <div className="border border-brand-line rounded-lg p-3 bg-brand-cream/40">
            <div className="grid grid-cols-1 sm:grid-cols-[1fr_150px_auto] gap-2 items-end">
                <div>
                    <label className={label}>Rate name (shown at checkout)</label>
                    <input className={input} value={rate.name} onChange={(e) => set("name", e.target.value)} placeholder="Standard shipping" />
                </div>
                <div>
                    <label className={label}>Type</label>
                    <select className={input} value={rate.type} onChange={(e) => set("type", e.target.value)}>
                        {RATE_TYPES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
                    </select>
                </div>
                <Button size="sm" variant="ghost" className="text-rose-600 mb-0.5" onClick={onRemove}><Trash2 className="w-4 h-4" /></Button>
            </div>

            {(rate.type === "flat" || rate.type === "free_over") && (
                <div className="grid grid-cols-2 gap-2 mt-2">
                    <div>
                        <label className={label}>{rate.type === "free_over" ? "Rate below threshold ($)" : "Price ($)"}</label>
                        <input className={input} type="number" step="0.01" value={rate.amount_dollars} onChange={(e) => set("amount_dollars", e.target.value)} />
                    </div>
                    {rate.type === "free_over" && (
                        <div>
                            <label className={label}>Free when order over ($)</label>
                            <input className={input} type="number" step="1" value={rate.free_over_dollars} onChange={(e) => set("free_over_dollars", e.target.value)} />
                        </div>
                    )}
                </div>
            )}

            {(rate.type === "weight" || rate.type === "price") && (
                <div className="mt-2">
                    <div className="text-[11px] text-zinc-500 mb-1">Tiers — charge based on {rate.type === "weight" ? "total weight (grams)" : "order value ($)"}. Leave the last “up to” empty for “and above”.</div>
                    {(rate.tiers || []).map((t, i) => (
                        <div key={i} className="grid grid-cols-[1fr_1fr_auto] gap-2 mb-1.5">
                            <input className={input} type="number" placeholder={`up to (${unit})`} value={t.up_to} onChange={(e) => setTier(i, "up_to", e.target.value)} />
                            <input className={input} type="number" step="0.01" placeholder="price ($)" value={t.amount_dollars} onChange={(e) => setTier(i, "amount_dollars", e.target.value)} />
                            <Button size="sm" variant="ghost" className="text-rose-600" onClick={() => onChange({ ...rate, tiers: rate.tiers.filter((_, j) => j !== i) })}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                    ))}
                    <Button size="sm" variant="outline" className="border-brand-line mt-1" onClick={() => onChange({ ...rate, tiers: [...(rate.tiers || []), { up_to: "", amount_dollars: 0 }] })}><Plus className="w-3.5 h-3.5 mr-1" /> Add tier</Button>
                </div>
            )}
        </div>
    );
}

/* --------------------------------- Settings -------------------------------- */
function SettingsTab() {
    const [s, setS] = useState(null);
    const [countries, setCountries] = useState([]);
    const [busy, setBusy] = useState(false);
    const load = useCallback(async () => {
        const [st, c] = await Promise.all([api.get("/store/shipping/settings"), api.get("/store/shipping/countries")]);
        setS(st.data); setCountries(c.data.countries || []);
    }, []);
    useEffect(() => { load(); }, [load]);
    if (!s) return null;
    const setOrigin = (k, v) => setS((p) => ({ ...p, origin: { ...p.origin, [k]: v } }));
    const worldwide = (s.countries_served || []).includes("*");
    const toggleServed = (code) => setS((p) => {
        const cur = p.countries_served.filter((x) => x !== "*");
        return { ...p, countries_served: cur.includes(code) ? cur.filter((x) => x !== code) : [...cur, code] };
    });
    const save = async () => {
        setBusy(true);
        try {
            await api.put("/store/shipping/settings", {
                origin: s.origin, weight_unit: s.weight_unit,
                default_weight_grams: Number(s.default_weight_grams || 0),
                handling_fee_cents: Math.round(Number(s.handling_fee_dollars ?? (s.handling_fee_cents / 100)) * 100),
                countries_served: s.countries_served, currency: s.currency,
            });
            toast.success("Shipping settings saved"); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); } finally { setBusy(false); }
    };
    const regions = [...new Set(countries.map((c) => c.region))];
    return (
        <div className="grid md:grid-cols-2 gap-5">
            <div className={card}>
                <div className="font-medium text-brand-ink mb-3 flex items-center gap-2"><MapPin className="w-4 h-4 text-brand-copper" /> Ship-from address</div>
                <p className="text-xs text-zinc-500 mb-3">Printed on invoices &amp; packing slips and used for carrier labels.</p>
                <input className={input + " mb-2"} placeholder="Business / warehouse name" value={s.origin.name} onChange={(e) => setOrigin("name", e.target.value)} />
                <input className={input + " mb-2"} placeholder="Street address" value={s.origin.address} onChange={(e) => setOrigin("address", e.target.value)} />
                <div className="grid grid-cols-2 gap-2 mb-2">
                    <input className={input} placeholder="City" value={s.origin.city} onChange={(e) => setOrigin("city", e.target.value)} />
                    <input className={input} placeholder="State / region" value={s.origin.region} onChange={(e) => setOrigin("region", e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                    <input className={input} placeholder="Postal code" value={s.origin.postal_code} onChange={(e) => setOrigin("postal_code", e.target.value)} />
                    <select className={input} value={s.origin.country} onChange={(e) => setOrigin("country", e.target.value)}>
                        {countries.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
                    </select>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                    <div>
                        <label className={label}>Default item weight (g)</label>
                        <input className={input} type="number" value={s.default_weight_grams} onChange={(e) => setS((p) => ({ ...p, default_weight_grams: e.target.value }))} />
                    </div>
                    <div>
                        <label className={label}>Handling fee ($)</label>
                        <input className={input} type="number" step="0.01" value={s.handling_fee_dollars ?? (s.handling_fee_cents / 100)} onChange={(e) => setS((p) => ({ ...p, handling_fee_dollars: e.target.value }))} />
                    </div>
                </div>
                <Button onClick={save} disabled={busy} className="mt-4 bg-brand-copper hover:bg-brand-copperHover text-white"><Save className="w-4 h-4 mr-1" /> {busy ? "Saving…" : "Save settings"}</Button>
            </div>

            <div className={card}>
                <div className="font-medium text-brand-ink mb-3 flex items-center gap-2"><Globe2 className="w-4 h-4 text-brand-copper" /> Countries you sell to</div>
                <label className="flex items-center gap-2 text-sm text-brand-ink mb-3 cursor-pointer">
                    <input type="checkbox" checked={worldwide} onChange={() => setS((p) => ({ ...p, countries_served: worldwide ? [] : ["*"] }))} data-testid="ship-worldwide" />
                    Sell &amp; ship worldwide
                </label>
                {!worldwide && (
                    <div className="max-h-72 overflow-y-auto border border-brand-line rounded-lg p-3 space-y-3">
                        {regions.map((region) => (
                            <div key={region}>
                                <div className="text-[11px] uppercase tracking-wide text-zinc-400 mb-1">{region}</div>
                                <div className="flex flex-wrap gap-1.5">
                                    {countries.filter((c) => c.region === region).map((c) => (
                                        <button key={c.code} type="button" onClick={() => toggleServed(c.code)}
                                            className={`text-xs rounded-full px-2.5 py-1 border ${(s.countries_served || []).includes(c.code) ? "bg-brand-copper text-white border-brand-copper" : "bg-white border-brand-line text-zinc-600 hover:border-brand-copper"}`}>
                                            {c.name}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

/* --------------------------------- Carriers -------------------------------- */
function CarriersTab() {
    const [country, setCountry] = useState("US");
    const [countries, setCountries] = useState([]);
    const [data, setData] = useState({ carriers: [], aggregators: [] });
    const load = useCallback(async () => {
        const { data } = await api.get(`/store/shipping/carriers?country=${country}`);
        setData(data);
    }, [country]);
    useEffect(() => { api.get("/store/shipping/countries").then((r) => setCountries(r.data.countries || [])); }, []);
    useEffect(() => { load(); }, [load]);
    return (
        <div className="space-y-5">
            <div className={`${card} bg-brand-cream/50`}>
                <div className="flex items-center gap-3 flex-wrap">
                    <span className="text-sm text-brand-ink font-medium">Show carriers that deliver to</span>
                    <select className={input + " max-w-xs"} value={country} onChange={(e) => setCountry(e.target.value)} data-testid="carrier-country">
                        {countries.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
                    </select>
                </div>
            </div>

            <div>
                <div className="font-medium text-brand-ink mb-2 flex items-center gap-2"><Package className="w-4 h-4 text-brand-copper" /> Connect once, get every carrier</div>
                <div className="grid sm:grid-cols-3 gap-3">
                    {(data.aggregators || []).map((a) => (
                        <div key={a.key} className={`${card} flex flex-col`}>
                            <div className="font-medium text-brand-ink flex items-center gap-2"><Boxes className="w-4 h-4 text-brand-copper" /> {a.name}</div>
                            <p className="text-xs text-zinc-500 mt-2 flex-1">{a.notes}</p>
                            <a href={a.website} target="_blank" rel="noreferrer" className="text-xs text-brand-copper hover:underline mt-3 inline-flex items-center gap-1">Visit {a.name} <ExternalLink className="w-3 h-3" /></a>
                        </div>
                    ))}
                </div>
            </div>

            <div>
                <div className="font-medium text-brand-ink mb-2 flex items-center gap-2"><Truck className="w-4 h-4 text-brand-copper" /> Carriers serving {countries.find((c) => c.code === country)?.name || country}</div>
                <div className="grid sm:grid-cols-2 gap-3">
                    {(data.carriers || []).map((c) => (
                        <div key={c.key} className={card}>
                            <div className="flex items-start justify-between gap-2">
                                <div className="font-medium text-brand-ink">{c.name}</div>
                                {c.api && <span className="text-[10px] uppercase tracking-wide bg-emerald-100 text-emerald-700 rounded px-1.5 py-0.5">API</span>}
                            </div>
                            <p className="text-xs text-zinc-500 mt-1.5">{c.notes}</p>
                            <div className="flex flex-wrap gap-1.5 mt-2">
                                {(c.services || []).map((s) => <span key={s} className="text-[11px] bg-brand-cream border border-brand-line rounded-full px-2 py-0.5 text-zinc-600">{s}</span>)}
                            </div>
                            <a href={c.website} target="_blank" rel="noreferrer" className="text-xs text-brand-copper hover:underline mt-3 inline-flex items-center gap-1">Website <ExternalLink className="w-3 h-3" /></a>
                        </div>
                    ))}
                    {!data.carriers?.length && <div className={`${card} text-sm text-zinc-400`}>No carriers listed for this country — use an aggregator above for global coverage.</div>}
                </div>
            </div>
        </div>
    );
}
