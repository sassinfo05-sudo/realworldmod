"""Email one-time-code 2FA shared by customer accounts and staff accounts.

Product rules:
- Every account has email 2FA ON by default. Customers may turn it off (Security page).
  Staff accounts can never turn it off.
- If the platform 2FA sender is NOT configured (Staff panel → Integrations → Email),
  email 2FA is skipped entirely so nobody gets locked out.
- Challenges live 10 minutes, max 5 attempts, single use.
- In APP_ENV=dev the code is also returned as `dev_code` so QA can complete the flow
  without a real mailbox.
"""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

from bson import ObjectId
from fastapi import HTTPException

from .. import config
from ..db import get_db, utc_now_iso
from . import platform_mail

CHALLENGE_TTL_MIN = 10
MAX_ATTEMPTS = 5


def _hash_code(code: str) -> str:
    """Keyed hash of a one-time code so plaintext codes are never stored at rest."""
    import hashlib
    import hmac
    return hmac.new(config.JWT_SECRET.encode(), (code or "").strip().encode(),
                    hashlib.sha256).hexdigest()


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def email_2fa_available() -> bool:
    return await platform_mail.is_configured()


async def create_challenge(subject_id: str, email: str, kind: str, brand: str = "Zanelvo") -> Dict[str, Any]:
    """kind = 'user' | 'staff'. Sends the code and returns the public challenge payload."""
    db = get_db()
    code = f"{secrets.randbelow(10**6):06d}"
    doc = {
        "subject_id": subject_id, "kind": kind, "email": email,
        "code_hash": _hash_code(code),  # never store the plaintext code
        "attempts": 0, "consumed": False,
        "expires_at": (_now() + timedelta(minutes=CHALLENGE_TTL_MIN)).isoformat().replace("+00:00", "Z"),
        "created_at": utc_now_iso(),
    }
    r = await db.mfa_challenges.insert_one(doc)
    sent = await platform_mail.send(
        "twofa", email, f"{code} is your {brand} sign-in code",
        f"Your {brand} verification code is {code}. It expires in {CHALLENGE_TTL_MIN} minutes.\n\n"
        "If you didn't try to sign in, change your password right away.",
        f"<p>Your <b>{brand}</b> verification code is</p><p style='font-size:28px;letter-spacing:6px'><b>{code}</b></p>"
        f"<p>It expires in {CHALLENGE_TTL_MIN} minutes.</p>",
    )
    out: Dict[str, Any] = {
        "mfa_required": True, "method": "email", "challenge_id": str(r.inserted_id),
        "masked_email": _mask(email), "expires_in_sec": CHALLENGE_TTL_MIN * 60,
        "delivery": "sent" if sent.get("ok") and not sent.get("simulated") else "simulated",
    }
    if config.APP_ENV == "dev":
        out["dev_code"] = code
    return out


async def verify_challenge(challenge_id: str, code: str, kind: str) -> Dict[str, Any]:
    """Returns the challenge doc on success; raises HTTPException otherwise."""
    db = get_db()
    try:
        oid = ObjectId(challenge_id)
    except Exception:
        raise HTTPException(400, "Invalid challenge")
    doc = await db.mfa_challenges.find_one({"_id": oid, "kind": kind})
    if not doc or doc.get("consumed"):
        raise HTTPException(400, "Challenge expired or already used")
    if datetime.fromisoformat(doc["expires_at"].replace("Z", "+00:00")) < _now():
        raise HTTPException(400, "Code expired — request a new one")
    if doc.get("attempts", 0) >= MAX_ATTEMPTS:
        raise HTTPException(429, "Too many attempts — request a new code")
    import hmac as _hmac
    if not _hmac.compare_digest(_hash_code(code), doc.get("code_hash") or ""):
        await db.mfa_challenges.update_one({"_id": oid}, {"$inc": {"attempts": 1}})
        raise HTTPException(401, "Incorrect code")
    # ATOMIC single-use consumption: only the first concurrent verifier flips consumed False→True.
    # A second request with the same (valid) code races here and gets None → rejected.
    claimed = await db.mfa_challenges.find_one_and_update(
        {"_id": oid, "kind": kind, "consumed": {"$ne": True}},
        {"$set": {"consumed": True, "consumed_at": utc_now_iso()}})
    if not claimed:
        raise HTTPException(400, "Challenge expired or already used")
    return claimed


async def resend_challenge(challenge_id: str, kind: str, brand: str = "Zanelvo") -> Dict[str, Any]:
    db = get_db()
    try:
        doc = await db.mfa_challenges.find_one({"_id": ObjectId(challenge_id), "kind": kind, "consumed": False})
    except Exception:
        doc = None
    if not doc:
        raise HTTPException(400, "Challenge not found")
    await db.mfa_challenges.update_one({"_id": doc["_id"]}, {"$set": {"consumed": True}})
    return await create_challenge(doc["subject_id"], doc["email"], kind, brand)


def _mask(email: str) -> str:
    try:
        name, dom = email.split("@", 1)
        return f"{name[0]}{'•' * max(2, len(name) - 2)}{name[-1]}@{dom}" if len(name) > 2 else f"{name[0]}••@{dom}"
    except Exception:
        return "••••"


def user_email_2fa_enabled(user_doc: Dict[str, Any]) -> bool:
    """Default ON — absent field means enabled."""
    return user_doc.get("mfa_email_enabled", True) is not False
