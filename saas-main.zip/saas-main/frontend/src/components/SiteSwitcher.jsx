import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { toast } from "sonner";
import { ChevronsUpDown, Globe2, Lock, Plus, Check } from "lucide-react";

/** Sidebar site switcher — lists the org's websites; switching sets the active site. */
export default function SiteSwitcher() {
    const [state, setState] = useState(null);
    const [open, setOpen] = useState(false);
    const navigate = useNavigate();
    async function load() { try { const { data } = await api.get("/sites"); setState(data); } catch { /* no org */ } }
    useEffect(() => { load(); const h = () => load(); window.addEventListener("zanelvo:sites-changed", h); return () => window.removeEventListener("zanelvo:sites-changed", h); }, []);
    if (!state || !state.sites?.length) return null;
    const active = state.sites.find((s) => s.is_active) || state.sites[0];
    async function activate(id) {
        try { const { data } = await api.post(`/sites/${id}/activate`); setState(data); setOpen(false); toast.success("Switched site"); window.dispatchEvent(new Event("zanelvo:sites-changed")); window.location.reload(); }
        catch (e) { toast.error(e?.response?.data?.detail || "Could not switch"); }
    }
    return (
        <div className="relative">
            <button type="button" onClick={() => setOpen((o) => !o)} data-testid="site-switcher"
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg border border-brand-line bg-brand-surface hover:border-zinc-300 text-left">
                <span className="w-6 h-6 rounded-md grid place-items-center text-white text-xs font-semibold" style={{ background: active.theme_primary || "#4F46E5" }}>{(active.name || "S")[0]}</span>
                <span className="flex-1 min-w-0">
                    <span className="block text-xs font-medium truncate">{active.name}</span>
                    <span className="block text-[10px] text-zinc-400 truncate flex items-center gap-1">
                        {active.maintenance?.enabled ? <><Lock className="w-3 h-3" /> Private</> : active.status === "published" ? <><Globe2 className="w-3 h-3" /> Live</> : "Draft"} · {state.used}/{state.limit} sites
                    </span>
                </span>
                <ChevronsUpDown className="w-3.5 h-3.5 text-zinc-400" />
            </button>
            {open && (
                <div className="absolute left-0 right-0 mt-1 rounded-lg border border-brand-line bg-white dark:bg-zinc-900 shadow-xl z-40 overflow-hidden" data-testid="site-switcher-menu">
                    {state.sites.map((s) => (
                        <button key={s.id} type="button" onClick={() => s.is_active ? setOpen(false) : activate(s.id)} data-testid={`site-switcher-item-${s.id}`}
                            className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs hover:bg-zinc-50 dark:hover:bg-white/5">
                            <span className="w-5 h-5 rounded grid place-items-center text-white text-[10px]" style={{ background: s.theme_primary || "#4F46E5" }}>{(s.name || "S")[0]}</span>
                            <span className="flex-1 truncate">{s.name}</span>
                            {s.is_active && <Check className="w-3.5 h-3.5 text-brand-copper" />}
                        </button>
                    ))}
                    <button type="button" onClick={() => { setOpen(false); navigate("/app/sites"); }} className="w-full flex items-center gap-2 px-3 py-2 text-xs text-brand-copper hover:bg-brand-copper/5 border-t border-brand-line" data-testid="site-switcher-manage">
                        <Plus className="w-3.5 h-3.5" /> Manage sites</button>
                </div>
            )}
        </div>
    );
}
