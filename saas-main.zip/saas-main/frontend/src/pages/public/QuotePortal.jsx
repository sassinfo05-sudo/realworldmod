import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CheckCircle2, XCircle, FileText, Clock, Loader2 } from "lucide-react";

const API = process.env.REACT_APP_BACKEND_URL;

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

export default function QuotePortal() {
    const { qid } = useParams();
    const [params] = useSearchParams();
    const tk = params.get("tk");
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [busy, setBusy] = useState(false);
    const [declineOpen, setDeclineOpen] = useState(false);
    const [declineReason, setDeclineReason] = useState("");

    async function load() {
        try {
            const r = await fetch(`${API}/api/public/portal/quote/${qid}?tk=${encodeURIComponent(tk)}`);
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            setData(await r.json());
        } catch (e) { setError(e.message); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [qid, tk]);

    async function accept() {
        setBusy(true);
        try {
            const r = await fetch(`${API}/api/public/portal/quote/${qid}/accept?tk=${encodeURIComponent(tk)}`, { method: "POST" });
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            await load();
        } catch (e) { setError(e.message); } finally { setBusy(false); }
    }
    async function decline() {
        setBusy(true);
        try {
            const r = await fetch(`${API}/api/public/portal/quote/${qid}/decline?tk=${encodeURIComponent(tk)}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ reason: declineReason.trim() || null }),
            });
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            setDeclineOpen(false);
            await load();
        } catch (e) { setError(e.message); } finally { setBusy(false); }
    }

    if (error && !data) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-brand-surface p-6" data-testid="quote-portal-error">
                <div className="max-w-md rounded-xl border border-brand-line bg-white p-8 text-center">
                    <XCircle className="w-8 h-8 text-red-500 mx-auto" />
                    <h1 className="font-display text-2xl text-brand-ink mt-3">This quote link isn't valid.</h1>
                    <p className="text-sm text-zinc-500 mt-2">It may have expired or been revoked. Please contact the business.</p>
                </div>
            </div>
        );
    }
    if (!data) {
        return <div className="min-h-screen flex items-center justify-center text-zinc-500"><Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading…</div>;
    }

    const q = data.quote;
    const isAccepted = q.status === "accepted";
    const isDeclined = q.status === "declined";
    const isPendingApproval = q.approval_state === "pending";
    const canDecide = !isAccepted && !isDeclined && !isPendingApproval;

    return (
        <div className="min-h-screen bg-brand-surface" data-testid="quote-portal-page">
            <div className="max-w-2xl mx-auto py-8 md:py-16 px-4 md:px-6">
                {/* Header */}
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Quote</div>
                <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium leading-tight">
                    {q.number || "Your quote"}
                </h1>
                <p className="mt-2 text-sm text-zinc-500">From {data.business?.business_name || data.org_name || "your provider"}.</p>

                {/* State banner */}
                {isAccepted && (
                    <div className="mt-6 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 flex items-start gap-3" data-testid="quote-portal-accepted-banner">
                        <CheckCircle2 className="w-5 h-5 mt-0.5" />
                        <div>
                            <div className="font-medium">You've accepted this quote.</div>
                            <div className="text-sm mt-0.5">The business has been notified. You'll receive next steps by email.</div>
                        </div>
                    </div>
                )}
                {isDeclined && (
                    <div className="mt-6 rounded-lg bg-zinc-50 border border-brand-line text-zinc-700 p-4 flex items-start gap-3" data-testid="quote-portal-declined-banner">
                        <XCircle className="w-5 h-5 mt-0.5" />
                        <div>
                            <div className="font-medium">This quote was declined.</div>
                            <div className="text-sm mt-0.5">Reach out if you'd like a revised offer.</div>
                        </div>
                    </div>
                )}
                {isPendingApproval && (
                    <div className="mt-6 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 p-4 flex items-start gap-3" data-testid="quote-portal-pending-banner">
                        <Clock className="w-5 h-5 mt-0.5" />
                        <div>
                            <div className="font-medium">Under internal review.</div>
                            <div className="text-sm mt-0.5">You'll hear back shortly with confirmation.</div>
                        </div>
                    </div>
                )}

                {/* Line items */}
                <div className="mt-6 rounded-2xl border border-brand-line bg-white overflow-hidden">
                    <div className="px-5 py-4 border-b border-brand-line flex items-center gap-2 text-zinc-500 text-sm">
                        <FileText className="w-4 h-4" /> Line items
                    </div>
                    <div className="divide-y divide-brand-line">
                        {(q.lines || []).map((l, idx) => (
                            <div key={l.id || idx} className="px-5 py-4 flex items-center justify-between gap-4" data-testid={`quote-line-${idx}`}>
                                <div className="min-w-0">
                                    <div className="font-medium text-brand-ink truncate">{l.label}</div>
                                    {l.description && <div className="text-xs text-zinc-500 mt-0.5">{l.description}</div>}
                                    <div className="text-xs text-zinc-500 mt-0.5">{l.quantity} × {money(l.unit_price_cents, q.currency)}{l.discount_percent ? ` · −${Math.round(l.discount_percent)}%` : ""}</div>
                                </div>
                                <div className="font-mono text-sm text-brand-ink whitespace-nowrap">{money(l.quantity * l.unit_price_cents * (1 - (Math.max(0, Math.min(100, l.discount_percent || 0))) / 100), q.currency)}</div>
                            </div>
                        ))}
                    </div>
                    <div className="px-5 py-4 border-t border-brand-line bg-brand-cream/30 space-y-1">
                        <div className="flex justify-between text-sm"><span className="text-zinc-600">Subtotal</span><span className="font-mono">{money(q.totals?.subtotal_cents, q.currency)}</span></div>
                        {q.totals?.discount_cents > 0 && <div className="flex justify-between text-sm text-emerald-700"><span>Discount</span><span className="font-mono">−{money(q.totals.discount_cents, q.currency)}</span></div>}
                        {q.totals?.tax_cents > 0 && <div className="flex justify-between text-sm"><span className="text-zinc-600">Tax</span><span className="font-mono">{money(q.totals.tax_cents, q.currency)}</span></div>}
                        <div className="flex justify-between items-center pt-2 border-t border-brand-line">
                            <span className="text-brand-ink font-medium">Total</span>
                            <span className="font-mono text-xl text-brand-ink" data-testid="quote-portal-total">{money(q.totals?.total_cents, q.currency)}</span>
                        </div>
                    </div>
                </div>

                {q.notes && (
                    <div className="mt-4 text-sm text-zinc-600 rounded-md border border-brand-line bg-white p-4">
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Notes</div>
                        {q.notes}
                    </div>
                )}
                {q.terms && (
                    <div className="mt-3 text-xs text-zinc-500 rounded-md border border-dashed border-brand-line p-3">
                        <div className="uppercase tracking-widest mb-1">Terms</div>
                        {q.terms}
                    </div>
                )}

                {/* Actions */}
                {canDecide && (
                    <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3" data-testid="quote-portal-actions">
                        <Button
                            onClick={accept}
                            disabled={busy}
                            className="bg-brand-copper hover:bg-brand-copperHover text-white h-12 text-base"
                            data-testid="quote-portal-accept-btn"
                        >
                            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                            Accept quote
                        </Button>
                        <Dialog open={declineOpen} onOpenChange={setDeclineOpen}>
                            <DialogTrigger asChild>
                                <Button variant="outline" className="h-12 text-base" data-testid="quote-portal-decline-btn">
                                    Decline
                                </Button>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader><DialogTitle>Decline this quote?</DialogTitle></DialogHeader>
                                <p className="text-sm text-zinc-600">Optional — let them know why. This helps them come back with a better fit.</p>
                                <Textarea
                                    value={declineReason}
                                    onChange={(e) => setDeclineReason(e.target.value)}
                                    placeholder="Too high, timing off, going with another provider…"
                                    className="mt-2"
                                    rows={4}
                                    data-testid="quote-portal-decline-reason"
                                />
                                <DialogFooter>
                                    <Button variant="ghost" onClick={() => setDeclineOpen(false)}>Cancel</Button>
                                    <Button variant="destructive" onClick={decline} disabled={busy} data-testid="quote-portal-decline-confirm">
                                        Decline quote
                                    </Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                    </div>
                )}
                {error && <div className="mt-4 rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm" data-testid="quote-portal-error-msg">{error}</div>}

                <div className="mt-8 text-center text-xs text-zinc-400">Quotes are signed digitally. Your IP + timestamp are recorded on acceptance.</div>
            </div>
        </div>
    );
}
