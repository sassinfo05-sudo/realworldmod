"""Managed phone numbers & AI voice control — owner-scoped under /api/numbers.

Browse a country-filtered catalog of numbers for sale, buy through our site
(ownership auto-assigned to the org), manage multiple numbers, and configure
per-number AI voice (persona, spoken language, greeting, default messages,
forwarding, SMS auto-reply, recording).

Simulated-until-connected: works end-to-end in simulated mode; provisions REAL
numbers once the founder connects a carrier (Telnyx recommended, or Twilio).
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..deps import current_user, require_org
from ..models import User
from ..services import numbers as svc

router = APIRouter(prefix="/numbers", tags=["numbers"])


@router.get("/settings")
async def settings(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    carrier = await svc.platform_carrier()
    allot = await svc.allotment(org_id)
    return {
        "carrier": carrier,
        "allotment": allot,
        "carriers": svc.carrier_summary(),
        "countries": svc.COUNTRIES,
        "languages": svc.SUPPORTED_LANGUAGES,
        "personas": svc.VOICE_PERSONAS,
        "metered": {"voice_min": svc.RETAIL_VOICE_MIN, "sms": svc.RETAIL_SMS},
    }


@router.get("/marketplace")
async def marketplace(country: str = "US", kind: str = "local", area_code: str = "",
                       user: User = Depends(current_user), org_id: str = Depends(require_org)):
    country = (country or "US").upper()
    if country not in svc.COUNTRY_BY_CODE:
        raise HTTPException(404, "Unknown country")
    catalog = svc.generate_catalog(country, kind=kind, limit=12, area_code=area_code)
    carrier = await svc.platform_carrier()
    return {"country": country, "kind": kind, "mode": carrier["mode"], "numbers": catalog}


@router.get("")
async def list_owned(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {
        "numbers": await svc.list_numbers(org_id),
        "allotment": await svc.allotment(org_id),
    }


class BuyIn(BaseModel):
    number: str
    country: str = "US"
    kind: str = "local"
    catalog_id: str = ""


@router.post("/buy")
async def buy(req: BuyIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    if not req.number.strip():
        raise HTTPException(400, "number required")
    country = (req.country or "US").upper()
    doc = await svc.buy_number(org_id, req.number.strip(), country, kind=req.kind,
                                catalog_id=req.catalog_id)
    return {"ok": True, "number": doc, "allotment": await svc.allotment(org_id)}


@router.get("/{number_id}")
async def detail(number_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    d = await svc.get_number(org_id, number_id)
    if not d:
        raise HTTPException(404, "Number not found")
    return d


class VoiceConfigIn(BaseModel):
    enabled: Optional[bool] = None
    persona: Optional[str] = None
    language: Optional[str] = None
    speaking_style: Optional[str] = None
    greeting: Optional[str] = None
    messages: Optional[Dict[str, Any]] = None
    forwarding: Optional[Dict[str, Any]] = None
    sms_auto_reply: Optional[Dict[str, Any]] = None
    record_calls: Optional[bool] = None
    voicemail_transcription: Optional[bool] = None


@router.put("/{number_id}/voice")
async def update_voice(number_id: str, req: VoiceConfigIn,
                        user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from ..services.entitlements import enforce_feature_enabled
    await enforce_feature_enabled(org_id, "ai_receptionist")
    patch = {k: v for k, v in req.model_dump().items() if v is not None}
    d = await svc.update_voice_config(org_id, number_id, patch)
    if not d:
        raise HTTPException(404, "Number not found")
    return {"ok": True, "number": d}


class TestCallIn(BaseModel):
    message: str = "I'd like to book an appointment for Thursday."


@router.post("/{number_id}/test-call")
async def test_call(number_id: str, req: TestCallIn,
                     user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Simulated test: shows how the AI would greet + answer in the chosen language."""
    d = await svc.get_number(org_id, number_id)
    if not d:
        raise HTTPException(404, "Number not found")
    vc = d.get("voice_config") or svc.default_voice_config()
    lang = vc.get("language", "en-US")
    lang_name = svc.LANG_NAME.get(lang, "English")
    transcript = [
        {"role": "assistant", "text": vc.get("greeting", "Hello!")},
        {"role": "caller", "text": req.message},
    ]
    reply = f"Absolutely — I can help with that. (This is a simulated preview; when a carrier is connected I'll answer live in {lang_name}.)"
    transcript.append({"role": "assistant", "text": reply})
    return {"ok": True, "language": lang, "language_name": lang_name,
            "persona": vc.get("persona"), "transcript": transcript,
            "mode": d.get("provisioning_mode", "simulated")}


@router.delete("/{number_id}")
async def release(number_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    ok = await svc.release_number(org_id, number_id)
    if not ok:
        raise HTTPException(404, "Number not found")
    return {"ok": True, "allotment": await svc.allotment(org_id)}
