"""Custom hostname provider adapters.

Provider-neutral interface + two implementations:
  - SimulatedProvider: state machine you can drive locally for testing (used by tests
    and by the dashboard wizard when Cloudflare isn't wired). Predictable transitions.
  - CloudflareProvider: real API client for the Cloudflare "Custom Hostnames for SaaS"
    endpoints. Honest "Not connected" state when API token is not configured.

Nothing here writes to Mongo — the routes layer holds state; the adapter just talks
to the provider and returns records/instructions.
"""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import httpx


@dataclass
class HostnameStatus:
    state: str  # pending | verifying | connected | error
    ssl_status: str = "unknown"  # unknown | initializing | pending_validation | active | failed
    ownership_record: Optional[Dict[str, str]] = None  # {type, name, value}
    dns_records: List[Dict[str, str]] = field(default_factory=list)
    provider_ref: Optional[str] = None
    error_detail: Optional[str] = None
    error_hint: Optional[str] = None


class CustomHostnameProvider(ABC):
    key: str = "abstract"
    label: str = "Abstract"
    is_connected: bool = False
    honest_status: str = "Provider adapter is abstract — implement a subclass."

    @abstractmethod
    async def create_hostname(self, hostname: str, origin_slug: str) -> HostnameStatus: ...

    @abstractmethod
    async def check_status(self, hostname: str, provider_ref: Optional[str] = None) -> HostnameStatus: ...

    @abstractmethod
    async def delete_hostname(self, hostname: str, provider_ref: Optional[str] = None) -> None: ...

    @abstractmethod
    async def get_dns_instructions(self, hostname: str, origin_slug: str) -> List[Dict[str, str]]: ...

    @abstractmethod
    async def verify_ownership(self, hostname: str, provider_ref: Optional[str] = None) -> HostnameStatus: ...


# --------------------------- Simulated ---------------------------

# Internal in-memory state machine — shared across process. This is deliberately
# simple: entries move Pending → Verifying → Connected on repeated status polls.
_SIMULATED_STATE: Dict[str, Dict[str, Any]] = {}
_ORIGIN_HOST = os.environ.get("PUBLIC_ORIGIN_HOSTNAME", "zanelvo.com")


class SimulatedProvider(CustomHostnameProvider):
    key = "simulated"
    label = "Simulated (testing)"
    is_connected = True
    honest_status = (
        "Simulated provider. Drives the wizard state machine end-to-end without touching DNS. "
        "Use for local testing; not for production traffic."
    )

    async def create_hostname(self, hostname: str, origin_slug: str) -> HostnameStatus:
        hostname = hostname.lower()
        ownership = {
            "type": "TXT",
            "name": f"_zanelvo-verify.{hostname}",
            "value": f"zv-verify-{abs(hash(hostname)) % 10_000_000:07d}",
        }
        dns = [
            {"type": "CNAME", "name": hostname, "value": _ORIGIN_HOST,
             "note": "Points your domain at the Zanelvo edge."},
            ownership | {"note": "Proves you own the domain."},
        ]
        _SIMULATED_STATE[hostname] = {"polls": 0, "origin_slug": origin_slug, "state": "pending"}
        return HostnameStatus(
            state="pending",
            ssl_status="pending_validation",
            ownership_record=ownership,
            dns_records=dns,
            provider_ref=f"sim_{abs(hash(hostname)) % 100000:05d}",
        )

    async def check_status(self, hostname: str, provider_ref: Optional[str] = None) -> HostnameStatus:
        hostname = hostname.lower()
        entry = _SIMULATED_STATE.setdefault(hostname, {"polls": 0, "state": "pending"})
        entry["polls"] += 1

        # Drive the state machine forward on repeat polls.
        if entry["state"] == "pending" and entry["polls"] >= 1:
            entry["state"] = "verifying"
        elif entry["state"] == "verifying" and entry["polls"] >= 3:
            entry["state"] = "connected"

        ssl_map = {"pending": "pending_validation", "verifying": "initializing",
                   "connected": "active"}
        return HostnameStatus(
            state=entry["state"],
            ssl_status=ssl_map.get(entry["state"], "unknown"),
            provider_ref=provider_ref,
        )

    async def delete_hostname(self, hostname: str, provider_ref: Optional[str] = None) -> None:
        _SIMULATED_STATE.pop(hostname.lower(), None)

    async def get_dns_instructions(self, hostname: str, origin_slug: str) -> List[Dict[str, str]]:
        return [
            {"type": "CNAME", "name": hostname, "value": _ORIGIN_HOST,
             "note": "Point your domain at the Zanelvo edge."},
            {"type": "TXT", "name": f"_zanelvo-verify.{hostname}",
             "value": f"zv-verify-{abs(hash(hostname)) % 10_000_000:07d}",
             "note": "Proves you own the domain."},
        ]

    async def verify_ownership(self, hostname: str, provider_ref: Optional[str] = None) -> HostnameStatus:
        # Simulate immediate ownership success
        hostname = hostname.lower()
        entry = _SIMULATED_STATE.setdefault(hostname, {"polls": 0, "state": "pending"})
        entry["state"] = "verifying"
        return HostnameStatus(state="verifying", ssl_status="initializing", provider_ref=provider_ref)


# --------------------------- Cloudflare ---------------------------


class CloudflareProvider(CustomHostnameProvider):
    """Real Cloudflare for SaaS Custom Hostnames client.

    Only active when both env vars are present:
      CLOUDFLARE_API_TOKEN, CLOUDFLARE_SAAS_ZONE_ID
    Otherwise the adapter reports `is_connected=False` and every method returns
    an honest error. The rest of the app (dashboard, wizard, domain state) still
    works via the SimulatedProvider.
    """
    key = "cloudflare"
    label = "Cloudflare for SaaS"

    def __init__(self):
        # Credentials come from the encrypted Staff Setup Center (integrations.domains); the env vars are a
        # legacy fallback only. `refresh_from_setup_center()` must be awaited before use (routes do this).
        self.api_token = os.environ.get("CLOUDFLARE_API_TOKEN", "").strip()
        self.zone_id = os.environ.get("CLOUDFLARE_SAAS_ZONE_ID", "").strip()
        self.origin = os.environ.get("CLOUDFLARE_SAAS_ORIGIN", _ORIGIN_HOST)
        self.probe_state = "not_connected"  # not_connected | connected | error
        self.probe_message = ""
        self._apply_status()

    def _apply_status(self) -> None:
        self.is_connected = bool(self.api_token and self.zone_id) and self.probe_state != "error"
        if not (self.api_token and self.zone_id):
            self.honest_status = ("Not connected — add the Cloudflare API token + SaaS zone id in Staff Setup Center → Domains.")
        elif self.probe_state == "error":
            self.honest_status = f"Error — credentials present but Cloudflare rejected them: {self.probe_message}"
        elif self.probe_state == "connected":
            self.honest_status = "Connected to Cloudflare for SaaS (probe OK)."
        else:
            self.honest_status = "Credentials present — run the probe to confirm the connection."

    async def refresh_from_setup_center(self) -> None:
        try:
            from . import integrations as _integ
            raw = (await _integ._raw()).get("domains", {}) or {}  # noqa: SLF001
            tok = (raw.get("cloudflare_api_token") or "").strip()
            zid = (raw.get("cloudflare_zone_id") or "").strip()
            if tok and zid:
                self.api_token, self.zone_id = tok, zid
                self.origin = (raw.get("cloudflare_origin") or "").strip() or self.origin
        except Exception:  # noqa: BLE001
            pass
        self._apply_status()

    async def probe(self) -> Dict[str, Any]:
        """REAL read-only probe: GET the SaaS zone with the token. Never returns the token."""
        await self.refresh_from_setup_center()
        if not (self.api_token and self.zone_id):
            self.probe_state, self.probe_message = "not_connected", ""
            self._apply_status()
            return {"state": "not_connected", "message": self.honest_status}
        try:
            async with httpx.AsyncClient(timeout=15.0) as c:
                r = await c.get(f"https://api.cloudflare.com/client/v4/zones/{self.zone_id}", headers=self._headers())
            data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
            if r.status_code < 400 and data.get("success"):
                self.probe_state, self.probe_message = "connected", ""
                self._apply_status()
                return {"state": "connected", "zone": (data.get("result") or {}).get("name"), "message": self.honest_status}
            msg = ((data.get("errors") or [{}])[0].get("message") or f"HTTP {r.status_code}")
            self.probe_state, self.probe_message = "error", msg[:160]
        except Exception as e:  # noqa: BLE001
            self.probe_state, self.probe_message = "error", type(e).__name__
        self._apply_status()
        return {"state": "error", "message": self.honest_status}

    def _headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.api_token}", "Content-Type": "application/json"}

    def _base_url(self) -> str:
        return f"https://api.cloudflare.com/client/v4/zones/{self.zone_id}/custom_hostnames"

    def _not_connected(self) -> HostnameStatus:
        return HostnameStatus(
            state="error",
            ssl_status="unknown",
            error_detail="Cloudflare provider not connected.",
            error_hint="A platform admin must add the Cloudflare API token and SaaS zone id in Staff Setup Center → Domains.",
        )

    async def _request(self, method: str, path: str = "", **kwargs) -> Dict[str, Any]:
        async with httpx.AsyncClient(timeout=15.0) as c:
            resp = await c.request(method, self._base_url() + path, headers=self._headers(), **kwargs)
        try:
            data = resp.json()
        except Exception:
            data = {"success": False, "errors": [{"message": resp.text[:200]}]}
        if resp.status_code >= 400 or not data.get("success", True):
            errs = data.get("errors") or [{"message": f"HTTP {resp.status_code}"}]
            raise CloudflareError(errs[0].get("message", "Cloudflare API error"))
        return data.get("result", {})

    async def create_hostname(self, hostname: str, origin_slug: str) -> HostnameStatus:
        if not self.is_connected:
            return self._not_connected()
        try:
            result = await self._request("POST", json={
                "hostname": hostname,
                "ssl": {"method": "http", "type": "dv", "settings": {"min_tls_version": "1.2"}},
                "custom_origin_server": self.origin,
            })
            ownership = result.get("ownership_verification") or {}
            return HostnameStatus(
                state="verifying",
                ssl_status=(result.get("ssl") or {}).get("status", "initializing"),
                ownership_record={
                    "type": ownership.get("type", "TXT"),
                    "name": ownership.get("name", ""),
                    "value": ownership.get("value", ""),
                } if ownership else None,
                dns_records=[
                    {"type": "CNAME", "name": hostname, "value": self.origin,
                     "note": "Routes traffic to your Zanelvo site."},
                ] + ([{"type": ownership.get("type", "TXT"), "name": ownership.get("name", ""),
                       "value": ownership.get("value", ""),
                       "note": "Proves you own the domain."}] if ownership else []),
                provider_ref=result.get("id"),
            )
        except CloudflareError as e:
            return HostnameStatus(state="error", error_detail=str(e),
                                  error_hint="Check the hostname isn't already claimed on Cloudflare.")

    async def check_status(self, hostname: str, provider_ref: Optional[str] = None) -> HostnameStatus:
        if not self.is_connected:
            return self._not_connected()
        if not provider_ref:
            return HostnameStatus(state="error", error_detail="Missing provider reference id.")
        try:
            result = await self._request("GET", f"/{provider_ref}")
            cf_state = result.get("status")
            ssl_state = (result.get("ssl") or {}).get("status", "unknown")
            state_map = {"active": "connected", "pending": "verifying",
                         "pending_validation": "verifying", "moved": "error",
                         "deleted": "removed", "blocked": "error"}
            return HostnameStatus(
                state=state_map.get(cf_state, "verifying"),
                ssl_status=ssl_state,
                provider_ref=provider_ref,
            )
        except CloudflareError as e:
            return HostnameStatus(state="error", error_detail=str(e))

    async def delete_hostname(self, hostname: str, provider_ref: Optional[str] = None) -> None:
        if not self.is_connected or not provider_ref:
            return
        try:
            await self._request("DELETE", f"/{provider_ref}")
        except CloudflareError:
            pass

    async def get_dns_instructions(self, hostname: str, origin_slug: str) -> List[Dict[str, str]]:
        if not self.is_connected:
            return [{"type": "CNAME", "name": hostname, "value": self.origin,
                     "note": "Cloudflare not connected — this is a preview of the record you'll need."}]
        return [{"type": "CNAME", "name": hostname, "value": self.origin,
                 "note": "Routes traffic to your Zanelvo site."}]

    async def verify_ownership(self, hostname: str, provider_ref: Optional[str] = None) -> HostnameStatus:
        # Cloudflare polls DNS itself; we just refresh status.
        return await self.check_status(hostname, provider_ref)


class CloudflareError(RuntimeError):
    pass


# --------------------------- Registry ---------------------------

_INSTANCES: Dict[str, CustomHostnameProvider] = {
    "simulated": SimulatedProvider(),
    "cloudflare": CloudflareProvider(),
}


def _is_production() -> bool:
    return (os.environ.get("APP_ENV") or "").strip().lower() in ("production", "prod")


def get_provider(key: str) -> CustomHostnameProvider:
    # PRODUCTION GUARD: the simulated provider must NEVER be used in production — it would
    # drive a domain to a fake "Connected" state without any real DNS/SSL verification.
    # Force the real provider (Cloudflare), which honestly reports "Not connected" until
    # credentials are configured, so a domain can only reach Connected via real verification.
    if _is_production():
        if key in (None, "", "simulated"):
            return _INSTANCES["cloudflare"]
        return _INSTANCES.get(key) or _INSTANCES["cloudflare"]
    return _INSTANCES.get(key) or _INSTANCES["simulated"]


def all_providers() -> List[CustomHostnameProvider]:
    return list(_INSTANCES.values())


async def refresh_credentials() -> None:
    """Load Cloudflare credentials from the Staff Setup Center (call before using a provider)."""
    await _INSTANCES["cloudflare"].refresh_from_setup_center()


async def probe_cloudflare() -> Dict[str, Any]:
    return await _INSTANCES["cloudflare"].probe()
