import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Pencil, Trash2 } from "lucide-react";

const DEFAULT_HOURS = [
    { day: 0, start: "09:00", end: "17:00" },
    { day: 1, start: "09:00", end: "17:00" },
    { day: 2, start: "09:00", end: "17:00" },
    { day: 3, start: "09:00", end: "17:00" },
    { day: 4, start: "09:00", end: "17:00" },
];

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const EMPTY = {
    display_name: "", email: "", phone: "", role: "technician",
    timezone: "America/Los_Angeles", working_hours: DEFAULT_HOURS,
    breaks: [], time_off: [], capacity: 1, color: "#D95A2B",
};

export default function Staff() {
    const [staff, setStaff] = useState([]);
    const [loading, setLoading] = useState(true);
    const [open, setOpen] = useState(false);
    const [editing, setEditing] = useState(null);
    const [form, setForm] = useState(EMPTY);
    const [busy, setBusy] = useState(false);

    async function load() {
        setLoading(true);
        try {
            const { data } = await api.get("/booking/staff");
            setStaff(data.staff || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    function openNew() { setEditing(null); setForm(EMPTY); setOpen(true); }
    function openEdit(s) {
        setEditing(s);
        setForm({
            display_name: s.display_name, email: s.email || "",
            phone: s.phone || "", role: s.role || "technician",
            timezone: s.timezone || "America/Los_Angeles",
            working_hours: s.working_hours?.length ? s.working_hours : DEFAULT_HOURS,
            breaks: s.breaks || [], time_off: s.time_off || [],
            capacity: s.capacity || 1, color: s.color || "#D95A2B",
        });
        setOpen(true);
    }
    async function save() {
        setBusy(true);
        try {
            const payload = { ...form };
            if (editing) await api.patch(`/booking/staff/${editing.id}`, payload);
            else await api.post("/booking/staff", payload);
            toast.success(editing ? "Staff updated" : "Staff added");
            setOpen(false); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Save failed"); }
        finally { setBusy(false); }
    }

    function toggleDay(day) {
        const has = form.working_hours.find((w) => w.day === day);
        if (has) setForm({ ...form, working_hours: form.working_hours.filter((w) => w.day !== day) });
        else setForm({ ...form, working_hours: [...form.working_hours, { day, start: "09:00", end: "17:00" }] });
    }
    function updateDayTime(day, key, value) {
        setForm({
            ...form,
            working_hours: form.working_hours.map((w) => w.day === day ? { ...w, [key]: value } : w),
        });
    }

    return (
        <div className="p-6" data-testid="staff-page">
            <div className="flex items-start justify-between mb-4 gap-3 flex-wrap">
                <div>
                    <h2 className="text-lg font-medium text-brand-ink">Staff & schedules</h2>
                    <p className="text-sm text-zinc-500">Working hours drive booking availability. Time off and breaks are respected automatically.</p>
                </div>
                <Button onClick={openNew} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="staff-new-btn">
                    <Plus className="w-4 h-4 mr-1" /> Add staff
                </Button>
            </div>

            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Timezone</TableHead>
                        <TableHead>Working days</TableHead>
                        <TableHead></TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {staff.map((s) => (
                            <TableRow key={s.id} data-testid={`staff-row-${s.id}`}>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <span className="w-2.5 h-2.5 rounded-full" style={{ background: s.color || "#C85A17" }} />
                                        <span className="font-medium">{s.display_name}</span>
                                    </div>
                                    <div className="text-xs text-zinc-500">{s.email || "—"}</div>
                                </TableCell>
                                <TableCell className="text-xs">{s.role}</TableCell>
                                <TableCell className="text-xs font-mono">{s.timezone}</TableCell>
                                <TableCell className="text-xs text-zinc-600">
                                    {(s.working_hours || []).map((w) => DAYS[w.day]).join(", ") || "—"}
                                </TableCell>
                                <TableCell><Button size="sm" variant="ghost" onClick={() => openEdit(s)} data-testid={`staff-edit-${s.id}`}><Pencil className="w-3.5 h-3.5" /></Button></TableCell>
                            </TableRow>
                        ))}
                        {!loading && !staff.length && (
                            <TableRow><TableCell colSpan={5} className="text-center text-zinc-500 py-10" data-testid="staff-empty">No staff yet.</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader><DialogTitle>{editing ? "Edit staff" : "Add staff"}</DialogTitle></DialogHeader>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="md:col-span-2">
                            <Label className="text-xs">Display name</Label>
                            <Input value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} data-testid="staff-form-name" />
                        </div>
                        <div>
                            <Label className="text-xs">Email</Label>
                            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Phone</Label>
                            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Role</Label>
                            <Input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Timezone</Label>
                            <Input value={form.timezone} onChange={(e) => setForm({ ...form, timezone: e.target.value })} placeholder="America/Los_Angeles" data-testid="staff-form-tz" />
                        </div>
                        <div>
                            <Label className="text-xs">Concurrent capacity</Label>
                            <Input type="number" min="1" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: +e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Color chip</Label>
                            <Input type="color" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className="h-10 p-1" />
                        </div>
                    </div>
                    <div className="mt-2">
                        <Label className="text-xs">Working hours</Label>
                        <div className="mt-2 space-y-1.5" data-testid="staff-form-hours">
                            {DAYS.map((label, day) => {
                                const w = form.working_hours.find((x) => x.day === day);
                                return (
                                    <div key={day} className="flex items-center gap-2 text-sm">
                                        <label className="w-16 flex items-center gap-1">
                                            <input type="checkbox" checked={!!w} onChange={() => toggleDay(day)} data-testid={`staff-form-day-${day}`} />
                                            <span className="text-xs">{label}</span>
                                        </label>
                                        {w ? (
                                            <>
                                                <Input type="time" value={w.start} onChange={(e) => updateDayTime(day, "start", e.target.value)} className="w-28 h-8 text-xs" />
                                                <span className="text-xs text-zinc-400">–</span>
                                                <Input type="time" value={w.end} onChange={(e) => updateDayTime(day, "end", e.target.value)} className="w-28 h-8 text-xs" />
                                            </>
                                        ) : <span className="text-xs text-zinc-400">Off</span>}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
                        <Button onClick={save} disabled={busy || !form.display_name} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="staff-form-save">
                            {editing ? "Save changes" : "Add staff"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
