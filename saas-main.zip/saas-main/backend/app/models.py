"""Domain models. Every tenant document carries org_id — enforced by shared deps."""
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, EmailStr, Field

from .db import BaseDocument

Role = Literal["platform_founder", "owner", "manager", "staff", "readonly"]


class Organization(BaseDocument):
    slug: str
    name: str
    industry: Optional[str] = None  # industry key


class User(BaseDocument):
    email: EmailStr
    password_hash: str
    full_name: Optional[str] = None
    org_id: Optional[str] = None  # None for platform_founder
    role: Role = "owner"
    email_verified: bool = False
    staff_role: Optional[str] = None   # set only for Zanelvo staff-panel sessions
    mfa_email_enabled: bool = True     # email one-time-code 2FA (default ON for everyone)


class PasswordResetToken(BaseDocument):
    user_id: str
    token: str  # opaque
    expires_at: str  # iso
    consumed: bool = False


class Plan(BaseDocument):
    code: str
    name: str
    price_usd: float
    tagline: str
    features: List[str]
    cta: str
    highlight: bool = False
    order: int = 0


class BrandConfigDoc(BaseDocument):
    """Single-row brand config; founder editable in later phase."""
    key: str = "primary"
    name: str
    status: str
    tagline: str
    promise: str
    cta_label: str
    colors: Dict[str, str]
    typography: Dict[str, str]
    logo_svg: str


# --- Onboarding & Generation ---

class InterviewAnswers(BaseModel):
    business_name: Optional[str] = None
    industry: Optional[str] = None  # key
    industry_freetext: Optional[str] = None
    services_text: Optional[str] = None  # free-form list from user
    service_area: Optional[str] = None
    hours_text: Optional[str] = None
    differentiators: Optional[str] = None
    tone: Optional[str] = None
    goals: List[str] = Field(default_factory=list)
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None
    color_pref: Optional[str] = None  # 'warm', 'cool', 'neutral', 'bold'


class InterviewSession(BaseDocument):
    org_id: str
    user_id: str
    status: Literal["in_progress", "generating", "ready", "failed"] = "in_progress"
    step_index: int = 0
    answers: InterviewAnswers = Field(default_factory=InterviewAnswers)
    business_profile_id: Optional[str] = None
    website_id: Optional[str] = None
    error: Optional[str] = None


class Service(BaseModel):
    id: str
    name: str
    description: str
    price: Optional[float] = None
    price_display: Optional[str] = None  # "$120" or "From $80/hr"
    unit: Optional[str] = None  # "per visit", "per hour"
    verified: bool = False


class HourRow(BaseModel):
    day: str  # Mon..Sun
    open: Optional[str] = None
    close: Optional[str] = None
    closed: bool = False
    verified: bool = False


class LocationRow(BaseModel):
    id: str
    name: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    region: Optional[str] = None
    phone: Optional[str] = None
    verified: bool = False


class KeyValue(BaseModel):
    id: str
    text: str
    verified: bool = False


class BusinessProfile(BaseDocument):
    org_id: str
    business_name: str
    industry: str  # key
    industry_label: str
    tagline: str
    about: str
    services: List[Service] = Field(default_factory=list)
    hours: List[HourRow] = Field(default_factory=list)
    locations: List[LocationRow] = Field(default_factory=list)
    differentiators: List[KeyValue] = Field(default_factory=list)
    policies: List[KeyValue] = Field(default_factory=list)
    tone: Optional[str] = None
    goals: List[str] = Field(default_factory=list)
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None


class Block(BaseModel):
    """Structured block. Renderer keys on `type` + `variant`. Future editor mutates `props`."""
    id: str
    type: Literal[
        "hero",
        "services_grid",
        "about_split",
        "testimonials",
        "cta_band",
        "contact_hours",
        "form",
        "booking",
        "chat_widget",
        "footer",
        "store",
        "faq",
        "gallery",
        "pricing_table",
        "video",
        "map",
        "stats",
        "team",
        "logo_cloud",
        "countdown",
        "social_links",
        "text",
        "blog_list",
    ]
    variant: str = "a"  # "a" | "b" | "c"
    props: Dict[str, Any] = Field(default_factory=dict)
    style: Dict[str, Any] = Field(default_factory=dict)
    hidden: bool = False  # Editor-controlled visibility flag; skipped on the live site.


class Page(BaseModel):
    id: str
    slug: str  # Phase 2: user-editable, kebab-case
    title: str
    seo: Dict[str, Any] = Field(default_factory=dict)  # {title, description, social_image, password}
    blocks: List[Block] = Field(default_factory=list)
    hidden: bool = False


class WebsiteTheme(BaseModel):
    primary: str
    secondary: str
    background: str
    surface: str
    foreground: str
    accent: str
    font_heading: str
    font_body: str
    radius: str = "0.75rem"
    industry: str = "professional_services"
    logo_svg: str = ""
    logo_image: str = ""
    logo_animation: str = "none"


class Website(BaseDocument):
    org_id: str
    business_profile_id: str
    # Draft state (Phase 2 editor edits these)
    theme: WebsiteTheme
    pages: List[Page] = Field(default_factory=list)
    nav_order: List[str] = Field(default_factory=list)  # ordered slugs for public nav
    # Publishing metadata
    slug: Optional[str] = None  # public path segment, unique across the platform
    slug_history: List[str] = Field(default_factory=list)  # for auto-redirects
    published_theme: Optional[WebsiteTheme] = None
    published_pages: Optional[List[Page]] = None
    published_nav_order: Optional[List[str]] = None
    published_at: Optional[str] = None
    published_revision_id: Optional[str] = None
    status: Literal["draft", "published"] = "draft"
    # Autosave heartbeat
    draft_updated_at: Optional[str] = None
    # Multi-site + private/maintenance mode
    name: Optional[str] = None
    maintenance: Dict[str, Any] = Field(default_factory=dict)  # {enabled,title,message,password_hash,eta,accent,show_logo}


# -------------------- Phase 2 collections --------------------


class Revision(BaseDocument):
    """Immutable snapshot of a website's pages + theme at a point in time."""
    org_id: str
    website_id: str
    kind: Literal["publish", "rollback", "manual_snapshot"] = "publish"
    theme: WebsiteTheme
    pages: List[Page]
    nav_order: List[str] = Field(default_factory=list)
    note: Optional[str] = None
    author_user_id: Optional[str] = None
    # For rollbacks, points at the revision that was restored
    rolled_back_from_id: Optional[str] = None


class Domain(BaseDocument):
    """Custom hostname bound to a tenant website."""
    org_id: str
    website_id: str
    hostname: str  # lowercased
    provider: Literal["cloudflare", "simulated"] = "simulated"
    provider_ref: Optional[str] = None  # provider-side id
    state: Literal[
        "pending", "verifying", "connected", "error", "removed"
    ] = "pending"
    dns_records: List[Dict[str, str]] = Field(default_factory=list)
    ownership: Dict[str, str] = Field(default_factory=dict)  # {type, name, value}
    ssl_status: Literal["initializing", "pending_validation", "active", "failed", "unknown"] = "unknown"
    error_detail: Optional[str] = None
    error_hint: Optional[str] = None
    primary: bool = False
    redirect_apex_to_www: bool = False
    redirect_www_to_apex: bool = False
    last_checked_at: Optional[str] = None
    connected_at: Optional[str] = None


class MediaAsset(BaseDocument):
    org_id: str
    filename: str
    mime: str
    size_bytes: int
    url: str
    alt_text: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    uploaded_by_user_id: Optional[str] = None


class FormSubmission(BaseDocument):
    org_id: str
    website_id: str
    page_slug: str
    block_id: Optional[str] = None
    fields: Dict[str, Any] = Field(default_factory=dict)
    visitor_ip: Optional[str] = None
    user_agent: Optional[str] = None
    read_at: Optional[str] = None


class AnalyticsEvent(BaseDocument):
    org_id: str
    website_id: str
    kind: Literal["pageview", "form_submit", "cta_click"] = "pageview"
    page_slug: Optional[str] = None
    referrer: Optional[str] = None
    user_agent: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


class ImportRun(BaseDocument):
    """A URL import attempt: fetched pages, extracted facts, planned redirects."""
    org_id: str
    user_id: Optional[str] = None
    source_url: str
    fetched_pages: List[Dict[str, Any]] = Field(default_factory=list)
    extracted_facts: Dict[str, Any] = Field(default_factory=dict)
    planned_redirects: List[Dict[str, str]] = Field(default_factory=list)
    generated_business_profile_id: Optional[str] = None
    generated_website_id: Optional[str] = None
    status: Literal["fetching", "extracting", "generating", "ready", "failed"] = "fetching"
    error: Optional[str] = None
