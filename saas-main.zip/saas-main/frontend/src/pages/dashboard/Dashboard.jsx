import { Outlet } from "react-router-dom";
import DashboardShell from "@/components/DashboardShell";

export default function Dashboard() {
    return (
        <DashboardShell>
            <Outlet />
        </DashboardShell>
    );
}
