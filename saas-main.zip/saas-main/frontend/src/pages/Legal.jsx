import PublicNav from "@/components/PublicNav";
import { Link } from "react-router-dom";
import { useBrand } from "@/context/BrandContext";

function Shell({ eyebrow, title, subtitle, children, testid }) {
    return (
        <div className="min-h-screen bg-brand-surface" data-testid={testid}>
            <PublicNav />
            <main className="mx-auto max-w-4xl px-6 py-16">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">{eyebrow}</div>
                <h1 className="mt-2 font-display text-4xl sm:text-5xl text-brand-ink">{title}</h1>
                {subtitle && <p className="mt-4 text-lg text-zinc-600 max-w-3xl">{subtitle}</p>}
                <div className="mt-10 prose prose-zinc max-w-none text-[15px] leading-relaxed">{children}</div>
                <div className="mt-16 pt-6 border-t border-brand-line text-sm text-zinc-500">
                    Questions? <Link to="/signup" className="underline hover:text-brand-copper">Start a trial</Link>{" "}
                    or read the <Link to="/pricing" className="underline hover:text-brand-copper">pricing</Link>.
                </div>
            </main>
        </div>
    );
}

export function Industries() {
    return (
        <Shell testid="page-industries" eyebrow="Industries"
                 title="Made for local service businesses."
                 subtitle="One AI-first workspace, tuned for the way your industry books, quotes, and follows up.">
            <div className="grid md:grid-cols-3 gap-6 not-prose mt-6">
                {[
                    { name: "Home services", body: "Plumbing, HVAC, cleaning, landscaping. Multi-service pricing, staff routing, deposit invoices, review requests when the job closes." },
                    { name: "Automotive", body: "Oil change to brake job. Time-boxed slots with buffers, vehicle notes on the contact, tokenized reschedule links." },
                    { name: "Beauty & wellness", body: "Cuts, color, treatments. Deposits, no-show protection, service history threading, one-tap rebook." },
                ].map((c) => (
                    <div key={c.name} className="rounded-xl border border-brand-line bg-white p-5" data-testid={`industry-${c.name.replace(/\W/g,'-').toLowerCase()}`}>
                        <div className="text-xs uppercase tracking-widest text-brand-copper">{c.name}</div>
                        <p className="mt-2 text-sm text-zinc-600">{c.body}</p>
                    </div>
                ))}
            </div>
            <p className="mt-8">
                The demo tenants seeded with the platform ("Demo Home Services", "Ridgeline Auto Service",
                "Mira & Co. Beauty") show each shape end-to-end — published site, services, staff, bookings,
                a quote and an invoice, and an AI receptionist tuned to the vertical.
            </p>
        </Shell>
    );
}

export function Security() {
    return (
        <Shell testid="page-security" eyebrow="Security"
                 title="What we do — and what we don't."
                 subtitle="Honest overview. No 'bank-grade' theatre.">
            <h2>Tenant isolation</h2>
            <p>Every domain document carries <code>org_id</code>. All read/write paths go through a shared FastAPI dependency (<code>require_org</code>) that resolves the caller's org from the JWT — the client never supplies its own. We include cross-tenant tests in the backend suite.</p>
            <h2>Authentication</h2>
            <p>Bcrypt password hashing (12 rounds). Sessions use a short-lived access token delivered as a <strong>Secure, HttpOnly cookie</strong> (not readable by JavaScript) plus a readable CSRF token for double-submit protection on state-changing requests. Rate limits on <code>/api/auth/login</code> (10 attempts / 5 min per IP) and <code>/api/auth/signup</code>. Optional TOTP-based MFA with 8 one-time backup codes (sha256-hashed); MFA fails closed in production.</p>
            <h2>Impersonation</h2>
            <p>Founder support access requires a written reason (min 6 chars), returns a short-lived 30-min JWT scoped to the target org, is audited on start / end / every mutating action, and shows a persistent banner in the tenant UI.</p>
            <h2>Portal tokens & webhooks</h2>
            <p>Booking / quote / invoice portal tokens are 24-byte URL-safe secrets, compared in constant time. Outbound webhooks are HMAC-SHA256 signed with a 5-minute replay window.</p>
            <h2>Data export & deletion</h2>
            <p>Owners can download a full org-scoped JSON ZIP export any time, or schedule a soft-delete with a 30-day grace window.</p>
        </Shell>
    );
}

function ReviewNotice({ brand }) {
    if (brand?.legal_reviewed) return null;
    return (
        <div className="mb-6 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900" data-testid="legal-review-notice">
            This document has not yet been confirmed by legal review. Until it is, it describes how the service
            operates but should not be relied on as a legally approved agreement.
        </div>
    );
}

export function Terms() {
    const brand = useBrand();
    const name = brand?.name || "Our platform";
    const custom = (brand?.legal?.tos_html || "").trim();
    if (custom) {
        return (
            <Shell testid="page-terms" eyebrow="Terms of Service" title="Terms of service" subtitle="">
                <ReviewNotice brand={brand} />
                <div dangerouslySetInnerHTML={{ __html: custom }} />
            </Shell>
        );
    }
    return (
        <Shell testid="page-terms" eyebrow="Terms of Service" title="Terms of service" subtitle="">
            <ReviewNotice brand={brand} />
            <p><strong>1. Service.</strong> {name} provides multi-tenant SaaS for service &amp; online businesses: AI website builder + hosting, CRM, email workspace, booking, quotes/invoices/payments, AI employees, marketing, and an owner-only control panel.</p>
            <p><strong>2. Accounts.</strong> You are responsible for the accuracy of your business facts, for keeping your credentials safe, and for the actions of every teammate on your workspace.</p>
            <p><strong>3. Plans and billing.</strong> Plans are billed monthly at the price shown on the Pricing page at the time you subscribe; your subscription keeps that price until you change plan. Plan limits and AI/provider spending caps are enforced server-side — a capped feature stops with a clear upgrade/top-up message rather than billing you extra. Upgrades take effect immediately; downgrades apply at the end of the period.</p>
            <p><strong>4. AI content.</strong> AI-generated text and images are drafts. You are responsible for reviewing generated ad copy, customer-facing emails, and site content before publishing. We don't guarantee accuracy of LLM output.</p>
            <p><strong>5. Acceptable use.</strong> No spam, no fraud, no impersonation of businesses you don't own. We may pause outbound email at any time via the global email kill switch to protect deliverability across the platform.</p>
            <p><strong>6. Data.</strong> Your workspace data belongs to you. Export any time; soft-delete with a 30-day grace.</p>
            <p><strong>7. Warranty.</strong> Service is provided "as is". We work in good faith; we won't invent uptime numbers we can't verify.</p>
        </Shell>
    );
}

export function Privacy() {
    const brand = useBrand();
    const name = brand?.name || "Our platform";
    const custom = (brand?.legal?.privacy_html || "").trim();
    if (custom) {
        return (
            <Shell testid="page-privacy" eyebrow="Privacy" title="Privacy policy" subtitle="">
                <div dangerouslySetInnerHTML={{ __html: custom }} />
            </Shell>
        );
    }
    return (
        <Shell testid="page-privacy" eyebrow="Privacy" title="Privacy policy" subtitle="">
            <ReviewNotice brand={brand} />
            <p><strong>What we store.</strong> Account records (email, hashed password, role), business profile, published websites, contacts, conversations, bookings, quotes, invoices, AI interaction logs, audit events, subscription and billing metadata.</p>
            <p><strong>Payments.</strong> Card payments on your storefront are processed by Stripe through a connected account you authorize with Stripe (Stripe Connect). {name} never stores your Stripe secret key; we store only your connected-account identifier and the capability flags Stripe reports. Until your Stripe account is connected and enabled, checkout runs in a clearly labelled test mode and no card data is collected.</p>
            <p><strong>Other providers.</strong> Email delivery, voice/SMS and advertising run only through accounts you connect under <em>Integrations</em>. Until you connect one, the feature is shown as "Not connected" and no data is sent to that provider.</p>
            <p><strong>AI subprocessors.</strong> When you use AI features, the request content (visitor questions, generation prompts, page text) is sent to our LLM provider (Anthropic Claude models via our AI gateway). Prompts are used only to produce your output; we do not sell your data or use it to train models.</p>
            <p><strong>Retention.</strong> Data stays for the life of your subscription; a soft-delete workflow gives you a 30-day grace window to recover, then the record is purged.</p>
            <p><strong>Access & export.</strong> Owners can export the full org's data as a JSON ZIP any time from Setup → Data.</p>
            <p><strong>Authentication & cookies.</strong> Signing in sets a short-lived, Secure, HttpOnly session cookie plus a readable CSRF token. No password or session token is stored in browser storage. Published sites record first-party analytics events (page views, CTA clicks, form submissions, attribution source) to power your dashboard; we do not run third-party ad trackers unless you add your own analytics IDs.</p>
            <p><strong>Security logging.</strong> Sign-in attempts, staff actions and impersonation sessions are recorded in an audit log with IP address and timestamp for abuse prevention.</p>
        </Shell>
    );
}


export function About() {
    const brand = useBrand();
    const name = brand?.name || "Our platform";
    const custom = (brand?.legal?.about_html || "").trim();
    return (
        <Shell testid="page-about" eyebrow="About" title={`About ${name}`} subtitle="">
            {custom
                ? <div dangerouslySetInnerHTML={{ __html: custom }} />
                : <p>{name} is an all-in-one platform for service and online businesses: an AI website builder with hosting, CRM and inbox, bookings, quotes and invoices, online store, marketing and automation — run from one owner dashboard.</p>}
        </Shell>
    );
}
