"""Platform-level system mail (2FA codes, staff invites, billing notices).

Uses the `email` section of the platform integrations doc (set from the Staff panel).
When no provider is configured, `is_configured()` is False and callers decide what to do
(2FA is skipped by product rule). Every attempt is logged to `db.system_mail_log`.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

from ..db import get_db, utc_now_iso
from . import integrations as integ
from . import platform_settings as ps
from .email_providers import SendPayload, build_provider_from_config

logger = logging.getLogger(__name__)


class _Cfg:
    def __init__(self, d: Dict[str, Any]):
        self.__dict__.update(d)

    def __getattr__(self, item):  # missing → None
        return None


async def is_configured() -> bool:
    return await integ.is_configured("email")


async def send(role: str, to: str, subject: str, text: str, html: str = "") -> Dict[str, Any]:
    """Send a system email from the platform address for `role` (twofa/support/billing…).
    Returns {ok, simulated, error}. Never raises."""
    db = get_db()
    sender = await ps.email_for(role)
    raw_cfg = (await integ._raw()).get("email") or {}
    configured = await is_configured()
    result: Dict[str, Any] = {"ok": False, "simulated": not configured, "error": None}
    try:
        if configured:
            provider = build_provider_from_config(_Cfg(raw_cfg))
            r = await provider.send(SendPayload(from_email=sender["address"], from_name=sender["display_name"],
                                                to=[to], subject=subject, text=text, html=html or ""))
            result.update(ok=bool(r.ok), error=r.error, simulated=bool(getattr(r, "simulated", False)))
        else:
            result.update(ok=True, simulated=True)
    except Exception as e:  # noqa: BLE001
        result.update(ok=False, error=str(e))
    try:
        await db.system_mail_log.insert_one({"role": role, "to": to, "subject": subject,
                                             "ok": result["ok"], "simulated": result["simulated"],
                                             "error": result["error"], "created_at": utc_now_iso()})
    except Exception:  # noqa: BLE001
        pass
    return result
