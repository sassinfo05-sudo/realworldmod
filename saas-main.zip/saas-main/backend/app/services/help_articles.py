"""Seeded help articles for the in-app help center + AI support assistant grounding."""
from __future__ import annotations

from typing import Any, Dict, List


# Article body is Markdown. Kept concise, honest, and mapped to real product routes.
HELP_ARTICLES: List[Dict[str, Any]] = [
    {
        "slug": "getting-started",
        "title": "Getting started with Zanelvo",
        "category": "Basics",
        "body_markdown": """
# Getting started

1. **Sign up** at `/signup` — a workspace (org) is created for you automatically.
2. **Answer the interview** — 8-10 short questions about your business.
3. **Watch your site generate** — usually under a minute.
4. **Review the facts** — every generated fact is editable in the Review step.
5. **Publish** from the Editor (`/app/editor`) → your site is live at
   `/site/<your-slug>`.
6. Optional: connect a **custom domain** in `Domains`, or invite teammates in
   **Settings → Team**.

Every action in Zanelvo is scoped to your organization. Nothing you enter is shared
with other tenants.
""".strip(),
        "keywords": ["signup", "onboarding", "getting started", "first site", "generate"],
        "related_routes": ["/api/auth/signup", "/api/onboarding", "/api/website"],
        "order": 1,
    },
    {
        "slug": "plans-and-limits",
        "title": "Plans, limits, and upgrades",
        "category": "Billing",
        "body_markdown": """
# Plans and what's included

Zanelvo has 5 plans: **Free**, **Starter**, **Business**, **Commerce + AI** and **Scale**.
Current prices are always shown on the Pricing page (they are read live from the plan
database, so this article never lists a number). Every plan carries hard limits — when you
cross one, the app returns a clear "plan limit reached" message with a one-click upgrade CTA.
AI usage and other variable provider costs also have a monthly hard cap per plan; you are
warned at 60%, 80% and 95% and chargeable AI operations stop at 100% until the next period
or an upgrade — ordinary sign-in and editing keep working.

Meters we enforce monthly per org:

- **AI conversations** (from the chat widget + call simulator)
- **Email sends** (outbound from the Inbox)
- **Voice minutes** (pass-through add-on; only available once a voice provider is connected)
- **Contacts** (total in CRM)
- **Users** (seats)
- **Websites** and **custom domain**

Usage resets on the first of each month (UTC). Upgrade takes effect immediately —
new caps apply to the current period. Downgrades run at the end of the period,
and we validate that your current usage fits the smaller plan.
""".strip(),
        "keywords": ["pricing", "plan", "billing", "usage", "upgrade", "downgrade",
                     "limit", "quota"],
        "related_routes": ["/api/billing/plans", "/api/billing/usage", "/api/billing/checkout"],
        "order": 2,
    },
    {
        "slug": "booking-and-availability",
        "title": "Booking rules and availability",
        "category": "Booking",
        "body_markdown": """
# How availability is computed

Availability comes from three inputs: **service duration + buffers** (in Settings →
Services), your **staff working hours** (Settings → Staff), and any **existing bookings**.
We never surface slots in the past.

- Public visitors can book from your live site's booking block or via the AI chat
  widget. The AI never invents slots — it must call the `get_availability` tool.
- Rescheduling is done from a tokenized customer portal link included in the
  confirmation email. Min-notice defaults to 4 hours; adjust in Settings.
- Owners can create bookings directly from the Calendar; a conflict check runs
  as a last-line defence.
""".strip(),
        "keywords": ["booking", "availability", "reschedule", "cancel", "calendar",
                     "buffer", "staff hours"],
        "related_routes": ["/api/booking/services", "/api/booking/availability",
                            "/api/public/booking/book"],
        "order": 3,
    },
    {
        "slug": "quotes-invoices-payments",
        "title": "Quotes, invoices, and payments",
        "category": "Revenue",
        "body_markdown": """
# Quote-to-cash

Build a quote (Quotes → New): add line items, an optional global discount, a tax
rate, and terms. Send it — the customer gets a tokenized portal link to accept or
decline. On accept, one click converts the quote into an invoice and (optionally)
a job.

Invoices support partial payments. The simulated payment provider is live by
default so you can practice; Stripe is available as an adapter — add your keys in
Setup → Payments to switch over.

**Money math**: `global_discount_percent` and `tax_rate` are 0-100 integers
(e.g., 25 = 25%). We validated this contract in Phase 4.
""".strip(),
        "keywords": ["quote", "invoice", "payment", "stripe", "checkout", "line item",
                     "tax", "discount", "portal"],
        "related_routes": ["/api/quotes", "/api/invoices", "/api/payments/checkout"],
        "order": 4,
    },
    {
        "slug": "ai-employees",
        "title": "AI employees and the Agent Studio",
        "category": "AI",
        "body_markdown": """
# AI employees

Zanelvo ships with a **Receptionist** (chat + call), a **Sales Assistant**, and a
**Reactivation** helper. Every agent is grounded — it can only quote prices,
hours, availability, and bookings that come from a tool. If it doesn't know, it
says so and offers to take a message.

- **Agent Studio** (`/app/ai/:agentId`): edit purpose, tone, allowed tools,
  escalation rules; each save is a new version. Promote to live, roll back a
  previous version, or test any version in the sandbox (no real CRM writes).
- **Kill switch** (`/app/ai`): flip the org-wide AI off; the chat widget shows a
  polite "please use the contact form" fallback.
- **Takeover** (in a conversation): the visitor keeps talking to a human; AI is
  paused server-side.

Approval-required agents let managers/owners review every AI-generated draft
before it hits the customer.
""".strip(),
        "keywords": ["ai", "receptionist", "sandbox", "agent", "prompt",
                     "escalation", "takeover", "kill switch", "grounded"],
        "related_routes": ["/api/ai/agents", "/api/ai/kill-switch", "/api/ai/conversations"],
        "order": 5,
    },
    {
        "slug": "api-keys-and-webhooks",
        "title": "Public API keys and webhooks",
        "category": "Integrations",
        "body_markdown": """
# API keys

Create scoped API keys in **Setup → API keys**. Keys look like
`yv_live_xxxx` (production) or `yv_test_xxxx` (sandbox). The full key is shown
once at creation — we only store its SHA-256 hash. Include it as
`Authorization: Bearer yv_live_...` on public API routes.

**Scopes** (least-privilege): `contacts:read`, `contacts:write`, `bookings:read`,
`bookings:write`, `invoices:read`, `invoices:write`.

# Webhooks

Register an endpoint URL in **Setup → Webhooks** and pick the events you care
about (e.g., `contact.created`, `booking.created`). Every request is signed as
`X-Zanelvo-Signature: t=<unix>,v1=<hmac_sha256(t + '.' + body)>`. Reject any
request whose timestamp is more than 5 minutes old — that's the replay window.
""".strip(),
        "keywords": ["api key", "webhook", "hmac", "integration", "zapier", "make",
                     "signature", "public api"],
        "related_routes": ["/api/setup/api-keys", "/api/setup/webhooks"],
        "order": 6,
    },
    {
        "slug": "security-mfa-and-export",
        "title": "Security: MFA, exports, deletion",
        "category": "Security",
        "body_markdown": """
# Multi-factor auth (TOTP)

MFA is required-by-default for the platform founder role and enrollable for
owners. Enroll in **Settings → Security**: scan the QR into any TOTP app (1Password,
Authy, Google Authenticator), enter the 6-digit code, and save the 8 one-time
backup codes shown after enrollment. Losing your backup codes has a documented
recovery procedure in `SECURITY.md`.

# Data export & deletion

**Export** downloads a ZIP of every org-owned collection as JSON. **Deletion** is
a soft-delete with a 30-day grace period — the org is suspended immediately and
purged after the window unless canceled.
""".strip(),
        "keywords": ["mfa", "totp", "2fa", "security", "export", "delete", "gdpr",
                     "backup codes"],
        "related_routes": ["/api/auth/mfa/enroll", "/api/auth/mfa/verify",
                            "/api/setup/data-export", "/api/setup/delete-org"],
        "order": 7,
    },
    {
        "slug": "founder-panel",
        "title": "Founder Control Center",
        "category": "Platform",
        "body_markdown": """
# For the platform founder

The founder panel lives at `/app/founder` and is exception-first: the Cockpit
surfaces what needs attention now — orgs over limits, dead-lettered webhooks,
pending approvals, error spikes — each with a direct action.

- **Tenants**: search + filter, plan, activation state, MRR contribution, usage
  and cost, health score with explainable factors, suspend/unsuspend.
- **Metrics**: MRR/ARR, activation funnel, per-org gross margin.
- **Impersonation**: open any tenant with a mandatory reason — a banner shows
  "Support session — acting as X". Session auto-exits after 30 min; every action
  is logged to an immutable audit collection.
- **Global controls**: feature flags (per-plan/per-org overrides), all-AI kill
  switch, all-outbound-email kill switch, all-public-chat kill switch, an
  announcement banner, maintenance mode.
- **Provider health**: LLM, email, payments status + queue health.
- **Approval queue**: refunds and any future high-risk actions land here.
""".strip(),
        "keywords": ["founder", "admin", "tenant", "impersonation", "kill switch",
                     "audit log", "feature flag", "announcement", "maintenance"],
        "related_routes": ["/api/founder/cockpit", "/api/founder/tenants",
                            "/api/founder/impersonate"],
        "order": 8,
    },
    {
        "slug": "connecting-your-domain",
        "title": "Connecting a custom domain",
        "category": "Setup",
        "body_markdown": """
# Custom domains

Add your hostname in `Domains` (`/app/domains`). We create a CNAME and a TXT
ownership record for you — paste both into your DNS provider. State advances
Pending → Verifying → Connected once DNS + SSL check out.

Cloudflare-for-SaaS is a real adapter but requires platform credentials — until
we activate that, the wizard uses the simulated provider (state machine advances
after three polls, useful for testing). Once connected, the site is served both
on `<slug>.zanelvo-hosted` and on your custom hostname.
""".strip(),
        "keywords": ["domain", "custom domain", "dns", "cname", "txt", "ssl", "cloudflare"],
        "related_routes": ["/api/domains"],
        "order": 9,
    },
    {
        "slug": "troubleshooting",
        "title": "Troubleshooting",
        "category": "Troubleshooting",
        "body_markdown": """
# Common issues

- **"Plan limit reached"** — you've hit a cap. Look at Setup → Billing → Usage
  meters or upgrade one tier.
- **AI reply feels off** — check the agent's live version in Agent Studio. Try
  a sandbox conversation. If the tool list is wrong, edit and promote a new
  version.
- **Booking widget shows no slots** — check that at least one Staff member has
  working hours matching the service. Availability never returns past slots.
- **Email not sending** — Setup → Email provider. Free/Launch plans have a
  monthly cap; Autopilot+ raises it.
- **Webhook keeps failing** — Setup → Webhooks → dead-letter list. Verify your
  endpoint returns 2xx and validates the `X-Zanelvo-Signature` header.
""".strip(),
        "keywords": ["error", "help", "fix", "not working", "500", "402", "429"],
        "related_routes": [],
        "order": 10,
    },
]


async def seed_help_articles() -> None:
    """Idempotent — upsert by slug."""
    from ..db import get_db, utc_now_iso
    db = get_db()
    for a in HELP_ARTICLES:
        await db.help_articles.update_one(
            {"slug": a["slug"]},
            {"$set": {**a, "updated_at": utc_now_iso()},
             "$setOnInsert": {"created_at": utc_now_iso()}},
            upsert=True,
        )
    await db.help_articles.create_index("slug", unique=True)
    await db.help_articles.create_index([("category", 1), ("order", 1)])
