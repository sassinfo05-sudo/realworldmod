import "@/App.css";
import { BrowserRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { BrandProvider } from "@/context/BrandContext";
import { ThemeProvider } from "@/context/ThemeContext";
import { Toaster } from "@/components/ui/sonner";

import Home from "@/pages/Home";
import Product from "@/pages/Product";
import Developers from "@/pages/Developers";
import Pricing from "@/pages/Pricing";
import Upgrade from "@/pages/Upgrade";
import Research from "@/pages/Research";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import PasswordReset from "@/pages/PasswordReset";
import AuthCallback from "@/pages/AuthCallback";
import Onboarding from "@/pages/Onboarding";
import Generating from "@/pages/Generating";
import FactReview from "@/pages/FactReview";
import Dashboard from "@/pages/dashboard/Dashboard";
import Website from "@/pages/dashboard/Website";
import WebsiteNew from "@/pages/dashboard/WebsiteNew";
import Blog from "@/pages/dashboard/Blog";
import PublicBlog from "@/pages/public/PublicBlog";
import Domains from "@/pages/dashboard/Domains";
import Analytics from "@/pages/dashboard/Analytics";
import Forms from "@/pages/dashboard/Forms";
import Editor from "@/pages/editor/Editor";
import PublicSite from "@/pages/public/PublicSite";
import PublicStatusPage from "@/pages/public/StatusPage";
import ComingSoon from "@/pages/dashboard/ComingSoon";
import CrmContacts from "@/pages/dashboard/CrmContacts";
import CrmContactDetail from "@/pages/dashboard/CrmContactDetail";
import CrmDeals from "@/pages/dashboard/CrmDeals";
import CrmImport from "@/pages/dashboard/CrmImport";
import Inbox from "@/pages/dashboard/Inbox";
import EmailSettings from "@/pages/dashboard/EmailSettings";
import SettingsShell from "@/pages/dashboard/SettingsShell";
import Account from "@/pages/dashboard/Account";
import Services from "@/pages/dashboard/Services";
import Staff from "@/pages/dashboard/Staff";
import PaymentSettings from "@/pages/dashboard/PaymentSettings";
import Calendar from "@/pages/dashboard/Calendar";
import Quotes from "@/pages/dashboard/Quotes";
import QuoteEditor from "@/pages/dashboard/QuoteEditor";
import Jobs from "@/pages/dashboard/Jobs";
import Invoices from "@/pages/dashboard/Invoices";
import InvoiceDetail from "@/pages/dashboard/InvoiceDetail";
import Products from "@/pages/dashboard/Products";
import Discounts from "@/pages/dashboard/Discounts";
import Shipping from "@/pages/dashboard/Shipping";
import TaxSettings from "@/pages/dashboard/TaxSettings";
import LogoStudio from "@/pages/dashboard/LogoStudio";
import Localization from "@/pages/dashboard/Localization";
import Numbers from "@/pages/dashboard/Numbers";
import Orders from "@/pages/dashboard/Orders";
import Subscriptions from "@/pages/dashboard/Subscriptions";
import Storefront from "@/pages/public/Storefront";
import QuotePortal from "@/pages/public/QuotePortal";
import InvoicePortal from "@/pages/public/InvoicePortal";
import BookingPortal from "@/pages/public/BookingPortal";
import SimulatedCheckout from "@/pages/public/SimulatedCheckout";
import { PaySuccess, PayCancel } from "@/pages/public/PayReturn";
import AiEmployees from "@/pages/dashboard/AiEmployees";
import AgentStudio from "@/pages/dashboard/AgentStudio";
import KnowledgeBase from "@/pages/dashboard/KnowledgeBase";
import CallSimulator from "@/pages/dashboard/CallSimulator";
import AiConversations from "@/pages/dashboard/AiConversations";
import Billing from "@/pages/dashboard/Billing";
import SetupShell from "@/pages/dashboard/SetupShell";
import Setup from "@/pages/dashboard/Setup";
import ApiKeys from "@/pages/dashboard/ApiKeys";
import Webhooks from "@/pages/dashboard/Webhooks";
import Security from "@/pages/dashboard/Security";
import DataTools from "@/pages/dashboard/DataTools";
import { SupportShell, ArticlesList, ArticleView, TicketsList, AiAssistant, StatusPage } from "@/pages/dashboard/Support";
import StaffShell from "@/pages/staff/StaffShell";
import StaffLogin from "@/pages/staff/StaffLogin";
import StaffSetPassword from "@/pages/staff/StaffSetPassword";
import StaffTeam from "@/pages/staff/StaffTeam";
import StaffPayments from "@/pages/staff/StaffPayments";
import StaffPlans from "@/pages/staff/StaffPlans";
import StaffFraud from "@/pages/staff/StaffFraud";
import StaffSupport from "@/pages/staff/StaffSupport";
import StaffAiUsage from "@/pages/staff/StaffAiUsage";
import StaffCompetitive from "@/pages/staff/StaffCompetitive";
import GoLive from "@/pages/staff/GoLive";
import Overview from "@/pages/dashboard/Overview";
import Sites from "@/pages/dashboard/Sites";
import { installToastRecorder } from "@/lib/notifications";
installToastRecorder();
import Cockpit from "@/pages/founder/Cockpit";
import { TenantList, TenantDetail } from "@/pages/founder/Tenants";
import Metrics from "@/pages/founder/Metrics";
import GlobalControls from "@/pages/founder/GlobalControls";
import Branding from "@/pages/founder/Branding";
import Integrations from "@/pages/founder/Integrations";
import EmailCenter from "@/pages/founder/EmailCenter";
import LegalEditor from "@/pages/founder/LegalEditor";
import SeoAnalytics from "@/pages/dashboard/SeoAnalytics";
import TenantIntegrations from "@/pages/dashboard/TenantIntegrations";
import { AuditLog, ProviderHealth, Approvals } from "@/pages/founder/Other";
import Marketing from "@/pages/dashboard/Marketing";
import Workflows from "@/pages/dashboard/Workflows";
import ContentManager from "@/pages/dashboard/ContentManager";
import ContentCollection from "@/pages/dashboard/ContentCollection";
import AssetLibrary from "@/pages/dashboard/AssetLibrary";
import DynamicCollectionPage from "@/pages/public/DynamicCollectionPage";
import { Industries, Security as LegalSecurity, Terms, Privacy, About } from "@/pages/Legal";
import SimulatedSubscriptionCheckout from "@/pages/public/SimulatedSubscriptionCheckout";
import NotFound from "@/pages/NotFound";

function StaffGate({ children }) {
    const { user, token } = useAuth();
    if (!token || !user) return <Navigate to="/staff/login" replace />;
    return children;
}

function Private({ children }) {
    const { user, token } = useAuth();
    if (!token || !user) return <Navigate to="/login" replace />;
    return children;
}

/** Soft fade+lift on every route change, keyed by pathname. */
function PageTransition({ children }) {
    const location = useLocation();
    return (
        <div key={location.pathname} className="page-transition">
            {children}
        </div>
    );
}

function App() {
    return (
        <div className="App">
            <ThemeProvider>
                <BrandProvider>
                    <AuthProvider>
                        <BrowserRouter>
                        <PageTransition>
                        <Routes>
                            {/* Public marketing */}
                            <Route path="/" element={<Home />} />
                            <Route path="/product" element={<Product />} />
                            <Route path="/developers" element={<Developers />} />
                            <Route path="/pricing" element={<Pricing />} />
                            <Route path="/upgrade" element={<Private><Upgrade /></Private>} />
                            <Route path="/research" element={<Private><Research /></Private>} />
                            <Route path="/industries" element={<Industries />} />
                            <Route path="/security" element={<LegalSecurity />} />
                            <Route path="/terms" element={<Terms />} />
                            <Route path="/privacy" element={<Privacy />} />
                            <Route path="/about" element={<About />} />
                            <Route path="/login" element={<Login />} />
                            <Route path="/signup" element={<Signup />} />
                            <Route path="/reset" element={<PasswordReset />} />
                            <Route path="/reset-password" element={<PasswordReset />} />
                            <Route path="/auth/callback" element={<AuthCallback />} />

                            {/* Public tenant sites */}
                            <Route path="/status" element={<PublicStatusPage />} />
                            <Route path="/site/:slug" element={<PublicSite />} />
                            <Route path="/site/:slug/blog" element={<PublicBlog />} />
                            <Route path="/site/:slug/blog/:postSlug" element={<PublicBlog />} />
                            <Route path="/site/:slug/:routeBase/:itemSlug" element={<DynamicCollectionPage mode="detail" />} />
                            <Route path="/site/:slug/:pageSlug" element={<PublicSite />} />
                            <Route path="/store/:orgId" element={<Storefront />} />

                            {/* Customer portals (tokenized) */}
                            <Route path="/portal/quote/:qid" element={<QuotePortal />} />
                            <Route path="/portal/invoice/:iid" element={<InvoicePortal />} />
                            <Route path="/portal/booking/:bid" element={<BookingPortal />} />

                            {/* Simulated payment flow (customer-facing) */}
                            <Route path="/pay/simulated/:sessionId" element={<SimulatedCheckout />} />
                            <Route path="/pay/simulated/subscription/:sid" element={<SimulatedSubscriptionCheckout />} />
                            <Route path="/pay/success" element={<PaySuccess />} />
                            <Route path="/pay/cancel" element={<PayCancel />} />

                            {/* Onboarding */}
                            <Route path="/onboarding" element={<Private><Onboarding /></Private>} />
                            <Route path="/generating" element={<Private><Generating /></Private>} />
                            <Route path="/review" element={<Private><FactReview /></Private>} />

                            {/* Editor (full-screen, outside dashboard shell) */}
                            <Route path="/app/editor" element={<Private><Editor /></Private>} />

                            {/* App dashboard */}
                            <Route path="/app" element={<Private><Dashboard /></Private>}>
                                <Route index element={<Overview />} />
                                <Route path="website" element={<Website />} />
                                <Route path="website/new" element={<WebsiteNew />} />
                                <Route path="blog" element={<Blog />} />
                                <Route path="sites" element={<Sites />} />
                                <Route path="domains" element={<Domains />} />
                                <Route path="analytics" element={<Analytics />} />
                                <Route path="forms" element={<Forms />} />
                                <Route path="content" element={<ContentManager />} />
                                <Route path="content/:cid" element={<ContentCollection />} />
                                <Route path="assets" element={<AssetLibrary />} />
                                <Route path="crm" element={<CrmContacts />} />
                                <Route path="crm/contacts/:id" element={<CrmContactDetail />} />
                                <Route path="crm/deals" element={<CrmDeals />} />
                                <Route path="crm/import" element={<CrmImport />} />
                                <Route path="inbox" element={<Inbox />} />
                                <Route path="inbox/:convId" element={<Inbox />} />

                                {/* Phase 4 */}
                                <Route path="calendar" element={<Calendar />} />
                                <Route path="quotes" element={<Quotes />} />
                                <Route path="quotes/:qid" element={<QuoteEditor />} />
                                <Route path="jobs" element={<Jobs />} />
                                <Route path="payments" element={<Invoices />} />
                                <Route path="payments/:iid" element={<InvoiceDetail />} />
                                <Route path="store/products" element={<Products />} />
                                <Route path="store/discounts" element={<Discounts />} />
                                <Route path="store/shipping" element={<Shipping />} />
                                <Route path="store/tax" element={<TaxSettings />} />
                                <Route path="logo-studio" element={<LogoStudio />} />
                                <Route path="languages" element={<Localization />} />
                                <Route path="store/orders" element={<Orders />} />
                                <Route path="store/subscriptions" element={<Subscriptions />} />

                                <Route path="ai" element={<AiEmployees />} />
                                <Route path="ai/:agentId" element={<AgentStudio />} />
                                <Route path="ai/conversations" element={<AiConversations />} />
                                <Route path="ai/conversations/:convId" element={<AiConversations />} />
                                <Route path="ai/calls" element={<CallSimulator />} />
                                <Route path="numbers" element={<Numbers />} />
                                <Route path="knowledge" element={<KnowledgeBase />} />
                                <Route path="marketing" element={<Marketing />} />
                                <Route path="workflows" element={<Workflows />} />

                                {/* Phase 6: Billing */}
                                <Route path="billing" element={<Billing />} />
                                <Route path="account" element={<Account />} />
                                <Route path="seo" element={<SeoAnalytics />} />
                                <Route path="integrations" element={<TenantIntegrations />} />

                                {/* Phase 6: Setup Center */}
                                <Route path="setup" element={<SetupShell />}>
                                    <Route index element={<Setup />} />
                                    <Route path="api-keys" element={<ApiKeys />} />
                                    <Route path="webhooks" element={<Webhooks />} />
                                    <Route path="security" element={<Security />} />
                                    <Route path="data" element={<DataTools />} />
                                </Route>

                                {/* Phase 6: Support */}
                                <Route path="support" element={<SupportShell />}>
                                    <Route index element={<ArticlesList />} />
                                    <Route path="article/:slug" element={<ArticleView />} />
                                    <Route path="tickets" element={<TicketsList />} />
                                    <Route path="ai" element={<AiAssistant />} />
                                    <Route path="status" element={<StatusPage />} />
                                </Route>

                                {/* Legacy founder URL → staff panel */}
                                <Route path="founder/*" element={<Navigate to="/staff" replace />} />

                                {/* Settings hub */}
                                <Route path="settings" element={<SettingsShell />}>
                                    <Route index element={<EmailSettings />} />
                                    <Route path="services" element={<Services />} />
                                    <Route path="staff" element={<Staff />} />
                                    <Route path="payments" element={<PaymentSettings />} />
                                </Route>
                            </Route>

                            {/* Zanelvo Staff panel — zanelvo.com/staff */}
                            <Route path="/staff/login" element={<StaffLogin />} />
                            <Route path="/staff/set-password" element={<StaffSetPassword />} />
                            <Route path="/staff" element={<StaffGate><StaffShell /></StaffGate>}>
                                <Route index element={<Cockpit />} />
                                <Route path="go-live" element={<GoLive />} />
                                <Route path="team" element={<StaffTeam />} />
                                <Route path="payments" element={<StaffPayments />} />
                                <Route path="pricing" element={<StaffPlans />} />
                                <Route path="branding" element={<Branding />} />
                                <Route path="integrations" element={<Integrations />} />
                                <Route path="emails" element={<EmailCenter />} />
                                <Route path="legal" element={<LegalEditor />} />
                                <Route path="tenants" element={<TenantList />} />
                                <Route path="tenants/:orgId" element={<TenantDetail />} />
                                <Route path="metrics" element={<Metrics />} />
                                <Route path="controls" element={<GlobalControls />} />
                                <Route path="fraud" element={<StaffFraud />} />
                                <Route path="support" element={<StaffSupport />} />
                                <Route path="ai-usage" element={<StaffAiUsage />} />
                                <Route path="competitive" element={<StaffCompetitive />} />
                                <Route path="audit" element={<AuditLog />} />
                                <Route path="health" element={<ProviderHealth />} />
                                <Route path="approvals" element={<Approvals />} />
                            </Route>

                            <Route path="*" element={<NotFound />} />
                        </Routes>
                        </PageTransition>
                    </BrowserRouter>
                    <Toaster position="bottom-right" closeButton toastOptions={{ classNames: { toast: "!rounded-xl !border-brand-line !shadow-xl !text-[13px]" } }} />
                </AuthProvider>
            </BrandProvider>
            </ThemeProvider>
        </div>
    );
}

export default App;
