"""Store engine — products + orders + public buy-now (simulated checkout) + CSV import.

Owner-scoped management under /api/store; public storefront + buy-now under
/api/public/store. Products/orders use UUID string _id (JSON-safe, no ObjectId).

The public buy-now flow creates a `store_orders` doc + a `payments` doc
(kind="store_order") + a SimulatedProvider checkout session, then returns the
in-app checkout URL (/pay/simulated/{sid}). When that session is paid via the
existing public POST /api/payments/simulated/pay endpoint, bookings._apply_paid_event
detects the store_order payment and calls apply_store_order_paid() here — flipping
the order to paid, decrementing stock, and firing buyer + owner notifications.
Idempotent: the payment doc flips to paid on first apply, so double-pay is a no-op.
"""
from __future__ import annotations

import asyncio
import csv
import io
import logging
import os
import uuid
from typing import Any, Dict, List, Literal, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Request, Response, UploadFile
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org, require_role
from .. import config
from ..models import User
from ..services.payment_providers import CheckoutRequest, build_payment_provider
from ..services import attribution as _attribution

logger = logging.getLogger("zanelvo")

router = APIRouter(prefix="/store", tags=["store"])
public_router = APIRouter(prefix="/public/store", tags=["store-public"])


# --------------------------- helpers ---------------------------

def _product_out(doc: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": doc["_id"],
        "name": doc.get("name"),
        "description": doc.get("description", ""),
        "price_cents": int(doc.get("price_cents", 0)),
        "compare_at_cents": int(doc.get("compare_at_cents", 0) or 0),
        "currency": doc.get("currency", "USD"),
        "stock": int(doc.get("stock", 0)),
        "track_inventory": bool(doc.get("track_inventory", True)),
        "weight_grams": int(doc.get("weight_grams", 0) or 0),
        "requires_shipping": bool(doc.get("requires_shipping", True)),
        "image_url": doc.get("image_url", ""),
        "images": doc.get("images", []),
        "active": bool(doc.get("active", True)),
        "sku": doc.get("sku", ""),
        "product_type": doc.get("product_type", "physical"),
        "digital_url": doc.get("digital_url", ""),
        "variants": doc.get("variants", []),
        "options": doc.get("options", []),
        "barcode": doc.get("barcode", ""),
        "related_ids": doc.get("related_ids", []),
        "bundle_items": doc.get("bundle_items", []),
        "gift_card_amount_cents": int(doc.get("gift_card_amount_cents", 0) or 0),
        "is_subscription": bool(doc.get("is_subscription", False)),
        "billing_interval": doc.get("billing_interval", "month"),
        "collection_ids": doc.get("collection_ids", []),
        "tags": doc.get("tags", []),
        "seo_title": doc.get("seo_title", ""),
        "seo_description": doc.get("seo_description", ""),
        "created_at": doc.get("created_at"),
        "updated_at": doc.get("updated_at"),
    }


def _order_out(doc: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": doc["_id"],
        "items": doc.get("items", []),
        "subtotal_cents": int(doc.get("subtotal_cents", 0)),
        "discount_cents": int(doc.get("discount_cents", 0) or 0),
        "discount_code": doc.get("discount_code", ""),
        "gift_card_cents": int(doc.get("gift_card_cents", 0) or 0),
        "gift_card_code": doc.get("gift_card_code", ""),
        "amount_charged_cents": int(doc.get("amount_charged_cents", doc.get("total_cents", 0)) or 0),
        "customer_id": doc.get("customer_id"),
        "shipping_cents": int(doc.get("shipping_cents", 0) or 0),
        "total_cents": int(doc.get("total_cents", doc.get("subtotal_cents", 0)) or 0),
        "shipping_method": doc.get("shipping_method", ""),
        "shipping_country": doc.get("shipping_country", ""),
        "fulfillment": doc.get("fulfillment", {}),
        "shipped_at": doc.get("shipped_at"),
        "currency": doc.get("currency", "USD"),
        "status": doc.get("status", "pending"),
        "buyer": doc.get("buyer", {}),
        "contact_id": doc.get("contact_id"),
        "provider": doc.get("provider", "simulated"),
        "provider_session_id": doc.get("provider_session_id"),
        "paid_at": doc.get("paid_at"),
        "fulfilled_at": doc.get("fulfilled_at"),
        "refunded_at": doc.get("refunded_at"),
        "cancelled_at": doc.get("cancelled_at"),
        "refund_reason": doc.get("refund_reason", ""),
        "tax_cents": int(doc.get("tax_cents", 0) or 0),
        "tax": doc.get("tax", {}),
        "status_history": doc.get("status_history", []),
        "notes": doc.get("notes", []),
        "returns": doc.get("returns", []),
        "created_at": doc.get("created_at"),
        "updated_at": doc.get("updated_at"),
    }


# =========================== OWNER: PRODUCTS ===========================

class ProductIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str = ""
    price_cents: int = Field(ge=0)
    compare_at_cents: int = Field(default=0, ge=0)
    currency: str = "USD"
    stock: int = Field(default=0, ge=0)
    track_inventory: bool = True
    weight_grams: int = Field(default=0, ge=0)
    requires_shipping: bool = True
    image_url: str = ""
    images: List[str] = Field(default_factory=list)
    active: bool = True
    sku: str = ""
    product_type: str = "physical"  # physical | digital
    digital_url: str = ""
    variants: List[Dict[str, Any]] = Field(default_factory=list)
    options: List[Dict[str, Any]] = Field(default_factory=list)   # [{name, values[]}] → variant matrix
    barcode: str = Field(default="", max_length=64)
    related_ids: List[str] = Field(default_factory=list)          # "You may also like"
    bundle_items: List[Dict[str, Any]] = Field(default_factory=list)  # [{product_id, qty}] for product_type=bundle
    gift_card_amount_cents: int = Field(default=0, ge=0)          # face value for product_type=gift_card
    is_subscription: bool = False                                # Round 12: recurring product
    billing_interval: str = "month"                              # month | year
    collection_ids: List[str] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    seo_title: str = ""
    seo_description: str = ""


class ProductPatch(BaseModel):
    model_config = {"extra": "forbid"}
    name: Optional[str] = None
    description: Optional[str] = None
    price_cents: Optional[int] = Field(default=None, ge=0)
    compare_at_cents: Optional[int] = Field(default=None, ge=0)
    currency: Optional[str] = None
    stock: Optional[int] = Field(default=None, ge=0)
    track_inventory: Optional[bool] = None
    weight_grams: Optional[int] = Field(default=None, ge=0)
    requires_shipping: Optional[bool] = None
    image_url: Optional[str] = None
    images: Optional[List[str]] = None
    active: Optional[bool] = None
    sku: Optional[str] = None
    product_type: Optional[str] = None
    digital_url: Optional[str] = None
    variants: Optional[List[Dict[str, Any]]] = None
    options: Optional[List[Dict[str, Any]]] = None
    barcode: Optional[str] = Field(default=None, max_length=64)
    related_ids: Optional[List[str]] = None
    bundle_items: Optional[List[Dict[str, Any]]] = None
    gift_card_amount_cents: Optional[int] = Field(default=None, ge=0)
    is_subscription: Optional[bool] = None
    billing_interval: Optional[str] = None
    collection_ids: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    seo_title: Optional[str] = None
    seo_description: Optional[str] = None


@router.get("/products")
async def list_products(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for p in db.store_products.find({"org_id": org_id}).sort("created_at", -1):
        out.append(_product_out(p))
    return {"products": out}


@router.post("/products")
async def create_product(req: ProductIn, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    now = utc_now_iso()
    from ..services.entitlements import enforce_feature_enabled, enforce_entitlement
    # Plan product cap (max_products) — enforced server-side before the write.
    await enforce_entitlement(org_id, "products", increment=1)
    # Selling subscription (recurring) products is a paid feature.
    if getattr(req, "is_subscription", False):
        await enforce_feature_enabled(org_id, "subscriptions")
    doc = {"_id": uuid.uuid4().hex, "org_id": org_id, **req.model_dump(),
           "created_at": now, "updated_at": now}
    await db.store_products.insert_one(doc)
    return _product_out(doc)


@router.put("/products/{product_id}")
async def update_product(product_id: str, req: ProductPatch,
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    patch = {k: v for k, v in req.model_dump(exclude_none=True).items()}
    if not patch:
        raise HTTPException(400, "No fields to update")
    # ENTITLEMENT: block the bypass of creating a normal product then updating it into a
    # subscription (recurring) product without the paid `subscriptions` feature.
    if patch.get("is_subscription") is True:
        from ..services.entitlements import enforce_feature_enabled
        await enforce_feature_enabled(org_id, "subscriptions")
    patch["updated_at"] = utc_now_iso()
    res = await db.store_products.find_one_and_update(
        {"_id": product_id, "org_id": org_id}, {"$set": patch}, return_document=True)
    if not res:
        raise HTTPException(404, "Product not found")
    return _product_out(res)


@router.delete("/products/{product_id}")
async def delete_product(product_id: str, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.store_products.delete_one({"_id": product_id, "org_id": org_id})
    if r.deleted_count == 0:
        raise HTTPException(404, "Product not found")
    return {"ok": True}


# =========================== OWNER: ORDERS ===========================

@router.get("/orders")
async def list_orders(status: Optional[str] = None, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if status:
        q["status"] = status
    out = []
    async for o in db.store_orders.find(q).sort("created_at", -1):
        out.append(_order_out(o))
    return {"orders": out}


@router.get("/orders/{order_id}")
async def get_order(order_id: str, user: User = Depends(current_user),
                     org_id: str = Depends(require_org)):
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    if not o:
        raise HTTPException(404, "Order not found")
    return _order_out(o)


@router.post("/orders/{order_id}/fulfill")
async def fulfill_order(order_id: str, user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    if not o:
        raise HTTPException(404, "Order not found")
    if o.get("status") != "paid":
        raise HTTPException(400, "Only paid orders can be fulfilled")
    now = utc_now_iso()
    await db.store_orders.update_one({"_id": order_id, "org_id": org_id},
                                      {"$set": {"status": "fulfilled", "fulfilled_at": now,
                                                 "updated_at": now},
                                       "$push": {"status_history": {"status": "fulfilled", "at": now, "actor": user.email, "note": ""}}})
    o["status"] = "fulfilled"
    o["fulfilled_at"] = now
    return _order_out(o)


class RefundReq(BaseModel):
    reason: str = ""
    restock: bool = True


@router.post("/orders/{order_id}/refund")
async def refund_order(order_id: str, req: RefundReq = RefundReq(),
                        user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Refund a paid/fulfilled order and (by default) auto-restock the items. Idempotent."""
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    if not o:
        raise HTTPException(404, "Order not found")
    if o.get("status") == "refunded":
        raise HTTPException(400, "Order already refunded")
    if o.get("status") not in ("paid", "fulfilled"):
        raise HTTPException(400, "Only paid or fulfilled orders can be refunded")
    now = utc_now_iso()
    # Attempt a real provider refund when the order was paid via a live provider.
    provider_refunded = False
    provider_name = o.get("provider", "simulated")
    if provider_name not in ("simulated", "", None):
        try:
            _key, prov = await _resolve_store_provider(db, org_id)
            if _key != "simulated" and hasattr(prov, "refund"):
                pay = await db.payments.find_one({"order_id": order_id, "kind": "store_order"})
                intent = (pay or {}).get("provider_payment_intent") or (pay or {}).get("provider_session_id")
                if intent:
                    res = await prov.refund(intent, int(o.get("subtotal_cents", 0)))
                    provider_refunded = bool((res or {}).get("ok", res))
        except Exception as e:  # noqa: BLE001
            logger.warning("provider refund failed (continuing with local refund): %s", e)
    # Auto-restock
    restocked = []
    if req.restock:
        for item in o.get("items", []):
            await db.store_products.update_one(
                {"_id": item["product_id"], "org_id": org_id},
                {"$inc": {"stock": int(item["qty"])}, "$set": {"updated_at": now}})
            restocked.append({"product_id": item["product_id"], "qty": int(item["qty"])})
    await db.store_orders.update_one(
        {"_id": order_id, "org_id": org_id},
        {"$set": {"status": "refunded", "refunded_at": now, "updated_at": now,
                  "refund_reason": req.reason or ""},
         "$push": {"status_history": {"status": "refunded", "at": now, "actor": user.email, "note": req.reason or ""}}})
    await db.payments.update_many(
        {"order_id": order_id, "kind": "store_order"},
        {"$set": {"status": "refunded", "updated_at": now}})
    # Timeline + notification
    try:
        from .crm import _record_interaction
        await _record_interaction(
            db, org_id, contact_id=o.get("contact_id"), type_="store_order_refunded",
            summary=f"Order refunded: {o['subtotal_cents']/100:.2f} {o.get('currency','USD')}"
                    + (f" — {req.reason}" if req.reason else ""),
            ref_type="store_order", ref_id=order_id,
            meta={"order_id": order_id, "restocked": restocked,
                  "provider_refunded": provider_refunded})
    except Exception as e:  # noqa: BLE001
        logger.warning("refund timeline hook failed: %s", e)
    try:
        await _notify_order_refunded(db, o, o.get("buyer", {}), o.get("contact_id"), req.reason)
    except Exception as e:  # noqa: BLE001
        logger.warning("refund notification failed: %s", e)
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    out = _order_out(o)
    out["restocked"] = restocked
    out["provider_refunded"] = provider_refunded
    out["simulated"] = provider_name in ("simulated", "", None)
    return out


@router.post("/orders/{order_id}/cancel")
async def cancel_order(order_id: str, user: User = Depends(current_user),
                        org_id: str = Depends(require_org)):
    """Cancel a pending (unpaid) order. Paid orders must be refunded instead."""
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    if not o:
        raise HTTPException(404, "Order not found")
    if o.get("status") == "cancelled":
        raise HTTPException(400, "Order already cancelled")
    if o.get("status") != "pending":
        raise HTTPException(400, "Only pending orders can be cancelled (paid orders must be refunded)")
    now = utc_now_iso()
    await db.store_orders.update_one(
        {"_id": order_id, "org_id": org_id},
        {"$set": {"status": "cancelled", "cancelled_at": now, "updated_at": now},
         "$push": {"status_history": {"status": "cancelled", "at": now, "actor": user.email, "note": ""}}})
    try:
        from ..services import commerce_ext as _cx
        await _cx.settle_reservation(db, order_id, "released")
    except Exception as e:  # noqa: BLE001
        logger.warning("reservation release failed: %s", e)
    await db.payments.update_many(
        {"order_id": order_id, "kind": "store_order"},
        {"$set": {"status": "cancelled", "updated_at": now}})
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    return _order_out(o)


# =========================== OWNER: CSV IMPORT ===========================

class ImportMapping(BaseModel):
    column: str
    target: str  # name|description|price|stock|sku|image_url|skip


class ProductImportExecuteReq(BaseModel):
    mapping: List[ImportMapping]


def _to_cents(raw: str) -> Optional[int]:
    s = (raw or "").strip().replace("$", "").replace(",", "")
    if not s:
        return None
    try:
        return int(round(float(s) * 100))
    except ValueError:
        return None


@router.post("/products/import/analyze")
async def product_import_analyze(file: UploadFile = File(...),
                                   user: User = Depends(current_user),
                                   org_id: str = Depends(require_org)):
    db = get_db()
    _raw = await file.read()
    if len(_raw) > 8 * 1024 * 1024:
        raise HTTPException(413, "CSV file too large (max 8 MB).")
    content = _raw.decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        raise HTTPException(400, "CSV has no header row")
    rows = list(reader)[:2000]
    proposed: List[Dict[str, str]] = []
    for col in reader.fieldnames:
        low = (col or "").strip().lower()
        target = "skip"
        if low in ("name", "title", "product", "product name"):
            target = "name"
        elif low in ("description", "desc", "details"):
            target = "description"
        elif low in ("price", "amount", "cost", "unit price"):
            target = "price"
        elif low in ("stock", "qty", "quantity", "inventory"):
            target = "stock"
        elif low in ("sku", "code", "id"):
            target = "sku"
        elif low in ("image", "image_url", "photo", "picture"):
            target = "image_url"
        proposed.append({"column": col, "target": target})
    run = {"_id": uuid.uuid4().hex, "org_id": org_id, "filename": file.filename or "products.csv",
           "rows_json": rows, "total_rows": len(rows), "status": "mapping",
           "created_at": utc_now_iso()}
    await db.product_import_runs.insert_one(run)
    return {"run_id": run["_id"], "columns": reader.fieldnames,
            "proposed_mapping": proposed, "row_sample": rows[:5], "total_rows": len(rows)}


@router.post("/products/import/{run_id}/execute")
async def product_import_execute(run_id: str, req: ProductImportExecuteReq,
                                   user: User = Depends(current_user),
                                   org_id: str = Depends(require_org)):
    db = get_db()
    run = await db.product_import_runs.find_one({"_id": run_id, "org_id": org_id})
    if not run:
        raise HTTPException(404, "Import run not found")
    # Plan product cap applies to bulk imports too (can't bypass max_products via CSV).
    from ..services.entitlements import enforce_entitlement as _enf
    _n_new = int(run.get("total_rows") or len(run.get("rows_json") or []))
    await _enf(org_id, "products", increment=max(1, _n_new))
    m = {mp.target: mp.column for mp in req.mapping if mp.target != "skip"}
    if "name" not in m:
        raise HTTPException(400, "A column must be mapped to 'name'")
    created: List[str] = []
    errors: List[Dict[str, Any]] = []
    now = utc_now_iso()
    for i, row in enumerate(run.get("rows_json", [])):
        name = (row.get(m["name"]) or "").strip()
        if not name:
            errors.append({"row_index": i, "error": "missing name"})
            continue
        price_cents = _to_cents(row.get(m["price"])) if "price" in m else 0
        if "price" in m and price_cents is None:
            errors.append({"row_index": i, "error": "invalid price"})
            continue
        stock = 0
        if "stock" in m:
            sraw = (row.get(m["stock"]) or "").strip()
            if sraw:
                try:
                    stock = max(0, int(float(sraw)))
                except ValueError:
                    errors.append({"row_index": i, "error": "invalid stock"})
                    continue
        doc = {"_id": uuid.uuid4().hex, "org_id": org_id, "name": name[:200],
               "description": (row.get(m["description"]) or "").strip() if "description" in m else "",
               "price_cents": int(price_cents or 0), "currency": "USD", "stock": stock,
               "image_url": (row.get(m["image_url"]) or "").strip() if "image_url" in m else "",
               "sku": (row.get(m["sku"]) or "").strip() if "sku" in m else "",
               "active": True, "created_at": now, "updated_at": now}
        await db.store_products.insert_one(doc)
        created.append(doc["_id"])
    await db.product_import_runs.update_one({"_id": run_id}, {"$set": {"status": "done"}})
    return {"created": len(created), "errors": errors}


# =========================== OWNER: PRODUCT SOURCING (dropshipping) ===========================

@router.get("/sourcing/providers")
async def sourcing_providers(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from ..services.product_sourcing import provider_status
    return {"providers": await provider_status(org_id)}


class SourcingImportReq(BaseModel):
    provider: Literal["starter", "aliexpress", "cj", "cj_dropshipping"]
    limit: int = Field(default=50, ge=1, le=250)


@router.post("/sourcing/import")
async def sourcing_import(req: SourcingImportReq, user: User = Depends(current_user),
                           org_id: str = Depends(require_org)):
    from ..services.product_sourcing import import_products
    result = await import_products(org_id, req.provider, limit=req.limit)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error") or "Import failed")
    return result


# =========================== OWNER: STORE SETTINGS / GO-LIVE ===========================

async def _resolve_store_provider(db, org_id: str):
    """Pick the payment provider for a store checkout based on tenant config.

    Returns (provider_key, provider_instance). Uses real Stripe only when the store
    has been flipped to 'live' AND a Stripe secret key is stored; otherwise simulated.
    """
    from ..services import stripe_connect
    try:
        ctx = await stripe_connect.tenant_charge_context(org_id)
        if ctx:
            prov = build_payment_provider("stripe", stripe_api_key=ctx["api_key"],
                                          stripe_webhook_secret=ctx["webhook_secret"],
                                          stripe_account=ctx["stripe_account"])
            if getattr(prov, "is_connected", False):
                return "stripe", prov
    except Exception as e:  # noqa: BLE001
        logger.warning("store provider resolve failed, falling back to simulated: %s", e)
    return "simulated", build_payment_provider("simulated")


@router.get("/settings")
async def store_settings(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Store go-live status — derived from the REAL Stripe Connect state (never from pasted keys)."""
    from ..services import stripe_connect
    st = await stripe_connect.refresh_status(org_id)
    mode = st.get("store_mode", "test")
    stripe_ready = bool(st.get("available") and st.get("charges_enabled"))
    return {
        "store_mode": mode,
        "live": mode == "live" and stripe_ready,
        "stripe_ready": stripe_ready,
        "connect": st,
        "webhook_ready": bool(await stripe_connect.platform_webhook_secret()),
        "active_provider": "stripe" if (mode == "live" and stripe_ready) else "simulated",
        "simulation_allowed": config.simulation_allowed(),
        "paypal": {"available": False, "status": "Not connected — unavailable until a signed sandbox flow passes."},
        "recurring_billing": {"available": False,
                              "status": "Recurring card billing for subscription products is not available yet "
                                        "(Stripe Billing integration pending). Subscription products can be created "
                                        "but renewals are not charged automatically."},
    }


class GoLiveReq(BaseModel):
    live: bool


@router.post("/go-live")
async def store_go_live(req: GoLiveReq, user: User = Depends(require_role("owner")),
                         org_id: str = Depends(require_org)):
    """Flip the store between test (simulated) and live (real charges on the tenant's connected account).

    Going live requires a Stripe Connect account whose `charges_enabled` Stripe has verified.
    """
    from ..services import stripe_connect, tenant_integrations
    if req.live:
        st = await stripe_connect.refresh_status(org_id)
        if not st.get("available"):
            raise HTTPException(503, {"error": "stripe_connect_unavailable",
                                      "message": st.get("reason") or "Online payments are not available yet."})
        if not st.get("charges_enabled"):
            raise HTTPException(400, {"error": "connect_incomplete",
                                      "message": "Finish Stripe onboarding (Settings → Payments → Connect with Stripe) "
                                                 "before going live. Stripe has not enabled charges for this account yet."})
    await tenant_integrations.update(org_id, {"payments": {"store_mode": "live" if req.live else "test"}})
    return await store_settings(user=user, org_id=org_id)


# ---------------------------------------------------------------------------
# Stripe Connect onboarding (tenant) — no secret keys ever pass through Zanelvo.
# ---------------------------------------------------------------------------

class ConnectStartReq(BaseModel):
    country: str = "US"


@router.post("/payments/stripe/connect/start")
async def stripe_connect_start(req: ConnectStartReq, request: Request,
                               user: User = Depends(require_role("owner")),
                               org_id: str = Depends(require_org)):
    from ..services import stripe_connect
    origin = (request.headers.get("origin") or "").rstrip("/")
    return await stripe_connect.start_onboarding(org_id, origin, email=user.email, country=req.country)


@router.get("/payments/stripe/connect/status")
async def stripe_connect_status(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from ..services import stripe_connect
    return await stripe_connect.refresh_status(org_id)


# =========================== OWNER: ABANDONED CHECKOUT NUDGE ===========================

ABANDON_AFTER_MIN_DEFAULT = 30


async def sweep_abandoned_checkouts(db, org_id: Optional[str] = None,
                                     older_than_min: int = ABANDON_AFTER_MIN_DEFAULT,
                                     limit: int = 200) -> Dict[str, Any]:
    """Find pending orders older than `older_than_min` with a buyer email that have
    not yet been nudged, and email the buyer a 'complete your order' link. Idempotent
    per order via `abandoned_nudge_sent`. If org_id is None, sweeps all orgs (cron)."""
    from datetime import datetime, timedelta, timezone
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=max(1, older_than_min))).isoformat()
    q: Dict[str, Any] = {
        "status": "pending",
        "abandoned_nudge_sent": {"$ne": True},
        "created_at": {"$lt": cutoff},
        "buyer.email": {"$nin": ["", None]},
    }
    if org_id:
        q["org_id"] = org_id
    sent = 0
    cursor = db.store_orders.find(q).sort("created_at", 1).limit(limit)
    _ent_cache: Dict[str, bool] = {}
    from ..services.entitlements import get_org_plan as _gop, entitlements_dict as _ed
    async for order in cursor:
        _oid = order.get("org_id")
        if _oid not in _ent_cache:
            try:
                _ent_cache[_oid] = bool(_ed(await _gop(_oid)).get("abandoned_cart"))
            except Exception:  # noqa: BLE001
                _ent_cache[_oid] = False
        if not _ent_cache[_oid]:
            continue  # plan does not include cart recovery — background job must not bypass it
        buyer = order.get("buyer", {})
        if not buyer.get("email"):
            continue
        try:
            await _notify_abandoned_checkout(db, order, buyer)
            await db.store_orders.update_one(
                {"_id": order["_id"]},
                {"$set": {"abandoned_nudge_sent": True,
                          "abandoned_nudge_at": utc_now_iso(),
                          "updated_at": utc_now_iso()}})
            sent += 1
        except Exception as e:  # noqa: BLE001
            logger.warning("abandoned nudge failed for order %s: %s", order.get("_id"), e)
    return {"ok": True, "nudged": sent}


async def _notify_abandoned_checkout(db, order, buyer) -> None:
    from ..models_crm import EmailProviderConfig
    from ..services.email_providers import SendPayload, build_provider_from_config
    cfg_doc = await db.email_provider_configs.find_one({"org_id": order["org_id"]})
    cfg = EmailProviderConfig.from_mongo(cfg_doc) if cfg_doc else EmailProviderConfig(org_id=order["org_id"])
    provider = build_provider_from_config(cfg)
    org = await _get_org(db, order["org_id"])
    store_name = (org or {}).get("name", "our store")
    lines = "\n".join(f" - {it['name']} x{it['qty']}" for it in order.get("items", []))
    total = f"{order['subtotal_cents']/100:.2f} {order.get('currency','USD')}"
    resume = f"/pay/simulated/{order.get('provider_session_id')}" if order.get("provider_session_id") else "/store"
    from_email = cfg.from_email or "notifications@zanelvo.local"
    from_name = cfg.from_name or store_name
    body = (f"Hi {buyer.get('name') or 'there'},\n\n"
            f"You left something behind at {store_name}! Your cart is still saved:\n\n"
            f"{lines}\n\nTotal: {total}\n\n"
            f"Finish your order here: {resume}\n\n"
            f"— {store_name}\n")
    res = await provider.send(SendPayload(
        from_email=from_email, from_name=from_name, to=[buyer["email"]],
        subject=f"You left items in your cart — {store_name}", text=body))
    try:
        from .crm import upsert_contact_from_form, _record_interaction
        cid = order.get("contact_id")
        if not cid and (buyer.get("email") or buyer.get("phone")):
            fields = {k: v for k, v in {"email": buyer.get("email"), "phone": buyer.get("phone"),
                                         "name": buyer.get("name")}.items() if v}
            cid = await upsert_contact_from_form(db, order["org_id"], fields, source="store")
        await _record_interaction(
            db, order["org_id"], contact_id=cid, type_="store_abandoned_nudge_sent",
            summary=f"Abandoned checkout nudge {'delivered (simulated)' if res.simulated else 'sent'} to {buyer['email']}",
            ref_type="store_order", ref_id=order["_id"],
            meta={"simulated": res.simulated, "provider": provider.key})
    except Exception:  # noqa: BLE001
        pass


@router.get("/abandoned")
async def list_abandoned(older_than_min: int = ABANDON_AFTER_MIN_DEFAULT,
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from datetime import datetime, timedelta, timezone
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=max(1, older_than_min))).isoformat()
    out = []
    async for o in db_abandoned_cursor(org_id, cutoff):
        out.append(_order_out(o) | {"abandoned_nudge_sent": bool(o.get("abandoned_nudge_sent"))})
    return {"orders": out}


def db_abandoned_cursor(org_id: str, cutoff: str):
    db = get_db()
    return db.store_orders.find({
        "org_id": org_id, "status": "pending",
        "buyer.email": {"$nin": ["", None]},
        "created_at": {"$lt": cutoff},
    }).sort("created_at", -1)


class AbandonSweepReq(BaseModel):
    older_than_min: int = Field(default=ABANDON_AFTER_MIN_DEFAULT, ge=1, le=10080)


@router.post("/abandoned/sweep")
async def abandoned_sweep(req: AbandonSweepReq = AbandonSweepReq(),
                           user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from ..services.entitlements import enforce_feature_enabled
    await enforce_feature_enabled(org_id, "abandoned_cart")
    db = get_db()
    return await sweep_abandoned_checkouts(db, org_id=org_id, older_than_min=req.older_than_min)


# ---- background auto-sweep loop (all orgs) ----
_abandon_task: Optional[asyncio.Task] = None
ABANDON_SWEEP_INTERVAL_SEC = 600  # every 10 minutes


async def _abandoned_sweep_loop():
    from ..db import get_db as _get_db
    # small initial delay so startup/seed finishes first
    await asyncio.sleep(60)
    while True:
        try:
            await sweep_abandoned_checkouts(_get_db(), org_id=None,
                                             older_than_min=ABANDON_AFTER_MIN_DEFAULT)
        except Exception as e:  # noqa: BLE001
            logger.exception("abandoned_sweep_loop error: %s", e)
        await asyncio.sleep(ABANDON_SWEEP_INTERVAL_SEC)


def start_abandoned_sweep_loop():
    global _abandon_task
    if _abandon_task is None or _abandon_task.done():
        _abandon_task = asyncio.create_task(_abandoned_sweep_loop())


# =========================== PUBLIC: STOREFRONT ===========================

_PUBLIC_SORTS = {"newest": ("created_at", -1), "price_asc": ("price_cents", 1),
                 "price_desc": ("price_cents", -1), "name": ("name", 1)}


@public_router.get("/{org_id}/products")
async def public_products(org_id: str, q: str = "", sort: str = "newest", collection_id: str = "", tag: str = ""):
    """Storefront catalogue. Round 11: text search (`q` over name/description/tags/sku), `sort`
    (newest|price_asc|price_desc|name), `collection_id` and `tag` filters — all server-side."""
    db = get_db()
    org = await _get_org(db, org_id)
    flt: Dict[str, Any] = {"org_id": org_id, "active": True, "stock": {"$gt": 0}}
    q = (q or "").strip()[:80]
    if q:
        import re as _re
        rx = {"$regex": _re.escape(q), "$options": "i"}
        flt["$or"] = [{"name": rx}, {"description": rx}, {"tags": rx}, {"sku": rx}]
    if collection_id:
        flt["collection_ids"] = collection_id
    if tag:
        flt["tags"] = tag
    key, direction = _PUBLIC_SORTS.get(sort, _PUBLIC_SORTS["newest"])
    out = []
    async for p in db.store_products.find(flt).sort(key, direction).limit(500):
        out.append(_product_out(p))
    brand = await db.org_branding.find_one({"org_id": org_id})
    branding = {"logo_svg": (brand or {}).get("logo_svg", ""),
                "logo_image": (brand or {}).get("logo_image", ""),
                "logo_animation": (brand or {}).get("logo_animation", "none")} if brand else {}
    # Storefront-level automatic discounts (shopper-facing label only; amounts are computed at checkout).
    autos = [{"title": d.get("title") or d.get("code"), "type": d.get("type"), "value": d.get("value"),
              "min_subtotal_cents": int(d.get("min_subtotal_cents", 0))}
             async for d in db.store_discounts.find({"org_id": org_id, "auto": True, "active": True}).limit(5)]
    return {"org_id": org_id, "store_name": (org or {}).get("name", "Store"),
            "branding": branding, "products": out, "query": {"q": q, "sort": sort if sort in _PUBLIC_SORTS else "newest",
                                                             "collection_id": collection_id, "tag": tag},
            "auto_discounts": autos}


@public_router.get("/{org_id}/products/{product_id}/related")
async def public_related_products(org_id: str, product_id: str, limit: int = 4):
    """"You may also like" — explicit `related_ids` first, then products sharing tags/collections."""
    db = get_db()
    product = await db.store_products.find_one({"_id": product_id, "org_id": org_id})
    if not product:
        raise HTTPException(404, "Product not found")
    limit = max(1, min(int(limit), 12))
    base = {"org_id": org_id, "active": True, "stock": {"$gt": 0}, "_id": {"$ne": product_id}}
    out: List[Dict[str, Any]] = []
    seen = set()
    rel_ids = [r for r in (product.get("related_ids") or []) if r]
    if rel_ids:
        async for p in db.store_products.find({**base, "_id": {"$in": rel_ids, "$ne": product_id}}):
            if p["_id"] not in seen:
                out.append(_product_out(p)); seen.add(p["_id"])
    if len(out) < limit:
        ors = []
        if product.get("tags"):
            ors.append({"tags": {"$in": product["tags"]}})
        if product.get("collection_ids"):
            ors.append({"collection_ids": {"$in": product["collection_ids"]}})
        if ors:
            async for p in db.store_products.find({**base, "$or": ors}).sort("created_at", -1).limit(limit * 2):
                if p["_id"] not in seen:
                    out.append(_product_out(p)); seen.add(p["_id"])
                if len(out) >= limit:
                    break
    return {"product_id": product_id, "related": out[:limit], "source": "related_ids" if rel_ids else "shared_tags"}


@public_router.get("/{org_id}/discount-preview")
async def public_discount_preview(org_id: str, subtotal_cents: int = 0, code: str = ""):
    """Shopper-facing preview of the discount that WILL be applied at checkout (server-authoritative)."""
    from .ecommerce import best_discount
    db = get_db()
    await _get_org(db, org_id)
    r = await best_discount(db, org_id, max(0, int(subtotal_cents)), code.strip() or None)
    return {k: v for k, v in r.items() if k != "discount_id"} | {"final_cents": max(0, int(subtotal_cents) - int(r.get("discount_cents", 0)))}


def _feed_products_query(org_id: str) -> Dict[str, Any]:
    return {"org_id": org_id, "active": True, "stock": {"$gt": 0}}


def _abs_url(request: Request, path: str) -> str:
    base = (os.environ.get("PUBLIC_BASE_URL") or str(request.base_url)).rstrip("/")
    return f"{base}{path}"


@public_router.get("/{org_id}/feed.xml")
async def public_feed_xml(org_id: str, request: Request):
    """Google Shopping product feed (RSS 2.0 + g: namespace). Owner toggle: store_settings.feeds_enabled
    (default on). Only active, in-stock products with a price are listed; honest availability."""
    db = get_db()
    org = await _get_org(db, org_id)
    st = await db.store_settings.find_one({"org_id": org_id}) or {}
    if st.get("feeds_enabled", True) is False:
        raise HTTPException(404, "Feed disabled")
    from xml.sax.saxutils import escape as _x
    items = []
    async for p in db.store_products.find(_feed_products_query(org_id)).sort("created_at", -1).limit(5000):
        price = int(p.get("price_cents", 0)) / 100
        cur = p.get("currency", "USD")
        link = _abs_url(request, f"/store/{org_id}?product={p['_id']}")
        parts = [f"<g:id>{_x(str(p['_id']))}</g:id>", f"<g:title>{_x(p.get('name', ''))}</g:title>",
                 f"<g:description>{_x((p.get('description') or p.get('name') or '')[:5000])}</g:description>",
                 f"<g:link>{_x(link)}</g:link>", f"<g:price>{price:.2f} {_x(cur)}</g:price>",
                 "<g:availability>in_stock</g:availability>",
                 f"<g:condition>new</g:condition>"]
        if p.get("image_url"):
            parts.append(f"<g:image_link>{_x(p['image_url'])}</g:image_link>")
        if p.get("barcode"):
            parts.append(f"<g:gtin>{_x(p['barcode'])}</g:gtin>")
        if p.get("sku"):
            parts.append(f"<g:mpn>{_x(p['sku'])}</g:mpn>")
        if int(p.get("compare_at_cents", 0) or 0) > int(p.get("price_cents", 0)):
            parts.append(f"<g:sale_price>{price:.2f} {_x(cur)}</g:sale_price>")
        if p.get("weight_grams"):
            parts.append(f"<g:shipping_weight>{int(p['weight_grams'])} g</g:shipping_weight>")
        items.append("<item>" + "".join(parts) + "</item>")
    title = _x((org or {}).get("name", "Store"))
    xml = ('<?xml version="1.0" encoding="UTF-8"?>'
           '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0"><channel>'
           f"<title>{title}</title><link>{_x(_abs_url(request, f'/store/{org_id}'))}</link>"
           f"<description>{title} product feed</description>" + "".join(items) + "</channel></rss>")
    return Response(content=xml, media_type="application/xml")


@public_router.get("/{org_id}/feed.csv")
async def public_feed_csv(org_id: str, request: Request):
    """Meta / marketplace CSV feed (same rows as feed.xml)."""
    db = get_db()
    await _get_org(db, org_id)
    st = await db.store_settings.find_one({"org_id": org_id}) or {}
    if st.get("feeds_enabled", True) is False:
        raise HTTPException(404, "Feed disabled")
    import csv as _csv
    import io as _io
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(["id", "title", "description", "availability", "condition", "price", "link", "image_link", "brand", "gtin", "mpn"])
    org = await _get_org(db, org_id)
    async for p in db.store_products.find(_feed_products_query(org_id)).sort("created_at", -1).limit(5000):
        w.writerow([p["_id"], p.get("name", ""), (p.get("description") or "")[:5000], "in stock", "new",
                    f"{int(p.get('price_cents', 0)) / 100:.2f} {p.get('currency', 'USD')}",
                    _abs_url(request, f"/store/{org_id}?product={p['_id']}"), p.get("image_url", ""),
                    (org or {}).get("name", ""), p.get("barcode", ""), p.get("sku", "")])
    return Response(content=buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "inline; filename=products-feed.csv"})


class BuyNowBuyer(BaseModel):
    name: str = ""
    email: str = ""
    phone: str = ""
    address: str = ""


class BuyNowReq(BaseModel):
    product_id: str
    qty: int = Field(default=1, ge=1, le=999)
    buyer: BuyNowBuyer = BuyNowBuyer()
    success_url: str = "/store/thank-you"
    country_code: str = ""          # destination for shipping quote (optional)
    region_code: str = ""           # state/province for tax (optional)
    shipping_option_id: str = ""    # "zone:rate" id from the shipping quote (optional)
    discount_code: str = Field(default="", max_length=40)  # Round 11: optional manual code (auto rules apply otherwise)
    gift_card_code: str = Field(default="", max_length=32)  # Round 12: optional stored-value tender
    customer_token: str = Field(default="", max_length=800)  # Round 12: shopper JWT (links order to account)
    attribution: Dict[str, Any] = Field(default_factory=dict)  # Round 11: UTM first-touch (allow-listed server-side)


@public_router.post("/{org_id}/buy-now")
async def buy_now(org_id: str, req: BuyNowReq):
    db = get_db()
    product = await db.store_products.find_one({"_id": req.product_id, "org_id": org_id})
    if not product or not product.get("active", True):
        raise HTTPException(404, "Product not available")
    from ..services import commerce_ext as cx
    if await cx.available_stock(db, product) < req.qty:
        raise HTTPException(400, "Not enough stock")
    subtotal = int(product["price_cents"]) * req.qty
    order_id = uuid.uuid4().hex
    now = utc_now_iso()
    # --- Discount: manual code (must be valid) or best automatic rule; never trust the client amount ---
    from .ecommerce import best_discount, resolve_buyer_group
    _cust_id_early = _shopper_id_from_token(req.customer_token, org_id)
    buyer_group = await resolve_buyer_group(db, org_id, _cust_id_early, req.buyer.email)
    disc = await best_discount(db, org_id, subtotal, req.discount_code.strip() or None, buyer_group)
    if req.discount_code.strip() and not disc.get("valid"):
        raise HTTPException(400, disc.get("message") or "Invalid discount code")
    discount_cents = int(disc.get("discount_cents", 0)) if disc.get("valid") else 0
    discounted_subtotal = max(0, subtotal - discount_cents)
    # --- Shipping: recompute server-side from the quote (never trust client price) ---
    shipping_cents = 0
    shipping_method = ""
    if req.country_code and product.get("requires_shipping", True):
        try:
            from ..services import shipping as ship
            weight = int(product.get("weight_grams", 0) or 0) * req.qty
            q = await ship.quote(org_id, req.country_code, discounted_subtotal, weight)
            if q.get("served") and q.get("options"):
                chosen = None
                if req.shipping_option_id:
                    chosen = next((o for o in q["options"] if o["id"] == req.shipping_option_id), None)
                chosen = chosen or q["options"][0]  # default to cheapest
                shipping_cents = int(chosen["amount_cents"])
                shipping_method = f"{chosen['zone']} · {chosen['name']}"
        except Exception as e:  # noqa: BLE001
            logger.warning("shipping quote during buy-now failed: %s", e)
    # --- Tax: server-side by destination (never trust client) ---
    tax = await cx.compute_tax(db, org_id, req.country_code, req.region_code, discounted_subtotal)
    tax_cents = int(tax["tax_cents"]) if tax.get("applied") and not tax.get("inclusive") else 0
    total = discounted_subtotal + shipping_cents + tax_cents
    # --- Gift card: applied as tender AFTER the order total is known (server verifies balance) ---
    from .gift_cards import preview_gift_card
    gc = await preview_gift_card(db, org_id, req.gift_card_code.strip(), total)
    if req.gift_card_code.strip() and not gc.get("valid"):
        raise HTTPException(400, gc.get("message") or "Invalid gift card")
    gift_card_cents = int(gc.get("applied_cents", 0)) if gc.get("valid") else 0
    amount_charged = max(0, total - gift_card_cents)
    # --- Link to a shopper account when a customer token is supplied ---
    customer_id = _cust_id_early
    provider_key, provider = await _resolve_store_provider(db, org_id)
    from .. import config as cfg
    # A gift card can fully cover the order → no external charge needed (works with no live provider).
    fully_covered = amount_charged <= 0 and gift_card_cents > 0
    if not fully_covered and provider_key == "simulated" and not cfg.simulation_allowed():
        raise HTTPException(400, {"error": "payments_not_configured",
                                  "message": "This store has no live payment provider connected yet."})
    order = {
        "_id": order_id, "org_id": org_id,
        "items": [{"product_id": product["_id"], "name": product["name"],
                    "price_cents": int(product["price_cents"]), "qty": req.qty}],
        "subtotal_cents": subtotal, "shipping_cents": shipping_cents,
        "discount_cents": discount_cents, "discount_code": disc.get("code", "") if discount_cents else "",
        "discount_auto": bool(disc.get("auto")) if discount_cents else False,
        "gift_card_cents": gift_card_cents, "gift_card_code": gc.get("code", "") if gift_card_cents else "",
        "amount_charged_cents": amount_charged,
        "customer_id": customer_id,
        "tax_cents": tax_cents, "tax": tax,
        "total_cents": total, "shipping_method": shipping_method,
        "shipping_country": (req.country_code or "").upper(),
        "status_history": [{"status": "pending", "at": now, "actor": "checkout", "note": ""}],
        "currency": product.get("currency", "USD"),
        "status": "pending", "buyer": req.buyer.model_dump(),
        "attribution": _attribution.clean_attribution(req.attribution),
        "contact_id": None, "provider": ("gift_card" if fully_covered else provider_key),
        "provider_session_id": None, "created_at": now, "updated_at": now,
    }
    if fully_covered:
        # Free order fully paid by gift card — no provider round-trip. Finalize immediately.
        await db.store_orders.insert_one(order)
        await _attribution.emit(db, org_id, "checkout_started", attribution=order.get("attribution"),
                                meta={"order_id": order_id, "amount_cents": total})
        if product.get("track_inventory", True):
            await cx.reserve_stock(db, org_id, product["_id"], req.qty, order_id)
        await db.payments.insert_one({
            "_id": uuid.uuid4().hex, "org_id": org_id, "kind": "store_order",
            "order_id": order_id, "amount_cents": 0, "currency": order["currency"],
            "method": "gift_card", "provider": "gift_card",
            "provider_session_id": None, "status": "paid",
            "created_at": now, "updated_at": now,
        })
        await _finalize_paid_order(db, order)
        return {"order_id": order_id, "checkout_url": None, "session_id": None, "provider": "gift_card",
                "subtotal_cents": subtotal, "shipping_cents": shipping_cents, "tax_cents": tax_cents, "tax": tax,
                "discount_cents": discount_cents, "discount_code": order["discount_code"],
                "discount_auto": order["discount_auto"], "gift_card_cents": gift_card_cents,
                "amount_charged_cents": 0, "total_cents": total, "paid": True, "simulated": False}
    result = await provider.create_checkout(CheckoutRequest(
        invoice_id=order_id, amount_cents=amount_charged, currency=order["currency"],
        customer_email=req.buyer.email or None,
        success_url=req.success_url, cancel_url="/store",
        metadata={"kind": "store_order", "order_id": order_id, "org_id": org_id},
    ))
    if not result.ok:
        raise HTTPException(502, "Could not start checkout")
    order["provider_session_id"] = result.session_id
    await db.store_orders.insert_one(order)
    await _attribution.emit(db, org_id, "checkout_started", attribution=order.get("attribution"),
                            meta={"order_id": order_id, "amount_cents": total})
    # Hold the stock for 30 minutes while the buyer pays (released on cancel/expiry, consumed on paid).
    if product.get("track_inventory", True):
        await cx.reserve_stock(db, org_id, product["_id"], req.qty, order_id)
    await db.payments.insert_one({
        "_id": uuid.uuid4().hex, "org_id": org_id, "kind": "store_order",
        "order_id": order_id, "amount_cents": amount_charged, "currency": order["currency"],
        "method": provider_key, "provider": provider_key,
        "provider_session_id": result.session_id, "status": "initiated",
        "created_at": now, "updated_at": now,
    })
    return {"order_id": order_id, "checkout_url": result.checkout_url,
            "session_id": result.session_id, "provider": provider_key,
            "subtotal_cents": subtotal, "shipping_cents": shipping_cents, "tax_cents": tax_cents, "tax": tax,
            "discount_cents": discount_cents, "discount_code": disc.get("code", "") if discount_cents else "",
            "discount_auto": bool(disc.get("auto")) if discount_cents else False,
            "gift_card_cents": gift_card_cents, "amount_charged_cents": amount_charged,
            "total_cents": total, "simulated": provider_key == "simulated"}


# ---- slug-based public storefront (portable to any host / custom domain) ----

async def _org_id_for_slug(db, slug: str) -> str:
    site = await db.websites.find_one({"slug": slug})
    if not site or not site.get("org_id"):
        raise HTTPException(404, "Store not found")
    return site["org_id"]


@public_router.get("/by-site/{slug}/products")
async def public_products_by_site(slug: str):
    db = get_db()
    org_id = await _org_id_for_slug(db, slug)
    return await public_products(org_id)


@public_router.post("/by-site/{slug}/buy-now")
async def buy_now_by_site(slug: str, req: BuyNowReq):
    db = get_db()
    org_id = await _org_id_for_slug(db, slug)
    return await buy_now(org_id, req)


# =========================== PAID HOOK (called by payments endpoint) ===========================

async def apply_store_order_paid(db, session_id: str, amount_cents: Optional[int] = None) -> bool:
    """Idempotent: flip payment+order to paid, decrement stock, notify. Returns True if applied."""
    pay = await db.payments.find_one({"provider_session_id": session_id, "kind": "store_order"})
    if not pay or pay.get("status") == "paid":
        return False
    order = await db.store_orders.find_one({"_id": pay["order_id"]})
    if not order:
        return False
    now = utc_now_iso()
    # Flip payment first (idempotency guard)
    await db.payments.update_one({"_id": pay["_id"]},
                                  {"$set": {"status": "paid", "updated_at": now}})
    return await _finalize_paid_order(db, order)


async def mark_store_order_paid_by_id(db, order_id: str) -> bool:
    """Idempotent finalize by order id (used by the real Stripe webhook)."""
    order = await db.store_orders.find_one({"_id": order_id})
    if not order:
        return False
    await db.payments.update_many(
        {"order_id": order_id, "kind": "store_order"},
        {"$set": {"status": "paid", "updated_at": utc_now_iso()}})
    return await _finalize_paid_order(db, order)


def _order_is_simulated(order) -> bool:
    """True only when the order was paid through the dev/test SimulatedProvider.
    Real provider payments (Stripe/PayPal/connected accounts) must NEVER be labelled simulated."""
    return (order.get("provider") or "simulated") in ("simulated", "", None)


async def _finalize_paid_order(db, order) -> bool:
    """Core paid handler — decrement stock, upsert buyer contact, timeline, notify.
    Guarded by order status so repeated calls are safe (no double decrement)."""
    if order.get("status") in ("paid", "fulfilled"):
        return True
    now = utc_now_iso()
    # Atomic claim: only ONE concurrent finalizer (webhook retry, manual mark-paid, poller) may
    # move the order out of its pre-paid state → no double stock decrement / double notifications.
    claimed = await db.store_orders.find_one_and_update(
        {"_id": order["_id"], "status": {"$nin": ["paid", "fulfilled", "finalizing"]}},
        {"$set": {"status": "finalizing", "updated_at": now}})
    if not claimed:
        return True
    contact_id = order.get("contact_id")
    buyer = order.get("buyer", {})
    await _attribution.emit(db, order["org_id"], "order_paid", attribution=order.get("attribution"),
                            meta={"order_id": order["_id"], "revenue_cents": int(order.get("total_cents", 0) or 0),
                                  "channel_hint": _attribution.channel_of(order.get("attribution"))})
    # Count discount usage once per PAID order (manual codes and automatic rules alike).
    if order.get("discount_code") and int(order.get("discount_cents", 0) or 0) > 0:
        await db.store_discounts.update_one({"org_id": order["org_id"], "code": order["discount_code"]},
                                            {"$inc": {"used_count": 1}})
    # Redeem an applied gift card (idempotent per order) + issue gift cards for gift_card products.
    try:
        from .gift_cards import redeem_gift_card, issue_gift_card_for_purchase
        if order.get("gift_card_code") and int(order.get("gift_card_cents", 0) or 0) > 0:
            await redeem_gift_card(db, order["org_id"], order["gift_card_code"],
                                   int(order["gift_card_cents"]), order["_id"])
        for _it in order.get("items", []):
            prod = await db.store_products.find_one({"_id": _it["product_id"], "org_id": order["org_id"]})
            if prod and prod.get("product_type") == "gift_card":
                face = int(prod.get("gift_card_amount_cents") or prod.get("price_cents", 0))
                if face > 0:
                    for _ in range(int(_it.get("qty", 1))):
                        await issue_gift_card_for_purchase(
                            db, order["org_id"], face, prod.get("currency", "USD"),
                            (order.get("buyer") or {}).get("email", ""), order["_id"])
    except Exception as e:  # noqa: BLE001
        logger.warning("gift card finalize hook failed: %s", e)
    # Activate a subscription when its first order is paid.
    try:
        if order.get("subscription_id"):
            from .subscriptions import activate_subscription_for_order
            await activate_subscription_for_order(db, order)
    except Exception as e:  # noqa: BLE001
        logger.warning("subscription activation hook failed: %s", e)
    # Decrement stock per line item — atomic $inc guarded so stock never goes negative
    for item in order.get("items", []):
        r = await db.store_products.update_one(
            {"_id": item["product_id"], "org_id": order["org_id"], "stock": {"$gte": int(item["qty"])}},
            {"$inc": {"stock": -int(item["qty"])}, "$set": {"updated_at": now}})
        if r.matched_count == 0:
            # Oversold (stock changed between checkout and payment): clamp to 0 and flag for the owner.
            await db.store_products.update_one({"_id": item["product_id"], "org_id": order["org_id"]},
                                               {"$set": {"stock": 0, "oversold_flag": True, "updated_at": now}})
            await db.store_orders.update_one({"_id": order["_id"]},
                                             {"$set": {"oversold": True}, "$push": {"oversold_notes": {
                                                 "at": now, "text": f"Oversold: {item.get('name') or item['product_id']} × {item['qty']}"}}})
    # Upsert a CRM contact for the buyer + timeline interaction
    try:
        from .crm import upsert_contact_from_form, _record_interaction
        if buyer.get("email") or buyer.get("phone"):
            fields = {"email": buyer.get("email"), "phone": buyer.get("phone"),
                       "name": buyer.get("name")}
            fields = {k: v for k, v in fields.items() if v}
            cid = await upsert_contact_from_form(db, order["org_id"], fields, source="store")
            contact_id = cid or contact_id
        _sim = _order_is_simulated(order)
        _grand = int(order.get("total_cents") or order.get("subtotal_cents") or 0)
        await _record_interaction(
            db, order["org_id"], contact_id=contact_id, type_="store_order_paid",
            summary=(f"Store order paid: {_grand/100:.2f} {order['currency']}"
                     + (" (simulated)" if _sim else f" via {order.get('provider')}")),
            ref_type="store_order", ref_id=order["_id"],
            meta={"order_id": order["_id"], "simulated": _sim, "provider": order.get("provider") or "simulated"})
    except Exception as e:  # noqa: BLE001
        logger.warning("store order CRM/timeline hook failed: %s", e)
    await db.store_orders.update_one(
        {"_id": order["_id"]},
        {"$set": {"status": "paid", "paid_at": now, "updated_at": now, "contact_id": contact_id},
         "$push": {"status_history": {"status": "paid", "at": now, "actor": "payment", "note": ""}}})
    try:
        from ..services import commerce_ext as _cx
        await _cx.settle_reservation(db, order["_id"], "consumed")
    except Exception as e:  # noqa: BLE001
        logger.warning("reservation settle failed: %s", e)
    try:
        from .marketing import fire_trigger as _fire
        await _fire(order["org_id"], "order_paid", {"contact_id": contact_id, "email": buyer.get("email"),
                                                    "name": buyer.get("name"), "order_id": order["_id"],
                                                    "total_cents": order.get("total_cents")})
    except Exception as e:  # noqa: BLE001
        logger.warning("order_paid trigger failed: %s", e)
    # Last-touch marketing attribution: credit revenue to a campaign the buyer clicked.
    try:
        from ..services.campaign_tracking import attribute_conversion
        if buyer.get("email"):
            await attribute_conversion(db, org_id=order["org_id"], email=buyer["email"],
                                        amount_cents=int(order.get("subtotal_cents") or 0))
    except Exception as e:  # noqa: BLE001
        logger.warning("campaign attribution failed: %s", e)
    # Notifications (buyer confirmation + owner alert)
    try:
        await _notify_order_paid(db, order, buyer, contact_id)
    except Exception as e:  # noqa: BLE001
        logger.warning("store order notification failed: %s", e)
    return True


async def _notify_order_paid(db, order, buyer, contact_id) -> None:
    from ..models_crm import EmailProviderConfig
    from ..services.email_providers import SendPayload, build_provider_from_config
    cfg_doc = await db.email_provider_configs.find_one({"org_id": order["org_id"]})
    cfg = EmailProviderConfig.from_mongo(cfg_doc) if cfg_doc else EmailProviderConfig(org_id=order["org_id"])
    provider = build_provider_from_config(cfg)
    org = await _get_org(db, order["org_id"])
    store_name = (org or {}).get("name", "our store")
    lines = "\n".join(f" - {it['name']} x{it['qty']} ({it['price_cents']/100:.2f})"
                       for it in order.get("items", []))
    # Receipts MUST show the grand total (subtotal - discount - gift card + shipping + tax), never the subtotal.
    _grand_cents = int(order.get("total_cents") if order.get("total_cents") is not None else order.get("subtotal_cents", 0))
    total = f"{_grand_cents/100:.2f} {order['currency']}"
    _breakdown = []
    if int(order.get("discount_cents", 0) or 0):
        _breakdown.append(f"Discount: -{int(order['discount_cents'])/100:.2f}")
    if int(order.get("gift_card_cents", 0) or 0):
        _breakdown.append(f"Gift card: -{int(order['gift_card_cents'])/100:.2f}")
    if int(order.get("shipping_cents", 0) or 0):
        _breakdown.append(f"Shipping: {int(order['shipping_cents'])/100:.2f}")
    if int(order.get("tax_cents", 0) or 0):
        _breakdown.append(f"Tax: {int(order['tax_cents'])/100:.2f}")
    breakdown = ("\n" + "\n".join(_breakdown) + "\n") if _breakdown else ""
    _sim_note = "This is a simulated (test-mode) payment confirmation.\n" if _order_is_simulated(order) else ""
    from_email = cfg.from_email or "notifications@zanelvo.local"
    from_name = cfg.from_name or store_name
    # Buyer confirmation
    if buyer.get("email"):
        buyer_payload = SendPayload(
            from_email=from_email, from_name=from_name, to=[buyer["email"]],
            subject=f"Order confirmed — {store_name}",
            text=(f"Thanks {buyer.get('name') or 'there'}! Your order is confirmed.\n\n"
                   f"{lines}\n{breakdown}\nTotal: {total}\nOrder ref: {order['_id'][:8]}\n\n"
                   f"{_sim_note}"))
        res = await provider.send(buyer_payload)
        try:
            from .crm import _record_interaction
            await _record_interaction(
                db, order["org_id"], contact_id=contact_id, type_="store_order_confirmation_sent",
                summary=f"Order confirmation {'delivered (simulated)' if res.simulated else 'sent'} to {buyer['email']}",
                ref_type="store_order", ref_id=order["_id"],
                meta={"simulated": res.simulated, "provider": provider.key})
        except Exception:  # noqa: BLE001
            pass
    # Owner notification
    owner = await db.users.find_one({"org_id": order["org_id"], "role": "owner"})
    owner_email = (owner or {}).get("email")
    if owner_email:
        owner_payload = SendPayload(
            from_email=from_email, from_name=from_name, to=[owner_email],
            subject=f"New paid order — {total}",
            text=(f"You received a new order.\n\n{lines}\n\nTotal: {total}\n"
                   f"Buyer: {buyer.get('name')} <{buyer.get('email')}> {buyer.get('phone') or ''}\n"
                   f"Ship to: {buyer.get('address') or '(not provided)'}\n"
                   f"Order ref: {order['_id'][:8]}\n"))
        await provider.send(owner_payload)


async def _notify_order_refunded(db, order, buyer, contact_id, reason: str = "") -> None:
    from ..models_crm import EmailProviderConfig
    from ..services.email_providers import SendPayload, build_provider_from_config
    cfg_doc = await db.email_provider_configs.find_one({"org_id": order["org_id"]})
    cfg = EmailProviderConfig.from_mongo(cfg_doc) if cfg_doc else EmailProviderConfig(org_id=order["org_id"])
    provider = build_provider_from_config(cfg)
    org = await _get_org(db, order["org_id"])
    store_name = (org or {}).get("name", "our store")
    total = f"{order['subtotal_cents']/100:.2f} {order.get('currency','USD')}"
    from_email = cfg.from_email or "notifications@zanelvo.local"
    from_name = cfg.from_name or store_name
    if buyer.get("email"):
        body = (f"Hi {buyer.get('name') or 'there'},\n\n"
                f"Your order (ref {order['_id'][:8]}) has been refunded for {total}.\n")
        if reason:
            body += f"Reason: {reason}\n"
        body += "\nRefunds may take a few business days to appear on your statement.\n"
        res = await provider.send(SendPayload(
            from_email=from_email, from_name=from_name, to=[buyer["email"]],
            subject=f"Refund processed — {store_name}", text=body))
        try:
            from .crm import _record_interaction
            await _record_interaction(
                db, order["org_id"], contact_id=contact_id, type_="store_order_refund_email_sent",
                summary=f"Refund email {'delivered (simulated)' if res.simulated else 'sent'} to {buyer['email']}",
                ref_type="store_order", ref_id=order["_id"],
                meta={"simulated": res.simulated, "provider": provider.key})
        except Exception:  # noqa: BLE001
            pass

def _is_oid(s: str) -> bool:
    return len(s) == 24 and all(c in "0123456789abcdef" for c in s.lower())


def _shopper_id_from_token(token: str, org_id: str) -> Optional[str]:
    """Return the shop_customer id if a valid shopper JWT bound to this org is supplied, else None."""
    if not token:
        return None
    try:
        import jwt as _jwt
        from .. import config as _cfg
        payload = _jwt.decode(token, _cfg.JWT_SECRET, algorithms=[_cfg.JWT_ALG])
    except Exception:  # noqa: BLE001
        return None
    if payload.get("role") != "shopper" or not payload.get("shop"):
        return None
    if payload.get("org_id") != org_id:
        return None
    return payload.get("sub")


async def _get_org(db, org_id: str):
    """Fetch an organization doc by its id string (ObjectId-backed) safely."""
    if _is_oid(org_id):
        from bson import ObjectId
        org = await db.organizations.find_one({"_id": ObjectId(org_id)})
        if org:
            return org
    return await db.organizations.find_one({"_id": org_id})
