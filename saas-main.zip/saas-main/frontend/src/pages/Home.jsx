import usePageMeta from "@/hooks/usePageMeta";
import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import PublicNav from "@/components/PublicNav";
import { useBrand } from "@/context/BrandContext";
import { Button } from "@/components/ui/button";
import {
    ArrowRight, Sparkles, Globe2, Users, Calendar, CreditCard, Bot, Megaphone,
    Inbox, Star, Check, Store, PlayCircle, TrendingUp, Zap, MessageSquare, Phone,
} from "lucide-react";

const SLIDES = [
    { img: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODF8MHwxfHNlYXJjaHwzfHxTYWFTJTIwZGFzaGJvYXJkfGVufDB8fHx8MTc4ODYyNjczNHww&ixlib=rb-4.1.0&q=85", title: "Your dashboard", caption: "Bookings, revenue and AI activity — at a glance." },
    { img: "https://images.unsplash.com/photo-1686061594225-3e92c0cd51b0?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzZ8MHwxfHNlYXJjaHw0fHxhbmFseXRpY3MlMjBVSXxlbnwwfHx8fDE3ODg2MjY3MzR8MA&ixlib=rb-4.1.0&q=85", title: "Insights that matter", caption: "See what's converting — and what to fix next." },
    { img: "https://images.unsplash.com/photo-1526628953301-3e589a6a8b74?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODF8MHwxfHNlYXJjaHwyfHxTYWFTJTIwZGFzaGJvYXJkfGVufDB8fHx8MTc4ODYyNjczNHww&ixlib=rb-4.1.0&q=85", title: "Everything, live", caption: "Inbox, calendar and store update in real time." },
    { img: "https://images.unsplash.com/photo-1637502875124-eb4a9843a2fa?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzZ8MHwxfHNlYXJjaHw0fHx3ZWJzaXRlJTIwbW9ja3VwfGVufDB8fHx8MTc4ODYyNjc0N3ww&ixlib=rb-4.1.0&q=85", title: "A site that sells", caption: "Beautiful on every device, out of the box." },
];

const FEATURES = [
    { icon: Globe2, title: "AI website + hosting", body: "A multi-page site tailored to your trade — copy, structure and images, all editable.", span: true },
    { icon: Store, title: "Online store", body: "List products, take orders, watch stock update the second you're paid." },
    { icon: Bot, title: "AI employees", body: "A receptionist that answers, books and follows up — 24/7." },
    { icon: Users, title: "CRM & contacts", body: "Every lead and conversation in one tidy place." },
    { icon: Calendar, title: "Online booking", body: "Customers book real slots against live availability." },
    { icon: CreditCard, title: "Quotes, invoices & payments", body: "Send a quote, convert to invoice, get paid — no back-and-forth.", span: true },
    { icon: Inbox, title: "Shared inbox", body: "Website messages and email in one shared workspace." },
    { icon: Megaphone, title: "Marketing studio", body: "Campaigns, automations and visuals that bring people back." },
];

const STEPS = [
    { n: "01", icon: MessageSquare, title: "Tell us about your business", body: "A short, friendly interview — pick from options, no essays required." },
    { n: "02", icon: Sparkles, title: "We build your site", body: "A real, tailored website appears with your services, prices and hours." },
    { n: "03", icon: Zap, title: "Turn on the rest", body: "Booking, store, payments, inbox and AI switch on whenever you're ready." },
];

const TRUST = ["Salons", "Home services", "Coaches", "Clinics", "Studios", "Contractors", "Retailers", "Agencies"];

const SCENARIOS = [
    { q: "A salon replaces its website, booking app and invoicing tool with one login and one bill.", a: "Salon or studio", r: "Bookings · payments · reminders", i: "SA", c: "from-indigo-500 to-violet-600", metric: "3 tools → 1" },
    { q: "A plumber's AI receptionist answers enquiries while they're on a job and offers the next free slot.", a: "Trades & home services", r: "AI receptionist · quotes · jobs", i: "TR", c: "from-brand-copper to-indigo-700", metric: "Never miss a lead" },
    { q: "A coach launches a polished site, takes card payments and sends invoices — all in an afternoon.", a: "Coaches & consultants", r: "Website · store · invoices", i: "CO", c: "from-violet-500 to-indigo-600", metric: "Live in a day" },
];

const FAQS = [
    { q: "Do I need any technical skills?", a: "No. You answer a few questions and everything is generated for you — then you tweak with simple click-to-edit tools." },
    { q: "Do I have to connect my own API keys?", a: "No. The tools you need are provided out of the box — payments, AI and email all work on day one. You only ever set up things that are uniquely yours, like your own domain." },
    { q: "Can I sell products online?", a: "Yes. Add products, share your storefront, and orders + stock are tracked automatically when a customer pays." },
    { q: "Can I use my own domain?", a: "Yes. Paid plans connect your custom domain with automatic SSL." },
    { q: "Can I cancel anytime?", a: "Yes. Plans are month-to-month, and annual billing simply saves you money." },
];

// Adds `.is-visible` to any `.reveal` element as it scrolls into view.
function useScrollReveal() {
    useEffect(() => {
        const els = Array.from(document.querySelectorAll(".reveal"));
        if (!("IntersectionObserver" in window) || !els.length) {
            els.forEach((el) => el.classList.add("is-visible"));
            return;
        }
        const io = new IntersectionObserver((entries) => {
            entries.forEach((e) => {
                if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); }
            });
        }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
        els.forEach((el) => io.observe(el));
        return () => io.disconnect();
    }, []);
}

// Bespoke, rendered product mockup — interactive, reads like the real app.
function RotatingWord({ words, className = "" }) {
    const [i, setI] = useState(0);
    const [show, setShow] = useState(true);
    useEffect(() => {
        const id = setInterval(() => {
            setShow(false);
            setTimeout(() => { setI((p) => (p + 1) % words.length); setShow(true); }, 280);
        }, 2600);
        return () => clearInterval(id);
    }, [words.length]);
    return (
        <span className={`inline-block transition-all duration-300 ${show ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"} ${className}`}>
            {words[i]}
        </span>
    );
}

// Animated count-up that runs once when scrolled into view.
function CountUp({ to, prefix = "", suffix = "", decimals = 0, duration = 1400, className = "" }) {
    const ref = useRef(null);
    const [val, setVal] = useState(0);
    const done = useRef(false);
    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const io = new IntersectionObserver((entries) => {
            entries.forEach((e) => {
                if (e.isIntersecting && !done.current) {
                    done.current = true;
                    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                    if (reduce) { setVal(to); return; }
                    const start = performance.now();
                    const tick = (now) => {
                        const p = Math.min(1, (now - start) / duration);
                        const eased = 1 - Math.pow(1 - p, 3);
                        setVal(to * eased);
                        if (p < 1) requestAnimationFrame(tick);
                        else setVal(to);
                    };
                    requestAnimationFrame(tick);
                }
            });
        }, { threshold: 0.4 });
        io.observe(el);
        return () => io.disconnect();
    }, [to, duration]);
    const shown = decimals ? val.toFixed(decimals) : Math.round(val).toLocaleString();
    return <span ref={ref} className={className}>{prefix}{shown}{suffix}</span>;
}

const METRICS = [
    { to: 9, suffix: "-in-1", label: "Tools replaced by one login", sub: "Website · store · CRM · booking · AI" },
    { to: 60, prefix: "<", suffix: "s", label: "To your first live website", sub: "From a short, friendly interview" },
    { to: 24, suffix: "/7", label: "AI that answers & books", sub: "Never miss a call or message" },
    { to: 0, label: "Plugins, code or API hunts", sub: "Everything is built in and ready" },
];

// Auto-rotating "what's happening" slider — same card look, dynamic content.
const ACTIVITY_SCENES = [
    [
        { icon: CreditCard, tint: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20", t: "Payment received", s: "Invoice #1042 · $240.00", tag: "Paid", tagCls: "text-emerald-400" },
        { icon: Calendar, tint: "text-brand-copper", bg: "bg-white/[0.04] border-white/10", t: "New booking · Thursday 2:30pm", s: "Kitchen tap fit · booked by AI", tag: "AI", tagCls: "bg-white/10 text-white/60 px-1.5 py-0.5 rounded text-[10px]" },
        { icon: MessageSquare, tint: "text-sky-400", bg: "bg-white/[0.04] border-white/10", t: "\u201cCan you come out this week?\u201d", s: "Replied & quoted in 18 seconds" },
    ],
    [
        { icon: Store, tint: "text-fuchsia-400", bg: "bg-fuchsia-500/10 border-fuchsia-500/20", t: "Order paid · #2087", s: "2 items · $58.00 · shipping label ready", tag: "New", tagCls: "text-fuchsia-300" },
        { icon: Star, tint: "text-amber-400", bg: "bg-white/[0.04] border-white/10", t: "New 5-star review", s: "\u201cFast, friendly, spotless work.\u201d", tag: "5.0", tagCls: "bg-white/10 text-white/60 px-1.5 py-0.5 rounded text-[10px]" },
        { icon: Users, tint: "text-indigo-400", bg: "bg-white/[0.04] border-white/10", t: "New lead captured", s: "Marcus R. · from your website form" },
    ],
    [
        { icon: Inbox, tint: "text-sky-400", bg: "bg-sky-500/10 border-sky-500/20", t: "Campaign sent · 412 contacts", s: "38% opened · 6 rebookings so far", tag: "Live", tagCls: "text-sky-300" },
        { icon: Bot, tint: "text-emerald-400", bg: "bg-white/[0.04] border-white/10", t: "AI answered 3 calls overnight", s: "2 booked, 1 message taken", tag: "24/7", tagCls: "bg-white/10 text-white/60 px-1.5 py-0.5 rounded text-[10px]" },
        { icon: CreditCard, tint: "text-emerald-400", bg: "bg-white/[0.04] border-white/10", t: "Quote accepted · $1,850", s: "Auto-converted to invoice" },
    ],
];

function ActivitySlider() {
    const [i, setI] = useState(0);
    useEffect(() => {
        const id = setInterval(() => setI((p) => (p + 1) % ACTIVITY_SCENES.length), 3200);
        return () => clearInterval(id);
    }, []);
    const scene = ACTIVITY_SCENES[i];
    return (
        <div>
            <div key={i} className="p-4 space-y-3 activity-fade">
                {scene.map((r, k) => (
                    <div key={k} className={`flex items-center gap-3 rounded-xl border p-3 ${r.bg}`}>
                        <div className={`w-9 h-9 rounded-lg bg-white/10 ${r.tint} flex items-center justify-center shrink-0`}><r.icon className="w-4 h-4" /></div>
                        <div className="flex-1 min-w-0"><div className="text-white text-sm font-medium truncate">{r.t}</div><div className="text-white/40 text-xs truncate">{r.s}</div></div>
                        {r.tag && <span className={`text-xs font-medium shrink-0 ${r.tagCls}`}>{r.tag}</span>}
                    </div>
                ))}
            </div>
            <div className="flex items-center justify-center gap-1.5 pb-3">
                {ACTIVITY_SCENES.map((_, idx) => (
                    <button key={idx} aria-label={`Scene ${idx + 1}`} onClick={() => setI(idx)}
                        className={`h-1.5 rounded-full transition-all ${idx === i ? "w-6 bg-brand-copper" : "w-1.5 bg-white/25"}`} />
                ))}
            </div>
        </div>
    );
}

const MOCK_NAV = [
    { id: "home", icon: Globe2, label: "Overview" },
    { id: "store", icon: Store, label: "Store" },
    { id: "crm", icon: Users, label: "Contacts" },
    { id: "inbox", icon: Inbox, label: "Inbox" },
    { id: "calendar", icon: Calendar, label: "Calendar" },
    { id: "ai", icon: Bot, label: "AI & calls" },
];

function MockShell({ children, title }) {
    return (
        <div className="p-5 min-h-[340px]">
            <div className="flex items-center justify-between">
                <div className="text-white font-display text-lg leading-tight">{title}</div>
                <div className="text-[11px] px-2 py-1 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Live</div>
            </div>
            <div className="mt-4">{children}</div>
        </div>
    );
}

function DashboardMock() {
    const [view, setView] = useState("home");
    const bars = [42, 68, 55, 80, 62, 95, 74];

    const views = {
        home: (
            <MockShell title="Here's your day">
                <div className="grid grid-cols-3 gap-2.5">
                    {[{ l: "Revenue", v: "$4,820" }, { l: "Bookings", v: "37" }, { l: "Orders", v: "12" }].map((k) => (
                        <div key={k.l} className="rounded-xl bg-white/[0.04] border border-white/10 p-3">
                            <div className="text-white/40 text-[10px] uppercase tracking-wide">{k.l}</div>
                            <div className="text-white font-display text-lg mt-0.5">{k.v}</div>
                        </div>
                    ))}
                </div>
                <div className="mt-4 rounded-xl bg-white/[0.04] border border-white/10 p-3">
                    <div className="flex items-center justify-between mb-3">
                        <div className="text-white/50 text-[11px]">This week</div>
                        <div className="text-white/30 text-[10px]">Mon–Sun</div>
                    </div>
                    <div className="flex items-end gap-1.5 h-20">
                        {bars.map((h, i) => (
                            <div key={i} className="flex-1 rounded-t-md bg-gradient-to-t from-brand-copper/40 to-brand-copper mock-bar" style={{ height: `${h}%`, animationDelay: `${i * 90}ms` }} />
                        ))}
                    </div>
                </div>
            </MockShell>
        ),
        store: (
            <MockShell title="Store · Orders">
                <div className="space-y-2">
                    {[{ n: "Ceramic mug set", s: "2 items · $39.98", t: "Paid" }, { n: "Gift card $50", s: "1 item · $50.00", t: "Paid" }, { n: "Candle — Amber", s: "3 items · $27.00", t: "Packing" }].map((o) => (
                        <div key={o.n} className="flex items-center gap-3 rounded-xl bg-white/[0.04] border border-white/10 p-2.5">
                            <div className="w-9 h-9 rounded-lg bg-brand-copper/15 text-brand-copper flex items-center justify-center shrink-0"><Store className="w-4 h-4" /></div>
                            <div className="min-w-0 flex-1"><div className="text-white text-[12px] font-medium truncate">{o.n}</div><div className="text-white/40 text-[11px]">{o.s}</div></div>
                            <div className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 shrink-0">{o.t}</div>
                        </div>
                    ))}
                </div>
            </MockShell>
        ),
        crm: (
            <MockShell title="Contacts">
                <div className="space-y-2">
                    {[{ n: "Sarah Doyle", s: "Lead · Kitchen remodel", c: "SD" }, { n: "Marcus Reed", s: "Customer · 3 jobs", c: "MR" }, { n: "Priya Nair", s: "Quote sent · $2,400", c: "PN" }].map((p) => (
                        <div key={p.n} className="flex items-center gap-3 rounded-xl bg-white/[0.04] border border-white/10 p-2.5">
                            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-fuchsia-500 text-white text-[11px] font-semibold flex items-center justify-center shrink-0">{p.c}</div>
                            <div className="min-w-0 flex-1"><div className="text-white text-[12px] font-medium truncate">{p.n}</div><div className="text-white/40 text-[11px] truncate">{p.s}</div></div>
                        </div>
                    ))}
                </div>
            </MockShell>
        ),
        inbox: (
            <MockShell title="Shared inbox">
                <div className="space-y-2">
                    {[{ n: "Can you come Thursday?", s: "Website chat · replied by AI", tag: "AI" }, { n: "Invoice question", s: "email · sarah@…", tag: "New" }, { n: "Booking confirmed", s: "2:30pm · Kitchen tap", tag: "✓" }].map((m) => (
                        <div key={m.n} className="flex items-center gap-3 rounded-xl bg-white/[0.04] border border-white/10 p-2.5">
                            <div className="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-400 flex items-center justify-center shrink-0"><MessageSquare className="w-4 h-4" /></div>
                            <div className="min-w-0 flex-1"><div className="text-white text-[12px] font-medium truncate">{m.n}</div><div className="text-white/40 text-[11px] truncate">{m.s}</div></div>
                            <div className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-white/60 shrink-0">{m.tag}</div>
                        </div>
                    ))}
                </div>
            </MockShell>
        ),
        calendar: (
            <MockShell title="Calendar · Today">
                <div className="space-y-2">
                    {[{ t: "9:00", n: "Boiler service", c: "bg-brand-copper" }, { t: "11:30", n: "Quote visit — Reed", c: "bg-indigo-500" }, { t: "2:30", n: "Kitchen tap fit", c: "bg-emerald-500" }, { t: "4:00", n: "Follow-up call", c: "bg-fuchsia-500" }].map((s) => (
                        <div key={s.t} className="flex items-center gap-3 rounded-xl bg-white/[0.04] border border-white/10 p-2.5">
                            <div className="text-white/50 text-[11px] w-10 shrink-0">{s.t}</div>
                            <div className={`w-1.5 h-8 rounded-full ${s.c}`} />
                            <div className="text-white text-[12px] font-medium">{s.n}</div>
                        </div>
                    ))}
                </div>
            </MockShell>
        ),
        ai: (
            <MockShell title="AI receptionist">
                <div className="rounded-xl bg-white/[0.04] border border-white/10 p-3 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center"><Phone className="w-4 h-4" /></div>
                    <div className="flex-1"><div className="text-white text-[12px] font-medium">+1 (415) 555‑0132</div><div className="text-white/40 text-[11px]">Answering 24/7 · English & Spanish</div></div>
                    <div className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400">On</div>
                </div>
                <div className="mt-2 space-y-2">
                    {[{ r: "AI", t: "Thanks for calling! How can I help?", me: false }, { r: "Caller", t: "Do you have a slot Thursday?", me: true }, { r: "AI", t: "Yes — 2:30pm works. Booked you in!", me: false }].map((b, i) => (
                        <div key={i} className={`max-w-[80%] rounded-xl px-3 py-2 text-[12px] ${b.me ? "ml-auto bg-brand-copper text-white" : "bg-white/[0.06] text-white/80 border border-white/10"}`}>{b.t}</div>
                    ))}
                </div>
            </MockShell>
        ),
    };

    return (
        <div className="relative mock-light">
            <div className="rounded-2xl bg-[#0d0d12] ring-1 ring-white/10 shadow-2xl shadow-black/50 overflow-hidden">
                {/* window chrome */}
                <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
                    <span className="w-3 h-3 rounded-full bg-red-400/80" />
                    <span className="w-3 h-3 rounded-full bg-amber-400/80" />
                    <span className="w-3 h-3 rounded-full bg-emerald-400/80" />
                    <div className="ml-3 h-6 flex-1 max-w-[220px] rounded-md bg-white/5 border border-white/10 flex items-center px-2 text-[11px] text-white/40">zanelvo.com/app</div>
                </div>
                <div className="flex">
                    {/* interactive mini sidebar */}
                    <div className="hidden sm:flex flex-col gap-2 items-center py-4 px-2.5 border-r border-white/10 bg-white/[0.02]">
                        {MOCK_NAV.map((it) => {
                            const Ic = it.icon;
                            const active = view === it.id;
                            return (
                                <button key={it.id} onClick={() => setView(it.id)} title={it.label} aria-label={it.label}
                                    className={`group relative w-9 h-9 rounded-lg flex items-center justify-center transition-all ${active ? "bg-brand-copper text-white shadow-lg shadow-brand-copper/30" : "text-white/40 hover:text-white hover:bg-white/10"}`}>
                                    <Ic className="w-4 h-4" />
                                    <span className="pointer-events-none absolute left-11 z-10 whitespace-nowrap rounded-md bg-black/80 px-2 py-1 text-[10px] text-white opacity-0 group-hover:opacity-100 transition">{it.label}</span>
                                </button>
                            );
                        })}
                    </div>
                    {/* main — switches with the sidebar (demo) */}
                    <div className="flex-1 transition-all duration-300">
                        {views[view]}
                    </div>
                </div>
            </div>
            {/* floating accents */}
            <div className="absolute -bottom-5 -left-5 hidden md:flex items-center gap-2 rounded-xl border border-white/10 bg-[#111119] px-4 py-3 shadow-xl float-y">
                <div className="w-8 h-8 rounded-lg bg-brand-copper/20 flex items-center justify-center text-brand-copper"><Zap className="w-4 h-4" /></div>
                <div className="text-xs"><div className="font-medium text-white">Site published</div><div className="text-white/40">live in 47 seconds</div></div>
            </div>
        </div>
    );
}

// Fast, bespoke rendered panels — no external images to wait on.
function SlidePanel({ idx }) {
    if (idx === 0) return (
        <div className="w-full h-full bg-gradient-to-br from-brand-ink to-[#1a1830] p-6 flex flex-col justify-center gap-3">
            <div className="grid grid-cols-3 gap-3">
                {[["Revenue", "$4,820"], ["Bookings", "37"], ["Orders", "12"]].map(([l, v]) => (
                    <div key={l} className="rounded-xl bg-white/10 border border-white/10 p-3"><div className="text-white/40 text-[10px] uppercase">{l}</div><div className="text-white font-display text-xl">{v}</div></div>
                ))}
            </div>
            <div className="rounded-xl bg-white/10 border border-white/10 p-3 flex items-end gap-1.5 h-24">
                {[45, 70, 55, 85, 60, 95, 78].map((h, i) => <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-brand-copper/50 to-brand-copper" style={{ height: `${h}%` }} />)}
            </div>
        </div>
    );
    if (idx === 1) return (
        <div className="w-full h-full bg-gradient-to-br from-[#141225] to-[#241a33] p-6 flex flex-col justify-center gap-3">
            {[["Conversion", "6.4%", "up"], ["Avg. order", "$186", "up"], ["Response time", "18s", "down"]].map(([l, v, d]) => (
                <div key={l} className="flex items-center gap-3 rounded-xl bg-white/10 border border-white/10 p-3">
                    <div className="flex-1"><div className="text-white/50 text-[11px]">{l}</div><div className="text-white font-display text-lg">{v}</div></div>
                    <div className={`text-[11px] px-2 py-1 rounded-full ${d === "up" ? "bg-emerald-500/20 text-emerald-300" : "bg-sky-500/20 text-sky-300"}`}>{d === "up" ? "▲" : "▼"} good</div>
                </div>
            ))}
        </div>
    );
    if (idx === 2) return (
        <div className="w-full h-full bg-gradient-to-br from-[#101a1a] to-[#1a2440] p-6 flex flex-col justify-center gap-2.5">
            {[["Inbox", "New enquiry — Thursday?", "AI"], ["Calendar", "2:30pm · Kitchen tap fit", "Booked"], ["Store", "Order #1042 · $240", "Paid"]].map(([a, t, tag]) => (
                <div key={a} className="flex items-center gap-3 rounded-xl bg-white/10 border border-white/10 p-3">
                    <div className="w-9 h-9 rounded-lg bg-brand-copper/25 text-brand-copper flex items-center justify-center text-[10px] font-bold">{a[0]}</div>
                    <div className="flex-1 min-w-0"><div className="text-white text-[12px] font-medium truncate">{t}</div><div className="text-white/40 text-[11px]">{a}</div></div>
                    <div className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">{tag}</div>
                </div>
            ))}
        </div>
    );
    return (
        <div className="w-full h-full bg-gradient-to-br from-[#1a1430] to-[#301a2a] p-6 flex items-center justify-center">
            <div className="w-full max-w-sm rounded-xl bg-white/10 border border-white/10 overflow-hidden shadow-2xl">
                <div className="flex items-center justify-between px-3 py-2 bg-white/[0.06] border-b border-white/10">
                    <span className="text-white font-display text-sm">Bloom & Petal</span>
                    <span className="flex gap-3 text-white/50 text-[10px]">Shop · Book · About</span>
                </div>
                <div className="h-20 bg-gradient-to-r from-brand-copper via-fuchsia-500 to-amber-400 flex items-center px-4">
                    <div><div className="text-white font-display text-sm leading-tight">Fresh flowers,<br/>delivered same day</div></div>
                </div>
                <div className="p-3 grid grid-cols-3 gap-2">
                    {["$28", "$45", "$60"].map((p, k) => (
                        <div key={k} className="rounded-lg bg-white/[0.08] border border-white/10 overflow-hidden">
                            <div className={`h-10 bg-gradient-to-br ${["from-rose-400 to-pink-500", "from-amber-300 to-orange-400", "from-emerald-300 to-teal-400"][k]}`} />
                            <div className="px-1.5 py-1 text-[9px] text-white/70 flex items-center justify-between">Bouquet <span className="text-white font-medium">{p}</span></div>
                        </div>
                    ))}
                </div>
                <div className="px-3 pb-3"><div className="h-7 rounded-lg bg-brand-copper text-white text-[10px] flex items-center justify-center font-medium">Book a consultation →</div></div>
            </div>
        </div>
    );
}

function Showcase() {
    const [i, setI] = useState(0);
    const timer = useRef(null);
    useEffect(() => {
        timer.current = setInterval(() => setI((p) => (p + 1) % SLIDES.length), 3800);
        return () => clearInterval(timer.current);
    }, []);
    return (
        <div className="reveal">
            <div className="relative rounded-2xl border border-brand-line bg-white shadow-2xl shadow-black/5 overflow-hidden">
                <div className="flex items-center gap-1.5 px-4 py-3 border-b border-brand-line bg-brand-cream/60">
                    <span className="w-3 h-3 rounded-full bg-red-400/70" />
                    <span className="w-3 h-3 rounded-full bg-amber-400/70" />
                    <span className="w-3 h-3 rounded-full bg-emerald-400/70" />
                    <div className="ml-3 h-5 flex-1 max-w-xs rounded bg-white border border-brand-line" />
                </div>
                <div className="relative aspect-[16/9]">
                    {SLIDES.map((s, idx) => (
                        <div key={idx} className={`slide-item ${idx === i ? "slide-active" : ""}`}>
                            <SlidePanel idx={idx} />
                            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 to-transparent p-5">
                                <div className="text-white font-display text-lg">{s.title}</div>
                                <div className="text-white/80 text-sm">{s.caption}</div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <div className="flex items-center justify-center gap-2 mt-4">
                {SLIDES.map((_, idx) => (
                    <button key={idx} aria-label={`Slide ${idx + 1}`} onClick={() => setI(idx)}
                        className={`h-1.5 rounded-full transition-all duration-300 ${idx === i ? "w-8 bg-brand-copper" : "w-2.5 bg-brand-line"}`} />
                ))}
            </div>
        </div>
    );
}

function Section({ children, className = "" }) {
    return <section className={className}>{children}</section>;
}

export default function Home() {
    usePageMeta("AI website builder, store, bookings & CRM");
    const brand = useBrand();
    const name = brand?.name || "Our platform";
    useScrollReveal();

    return (
        <div className="min-h-screen bg-brand-surface text-brand-ink">
            <PublicNav />

            {/* ================= HERO (dark, bespoke) ================= */}
            <Section className="relative overflow-hidden bg-brand-cream text-brand-ink dark:bg-brand-ink dark:text-white">
                {/* layered background */}
                <div className="pointer-events-none absolute inset-0 hero-grid opacity-[0.06] dark:opacity-[0.18]" />
                <div className="pointer-events-none absolute -top-40 -right-32 w-[42rem] h-[42rem] rounded-full bg-brand-copper/15 dark:bg-brand-copper/25 blur-[120px] mesh-orb" />
                <div className="pointer-events-none absolute -bottom-56 -left-40 w-[38rem] h-[38rem] rounded-full bg-violet-500/10 dark:bg-violet-500/15 blur-[120px] mesh-orb-slow" />
                <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-brand-surface" />

                <div className="relative mx-auto max-w-6xl px-6 pt-16 md:pt-24 pb-28 grid lg:grid-cols-[1.05fr_1fr] gap-14 items-center">
                    <div>
                        <div className="inline-flex items-center gap-2 rounded-full border border-brand-line bg-white text-zinc-600 dark:border-white/15 dark:bg-white/5 dark:text-white/70 backdrop-blur px-3 py-1 text-xs mb-6 animate-in-up" data-testid="home-badge">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            The all-in-one platform for service &amp; online businesses
                        </div>
                        <h1 className="font-display text-5xl md:text-[4.2rem] font-medium tracking-tight leading-[1.02] animate-in-up" style={{ animationDelay: "60ms" }} data-testid="home-hero-headline">
                            Build a business that{" "}
                            <RotatingWord
                                words={["books work.", "sells online.", "answers calls.", "runs itself."]}
                                className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-violet-600 to-indigo-500 dark:from-indigo-200 dark:via-violet-200 dark:to-indigo-300 headline-sheen"
                            />
                        </h1>
                        <p className="mt-6 text-lg text-zinc-600 dark:text-white/70 max-w-xl animate-in-up" style={{ animationDelay: "120ms" }} data-testid="home-hero-sub">
                            {name} interviews you like a great agency would, then builds a real, tailored website — with a store, CRM, booking, payments and AI employees wired in. No code. No plugins. No API keys to hunt down.
                        </p>
                        <div className="mt-9 flex flex-col sm:flex-row gap-3 animate-in-up" style={{ animationDelay: "180ms" }}>
                            <Link to="/signup" data-testid="home-primary-cta">
                                <Button size="lg" className="bg-brand-copper hover:bg-brand-copperHover text-white cta-sheen w-full sm:w-auto transition-transform hover:-translate-y-0.5 shadow-lg shadow-brand-copper/25">
                                    {brand?.cta_label || "Build my website"} <ArrowRight className="ml-2 w-4 h-4" />
                                </Button>
                            </Link>
                            <Link to="/pricing" data-testid="home-secondary-cta">
                                <Button size="lg" variant="outline" className="border-brand-line bg-white text-brand-ink hover:bg-zinc-50 hover:text-brand-ink dark:border-white/20 dark:bg-white/5 dark:text-white dark:hover:bg-white/10 dark:hover:text-white w-full sm:w-auto transition-transform hover:-translate-y-0.5">See pricing &amp; plans</Button>
                            </Link>
                        </div>
                        <div className="mt-5 text-sm text-zinc-500 dark:text-white/50 animate-in-up" style={{ animationDelay: "240ms" }} data-testid="home-hero-note">
                            No credit card · Real AI · Cancel anytime
                        </div>
                    </div>
                    <div className="relative animate-in-up" style={{ animationDelay: "160ms" }}>
                        <DashboardMock />
                    </div>
                </div>

                {/* Animated metrics band */}
                <div className="relative mx-auto max-w-6xl px-6 pb-16">
                    <div className="grid grid-cols-2 md:grid-cols-4 rounded-2xl border border-brand-line bg-white dark:border-white/10 dark:bg-white/[0.03] backdrop-blur divide-y divide-brand-line dark:divide-white/10 md:divide-y-0 md:divide-x md:divide-brand-line md:dark:divide-white/10 overflow-hidden">
                        {METRICS.map((m) => (
                            <div key={m.label} className="text-center px-4 py-7 reveal hover:bg-black/[0.02] dark:hover:bg-white/[0.03] transition-colors">
                                <div className="font-display text-4xl md:text-5xl bg-clip-text text-transparent bg-gradient-to-b from-brand-ink to-brand-ink/60 dark:from-white dark:to-white/55">
                                    <CountUp to={m.to} prefix={m.prefix || ""} suffix={m.suffix || ""} />
                                </div>
                                <div className="text-sm text-zinc-600 dark:text-white/70 mt-2 font-medium">{m.label}</div>
                                <div className="text-xs text-zinc-400 dark:text-white/35 mt-1 leading-snug">{m.sub}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </Section>

            {/* Trust marquee */}
            <div className="py-12 overflow-hidden marquee-mask border-b border-brand-line bg-brand-cream/50 dark:bg-[#101015]">
                <div className="text-center text-xs uppercase tracking-[0.28em] text-brand-copper/80 mb-7">Built for every kind of business</div>
                <div className="marquee-track gap-4 px-6">
                    {[...TRUST, ...TRUST].map((t, i) => (
                        <span key={i} className="inline-flex items-center gap-2.5 whitespace-nowrap rounded-full border border-brand-line bg-white px-5 py-2.5 shadow-sm shadow-black/[0.03] hover:shadow-md hover:-translate-y-0.5 hover:border-brand-copper/30 transition-all">
                            <span className="w-2 h-2 rounded-full bg-brand-copper" />
                            <span className="text-zinc-700 dark:text-zinc-200 font-semibold text-[15px]">{t}</span>
                        </span>
                    ))}
                </div>
            </div>

            {/* Product showcase (auto-advancing) */}
            <Section className="py-20">
                <div className="mx-auto max-w-6xl px-6 grid lg:grid-cols-2 gap-12 items-center">
                    <div className="reveal">
                        <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-3"><PlayCircle className="w-4 h-4" /> See it in motion</div>
                        <h2 className="font-display text-3xl md:text-4xl font-medium text-brand-ink leading-tight">Watch your business run itself.</h2>
                        <p className="mt-3 text-zinc-600 max-w-lg">A living dashboard where leads arrive, calendars fill, orders get paid and your AI keeps working — while you&apos;re out doing the work you love.</p>
                        <ul className="mt-6 space-y-3">
                            {["Real-time bookings & orders", "Payments that reconcile themselves", "AI that answers day and night"].map((t) => (
                                <li key={t} className="flex items-start gap-3 text-zinc-700">
                                    <span className="mt-0.5 w-5 h-5 rounded-full bg-brand-copper/15 text-brand-copper flex items-center justify-center shrink-0"><Check className="w-3.5 h-3.5" /></span>{t}
                                </li>
                            ))}
                        </ul>
                    </div>
                    <Showcase />
                </div>
            </Section>

            {/* Features — bento grid */}
            <Section className="py-20 bg-brand-cream/60 border-y border-brand-line">
                <div className="mx-auto max-w-6xl px-6">
                    <div className="max-w-2xl reveal">
                        <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">Everything inside</div>
                        <h2 className="font-display text-3xl md:text-4xl font-medium text-brand-ink leading-tight">One serious workspace. Not a stack of tabs.</h2>
                        <p className="mt-3 text-zinc-600">Most tools give you a website, or a store, or a booking page. {name} gives you all of them — and answers the phone.</p>
                    </div>
                    <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:auto-rows-[minmax(0,1fr)]" data-testid="home-features">
                        {/* Featured large cell — AI website builder with a mini live preview */}
                        <div className="reveal group relative overflow-hidden rounded-2xl border border-brand-line bg-white p-6 sm:col-span-2 lg:row-span-2 flex flex-col transition-all duration-300 hover:shadow-2xl hover:shadow-brand-copper/10 hover:border-brand-copper/40">
                            <div className="absolute inset-x-0 top-0 h-0.5 bg-brand-copper scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-500" />
                            <div className="w-11 h-11 rounded-xl bg-brand-copper text-white flex items-center justify-center shadow-lg shadow-brand-copper/25">
                                <Globe2 className="w-5 h-5" />
                            </div>
                            <h3 className="mt-4 font-display text-xl text-brand-ink">AI website + hosting</h3>
                            <p className="mt-2 text-sm text-zinc-600 leading-relaxed max-w-md">A multi-page site tailored to your trade — copy, structure and images, all editable with simple click-to-edit tools. Live in under a minute.</p>
                            {/* mini browser preview */}
                            <div className="mt-5 rounded-xl border border-brand-line bg-brand-cream/70 overflow-hidden shadow-inner flex-1 min-h-[190px]">
                                <div className="flex items-center gap-1.5 px-3 py-2 border-b border-brand-line bg-white/70">
                                    <span className="w-2.5 h-2.5 rounded-full bg-red-400/70" /><span className="w-2.5 h-2.5 rounded-full bg-amber-400/70" /><span className="w-2.5 h-2.5 rounded-full bg-emerald-400/70" />
                                    <div className="ml-3 h-4 flex-1 max-w-[180px] rounded bg-white border border-brand-line" />
                                </div>
                                <div className="p-4">
                                    <div className="flex items-center justify-between">
                                        <div className="h-3 w-24 rounded bg-brand-ink/80" />
                                        <div className="flex gap-1.5">{[0,1,2].map((k)=>(<div key={k} className="h-2.5 w-8 rounded bg-zinc-300" />))}</div>
                                    </div>
                                    <div className="mt-4 h-6 w-3/4 rounded bg-brand-copper/25" />
                                    <div className="mt-2 h-3 w-1/2 rounded bg-zinc-200" />
                                    <div className="mt-4 grid grid-cols-3 gap-2">
                                        {[0,1,2].map((k)=>(<div key={k} className="rounded-lg border border-brand-line bg-white p-2"><div className="h-8 rounded bg-brand-cream" /><div className="mt-2 h-2 w-2/3 rounded bg-zinc-200" /></div>))}
                                    </div>
                                    <div className="mt-3 inline-flex h-6 items-center rounded-md bg-brand-copper px-3"><div className="h-2 w-12 rounded bg-white/80" /></div>
                                </div>
                            </div>
                            <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-brand-copper">
                                Included on every plan <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                            </div>
                        </div>
                        {/* Remaining feature cells */}
                        {FEATURES.filter((f) => f.title !== "AI website + hosting").map((f, idx) => (
                            <div key={f.title} className="reveal group relative overflow-hidden rounded-2xl border border-brand-line bg-white p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-brand-copper/10 hover:border-brand-copper/40" style={{ transitionDelay: `${(idx % 3) * 40}ms` }}>
                                <div className="absolute inset-x-0 top-0 h-0.5 bg-brand-copper scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-500" />
                                <div className="pointer-events-none absolute -top-16 -right-16 w-40 h-40 rounded-full bg-brand-copper opacity-0 group-hover:opacity-[0.07] transition-opacity duration-500 blur-2xl" />
                                <div className="w-11 h-11 rounded-xl bg-brand-copper/10 text-brand-copper flex items-center justify-center ring-1 ring-brand-copper/15 group-hover:bg-brand-copper group-hover:text-white group-hover:ring-brand-copper transition-all duration-300">
                                    <f.icon className="w-5 h-5" />
                                </div>
                                <h3 className="mt-4 font-display text-lg text-brand-ink">{f.title}</h3>
                                <p className="mt-2 text-sm text-zinc-600 leading-relaxed">{f.body}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </Section>

            {/* Showcase image */}
            <Section className="py-20">
                <div className="mx-auto max-w-6xl px-6 grid lg:grid-cols-2 gap-12 items-center">
                    <div className="reveal relative mock-light">
                        <div className="rounded-2xl overflow-hidden border border-brand-line shadow-2xl bg-gradient-to-br from-brand-ink to-[#1a1830] p-6">
                            {/* Browser-style mock: live activity slider */}
                            <div className="rounded-xl bg-white/[0.04] border border-white/10 overflow-hidden">
                                <div className="flex items-center gap-1.5 px-3 py-2 border-b border-white/10">
                                    <span className="w-2.5 h-2.5 rounded-full bg-red-400/70" /><span className="w-2.5 h-2.5 rounded-full bg-amber-400/70" /><span className="w-2.5 h-2.5 rounded-full bg-emerald-400/70" />
                                    <span className="ml-auto text-[10px] text-white/40 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> live</span>
                                </div>
                                <ActivitySlider />
                            </div>
                        </div>
                        <div className="absolute -bottom-4 -right-4 hidden sm:flex items-center gap-2 rounded-xl border border-brand-line bg-white px-4 py-3 shadow-xl">
                            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-500 flex items-center justify-center"><TrendingUp className="w-4 h-4" /></div>
                            <div className="text-xs"><div className="font-semibold text-brand-ink">Revenue this week</div><div className="text-zinc-500">$4,820 · +18%</div></div>
                        </div>
                    </div>
                    <div className="reveal">
                        <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">Built for real businesses</div>
                        <h2 className="font-display text-3xl md:text-4xl font-medium text-brand-ink leading-tight">From first click to booked and paid.</h2>
                        <ul className="mt-6 space-y-3">
                            {["A site that reads like you wrote it", "Customers book and buy themselves — no phone tag", "Quotes and invoices that get paid faster", "An AI that never misses an enquiry"].map((t) => (
                                <li key={t} className="flex items-start gap-3 text-zinc-700">
                                    <span className="mt-0.5 w-5 h-5 rounded-full bg-brand-copper/15 text-brand-copper flex items-center justify-center shrink-0"><Check className="w-3.5 h-3.5" /></span>{t}
                                </li>
                            ))}
                        </ul>
                        <Link to="/signup" className="inline-block mt-8"><Button className="bg-brand-ink hover:bg-black text-white transition-transform hover:-translate-y-0.5">{brand?.cta_label || "Get started"} <ArrowRight className="ml-2 w-4 h-4" /></Button></Link>
                    </div>
                </div>
            </Section>

            {/* How it works */}
            <Section className="py-20 bg-brand-cream/60 border-y border-brand-line">
                <div className="mx-auto max-w-6xl px-6">
                    <div className="max-w-2xl reveal">
                        <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">How it works</div>
                        <h2 className="font-display text-3xl md:text-4xl font-medium text-brand-ink leading-tight">Live in three easy steps.</h2>
                    </div>
                    <div className="mt-12 grid md:grid-cols-3 gap-6 relative">
                        <div className="hidden md:block absolute top-10 left-[16%] right-[16%] h-px bg-gradient-to-r from-transparent via-brand-copper/50 to-transparent" />
                        {STEPS.map((s, idx) => (
                            <div key={s.n} className="reveal relative rounded-2xl border border-brand-line bg-white p-7 transition-all hover:-translate-y-1.5 hover:shadow-xl hover:border-brand-copper/40" style={{ transitionDelay: `${idx * 90}ms` }}>
                                <div className="flex items-center gap-4">
                                    <div className="relative w-14 h-14 rounded-2xl bg-brand-copper flex items-center justify-center text-white shadow-lg shadow-brand-copper/25 shrink-0">
                                        <s.icon className="w-6 h-6" />
                                        <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-brand-ink text-white text-[11px] font-bold flex items-center justify-center border-2 border-white dark:border-[#141418]">{s.n.replace("0", "")}</span>
                                    </div>
                                    <div className="font-display text-5xl text-brand-copper/15 leading-none">{s.n}</div>
                                </div>
                                <h3 className="mt-5 font-display text-xl text-brand-ink">{s.title}</h3>
                                <p className="mt-2 text-sm text-zinc-600 leading-relaxed">{s.body}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </Section>

            {/* Why teams choose Zanelvo — everything included, one price */}
            <Section className="py-20 bg-brand-cream text-brand-ink dark:bg-brand-ink dark:text-white">
                <div className="mx-auto max-w-6xl px-6">
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper dark:text-brand-accent mb-3 reveal">One platform, everything included</div>
                    <h2 className="font-display text-3xl md:text-5xl leading-tight max-w-2xl reveal" data-testid="home-compare-title">One subscription replaces your website builder, store, booking tool, CRM and email software.</h2>
                    <p className="mt-4 text-zinc-600 dark:text-white/60 max-w-2xl reveal">No plugins to install, no app store fees, no API keys to hunt down. Everything below is built in and ready the moment your site goes live.</p>
                    <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4 reveal" data-testid="home-included-grid">
                        {[
                            [Globe2, "AI website designer", "Interviews you, then writes and designs your whole multi-page site."],
                            [Store, "Online store + payments", "Products, orders, discounts and shipping — get paid the day you launch."],
                            [CreditCard, "Subscription products", "Sell memberships and monthly boxes with automatic recurring billing."],
                            [Calendar, "Bookings, quotes & invoices", "Take appointments, send quotes and collect payment in one flow."],
                            [Users, "Built-in CRM & shared inbox", "Every lead, message and customer in a single, organized place."],
                            [Megaphone, "Email marketing + automations", "Drag-and-drop email builder, welcome flows and cart recovery included."],
                            [Bot, "AI employees", "An AI receptionist that answers chat and email around the clock."],
                            [MessageSquare, "Multi-language storefront", "Sell in any language with hand-authored translations, not just machine ones."],
                            [Phone, "Point of sale (POS)", "Ring up in-person sales while online and in-store inventory stay in sync."],
                            [TrendingUp, "Analytics & SEO tools", "Understand what's working and get found — no extra subscriptions."],
                            [Sparkles, "Multiple sites, one login", "Run several brands or locations without juggling accounts."],
                            [Zap, "Developer API & webhooks", "Automate everything with API keys, webhooks and full documentation."],
                        ].map(([Icon, title, desc]) => (
                            <div key={title} className="group relative overflow-hidden rounded-2xl border border-brand-line bg-white dark:border-white/10 dark:bg-white/[0.04] p-5 transition-all hover:bg-brand-cream dark:hover:bg-white/[0.07] hover:-translate-y-1 hover:border-brand-copper/30 dark:hover:border-white/20">
                                <div className="pointer-events-none absolute -top-14 -right-14 w-32 h-32 rounded-full bg-brand-copper opacity-0 group-hover:opacity-10 dark:group-hover:opacity-20 blur-2xl transition-opacity duration-500" />
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-xl bg-brand-copper/10 ring-1 ring-brand-copper/15 dark:bg-white/5 dark:ring-white/10 flex items-center justify-center text-brand-copper group-hover:text-white group-hover:bg-brand-copper transition-colors shrink-0">
                                        <Icon className="w-5 h-5" />
                                    </div>
                                    <div className="text-brand-ink dark:text-white font-medium leading-tight flex items-center gap-2">{title}</div>
                                </div>
                                <p className="mt-3 text-sm text-zinc-600 dark:text-white/55 leading-relaxed">{desc}</p>
                            </div>
                        ))}
                    </div>
                    <p className="mt-6 text-[11px] text-zinc-400 dark:text-white/40 reveal">Everything included from the first paid plan. No hidden add-ons or per-app fees.</p>
                </div>
            </Section>

            {/* Testimonials */}
            <Section className="py-20">
                <div className="mx-auto max-w-6xl px-6">
                    <div className="text-center reveal">
                        <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">In practice</div>
                        <h2 className="font-display text-3xl md:text-4xl font-medium text-brand-ink leading-tight">What it looks like for a business like yours.</h2>
                        <p className="mt-3 text-sm text-zinc-500">Example scenarios to show how the pieces fit together — illustrative, not customer quotes.</p>
                    </div>
                    <div className="mt-10 grid md:grid-cols-3 gap-6">
                        {SCENARIOS.map((t) => (
                            <div key={t.a} className="reveal group relative overflow-hidden rounded-2xl border border-brand-line bg-white p-7 transition-all hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-brand-copper/10 hover:border-brand-copper/30" data-testid="scenario-card">
                                <div className="pointer-events-none absolute -top-16 -right-10 font-display text-[7rem] leading-none text-brand-copper/[0.06] select-none">&ldquo;</div>
                                <div className="flex items-center justify-between">
                                    <div className="text-[10px] uppercase tracking-[0.24em] text-zinc-400">Example scenario</div>
                                    <div className="flex gap-0.5 text-brand-copper">
                                        {[0,1,2,3,4].map((k)=>(<Star key={k} className="w-3.5 h-3.5 fill-current" />))}
                                    </div>
                                </div>
                                <p className="mt-4 text-brand-ink leading-relaxed relative">{t.q}</p>
                                <div className="mt-6 flex items-center gap-3 pt-5 border-t border-brand-line">
                                    <div className={`w-11 h-11 rounded-full bg-gradient-to-br ${t.c} text-white font-semibold flex items-center justify-center shrink-0 shadow-md`}>{t.i}</div>
                                    <div className="min-w-0 flex-1">
                                        <div className="font-medium text-brand-ink text-sm">{t.a}</div>
                                        <div className="text-xs text-zinc-500 truncate">{t.r}</div>
                                    </div>
                                    <div className="text-[11px] font-medium px-2 py-1 rounded-full bg-brand-copper/10 text-brand-copper whitespace-nowrap">{t.metric}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </Section>

            {/* FAQ */}
            <Section className="py-20 bg-brand-cream/60 border-y border-brand-line">
                <div className="mx-auto max-w-3xl px-6">
                    <div className="text-center reveal">
                        <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">Good to know</div>
                        <h2 className="font-display text-3xl md:text-4xl font-medium text-brand-ink leading-tight">Questions, answered.</h2>
                    </div>
                    <div className="mt-10 space-y-3 reveal">
                        {FAQS.map((f) => (
                            <details key={f.q} className="group rounded-2xl border border-brand-line bg-white p-5 open:shadow-lg open:border-brand-copper/30 transition-all" data-testid="home-faq-item">
                                <summary className="cursor-pointer list-none flex items-center justify-between gap-4 text-brand-ink font-medium">
                                    <span className="flex items-center gap-3">
                                        <span className="w-6 h-6 rounded-full bg-brand-copper/10 text-brand-copper flex items-center justify-center text-xs shrink-0 group-open:bg-brand-copper group-open:text-white transition-colors">Q</span>
                                        {f.q}
                                    </span>
                                    <span className="w-7 h-7 rounded-full border border-brand-line flex items-center justify-center text-brand-copper transition-transform group-open:rotate-45 text-xl leading-none shrink-0">+</span>
                                </summary>
                                <p className="mt-3 pl-9 text-sm text-zinc-600 leading-relaxed">{f.a}</p>
                            </details>
                        ))}
                    </div>
                    <div className="mt-8 text-center reveal">
                        <span className="text-sm text-zinc-600">Still curious? </span>
                        <Link to="/signup" className="text-sm font-medium text-brand-copper hover:underline">Try it free — no card needed →</Link>
                    </div>
                </div>
            </Section>

            {/* Final CTA */}
            <Section className="py-24">
                <div className="mx-auto max-w-4xl px-6">
                    <div className="reveal rounded-3xl bg-white border border-brand-line text-brand-ink dark:bg-brand-ink dark:text-white dark:border-transparent p-10 md:p-14 relative overflow-hidden grain text-center">
                        <div className="pointer-events-none absolute inset-0 hero-grid opacity-[0.05] dark:opacity-10" />
                        <div className="pointer-events-none absolute -top-24 -right-24 w-72 h-72 rounded-full bg-brand-copper/15 dark:bg-brand-copper/30 blur-3xl mesh-orb" />
                        <h2 className="font-display text-3xl md:text-5xl leading-tight relative">Show us your business. We&apos;ll show you the site.</h2>
                        <p className="mt-4 text-zinc-600 dark:text-zinc-300 max-w-lg mx-auto relative">A 90-second interview. Then a real preview, on your dashboard, with every fact editable.</p>
                        <Link to="/signup" className="inline-block mt-8 relative" data-testid="home-final-cta-btn">
                            <Button size="lg" className="bg-brand-copper hover:bg-brand-copperHover text-white cta-sheen transition-transform hover:-translate-y-0.5">{brand?.cta_label || "Build my website"} <ArrowRight className="ml-2 w-4 h-4" /></Button>
                        </Link>
                    </div>
                </div>
            </Section>

            <footer className="py-14 border-t border-brand-line">
                <div className="mx-auto max-w-6xl px-6 grid md:grid-cols-4 gap-8 text-sm">
                    <div>
                        <div className="font-display text-lg text-brand-ink">{brand?.name || name}</div>
                        <div className="mt-2 text-zinc-500 max-w-xs">{brand?.tagline || "The all-in-one platform for service & online businesses."}</div>
                        {brand?.support_email && (
                            <a href={`mailto:${brand.support_email}`} className="mt-3 inline-block text-brand-copper hover:underline">
                                {brand.support_email}
                            </a>
                        )}
                    </div>
                    <div>
                        <div className="text-zinc-400 text-xs uppercase tracking-widest">Product</div>
                        <ul className="mt-3 space-y-2">
                            <li><Link to="/product" className="text-zinc-600 hover:text-brand-ink">Overview</Link></li>
                            <li><Link to="/pricing" className="text-zinc-600 hover:text-brand-ink">Pricing</Link></li>
                            <li><Link to="/industries" className="text-zinc-600 hover:text-brand-ink">Industries</Link></li>
                            <li><Link to="/signup" className="text-zinc-600 hover:text-brand-ink">Start free</Link></li>
                        </ul>
                    </div>
                    <div>
                        <div className="text-zinc-400 text-xs uppercase tracking-widest">Company</div>
                        <ul className="mt-3 space-y-2">
                            <li><Link to="/security" className="text-zinc-600 hover:text-brand-ink">Security</Link></li>
                            {brand?.emails?.support?.address && <li><a href={`mailto:${brand.emails.support.address}`} className="text-zinc-600 hover:text-brand-ink">Support</a></li>}
                            {brand?.emails?.sales?.address && <li><a href={`mailto:${brand.emails.sales.address}`} className="text-zinc-600 hover:text-brand-ink">Sales</a></li>}
                            <li><Link to="/login" className="text-zinc-600 hover:text-brand-ink">Log in</Link></li>
                        </ul>
                    </div>
                    <div>
                        <div className="text-zinc-400 text-xs uppercase tracking-widest">Legal</div>
                        <ul className="mt-3 space-y-2">
                            <li><Link to="/terms" className="text-zinc-600 hover:text-brand-ink">Terms of service</Link></li>
                            <li><Link to="/privacy" className="text-zinc-600 hover:text-brand-ink">Privacy policy</Link></li>
                            <li><Link to="/security" className="text-zinc-600 hover:text-brand-ink">Security overview</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="mx-auto max-w-6xl px-6 mt-10 pt-6 border-t border-brand-line text-xs text-zinc-500 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div>© {new Date().getFullYear()} {brand?.company_name || name}. {brand?.footer_note || "All rights reserved."}</div>
                    <div className="opacity-70">Built for real service businesses.</div>
                </div>
            </footer>
        </div>
    );
}
