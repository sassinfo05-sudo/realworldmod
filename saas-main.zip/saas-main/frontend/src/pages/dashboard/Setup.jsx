import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { CheckCircle2, Circle, AlertTriangle, XCircle, RefreshCw, Zap } from "lucide-react";

const STATE_STYLES = {
    connected: { icon: CheckCircle2, cls: "text-emerald-600", label: "Connected" },
    not_connected: { icon: Circle, cls: "text-zinc-400", label: "Not connected" },
    requires_credential: { icon: AlertTriangle, cls: "text-amber-600", label: "Needs credential" },
    error: { icon: XCircle, cls: "text-red-600", label: "Error" },
};

function CardTile({ card, onTest }) {
    const st = STATE_STYLES[card.state] || STATE_STYLES.not_connected;
    const Icon = st.icon;
    return (
        <div className="rounded-lg border border-brand-line bg-white p-4 hover:shadow-sm transition-shadow" data-testid={`setup-card-${card.key}`}>
            <div className="flex items-start justify-between gap-2">
                <div>
                    <div className="text-sm font-medium text-brand-ink">{card.label}</div>
                    <div className="text-xs text-zinc-500 mt-0.5">{card.purpose}</div>
                </div>
                <Icon className={`w-4 h-4 ${st.cls} shrink-0`} />
            </div>
            {card.enables && (
                <div className="mt-2 text-[11px] text-zinc-500 italic">Enables: {card.enables}</div>
            )}
            {card.error_hint && (
                <div className="mt-2 text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1">
                    {card.error_hint}
                </div>
            )}
            <div className="mt-3 flex items-center justify-between">
                <span className={`text-[11px] uppercase tracking-widest ${st.cls}`}>{st.label}</span>
                <Button size="sm" variant="ghost" onClick={() => onTest(card.key)} data-testid={`setup-card-${card.key}-test`}>
                    <RefreshCw className="w-3 h-3 mr-1" /> Test
                </Button>
            </div>
        </div>
    );
}

function LaunchScore({ score }) {
    if (!score) return null;
    return (
        <div className="rounded-lg border border-brand-line bg-white p-5 mb-6" data-testid="launch-score">
            <div className="flex items-center justify-between mb-3">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">Launch Score</div>
                    <div className="mt-1 font-display text-3xl text-brand-ink">{score.score}%</div>
                    <div className="text-xs text-zinc-500">{score.done} of {score.total} checks passed — real state, not decorative.</div>
                </div>
                <Zap className="w-8 h-8 text-brand-copper opacity-30" />
            </div>
            <div className="grid md:grid-cols-3 gap-2">
                {score.checks.map((c) => (
                    <div key={c.key} className={`flex items-start gap-2 rounded-md px-3 py-2 text-sm ${
                        c.done ? "bg-emerald-50" : "bg-brand-cream"
                    }`} data-testid={`launch-check-${c.key}`}>
                        {c.done ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" /> : <Circle className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />}
                        <div>
                            <div className={c.done ? "text-emerald-800 line-through" : "text-brand-ink"}>{c.label}</div>
                            {!c.done && c.action && <div className="text-[11px] text-zinc-500 mt-0.5">{c.action}</div>}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default function Setup() {
    const [cards, setCards] = useState([]);
    const [score, setScore] = useState(null);
    const [loading, setLoading] = useState(true);

    async function load() {
        setLoading(true);
        try {
            const [c, s] = await Promise.all([
                api.get("/setup/cards"),
                api.get("/setup/launch-score"),
            ]);
            setCards(c.data.cards || []);
            setScore(s.data);
        } catch (e) { toast.error("Failed to load setup"); }
        finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    async function testCard(key) {
        try {
            const { data } = await api.post(`/setup/cards/${key}/test`);
            if (data.ok) toast.success(data.message || "OK");
            else toast.warning(data.message || "Not configured");
            load();
        } catch (e) {
            toast.error("Test failed");
        }
    }

    const groups = {};
    for (const c of cards) {
        (groups[c.category] ||= []).push(c);
    }
    const catLabels = {
        identity: "Identity & Brand", email: "Email & Inbox",
        channels: "Channels", payments: "Payments",
        marketing: "Marketing", accounting: "Accounting",
        devtools: "Developer tools",
    };

    return (
        <div className="p-6 max-w-6xl" data-testid="setup-page">
            <LaunchScore score={score} />

            {loading ? <div className="text-zinc-500">Loading…</div> : (
                Object.keys(catLabels).filter((k) => groups[k]?.length).map((cat) => (
                    <div key={cat} className="mb-6">
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">{catLabels[cat]}</div>
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                            {groups[cat].map((c) => <CardTile key={c.key} card={c} onTest={testCard} />)}
                        </div>
                    </div>
                ))
            )}
        </div>
    );
}
