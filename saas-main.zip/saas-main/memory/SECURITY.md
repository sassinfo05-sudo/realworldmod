# SECURITY INCIDENT LOG

## R15-INC-001 — leaked JWT artifacts in git (Round 15)
- **What:** `tmp_r11/owner_token` and `tmp_r11/staff_token` (real owner + staff JWTs) were
  committed to git history across recent commits (f90cbf1 … 909b62a).
- **Mitigation (done):** removed from working tree + git index; **JWT_SECRET rotated**, which
  cryptographically invalidates those JWTs (and all existing owner/staff/impersonation sessions)
  — the leaked tokens can no longer be verified or used. Seeded/test passwords rotated via fresh seed.
- **Provider rotation required:** NONE — the leaked artifacts were JWTs (no provider API key).
  `.env` (incl. EMERGENT_LLM_KEY) was never committed.
- **History note:** destructive git-history rewrite was NOT performed (agent must not rewrite git
  history; unnecessary since tokens are already invalidated). If desired later, a maintainer can
  run BFG/git-filter-repo to purge the dead blobs.
- **Prevention:** `.gitignore` now blocks `tmp_r*/`, `*_token`, `*.secret(s)`, secret-bearing
  `test_reports/**`, `scratch/`. `memory/test_credentials.md` and `.env` remain ignored.

---


# Revenue OS — Security Notes

## MFA / TOTP

- Required-by-default for the platform founder role. Enrollable for owners and below.
- Enrollment secret is stored per-user in `mfa_secrets.secret_base32`. A production
  deployment should encrypt this at rest (KMS-wrapped envelope encryption or Mongo
  field-level encryption). The current MVP stores base32 in cleartext — acceptable
  for a single-tenant dev deployment; NOT for production.
- 8 one-time backup codes are generated at enrollment. Only SHA-256 hashes are
  stored (`mfa_secrets.backup_codes_hashed`). Codes are shown once to the user.

## Founder MFA — Recovery procedure

If the founder loses their authenticator device AND all backup codes:

1. Direct MongoDB reset — an operator with DB access runs:

```python
db.mfa_secrets.update_one(
    {"user_id": "<founder_user_id>"},
    {"$set": {"enabled": False, "backup_codes_hashed": []}}
)
```

2. Log a manual audit event:

```python
db.audit_events.insert_one({
    "action": "mfa.recovery",
    "actor_user_id": None,
    "actor_role": "system",
    "actor_email": "ops",
    "target_type": "user",
    "target_id": "<founder_user_id>",
    "reason": "documented CLI recovery",
    "meta": {}, "created_at": ..., "updated_at": ...,
})
```

3. Log in with the founder password (still enforced), then re-enroll MFA immediately
   at `/app/setup/security`.

There is NO in-code bypass and NO env-flag skip. The recovery path requires operator
access to the primary database.

## Rate limiting

- `/api/auth/login`: 10 attempts / 5 minutes per client IP.
- `/api/auth/signup`: 8 attempts / 10 minutes per client IP.
- `/api/public/chat/start`: 30 requests / 60s per client IP.
- `/api/public/chat/message`: 60 requests / 60s per client IP.

All limits are in-process (single-worker). A cluster deployment must front the API
with a Redis-backed rate limiter (nginx `limit_req` or a shared bucket in Redis).

## Token security

- Portal tokens (Booking/Quote/Invoice) are `secrets.token_urlsafe(24)`.
- All comparisons use `hmac.compare_digest` — constant-time — via
  `_tokens_equal` / `_token_matches_any` in `routes/bookings.py`.
- JWT access tokens are HS256, 24-hour TTL. Rotate `JWT_SECRET` to invalidate all
  sessions.

## API keys

- Format: `yv_live_<24 char>` (prod) / `yv_test_<24 char>` (sandbox).
- Server stores only `sha256(full_key)`. Full key is displayed ONCE at creation.
- Scoped to explicit permissions (`contacts:read`, `bookings:write`, etc.).
- Revocation is idempotent: set `revoked: true`. Lookups filter revoked keys.

## Webhook signing

- Header: `X-Revenue-OS-Signature: t=<unix>,v1=<hex hmac_sha256(t + "." + body)>`.
- Verifier rejects timestamps outside a 5-minute window (`REPLAY_WINDOW_SECONDS`).
- Constant-time compare on the HMAC (`hmac.compare_digest`).
- Secret is displayed ONCE at webhook creation; server stores SHA-256 hash.

## Data export & deletion

- Export: `POST /api/setup/data-export` streams a ZIP of every org-owned Mongo
  collection as JSON. Runs synchronously; a queue-worker split is Phase 8.
- Deletion: `POST /api/setup/delete-org` soft-deletes with a 30-day grace. Org is
  immediately `suspended`; a scheduled purge job (not yet wired — Phase 7) removes
  the data at `scheduled_purge_at`.

## Impersonation

- Only `platform_founder` can call `/api/founder/impersonate/start`.
- Reason is required (min 6 chars) and stored on the `impersonation_sessions` doc.
- Hard expiry: 30 minutes from `started_at`.
- Every action taken during a session must be tagged with `impersonation_session_id`
  in the audit log — verified server-side by the audit helper.

## Kill switches

- Per-org: `KillSwitch{org_id, ai_enabled}` (owner/manager controls).
- Platform-wide: `GlobalKillSwitchDoc{all_ai_disabled, all_email_disabled,
  all_public_chat_disabled}` (founder only).
- Both are consulted before every AI conversation start and every AI turn.


## Round 8 additions (2026-09-06)
- Reset tokens: sha256-hashed, single active token per user, atomic single-use consume, 2h expiry, `sessions_invalidated_at` rejects older JWTs (iat <= inv).
- Invites: set-password link (48h hashed token) — API never returns temporary passwords in production.
- CORS: `allow_credentials` only with an explicit origin allow-list (`CORS_ORIGINS`), never with `*`.
- Body limits: 2 MB JSON / 25 MB multipart (`MAX_JSON_BYTES`, `MAX_REQUEST_BYTES`); 413 on excess.
- SSRF: `services/netsafe.py` (public IP resolution, scheme/port allow-list, manual redirect following) for website import + outbound webhooks; webhook URLs must be public https.
- Secrets at rest: Fernet via `services/secretbox.py` (`SECRETS_ENC_KEY` or derived from `JWT_SECRET`) for platform + tenant integration secrets.
- Rate limits: auth/reset/2FA buckets persisted in Mongo (`rate_limits`, TTL) + in-process; global soft limit `API_GLOBAL_RPM` (default 900/min/IP).
- Webhooks: Stripe signature (existing), inbound email shared secret required in production, voice webhooks require Twilio signature or `voice.webhook_secret`.
- Cost abuse: every paid op passes `services/usage.enforce_budget` (pause-all, provider kill, global cap, plan cap, per-user share, feature caps, visitor daily cap).
- Production seeding: demo data/accounts only when `APP_ENV` in dev/test/demo or `SEED_DEMO_DATA=true`; founder bootstrap via `FOUNDER_INITIAL_PASSWORD`.
- Known open: SVG sanitisation for uploaded logos; Redis for multi-worker non-auth rate limits.

## Round 15 hardening (pass 2)
- Auth: HttpOnly `zv_access` + readable `zv_csrf` (CSRF double-submit); NO raw JWT in JS storage
  (verified 6/6 frontend). JWT_SECRET rotated. CORS fails closed in production (explicit allow-list).
- MFA FAILS CLOSED in production: staff login refuses a session when the MFA provider is
  unavailable; owner login refuses when email-2FA is enrolled but the provider is down. Backup
  codes are consumed with an atomic conditional `$pull` (single-use); TOTP/email challenges are
  claimed with an atomic conditional `$set consumed` (no replay).
- Cost control: two DB-backed editable hard caps per plan (AI + total variable-provider). Atomic
  reservation + race-safe FIFO confirm; `reserve()` fails closed (503) if metering storage is down;
  pass-through/prepaid kinds never consume plan margin. Concurrency proof in
  `backend/tests/test_atomic_metering.py`. See `PRODUCTION_COST_MODEL.md`.
- Entitlements: `PUT /api/store/products/{id}` enforces the `subscriptions` feature when a product
  is flipped to recurring (closes the create-then-update bypass).
- Voice webhooks: tenant resolved STRICTLY from the verified dialed number (no `?org_id=` /
  first-receptionist fallback in production); signatures verified before processing.
- Custom domains: the simulated provider can never be selected in production (forces the real
  Cloudflare provider, which honestly reports Not-connected until credentials exist).
- XSS: server-side strict-allowlist `sanitize_svg`/`sanitize_html` (nh3) on branding/uploads/legal;
  `Support.jsx` escapes article markdown before render. Regression:
  `backend/tests/test_xss_sanitizer.py` (12 payloads neutralized).
- Still open (P0/P1): Stripe Connect + sandbox probes; inbound-email identity/signature +
  status/state fix; outbound-webhook durable retries/DLQ; frontend HTML CSP as a deploy header;
  distributed staff-auth limiter; dedicated worker/queue; CI + secret scanning; full fresh regression.


## Round 15 pass 4 additions
* No tenant secret keys: `tenant_integrations.TENANT_SECRET_KEYS_REJECTED` blocks pasted Stripe/PayPal secrets (400).
* Stripe webhook: platform secret from Setup Center; unique-`_id` atomic idempotency; Connect `account` must own the
  referenced order/invoice (403 otherwise).
* Staff: invitations are hashed (SHA-256), 48 h, single-use (atomic claim); MFA challenge consumption is atomic;
  `sessions_invalidated_at` rejects tokens issued before a credential change; login/2FA/invite endpoints use the
  Mongo-backed limiter (multi-worker safe). Residual: the limiter keys on `X-Forwarded-For` — only trust it behind
  the ingress that sets it (documented in deploy/).
* Inbound email: 401/403 on missing/invalid signatures; SendGrid ECDSA signed events supported; tenant routing only
  from platform-assigned mailboxes or verified custom domains.
* Public AI: per-session / per-IP / per-tenant daily caps prevent quota exhaustion by a single visitor.

## Round 17 — Storage security
- Object keys are tenant-scoped + non-guessable (org/{org_id}/{asset_id}/{variant}); org_id always from auth context.
- Provider credentials in platform_settings.storage: encrypted at rest (secretbox), masked in all responses,
  never logged/exported; rotation supported; status Connected/Sandbox/Not connected/Error.
- Uploads: MIME allowlist, magic-byte validation, SVG nh3 sanitisation, decompression-bomb + dimension guard,
  EXIF/location strip on re-encode, per-tenant (never cross-tenant) SHA-256 dedup, atomic quota reservation.
- Private assets served only via short-lived HMAC-signed URLs (local mode) / provider presigned URLs (S3).
- Production refuses container-local storage as permanent storage (_DisabledProvider raises on write).
- Invalid asset IDs return 404 (never 500). Delete failures recorded for dead-letter reconciliation.
