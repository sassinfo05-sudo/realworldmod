import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { ArrowLeft, Save, Send, RotateCcw, Play, Loader2, Bot, Sparkles, GitBranch, History } from "lucide-react";

const DEFAULT_ESC_RULE = { kind: "topic", value: "", note: "" };
const DEFAULT_QQ = { name: "", prompt: "", required: false };

export default function AgentStudio() {
    const { agentId } = useParams();
    const navigate = useNavigate();
    const [agent, setAgent] = useState(null);
    const [versions, setVersions] = useState([]);
    const [tools, setTools] = useState([]);
    const [form, setForm] = useState(null);
    const [busy, setBusy] = useState(false);
    const [tab, setTab] = useState("config");

    // Sandbox
    const [sandboxMsgs, setSandboxMsgs] = useState([]);
    const [sandboxInput, setSandboxInput] = useState("");
    const [sandboxConvId, setSandboxConvId] = useState(null);
    const [sandboxVersionId, setSandboxVersionId] = useState(null);
    const [sandboxBusy, setSandboxBusy] = useState(false);
    const scrollRef = useRef(null);

    async function load() {
        const [a, t] = await Promise.all([
            api.get(`/ai/agents/${agentId}`),
            api.get("/ai/tools"),
        ]);
        setAgent(a.data.agent);
        setVersions(a.data.versions);
        setTools(t.data.tools);
        const live = a.data.versions.find((v) => v.is_live) || a.data.versions[0];
        setForm(versionToForm(live));
        setSandboxVersionId(live?.id || null);
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [agentId]);

    useEffect(() => {
        if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, [sandboxMsgs, sandboxBusy]);

    function versionToForm(v) {
        return {
            label: v?.label || "",
            purpose: v?.purpose || "",
            tone: v?.tone || "",
            languages: v?.languages || ["en"],
            allowed_tools: v?.allowed_tools || [],
            qualification_questions: v?.qualification_questions || [],
            escalation_rules: v?.escalation_rules || [],
            allowed_claims: v?.allowed_claims || "",
            confidence_threshold: v?.confidence_threshold ?? 0.4,
            require_approval: !!v?.require_approval,
            model: v?.model || "claude-sonnet-4-6",
        };
    }

    async function saveVersion(promote) {
        setBusy(true);
        try {
            const { data } = await api.post(`/ai/agents/${agentId}/versions`, {
                ...form, promote_to_live: !!promote,
            });
            toast.success(promote ? `Promoted to live (v${data.version})` : `Draft v${data.version} saved`);
            setSandboxVersionId(data.id);
            await load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Save failed"); }
        finally { setBusy(false); }
    }

    async function promote(vid) {
        try {
            await api.post(`/ai/agents/${agentId}/promote/${vid}`);
            toast.success("Promoted to live");
            await load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Promote failed"); }
    }

    async function sandboxSend() {
        if (!sandboxInput.trim()) return;
        const message = sandboxInput.trim();
        setSandboxInput("");
        setSandboxBusy(true);
        setSandboxMsgs((m) => [...m, { role: "visitor", content: message, id: `v-${Date.now()}` }]);
        try {
            const { data } = await api.post("/ai/sandbox/message", {
                agent_id: agentId,
                version_id: sandboxVersionId,
                message,
                conversation_id: sandboxConvId,
            });
            setSandboxConvId(data.conversation_id);
            setSandboxMsgs((m) => [...m, {
                role: "ai", content: data.reply, id: `a-${Date.now()}`,
                confidence: data.confidence, action: data.action, tool_calls: data.tool_calls,
            }]);
        } catch (e) {
            toast.error("Sandbox failed"); setSandboxMsgs((m) => [...m.slice(0, -1)]);
        } finally { setSandboxBusy(false); }
    }

    function resetSandbox() { setSandboxMsgs([]); setSandboxConvId(null); }

    const liveVersion = useMemo(() => versions.find((v) => v.is_live), [versions]);

    if (!agent || !form) return <div className="p-10 text-zinc-500">Loading…</div>;

    return (
        <div className="p-6 max-w-6xl" data-testid="agent-studio-page">
            <button onClick={() => navigate("/app/ai")} className="text-xs text-brand-copper mb-2 inline-flex items-center gap-1 hover:underline">
                <ArrowLeft className="w-3.5 h-3.5" /> Back to AI Employees
            </button>
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">{agent.agent_type}</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">{agent.name}</h1>
                    <p className="text-sm text-zinc-500 mt-1">
                        Live: <span className="font-mono">v{liveVersion?.version || "—"}</span> · {versions.length} version(s)
                    </p>
                </div>
                <Badge className={agent.enabled ? "bg-emerald-100 text-emerald-800" : "bg-zinc-200 text-zinc-600"}>{agent.enabled ? "Enabled" : "Paused"}</Badge>
            </div>

            <Tabs value={tab} onValueChange={setTab} className="mt-6">
                <TabsList data-testid="studio-tabs">
                    <TabsTrigger value="config" data-testid="studio-tab-config">Config</TabsTrigger>
                    <TabsTrigger value="sandbox" data-testid="studio-tab-sandbox">Sandbox</TabsTrigger>
                    <TabsTrigger value="history" data-testid="studio-tab-history">Version history</TabsTrigger>
                </TabsList>

                <TabsContent value="config" className="mt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="rounded-2xl border border-brand-line bg-white p-5 space-y-3">
                            <div>
                                <Label className="text-xs">Purpose</Label>
                                <Textarea rows={2} value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })} data-testid="studio-purpose" />
                            </div>
                            <div>
                                <Label className="text-xs">Tone</Label>
                                <Input value={form.tone} onChange={(e) => setForm({ ...form, tone: e.target.value })} data-testid="studio-tone" />
                            </div>
                            <div>
                                <Label className="text-xs">Languages (comma-separated)</Label>
                                <Input value={form.languages.join(", ")} onChange={(e) => setForm({ ...form, languages: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} data-testid="studio-langs" />
                                <div className="text-[10px] text-zinc-400 mt-0.5">Common: en, he, es, fr, ar, ru, pt, de</div>
                            </div>
                            <div>
                                <Label className="text-xs">Allowed claims / guardrails</Label>
                                <Textarea rows={3} value={form.allowed_claims} onChange={(e) => setForm({ ...form, allowed_claims: e.target.value })} data-testid="studio-claims" />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <Label className="text-xs">Confidence threshold ({form.confidence_threshold})</Label>
                                    <Input type="range" min="0" max="1" step="0.05" value={form.confidence_threshold} onChange={(e) => setForm({ ...form, confidence_threshold: +e.target.value })} data-testid="studio-confidence" />
                                    <div className="text-[10px] text-zinc-400 mt-0.5">Below this → escalate to human.</div>
                                </div>
                                <div>
                                    <Label className="text-xs">Model</Label>
                                    <Input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} data-testid="studio-model" />
                                </div>
                            </div>
                            <label className="flex items-center gap-2 text-xs">
                                <input type="checkbox" checked={form.require_approval} onChange={(e) => setForm({ ...form, require_approval: e.target.checked })} data-testid="studio-require-approval" />
                                Require owner approval before any outbound
                            </label>
                        </div>

                        <div className="rounded-2xl border border-brand-line bg-white p-5 space-y-4">
                            <div>
                                <Label className="text-xs">Allowed tools</Label>
                                <div className="mt-2 space-y-1" data-testid="studio-tools-list">
                                    {tools.map((t) => (
                                        <label key={t.name} className="flex items-start gap-2 text-sm">
                                            <input
                                                type="checkbox"
                                                checked={form.allowed_tools.includes(t.name)}
                                                onChange={(e) => {
                                                    setForm({ ...form,
                                                        allowed_tools: e.target.checked
                                                            ? [...form.allowed_tools, t.name]
                                                            : form.allowed_tools.filter((x) => x !== t.name)
                                                    });
                                                }}
                                                data-testid={`studio-tool-${t.name}`}
                                                className="mt-0.5"
                                            />
                                            <div className="min-w-0">
                                                <div className="font-mono text-xs text-brand-ink">{t.name}{t.write ? <span className="ml-1 text-red-600">(write)</span> : null}</div>
                                                <div className="text-[11px] text-zinc-500 line-clamp-2">{t.description}</div>
                                            </div>
                                        </label>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <Label className="text-xs">Escalation rules</Label>
                                <div className="mt-2 space-y-2" data-testid="studio-escalation-list">
                                    {form.escalation_rules.map((r, i) => (
                                        <div key={i} className="flex gap-2 items-center">
                                            <select value={r.kind} onChange={(e) => {
                                                const next = [...form.escalation_rules]; next[i] = { ...r, kind: e.target.value };
                                                setForm({ ...form, escalation_rules: next });
                                            }} className="rounded-md border border-brand-line px-2 py-1 text-xs">
                                                <option value="topic">topic</option>
                                                <option value="keyword">keyword</option>
                                                <option value="sentiment">sentiment</option>
                                                <option value="low_confidence">low_confidence</option>
                                            </select>
                                            <Input value={r.value} onChange={(e) => {
                                                const next = [...form.escalation_rules]; next[i] = { ...r, value: e.target.value };
                                                setForm({ ...form, escalation_rules: next });
                                            }} placeholder="value (e.g. refund)" className="h-7 text-xs" />
                                            <Button size="sm" variant="ghost" onClick={() => {
                                                setForm({ ...form, escalation_rules: form.escalation_rules.filter((_, j) => j !== i) });
                                            }}>×</Button>
                                        </div>
                                    ))}
                                    <Button size="sm" variant="outline" onClick={() => setForm({ ...form, escalation_rules: [...form.escalation_rules, { ...DEFAULT_ESC_RULE }] })} data-testid="studio-add-escalation">Add rule</Button>
                                </div>
                            </div>
                            <div>
                                <Label className="text-xs">Qualification questions</Label>
                                <div className="mt-2 space-y-2">
                                    {form.qualification_questions.map((q, i) => (
                                        <div key={i} className="flex gap-2 items-center">
                                            <Input value={q.name} onChange={(e) => {
                                                const next = [...form.qualification_questions]; next[i] = { ...q, name: e.target.value };
                                                setForm({ ...form, qualification_questions: next });
                                            }} placeholder="field name" className="h-7 text-xs w-28" />
                                            <Input value={q.prompt} onChange={(e) => {
                                                const next = [...form.qualification_questions]; next[i] = { ...q, prompt: e.target.value };
                                                setForm({ ...form, qualification_questions: next });
                                            }} placeholder="prompt to ask" className="h-7 text-xs flex-1" />
                                            <label className="text-xs flex items-center gap-1"><input type="checkbox" checked={q.required} onChange={(e) => {
                                                const next = [...form.qualification_questions]; next[i] = { ...q, required: e.target.checked };
                                                setForm({ ...form, qualification_questions: next });
                                            }} />req</label>
                                            <Button size="sm" variant="ghost" onClick={() => setForm({ ...form, qualification_questions: form.qualification_questions.filter((_, j) => j !== i) })}>×</Button>
                                        </div>
                                    ))}
                                    <Button size="sm" variant="outline" onClick={() => setForm({ ...form, qualification_questions: [...form.qualification_questions, { ...DEFAULT_QQ }] })}>Add question</Button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="mt-4">
                        <Label className="text-xs">Version label (optional)</Label>
                        <Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="e.g. Friendlier tone Aug '26" data-testid="studio-label" />
                    </div>

                    <div className="mt-4 flex gap-2 flex-wrap">
                        <Button variant="outline" onClick={() => saveVersion(false)} disabled={busy} data-testid="studio-save-draft-btn">
                            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                            Save as draft
                        </Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={() => saveVersion(true)} disabled={busy} data-testid="studio-promote-btn">
                            <Send className="w-4 h-4 mr-2" /> Promote to live
                        </Button>
                    </div>
                </TabsContent>

                <TabsContent value="sandbox" className="mt-4">
                    <div className="rounded-2xl border-2 border-dashed border-amber-300 bg-amber-50/40 p-3 mb-3 text-xs text-amber-900 flex items-center gap-2">
                        <Sparkles className="w-4 h-4" />
                        Sandbox — talks against your live retrieval + tools BUT write tools do nothing (no bookings, no leads). Save the current draft first to test it.
                    </div>
                    <div className="rounded-2xl border border-brand-line bg-white flex flex-col h-[520px] overflow-hidden" data-testid="sandbox-chat">
                        <div className="px-4 py-2 border-b border-brand-line text-xs text-zinc-500 flex items-center justify-between">
                            <span>Testing: {form.label || `v${liveVersion?.version || "?"} (live)`}</span>
                            <Button size="sm" variant="ghost" onClick={resetSandbox} data-testid="sandbox-reset-btn"><RotateCcw className="w-3.5 h-3.5 mr-1" /> Reset</Button>
                        </div>
                        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 bg-brand-surface" data-testid="sandbox-messages">
                            {sandboxMsgs.map((m) => (
                                <div key={m.id} className={`flex ${m.role === "visitor" ? "justify-end" : "justify-start"}`} data-testid={`sandbox-msg-${m.role}`}>
                                    <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${m.role === "visitor" ? "bg-brand-ink text-white" : "bg-white border border-brand-line whitespace-pre-wrap"}`}>
                                        {m.content}
                                        {m.role === "ai" && (
                                            <div className="mt-1 text-[10px] uppercase tracking-widest text-zinc-400 flex gap-2 flex-wrap">
                                                <span>conf {(m.confidence || 0).toFixed(2)}</span>
                                                <span>action {m.action}</span>
                                                {m.tool_calls?.length > 0 && <span>tools: {m.tool_calls.map((t) => t.name).join(", ")}</span>}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                            {sandboxBusy && (
                                <div className="text-xs text-zinc-500 flex items-center gap-1"><Loader2 className="w-3.5 h-3.5 animate-spin" /> thinking…</div>
                            )}
                            {!sandboxMsgs.length && !sandboxBusy && (
                                <div className="text-xs text-zinc-400 text-center py-10">Send a message to start testing.</div>
                            )}
                        </div>
                        <form onSubmit={(e) => { e.preventDefault(); sandboxSend(); }} className="border-t border-brand-line p-2 bg-white flex gap-1.5">
                            <Input value={sandboxInput} onChange={(e) => setSandboxInput(e.target.value)}
                                placeholder="Ask something a visitor might ask…"
                                disabled={sandboxBusy}
                                data-testid="sandbox-input" />
                            <Button type="submit" size="sm" disabled={sandboxBusy || !sandboxInput.trim()} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="sandbox-send-btn">
                                <Send className="w-4 h-4" />
                            </Button>
                        </form>
                    </div>
                </TabsContent>

                <TabsContent value="history" className="mt-4">
                    <div className="rounded-2xl border border-brand-line bg-white overflow-hidden">
                        {versions.map((v) => (
                            <div key={v.id} className={`px-5 py-3 border-b border-brand-line flex items-center justify-between gap-3 ${v.is_live ? "bg-emerald-50/40" : ""}`} data-testid={`version-row-${v.version}`}>
                                <div className="min-w-0">
                                    <div className="flex items-center gap-2">
                                        <GitBranch className="w-3.5 h-3.5 text-brand-copper" />
                                        <span className="font-mono text-sm text-brand-ink">v{v.version}</span>
                                        {v.is_live && <Badge className="bg-emerald-100 text-emerald-800">LIVE</Badge>}
                                        {v.label && <span className="text-xs text-zinc-500 truncate">{v.label}</span>}
                                    </div>
                                    <div className="text-xs text-zinc-500 mt-0.5 truncate">
                                        Tools: {(v.allowed_tools || []).join(", ") || "none"} · conf ≥ {v.confidence_threshold} · {v.model}
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <Button size="sm" variant="ghost" onClick={() => { setForm(versionToForm(v)); setTab("config"); toast.info(`Loaded v${v.version} into editor`); }} data-testid={`version-load-${v.version}`}>Load</Button>
                                    {!v.is_live && (
                                        <Button size="sm" variant="outline" onClick={() => promote(v.id)} data-testid={`version-promote-${v.version}`}>
                                            <History className="w-3.5 h-3.5 mr-1" /> Rollback to this
                                        </Button>
                                    )}
                                </div>
                            </div>
                        ))}
                        {!versions.length && <div className="p-10 text-center text-zinc-500">No versions yet.</div>}
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
}
