# ZANELVO — HANDOFF ROUND 10 (for a NEW chat)

_Living document for Round 10. Read this first, then `HANDOFF_ROUND_9.md`, then `HANDOFF_ROUND_8.md` §2
(the authoritative A–N backlog with "how to build" notes). Source code + fresh test evidence override any
older ✅ claims._

---------------------------------------------------------------------------------------------------
## 0. HOW TO CONTINUE (first 10 minutes) — env is WIPED on import
---------------------------------------------------------------------------------------------------
```bash
env | grep -i preview_endpoint                       # preview host changes per job
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && \
SEK=$(python3 -c "import secrets;print(secrets.token_urlsafe(32))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
SECRETS_ENC_KEY=$SEK
EMERGENT_LLM_KEY=<emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
SEED_DEMO=true
CORS_ORIGINS=*
EOF
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile
sudo supervisorctl restart backend frontend && sleep 30 && curl -s localhost:8001/api/health
cat /app/memory/test_credentials.md      # regenerated with FRESH passwords on seed; send the NEW ones
```
Logins: owner `/login` → `/app`; founder/staff `/staff/login` (`POST /api/staff/auth/login`);
public demo `/site/demo-home-services`; storefront `/store/<org_id>`.

---------------------------------------------------------------------------------------------------
## 1. ROUND 10 PROGRESS TRACKER (⬜ todo · 🟨 in progress · ✅ done & verified)
---------------------------------------------------------------------------------------------------
### Gate 1 leftovers (P0)
- ✅ 1G Inbound email: Resend Svix signature verification + org resolution (to-address → tenant inbox) — curl-verified
- ✅ 1B-cookie JWT → HttpOnly cookie + CSRF double-submit (dual-mode: bearer still accepted) — curl + browser verified
- 🔒 1F-paypal PayPal signed webhook — blocked on PayPal creds (live rail refused until then)

### Gate 2 — regression of untested modules
- ✅ backend regression run (testing agent, 55/66 — all 11 'failures' were harness path/expectation errors, re-verified manually: wildcard tax + public blog OK). Frontend regression: see §3.

### Gate 3 — website breadth
- ✅ Template gallery + build-from-scratch (`/app/website/new`) — API + UI verified (8 templates)
- ✅ Section regeneration (`POST /api/editor/website/blocks/{id}/regenerate`, feature=section_regenerate, ledger row verified) + Inspector UI
- ✅ Blog (owner CRUD + AI draft + public list/article + `blog_list` block + sitemap) — API + UI verified

### Gate 4 — commerce depth
- ✅ Product options matrix + barcode + related_ids · stock reservations (30-min holds) · tax rates by region · order status history/notes/returns (RMA) · product CSV export — curl + UI verified

### Gate 5/6 — automation / staff
- ✅ Workflow graph model + runner + visual builder UI (/app/workflows, @xyflow/react) — API + UI verified
- ✅ Staff pricing-history UI (StaffPlans.jsx 'Show pricing history') · error-events view (founder Health page `ErrorEvents`)

### Docs
- ⬜ CHANGELOG / SECOND_RUN_AUDIT / PRD / test_result.md updated at end of round

---------------------------------------------------------------------------------------------------
## 2. WHAT ROUND 10 SHIPPED (filled in as tasks complete)
---------------------------------------------------------------------------------------------------
(see tracker above; details appended per task below)

### 2.1 Gate 1B-cookie — HttpOnly session cookies + CSRF (dual-mode)
- `backend/app/services/session_cookies.py`: `zv_access` (HttpOnly, SameSite=Lax, Secure on https) + `zv_csrf`
  (readable). `server.py::_hardening` mirrors `access_token` from 200 responses of `TOKEN_ISSUING_PATHS`
  (auth login/signup/2fa-verify, staff login/2fa-verify, oauth session-exchange) into cookies; clears them on
  `POST /api/auth/logout` (new endpoint in `routes/auth.py`).
- `deps._extract_token`: Bearer header first; else cookie. Cookie-auth on POST/PUT/PATCH/DELETE requires
  `X-CSRF-Token` == `zv_csrf` else 403 `{code:"csrf_failed"}`.
- Frontend: `lib/api.js` → `withCredentials:true`, sends `X-CSRF-Token`, exports `authHeaders()` for raw fetch
  downloads (DataTools.jsx, Marketing.jsx). `context/AuthContext.jsx` stores ONLY `revenue_os.session="1"` +
  profile; the raw JWT is never written to localStorage anymore (legacy key removed on first persist).
  Impersonation tokens (founder → tenant) still ride in localStorage as short-lived Bearer tokens (by design).
- Test: login via curl -c → `/api/auth/me` with cookie only = 200; PUT without header = 403; with header = 200.

### 2.2 Gate 1G — inbound email provider signatures + tenant routing
- `routes/email_inbound.py`: `verify_svix()` (Resend/Svix HMAC over `id.ts.body`, 5-min tolerance, multi-sig).
  New staff config field `email.resend_signing_secret` (whsec_…, encrypted at rest, `PUT /api/staff/email/config`).
  When set, Resend webhooks MUST be signed; otherwise shared secret; otherwise dev-only open / prod refuse.
- `resolve_org_for_address(to)`: organizations.inbound_email|contact_email → tenant_integrations.email.from_email|
  reply_to → verified `db.domains` hostname. Matched mail creates CRM contact + conversation + message in the
  TENANT unified inbox (`_deliver_to_tenant`); unmatched → platform staff inbox. `inbox_messages` rows carry
  `org_id`, `auth_method`, `routed_to`. Idempotent by provider event id.
- Owner action to receive mail for a tenant: set `organizations.inbound_email` (no UI yet → add to Settings).

### 2.3 Gate 3 — website breadth
- `services/site_templates.py`: 8 deterministic industry templates (props match the React block renderers exactly:
  services_grid.services[{name,description}], faq.items[{question,answer}], pricing_table.plans[], gallery.images[{url,caption}]…).
  `GET /api/editor/templates`; `POST /api/editor/website/apply-template {template_id|null, mode: replace|new_site, name}`
  (null = blank starter; new_site respects plan site limit and activates the new site).
- `POST /api/editor/website/blocks/{id}/regenerate {instruction?, tone?}` — LLM rewrites text props only (keeps
  image/href/fields/…); `EditorProvider.regenerateBlock` flushes autosave first, Inspector shows "Regenerate copy".
- `routes/blog.py` (+ `public_router`): `/api/blog/posts` CRUD, `POST /api/blog/posts/ai-draft` (feature=blog_draft),
  public `/api/public/sites/{slug}/blog[/{post_slug}]`; sitemap.xml lists `/site/{slug}/blog/{post}`.
  Frontend: `pages/dashboard/Blog.jsx` (/app/blog, nav Build → Blog), `pages/public/PublicBlog.jsx`
  (/site/:slug/blog[/:postSlug]), `components/blocks/BlogListBlock.jsx` registered as `blog_list` (also in AddSectionMenu).
- `models.Block.type` gained `blog_list`; `editor.create_block` now accepts every BLOCK_LIBRARY type (was a stale 8-type allow-list).
- `pages/dashboard/WebsiteNew.jsx` (/app/website/new): interview / blank / template gallery on one screen; Website.jsx links to it.

### 2.4 Gate 4 — commerce depth
- `services/commerce_ext.py`: `available_stock` (stock − active holds), `reserve_stock/settle_reservation/expire_reservations`
  (`db.stock_reservations`, TTL 30 min), `compute_tax` (most-specific rule: country+region > country > "*", inclusive
  supported), `push_status`, `variant_matrix(options)`.
- `routes/commerce_ext.py` (mounted /api/store + /api/public/store): `GET/PUT /store/tax-rates`, public
  `GET /public/store/{org}/tax-preview`, `GET /store/products/export.csv`, `POST /store/products/variant-matrix`,
  `GET /store/reservations`, `POST /store/orders/{id}/notes`, `GET /store/orders/{id}/history`, `POST /store/orders/{id}/return` (RMA, optional restock).
- `routes/store.py`: ProductIn/Patch/_out gained `options`, `barcode`, `related_ids`; buy-now uses available stock,
  computes `tax_cents` server-side (BuyNowReq.region_code), stores `status_history`, creates a reservation; finalize
  consumes it + pushes "paid"; cancel releases it; fulfill/refund/cancel push history. `_order_out` exposes tax/history/notes/returns.
- UI: Products.jsx (barcode, options matrix → "Generate variants", Export CSV), Orders.jsx `OrderHistoryPanel`
  (timeline, internal notes, Record return), new `pages/dashboard/TaxSettings.jsx` at /app/store/tax (nav Sell → Tax).
- Not done: customer accounts/saved carts, subscriptions (Stripe Billing), gift cards, bundles UI, automatic discounts.

### 2.5 Gate 5 — visual workflow engine
- `services/workflows.py`: graph {nodes[{id,type,config,position}], edges[{from,to,when}]}; 13 node types (trigger,
  condition yes/no, delay, wait_until, send_email, add_tag, remove_tag, create_task, notify_owner, webhook (netsafe
  https+public only), ai_generate (metered feature=`workflow:<id>`, monthly `settings.cost_cap_usd`), approval, end);
  21 triggers. Persisted runs in `db.workflow_runs` (running/waiting(next_at)/awaiting_approval/completed/failed/
  dead_letter/cancelled); retries ×3 with backoff → dead-letter (replay via `/runs/{id}/retry`); test_mode = dry run
  (no sends/mutations, delays+approvals skipped). `scheduler_loop()` (15 s) resumes due waits; started in server startup.
  Emails go via the tenant's provider (`inbox._get_provider_config`) and are logged in `db.messages` (simulated flag honest).
- Trigger hooks: `marketing.fire_trigger` now also calls `workflows.fire` (legacy automations untouched); new emits:
  crm `new_lead` (contact created), bookings `quote_sent`, store `order_paid`. `VALID_TRIGGERS` widened.
- `routes/workflows.py` (/api/workflows): catalog, CRUD, from-template (3 templates), validate, publish (versions[]),
  pause, test-run, run (manual), runs, runs/pending-approvals, runs/{id}/approve|reject|retry.
- UI `pages/dashboard/Workflows.jsx` (nav Grow → Workflows): list + templates + pending approvals; Builder with
  React-Flow canvas (custom StepNode, yes/no handles), step palette, node inspector, limits, validate/test/publish/pause,
  run history with retry. New dep `@xyflow/react@^12` (already in package.json → `yarn install` restores it).
- Not done: SMS/WhatsApp nodes (no provider), A/B split node, per-node analytics chart, drag-from-palette (click-to-add instead).

### 2.6 Founder error-events + misc
- Account page: 'Inbound email address' field → `PUT /api/auth/profile {inbound_email}` (422 invalid / 409 clash) → drives inbound routing (§2.2).
- Founder Health page (`pages/founder/Other.jsx::ErrorEvents`) lists `GET /api/founder/error-events`.
- `server.py::_unhandled` writes redacted rows to `db.error_events`; `GET /api/founder/error-events?limit=`.

