"""Google (Emergent-managed) + Apple Sign-In adapters.

- Google: uses the Emergent managed auth flow. Frontend redirects to
  `https://auth.emergentagent.com/?redirect=<callback>`. On return the URL
  fragment contains `session_id=...`. Frontend POSTs it here; we exchange it
  server-side with Emergent's session-data endpoint, upsert the user in Mongo,
  auto-provision an org for new users, and return our own JWT so the rest of
  the app treats them identically to email-signup users.

- Apple: full adapter scaffold. Only reports as `configured=True` and only
  accepts callbacks when all of APPLE_TEAM_ID, APPLE_KEY_ID, APPLE_PRIVATE_KEY,
  APPLE_SERVICE_ID are set. The UI reads /social-status and hides the Apple
  button when unconfigured — no dead button is rendered.
"""
from __future__ import annotations

import logging
import os
import re
from typing import Optional

import httpx
from bson import ObjectId
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from ..db import get_db, utc_now_iso
from ..models import User
from ..security import create_access_token, hash_password

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/auth", tags=["auth-oauth"])

EMERGENT_SESSION_DATA_URL = (
    "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data"
)


def _apple_configured() -> bool:
    return all(
        os.environ.get(k)
        for k in ("APPLE_TEAM_ID", "APPLE_KEY_ID", "APPLE_PRIVATE_KEY", "APPLE_SERVICE_ID")
    )


def _slug_from_email(email: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", email.split("@")[0].lower()).strip("-")
    return s or "workspace"


class SessionExchangeReq(BaseModel):
    session_id: str


class SocialAuthResp(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict
    needs_onboarding: bool = False
    provider: str = "google"


@router.get("/social-status")
async def social_status() -> dict:
    """Which social providers are usable right now.

    Google is always available (Emergent managed — no owner credentials needed).
    Apple requires all four APPLE_* env vars to be present.
    """
    return {
        "google": {"available": True, "provider": "emergent_managed"},
        "apple": {
            "available": _apple_configured(),
            "provider": "apple_signin",
            "requires": ["APPLE_TEAM_ID", "APPLE_KEY_ID", "APPLE_PRIVATE_KEY", "APPLE_SERVICE_ID"],
        },
    }


@router.post("/session-exchange", response_model=SocialAuthResp)
async def google_session_exchange(req: SessionExchangeReq, request: Request):
    """Server-side session_id → user exchange with Emergent's session-data endpoint.
    Frontend must never call session-data directly.
    """
    if not req.session_id or len(req.session_id) < 8:
        raise HTTPException(400, "Missing session_id")
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(
                EMERGENT_SESSION_DATA_URL,
                headers={"X-Session-ID": req.session_id},
            )
    except httpx.HTTPError as e:
        logger.exception("Emergent session-data unreachable: %s", e)
        raise HTTPException(502, "Google auth service unreachable")
    if r.status_code != 200:
        logger.warning("Emergent session-data returned %s: %s", r.status_code, r.text[:200])
        raise HTTPException(401, "Google session invalid or expired")
    data = r.json() or {}
    email = (data.get("email") or "").lower().strip()
    name = data.get("name") or None
    if not email:
        raise HTTPException(401, "Google session missing email")

    db = get_db()
    existing = await db.users.find_one({"email": email})
    from .. import config
    # Founder auto-promotion by email match is a NON-PRODUCTION convenience only. In production a
    # founder is provisioned explicitly (bootstrap CLI / staff invite) — never granted by OAuth email.
    is_founder_email = (email in config.FOUNDER_EMAILS) and config.is_founder_autopromote_allowed()
    if existing:
        user = User.from_mongo(existing)
        org = None
        if user.org_id:
            try:
                org = await db.organizations.find_one({"_id": ObjectId(user.org_id)})
            except Exception:  # noqa: BLE001
                org = None
        # Existing user: link Google identity, refresh full_name if empty.
        upd: dict = {"google_linked": True, "updated_at": utc_now_iso()}
        if not existing.get("full_name") and name:
            upd["full_name"] = name
        if not existing.get("email_verified"):
            upd["email_verified"] = True
        # Owner lock: founder emails are always platform founders.
        if is_founder_email and user.role != "platform_founder":
            upd["role"] = "platform_founder"
            user.role = "platform_founder"
        await db.users.update_one({"_id": existing["_id"]}, {"$set": upd})
        token = create_access_token(user.id, user.org_id, user.role)
        # Onboarding needed iff their org has no business profile yet.
        needs_ob = False
        if user.org_id:
            bp = await db.business_profiles.find_one({"org_id": user.org_id})
            needs_ob = bp is None
        return SocialAuthResp(
            access_token=token,
            user={
                "id": user.id, "email": user.email, "role": user.role,
                "org_id": user.org_id, "full_name": name or user.full_name,
                "org_name": (org or {}).get("name") if org else None,
                "org_slug": (org or {}).get("slug") if org else None,
                "email_verified": True,
            },
            needs_onboarding=needs_ob,
        )

    # New user via Google.
    # Owner lock: a founder email becomes a platform_founder with NO org.
    if is_founder_email:
        unusable_pw = hash_password(os.urandom(32).hex())
        fres = await db.users.insert_one({
            "email": email,
            "password_hash": unusable_pw,
            "full_name": name,
            "org_id": None,
            "role": "platform_founder",
            "email_verified": True,
            "google_linked": True,
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        fuser = User.from_mongo(await db.users.find_one({"_id": fres.inserted_id}))
        ftoken = create_access_token(fuser.id, None, "platform_founder")
        return SocialAuthResp(
            access_token=ftoken,
            user={
                "id": fuser.id, "email": fuser.email, "role": "platform_founder",
                "org_id": None, "full_name": name, "org_name": None,
                "org_slug": None, "email_verified": True,
            },
            needs_onboarding=False,
        )

    # Regular new user via Google — auto-provision an org (same as email signup path).
    base_slug = _slug_from_email(email)
    slug, n = base_slug, 1
    while await db.organizations.find_one({"slug": slug}):
        n += 1
        slug = f"{base_slug}-{n}"
    org_res = await db.organizations.insert_one({
        "slug": slug,
        "name": (name or email.split("@")[0]) + "'s workspace",
        "industry": None,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    org_id = str(org_res.inserted_id)

    # No password on Google-only accounts: store an unusable random hash so
    # /api/auth/login never accepts an empty password. Owner can set a
    # password later via /api/auth/password-reset/request.
    unusable_pw = hash_password(os.urandom(32).hex())
    user_res = await db.users.insert_one({
        "email": email,
        "password_hash": unusable_pw,
        "full_name": name,
        "org_id": org_id,
        "role": "owner",
        "email_verified": True,
        "google_linked": True,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    user = User.from_mongo(await db.users.find_one({"_id": user_res.inserted_id}))
    org = await db.organizations.find_one({"_id": org_res.inserted_id})
    token = create_access_token(user.id, user.org_id, user.role)
    return SocialAuthResp(
        access_token=token,
        user={
            "id": user.id, "email": user.email, "role": user.role,
            "org_id": user.org_id, "full_name": name,
            "org_name": (org or {}).get("name"),
            "org_slug": (org or {}).get("slug"),
            "email_verified": True,
        },
        needs_onboarding=True,
    )


class AppleCallbackReq(BaseModel):
    identity_token: str
    authorization_code: Optional[str] = None
    full_name: Optional[str] = None


@router.post("/apple/callback", response_model=SocialAuthResp)
async def apple_callback(req: AppleCallbackReq, request: Request):
    """Apple Sign-In adapter. Fully-scaffolded route; refuses to run without
    owner-provided Apple Developer credentials.

    Steps once configured: verify identity_token against Apple's JWKS
    (https://appleid.apple.com/auth/keys), issue a client_secret JWT with
    APPLE_KEY_ID + APPLE_PRIVATE_KEY, exchange authorization_code with
    https://appleid.apple.com/auth/token (or accept the identity_token when it
    contains a verified email), then upsert user + return our JWT.
    """
    if not _apple_configured():
        raise HTTPException(
            status_code=503,
            detail=(
                "Apple Sign-In is not configured on this workspace. "
                "Owner must provide APPLE_TEAM_ID, APPLE_KEY_ID, APPLE_PRIVATE_KEY, "
                "APPLE_SERVICE_ID in backend/.env — see /app/memory/OWNER_SETUP_CHECKLIST.md."
            ),
        )
    # When configured, implement full flow: (1) fetch Apple JWKS, (2) verify
    # identity_token signature + issuer + audience, (3) extract sub + email
    # (email may be relay-hidden). Upsert user by sub, mirror the Google path.
    raise HTTPException(
        status_code=501,
        detail="Apple Sign-In configured but verification implementation pending.",
    )
