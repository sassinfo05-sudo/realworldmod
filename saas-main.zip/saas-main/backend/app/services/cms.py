"""Dynamic CMS & Extensions Foundation — core service.

Tenant-scoped custom data collections, items, dynamic page templates, safe public
projections, plan limits, revisions/rollback, and an SSRF-hardened external REST connector.

Security invariants:
  * Every document carries `org_id`, resolved ONLY from authenticated server context.
  * No arbitrary physical Mongo collections from customer names — everything lives in the
    fixed shared collections below, filtered by org_id.
  * Public reads use safe projections: only published, non-archived items; private fields
    and audit metadata are stripped; never another tenant's data.
  * Rich-text/HTML values are sanitised server-side with the strict nh3 allow-list.
  * The external connector blocks localhost / private / link-local / metadata IPs, non-HTTPS,
    non-approved ports, oversized responses, and re-validates every redirect (DNS-rebinding safe).
"""
from __future__ import annotations

import ipaddress
import re
import socket
import uuid
from typing import Any, Dict, List, Optional, Tuple

from fastapi import HTTPException

from ..db import get_db, utc_now_iso
from .svg_safe import sanitize_html

# ---- fixed shared collections (never per-tenant physical collections) ----
DEFS = "content_collection_definitions"
ITEMS = "content_items"
ITEM_REV = "content_item_revisions"
TEMPLATES = "dynamic_page_templates"
TEMPLATE_REV = "dynamic_page_template_revisions"
CONNECTIONS = "external_data_connections"
CMS_AUDIT = "cms_audit"

FIELD_TYPES = {
    "short_text", "rich_text", "number", "currency", "boolean", "date", "datetime",
    "media", "url", "email", "phone", "single_select", "multi_select", "location",
    "reference", "multi_reference", "slug",
}

MAX_FIELDS = 60
MAX_PAGE_SIZE = 100
CSV_MAX_BYTES = 5 * 1024 * 1024
CSV_MAX_ROWS = 5000
CSV_MAX_COLS = 60

# ---------------------------------------------------------------------------
# Plan limits (DB-backed defaults; founder-editable via platform_settings.cms_limits)
# Internal plan codes: free / launch / revenue / autopilot / scale
# ---------------------------------------------------------------------------
DEFAULT_CMS_LIMITS: Dict[str, Dict[str, int]] = {
    "free":      {"max_collections": 1,   "max_items": 100,    "max_connectors": 0},
    "launch":    {"max_collections": 3,   "max_items": 1000,   "max_connectors": 0},
    "revenue":   {"max_collections": 20,  "max_items": 25000,  "max_connectors": 2},
    "autopilot": {"max_collections": 100, "max_items": 250000, "max_connectors": 10},
    "scale":     {"max_collections": 1000, "max_items": 5000000, "max_connectors": 50},
}


async def cms_limits(org_id: str) -> Dict[str, int]:
    from .entitlements import get_org_plan
    plan = await get_org_plan(org_id)
    limits = dict(DEFAULT_CMS_LIMITS.get(plan) or DEFAULT_CMS_LIMITS["free"])
    try:
        from .platform_settings import SETTINGS_KEY as _SK
        doc = await get_db().platform_settings.find_one({"key": _SK}, {"cms_limits": 1})
        override = ((doc or {}).get("cms_limits") or {}).get(plan)
        if isinstance(override, dict):
            for k in ("max_collections", "max_items", "max_connectors"):
                if k in override:
                    limits[k] = int(override[k])
    except Exception:  # noqa: BLE001
        pass
    limits["plan"] = plan  # type: ignore
    return limits


def _now() -> str:
    return utc_now_iso()


def _slugify(v: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (v or "").strip().lower()).strip("-")
    return s or uuid.uuid4().hex[:8]


async def audit(org_id: str, action: str, user_id: Optional[str], meta: Dict[str, Any]) -> None:
    try:
        await get_db()[CMS_AUDIT].insert_one({
            "id": uuid.uuid4().hex, "org_id": org_id, "action": action,
            "user_id": user_id, "meta": meta, "created_at": _now(),
        })
    except Exception:  # noqa: BLE001
        pass


# ---------------------------------------------------------------------------
# Field / schema validation
# ---------------------------------------------------------------------------
def _norm_field(f: Dict[str, Any]) -> Dict[str, Any]:
    ftype = f.get("type")
    if ftype not in FIELD_TYPES:
        raise HTTPException(400, f"Unsupported field type: {ftype}")
    key = _slugify(f.get("key") or f.get("label") or "").replace("-", "_")
    if not key:
        raise HTTPException(400, "field key required")
    out = {
        "key": key,
        "label": (f.get("label") or key)[:120],
        "type": ftype,
        "required": bool(f.get("required")),
        "unique": bool(f.get("unique")),
        "searchable": bool(f.get("searchable")),
        "private": bool(f.get("private")),
        "default": f.get("default"),
        "options": [str(o)[:200] for o in (f.get("options") or [])][:200],
        "ref_collection": f.get("ref_collection"),
        "validation": f.get("validation") or {},
    }
    return out


def _validate_value(field: Dict[str, Any], value: Any) -> Any:
    """Coerce + validate a single value against its field definition. Raises 400 on error."""
    t = field["type"]
    if value is None or value == "":
        if field.get("required") and t != "boolean":
            raise HTTPException(400, {"field": field["key"], "error": "required"})
        return None if t != "boolean" else bool(value)
    try:
        if t in ("short_text", "url", "email", "phone", "slug", "single_select", "location"):
            s = str(value)[:2000]
            if t == "email" and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", s):
                raise ValueError("invalid email")
            if t == "url" and not re.match(r"^https?://", s):
                raise ValueError("invalid url")
            if t == "single_select" and field.get("options") and s not in field["options"]:
                raise ValueError("not an allowed option")
            return s
        if t == "rich_text":
            return sanitize_html(str(value), max_len=200_000)
        if t in ("number", "currency"):
            return float(value)
        if t == "boolean":
            return bool(value)
        if t in ("date", "datetime"):
            return str(value)[:40]
        if t == "media":
            return str(value)[:2000]
        if t == "multi_select":
            vals = [str(x)[:200] for x in (value if isinstance(value, list) else [value])]
            if field.get("options"):
                for x in vals:
                    if x not in field["options"]:
                        raise ValueError("not an allowed option")
            return vals
        if t == "reference":
            return str(value)[:64]
        if t == "multi_reference":
            return [str(x)[:64] for x in (value if isinstance(value, list) else [value])][:200]
    except (ValueError, TypeError) as e:
        raise HTTPException(400, {"field": field["key"], "error": str(e)})
    return value


def validate_item_values(definition: Dict[str, Any], values: Dict[str, Any]) -> Dict[str, Any]:
    fields = {f["key"]: f for f in (definition.get("fields") or [])}
    out: Dict[str, Any] = {}
    errors: List[Dict[str, str]] = []
    for key, field in fields.items():
        raw = values.get(key, field.get("default"))
        try:
            out[key] = _validate_value(field, raw)
        except HTTPException as e:
            d = e.detail if isinstance(e.detail, dict) else {"field": key, "error": str(e.detail)}
            errors.append(d)
    if errors:
        raise HTTPException(400, {"error": "validation_failed", "errors": errors})
    return out


def public_projection(definition: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    """Strip private fields + audit metadata for public consumption."""
    private = {f["key"] for f in (definition.get("fields") or []) if f.get("private")}
    vals = {k: v for k, v in (item.get("values") or {}).items() if k not in private}
    return {"id": item["id"], "slug": item.get("slug"), "values": vals,
            "updated_at": item.get("updated_at")}


# ---------------------------------------------------------------------------
# Collection definitions
# ---------------------------------------------------------------------------
async def create_collection(org_id: str, user_id: str, name: str, fields: List[Dict[str, Any]],
                            display_field: Optional[str] = None) -> Dict[str, Any]:
    db = get_db()
    lim = await cms_limits(org_id)
    count = await db[DEFS].count_documents({"org_id": org_id, "archived": {"$ne": True}})
    if count >= lim["max_collections"]:
        raise HTTPException(402, {"error": "cms_collection_limit", "limit": lim["max_collections"],
                                  "plan": lim.get("plan"), "upgrade_url": "/app/billing",
                                  "message": f"Your plan allows {lim['max_collections']} collection(s). Upgrade to add more."})
    if len(fields or []) > MAX_FIELDS:
        raise HTTPException(400, f"Too many fields (max {MAX_FIELDS}).")
    norm_fields = [_norm_field(f) for f in (fields or [])]
    keys = [f["key"] for f in norm_fields]
    if len(keys) != len(set(keys)):
        raise HTTPException(400, "Duplicate field keys.")
    internal_id = _slugify(name)
    if await db[DEFS].find_one({"org_id": org_id, "internal_id": internal_id}):
        internal_id = f"{internal_id}-{uuid.uuid4().hex[:4]}"
    doc = {
        "id": uuid.uuid4().hex, "org_id": org_id, "name": name[:120],
        "internal_id": internal_id, "fields": norm_fields,
        "display_field": display_field or (keys[0] if keys else None),
        "schema_version": 1, "archived": False,
        "created_by": user_id, "created_at": _now(), "updated_at": _now(),
    }
    await db[DEFS].insert_one(dict(doc))
    doc.pop("_id", None)
    await audit(org_id, "collection.create", user_id, {"collection_id": doc["id"], "name": name})
    return doc


async def get_collection(org_id: str, cid: str) -> Dict[str, Any]:
    doc = await get_db()[DEFS].find_one({"org_id": org_id, "id": cid}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Collection not found")
    return doc


async def list_collections(org_id: str, include_archived: bool = False) -> List[Dict[str, Any]]:
    q: Dict[str, Any] = {"org_id": org_id}
    if not include_archived:
        q["archived"] = {"$ne": True}
    out = []
    async for d in get_db()[DEFS].find(q, {"_id": 0}).sort("created_at", -1):
        cnt = await get_db()[ITEMS].count_documents({"org_id": org_id, "collection_id": d["id"], "archived": {"$ne": True}})
        d["item_count"] = cnt
        out.append(d)
    return out


async def update_collection(org_id: str, user_id: str, cid: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    db = get_db()
    doc = await get_collection(org_id, cid)
    upd: Dict[str, Any] = {"updated_at": _now()}
    if "name" in patch and patch["name"]:
        upd["name"] = str(patch["name"])[:120]
    if "display_field" in patch:
        upd["display_field"] = patch["display_field"]
    if "archived" in patch:
        upd["archived"] = bool(patch["archived"])
    if "fields" in patch and patch["fields"] is not None:
        if len(patch["fields"]) > MAX_FIELDS:
            raise HTTPException(400, f"Too many fields (max {MAX_FIELDS}).")
        norm = [_norm_field(f) for f in patch["fields"]]
        keys = [f["key"] for f in norm]
        if len(keys) != len(set(keys)):
            raise HTTPException(400, "Duplicate field keys.")
        upd["fields"] = norm
        upd["schema_version"] = int(doc.get("schema_version") or 1) + 1
    await db[DEFS].update_one({"org_id": org_id, "id": cid}, {"$set": upd})
    await audit(org_id, "collection.update", user_id, {"collection_id": cid, "keys": list(upd.keys())})
    return await get_collection(org_id, cid)


# ---------------------------------------------------------------------------
# Items
# ---------------------------------------------------------------------------
async def _unique_check(org_id: str, cid: str, definition: Dict[str, Any],
                        values: Dict[str, Any], exclude_id: Optional[str] = None) -> None:
    db = get_db()
    for f in definition.get("fields") or []:
        if f.get("unique") and values.get(f["key"]) not in (None, ""):
            q = {"org_id": org_id, "collection_id": cid, "archived": {"$ne": True},
                 f"values.{f['key']}": values[f["key"]]}
            if exclude_id:
                q["id"] = {"$ne": exclude_id}
            if await db[ITEMS].find_one(q, {"_id": 1}):
                raise HTTPException(409, {"error": "unique_violation", "field": f["key"]})


async def _resolve_slug(org_id: str, cid: str, definition: Dict[str, Any], values: Dict[str, Any],
                        exclude_id: Optional[str] = None) -> str:
    db = get_db()
    slug_field = next((f["key"] for f in (definition.get("fields") or []) if f["type"] == "slug"), None)
    base = None
    if slug_field and values.get(slug_field):
        base = _slugify(str(values[slug_field]))
    elif definition.get("display_field") and values.get(definition["display_field"]):
        base = _slugify(str(values[definition["display_field"]]))
    base = base or uuid.uuid4().hex[:8]
    slug = base
    n = 1
    while True:
        q = {"org_id": org_id, "collection_id": cid, "slug": slug}
        if exclude_id:
            q["id"] = {"$ne": exclude_id}
        if not await db[ITEMS].find_one(q, {"_id": 1}):
            return slug
        n += 1
        slug = f"{base}-{n}"


async def create_item(org_id: str, user_id: str, cid: str, values: Dict[str, Any],
                      status: str = "published") -> Dict[str, Any]:
    db = get_db()
    definition = await get_collection(org_id, cid)
    lim = await cms_limits(org_id)
    total = await db[ITEMS].count_documents({"org_id": org_id, "archived": {"$ne": True}})
    if total >= lim["max_items"]:
        raise HTTPException(402, {"error": "cms_item_limit", "limit": lim["max_items"],
                                  "plan": lim.get("plan"), "upgrade_url": "/app/billing",
                                  "message": f"Your plan allows {lim['max_items']} items. Upgrade to add more."})
    clean = validate_item_values(definition, values)
    await _unique_check(org_id, cid, definition, clean)
    slug = await _resolve_slug(org_id, cid, definition, clean)
    doc = {
        "id": uuid.uuid4().hex, "org_id": org_id, "collection_id": cid,
        "values": clean, "slug": slug, "status": ("published" if status == "published" else "draft"),
        "archived": False, "schema_version": definition.get("schema_version", 1),
        "created_by": user_id, "created_at": _now(), "updated_at": _now(),
    }
    await db[ITEMS].insert_one(dict(doc))
    doc.pop("_id", None)
    await _snapshot_item(org_id, doc, user_id)
    await audit(org_id, "item.create", user_id, {"collection_id": cid, "item_id": doc["id"]})
    return doc


async def _snapshot_item(org_id: str, item: Dict[str, Any], user_id: Optional[str]) -> None:
    try:
        await get_db()[ITEM_REV].insert_one({
            "id": uuid.uuid4().hex, "org_id": org_id, "item_id": item["id"],
            "collection_id": item["collection_id"], "values": item.get("values"),
            "slug": item.get("slug"), "status": item.get("status"),
            "created_by": user_id, "created_at": _now(),
        })
    except Exception:  # noqa: BLE001
        pass


async def update_item(org_id: str, user_id: str, item_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    db = get_db()
    item = await db[ITEMS].find_one({"org_id": org_id, "id": item_id}, {"_id": 0})
    if not item:
        raise HTTPException(404, "Item not found")
    definition = await get_collection(org_id, item["collection_id"])
    upd: Dict[str, Any] = {"updated_at": _now()}
    if "values" in patch and patch["values"] is not None:
        merged = {**(item.get("values") or {}), **patch["values"]}
        clean = validate_item_values(definition, merged)
        await _unique_check(org_id, item["collection_id"], definition, clean, exclude_id=item_id)
        upd["values"] = clean
        upd["slug"] = await _resolve_slug(org_id, item["collection_id"], definition, clean, exclude_id=item_id)
    if "status" in patch:
        upd["status"] = "published" if patch["status"] == "published" else "draft"
    if "archived" in patch:
        upd["archived"] = bool(patch["archived"])
    await db[ITEMS].update_one({"org_id": org_id, "id": item_id}, {"$set": upd})
    fresh = await db[ITEMS].find_one({"org_id": org_id, "id": item_id}, {"_id": 0})
    await _snapshot_item(org_id, fresh, user_id)
    await audit(org_id, "item.update", user_id, {"item_id": item_id})
    return fresh


async def list_items(org_id: str, cid: str, *, q: Optional[str] = None, page: int = 1,
                     page_size: int = 50, sort: str = "-created_at",
                     include_archived: bool = False) -> Dict[str, Any]:
    db = get_db()
    await get_collection(org_id, cid)  # 404 if not owned
    page = max(1, int(page))
    page_size = min(MAX_PAGE_SIZE, max(1, int(page_size)))
    query: Dict[str, Any] = {"org_id": org_id, "collection_id": cid}
    if not include_archived:
        query["archived"] = {"$ne": True}
    if q:
        # safe regex: escape user input to avoid ReDoS/injection
        rx = {"$regex": re.escape(str(q)[:120]), "$options": "i"}
        query["$or"] = [{"slug": rx}]
        definition = await get_collection(org_id, cid)
        for f in definition.get("fields") or []:
            if f.get("searchable") and f["type"] in ("short_text", "rich_text", "email", "url", "single_select"):
                query["$or"].append({f"values.{f['key']}": rx})
    field = sort.lstrip("-")
    direction = -1 if sort.startswith("-") else 1
    sort_key = field if field in ("created_at", "updated_at", "slug") else f"values.{field}"
    total = await db[ITEMS].count_documents(query)
    cursor = db[ITEMS].find(query, {"_id": 0}).sort(sort_key, direction).skip((page - 1) * page_size).limit(page_size)
    return {"items": [d async for d in cursor], "total": total, "page": page,
            "page_size": page_size, "pages": (total + page_size - 1) // page_size}


async def item_revisions(org_id: str, item_id: str) -> List[Dict[str, Any]]:
    out = []
    async for d in get_db()[ITEM_REV].find({"org_id": org_id, "item_id": item_id}, {"_id": 0}).sort("created_at", -1).limit(50):
        out.append(d)
    return out


async def rollback_item(org_id: str, user_id: str, item_id: str, revision_id: str) -> Dict[str, Any]:
    rev = await get_db()[ITEM_REV].find_one({"org_id": org_id, "item_id": item_id, "id": revision_id}, {"_id": 0})
    if not rev:
        raise HTTPException(404, "Revision not found")
    return await update_item(org_id, user_id, item_id,
                             {"values": rev.get("values") or {}, "status": rev.get("status")})


# ---------------------------------------------------------------------------
# Dynamic page templates
# ---------------------------------------------------------------------------
async def create_template(org_id: str, user_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    db = get_db()
    cid = body.get("collection_id")
    definition = await get_collection(org_id, cid)
    site_slug = body.get("site_slug")
    route_base = _slugify(body.get("route_base") or definition["internal_id"])
    # unique route per site+org
    if await db[TEMPLATES].find_one({"org_id": org_id, "site_slug": site_slug, "route_base": route_base}):
        raise HTTPException(409, {"error": "route_conflict", "route_base": route_base})
    doc = {
        "id": uuid.uuid4().hex, "org_id": org_id, "collection_id": cid,
        "site_slug": site_slug, "route_base": route_base,
        "slug_field": body.get("slug_field"),
        "list_layout": body.get("list_layout") or {"blocks": []},
        "detail_layout": _sanitize_layout(body.get("detail_layout") or {"blocks": []}),
        "seo": body.get("seo") or {},
        "status": "draft", "revision": 1,
        "created_by": user_id, "created_at": _now(), "updated_at": _now(),
    }
    await db[TEMPLATES].insert_one(dict(doc))
    doc.pop("_id", None)
    await audit(org_id, "template.create", user_id, {"template_id": doc["id"]})
    return doc


def _sanitize_layout(layout: Dict[str, Any]) -> Dict[str, Any]:
    """Sanitise any static HTML in block props (bindings are dynamic + resolved safely at render)."""
    for b in (layout.get("blocks") or []):
        props = b.get("props") or {}
        for k, v in list(props.items()):
            if isinstance(v, str) and ("<" in v or ">" in v):
                props[k] = sanitize_html(v)
        b["props"] = props
    return layout


async def update_template(org_id: str, user_id: str, tid: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    db = get_db()
    tpl = await db[TEMPLATES].find_one({"org_id": org_id, "id": tid}, {"_id": 0})
    if not tpl:
        raise HTTPException(404, "Template not found")
    upd: Dict[str, Any] = {"updated_at": _now()}
    for k in ("list_layout", "detail_layout", "seo", "slug_field", "route_base"):
        if k in patch and patch[k] is not None:
            upd[k] = _sanitize_layout(patch[k]) if k == "detail_layout" else patch[k]
    if "status" in patch:
        upd["status"] = "published" if patch["status"] == "published" else "draft"
        if upd["status"] == "published":
            upd["revision"] = int(tpl.get("revision") or 1) + 1
            try:
                await db[TEMPLATE_REV].insert_one({"id": uuid.uuid4().hex, "org_id": org_id,
                                                   "template_id": tid, "snapshot": {**tpl, **upd},
                                                   "created_by": user_id, "created_at": _now()})
            except Exception:  # noqa: BLE001
                pass
    await db[TEMPLATES].update_one({"org_id": org_id, "id": tid}, {"$set": upd})
    return await db[TEMPLATES].find_one({"org_id": org_id, "id": tid}, {"_id": 0})


async def list_templates(org_id: str) -> List[Dict[str, Any]]:
    out = []
    async for d in get_db()[TEMPLATES].find({"org_id": org_id}, {"_id": 0}).sort("created_at", -1):
        out.append(d)
    return out


# ---- Public render resolution (safe) ----
async def public_template_by_route(org_id: str, site_slug: str, route_base: str) -> Optional[Dict[str, Any]]:
    return await get_db()[TEMPLATES].find_one(
        {"org_id": org_id, "site_slug": site_slug, "route_base": route_base, "status": "published"}, {"_id": 0})


async def public_list(org_id: str, tid_or_route: Dict[str, Any], q: Optional[str], page: int, page_size: int) -> Dict[str, Any]:
    definition = await get_db()[DEFS].find_one({"org_id": org_id, "id": tid_or_route["collection_id"]}, {"_id": 0})
    if not definition:
        return {"items": [], "total": 0}
    query = {"org_id": org_id, "collection_id": definition["id"], "status": "published", "archived": {"$ne": True}}
    if q:
        rx = {"$regex": re.escape(str(q)[:120]), "$options": "i"}
        ors = [{"slug": rx}]
        for f in definition.get("fields") or []:
            if f.get("searchable") and not f.get("private"):
                ors.append({f"values.{f['key']}": rx})
        query["$or"] = ors
    page = max(1, int(page)); page_size = min(MAX_PAGE_SIZE, max(1, int(page_size)))
    db = get_db()
    total = await db[ITEMS].count_documents(query)
    cursor = db[ITEMS].find(query, {"_id": 0}).sort("created_at", -1).skip((page - 1) * page_size).limit(page_size)
    return {"items": [public_projection(definition, d) async for d in cursor],
            "total": total, "page": page, "page_size": page_size,
            "pages": (total + page_size - 1) // page_size, "collection": definition["internal_id"]}


async def public_detail(org_id: str, template: Dict[str, Any], slug: str) -> Optional[Dict[str, Any]]:
    db = get_db()
    definition = await db[DEFS].find_one({"org_id": org_id, "id": template["collection_id"]}, {"_id": 0})
    if not definition:
        return None
    item = await db[ITEMS].find_one({"org_id": org_id, "collection_id": definition["id"],
                                     "slug": slug, "status": "published", "archived": {"$ne": True}}, {"_id": 0})
    if not item:
        return None
    return {"item": public_projection(definition, item), "detail_layout": template.get("detail_layout"),
            "seo": _resolve_seo(template.get("seo") or {}, definition, item), "collection": definition["internal_id"]}


def _resolve_seo(seo: Dict[str, Any], definition: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    vals = item.get("values") or {}
    private = {f["key"] for f in (definition.get("fields") or []) if f.get("private")}

    def resolve(s: Any) -> Any:
        if not isinstance(s, str):
            return s
        def repl(m):
            k = m.group(1)
            return "" if k in private else str(vals.get(k, ""))
        return re.sub(r"\{{1,2}\s*([a-zA-Z0-9_]+)\s*\}{1,2}", repl, s)
    return {k: resolve(v) for k, v in seo.items()}


# ---------------------------------------------------------------------------
# External REST connector — SSRF hardened
# ---------------------------------------------------------------------------
APPROVED_PORTS = {443}
CONNECTOR_TIMEOUT_S = 10
CONNECTOR_MAX_BYTES = 2 * 1024 * 1024


def _ip_is_public(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return not (addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_multicast
                or addr.is_reserved or addr.is_unspecified
                or (addr.version == 4 and str(addr).startswith("169.254")))


def _assert_safe_url(url: str) -> Tuple[str, str]:
    """Validate scheme/port and that EVERY resolved IP is public. Returns (host, url).
    Raises 400 on any SSRF risk (localhost/private/link-local/metadata/bad scheme/port)."""
    from urllib.parse import urlparse
    p = urlparse(url)
    if p.scheme != "https":
        raise HTTPException(400, {"error": "ssrf_blocked", "reason": "only https is allowed"})
    host = p.hostname or ""
    if not host:
        raise HTTPException(400, {"error": "ssrf_blocked", "reason": "no host"})
    port = p.port or 443
    if port not in APPROVED_PORTS:
        raise HTTPException(400, {"error": "ssrf_blocked", "reason": f"port {port} not allowed"})
    low = host.lower()
    if low in ("localhost", "metadata.google.internal") or low.endswith(".local") or low.endswith(".internal"):
        raise HTTPException(400, {"error": "ssrf_blocked", "reason": "internal hostname"})
    try:
        infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        raise HTTPException(400, {"error": "ssrf_blocked", "reason": "dns resolution failed"})
    ips = {i[4][0] for i in infos}
    if not ips:
        raise HTTPException(400, {"error": "ssrf_blocked", "reason": "no ip"})
    for ip in ips:
        if not _ip_is_public(ip):
            raise HTTPException(400, {"error": "ssrf_blocked", "reason": f"resolves to non-public address ({ip})"})
    return host, url


async def connector_fetch(url: str, headers: Dict[str, str], params: Dict[str, str]) -> Dict[str, Any]:
    """SSRF-safe GET with manual redirect re-validation (DNS-rebinding resistant)."""
    import httpx
    current = url
    for _ in range(4):
        _assert_safe_url(current)
        async with httpx.AsyncClient(timeout=CONNECTOR_TIMEOUT_S, follow_redirects=False) as client:
            resp = await client.get(current, headers=headers or {}, params=params or {})
        if resp.status_code in (301, 302, 303, 307, 308):
            loc = resp.headers.get("location")
            if not loc:
                break
            from urllib.parse import urljoin
            current = urljoin(current, loc)
            continue
        raw = resp.content[:CONNECTOR_MAX_BYTES]
        if len(resp.content) > CONNECTOR_MAX_BYTES:
            raise HTTPException(413, {"error": "response_too_large"})
        try:
            data = resp.json()
        except Exception:  # noqa: BLE001
            data = {"raw": raw.decode("utf-8", errors="ignore")[:CONNECTOR_MAX_BYTES]}
        return {"status_code": resp.status_code, "data": data}
    raise HTTPException(400, {"error": "too_many_redirects"})
