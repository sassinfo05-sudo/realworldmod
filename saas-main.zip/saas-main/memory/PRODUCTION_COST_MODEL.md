# Zanelvo — PRODUCTION COST MODEL (Round 15 closed-beta)

_All caps are DB-backed and founder-editable (`db.plans[].limits`, applied at startup via
`entitlements.apply_db_overrides`). The values below are the seeded closed-beta defaults and
the single source of truth for enforcement — there are no scattered hardcoded allowances._

## Plan caps (USD / month)

| Plan (code)          | Monthly price | AI hard cap | Total variable-provider hard cap |
| -------------------- | ------------: | ----------: | -------------------------------: |
| Free (`free`)        |            $0 |       $0.10 |                            $0.25 |
| Starter (`launch`)   |           $17 |       $1.00 |                            $2.04 |
| Business (`revenue`) |           $39 |       $3.00 |                            $4.68 |
| Commerce+AI (`autopilot`) |      $99 |       $8.00 |                           $11.88 |
| Scale (`scale`)      |          $249 |      $20.00 |                           $29.88 |

Verified live via `GET /api/billing/plans` (each plan exposes `ai_credits_usd_per_month` and
`variable_provider_cap_usd`).

## What each cap covers

- **AI hard cap** — direct LLM serving cost only. Ledger `kind ∈ {text, json, image}`.
- **Total variable-provider hard cap** — every margin-consuming provider cost that is NOT
  pass-through/prepaid. Includes AI kinds + email + translation + embeddings + shipping-rate
  lookups + ad-API calls.
- **Pass-through / prepaid (never charged against plan margin)** — `kind ∈ {sms, whatsapp,
  voice_second, shipping_label, phone_number_month, ad_spend_usd, domain_registration,
  payment_fee}`. These are billed straight to the tenant (prepaid balance / their own
  connected account) so they can never silently consume plan margin.

## Enforcement (services/usage.py)

1. `enforce_budget(org, kind=…, est_cost=…)` — fast pre-check: pause-all → provider kill →
   global cap → **AI cap (AI-scoped spend)** → **variable-provider cap (non-pass-through
   spend)** → per-user share → per-feature cap → public-visitor daily cap.
2. `reserve()` — inserts a `held` reservation (counts against budget until settled/expired).
   **Fails closed (503 `metering_unavailable`)** if reservation storage is unavailable.
3. `confirm_reservation()` — race-safe: for every applicable cap, sums settled ledger + held
   reservations up to & including this one (restricted to the cap's kind scope) in FIFO
   `(created_at, id)` order; any hold that would push a running total over a cap releases
   itself and returns 402. The sum of surviving holds can never exceed any cap.
4. `settle()` — writes the real ledger row, closes the hold, fires ≤1 budget-warning email
   per period at the warn threshold; `release()` frees unused holds; `expire_stale_reservations()`
   reclaims TTL-expired holds (crash safety).

Idempotency: scoped unique index on `usage_idempotency.skey` (tenant+user+feature+op+key) so a
retry never re-charges and one tenant can never read another's cached output.

## Warnings & stop behavior

- Warn the owner at the configured threshold (default 80%; UI shows 60/80/95 bands) via one
  idempotent email per period.
- Stop chargeable operations at 100% (402 with a precise upgrade/top-up message).
- Ordinary auth + CRUD stay available when the AI allowance is exhausted (verified: 402 on AI
  endpoint while `GET /api/crm/contacts` and `/api/auth/me` still 200).

## Margin assumptions (to be re-validated before GA)

- Cost rates (`COST_RATES` in usage.py, founder-overridable via `platform_settings.llm_cost_rates`)
  drive both estimates and settled cost. Text ~ Claude Sonnet $0.003/$0.015 per 1k in/out;
  image ~ $0.039–0.04; email ~ $0.0009; SMS ~ $0.0079; voice ~ $0.013/min.
- The old $60 / $300 AI allowances have been removed in favor of the table above.
- `services/usage.margin_summary` reports MRR vs metered cost per org and flags loss-making
  orgs — use it to re-tune caps before GA with real usage data.

## Deterministic proof

`cd /app/backend && python tests/test_atomic_metering.py` → ALL PASS
(20 concurrent AI reservations settle $0.09 ≤ $0.10 free cap; variable cap holds at $0.25;
pass-through ungated; AI spend also respects the variable cap).
