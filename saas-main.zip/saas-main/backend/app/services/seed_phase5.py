"""Phase 5 seed: knowledge sources, agents (with an initial live version each),
one org-level kill switch (enabled), a couple of synthetic chat transcripts, and one
simulated call record — so the AI Employees dashboard demos well immediately.
"""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

from ..db import get_db, utc_now_iso
from ..models_ai import (
    Agent, AgentVersion, ChatConversation, ChatMessage,
    CallRecord, KillSwitch,
)
from .knowledge import ingest_website_pages, refresh_structured_facts, add_faq, add_policy

logger = logging.getLogger(__name__)


DEFAULT_AGENTS: List[Dict[str, Any]] = [
    {
        "agent_type": "receptionist",
        "name": "Receptionist",
        "purpose": "Answer visitor questions, qualify leads and book appointments.",
        "tone": "warm, direct, honest — no fluff, respect the visitor's time",
        "allowed_tools": ["get_services", "get_hours", "get_locations", "get_policies",
                            "get_availability", "create_booking", "take_message"],
        "qualification_questions": [
            {"name": "service_interest", "prompt": "What kind of work do you need?", "required": False},
            {"name": "location", "prompt": "What's your address or ZIP?", "required": False},
            {"name": "urgency", "prompt": "How urgent is it?", "required": False},
        ],
        "escalation_rules": [
            {"kind": "topic", "value": "refund", "note": "Money-back requests → human"},
            {"kind": "topic", "value": "complaint", "note": "Any complaint escalates"},
            {"kind": "keyword", "value": "lawyer", "note": "Legal → human immediately"},
            {"kind": "low_confidence", "value": "0.4"},
        ],
        "allowed_claims": ("Only quote prices from the verified services list. "
                              "Never promise same-day service unless the availability tool confirms it."),
        "confidence_threshold": 0.4,
    },
    {
        "agent_type": "sales",
        "name": "Sales Assistant",
        "purpose": "Draft first responses to new leads and a follow-up cadence. Owner reviews before send.",
        "tone": "warm, helpful, low-pressure",
        "allowed_tools": ["get_services", "get_policies"],
        "qualification_questions": [],
        "escalation_rules": [{"kind": "topic", "value": "refund"}],
        "allowed_claims": "Draft mode only. Never send autonomously; always await approval.",
        "confidence_threshold": 0.3,
    },
    {
        "agent_type": "reactivation",
        "name": "Reactivation Agent",
        "purpose": "Find stale leads, expired quotes, lapsed customers. Draft reactivation messages.",
        "tone": "friendly, respectful of frequency caps",
        "allowed_tools": ["get_services"],
        "qualification_questions": [],
        "escalation_rules": [],
        "allowed_claims": "Respect the suppression list; never contact suppressed emails.",
        "confidence_threshold": 0.3,
    },
    {
        "agent_type": "support",
        "name": "Support Agent",
        "purpose": "Answer 'when is my appointment / did my payment go through / cancel policy' style questions.",
        "tone": "helpful, precise, calm under pressure",
        "allowed_tools": ["get_booking", "get_invoice", "get_policies", "take_message"],
        "qualification_questions": [],
        "escalation_rules": [
            {"kind": "topic", "value": "refund", "note": "Refunds always human"},
            {"kind": "topic", "value": "billing_dispute"},
        ],
        "allowed_claims": "Never promise refunds. Use lookup tools first before quoting facts.",
        "confidence_threshold": 0.4,
    },
    {
        "agent_type": "admin",
        "name": "Admin Agent",
        "purpose": "Generate the daily digest for the owner.",
        "tone": "concise, business-first",
        "allowed_tools": [],
        "qualification_questions": [],
        "escalation_rules": [],
        "allowed_claims": "Numbers only — no editorialising.",
        "confidence_threshold": 0.2,
    },
]


SAMPLE_FAQS = [
    ("Do you offer emergency service?",
      "Yes — same-day emergency visits are available for water leaks, gas smells, and full drain "
      "backups when a slot is open. Emergency fee applies outside business hours."),
    ("How does pricing work?",
      "We quote a flat rate up front for most jobs. If we find something bigger once we're on site, "
      "we stop, explain it clearly, and only proceed with your OK."),
    ("What areas do you cover?",
      "We serve the Bay Area — roughly a 40-mile radius from Oakland. Book a slot and we'll confirm "
      "coverage in your ZIP within a few minutes."),
]


SAMPLE_POLICIES = [
    ("Cancellation policy",
      "Reschedules or cancellations are free up to 4 hours before your booked start time. "
      "Later than that we may apply a $25 short-notice fee to cover the crew's travel."),
    ("Payment policy",
      "We accept card via secure link after the job. Deposits are only required for large installs, "
      "and every invoice is itemised."),
]


SAMPLE_CHATS = [
    {
        "visitor_name": "Priya",
        "messages": [
            ("visitor", "Do you unblock drains on Sundays?"),
            ("ai", "We do — Sunday visits are available from 10am to 4pm and use our standard drain unblock rate ($120). Want to grab a slot?",
              0.85),
            ("visitor", "Yeah, tomorrow around 11 if possible."),
            ("ai", "Perfect — I can hold 11:00 for you. Can I get your name, email and address?", 0.9),
        ],
    },
    {
        "visitor_name": "Aaron",
        "messages": [
            ("visitor", "Is a water heater install same-day?"),
            ("ai", "Water heater installs run about 2 hours and we usually schedule them 2-3 days out to make sure the right unit is on the truck. Want me to check tomorrow?",
              0.8),
            ("visitor", "What does it cost?"),
            ("ai", "Standard install is $1,200 including haul-away of the old unit. Complex jobs (venting changes, gas re-routes) run higher — the tech confirms on-site before starting.", 0.9),
        ],
    },
]


async def seed_phase5_demo() -> None:
    db = get_db()
    org = await db.organizations.find_one({"slug": "demo-home-services"})
    if not org:
        logger.warning("Phase 5 seed: demo org not found; skipping.")
        return
    org_id = str(org["_id"])

    # Indexes
    try:
        await db.knowledge_sources.create_index([("org_id", 1), ("kind", 1)])
        await db.knowledge_sources.create_index([("org_id", 1), ("status", 1)])
        await db.agents.create_index([("org_id", 1), ("agent_type", 1)], unique=True)
        await db.agent_versions.create_index([("org_id", 1), ("agent_id", 1), ("version", 1)],
                                                  unique=True)
        await db.chat_conversations.create_index([("org_id", 1), ("session_token", 1)],
                                                       unique=True)
        await db.chat_conversations.create_index([("org_id", 1), ("last_message_at", -1)])
        await db.chat_messages.create_index([("conversation_id", 1)])
        await db.agent_interactions.create_index([("org_id", 1), ("agent_id", 1), ("created_at", -1)])
        await db.call_records.create_index([("org_id", 1), ("created_at", -1)])
        await db.kill_switches.create_index([("org_id", 1)], unique=True)
    except Exception as e:  # noqa: BLE001
        logger.warning("Phase 5 index create warning: %s", e)

    if await db.agents.count_documents({"org_id": org_id}) >= 5:
        logger.info("Phase 5 already seeded — refreshing structured facts + ingesting site.")
        try:
            await refresh_structured_facts(org_id)
            await ingest_website_pages(org_id)
        except Exception as e:  # noqa: BLE001
            logger.exception("Refresh failed: %s", e)
        return

    # Kill-switch: enabled
    if not await db.kill_switches.find_one({"org_id": org_id}):
        await db.kill_switches.insert_one(KillSwitch(org_id=org_id, ai_enabled=True,
                                                          updated_at=utc_now_iso()).to_mongo())

    # Knowledge: structured facts + website pages + FAQs + policies
    await refresh_structured_facts(org_id)
    await ingest_website_pages(org_id)
    for title, body in SAMPLE_FAQS:
        await add_faq(org_id, title, body)
    for title, body in SAMPLE_POLICIES:
        await add_policy(org_id, title, body)

    # Agents
    for spec in DEFAULT_AGENTS:
        agent = Agent(org_id=org_id, agent_type=spec["agent_type"], name=spec["name"],
                        enabled=True, updated_at=utc_now_iso())
        a_res = await db.agents.insert_one(agent.to_mongo())
        agent_id = str(a_res.inserted_id)

        version = AgentVersion(
            org_id=org_id, agent_id=agent_id, version=1, label="Initial",
            purpose=spec["purpose"], tone=spec["tone"],
            languages=["en"], allowed_tools=spec["allowed_tools"],
            qualification_questions=spec["qualification_questions"],
            escalation_rules=spec["escalation_rules"],
            allowed_claims=spec["allowed_claims"],
            confidence_threshold=spec["confidence_threshold"],
            require_approval=False, is_live=True, is_sandbox=False,
        )
        v_res = await db.agent_versions.insert_one(version.to_mongo())
        await db.agents.update_one({"_id": a_res.inserted_id},
                                       {"$set": {"live_version_id": str(v_res.inserted_id),
                                                    "updated_at": utc_now_iso()}})

    receptionist = await db.agents.find_one({"org_id": org_id, "agent_type": "receptionist"})
    receptionist_id = str(receptionist["_id"])
    receptionist_ver = receptionist["live_version_id"]

    # Sample chat transcripts (2)
    now = datetime.now(timezone.utc)
    for i, sample in enumerate(SAMPLE_CHATS):
        conv = ChatConversation(
            org_id=org_id, channel="chat",
            session_token=secrets.token_urlsafe(20),
            website_slug="demo-home-services",
            agent_id=receptionist_id, agent_version_id=receptionist_ver,
            status="ai", started_at=(now - timedelta(days=1, hours=i)).isoformat().replace("+00:00", "Z"),
            last_message_at=(now - timedelta(days=1, hours=i, minutes=-5)).isoformat().replace("+00:00", "Z"),
            visitor_meta={"name": sample["visitor_name"]},
        )
        c_res = await db.chat_conversations.insert_one(conv.to_mongo())
        cid = str(c_res.inserted_id)
        for entry in sample["messages"]:
            role, content, *rest = entry
            confidence = rest[0] if rest else None
            msg = ChatMessage(org_id=org_id, conversation_id=cid, role=role,
                                content=content, confidence=confidence,
                                created_at_iso=utc_now_iso())
            await db.chat_messages.insert_one(msg.to_mongo())

    # Simulated call record
    call_conv = ChatConversation(
        org_id=org_id, channel="call",
        session_token=secrets.token_urlsafe(20),
        website_slug=None,
        agent_id=receptionist_id, agent_version_id=receptionist_ver,
        status="ai",
        started_at=(now - timedelta(hours=6)).isoformat().replace("+00:00", "Z"),
        last_message_at=(now - timedelta(hours=6, minutes=-3)).isoformat().replace("+00:00", "Z"),
        visitor_meta={"name": "Deven Patel", "phone": "+1 415 555 0134"},
    )
    cc_res = await db.chat_conversations.insert_one(call_conv.to_mongo())
    ccid = str(cc_res.inserted_id)
    transcript = (
        "Agent: Thanks for calling — how can I help?\n"
        "Caller: I have a leak under my kitchen sink, can someone come today?\n"
        "Agent: I'm sorry, that's stressful. Let me check availability — is 4pm today OK?\n"
        "Caller: Yes.\n"
        "Agent: Booked. You'll get a confirmation text. Anything else?\n"
        "Caller: No thanks."
    )
    for line in transcript.split("\n"):
        role = "ai" if line.startswith("Agent:") else "visitor"
        await db.chat_messages.insert_one(ChatMessage(
            org_id=org_id, conversation_id=ccid, role=role,
            content=line.split(": ", 1)[1] if ": " in line else line,
            created_at_iso=utc_now_iso(),
        ).to_mongo())
    call = CallRecord(
        org_id=org_id, conversation_id=ccid,
        contact_id=None, direction="inbound", duration_seconds=182,
        transcript=transcript,
        ai_summary=("Caller had a kitchen-sink leak. Booked an emergency visit for 4pm same day. "
                     "No refund/complaint topics. Confidence high."),
        extracted_fields={"name": "Deven Patel", "phone": "+1 415 555 0134",
                           "service_interest": "emergency_leak"},
        outcome="booked", simulated=True,
        cost_cents=1.2,
        ended_at=utc_now_iso(),
    )
    await db.call_records.insert_one(call.to_mongo())

    logger.info("Phase 5 demo seeded: %d agents + knowledge sources + %d transcripts + 1 call",
                len(DEFAULT_AGENTS), len(SAMPLE_CHATS))
