import { useState } from "react";
import PublicNav from "@/components/PublicNav";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function PasswordReset() {
    const _qsToken = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("token") : null;
    const [stage, setStage] = useState(_qsToken ? "confirm" : "request"); // request | confirm | done
    const [email, setEmail] = useState("");
    const [token, setToken] = useState(_qsToken || "");
    const [newPassword, setNewPassword] = useState("");
    const [devToken, setDevToken] = useState(null);
    const [senderWired, setSenderWired] = useState(false);
    const [busy, setBusy] = useState(false);

    async function requestReset(e) {
        e.preventDefault();
        setBusy(true);
        try {
            const { data } = await api.post("/auth/password-reset/request", { email: email.trim() });
            setDevToken(data.dev_token || null);
            setSenderWired(!!data.sender_wired);
            setToken(data.dev_token || "");
            setStage("confirm");
            toast.success(data.sender_wired ? "Check your inbox for the reset link" : "If that email exists, a reset link was issued");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Request failed");
        } finally {
            setBusy(false);
        }
    }

    async function confirmReset(e) {
        e.preventDefault();
        if (newPassword.length < 8) {
            toast.error("Password must be at least 8 characters.");
            return;
        }
        setBusy(true);
        try {
            await api.post("/auth/password-reset/confirm", { token, new_password: newPassword });
            setStage("done");
            toast.success("Password updated");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Reset failed");
        } finally {
            setBusy(false);
        }
    }

    return (
        <div className="min-h-screen bg-brand-surface">
            <PublicNav />
            <div className="mx-auto max-w-md px-6 py-16">
                <h1 className="font-display text-3xl text-brand-ink font-medium" data-testid="reset-title">
                    Reset your password
                </h1>

                {stage === "request" && (
                    <form onSubmit={requestReset} className="mt-8 space-y-4" data-testid="reset-request-form">
                        <div>
                            <Label htmlFor="reset-email">Email</Label>
                            <Input
                                id="reset-email"
                                type="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="mt-1"
                                data-testid="reset-email"
                            />
                        </div>
                        <Button
                            type="submit"
                            disabled={busy}
                            className="w-full bg-brand-ink hover:bg-black text-white"
                            data-testid="reset-request-submit"
                        >
                            {busy ? "Sending…" : "Send reset token"}
                        </Button>
                    </form>
                )}

                {stage === "confirm" && (
                    <>
                        {devToken ? (
                            <div
                                className="mt-6 rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900"
                                data-testid="reset-dev-note"
                            >
                                Development mode: no email provider is connected yet, so your reset token is shown here.
                                <div className="mt-3 rounded bg-white border border-amber-200 p-2 font-mono text-xs break-all">
                                    {devToken}
                                </div>
                            </div>
                        ) : (
                            <div className="mt-6 rounded-lg border border-brand-line bg-white p-4 text-sm text-zinc-700" data-testid="reset-sent-note">
                                If an account exists for that email, we've sent a reset link. Open it, or paste the token from the email below.
                            </div>
                        )}
                        <form onSubmit={confirmReset} className="mt-6 space-y-4" data-testid="reset-confirm-form">
                            <div>
                                <Label htmlFor="reset-token">Reset token</Label>
                                <Input
                                    id="reset-token"
                                    value={token}
                                    onChange={(e) => setToken(e.target.value)}
                                    className="mt-1 font-mono text-xs"
                                    data-testid="reset-token-input"
                                />
                            </div>
                            <div>
                                <Label htmlFor="reset-new-password">New password</Label>
                                <Input
                                    id="reset-new-password"
                                    type="password"
                                    required
                                    minLength={8}
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value)}
                                    className="mt-1"
                                    data-testid="reset-new-password"
                                />
                            </div>
                            <Button
                                type="submit"
                                disabled={busy}
                                className="w-full bg-brand-copper hover:bg-brand-copperHover text-white"
                                data-testid="reset-confirm-submit"
                            >
                                {busy ? "Updating…" : "Set new password"}
                            </Button>
                        </form>
                    </>
                )}

                {stage === "done" && (
                    <div className="mt-8 rounded-lg border border-emerald-300 bg-emerald-50 p-4 text-sm text-emerald-900"
                         data-testid="reset-done">
                        Your password has been updated. You can now sign in.
                    </div>
                )}
            </div>
        </div>
    );
}
