"""Founder-managed third-party integration credentials.

Single-row doc in `integrations` (key='primary'). The owner pastes provider keys
in the owner dashboard instead of editing env files. Secrets are STORED but never
returned in full — reads return `{set: bool, hint: "…last4"}` per secret and a
`configured` flag per provider so the UI can show honest connection status.

This is the credential store + status layer. The downstream feature flows
(checkout, product import, voice calls) read `get_secret()` and act only when the
relevant provider `configured` is true — otherwise they stay in the existing
honest "not connected" state. Nothing here is simulated: an unset key = not connected.
"""
from __future__ import annotations

from typing import Any, Dict

from ..db import get_db, utc_now_iso

INTEGRATIONS_KEY = "primary"

# Fields that must be masked on read (secrets). Everything else is returned as-is.
SECRET_FIELDS = {
    "stripe_secret_key", "stripe_webhook_secret", "paypal_secret", "ecommerce_api_secret",
    "openai_api_key", "gemini_api_key", "retell_api_key", "twilio_auth_token",
    "ecommerce_api_key", "resend_api_key", "smtp_password", "telnyx_api_key",
    "sendgrid_api_key", "webhook_secret", "inbound_secret", "resend_signing_secret", "cloudflare_api_token",
}

DEFAULTS: Dict[str, Any] = {
    "key": INTEGRATIONS_KEY,
    "domains": {
        # Cloudflare for SaaS (custom hostnames + SSL). Loaded by services.domain_providers at request time.
        "cloudflare_api_token": "",    # secret — API token with Zone:SSL and Certificates:Edit on the SaaS zone
        "cloudflare_zone_id": "",
        "cloudflare_origin": "",       # fallback origin hostname (defaults to the platform origin)
    },
    "payments": {
        "provider": "none",            # legacy: none | stripe | paypal (kept for compatibility)
        "stripe_enabled": False,       # legacy toggle (kept); readiness now auto-enables on key presence
        "stripe_paused": False,        # explicit kill-switch: pause a connected provider without deleting keys
        "stripe_secret_key": "",
        "stripe_publishable_key": "",  # public
        "stripe_webhook_secret": "",
        "paypal_enabled": False,       # legacy toggle (kept)
        "paypal_paused": False,        # explicit kill-switch
        "paypal_client_id": "",        # public-ish
        "paypal_secret": "",
        "paypal_mode": "sandbox",      # sandbox | live
    },
    "email": {
        # Platform system mail: 2FA codes, staff invites, billing notices, transactional.
        "provider": "none",            # none | resend | sendgrid | smtp
        "resend_api_key": "",
        "sendgrid_api_key": "",
        "smtp_host": "",
        "smtp_port": 587,
        "smtp_username": "",
        "smtp_password": "",
        "smtp_use_tls": True,
        "inbound_secret": "",          # shared secret for inbound email webhooks
        "resend_signing_secret": "",   # Resend/Svix whsec_… — when set, inbound Resend webhooks MUST be signed
        "sendgrid_event_public_key": "",  # SendGrid Event Webhook "Signed Event Webhook" ECDSA public key (base64)
    },
    "ecommerce": {
        "provider": "none",            # none | aliexpress | cj_dropshipping
        "ecommerce_api_key": "",
        "ecommerce_api_secret": "",
    },
    "ai_media": {
        "image_provider": "emergent",  # emergent (uses platform key) | openai | gemini
        "openai_api_key": "",
        "gemini_api_key": "",
    },
    "voice": {
        "provider": "none",            # none | telnyx | twilio | retell
        "retell_api_key": "",
        "webhook_secret": "",          # shared secret carriers must send (?secret= / X-Webhook-Secret)
        "telnyx_api_key": "",          # recommended managed-numbers carrier
        "telnyx_connection_id": "",    # voice app / connection for TeXML
        "twilio_account_sid": "",      # public-ish
        "twilio_auth_token": "",
    },
}


def _mask(val: str) -> Dict[str, Any]:
    val = val or ""
    return {"set": bool(val), "hint": (f"…{val[-4:]}" if len(val) >= 4 else ("set" if val else ""))}


def _merge_defaults(doc: Dict[str, Any]) -> Dict[str, Any]:
    out = {k: dict(v) if isinstance(v, dict) else v for k, v in DEFAULTS.items()}
    for section, val in (doc or {}).items():
        if section in out and isinstance(out[section], dict) and isinstance(val, dict):
            out[section] = {**out[section], **val}
        elif section in out:
            out[section] = val
    return out


def stripe_ready(cfg: Dict[str, Any]) -> bool:
    return bool(cfg.get("stripe_secret_key")) and (cfg.get("stripe_enabled") or cfg.get("provider") == "stripe")


def paypal_ready(cfg: Dict[str, Any]) -> bool:
    return bool(cfg.get("paypal_secret") and cfg.get("paypal_client_id")) and \
        (cfg.get("paypal_enabled") or cfg.get("provider") == "paypal")


def _configured(section: str, cfg: Dict[str, Any]) -> bool:
    if section == "payments":
        return stripe_ready(cfg) or paypal_ready(cfg)
    if section == "email":
        p = cfg.get("provider")
        if p == "resend":
            return bool(cfg.get("resend_api_key"))
        if p == "sendgrid":
            return bool(cfg.get("sendgrid_api_key"))
        if p == "smtp":
            return bool(cfg.get("smtp_host"))
        return False
    if section == "ecommerce":
        return cfg.get("provider") not in (None, "none") and bool(cfg.get("ecommerce_api_key"))
    if section == "ai_media":
        ip = cfg.get("image_provider")
        if ip == "emergent":
            return True  # uses the platform's Emergent key
        if ip == "openai":
            return bool(cfg.get("openai_api_key"))
        if ip == "gemini":
            return bool(cfg.get("gemini_api_key"))
        return False
    if section == "voice":
        p = cfg.get("provider")
        if p == "retell":
            return bool(cfg.get("retell_api_key"))
        if p == "telnyx":
            return bool(cfg.get("telnyx_api_key"))
        if p == "twilio":
            return bool(cfg.get("twilio_account_sid") and cfg.get("twilio_auth_token"))
        return False
    return False


async def get_raw() -> Dict[str, Any]:
    """Public accessor for the merged raw config (used by services/numbers.py)."""
    return await _raw()


def _decrypt_doc(doc: Dict[str, Any]) -> Dict[str, Any]:
    """Secrets are encrypted at rest (services/secretbox.py); callers always see plaintext."""
    from . import secretbox
    out = dict(doc)
    for section, cfg in doc.items():
        if isinstance(cfg, dict):
            out[section] = {k: (secretbox.decrypt(v) if k in SECRET_FIELDS and isinstance(v, str) else v)
                            for k, v in cfg.items()}
    return out


def _encrypt_doc(doc: Dict[str, Any]) -> Dict[str, Any]:
    from . import secretbox
    out = dict(doc)
    for section, cfg in doc.items():
        if isinstance(cfg, dict):
            out[section] = {k: (secretbox.encrypt(v) if k in SECRET_FIELDS and isinstance(v, str) and v else v)
                            for k, v in cfg.items()}
    return out


async def _raw() -> Dict[str, Any]:
    db = get_db()
    doc = await db.integrations.find_one({"key": INTEGRATIONS_KEY}, {"_id": 0})
    if not doc:
        doc = _merge_defaults({})
        await db.integrations.update_one(
            {"key": INTEGRATIONS_KEY},
            {"$set": {**doc, "created_at": utc_now_iso(), "updated_at": utc_now_iso()}},
            upsert=True,
        )
        return doc
    return _merge_defaults(_decrypt_doc(doc))


async def get_public() -> Dict[str, Any]:
    """Masked view for the owner UI: secrets become {set,hint}; adds `configured`."""
    raw = await _raw()
    out: Dict[str, Any] = {}
    for section, cfg in raw.items():
        if section == "key" or not isinstance(cfg, dict):
            continue
        masked = {}
        for k, v in cfg.items():
            if k in SECRET_FIELDS:
                masked[k] = _mask(v)
            else:
                masked[k] = v
        masked["configured"] = _configured(section, cfg)
        if section == "payments":
            masked["stripe_ready"] = stripe_ready(cfg)
            masked["paypal_ready"] = paypal_ready(cfg)
        out[section] = masked
    return out


async def update(patch: Dict[str, Any]) -> Dict[str, Any]:
    """Merge a patch. Secret fields are only overwritten when a non-empty new value
    is supplied (so re-saving the masked form never wipes a stored secret)."""
    raw = await _raw()
    for section, cfg in (patch or {}).items():
        if section not in DEFAULTS or not isinstance(cfg, dict):
            continue
        cur = raw.get(section, {})
        for k, v in cfg.items():
            if k in SECRET_FIELDS:
                if isinstance(v, str) and v.strip():
                    cur[k] = v.strip()
                # empty / masked → keep existing
            else:
                cur[k] = v
        raw[section] = cur
    raw["updated_at"] = utc_now_iso()
    await get_db().integrations.update_one(
        {"key": INTEGRATIONS_KEY}, {"$set": _encrypt_doc(raw)}, upsert=True
    )
    return await get_public()


async def get_secret(section: str, field: str) -> str:
    """Downstream feature flows call this to obtain a real secret. Never exposed via API."""
    raw = await _raw()
    return (raw.get(section) or {}).get(field, "") or ""


async def is_configured(section: str) -> bool:
    raw = await _raw()
    return _configured(section, raw.get(section, {}))


async def payment_methods_public() -> Dict[str, Any]:
    """Which checkout methods the platform can offer right now (no secrets)."""
    raw = await _raw()
    cfg = raw.get("payments", {})
    return {
        "stripe": stripe_ready(cfg),
        "paypal": paypal_ready(cfg),
        "paypal_client_id": cfg.get("paypal_client_id") if paypal_ready(cfg) else "",
        "paypal_mode": cfg.get("paypal_mode", "sandbox"),
        "stripe_publishable_key": cfg.get("stripe_publishable_key") if stripe_ready(cfg) else "",
        "simulated": not (stripe_ready(cfg) or paypal_ready(cfg)),
    }
