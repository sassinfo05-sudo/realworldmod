"""Platform-wide, founder-editable settings.

Single-row doc in `platform_settings` (key='primary'). Holds:
- White-label identity (brand name, product url, support email, company info)
- Annual discount percentage
- Unit costs used by the profit/economics calculator

All values are founder-editable via /api/founder/settings. Everything reads from
here so a rename propagates across the whole product (public site, dashboard,
emails, meta) without a code change.
"""
from __future__ import annotations

from typing import Any, Dict

from ..db import get_db, utc_now_iso

SETTINGS_KEY = "primary"

# Reasonable, fully-editable defaults. Costs are per-unit, per-month where noted.
DEFAULT_UNIT_COSTS: Dict[str, float] = {
    "per_ai_conversation": 0.02,      # $ per AI conversation
    "per_voice_minute": 0.08,         # $ per voice minute
    "per_email": 0.0004,              # $ per outbound email
    "per_website_month": 0.50,        # $ per hosted website / month
    "per_contact_month": 0.0,         # $ per stored contact / month
    "base_infra_per_org_month": 0.50,  # fixed infra cost per active org / month
}

# Default professional-looking email addresses the platform uses for its own
# system messages (2FA codes, marketing, support inbox, transactional / no-reply).
# The founder edits these + connects SMTP / SendGrid on the Integrations page.
DEFAULT_EMAILS: Dict[str, Dict[str, str]] = {
    "support":     {"address": "support@zanelvo.com",     "display_name": "Zanelvo Support"},
    "twofa":       {"address": "security@zanelvo.com",    "display_name": "Zanelvo Security"},
    "marketing":   {"address": "hello@zanelvo.com",       "display_name": "Zanelvo"},
    "billing":     {"address": "billing@zanelvo.com",     "display_name": "Zanelvo Billing"},
    "noreply":     {"address": "no-reply@zanelvo.com",    "display_name": "Zanelvo"},
    "sales":       {"address": "sales@zanelvo.com",       "display_name": "Zanelvo Sales"},
    "notifications": {"address": "notifications@zanelvo.com", "display_name": "Zanelvo"},
}

DEFAULTS: Dict[str, Any] = {
    "key": SETTINGS_KEY,
    "brand_name": "Zanelvo",
    "product_url": "https://zanelvo.com",
    "support_email": "support@zanelvo.com",
    "company_name": "Zanelvo",
    "company_address": "",
    "footer_note": "",
    "annual_discount_pct": 20,
    "processing_fee_pct": 2.9,     # card processing % (Stripe/PayPal standard)
    "processing_fee_fixed": 0.30,  # fixed per-transaction fee in USD
    "unit_costs": DEFAULT_UNIT_COSTS,
    "emails": DEFAULT_EMAILS,
    # Public-facing legal & about copy the owner can rewrite. Empty string = fall back to templates.
    "legal": {
        "tos_html": "",
        "privacy_html": "",
        "about_html": "",
    },
}

# Fields a founder is allowed to write.
_EDITABLE = {
    "brand_name", "product_url", "support_email", "company_name",
    "company_address", "footer_note", "annual_discount_pct", "unit_costs",
    "emails", "legal", "processing_fee_pct", "processing_fee_fixed", "favicon_svg",
}

_EMAIL_ROLES = set(DEFAULT_EMAILS.keys())


async def get_settings() -> Dict[str, Any]:
    db = get_db()
    doc = await db.platform_settings.find_one({"key": SETTINGS_KEY}, {"_id": 0})
    if not doc:
        doc = dict(DEFAULTS)
        await db.platform_settings.update_one(
            {"key": SETTINGS_KEY},
            {"$set": {**doc, "created_at": utc_now_iso(), "updated_at": utc_now_iso()}},
            upsert=True,
        )
        return doc
    # merge any missing keys (forward-compatible)
    merged = {**DEFAULTS, **doc}
    merged["unit_costs"] = {**DEFAULT_UNIT_COSTS, **(doc.get("unit_costs") or {})}
    # merge emails so newly-added roles get defaults even on old docs
    _emails = {k: dict(v) for k, v in DEFAULT_EMAILS.items()}
    for role, cfg in (doc.get("emails") or {}).items():
        if role in _emails and isinstance(cfg, dict):
            _emails[role] = {**_emails[role], **cfg}
    merged["emails"] = _emails
    merged["legal"] = {**DEFAULTS["legal"], **(doc.get("legal") or {})}
    return merged


async def update_settings(patch: Dict[str, Any]) -> Dict[str, Any]:
    db = get_db()
    clean: Dict[str, Any] = {}
    for k, v in (patch or {}).items():
        if k not in _EDITABLE:
            continue
        if k == "unit_costs" and isinstance(v, dict):
            cur = await get_settings()
            merged_costs = {**cur.get("unit_costs", DEFAULT_UNIT_COSTS)}
            for ck, cv in v.items():
                if ck in DEFAULT_UNIT_COSTS:
                    try:
                        merged_costs[ck] = float(cv)
                    except (TypeError, ValueError):
                        pass
            clean["unit_costs"] = merged_costs
        elif k == "annual_discount_pct":
            try:
                clean[k] = max(0, min(90, float(v)))
            except (TypeError, ValueError):
                pass
        elif k == "emails" and isinstance(v, dict):
            cur = await get_settings()
            merged = {k2: dict(v2) for k2, v2 in cur.get("emails", DEFAULT_EMAILS).items()}
            for role, cfg in v.items():
                if role not in _EMAIL_ROLES or not isinstance(cfg, dict):
                    continue
                addr = str(cfg.get("address") or "").strip()
                name = str(cfg.get("display_name") or "").strip()
                if addr:
                    merged[role]["address"] = addr
                if name:
                    merged[role]["display_name"] = name
            clean["emails"] = merged
        elif k == "legal" and isinstance(v, dict):
            from .svg_safe import sanitize_html
            cur = await get_settings()
            merged = {**cur.get("legal", DEFAULTS["legal"])}
            for lk, lv in v.items():
                if lk in DEFAULTS["legal"]:
                    # Stored-XSS defence: strict server-side allow-list sanitisation of
                    # tenant/staff-authored legal & about HTML before it is persisted and
                    # later rendered via dangerouslySetInnerHTML on public pages.
                    merged[lk] = sanitize_html(str(lv or ""))
            clean["legal"] = merged
        elif k == "favicon_svg":
            from .svg_safe import sanitize_svg
            clean[k] = sanitize_svg(str(v or "")) if v else ""
        else:
            clean[k] = v
    clean["updated_at"] = utc_now_iso()
    await db.platform_settings.update_one(
        {"key": SETTINGS_KEY}, {"$set": clean}, upsert=True
    )
    return await get_settings()


async def email_for(role: str) -> Dict[str, str]:
    """Resolve a professional 'From' address+name for a role (support/marketing/twofa/...).
    Falls back to no-reply if the role is unknown."""
    s = await get_settings()
    emails = s.get("emails") or DEFAULT_EMAILS
    return dict(emails.get(role) or emails.get("noreply") or DEFAULT_EMAILS["noreply"])
