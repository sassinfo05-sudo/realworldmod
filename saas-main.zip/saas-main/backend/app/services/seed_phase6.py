"""Phase 6 seed: subscriptions on demo org, additional thin demo orgs on different plans,
feature flags, help articles, and a starter coupon.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

from bson import ObjectId

from ..config import DEMO_OWNER_EMAIL
from ..db import get_db, utc_now_iso
from ..security import generate_readable_password, hash_password
from .entitlements import get_or_create_subscription
from .help_articles import seed_help_articles

logger = logging.getLogger(__name__)


DEMO_ORGS_PHASE6 = [
    {
        "email": "owner@free-demo.zanelvo.com",
        "org_name": "Cedar Lane Landscaping",
        "org_slug": "cedar-lane-landscaping",
        "plan": "free",
        "industry": "home_services",
        "publish_site": True,
    },
    {
        "email": "owner@launch-demo.zanelvo.com",
        "org_name": "Bright Path Coaching",
        "org_slug": "bright-path-coaching",
        "plan": "launch",
        "industry": "professional_services",
    },
    {
        "email": "owner@autopilot-demo.zanelvo.com",
        "org_name": "River & Grain Salon",
        "org_slug": "river-grain-salon",
        "plan": "autopilot",
        "industry": "beauty_wellness",
    },
]


async def _ensure_org_and_user(email: str, org_name: str, org_slug: str,
                                    industry: str) -> Dict[str, Any]:
    db = get_db()
    existing = await db.users.find_one({"email": email})
    if existing:
        org = await db.organizations.find_one({"_id": ObjectId(existing["org_id"])})
        return {"user": existing, "org": org, "password": None}
    org = await db.organizations.find_one({"slug": org_slug})
    if not org:
        r = await db.organizations.insert_one({
            "slug": org_slug, "name": org_name, "industry": industry,
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        org = await db.organizations.find_one({"_id": r.inserted_id})
    org_id = str(org["_id"])
    password = generate_readable_password(16)
    r = await db.users.insert_one({
        "email": email, "password_hash": hash_password(password),
        "full_name": org_name + " Owner",
        "org_id": org_id, "role": "owner",
        "email_verified": True,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    return {"user": await db.users.find_one({"_id": r.inserted_id}),
             "org": org, "password": password}


async def _ensure_minimal_published_site(org_id: str, spec: Dict[str, Any]) -> None:
    db = get_db()
    existing = await db.websites.find_one({"org_id": org_id})
    if existing:
        # Ensure it's published so the branding footer is visible.
        if existing.get("status") != "published":
            await db.websites.update_one({"_id": existing["_id"]}, {"$set": {
                "status": "published", "published_at": utc_now_iso(),
                "updated_at": utc_now_iso(),
            }})
        return
    home_blocks = [
        {"id": "hero-1", "kind": "hero", "props": {
            "eyebrow": spec.get("industry", "").replace("_", " ").title(),
            "heading": f"Welcome to {spec['org_name']}.",
            "subheading": "Trusted local service. Book online in under a minute.",
            "cta_label": "Get a quote", "cta_href": "#contact",
        }, "style": {"align": "left"}},
        {"id": "contact-1", "kind": "contact_form", "props": {
            "heading": "Send us a note",
            "fields": [{"key": "name", "label": "Name", "required": True},
                        {"key": "email", "label": "Email", "required": True},
                        {"key": "message", "label": "Message", "required": False}],
        }, "style": {}},
    ]
    theme = {"primary": "#B85C38", "ink": "#1F1F1F", "surface": "#F7F3EE"}
    slug = spec["org_slug"]
    await db.websites.insert_one({
        "org_id": org_id, "slug": slug,
        "name": spec["org_name"],
        "status": "published",
        "published_pages": [{"slug": "home", "title": "Home", "blocks": home_blocks,
                                "seo": {}, "hidden": False}],
        "published_nav_order": ["home"],
        "published_theme": theme,
        "published_at": utc_now_iso(),
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })


async def seed_phase6() -> None:
    db = get_db()
    logger.info("Phase 6 seed starting…")

    # Help articles (idempotent)
    try:
        await seed_help_articles()
    except Exception as e:  # noqa: BLE001
        logger.exception("help articles seed failed: %s", e)

    # 1. Ensure the main demo owner has an autopilot subscription (matches marketing story)
    demo_user = await db.users.find_one({"email": DEMO_OWNER_EMAIL})
    if demo_user and demo_user.get("org_id"):
        sub = await db.subscriptions.find_one({"org_id": demo_user["org_id"]})
        if not sub:
            await get_or_create_subscription(demo_user["org_id"], "autopilot")
            logger.info("Demo owner subscribed to Autopilot.")
        elif sub.get("plan_code") != "autopilot":
            await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
                "plan_code": "autopilot", "status": "active",
                "updated_at": utc_now_iso(),
            }})

    # 2. Additional thin demo orgs on different plans (for founder dashboard visualisation)
    created_creds = []
    for spec in DEMO_ORGS_PHASE6:
        r = await _ensure_org_and_user(spec["email"], spec["org_name"],
                                            spec["org_slug"], spec["industry"])
        org_id = str(r["org"]["_id"])
        # Subscription
        sub = await db.subscriptions.find_one({"org_id": org_id})
        if not sub:
            await get_or_create_subscription(org_id, spec["plan"])
        elif sub.get("plan_code") != spec["plan"]:
            await db.subscriptions.update_one({"_id": sub["_id"]},
                                                    {"$set": {"plan_code": spec["plan"],
                                                                "status": "active"}})
        # Business profile (light)
        if not await db.business_profiles.find_one({"org_id": org_id}):
            await db.business_profiles.insert_one({
                "org_id": org_id,
                "business_name": spec["org_name"],
                "industry": spec["industry"],
                "industry_label": spec["industry"].replace("_", " ").title(),
                "tagline": "Demo tenant seeded for Phase 6 founder views.",
                "about": "Seeded demo tenant.",
                "services": [], "hours": [], "locations": [],
                "differentiators": [], "policies": [],
                "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
            })
        if r.get("password"):
            created_creds.append({"email": spec["email"], "password": r["password"],
                                    "plan": spec["plan"], "org": spec["org_name"]})
        # Publish a tiny site for the Free demo so the "Powered by Zanelvo" footer is testable.
        if spec.get("publish_site"):
            await _ensure_minimal_published_site(org_id, spec)

    # 3. Feature flag seed
    default_flags = [
        {"key": "public_chat_widget", "label": "Public chat widget",
          "description": "AI receptionist widget rendered on public sites.",
          "enabled_globally": True},
        {"key": "ai_call_simulator", "label": "AI call simulator",
          "description": "In-dashboard voice simulator (real Retell/Twilio arrives later).",
          "enabled_globally": True},
        {"key": "webhooks_outbound", "label": "Outbound webhooks",
          "description": "Fire-and-log webhooks to tenant endpoints.",
          "enabled_globally": True},
        {"key": "ai_support_assistant", "label": "In-app AI support",
          "description": "Grounded help assistant in the Support panel.",
          "enabled_globally": True},
    ]
    for f in default_flags:
        await db.feature_flags.update_one({"key": f["key"]},
                                              {"$set": {**f, "updated_at": utc_now_iso()},
                                               "$setOnInsert": {"created_at": utc_now_iso()}},
                                              upsert=True)

    # 4. Starter coupon
    await db.coupons.update_one({"code": "LAUNCH20"},
                                   {"$set": {"code": "LAUNCH20", "percent_off": 20,
                                              "duration": "once", "active": True,
                                              "updated_at": utc_now_iso()},
                                    "$setOnInsert": {"redemptions": 0,
                                                       "created_at": utc_now_iso(),
                                                       "note": "Onboarding discount"}},
                                   upsert=True)

    # 5. Indexes for new collections
    for coll, idx in [
        ("subscriptions", "org_id"), ("billing_invoices", "org_id"),
        ("api_keys", "key_hash"), ("audit_events", "created_at"),
        ("webhook_deliveries", "created_at"), ("support_tickets", "org_id"),
        ("impersonation_sessions", "founder_user_id"),
    ]:
        try:
            await db[coll].create_index(idx)
        except Exception:  # noqa: BLE001
            pass
    try:
        await db.api_keys.create_index("key_hash", unique=True)
    except Exception:  # noqa: BLE001
        pass
    try:
        await db.coupons.create_index("code", unique=True)
    except Exception:  # noqa: BLE001
        pass

    # 6. Persist creds if any new demo owner was created
    if created_creds:
        creds_path = "/app/memory/test_credentials.md"
        existing = ""
        try:
            with open(creds_path, "r") as f:
                existing = f.read()
        except Exception:  # noqa: BLE001
            pass
        appendix_lines = ["", "## Phase 6 additional demo orgs", ""]
        for c in created_creds:
            appendix_lines.append(f"- **{c['email']}** — `{c['password']}` "
                                    f"(role: owner, plan: {c['plan']}, org: {c['org']})")
        appendix = "\n".join(appendix_lines) + "\n"
        if "Phase 6 additional demo orgs" not in existing:
            with open(creds_path, "a") as f:
                f.write(appendix)
            logger.info("Appended Phase 6 demo credentials to test_credentials.md")
    logger.info("Phase 6 seed complete.")
