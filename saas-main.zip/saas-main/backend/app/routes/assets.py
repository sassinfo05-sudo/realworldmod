"""Asset Library + storage API (tenant-safe, all under /api).

Owner/staff asset management, atomic upload flow, storage usage, references, trash lifecycle,
safe public/private blob serving, plus founder storage-provider configuration (Setup Center).
"""
from __future__ import annotations

import base64
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field

from ..db import get_db
from ..deps import current_user, require_org, require_role
from ..models import User
from ..services import assets as A
from ..services import storage as S
from ..services import secretbox

router = APIRouter(prefix="/assets", tags=["assets"])
public_router = APIRouter(prefix="/public/assets", tags=["assets-public"])
founder_router = APIRouter(prefix="/founder/storage", tags=["storage-admin"])


# ============================= UPLOAD FLOW =============================
class InitIn(BaseModel):
    filename: str
    mime: str
    size: int
    category: str = "other"
    visibility: str = "public"
    idempotency_key: Optional[str] = None


@router.post("/upload/init")
async def upload_init(body: InitIn, user: User = Depends(require_role("owner", "manager", "staff")),
                     org_id: str = Depends(require_org)):
    return await A.init_upload(org_id, user.id, filename=body.filename, mime=body.mime, size=body.size,
                               category=body.category, visibility=body.visibility,
                               idempotency_key=body.idempotency_key)


class FinalizeIn(BaseModel):
    data_base64: str
    alt_text: Optional[str] = None
    caption: Optional[str] = None
    folder: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    source: str = "upload"


@router.post("/upload/{upload_id}/finalize")
async def upload_finalize(upload_id: str, body: FinalizeIn,
                          user: User = Depends(require_role("owner", "manager", "staff")),
                          org_id: str = Depends(require_org)):
    try:
        raw = base64.b64decode(body.data_base64, validate=True)
    except Exception:
        raise HTTPException(400, {"error": "invalid_base64"})
    return await A.finalize_upload(org_id, user.id, upload_id, raw, alt_text=body.alt_text,
                                   caption=body.caption, folder=body.folder, tags=body.tags,
                                   source=body.source)


@router.post("/upload/{upload_id}/cancel")
async def upload_cancel(upload_id: str, user: User = Depends(require_role("owner", "manager", "staff")),
                        org_id: str = Depends(require_org)):
    return await A.cancel_upload(org_id, upload_id)


# ============================= USAGE =============================
@router.get("/usage")
async def usage(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await A.usage_summary(org_id)


@router.get("/breakdown")
async def breakdown(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await A.breakdown(org_id)


@router.post("/reconcile")
async def reconcile(user: User = Depends(require_role("owner", "manager")), org_id: str = Depends(require_org)):
    return await A.reconcile(org_id)


# ============================= LIST / CRUD =============================
@router.get("")
async def list_assets(category: Optional[str] = None, folder: Optional[str] = None, q: Optional[str] = None,
                      trashed: bool = False, unused: bool = False, sort: str = "-created_at",
                      page: int = 1, page_size: int = 40,
                      user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await A.list_assets(org_id, category=category, folder=folder, q=q, trashed=trashed,
                               unused=unused, sort=sort, page=page, page_size=page_size)


@router.get("/{asset_id}")
async def get_asset(asset_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await A.get_asset(org_id, asset_id)


class AssetPatch(BaseModel):
    display_name: Optional[str] = None
    alt_text: Optional[str] = None
    caption: Optional[str] = None
    folder: Optional[str] = None
    visibility: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = None


@router.patch("/{asset_id}")
async def patch_asset(asset_id: str, body: AssetPatch,
                      user: User = Depends(require_role("owner", "manager", "staff")),
                      org_id: str = Depends(require_org)):
    return await A.update_asset(org_id, asset_id, body.model_dump(exclude_none=True))


@router.get("/{asset_id}/signed-url")
async def get_signed_url(asset_id: str, ttl: int = 3600,
                         user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Time-limited URL whose reported `expires_at` equals now + ttl (default 1 hour)."""
    return await A.signed_url_info(org_id, asset_id, ttl=ttl)


@router.get("/{asset_id}/references")
async def references(asset_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    refs = await A.list_references(org_id, asset_id)
    return {"references": refs, "count": len(refs)}


class RefIn(BaseModel):
    feature: str
    record_id: str
    usage_type: str = "content"
    meta: Dict[str, Any] = Field(default_factory=dict)


@router.post("/{asset_id}/references")
async def add_ref(asset_id: str, body: RefIn,
                  user: User = Depends(require_role("owner", "manager", "staff")),
                  org_id: str = Depends(require_org)):
    await A.get_asset(org_id, asset_id)  # 404 if not owned
    return await A.add_reference(org_id, asset_id, feature=body.feature, record_id=body.record_id,
                                 usage_type=body.usage_type, meta=body.meta)


@router.post("/{asset_id}/trash")
async def trash(asset_id: str, user: User = Depends(require_role("owner", "manager", "staff")),
                org_id: str = Depends(require_org)):
    return await A.trash_asset(org_id, user.id, asset_id)


@router.post("/{asset_id}/restore")
async def restore(asset_id: str, user: User = Depends(require_role("owner", "manager", "staff")),
                  org_id: str = Depends(require_org)):
    return await A.restore_asset(org_id, user.id, asset_id)


@router.delete("/{asset_id}")
async def purge(asset_id: str, force: bool = False,
                user: User = Depends(require_role("owner", "manager")),
                org_id: str = Depends(require_org)):
    return await A.purge_asset(org_id, user.id, asset_id, force=force)


# ============================= BLOB SERVING =============================
async def _serve(asset: Dict[str, Any]) -> Response:
    prov = await S.get_provider_for(asset)  # read through the asset's OWN recorded provider
    try:
        data = await prov.get(asset["object_key"])
    except Exception:
        raise HTTPException(404, "not found")
    disp = "inline"
    mime = asset.get("mime") or "application/octet-stream"
    # Force download (never inline-render) for anything that could execute in the browser context.
    if mime in ("image/svg+xml", "text/html", "application/xml", "text/xml") or asset.get("media_type") == "document":
        disp = "attachment"
    return Response(content=data, media_type=mime, headers={
        "Cache-Control": ("public, max-age=31536000, immutable" if asset.get("visibility") == "public"
                          else "private, no-store"),
        "Content-Disposition": f"{disp}; filename=\"{A.safe_name(asset.get('filename') or 'file')}\"",
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; sandbox",
    })


@public_router.get("/{key:path}")
async def serve_public(key: str):
    asset = await get_db()[A.ASSETS].find_one({"object_key": key, "visibility": "public",
                                               "trashed_at": None}, {"_id": 0})
    if not asset:
        raise HTTPException(404, "not found")
    return await _serve(asset)


@router.get("/blob/{key:path}")
async def serve_signed(key: str, exp: str = "", sig: str = ""):
    if not S.verify_signed(key, exp, sig):
        raise HTTPException(403, "invalid or expired signature")
    asset = await get_db()[A.ASSETS].find_one({"object_key": key, "trashed_at": None}, {"_id": 0})
    if not asset:
        raise HTTPException(404, "not found")
    return await _serve(asset)


# ============================= FOUNDER STORAGE CONFIG =============================
@founder_router.get("")
async def get_storage(user: User = Depends(require_role("platform_founder"))):
    cfg = await S.get_storage_config()
    return {"config": S.mask_config(cfg), "status": await S.provider_status()}


class StorageCfgIn(BaseModel):
    provider: Optional[str] = None       # s3 | r2 | b2 | minio
    bucket: Optional[str] = None
    endpoint: Optional[str] = None
    region: Optional[str] = None
    public_base_url: Optional[str] = None
    access_key_id: Optional[str] = None
    secret_access_key: Optional[str] = None


@founder_router.put("")
async def put_storage(body: StorageCfgIn, user: User = Depends(require_role("platform_founder"))):
    patch = body.model_dump(exclude_none=True)
    for f in S.STORAGE_FIELDS_SECRET:
        if patch.get(f):
            patch[f] = secretbox.encrypt(patch[f])  # encrypted at rest
    cur = await S.save_storage_config(patch)  # mints a new config version if the target changed
    return {"config": S.mask_config(cur), "status": await S.provider_status()}


@founder_router.post("/test")
async def test_storage(user: User = Depends(require_role("platform_founder"))):
    return await S.provider_status()


# ============================= STAFF OVERVIEW =============================
@router.get("/staff/overview")
async def staff_overview(user: User = Depends(require_role("platform_founder", "platform_staff"))):
    db = get_db()
    top = [x async for x in db[A.USAGE].find({}, {"_id": 0}).sort("active_bytes", -1).limit(25)]
    fails = await db.storage_delete_failures.count_documents({})
    return {"top_tenants": top, "delete_failures": fails, "provider": await S.provider_status()}


class OverrideIn(BaseModel):
    org_id: str
    bytes: int


@router.put("/staff/override")
async def staff_override(body: OverrideIn, user: User = Depends(require_role("platform_founder", "platform_staff"))):
    from ..db import utc_now_iso
    await get_db()[A.OVERRIDES].update_one({"org_id": body.org_id},
                                           {"$set": {"org_id": body.org_id, "bytes": int(body.bytes),
                                                     "set_by": user.id, "updated_at": utc_now_iso()}},
                                           upsert=True)
    return {"ok": True, "org_id": body.org_id, "bytes": int(body.bytes)}
