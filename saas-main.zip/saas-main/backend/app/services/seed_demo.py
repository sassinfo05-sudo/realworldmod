"""Idempotently seed the demo owner's org with a published site so Phase 2 has a
live example for /site/{slug} testing."""
import logging
import uuid
from typing import List

from bson import ObjectId

from ..db import get_db, utc_now_iso
from ..models import (
    Block, BusinessProfile, HourRow, KeyValue, LocationRow, Page, Service,
    Website, WebsiteTheme,
)
from ..services.publishing import ensure_unique_slug, snapshot_publish

logger = logging.getLogger(__name__)

DEMO_SLUG = "demo-home-services"


def _b(btype, variant="a", **props):
    return Block(id=str(uuid.uuid4()), type=btype, variant=variant, props=props)


def _demo_pages() -> List[Page]:
    home = Page(id=str(uuid.uuid4()), slug="home", title="Home",
                seo={"title": "Demo Home Services — Reliable local plumbing",
                     "description": "Trusted plumbing and repairs for the neighborhood."},
                blocks=[
                    _b("hero", "a",
                       eyebrow="Serving the neighborhood since 2011",
                       headline="Plumbing done right, the first time.",
                       subheadline="Licensed, insured, and up-front about pricing. Same-day service on eight out of ten calls.",
                       primary_cta={"label": "Get a quote", "href": "/contact"},
                       secondary_cta={"label": "See services", "href": "/services"},
                       image="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=1600&auto=format&fit=crop&q=80"),
                    _b("services_grid", "b",
                       eyebrow="What we do",
                       headline="Every job, one clear price.",
                       services=[
                           {"id": "s1", "name": "Emergency callout", "description": "24/7 for burst pipes and leaks.", "price_display": "$180 first hour"},
                           {"id": "s2", "name": "Drain unblock", "description": "Most jobs fixed in one visit.", "price_display": "$220"},
                           {"id": "s3", "name": "Water heater install", "description": "Includes haul-away of the old unit.", "price_display": "from $1,200"},
                       ]),
                    _b("about_split", "a",
                       eyebrow="Why us",
                       headline="Fourteen years, one crew.",
                       body="We're a small crew that answers our own phones. No call centers, no bait pricing. If we quote it, that's the price.",
                       bullets=["Licensed & insured for 14 years", "Flat-rate quotes before we start", "Same-day service on 8/10 calls"],
                       image="https://images.unsplash.com/photo-1591955506264-3f5a6834570a?w=1600&auto=format&fit=crop&q=80"),
                    _b("cta_band", "a",
                       headline="Something dripping, running, or not draining?",
                       subheadline="Send us a photo and we'll quote back within the hour.",
                       primary_cta={"label": "Get a quote", "href": "/contact"},
                       background_image="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1600&auto=format&fit=crop&q=80"),
                    _b("footer", "a",
                       business_name="Demo Home Services",
                       tagline="Reliable plumbing in the neighborhood.",
                       email="hello@demo.zanelvo.com",
                       phone="(555) 010-0123"),
                ])
    services = Page(id=str(uuid.uuid4()), slug="services", title="Services",
                     seo={"title": "Services — Demo Home Services"},
                     blocks=[
                         _b("hero", "c",
                            eyebrow="Services",
                            headline="Every kind of pipe, drain, and heater.",
                            subheadline="Straight-up pricing. Real people on the phone."),
                         _b("services_grid", "b",
                            headline="Full service list",
                            services=[
                                {"id": "s1", "name": "Emergency callout", "description": "24/7 for burst pipes.", "price_display": "$180 first hour"},
                                {"id": "s2", "name": "Drain unblock", "description": "One visit, done.", "price_display": "$220"},
                                {"id": "s3", "name": "Water heater install", "description": "Haul-away included.", "price_display": "from $1,200"},
                                {"id": "s4", "name": "Leak detection", "description": "Non-invasive.", "price_display": "$180"},
                            ]),
                         _b("footer", "a", business_name="Demo Home Services",
                            tagline="Reliable plumbing in the neighborhood.",
                            email="hello@demo.zanelvo.com", phone="(555) 010-0123"),
                     ])
    about = Page(id=str(uuid.uuid4()), slug="about", title="About",
                  seo={"title": "About — Demo Home Services"},
                  blocks=[
                      _b("hero", "c", eyebrow="About", headline="A small crew that answers its own phones."),
                      _b("about_split", "a",
                         headline="Fourteen years, one crew.",
                         body="We started as a two-person outfit and haven't gotten much bigger. It's on purpose.",
                         bullets=["Owner-operated", "Same-day 8/10", "Flat-rate quotes"],
                         image="https://images.unsplash.com/photo-1591955506264-3f5a6834570a?w=1600&auto=format&fit=crop&q=80"),
                      _b("footer", "a", business_name="Demo Home Services",
                         email="hello@demo.zanelvo.com", phone="(555) 010-0123"),
                  ])
    contact = Page(id=str(uuid.uuid4()), slug="contact", title="Contact",
                    seo={"title": "Contact — Demo Home Services"},
                    blocks=[
                        _b("hero", "c", eyebrow="Contact", headline="Send us a note. We answer fast."),
                        _b("contact_hours", "a",
                           headline="Reach us any way you like",
                           subheadline="We answer the phone during hours and call back within the hour outside them.",
                           hours=[
                               {"day": "Mon", "open": "7:00 AM", "close": "6:00 PM", "closed": False},
                               {"day": "Tue", "open": "7:00 AM", "close": "6:00 PM", "closed": False},
                               {"day": "Wed", "open": "7:00 AM", "close": "6:00 PM", "closed": False},
                               {"day": "Thu", "open": "7:00 AM", "close": "6:00 PM", "closed": False},
                               {"day": "Fri", "open": "7:00 AM", "close": "6:00 PM", "closed": False},
                               {"day": "Sat", "open": "8:00 AM", "close": "2:00 PM", "closed": False},
                               {"day": "Sun", "closed": True},
                           ],
                           locations=[{"id": "l1", "city": "Austin", "region": "TX", "phone": "(555) 010-0123"}],
                           email="hello@demo.zanelvo.com", phone="(555) 010-0123"),
                        _b("form", "a",
                           headline="Send us a message",
                           subheadline="Tell us what's going on and we'll get back within one business day.",
                           website_slug="demo-home-services",
                           page_slug="contact",
                           submit_label="Send message",
                           fields=[
                               {"name": "name", "label": "Your name", "type": "text", "required": True},
                               {"name": "email", "label": "Email", "type": "email", "required": True},
                               {"name": "phone", "label": "Phone (optional)", "type": "tel", "required": False},
                               {"name": "message", "label": "How can we help?", "type": "textarea", "required": True},
                           ]),
                        _b("booking", "a",
                           headline="Prefer to book a visit?",
                           subheadline="Pick a service and a slot that works for you.",
                           website_slug="demo-home-services",
                           confirm_label="Confirm booking"),
                        _b("footer", "a", business_name="Demo Home Services",
                           email="hello@demo.zanelvo.com", phone="(555) 010-0123"),
                    ])
    return [home, services, about, contact]


async def _ensure_demo_business_profile(db, org_id: str) -> str:
    """Idempotently ensure the demo org has a BusinessProfile. Returns its id."""
    existing = await db.business_profiles.find_one({"org_id": org_id})
    if existing:
        return str(existing["_id"])
    profile = BusinessProfile(
        org_id=org_id,
        business_name="Demo Home Services",
        industry="home_services",
        industry_label="Home services",
        tagline="Reliable plumbing in the neighborhood.",
        about="A small owner-operated crew serving the neighborhood since 2011. Licensed and insured. Same-day service on 8 of 10 calls.",
        services=[
            Service(id="s1", name="Emergency callout",
                    description="24/7 for burst pipes and leaks.",
                    price=180.0, price_display="$180 first hour",
                    unit="per hour", verified=True),
            Service(id="s2", name="Drain unblock",
                    description="Most jobs fixed in one visit.",
                    price=220.0, price_display="$220", verified=True),
            Service(id="s3", name="Water heater install",
                    description="Includes haul-away of the old unit.",
                    price=1200.0, price_display="from $1,200", verified=True),
        ],
        hours=[
            HourRow(day="Mon", open="7:00 AM", close="6:00 PM", verified=True),
            HourRow(day="Tue", open="7:00 AM", close="6:00 PM", verified=True),
            HourRow(day="Wed", open="7:00 AM", close="6:00 PM", verified=True),
            HourRow(day="Thu", open="7:00 AM", close="6:00 PM", verified=True),
            HourRow(day="Fri", open="7:00 AM", close="6:00 PM", verified=True),
            HourRow(day="Sat", open="8:00 AM", close="2:00 PM", verified=True),
            HourRow(day="Sun", closed=True, verified=True),
        ],
        locations=[
            LocationRow(id="l1", name="Main", city="Austin", region="TX",
                        phone="(555) 010-0123", verified=True),
        ],
        differentiators=[
            KeyValue(id="d1", text="Licensed & insured for 14 years", verified=True),
            KeyValue(id="d2", text="Flat-rate quotes before we start", verified=True),
            KeyValue(id="d3", text="Same-day service on 8/10 calls", verified=True),
        ],
        tone="calm_confident",
        goals=["more_calls", "more_quotes"],
        contact_email="hello@demo.zanelvo.com",
        contact_phone="(555) 010-0123",
    )
    prof_res = await db.business_profiles.insert_one(profile.to_mongo())
    return str(prof_res.inserted_id)


_BAD_UNSPLASH_URLS = {
    # Some Unsplash IDs were retired after we seeded; rewrite them to known-good
    # equivalents on every startup so already-published demo sites don't render broken images.
    "https://images.unsplash.com/photo-1581093458791-9d42cc05dcfe?w=1600&auto=format&fit=crop&q=80":
        "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=1600&auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1585152220000-9d9a1cf1ef95?w=1600&auto=format&fit=crop&q=80":
        "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=1600&auto=format&fit=crop&q=80",
}


def _rewrite_bad_urls_in_pages(pages_list):
    """Walk block props and replace known-dead Unsplash URLs. Returns (pages, changed_count)."""
    if not pages_list:
        return pages_list, 0
    changed = 0

    def rewrite(value):
        nonlocal changed
        if isinstance(value, str) and value in _BAD_UNSPLASH_URLS:
            changed += 1
            return _BAD_UNSPLASH_URLS[value]
        if isinstance(value, dict):
            return {k: rewrite(v) for k, v in value.items()}
        if isinstance(value, list):
            return [rewrite(v) for v in value]
        return value

    new_pages = [rewrite(p) for p in pages_list]
    return new_pages, changed


async def _ensure_form_block_on_contact(db, website_doc) -> bool:
    """Idempotently add a lead-form block AND booking block AND chat widget to the
    demo site: lead form + booking on `contact` (owner-visible priority pages),
    and chat_widget appended to EVERY page's tail so it shows up site-wide.
    Republishes if changes were made.
    """
    changed = False

    def _add_blocks(pages_list, slug_hint):
        nonlocal changed
        out = []
        for p in pages_list:
            page = dict(p)
            blocks = list(page.get("blocks") or [])
            has_chat = any(b.get("type") == "chat_widget" for b in blocks)
            new_blocks_before_footer: list = []
            new_blocks_end: list = []
            if page.get("slug") == "contact":
                had_form = any(b.get("type") == "form" for b in blocks)
                had_booking = any(b.get("type") == "booking" for b in blocks)
                if not had_form:
                    new_blocks_before_footer.append({
                        "id": str(uuid.uuid4()),
                        "type": "form", "variant": "a", "hidden": False,
                        "props": {
                            "headline": "Send us a message",
                            "subheadline": "Tell us what's going on and we'll get back within one business day.",
                            "website_slug": slug_hint,
                            "page_slug": "contact",
                            "submit_label": "Send message",
                            "fields": [
                                {"name": "name", "label": "Your name", "type": "text", "required": True},
                                {"name": "email", "label": "Email", "type": "email", "required": True},
                                {"name": "phone", "label": "Phone (optional)", "type": "tel", "required": False},
                                {"name": "message", "label": "How can we help?", "type": "textarea", "required": True},
                            ],
                        },
                        "style": {},
                    })
                if not had_booking:
                    new_blocks_before_footer.append({
                        "id": str(uuid.uuid4()),
                        "type": "booking", "variant": "a", "hidden": False,
                        "props": {
                            "headline": "Prefer to book a visit?",
                            "subheadline": "Pick a service and a slot that works for you.",
                            "website_slug": slug_hint,
                            "confirm_label": "Confirm booking",
                        },
                        "style": {},
                    })
            if not has_chat:
                new_blocks_end.append({
                    "id": str(uuid.uuid4()),
                    "type": "chat_widget", "variant": "a", "hidden": False,
                    "props": {
                        "website_slug": slug_hint,
                        "title": "Ask us anything",
                        "label": "Chat with us",
                        "accent": "#C85A17",
                    },
                    "style": {},
                })
            if new_blocks_before_footer:
                footer_idx = next((i for i, b in enumerate(blocks) if b.get("type") == "footer"), None)
                if footer_idx is not None:
                    blocks[footer_idx:footer_idx] = new_blocks_before_footer
                else:
                    blocks.extend(new_blocks_before_footer)
                changed = True
            if new_blocks_end:
                blocks.extend(new_blocks_end)
                changed = True
            page["blocks"] = blocks
            out.append(page)
        return out

    slug = website_doc.get("slug") or "demo-home-services"
    updates = {}
    if website_doc.get("pages"):
        new_draft = _add_blocks(website_doc["pages"], slug)
        if changed:
            updates["pages"] = new_draft
    prev_changed = changed
    if website_doc.get("published_pages"):
        new_pub = _add_blocks(website_doc["published_pages"], slug)
        if changed and not prev_changed:
            updates["published_pages"] = new_pub
        elif changed:
            updates["published_pages"] = new_pub
    if updates:
        updates["updated_at"] = utc_now_iso()
        updates["draft_updated_at"] = utc_now_iso()
        await db.websites.update_one({"_id": website_doc["_id"]}, {"$set": updates})
        logger.info("Backfilled lead form + booking + chat widget on demo website %s",
                    website_doc["_id"])
    return changed


async def _migrate_dead_image_urls(db, website_doc):
    """Rewrite dead Unsplash URLs on the demo website in-place (draft + published + revisions)."""
    updates = {}
    for field in ("pages", "published_pages"):
        pages = website_doc.get(field) or []
        rewritten, changed = _rewrite_bad_urls_in_pages(pages)
        if changed:
            updates[field] = rewritten
    if updates:
        updates["updated_at"] = utc_now_iso()
        await db.websites.update_one({"_id": website_doc["_id"]}, {"$set": updates})
        logger.info("Rewrote %d dead Unsplash URLs on demo website %s",
                    sum(1 for f in updates if f.endswith("pages")), website_doc["_id"])
    # Also rewrite in revisions (so rollback doesn't reintroduce a broken URL).
    async for rev in db.revisions.find({"website_id": str(website_doc["_id"])}):
        rev_pages = rev.get("pages") or []
        rewritten, changed = _rewrite_bad_urls_in_pages(rev_pages)
        if changed:
            await db.revisions.update_one(
                {"_id": rev["_id"]},
                {"$set": {"pages": rewritten}},
            )


async def seed_demo_site() -> None:
    db = get_db()
    demo_org = await db.organizations.find_one({"slug": "demo-home-services"})
    if not demo_org:
        return
    org_id = str(demo_org["_id"])

    # Always ensure the BusinessProfile exists (independent of website state) — this
    # backfills for orgs whose website was seeded before the profile was added.
    profile_doc_id = await _ensure_demo_business_profile(db, org_id)

    # If a website is already published for this org, backfill its business_profile_id
    # link if it was left empty by a prior seed, then bail (owner may have edited).
    existing_pub = await db.websites.find_one({"org_id": org_id, "status": "published"})
    if existing_pub:
        if not existing_pub.get("business_profile_id"):
            await db.websites.update_one(
                {"_id": existing_pub["_id"]},
                {"$set": {"business_profile_id": profile_doc_id, "updated_at": utc_now_iso()}},
            )
        # Migrate dead image URLs (idempotent — no-op if already migrated).
        await _migrate_dead_image_urls(db, existing_pub)
        # Ensure the contact page has a lead form block on draft + published.
        # If we added one, republish so /site/{slug} reflects it immediately.
        fresh_doc = await db.websites.find_one({"_id": existing_pub["_id"]})
        form_added = await _ensure_form_block_on_contact(db, fresh_doc)
        if form_added:
            fresh_after = await db.websites.find_one({"_id": existing_pub["_id"]})
            website_obj = Website.from_mongo(fresh_after)
            await snapshot_publish(website_obj, note="Backfill lead form on contact",
                                     author_user_id=None)
            logger.info("Republished demo site with lead form on contact page.")
        return

    theme = WebsiteTheme(
        primary="#D95A2B", secondary="#1E293B", background="#FAFAFA", surface="#FFFFFF",
        foreground="#0F172A", accent="#0EA5E9",
        font_heading="'Fraunces', serif", font_body="'DM Sans', sans-serif",
        industry="home_services",
    )
    pages = _demo_pages()

    existing_ws = await db.websites.find_one({"org_id": org_id})
    if existing_ws:
        ws_id = str(existing_ws["_id"])
        website = Website(
            id=ws_id, org_id=org_id, business_profile_id=profile_doc_id or "",
            theme=theme, pages=pages, nav_order=[p.slug for p in pages],
        )
        await db.websites.update_one(
            {"_id": existing_ws["_id"]},
            {"$set": {
                "theme": theme.model_dump(),
                "pages": [p.model_dump() for p in pages],
                "nav_order": [p.slug for p in pages],
                "business_profile_id": profile_doc_id or "",
                "updated_at": utc_now_iso(),
                "draft_updated_at": utc_now_iso(),
            }},
        )
    else:
        website = Website(
            org_id=org_id, business_profile_id=profile_doc_id or "",
            theme=theme, pages=pages, nav_order=[p.slug for p in pages],
        )
        res = await db.websites.insert_one(website.to_mongo())
        website.id = str(res.inserted_id)

    slug = await ensure_unique_slug(DEMO_SLUG, exclude_website_id=website.id)
    await db.websites.update_one(
        {"_id": ObjectId(website.id)},
        {"$set": {"slug": slug, "updated_at": utc_now_iso()}},
    )
    website.slug = slug
    await snapshot_publish(website, note="Initial demo site seed", author_user_id=None)
    logger.info("Seeded demo published site at slug=%s", slug)
