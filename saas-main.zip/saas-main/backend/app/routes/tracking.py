"""Public (unauthenticated) email tracking endpoints: open pixel + click redirect.

These must be reachable from an email client, so no auth. Mounted at /api/t.
"""
from __future__ import annotations

import base64
from urllib.parse import unquote

from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse, Response

from ..db import get_db
from ..services import campaign_tracking as ct

router = APIRouter(prefix="/api/t", tags=["tracking"])

# 1x1 transparent GIF
_PIXEL = base64.b64decode(
    "R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=="
)


@router.get("/o/{token}.gif")
async def track_open(token: str):
    try:
        await ct.record_open(get_db(), token)
    except Exception:  # noqa: BLE001
        pass
    return Response(content=_PIXEL, media_type="image/gif",
                    headers={"Cache-Control": "no-store, no-cache, must-revalidate, private", "Pragma": "no-cache"})


@router.get("/o/{token}")
async def track_open_no_ext(token: str):
    return await track_open(token)


@router.get("/c/{token}")
async def track_click(token: str, request: Request):
    url = request.query_params.get("u") or ""
    url = unquote(url)
    try:
        await ct.record_click(get_db(), token)
    except Exception:  # noqa: BLE001
        pass
    if not (url.startswith("http://") or url.startswith("https://")):
        url = "/"
    return RedirectResponse(url=url, status_code=302)
