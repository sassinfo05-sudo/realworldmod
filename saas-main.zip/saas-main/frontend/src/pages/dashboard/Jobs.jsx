import { useEffect, useMemo, useState } from "react";
import api from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Wrench, Play, CheckCircle2, XCircle, User } from "lucide-react";

const COLS = [
    { key: "scheduled", label: "Scheduled" },
    { key: "in_progress", label: "In progress" },
    { key: "completed", label: "Completed" },
    { key: "cancelled", label: "Cancelled" },
];

const NEXT_STATUS = {
    scheduled: { next: "in_progress", label: "Start job", Icon: Play },
    in_progress: { next: "completed", label: "Mark complete", Icon: CheckCircle2 },
};

export default function Jobs() {
    const [jobs, setJobs] = useState([]);
    const [staff, setStaff] = useState([]);
    const [filterStaff, setFilterStaff] = useState("all");
    const [loading, setLoading] = useState(true);

    async function load() {
        setLoading(true);
        try {
            const [j, s] = await Promise.all([
                api.get(`/jobs${filterStaff !== "all" ? `?staff_id=${filterStaff}` : ""}`),
                api.get("/booking/staff"),
            ]);
            setJobs(j.data.jobs || []);
            setStaff(s.data.staff || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [filterStaff]);

    const cols = useMemo(() => {
        const map = { scheduled: [], in_progress: [], completed: [], cancelled: [] };
        for (const j of jobs) (map[j.status] = map[j.status] || []).push(j);
        return map;
    }, [jobs]);

    const staffMap = useMemo(() => Object.fromEntries(staff.map((s) => [s.id, s])), [staff]);

    async function advance(jobId, next) {
        try {
            await api.patch(`/jobs/${jobId}`, { status: next });
            toast.success(`Job ${next.replace("_", " ")}`);
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Update failed"); }
    }

    async function toggleChecklist(jobId, itemId, done) {
        try {
            await api.post(`/jobs/${jobId}/checklist/check`, { item_id: itemId, done });
            load();
        } catch (e) { toast.error("Could not update checklist"); }
    }

    return (
        <div className="p-6" data-testid="jobs-page">
            <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Jobs</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Dispatch board</h1>
                    <p className="text-sm text-zinc-500 mt-1">Every crew job in one view. Completed jobs auto-schedule a customer follow-up.</p>
                </div>
                <Select value={filterStaff} onValueChange={setFilterStaff}>
                    <SelectTrigger className="w-52" data-testid="jobs-staff-filter"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All crew</SelectItem>
                        {staff.map((s) => <SelectItem key={s.id} value={s.id}>{s.display_name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3" data-testid="jobs-board">
                {COLS.map((c) => (
                    <div key={c.key} className="rounded-xl border border-brand-line bg-white overflow-hidden">
                        <div className="px-4 py-3 border-b border-brand-line flex items-center justify-between">
                            <div className="text-xs uppercase tracking-widest text-zinc-500">{c.label}</div>
                            <div className="text-xs font-mono text-brand-ink">{(cols[c.key] || []).length}</div>
                        </div>
                        <div className="p-2 space-y-2 min-h-64" data-testid={`jobs-col-${c.key}`}>
                            {(cols[c.key] || []).map((j) => (
                                <div key={j.id} className="rounded-md border border-brand-line p-3 hover:border-brand-copper transition-colors" data-testid={`job-card-${j.id}`}>
                                    <div className="flex items-start justify-between gap-2">
                                        <div className="min-w-0">
                                            <div className="font-medium text-sm text-brand-ink truncate">{j.name}</div>
                                            <div className="text-[10px] font-mono text-zinc-500 mt-0.5">{j.number}</div>
                                        </div>
                                    </div>
                                    {j.staff_id && staffMap[j.staff_id] && (
                                        <div className="mt-2 text-xs text-zinc-500 flex items-center gap-1">
                                            <User className="w-3 h-3" /> {staffMap[j.staff_id].display_name}
                                        </div>
                                    )}
                                    {(j.checklist || []).length > 0 && (
                                        <div className="mt-2 space-y-1">
                                            {j.checklist.slice(0, 4).map((item) => (
                                                <label key={item.id} className="flex items-center gap-2 text-xs cursor-pointer" onClick={(e) => e.stopPropagation()}>
                                                    <input
                                                        type="checkbox"
                                                        checked={!!item.done}
                                                        onChange={(e) => toggleChecklist(j.id, item.id, e.target.checked)}
                                                        data-testid={`job-checklist-${j.id}-${item.id}`}
                                                    />
                                                    <span className={item.done ? "text-zinc-400 line-through" : "text-zinc-700"}>{item.label}</span>
                                                </label>
                                            ))}
                                        </div>
                                    )}
                                    {NEXT_STATUS[j.status] && (
                                        <Button size="sm" variant="outline" className="mt-3 w-full text-xs" onClick={() => advance(j.id, NEXT_STATUS[j.status].next)} data-testid={`job-advance-${j.id}`}>
                                            {(() => { const I = NEXT_STATUS[j.status].Icon; return <I className="w-3.5 h-3.5 mr-1" />; })()}
                                            {NEXT_STATUS[j.status].label}
                                        </Button>
                                    )}
                                </div>
                            ))}
                            {!(cols[c.key] || []).length && (
                                <div className="text-[10px] text-zinc-400 uppercase tracking-widest text-center py-3">no jobs</div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
