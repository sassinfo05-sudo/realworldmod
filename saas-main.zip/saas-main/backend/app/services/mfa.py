"""TOTP-based MFA (pyotp). One-time backup codes issued at enrollment."""
from __future__ import annotations

import base64
import hashlib
import io
import secrets
from typing import List, Tuple

import pyotp
import qrcode


ISSUER = "Zanelvo"


def generate_secret() -> str:
    return pyotp.random_base32()


def encrypt_secret(plain: str) -> str:
    """Encrypt a TOTP secret for storage at rest."""
    from . import secretbox
    return secretbox.encrypt(plain)


def secret_from_doc(doc: dict) -> str:
    """Return the plaintext TOTP secret from a stored mfa_secrets doc, decrypting the
    encrypted value (legacy plaintext values are returned as-is and re-encrypted on next save)."""
    from . import secretbox
    raw = (doc or {}).get("secret_base32") or ""
    return secretbox.decrypt(raw) if str(raw).startswith("enc:v1:") else raw


def totp_uri(secret_base32: str, account_email: str) -> str:
    return pyotp.totp.TOTP(secret_base32).provisioning_uri(
        name=account_email, issuer_name=ISSUER,
    )


def qr_png_data_url(uri: str) -> str:
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def verify_code(secret_base32: str, code: str) -> bool:
    try:
        # Small window tolerates minor clock skew (±30s).
        return pyotp.TOTP(secret_base32).verify((code or "").strip(), valid_window=1)
    except Exception:  # noqa: BLE001
        return False


def generate_backup_codes(count: int = 8) -> Tuple[List[str], List[str]]:
    """Returns (plain_codes, hashed_codes). Show plain once, store hashes only."""
    codes = [_readable_code() for _ in range(count)]
    hashed = [hashlib.sha256(c.encode("utf-8")).hexdigest() for c in codes]
    return codes, hashed


def hash_backup(code: str) -> str:
    return hashlib.sha256(code.strip().encode("utf-8")).hexdigest()


def _readable_code() -> str:
    # 10-char, dash in middle, easy to type.
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    left = "".join(secrets.choice(alphabet) for _ in range(5))
    right = "".join(secrets.choice(alphabet) for _ in range(5))
    return f"{left}-{right}"
