"""Billing routes — plans, entitlements, usage, simulated checkout lifecycle, coupons.

The Stripe adapter is present but returns 400 with an "unavailable" hint when the
STRIPE_SECRET_KEY env is unset. The simulated provider is fully functional so the
whole upgrade / downgrade / cancel / dunning / coupon flow can be exercised end-to-end.
"""
from __future__ import annotations

import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_role, require_org
from ..models import User
from ..services import audit
from ..services.entitlements import (
    ENTITLEMENTS, entitlements_dict, feature_matrix, get_or_create_subscription,
    measure_usage, usage_with_limits,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/billing", tags=["billing"])


# ---------- Public: list plans + entitlement matrix ----------

@router.get("/plans")
async def get_plans():
    db = get_db()
    plans = []
    codes = []
    async for p in db.plans.find({}).sort("order", 1):
        code = p.get("code")
        codes.append(code)
        plans.append({
            "code": code, "name": p.get("name"),
            "price_usd": p.get("price_usd"), "annual_price_usd": p.get("annual_price_usd"),
            "tagline": p.get("tagline"), "audience": p.get("audience"),
            "features": p.get("features") or [], "cta": p.get("cta"),
            "badge": p.get("badge"), "order": p.get("order"),
            "highlight": bool(p.get("highlight")),
            "entitlements": entitlements_dict(code),
        })
    from ..services.entitlements import provider_availability
    avail = await provider_availability()
    return {"plans": plans, "matrix": feature_matrix(codes, avail), "provider_availability": avail}


# ---------- Owner: current subscription + usage ----------

@router.get("/subscription")
async def get_subscription(user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    sub = await get_or_create_subscription(org_id, "free")
    sub["id"] = str(sub.pop("_id"))
    return {"subscription": sub, "plan_code": sub.get("plan_code"),
             "entitlements": entitlements_dict(sub.get("plan_code"))}


@router.get("/usage")
async def get_usage(user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    return await usage_with_limits(org_id)


# ---------- Coupons ----------

class CouponIn(BaseModel):
    code: str = Field(min_length=3, max_length=32)
    percent_off: Optional[int] = Field(default=None, ge=1, le=100)
    amount_off_cents: Optional[int] = Field(default=None, ge=1)
    duration: str = "once"   # once | repeating | forever
    duration_in_months: Optional[int] = Field(default=None, ge=1, le=24)
    max_redemptions: Optional[int] = None
    expires_at: Optional[str] = None
    note: Optional[str] = None


@router.post("/coupons")
async def create_coupon(req: CouponIn,
                          user: User = Depends(require_role("platform_founder"))):
    if not req.percent_off and not req.amount_off_cents:
        raise HTTPException(422, "Set percent_off or amount_off_cents")
    if req.duration == "repeating" and not req.duration_in_months:
        raise HTTPException(422, "duration=repeating needs duration_in_months")
    db = get_db()
    doc = {
        "code": req.code.upper(), "percent_off": req.percent_off,
        "amount_off_cents": req.amount_off_cents,
        "duration": req.duration, "duration_in_months": req.duration_in_months,
        "max_redemptions": req.max_redemptions,
        "redemptions": 0,
        "expires_at": req.expires_at, "active": True, "note": req.note,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    }
    try:
        r = await db.coupons.insert_one(doc)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(409, f"coupon code exists: {e}")
    await audit.record(action="coupon.create", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email,
                          target_type="coupon", target_id=str(r.inserted_id),
                          meta={"code": doc["code"]})
    return {"id": str(r.inserted_id), "code": doc["code"]}


@router.get("/coupons")
async def list_coupons(user: User = Depends(require_role("platform_founder"))):
    db = get_db()
    out = []
    async for c in db.coupons.find({}).sort("created_at", -1):
        out.append({"id": str(c["_id"]), "code": c.get("code"),
                     "percent_off": c.get("percent_off"),
                     "amount_off_cents": c.get("amount_off_cents"),
                     "duration": c.get("duration"),
                     "duration_in_months": c.get("duration_in_months"),
                     "max_redemptions": c.get("max_redemptions"),
                     "redemptions": c.get("redemptions", 0),
                     "active": c.get("active", True),
                     "expires_at": c.get("expires_at"),
                     "note": c.get("note")})
    return {"coupons": out}


async def _resolve_and_apply_coupon(code: Optional[str], price_cents: int) -> Dict[str, Any]:
    """Return {'valid': bool, 'coupon': {...}, 'discount_cents': int, 'reason': str}"""
    if not code:
        return {"valid": False, "coupon": None, "discount_cents": 0, "reason": "no code"}
    db = get_db()
    c = await db.coupons.find_one({"code": code.upper(), "active": True})
    if not c:
        return {"valid": False, "coupon": None, "discount_cents": 0, "reason": "not found"}
    if c.get("expires_at"):
        try:
            exp = datetime.fromisoformat(c["expires_at"].replace("Z", "+00:00"))
            if exp < datetime.now(timezone.utc):
                return {"valid": False, "coupon": None, "discount_cents": 0, "reason": "expired"}
        except Exception:  # noqa: BLE001
            pass
    if c.get("max_redemptions") and c.get("redemptions", 0) >= c["max_redemptions"]:
        return {"valid": False, "coupon": None, "discount_cents": 0, "reason": "max redemptions"}
    if c.get("percent_off"):
        discount = int(price_cents * (c["percent_off"] / 100.0))
    else:
        discount = min(price_cents, int(c.get("amount_off_cents") or 0))
    return {"valid": True, "coupon": {**c, "id": str(c["_id"])},
             "discount_cents": max(0, discount), "reason": "ok"}


# ---------- Simulated checkout (upgrade/downgrade/cancel) ----------

class CheckoutStartReq(BaseModel):
    plan_code: str
    coupon_code: Optional[str] = None
    provider: str = "simulated"    # simulated | stripe | paypal (real rails need staff-panel keys)
    interval: str = "monthly"      # monthly | annual


@router.post("/checkout")
async def start_checkout(req: CheckoutStartReq, request: Request,
                            user: User = Depends(require_role("owner", "manager")),
                            org_id: str = Depends(require_org)):
    """Start a checkout session.

    - Real providers (stripe) create a provider-hosted session with a
      server-computed, immutable amount and complete ONLY via a signed webhook.
    - The simulated provider is available ONLY in non-production environments
      (APP_ENV in dev/test/demo). Production refuses simulated money flows.
    """
    from .. import config as cfg
    db = get_db()
    plan_doc = await db.plans.find_one({"code": req.plan_code})
    if not plan_doc:
        raise HTTPException(404, f"Unknown plan {req.plan_code}")
    from ..services.integrations import payment_methods_public
    rails = await payment_methods_public()
    provider = req.provider if req.provider in ("stripe", "paypal") else "simulated"

    if provider == "stripe" and not rails["stripe"]:
        raise HTTPException(400, {"error": "provider_not_connected",
                                  "message": "Stripe is not connected yet. The Zanelvo team enables it in Staff → Payments."})
    if provider == "paypal":
        # PayPal live completion (signed webhook verification) is not implemented yet.
        # Never offer it as a live rail — that would let money move without verification.
        raise HTTPException(400, {"error": "provider_not_available",
                                  "message": "PayPal is not available yet. Please use card checkout."})
    if provider == "simulated" and not cfg.simulation_allowed():
        # Production must never mint a paid plan through the simulated flow.
        raise HTTPException(400, {"error": "payments_not_configured",
                                  "message": "No live payment provider is connected. Contact support to enable checkout."})

    interval = "annual" if req.interval == "annual" else "monthly"
    # Server-computed, immutable amount — the client never supplies a price.
    if interval == "annual":
        annual = plan_doc.get("annual_price_usd")
        if annual is None:
            annual = (plan_doc.get("price_usd") or 0) * 12 * 0.8
        price_cents = int(round(float(annual) * 100))
    else:
        price_cents = int((plan_doc.get("price_usd") or 0) * 100)
    coupon = await _resolve_and_apply_coupon(req.coupon_code, price_cents)
    amount_cents = max(0, price_cents - coupon["discount_cents"])
    currency = (plan_doc.get("currency") or "usd").lower()
    now = datetime.now(timezone.utc)
    session_doc = {
        "org_id": org_id, "plan_code": req.plan_code,
        "coupon_code": (coupon["coupon"] or {}).get("code") if coupon["valid"] else None,
        "provider": provider,
        "interval": interval,
        "status": "pending",
        "currency": currency,
        # Immutable price snapshot captured server-side at start.
        "price_cents": amount_cents,
        "plan_price_snapshot": {
            "plan_code": req.plan_code,
            "price_usd": plan_doc.get("price_usd"),
            "annual_price_usd": plan_doc.get("annual_price_usd"),
            "interval": interval,
            "currency": currency,
        },
        "expires_at": (now + timedelta(minutes=30)).isoformat().replace("+00:00", "Z"),
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    }
    r = await db.checkout_sessions.insert_one(session_doc)
    sid = str(r.inserted_id)

    checkout_url = f"/pay/simulated/subscription/{sid}"
    provider_session_id = None
    if provider == "stripe":
        # Create a REAL provider session; completion happens only via signed webhook.
        from ..services.payment_providers import StripeProvider, CheckoutRequest
        origin = request.headers.get("origin") or os.environ.get("PUBLIC_APP_URL") or ""
        origin = origin.rstrip("/")
        sp = StripeProvider()
        result = await sp.create_checkout(CheckoutRequest(
            invoice_id=sid, amount_cents=amount_cents, currency=currency,
            customer_email=user.email,
            success_url=f"{origin}/app/billing",
            cancel_url=f"{origin}/pricing",
            metadata={"checkout_session_id": sid, "org_id": org_id,
                       "kind": "subscription", "plan_code": req.plan_code},
        ))
        if not result.ok or not result.checkout_url:
            await db.checkout_sessions.update_one({"_id": r.inserted_id},
                {"$set": {"status": "error", "error": result.error or "provider error"}})
            raise HTTPException(502, {"error": "provider_error",
                                      "message": "Could not start Stripe checkout. Please try again."})
        checkout_url = result.checkout_url
        provider_session_id = result.session_id
        await db.checkout_sessions.update_one({"_id": r.inserted_id},
            {"$set": {"provider_session_id": provider_session_id, "updated_at": utc_now_iso()}})

    await audit.record(action="subscription.checkout_start", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="checkout_session", target_id=sid,
                          reason=req.plan_code, meta={"coupon": session_doc.get("coupon_code"),
                                                        "provider": provider},
                          request=request)
    return {"id": sid, "checkout_url": checkout_url, "provider": provider,
             "amount_cents": amount_cents,
             "coupon_valid": coupon["valid"], "coupon_reason": coupon["reason"]}


@router.post("/checkout/{sid}/complete")
async def complete_checkout(sid: str, request: Request,
                               user: User = Depends(current_user)):
    """Complete a SIMULATED checkout (non-production only). Real providers must
    complete via their signed, idempotent webhook — never through this endpoint.

    Idempotent: flips the sub, writes a billing invoice, redeems the coupon and
    resets dunning state.
    """
    from .. import config as cfg
    db = get_db()
    # HARD GATE 1: production never accepts simulated completion.
    if not cfg.simulation_allowed():
        raise HTTPException(403, {"error": "simulated_completion_forbidden",
                                  "message": "Payments are completed by the provider webhook. This endpoint is disabled in production."})
    sess = await db.checkout_sessions.find_one({"_id": ObjectId(sid)})
    if not sess:
        raise HTTPException(404, "Session not found")
    # HARD GATE 2: only simulated sessions may complete here; real provider
    # sessions (stripe/paypal) MUST be activated by their verified webhook.
    if (sess.get("provider") or "simulated") != "simulated":
        raise HTTPException(400, {"error": "provider_completion_required",
                                  "message": "This checkout is completed by the payment provider webhook, not manually."})
    org_id = sess["org_id"]
    if user.org_id != org_id and user.role != "platform_founder":
        raise HTTPException(403, "Not your session")
    if sess.get("status") == "completed":
        return {"ok": True, "already": True}
    now = datetime.now(timezone.utc)
    interval = sess.get("interval") or "monthly"
    period_end = now + timedelta(days=365 if interval == "annual" else 30)
    sub = await get_or_create_subscription(org_id, sess["plan_code"])
    # Apply the change
    await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
        "plan_code": sess["plan_code"], "status": "active", "interval": interval,
        "current_period_start": now.isoformat().replace("+00:00", "Z"),
        "current_period_end": period_end.isoformat().replace("+00:00", "Z"),
        "cancel_at_period_end": False,
        "canceled_at": None,
        "coupon_code": sess.get("coupon_code"),
        "last_payment_at": utc_now_iso(),
        "failed_payment_count": 0, "last_payment_failed_at": None,
        "updated_at": utc_now_iso(),
    }})
    # Redeem coupon (idempotent when session state guards it)
    if sess.get("coupon_code"):
        await db.coupons.update_one({"code": sess["coupon_code"]},
                                        {"$inc": {"redemptions": 1}})
    # Billing invoice
    number = f"BI-{now.year}-{secrets.token_hex(2).upper()}"
    plan_doc = await db.plans.find_one({"code": sess["plan_code"]}) or {}
    subtotal_cents = int(round(float(plan_doc.get("annual_price_usd") or (plan_doc.get("price_usd") or 0) * 12 * 0.8) * 100)) \
        if interval == "annual" else int((plan_doc.get("price_usd") or 0) * 100)
    total_cents = sess["price_cents"]
    discount_cents = max(0, subtotal_cents - total_cents)
    await db.billing_invoices.insert_one({
        "org_id": org_id, "number": number,
        "plan_code": sess["plan_code"],
        "subtotal_cents": subtotal_cents, "discount_cents": discount_cents,
        "total_cents": total_cents,
        "period_start": now.isoformat().replace("+00:00", "Z"),
        "period_end": period_end.isoformat().replace("+00:00", "Z"),
        "status": "paid", "provider": "simulated",
        "interval": interval,
        "line_items": [{"label": f"{plan_doc.get('name') or sess['plan_code'].title()} plan ({'1 year' if interval == 'annual' else '1 month'})",
                          "amount_cents": subtotal_cents}]
                          + ([{"label": f"Coupon {sess['coupon_code']}",
                                "amount_cents": -discount_cents}] if discount_cents else []),
        "paid_at": utc_now_iso(),
        "coupon_code": sess.get("coupon_code"),
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    await db.checkout_sessions.update_one({"_id": sess["_id"]}, {"$set": {
        "status": "completed", "completed_at": utc_now_iso(), "updated_at": utc_now_iso(),
    }})
    await audit.record(action="subscription.upgrade", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="subscription", target_id=str(sub["_id"]),
                          reason=sess["plan_code"], request=request,
                          meta={"coupon": sess.get("coupon_code"),
                                "total_cents": total_cents})
    return {"ok": True, "plan_code": sess["plan_code"], "invoice_number": number}


@router.get("/checkout/{sid}")
async def get_checkout(sid: str, user: User = Depends(current_user)):
    db = get_db()
    sess = await db.checkout_sessions.find_one({"_id": ObjectId(sid)})
    if not sess:
        raise HTTPException(404, "Not found")
    if user.org_id != sess["org_id"] and user.role != "platform_founder":
        raise HTTPException(403, "Not yours")
    sess["id"] = str(sess.pop("_id"))
    return sess


# ---------- Downgrade / cancel ----------

class DowngradeReq(BaseModel):
    plan_code: str


@router.post("/subscription/downgrade")
async def downgrade(req: DowngradeReq, request: Request,
                       user: User = Depends(require_role("owner")),
                       org_id: str = Depends(require_org)):
    """Downgrades run at end-of-period after validating usage fits the target plan.
    Never triggers charges — the current plan runs until period_end.
    """
    db = get_db()
    target = ENTITLEMENTS.get(req.plan_code)
    if not target:
        raise HTTPException(404, f"unknown plan {req.plan_code}")
    usage = await measure_usage(org_id)
    conflicts: List[str] = []
    if usage["users"] > target.max_users:
        conflicts.append(f"You have {usage['users']} users; {target.label} allows {target.max_users}.")
    if usage["contacts"] > target.max_contacts:
        conflicts.append(f"You have {usage['contacts']} contacts; {target.label} allows {target.max_contacts}.")
    if usage["websites"] > target.websites:
        conflicts.append(f"You have {usage['websites']} websites; {target.label} allows {target.websites}.")
    if conflicts:
        raise HTTPException(409, {"error": "downgrade_would_break",
                                     "conflicts": conflicts, "target_plan": req.plan_code})
    sub = await get_or_create_subscription(org_id, "free")
    await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
        "cancel_at_period_end": False,
        "pending_plan_code": req.plan_code,
        "updated_at": utc_now_iso(),
    }})
    await audit.record(action="subscription.downgrade_scheduled",
                          actor_user_id=user.id, actor_role=user.role,
                          actor_email=user.email, org_id=org_id,
                          target_type="subscription", target_id=str(sub["_id"]),
                          reason=req.plan_code, request=request)
    return {"ok": True, "effective_at": sub.get("current_period_end")}


@router.post("/subscription/cancel")
async def cancel(request: Request, reason: str = Body(default="", embed=True),
                    survey_answer: str = Body(default="", embed=True),
                    user: User = Depends(require_role("owner")),
                    org_id: str = Depends(require_org)):
    """Cancel at end-of-period; access continues until then."""
    db = get_db()
    sub = await get_or_create_subscription(org_id, "free")
    await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
        "cancel_at_period_end": True, "canceled_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }})
    # Store the cancellation survey
    await db.cancellation_surveys.insert_one({
        "org_id": org_id, "reason": reason, "survey_answer": survey_answer,
        "created_at": utc_now_iso(),
    })
    await audit.record(action="subscription.cancel", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="subscription", target_id=str(sub["_id"]),
                          reason=reason or None, request=request)
    return {"ok": True, "effective_at": sub.get("current_period_end")}


@router.post("/subscription/resume")
async def resume(request: Request,
                    user: User = Depends(require_role("owner")),
                    org_id: str = Depends(require_org)):
    """Undo a pending cancel-at-period-end."""
    db = get_db()
    sub = await get_or_create_subscription(org_id, "free")
    await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
        "cancel_at_period_end": False, "canceled_at": None,
        "updated_at": utc_now_iso(),
    }})
    await audit.record(action="subscription.resume", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="subscription", target_id=str(sub["_id"]),
                          request=request)
    return {"ok": True}


# ---------- Simulated dunning trigger ----------

@router.post("/subscription/simulate-payment-failure")
async def simulate_dunning(request: Request,
                              user: User = Depends(require_role("owner", "platform_founder"))):
    """Test hook: mark the caller's subscription as past_due to visualise dunning."""
    from .. import config as cfg
    if not cfg.simulation_allowed():
        raise HTTPException(403, {"error": "test_hook_disabled",
                                  "message": "Dunning simulation is disabled in production."})
    if user.role == "platform_founder" and not user.org_id:
        raise HTTPException(400, "Founder has no org; impersonate a tenant first")
    org_id = user.org_id
    db = get_db()
    sub = await get_or_create_subscription(org_id, "free")
    await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
        "status": "past_due",
        "failed_payment_count": (sub.get("failed_payment_count") or 0) + 1,
        "last_payment_failed_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }})
    return {"ok": True}


# ---------- Billing invoices ----------

@router.get("/invoices")
async def list_billing_invoices(user: User = Depends(current_user),
                                    org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for i in db.billing_invoices.find({"org_id": org_id}) \
                                             .sort("created_at", -1).limit(50):
        out.append({"id": str(i["_id"]), "number": i.get("number"),
                     "plan_code": i.get("plan_code"),
                     "subtotal_cents": i.get("subtotal_cents"),
                     "discount_cents": i.get("discount_cents"),
                     "total_cents": i.get("total_cents"),
                     "status": i.get("status"),
                     "period_start": i.get("period_start"),
                     "period_end": i.get("period_end"),
                     "paid_at": i.get("paid_at")})
    return {"invoices": out}



# ---------- Real Stripe webhook (honest: rejects until STRIPE_WEBHOOK_SECRET is set) ----------

@router.post("/webhook/paypal")
async def paypal_webhook(request: Request):
    """Round 11 — PayPal webhook, verified through PayPal's verify-webhook-signature API.

    Refuses (400) whenever verification is not possible or fails. Idempotent on PayPal event id
    (`paypal_events`). Handles CHECKOUT.ORDER.APPROVED / PAYMENT.CAPTURE.COMPLETED for store orders and
    subscription checkout sessions whose `custom_id` carries our session/order id. Live PayPal checkout
    creation is still refused elsewhere until credentials exist — this endpoint simply makes the rail
    signature-safe on day one.
    """
    import json as _json
    from ..services import integrations as integ
    from ..services.payment_providers import PayPalWebhookVerifier

    payload = await request.body()
    verifier = PayPalWebhookVerifier(
        client_id=await integ.get_secret("payments", "paypal_client_id"),
        client_secret=await integ.get_secret("payments", "paypal_client_secret"),
        webhook_id=await integ.get_secret("payments", "paypal_webhook_id"),
        sandbox=(await integ.get_secret("payments", "paypal_mode") or "sandbox") != "live")
    if not verifier.is_configured:
        raise HTTPException(400, "PayPal webhook not configured (client id / secret / webhook id missing)")
    if not await verifier.verify(dict(request.headers), payload):
        raise HTTPException(400, "Invalid or unverifiable PayPal signature")
    try:
        event = _json.loads(payload.decode("utf-8"))
    except Exception:  # noqa: BLE001
        raise HTTPException(400, "Malformed JSON body")
    db = get_db()
    event_id = event.get("id")
    if event_id:
        if await db.paypal_events.find_one({"_id": event_id}):
            return {"ok": True, "duplicate": True}
        await db.paypal_events.insert_one({"_id": event_id, "type": event.get("event_type"), "received_at": utc_now_iso()})
    etype = event.get("event_type") or ""
    res = (event.get("resource") or {})
    custom = res.get("custom_id") or ((res.get("purchase_units") or [{}])[0].get("custom_id") if res.get("purchase_units") else None)
    if etype in ("PAYMENT.CAPTURE.COMPLETED", "CHECKOUT.ORDER.APPROVED") and custom:
        order = await db.store_orders.find_one({"_id": custom})
        if order:
            from .store import _finalize_paid_order
            await _finalize_paid_order(db, order)
            return {"ok": True, "applied": "store_order", "order_id": custom}
        sess = await db.checkout_sessions.find_one({"_id": custom}) if hasattr(db, "checkout_sessions") else None
        if sess:
            return {"ok": True, "applied": "checkout_session", "note": "completion handled by billing session finalizer"}
    return {"ok": True, "ignored": etype}


@router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    """Verify a real Stripe webhook signature, then apply the event idempotently.

    - 400 on missing/invalid signature (also 400 when STRIPE_WEBHOOK_SECRET unset —
      honest: we cannot verify, so we refuse).
    - Idempotent on Stripe's event id via the `stripe_events` collection: a replayed
      event returns {"ok": true, "duplicate": true} and does not re-apply.
    - Handles `checkout.session.completed`:
        * metadata.kind == "store_order"  -> mark the store order paid (+ decrement stock)
        * metadata.invoice_id             -> apply the booking-invoice paid event
        * subscription checkout session    -> complete the checkout_session + activate sub
    """
    import json as _json
    from ..services.payment_providers import StripeProvider

    payload = await request.body()
    sig = request.headers.get("Stripe-Signature") or request.headers.get("stripe-signature")
    # Platform webhook secret comes from the encrypted Staff Setup Center (env only as a fallback).
    from ..services import stripe_connect
    _wh = await stripe_connect.platform_webhook_secret()
    provider = StripeProvider(webhook_secret=_wh or None)
    if not provider.verify_webhook(payload, sig):
        raise HTTPException(400, "Invalid or unverifiable Stripe signature")
    try:
        event = _json.loads(payload.decode("utf-8"))
    except Exception:  # noqa: BLE001
        raise HTTPException(400, "Malformed JSON body")

    event_id = event.get("id")
    db = get_db()
    if event_id:
        # ATOMIC idempotency claim: unique _id insert — concurrent duplicate deliveries race here and
        # exactly one wins; the rest return duplicate=true without re-applying.
        from pymongo.errors import DuplicateKeyError
        try:
            await db.stripe_events.insert_one({"_id": event_id, "type": event.get("type"),
                                                "account": event.get("account"), "received_at": utc_now_iso()})
        except DuplicateKeyError:
            return {"ok": True, "duplicate": True}

    # Tenant ownership: Connect events carry the connected account id. The object being finalized MUST
    # belong to the org that owns that connected account — otherwise reject (403) and keep the claim so
    # the forged/misrouted event is never re-applied.
    acct = event.get("account")
    if acct:
        owner_org = await stripe_connect.org_for_connected_account(acct)
        obj = (event.get("data") or {}).get("object") or {}
        meta = obj.get("metadata") or {}
        target_org = None
        if meta.get("kind") == "store_order" and meta.get("order_id"):
            o = await db.store_orders.find_one({"_id": meta["order_id"]}, {"org_id": 1})
            target_org = (o or {}).get("org_id")
        elif meta.get("invoice_id"):
            pdoc = await db.payments.find_one({"provider_session_id": obj.get("id")}, {"org_id": 1})
            target_org = (pdoc or {}).get("org_id")
        if target_org and owner_org != target_org:
            await db.stripe_events.update_one({"_id": event_id}, {"$set": {"rejected": "tenant_mismatch"}})
            raise HTTPException(403, "Event account does not own the referenced object")

    result = await _handle_stripe_event(db, event)
    return {"ok": True, **result}


async def _handle_stripe_event(db, event: Dict[str, Any]) -> Dict[str, Any]:
    etype = event.get("type")
    obj = (event.get("data") or {}).get("object") or {}
    if etype != "checkout.session.completed":
        return {"handled": False, "type": etype}
    meta = obj.get("metadata") or {}
    session_id = obj.get("id")
    handled: List[str] = []

    # 1) Store order
    if meta.get("kind") == "store_order" and meta.get("order_id"):
        from .store import mark_store_order_paid_by_id
        if await mark_store_order_paid_by_id(db, meta["order_id"]):
            handled.append("store_order")

    # 2) Booking invoice (payments doc keyed by the stripe session id)
    if meta.get("invoice_id") and session_id:
        pay = await db.payments.find_one({"provider_session_id": session_id})
        if pay:
            from .bookings import _apply_paid_event
            await _apply_paid_event(db, session_id, obj.get("amount_total"))
            handled.append("invoice")

    # 3) Subscription checkout session (match our checkout_sessions doc)
    csid = meta.get("checkout_session_id")
    sess = None
    if csid:
        try:
            sess = await db.checkout_sessions.find_one({"_id": ObjectId(csid)})
        except Exception:  # noqa: BLE001
            sess = None
    if not sess and session_id:
        sess = await db.checkout_sessions.find_one({"provider_session_id": session_id})
    if sess and sess.get("status") != "completed":
        now = datetime.now(timezone.utc)
        period_end = now + timedelta(days=30)
        sub = await get_or_create_subscription(sess["org_id"], sess["plan_code"])
        await db.subscriptions.update_one({"_id": sub["_id"]}, {"$set": {
            "plan_code": sess["plan_code"], "status": "active",
            "current_period_start": now.isoformat().replace("+00:00", "Z"),
            "current_period_end": period_end.isoformat().replace("+00:00", "Z"),
            "cancel_at_period_end": False, "canceled_at": None,
            "last_payment_at": utc_now_iso(), "failed_payment_count": 0,
            "updated_at": utc_now_iso(),
        }})
        number = f"BI-{now.year}-{secrets.token_hex(2).upper()}"
        await db.billing_invoices.insert_one({
            "org_id": sess["org_id"], "number": number, "plan_code": sess["plan_code"],
            "subtotal_cents": sess.get("price_cents", 0), "discount_cents": 0,
            "total_cents": sess.get("price_cents", 0),
            "status": "paid", "provider": "stripe", "paid_at": utc_now_iso(),
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
        })
        await db.checkout_sessions.update_one({"_id": sess["_id"]}, {"$set": {
            "status": "completed", "completed_at": utc_now_iso(), "updated_at": utc_now_iso()}})
        handled.append("subscription")

    return {"handled": handled}
