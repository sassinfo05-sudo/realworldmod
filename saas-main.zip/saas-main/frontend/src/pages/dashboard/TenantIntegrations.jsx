import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { CreditCard, Mail, MessageCircle, ShoppingBag, CheckCircle2, Circle, ExternalLink, Info } from "lucide-react";

// Grouped provider setup instructions — used as inline "how to get your key" cards.
const INSTRUCTIONS = {
    stripe: {
        title: "Connect Stripe",
        steps: [
            "Go to https://dashboard.stripe.com/apikeys",
            "Copy your live 'Secret key' (starts with sk_live_…) and paste it below",
            "Copy the 'Publishable key' (starts with pk_live_…) and paste it below",
            "In Stripe → Developers → Webhooks, add endpoint: {backend}/api/billing/webhook/stripe",
            "Subscribe to the 'checkout.session.completed' event, then copy the Signing secret (whsec_…) into the Webhook Secret field below",
            "Save, then use the 'Store payment mode' switch below to flip your store Live",
        ],
        link: "https://dashboard.stripe.com/apikeys",
    },
    paypal: {
        title: "Connect PayPal",
        steps: [
            "Sign in at https://developer.paypal.com/dashboard/",
            "Create or open an app → copy the Client ID and Secret",
            "Use 'Live' credentials to accept real payments",
        ],
        link: "https://developer.paypal.com/dashboard/",
    },
    sendgrid: {
        title: "Connect SendGrid",
        steps: [
            "Sign in at https://app.sendgrid.com/",
            "Settings → API Keys → Create API Key with 'Mail Send' permission",
            "Verify your sending domain (SPF + DKIM) for best deliverability",
            "Paste the API Key and set the 'From' address to something on your verified domain",
        ],
        link: "https://app.sendgrid.com/",
    },
    resend: {
        title: "Connect Resend",
        steps: [
            "Sign in at https://resend.com/",
            "API Keys → Create API Key with full access",
            "Add your sending domain and complete DNS verification",
            "Paste the key and set a From address on that domain",
        ],
        link: "https://resend.com/",
    },
    smtp: {
        title: "Connect SMTP",
        steps: [
            "Get SMTP credentials from your host (Google Workspace, Zoho, Mailgun, etc.)",
            "Host: smtp.example.com · Port: 587 (STARTTLS) or 465 (SSL)",
            "Username & password from your provider",
            "Set a From address that matches the account",
        ],
        link: "",
    },
    twilio: {
        title: "Connect Twilio (SMS + voice)",
        steps: [
            "Sign in at https://console.twilio.com/",
            "Copy 'Account SID' and 'Auth Token' from the console",
            "Buy a phone number and paste it as 'From number'",
        ],
        link: "https://console.twilio.com/",
    },
    retell: {
        title: "Connect Retell AI (voice)",
        steps: [
            "Sign in at https://dashboard.retellai.com/",
            "Create an API key with 'call' permission",
            "Paste the key below",
        ],
        link: "https://dashboard.retellai.com/",
    },
    aliexpress: {
        title: "Connect AliExpress (dropshipping feed)",
        steps: [
            "Register as an affiliate at https://portals.aliexpress.com/",
            "Get your API key and secret from the developer console",
            "Paste both below",
        ],
        link: "https://portals.aliexpress.com/",
    },
    cj_dropshipping: {
        title: "Connect CJ Dropshipping",
        steps: [
            "Sign in at https://developers.cjdropshipping.com/",
            "Create an API key from the developer console",
            "Paste it below",
        ],
        link: "https://developers.cjdropshipping.com/",
    },
};

export default function TenantIntegrations() {
    const [loading, setLoading] = useState(true);
    const [integ, setInteg] = useState({});
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get("/tenant/integrations");
                setInteg(data);
            } catch (e) {
                toast.error("Couldn't load integrations");
            } finally { setLoading(false); }
        })();
    }, []);

    async function save(section) {
        setBusy(true);
        try {
            const { data } = await api.put("/tenant/integrations", { [section]: integ[section] });
            setInteg(data);
            toast.success("Saved");
        } catch (e) { toast.error("Save failed"); }
        finally { setBusy(false); }
    }

    function setField(section, field, value) {
        setInteg((prev) => ({ ...prev, [section]: { ...(prev[section] || {}), [field]: value } }));
    }

    if (loading) return <div className="p-10 text-zinc-500">Loading integrations…</div>;

    return (
        <div className="p-6 md:p-10" data-testid="tenant-integrations-page">
            <div className="max-w-5xl">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Integrations</div>
                <h1 className="font-display text-3xl text-brand-ink">Bring your own accounts.</h1>
                <p className="mt-3 text-zinc-600 max-w-2xl">
                    Connect the tools you already use so payments, emails, SMS and product feeds run on
                    <em> your</em> credentials — not ours. Keys are stored encrypted and never displayed again.
                </p>

                {/* Payments */}
                <Section
                    icon={CreditCard} title="Payments"
                    subtitle="Take real payments on your site — checkout, quotes, invoices."
                    section={integ.payments} sectionKey="payments">
                    <StripeConnectPanel />
                </Section>

                {/* Email */}
                <Section
                    icon={Mail} title="Email sending"
                    subtitle="Send transactional email, receipts and campaigns from your domain."
                    section={integ.email} sectionKey="email">
                    <Select value={integ.email?.provider || "none"}
                            onChange={(v) => setField("email", "provider", v)}
                            testid="email-provider"
                            options={[
                                { value: "none", label: "Not connected (emails go through platform default)" },
                                { value: "sendgrid", label: "SendGrid" },
                                { value: "resend", label: "Resend" },
                                { value: "smtp", label: "Custom SMTP" },
                            ]} />
                    {integ.email?.provider !== "none" && integ.email?.provider && (
                        <>
                            <div className="grid sm:grid-cols-2 gap-3">
                                <PlainField label="From email" placeholder="hello@yourdomain.com"
                                             value={integ.email?.from_email || ""}
                                             onChange={(v) => setField("email", "from_email", v)}
                                             testid="email-from-email" />
                                <PlainField label="From name" placeholder="Your Business"
                                             value={integ.email?.from_name || ""}
                                             onChange={(v) => setField("email", "from_name", v)}
                                             testid="email-from-name" />
                            </div>
                        </>
                    )}
                    {integ.email?.provider === "sendgrid" && (
                        <>
                            <InstructionCard {...INSTRUCTIONS.sendgrid} />
                            <SecretField label="SendGrid API key" placeholder="SG.xxxx.xxxx"
                                          masked={integ.email?.sendgrid_api_key}
                                          onChange={(v) => setField("email", "sendgrid_api_key", v)}
                                          testid="sendgrid-key" />
                        </>
                    )}
                    {integ.email?.provider === "resend" && (
                        <>
                            <InstructionCard {...INSTRUCTIONS.resend} />
                            <SecretField label="Resend API key" placeholder="re_xxxxxxxxxx"
                                          masked={integ.email?.resend_api_key}
                                          onChange={(v) => setField("email", "resend_api_key", v)}
                                          testid="resend-key" />
                        </>
                    )}
                    {integ.email?.provider === "smtp" && (
                        <>
                            <InstructionCard {...INSTRUCTIONS.smtp} />
                            <div className="grid sm:grid-cols-2 gap-3">
                                <PlainField label="SMTP host" placeholder="smtp.example.com"
                                             value={integ.email?.smtp_host || ""}
                                             onChange={(v) => setField("email", "smtp_host", v)}
                                             testid="smtp-host" />
                                <PlainField label="Port" placeholder="587"
                                             value={String(integ.email?.smtp_port || 587)}
                                             onChange={(v) => setField("email", "smtp_port", parseInt(v || 587, 10))}
                                             testid="smtp-port" />
                                <PlainField label="Username" placeholder="user@example.com"
                                             value={integ.email?.smtp_username || ""}
                                             onChange={(v) => setField("email", "smtp_username", v)}
                                             testid="smtp-username" />
                                <SecretField label="Password" placeholder="••••••"
                                              masked={integ.email?.smtp_password}
                                              onChange={(v) => setField("email", "smtp_password", v)}
                                              testid="smtp-password" />
                            </div>
                        </>
                    )}
                    <SaveRow onClick={() => save("email")} busy={busy} />
                </Section>

                {/* Messaging */}
                <Section
                    icon={MessageCircle} title="Messaging (SMS + voice)"
                    subtitle="Send appointment reminders + let your AI receptionist answer real calls."
                    section={integ.messaging} sectionKey="messaging">
                    <Select value={integ.messaging?.provider || "none"}
                            onChange={(v) => setField("messaging", "provider", v)}
                            testid="messaging-provider"
                            options={[
                                { value: "none", label: "Not connected" },
                                { value: "twilio", label: "Twilio (SMS + voice)" },
                                { value: "retell", label: "Retell AI (voice)" },
                            ]} />
                    {integ.messaging?.provider === "twilio" && (
                        <>
                            <InstructionCard {...INSTRUCTIONS.twilio} />
                            <PlainField label="Account SID" placeholder="ACxxxxxxxxxx"
                                         value={integ.messaging?.twilio_account_sid || ""}
                                         onChange={(v) => setField("messaging", "twilio_account_sid", v)}
                                         testid="twilio-sid" />
                            <SecretField label="Auth Token" placeholder="xxxxxxxxxxxxxxxxx"
                                          masked={integ.messaging?.twilio_auth_token}
                                          onChange={(v) => setField("messaging", "twilio_auth_token", v)}
                                          testid="twilio-token" />
                            <PlainField label="From number" placeholder="+15551234567"
                                         value={integ.messaging?.twilio_from_number || ""}
                                         onChange={(v) => setField("messaging", "twilio_from_number", v)}
                                         testid="twilio-from" />
                        </>
                    )}
                    {integ.messaging?.provider === "retell" && (
                        <>
                            <InstructionCard {...INSTRUCTIONS.retell} />
                            <SecretField label="Retell API key" placeholder="key_xxxxxxxxxx"
                                          masked={integ.messaging?.retell_api_key}
                                          onChange={(v) => setField("messaging", "retell_api_key", v)}
                                          testid="retell-key" />
                        </>
                    )}
                    <SaveRow onClick={() => save("messaging")} busy={busy} />
                </Section>

                {/* Ecommerce */}
                <Section
                    icon={ShoppingBag} title="Dropshipping suppliers"
                    subtitle="Import products from a supplier feed to sell in your store."
                    section={integ.ecommerce} sectionKey="ecommerce">
                    <Select value={integ.ecommerce?.provider || "none"}
                            onChange={(v) => setField("ecommerce", "provider", v)}
                            testid="ecom-provider"
                            options={[
                                { value: "none", label: "Not connected" },
                                { value: "aliexpress", label: "AliExpress" },
                                { value: "cj_dropshipping", label: "CJ Dropshipping" },
                            ]} />
                    {integ.ecommerce?.provider === "aliexpress" && <InstructionCard {...INSTRUCTIONS.aliexpress} />}
                    {integ.ecommerce?.provider === "cj_dropshipping" && <InstructionCard {...INSTRUCTIONS.cj_dropshipping} />}
                    {integ.ecommerce?.provider && integ.ecommerce?.provider !== "none" && (
                        <>
                            <SecretField label="API key" placeholder="…"
                                          masked={integ.ecommerce?.ecommerce_api_key}
                                          onChange={(v) => setField("ecommerce", "ecommerce_api_key", v)}
                                          testid="ecom-api-key" />
                            <SecretField label="API secret (if required)" placeholder="…"
                                          masked={integ.ecommerce?.ecommerce_api_secret}
                                          onChange={(v) => setField("ecommerce", "ecommerce_api_secret", v)}
                                          testid="ecom-api-secret" />
                        </>
                    )}
                    <SaveRow onClick={() => save("ecommerce")} busy={busy} />
                </Section>
            </div>
        </div>
    );
}

function Section({ icon: Icon, title, subtitle, children, section, sectionKey }) {
    const configured = !!section?.configured;
    return (
        <div className="mt-6 rounded-2xl border border-brand-line bg-white p-6"
             data-testid={`tenant-integ-section-${sectionKey}`}>
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-brand-cream flex items-center justify-center text-brand-copper">
                        <Icon className="w-5 h-5" />
                    </div>
                    <div>
                        <div className="text-brand-ink font-medium">{title}</div>
                        <div className="text-sm text-zinc-500">{subtitle}</div>
                    </div>
                </div>
                <span className={`inline-flex items-center gap-1.5 text-xs font-medium rounded-full px-2.5 py-1 ${configured ? "bg-emerald-50 text-emerald-700" : "bg-zinc-100 text-zinc-500"}`}
                      data-testid={`tenant-integ-status-${sectionKey}`}>
                    {configured ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Circle className="w-3.5 h-3.5" />}
                    {configured ? "Connected" : "Not connected"}
                </span>
            </div>
            <div className="mt-5 space-y-3">{children}</div>
        </div>
    );
}

function InstructionCard({ title, steps, link }) {
    return (
        <div className="rounded-xl border border-brand-line/70 bg-brand-cream/40 p-4" data-testid="integ-instruction">
            <div className="flex items-center gap-2 text-brand-ink text-sm font-medium">
                <Info className="w-4 h-4 text-brand-copper" /> {title}
            </div>
            <ol className="mt-2 pl-5 list-decimal text-sm text-zinc-600 space-y-1">
                {steps.map((s, i) => <li key={i}>{s}</li>)}
            </ol>
            {link && (
                <a href={link} target="_blank" rel="noreferrer"
                   className="mt-2 inline-flex items-center gap-1 text-xs text-brand-copper hover:underline">
                    Open provider dashboard <ExternalLink className="w-3 h-3" />
                </a>
            )}
        </div>
    );
}

function Select({ value, onChange, options, testid }) {
    return (
        <select value={value} onChange={(e) => onChange(e.target.value)}
                data-testid={testid}
                className="w-full border border-brand-line rounded-md px-3 py-2 text-sm bg-white">
            {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
    );
}

function PlainField({ label, placeholder, value, onChange, testid }) {
    return (
        <div>
            <label className="text-xs text-zinc-500">{label}</label>
            <input type="text" placeholder={placeholder} value={value}
                    onChange={(e) => onChange(e.target.value)}
                    data-testid={testid}
                    className="mt-1 w-full border border-brand-line rounded-md px-3 py-2 text-sm" />
        </div>
    );
}

function SecretField({ label, placeholder, masked, onChange, testid }) {
    const [val, setVal] = useState("");
    return (
        <div>
            <label className="text-xs text-zinc-500 flex items-center justify-between">
                <span>{label}</span>
                {masked?.set && <span className="text-emerald-700">stored ({masked.hint})</span>}
            </label>
            <input type="password" placeholder={placeholder} value={val}
                    onChange={(e) => { setVal(e.target.value); onChange(e.target.value); }}
                    data-testid={testid}
                    autoComplete="new-password"
                    className="mt-1 w-full border border-brand-line rounded-md px-3 py-2 text-sm" />
        </div>
    );
}

function SaveRow({ onClick, busy }) {
    return (
        <div>
            <Button onClick={onClick} disabled={busy}
                    className="bg-brand-copper hover:bg-brand-copperHover text-white"
                    data-testid="save-section">
                {busy ? "Saving…" : "Save this section"}
            </Button>
        </div>
    );
}

function StripeConnectPanel() {
    const [settings, setSettings] = useState(null);
    const [busy, setBusy] = useState(false);
    const [err, setErr] = useState("");

    async function load() {
        try { const r = await api.get("/store/settings"); setSettings(r.data); } catch (e) { /* ignore */ }
    }
    useEffect(() => { load(); }, []);

    async function connect() {
        setBusy(true); setErr("");
        try {
            const { data } = await api.post("/store/payments/stripe/connect/start", { country: "US" });
            if (data?.url) window.location.assign(data.url);
        } catch (e) {
            const d = e?.response?.data?.detail;
            setErr((d && (d.message || d)) || "Could not start Stripe onboarding.");
        } finally { setBusy(false); }
    }

    async function flip(live) {
        setBusy(true); setErr("");
        try {
            const { data } = await api.post("/store/go-live", { live });
            setSettings(data);
            toast.success(live ? "Store is now LIVE — real cards will be charged" : "Store back in Test mode (simulated checkout)");
        } catch (e) {
            const d = e?.response?.data?.detail;
            setErr((d && (d.message || d)) || "Could not change store mode");
        } finally { setBusy(false); }
    }

    const c = settings?.connect || {};
    const live = settings?.live;
    const available = !!c.available;
    const state = c.status || "not_connected";
    const badge = live ? ["LIVE", "bg-emerald-100 text-emerald-800"]
        : state === "connected" ? ["Connected (test mode)", "bg-sky-100 text-sky-800"]
        : state === "pending" || state === "onboarding" ? ["Onboarding in progress", "bg-amber-100 text-amber-800"]
        : ["Not connected", "bg-zinc-200 text-zinc-700"];

    return (
        <div className="mt-2 space-y-4" data-testid="stripe-connect-panel">
            <div className="rounded-lg border border-brand-line p-4 bg-zinc-50">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div>
                        <div className="text-sm font-medium text-brand-ink flex items-center gap-2">
                            Stripe (via Stripe Connect)
                            <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] ${badge[1]}`} data-testid="stripe-connect-state">{badge[0]}</span>
                        </div>
                        <p className="text-xs text-zinc-500 mt-1 max-w-lg">
                            You never paste secret keys into Zanelvo. Stripe hosts the onboarding and verifies your business;
                            payouts go straight to your bank. Zanelvo only stores your connected account ID.
                        </p>
                        {!available && (
                            <p className="text-xs text-amber-700 mt-2" data-testid="stripe-connect-unavailable">
                                Online payments are not available yet on this platform{c.reason ? `: ${c.reason}` : "."} Your storefront stays in simulated test mode.
                            </p>
                        )}
                    </div>
                    <div className="flex gap-2">
                        {state !== "connected" && (
                            <Button size="sm" disabled={busy || !available} onClick={connect} data-testid="stripe-connect-start">
                                {state === "not_connected" ? "Connect with Stripe" : "Continue onboarding"}
                            </Button>
                        )}
                        <Button size="sm" variant="outline" disabled={busy} onClick={load} data-testid="stripe-connect-refresh">Refresh status</Button>
                    </div>
                </div>
                {c.account_id && (
                    <dl className="mt-3 grid grid-cols-3 gap-2 text-xs text-zinc-600">
                        <div><dt className="text-zinc-400">Account</dt><dd className="font-mono">{c.account_id}</dd></div>
                        <div><dt className="text-zinc-400">Charges</dt><dd>{c.charges_enabled ? "Enabled" : "Not yet"}</dd></div>
                        <div><dt className="text-zinc-400">Payouts</dt><dd>{c.payouts_enabled ? "Enabled" : "Not yet"}</dd></div>
                    </dl>
                )}
                {err && <p className="text-xs text-rose-600 mt-2" data-testid="stripe-connect-error">{String(err)}</p>}
            </div>

            <div className="rounded-lg border border-brand-line p-4 bg-zinc-50" data-testid="store-go-live">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div>
                        <div className="text-sm font-medium text-brand-ink flex items-center gap-2">
                            Store payment mode
                            <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] ${live ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
                                {live ? "LIVE" : "TEST"}
                            </span>
                        </div>
                        <p className="text-xs text-zinc-500 mt-1 max-w-md">
                            {live ? "Real charges are active on your storefront through your connected Stripe account."
                                  : "Your storefront uses simulated checkout (no real charges). Go Live becomes available once Stripe has enabled charges on your connected account."}
                        </p>
                    </div>
                    <div className="flex gap-2">
                        <Button size="sm" variant={live ? "outline" : "default"} disabled={busy || !live}
                            className={!live ? "bg-zinc-200 text-zinc-500" : "border-brand-line"}
                            onClick={() => flip(false)} data-testid="go-test">Test</Button>
                        <Button size="sm" disabled={busy || live || !settings?.stripe_ready}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white disabled:opacity-50"
                            onClick={() => flip(true)} data-testid="go-live">Go Live</Button>
                    </div>
                </div>
            </div>

            <div className="rounded-lg border border-dashed border-brand-line p-3 text-xs text-zinc-500">
                <div><b>PayPal:</b> {settings?.paypal?.status || "Not available."}</div>
                <div className="mt-1"><b>Recurring billing:</b> {settings?.recurring_billing?.status || "Not available yet."}</div>
            </div>
        </div>
    );
}
