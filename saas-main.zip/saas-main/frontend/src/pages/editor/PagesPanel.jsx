import { useState } from "react";
import { useEditor } from "./EditorProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Copy, Trash2, MoreHorizontal, EyeOff } from "lucide-react";
import { DndContext, PointerSensor, useSensor, useSensors, closestCenter } from "@dnd-kit/core";
import { SortableContext, useSortable, verticalListSortingStrategy, arrayMove } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import api from "@/lib/api";

function SortablePageItem({ page, isActive, onSelect, onDuplicate, onDelete }) {
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: page.slug });
    const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 };
    return (
        <div ref={setNodeRef} style={style}
             className={`group flex items-center gap-2 px-2 py-1.5 rounded-md text-sm cursor-pointer ${
                 isActive ? "bg-brand-cream text-brand-ink font-medium" : "text-zinc-700 hover:bg-zinc-50"
             }`}
             onClick={onSelect}
             data-testid={`pages-panel-${page.slug}`}>
            <span {...attributes} {...listeners} className="cursor-grab text-zinc-400 hover:text-zinc-700" onClick={(e) => e.stopPropagation()}>⋮⋮</span>
            <span className="flex-1 truncate">{page.title}</span>
            {page.hidden && <EyeOff className="w-3 h-3 text-zinc-400" />}
            <button className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-brand-ink" onClick={(e) => { e.stopPropagation(); onDuplicate(); }}
                    data-testid={`pages-duplicate-${page.slug}`}><Copy className="w-3.5 h-3.5" /></button>
            <button className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-red-600" onClick={(e) => { e.stopPropagation(); onDelete(); }}
                    data-testid={`pages-delete-${page.slug}`}><Trash2 className="w-3.5 h-3.5" /></button>
        </div>
    );
}

export default function PagesPanel() {
    const {
        website, draft, selectedPageSlug, setSelectedPageSlug,
        addPage, duplicatePage, deletePage, refetch,
    } = useEditor();
    const [showNew, setShowNew] = useState(false);
    const [newTitle, setNewTitle] = useState("");
    const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

    if (!draft) return null;
    const pages = website?.pages || [];
    const navOrder = draft.nav_order.filter((s) => pages.some((p) => p.slug === s));

    async function onNavDragEnd(event) {
        const { active, over } = event;
        if (!over || active.id === over.id) return;
        const old = navOrder.indexOf(active.id);
        const nw = navOrder.indexOf(over.id);
        if (old < 0 || nw < 0) return;
        const next = arrayMove(navOrder, old, nw);
        try {
            await api.patch("/editor/website/nav-order", { nav_order: next });
            await refetch();
        } catch {}
    }

    return (
        <aside className="w-56 border-r border-brand-line bg-white p-3 flex flex-col" data-testid="editor-pages-panel">
            <div className="flex items-center justify-between mb-3 px-1">
                <div className="text-xs uppercase tracking-widest text-zinc-500">Pages</div>
                <Dialog open={showNew} onOpenChange={setShowNew}>
                    <DialogTrigger asChild>
                        <button className="text-zinc-500 hover:text-brand-ink" data-testid="page-add-btn"><Plus className="w-4 h-4" /></button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>New page</DialogTitle></DialogHeader>
                        <div className="space-y-3">
                            <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)}
                                   placeholder="Page title (e.g., FAQ)" data-testid="new-page-title" autoFocus />
                        </div>
                        <DialogFooter>
                            <Button variant="ghost" onClick={() => setShowNew(false)}>Cancel</Button>
                            <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={!newTitle.trim()}
                                    onClick={async () => { await addPage({ title: newTitle.trim() }); setNewTitle(""); setShowNew(false); }}
                                    data-testid="new-page-submit">
                                Add page
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onNavDragEnd}>
                <SortableContext items={navOrder} strategy={verticalListSortingStrategy}>
                    <div className="flex-1 space-y-0.5 overflow-y-auto">
                        {navOrder.map((slug) => {
                            const p = pages.find((x) => x.slug === slug);
                            if (!p) return null;
                            return (
                                <SortablePageItem
                                    key={slug}
                                    page={p}
                                    isActive={selectedPageSlug === slug}
                                    onSelect={() => setSelectedPageSlug(slug)}
                                    onDuplicate={() => duplicatePage(slug)}
                                    onDelete={() => {
                                        if (pages.length <= 1) return;
                                        if (window.confirm(`Delete "${p.title}"?`)) deletePage(slug);
                                    }}
                                />
                            );
                        })}
                    </div>
                </SortableContext>
            </DndContext>
        </aside>
    );
}
