import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ArrowRight, LayoutTemplate, MessageSquareText, PencilRuler, Loader2, Check } from "lucide-react";

/**
 * /app/website/new — three ways to start a site on ONE screen:
 *   1. AI interview (existing onboarding → tailored generation)
 *   2. From scratch (blank starter, no AI, no cost)
 *   3. Template gallery (deterministic industry designs, instantly editable)
 * Applying a template/blank can REPLACE the current draft or create a NEW site (plan-limited).
 */
export default function WebsiteNew() {
    const navigate = useNavigate();
    const [templates, setTemplates] = useState([]);
    const [loading, setLoading] = useState(true);
    const [pick, setPick] = useState(null);          // {template_id|null, name}
    const [mode, setMode] = useState("replace");
    const [siteName, setSiteName] = useState("");
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        api.get("/editor/templates").then(({ data }) => setTemplates(data.templates || []))
            .catch(() => toast.error("Could not load templates")).finally(() => setLoading(false));
    }, []);

    const apply = async () => {
        if (busy) return;
        setBusy(true);
        try {
            const body = { template_id: pick.template_id, mode, name: mode === "new_site" ? (siteName || undefined) : undefined };
            const { data } = await api.post("/editor/website/apply-template", body);
            toast.success(mode === "new_site" ? "New site created — opening the editor" : "Design applied to your draft");
            setPick(null);
            navigate("/app/editor", { state: { from: "website-new", website_id: data.website_id } });
        } catch (e) {
            const d = e?.response?.data?.detail;
            toast.error(typeof d === "string" ? d : (d?.message || "Could not apply this design"));
        } finally { setBusy(false); }
    };

    return (
        <div className="p-6 md:p-8 max-w-6xl" data-testid="website-new-page">
            <Link to="/app/website" className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-brand-ink" data-testid="website-new-back">
                <ArrowLeft className="w-4 h-4" /> Back to website
            </Link>
            <div className="mt-3 text-xs uppercase tracking-[0.28em] text-brand-copper">New design</div>
            <h1 className="font-display text-2xl md:text-3xl text-brand-ink font-medium mt-1">How do you want to start?</h1>
            <p className="mt-2 text-zinc-600 max-w-2xl">Pick the path that fits you. Every option lands in the same visual editor, and nothing goes live until you publish.</p>

            <div className="mt-6 grid md:grid-cols-3 gap-4">
                <StartCard icon={MessageSquareText} title="Let AI build it" testid="start-interview"
                    body="Answer a short interview about your business and get a tailored, multi-page site written for you."
                    cta="Start the interview" onClick={() => navigate("/onboarding")} accent />
                <StartCard icon={PencilRuler} title="Build from scratch" testid="start-blank"
                    body="A clean one-page starter with a hero, services, about and contact form. No AI, no cost — you write everything."
                    cta="Start blank" onClick={() => { setPick({ template_id: null, name: "Blank starter" }); setMode("replace"); }} />
                <StartCard icon={LayoutTemplate} title="Pick a template" testid="start-template"
                    body="Choose a ready-made industry design below and make it yours in the editor."
                    cta="Browse templates" onClick={() => document.getElementById("template-gallery")?.scrollIntoView({ behavior: "smooth" })} />
            </div>

            <div id="template-gallery" className="mt-10">
                <div className="flex items-end justify-between gap-4">
                    <div>
                        <h2 className="font-display text-xl text-brand-ink font-medium">Template gallery</h2>
                        <p className="text-sm text-zinc-500 mt-1">Deterministic designs with honest placeholder copy — replace the placeholders before you publish.</p>
                    </div>
                    <Badge variant="outline" className="text-xs">{templates.length} templates</Badge>
                </div>
                {loading ? (
                    <div className="mt-6 text-sm text-zinc-500 flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Loading templates…</div>
                ) : (
                    <div className="mt-5 grid sm:grid-cols-2 lg:grid-cols-3 gap-5" data-testid="template-gallery">
                        {templates.map((t) => (
                            <button key={t.id} type="button" onClick={() => { setPick({ template_id: t.id, name: t.name }); setMode("replace"); }}
                                className="group text-left rounded-2xl border border-brand-line bg-white overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all"
                                data-testid={`template-card-${t.id}`}>
                                <div className="relative h-40 overflow-hidden" style={{ background: t.palette.background }}>
                                    <img src={t.preview_image} alt="" className="absolute inset-0 w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform" loading="lazy" />
                                    <div className="absolute inset-x-0 bottom-0 p-3 flex gap-1.5">
                                        {["primary", "secondary", "accent"].map((k) => (
                                            <span key={k} className="w-5 h-5 rounded-full border border-white/70 shadow" style={{ background: t.palette[k] }} />
                                        ))}
                                    </div>
                                </div>
                                <div className="p-4">
                                    <div className="flex items-center justify-between gap-2">
                                        <div className="font-medium text-brand-ink">{t.name}</div>
                                        <span className="text-[11px] text-zinc-500">{t.pages.length} page{t.pages.length === 1 ? "" : "s"}</span>
                                    </div>
                                    <p className="mt-1 text-sm text-zinc-600 line-clamp-2">{t.description}</p>
                                    <div className="mt-3 flex flex-wrap gap-1.5">
                                        {t.tags.map((tag) => <Badge key={tag} variant="secondary" className="text-[10px]">{tag}</Badge>)}
                                    </div>
                                </div>
                            </button>
                        ))}
                    </div>
                )}
            </div>

            <Dialog open={!!pick} onOpenChange={(o) => !o && setPick(null)}>
                <DialogContent data-testid="apply-template-dialog">
                    <DialogHeader>
                        <DialogTitle>Use “{pick?.name}”</DialogTitle>
                        <DialogDescription>Choose where this design should go. Your published site stays live until you publish again.</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-2">
                        <ModeOption value="replace" current={mode} onPick={setMode} title="Replace my current draft"
                            body="Overwrites the unpublished draft of your active site. You can undo by rolling back to a previous revision." testid="mode-replace" />
                        <ModeOption value="new_site" current={mode} onPick={setMode} title="Create a new site"
                            body="Keeps your current site and adds another one (counts toward your plan's site limit)." testid="mode-new-site" />
                        {mode === "new_site" && (
                            <div className="pt-1">
                                <Label className="text-xs uppercase tracking-widest text-zinc-500">Site name</Label>
                                <Input value={siteName} onChange={(e) => setSiteName(e.target.value)} placeholder={pick?.name} className="mt-1" data-testid="new-site-name" />
                            </div>
                        )}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setPick(null)} disabled={busy}>Cancel</Button>
                        <Button onClick={apply} disabled={busy} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="apply-template-confirm">
                            {busy ? <><Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> Applying…</> : <>Apply & open editor <ArrowRight className="w-4 h-4 ml-1" /></>}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}

function StartCard({ icon: Icon, title, body, cta, onClick, accent, testid }) {
    return (
        <div className={`rounded-2xl border p-5 flex flex-col ${accent ? "border-brand-copper/40 bg-gradient-to-br from-brand-copper/5 to-white" : "border-brand-line bg-white"}`} data-testid={testid}>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${accent ? "bg-brand-copper text-white" : "bg-zinc-100 text-brand-ink"}`}><Icon className="w-5 h-5" /></div>
            <div className="mt-3 font-medium text-brand-ink">{title}</div>
            <p className="mt-1 text-sm text-zinc-600 flex-1">{body}</p>
            <Button onClick={onClick} variant={accent ? "default" : "outline"} size="sm" className={`mt-4 ${accent ? "bg-brand-copper hover:bg-brand-copperHover text-white" : ""}`} data-testid={`${testid}-btn`}>
                {cta} <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Button>
        </div>
    );
}

function ModeOption({ value, current, onPick, title, body, testid }) {
    const on = current === value;
    return (
        <button type="button" onClick={() => onPick(value)} data-testid={testid}
            className={`w-full text-left rounded-xl border p-3 flex gap-3 items-start ${on ? "border-brand-copper bg-brand-copper/5" : "border-brand-line hover:bg-zinc-50"}`}>
            <span className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center ${on ? "border-brand-copper bg-brand-copper text-white" : "border-zinc-300"}`}>{on && <Check className="w-3 h-3" />}</span>
            <span><span className="block text-sm font-medium text-brand-ink">{title}</span><span className="block text-xs text-zinc-500 mt-0.5">{body}</span></span>
        </button>
    );
}
