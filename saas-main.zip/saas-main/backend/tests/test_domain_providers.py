"""Unit tests for the domain provider adapters.

Covers:
- CloudflareProvider honestly reports `Not connected` and returns state='error' with a
  helpful hint when API token/zone are unset.
- CloudflareProvider create_hostname / check_status / delete_hostname exercise the
  correct HTTP paths and map Cloudflare-side statuses to our internal state machine
  (via a mocked httpx.AsyncClient).
- SimulatedProvider drives pending → verifying → connected on repeated status polls.
"""
from __future__ import annotations

import asyncio
from typing import Any, Dict
from unittest.mock import patch, AsyncMock

import pytest

from app.services.domain_providers import (
    CloudflareProvider,
    HostnameStatus,
    SimulatedProvider,
    _SIMULATED_STATE,
)


# ---------- SimulatedProvider ----------

def _run(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


class TestSimulatedProvider:
    def setup_method(self):
        _SIMULATED_STATE.clear()

    def test_state_machine_pending_to_connected(self):
        p = SimulatedProvider()
        created = _run(p.create_hostname("test.example.com", "demo-site"))
        assert created.state == "pending"
        assert created.ownership_record and created.ownership_record["type"] == "TXT"
        assert any(r["type"] == "CNAME" for r in created.dns_records)

        # First poll → verifying
        s1 = _run(p.check_status("test.example.com", created.provider_ref))
        assert s1.state == "verifying"
        # Second poll → still verifying
        s2 = _run(p.check_status("test.example.com", created.provider_ref))
        assert s2.state == "verifying"
        # Third poll → connected
        s3 = _run(p.check_status("test.example.com", created.provider_ref))
        assert s3.state == "connected"
        assert s3.ssl_status == "active"

    def test_delete_removes_state(self):
        p = SimulatedProvider()
        _run(p.create_hostname("gone.example.com", "demo"))
        assert "gone.example.com" in _SIMULATED_STATE
        _run(p.delete_hostname("gone.example.com"))
        assert "gone.example.com" not in _SIMULATED_STATE


# ---------- CloudflareProvider ----------

class TestCloudflareProviderNotConnected:
    def setup_method(self):
        # Force unset env
        self._patch = patch.dict(
            "os.environ",
            {"CLOUDFLARE_API_TOKEN": "", "CLOUDFLARE_SAAS_ZONE_ID": ""},
            clear=False,
        )
        self._patch.start()

    def teardown_method(self):
        self._patch.stop()

    def test_reports_not_connected(self):
        p = CloudflareProvider()
        assert p.is_connected is False
        assert "Not connected" in p.honest_status
        # Creds now live in the Staff Setup Center (not env vars); message must point there.
        assert "Setup Center" in p.honest_status
        assert "Cloudflare" in p.honest_status

    def test_create_returns_error_with_hint(self):
        p = CloudflareProvider()
        s = _run(p.create_hostname("mybiz.com", "demo"))
        assert isinstance(s, HostnameStatus)
        assert s.state == "error"
        assert "not connected" in (s.error_detail or "").lower()
        assert "Setup Center" in (s.error_hint or "")


class _FakeResp:
    def __init__(self, status_code: int, payload: Dict[str, Any]):
        self.status_code = status_code
        self._payload = payload
        self.text = str(payload)

    def json(self):
        return self._payload


class _FakeAsyncClient:
    """Minimal stand-in for httpx.AsyncClient."""

    def __init__(self, responses):
        # responses: list of (expected_method, expected_path_suffix, response) tuples
        self.responses = list(responses)
        self.calls = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        method_exp, suffix_exp, resp = self.responses.pop(0)
        assert method == method_exp, f"expected {method_exp}, got {method}"
        assert url.endswith(suffix_exp), f"expected URL suffix {suffix_exp}, got {url}"
        return resp


class TestCloudflareProviderConnected:
    def setup_method(self):
        self._patch = patch.dict(
            "os.environ",
            {
                "CLOUDFLARE_API_TOKEN": "test-token",
                "CLOUDFLARE_SAAS_ZONE_ID": "zone123",
                "CLOUDFLARE_SAAS_ORIGIN": "origin.revenueos.app",
            },
            clear=False,
        )
        self._patch.start()

    def teardown_method(self):
        self._patch.stop()

    def test_create_hostname_maps_response(self):
        p = CloudflareProvider()
        assert p.is_connected is True

        cf_result = {
            "success": True,
            "result": {
                "id": "cf-hostname-abc",
                "hostname": "mybiz.com",
                "ssl": {"status": "initializing"},
                "ownership_verification": {
                    "type": "TXT",
                    "name": "_cf-validate.mybiz.com",
                    "value": "cf-validate-token-xyz",
                },
            },
        }
        fake = _FakeAsyncClient([("POST", "custom_hostnames", _FakeResp(200, cf_result))])
        with patch("app.services.domain_providers.httpx.AsyncClient", return_value=fake):
            s = _run(p.create_hostname("mybiz.com", "demo-slug"))
        assert s.state == "verifying"
        assert s.ssl_status == "initializing"
        assert s.provider_ref == "cf-hostname-abc"
        assert s.ownership_record["value"] == "cf-validate-token-xyz"
        assert any(r["type"] == "CNAME" and r["value"] == "origin.revenueos.app" for r in s.dns_records)

    def test_check_status_maps_active_to_connected(self):
        p = CloudflareProvider()
        cf_result = {
            "success": True,
            "result": {
                "id": "cf-hostname-abc",
                "status": "active",
                "ssl": {"status": "active"},
            },
        }
        fake = _FakeAsyncClient([("GET", "/cf-hostname-abc", _FakeResp(200, cf_result))])
        with patch("app.services.domain_providers.httpx.AsyncClient", return_value=fake):
            s = _run(p.check_status("mybiz.com", "cf-hostname-abc"))
        assert s.state == "connected"
        assert s.ssl_status == "active"

    def test_check_status_maps_pending_to_verifying(self):
        p = CloudflareProvider()
        cf_result = {
            "success": True,
            "result": {"id": "cf-hostname-abc", "status": "pending_validation",
                       "ssl": {"status": "pending_validation"}},
        }
        fake = _FakeAsyncClient([("GET", "/cf-hostname-abc", _FakeResp(200, cf_result))])
        with patch("app.services.domain_providers.httpx.AsyncClient", return_value=fake):
            s = _run(p.check_status("mybiz.com", "cf-hostname-abc"))
        assert s.state == "verifying"

    def test_api_error_returns_error_state(self):
        p = CloudflareProvider()
        err = {"success": False, "errors": [{"message": "hostname already claimed"}]}
        fake = _FakeAsyncClient([("POST", "custom_hostnames", _FakeResp(400, err))])
        with patch("app.services.domain_providers.httpx.AsyncClient", return_value=fake):
            s = _run(p.create_hostname("taken.example.com", "demo"))
        assert s.state == "error"
        assert "hostname already claimed" in (s.error_detail or "")

    def test_delete_hits_correct_path(self):
        p = CloudflareProvider()
        fake = _FakeAsyncClient([("DELETE", "/cf-hostname-abc",
                                  _FakeResp(200, {"success": True, "result": {}}))])
        with patch("app.services.domain_providers.httpx.AsyncClient", return_value=fake):
            _run(p.delete_hostname("mybiz.com", "cf-hostname-abc"))
        assert fake.calls  # confirmed a request went out
        method, url, _ = fake.calls[0]
        assert method == "DELETE"
        assert "custom_hostnames/cf-hostname-abc" in url
