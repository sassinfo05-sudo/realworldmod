import { useEffect, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TrendingUp, TrendingDown, DollarSign, Users, Percent, RefreshCw } from "lucide-react";

const money = (n) => (n === null || n === undefined) ? "—" : new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(n);
const PL = ({ v }) => <span className={`tabular-nums font-medium ${v < 0 ? "text-red-600" : "text-emerald-700"}`}>{v < 0 ? "−" : "+"}{money(Math.abs(v))}</span>;

/** Staff → Plans & P&L: edit real prices (monthly + annual), see live profit/loss from the database. */
export default function StaffPlans() {
    const [eco, setEco] = useState(null);
    const [history, setHistory] = useState({});
    async function toggleHistory(code) {
        if (history[code]) { setHistory({ ...history, [code]: null }); return; }
        try { const { data } = await api.get(`/founder/plans-admin/${code}/history`); setHistory({ ...history, [code]: data }); }
        catch { toast.error("Could not load pricing history"); }
    }
    const [plans, setPlans] = useState([]);
    const [settings, setSettings] = useState(null);
    const [edit, setEdit] = useState({});
    const [busy, setBusy] = useState(false);

    async function load() {
        try {
            const [e, p, s] = await Promise.all([api.get("/founder/economics"), api.get("/founder/plans-admin"), api.get("/founder/settings")]);
            setEco(e.data); setPlans(p.data); setSettings(s.data);
            const ed = {}; p.data.forEach((pl) => { ed[pl.code] = { price_usd: pl.price_usd, annual_price_usd: pl.annual_price_usd ?? Math.round(pl.price_usd * 10), name: pl.name, tagline: pl.tagline || "", features: (pl.features || []).join("\n") }; });
            setEdit(ed);
        } catch (err) { toast.error(err?.response?.data?.detail || "Could not load"); }
    }
    useEffect(() => { load(); }, []);

    async function savePlan(code) {
        setBusy(true);
        try {
            const e = edit[code];
            await api.put(`/founder/plans-admin/${code}`, { price_usd: Number(e.price_usd), annual_price_usd: Number(e.annual_price_usd), name: e.name, tagline: e.tagline, features: e.features.split("\n").map((x) => x.trim()).filter(Boolean) });
            toast.success(`${e.name} saved — pricing page updated`); load();
        } catch (err) { toast.error(err?.response?.data?.detail || "Save failed (pricing permission needed)"); } finally { setBusy(false); }
    }
    async function saveCosts() {
        setBusy(true);
        try { await api.put("/founder/settings", { unit_costs: settings.unit_costs, processing_fee_pct: Number(settings.processing_fee_pct), processing_fee_fixed: Number(settings.processing_fee_fixed), annual_discount_pct: Number(settings.annual_discount_pct) }); toast.success("Cost model saved"); load(); }
        catch (err) { toast.error(err?.response?.data?.detail || "Save failed"); } finally { setBusy(false); }
    }

    if (!eco || !settings) return <div className="p-8 text-sm text-zinc-500">Loading economics…</div>;
    const T = eco.actual.totals;
    return (
        <div className="px-4 md:px-8 py-6 max-w-[1300px] mx-auto space-y-8" data-testid="staff-plans-page">
            <div className="flex flex-wrap items-end justify-between gap-3">
                <div><h2 className="font-display text-2xl md:text-3xl text-brand-ink dark:text-white">Plans & P&L</h2>
                    <p className="text-sm text-zinc-500 mt-1">Live numbers from your database — active subscriptions, metered usage this month, your unit costs and card fees. Change a price here and the public pricing page updates instantly.</p></div>
                <Button variant="outline" size="sm" onClick={load}><RefreshCw className="w-3.5 h-3.5" /> Refresh</Button>
            </div>

            {/* Live totals */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3" data-testid="pl-totals">
                {[["MRR", money(T.mrr), DollarSign, "#4F46E5"], ["ARR (run-rate)", money(T.arr), TrendingUp, "#7C3AED"], ["Monthly cost + fees", money(T.cost + T.fees), TrendingDown, "#F59E0B"],
                  ["Monthly profit", money(T.profit), T.profit >= 0 ? TrendingUp : TrendingDown, T.profit >= 0 ? "#059669" : "#DC2626"], ["Paying + free orgs", T.subscribers, Users, "#0EA5E9"]].map(([l, v, Icon, c]) => (
                    <div key={l} className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-4"><div className="flex items-center justify-between text-[11px] uppercase tracking-widest text-zinc-500">{l}<Icon className="w-4 h-4" style={{ color: c }} /></div><div className="font-display text-2xl mt-2 tabular-nums">{v}</div></div>
                ))}
            </div>

            {/* Per plan: actual */}
            <section className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 overflow-hidden">
                <div className="px-5 py-4 border-b border-brand-line"><div className="font-medium">Actual profit / loss by plan — this month</div><div className="text-xs text-zinc-500">{eco.actual.note}</div></div>
                <table className="w-full text-sm">
                    <thead className="bg-zinc-50 dark:bg-white/5 text-left text-[11px] uppercase tracking-widest text-zinc-500"><tr><th className="px-4 py-2">Plan</th><th className="px-4 py-2">Subscribers</th><th className="px-4 py-2">MRR</th><th className="px-4 py-2">Usage cost</th><th className="px-4 py-2">Card fees</th><th className="px-4 py-2">Profit / mo</th><th className="px-4 py-2">Annualized</th><th className="px-4 py-2">Margin</th><th className="px-4 py-2">Usage</th></tr></thead>
                    <tbody>{eco.actual.by_plan.map((r) => (
                        <tr key={r.code} className="border-t border-brand-line/70" data-testid={`pl-actual-${r.code}`}>
                            <td className="px-4 py-2.5 font-medium">{r.name}</td>
                            <td className="px-4 py-2.5">{r.subscribers} <span className="text-xs text-zinc-400">({r.monthly_subs} mo · {r.annual_subs} yr)</span></td>
                            <td className="px-4 py-2.5 tabular-nums">{money(r.mrr)}</td><td className="px-4 py-2.5 tabular-nums">{money(r.usage_cost)}</td><td className="px-4 py-2.5 tabular-nums">{money(r.processing_fees)}</td>
                            <td className="px-4 py-2.5"><PL v={r.profit_monthly} /></td><td className="px-4 py-2.5"><PL v={r.profit_annualized} /></td>
                            <td className="px-4 py-2.5">{r.margin_pct === null ? "—" : `${r.margin_pct}%`}</td>
                            <td className="px-4 py-2.5 text-[11px] text-zinc-500">{r.usage.emails} emails · {r.usage.ai_conversations} AI · {r.usage.websites} sites · {r.usage.contacts} contacts · {r.usage.voice_minutes} min</td>
                        </tr>))}</tbody>
                </table>
            </section>

            {/* Per plan: pricing editor + list-price economics */}
            <section>
                <div className="mb-3"><div className="font-medium">Plan pricing & worst-case economics</div><div className="text-xs text-zinc-500">Per single customer at list price. “At 100% usage” assumes the customer maxes every limit — the floor of your margin. Fees: {eco.processing_fee_pct}% + {money(eco.processing_fee_fixed)} per charge.</div></div>
                <div className="grid xl:grid-cols-2 gap-4">
                    {eco.plans.map((p) => { const e = edit[p.code] || {}; return (
                        <div key={p.code} className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5" data-testid={`plan-editor-${p.code}`}>
                            <div className="flex items-start justify-between gap-3">
                                <div className="flex-1"><Label className="text-[10px] uppercase tracking-widest text-zinc-400">Plan name · code {p.code}</Label><Input value={e.name || ""} onChange={(ev) => setEdit({ ...edit, [p.code]: { ...e, name: ev.target.value } })} className="mt-1 font-medium" data-testid={`plan-name-${p.code}`} /></div>
                                <div className="text-right text-xs"><div className={`px-2 py-1 rounded-full ${p.net_profit_monthly_plan < 0 ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`}>{p.net_profit_monthly_plan < 0 ? "Loses money at full usage" : `${p.margin_pct ?? 0}% margin`}</div></div>
                            </div>
                            <div className="grid grid-cols-2 gap-3 mt-3">
                                <div><Label>Monthly price ($)</Label><Input type="number" step="1" value={e.price_usd ?? 0} onChange={(ev) => setEdit({ ...edit, [p.code]: { ...e, price_usd: ev.target.value } })} className="mt-1" data-testid={`plan-price-${p.code}`} /></div>
                                <div><Label>Annual price ($ / year)</Label><Input type="number" step="1" value={e.annual_price_usd ?? 0} onChange={(ev) => setEdit({ ...edit, [p.code]: { ...e, annual_price_usd: ev.target.value } })} className="mt-1" data-testid={`plan-annual-${p.code}`} /><div className="text-[11px] text-zinc-500 mt-0.5">= {money(p.annual_monthly_equiv)}/mo · {p.annual_discount_pct}% off</div></div>
                            </div>
                            <div className="mt-3"><Label>Tagline</Label><Input value={e.tagline || ""} onChange={(ev) => setEdit({ ...edit, [p.code]: { ...e, tagline: ev.target.value } })} className="mt-1" /></div>
                            <div className="mt-3"><Label>Features (one per line)</Label><textarea value={e.features || ""} onChange={(ev) => setEdit({ ...edit, [p.code]: { ...e, features: ev.target.value } })} rows={4} className="mt-1 w-full rounded-lg border border-brand-line px-3 py-2 text-sm" /></div>
                            <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                                <div className="rounded-lg bg-zinc-50 dark:bg-white/5 p-3"><div className="text-zinc-500">Monthly plan — per customer / month</div>
                                    <div className="mt-1 flex justify-between"><span>Price</span><span>{money(p.price_monthly)}</span></div><div className="flex justify-between"><span>Cost @100% usage</span><span>−{money(p.cost_at_full_usage)}</span></div><div className="flex justify-between"><span>Card fee</span><span>−{money(p.processing_fee_monthly)}</span></div>
                                    <div className="flex justify-between border-t border-brand-line mt-1 pt-1"><span>Net</span><PL v={p.net_profit_monthly_plan} /></div></div>
                                <div className="rounded-lg bg-zinc-50 dark:bg-white/5 p-3"><div className="text-zinc-500">Annual plan — per customer / month</div>
                                    <div className="mt-1 flex justify-between"><span>Price (÷12)</span><span>{money(p.annual_monthly_equiv)}</span></div><div className="flex justify-between"><span>Cost @100% usage</span><span>−{money(p.cost_at_full_usage)}</span></div><div className="flex justify-between"><span>Card fee</span><span>−{money(p.processing_fee_annual_monthly_equiv)}</span></div>
                                    <div className="flex justify-between border-t border-brand-line mt-1 pt-1"><span>Net</span><PL v={p.net_profit_annual_plan_per_month} /></div>
                                    <div className="flex justify-between text-zinc-500 mt-1"><span>vs monthly, per year</span><PL v={p.annual_vs_monthly_delta_per_year} /></div></div>
                            </div>
                            <div className="mt-4 flex justify-between items-center">
                                <button type="button" className="text-xs text-brand-copper hover:underline" onClick={() => toggleHistory(p.code)} data-testid={`plan-history-${p.code}`}>{history[p.code] ? "Hide" : "Show"} pricing history</button>
                                <Button size="sm" disabled={busy} onClick={() => savePlan(p.code)} data-testid={`plan-save-${p.code}`}>Save {e.name}</Button>
                            </div>
                            {history[p.code] && (
                                <div className="mt-3 rounded-lg bg-zinc-50 border border-brand-line p-3 text-xs space-y-1" data-testid={`plan-history-list-${p.code}`}>
                                    <div className="text-zinc-500 uppercase tracking-widest text-[10px]">Version history (newest first) · current v{history[p.code].current?.pricing_version ?? 1}</div>
                                    {history[p.code].history.length === 0 && <div className="text-zinc-500">No changes recorded yet.</div>}
                                    {history[p.code].history.map((h, i) => (
                                        <div key={i} className="flex flex-wrap gap-x-3 gap-y-0.5 border-t border-brand-line pt-1">
                                            <span className="font-mono text-zinc-500">{new Date(h.created_at).toLocaleString()}</span>
                                            <span>v{h.pricing_version ?? h.version ?? "?"}</span>
                                            <span>${h.price_usd ?? h.after?.price_usd ?? "—"}/mo</span>
                                            {(h.annual_price_usd ?? h.after?.annual_price_usd) != null && <span>${h.annual_price_usd ?? h.after?.annual_price_usd}/yr</span>}
                                            {(h.actor || h.changed_by) && <span className="text-zinc-500">by {h.actor || h.changed_by}</span>}
                                            {h.reason && <span className="text-zinc-500 italic">{h.reason}</span>}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>); })}
                </div>
            </section>

            {/* Cost model */}
            <section className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5" data-testid="cost-model">
                <div className="font-medium">Cost model</div><div className="text-xs text-zinc-500">Your real per-unit costs from your providers. These drive every number above.</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
                    {Object.entries(settings.unit_costs || {}).map(([k, v]) => (
                        <div key={k}><Label className="text-xs">{k.replace(/_/g, " ")} ($)</Label><Input type="number" step="0.0001" value={v} onChange={(e) => setSettings({ ...settings, unit_costs: { ...settings.unit_costs, [k]: Number(e.target.value) } })} className="mt-1" data-testid={`cost-${k}`} /></div>))}
                    <div><Label className="text-xs">Card fee %</Label><Input type="number" step="0.1" value={settings.processing_fee_pct ?? 2.9} onChange={(e) => setSettings({ ...settings, processing_fee_pct: e.target.value })} className="mt-1" /></div>
                    <div><Label className="text-xs">Card fee fixed ($)</Label><Input type="number" step="0.01" value={settings.processing_fee_fixed ?? 0.3} onChange={(e) => setSettings({ ...settings, processing_fee_fixed: e.target.value })} className="mt-1" /></div>
                    <div><Label className="text-xs">Default annual discount %</Label><Input type="number" value={settings.annual_discount_pct ?? 20} onChange={(e) => setSettings({ ...settings, annual_discount_pct: e.target.value })} className="mt-1" /></div>
                </div>
                <div className="mt-4 flex justify-end"><Button size="sm" disabled={busy} onClick={saveCosts} data-testid="cost-save"><Percent className="w-3.5 h-3.5" /> Save cost model</Button></div>
            </section>
        </div>
    );
}
