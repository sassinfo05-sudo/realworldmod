/**
 * Round 11 — Unified staff support inbox (all tenants) + incidents that feed the public /status page.
 * API: /api/staff/support/* and /api/staff/incidents (see backend/app/routes/staff_support.py).
 */
import { useCallback, useEffect, useRef, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { LifeBuoy, Lock, StickyNote, Send, UserCheck, AlertTriangle, RefreshCw } from "lucide-react";

const STATUSES = ["open", "answered", "waiting_on_customer", "resolved", "closed"];
const sel = "bg-white border border-brand-line rounded-md px-3 py-1.5 text-sm text-brand-ink";
const inp = "w-full bg-white border border-brand-line rounded-md px-3 py-2 text-sm text-brand-ink placeholder:text-zinc-400 outline-none focus:border-brand-copper";
const btn = "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors";

function Stat({ label, value }) {
    return (
        <div className="rounded-xl bg-white border border-brand-line p-4">
            <div className="text-2xl font-semibold">{value ?? "—"}</div>
            <div className="text-zinc-500 text-xs mt-1">{label}</div>
        </div>
    );
}

function Badge({ children, tone = "zinc" }) {
    const tones = { zinc: "bg-zinc-100 text-zinc-600", amber: "bg-amber-100 text-amber-700", emerald: "bg-emerald-100 text-emerald-700",
        indigo: "bg-indigo-100 text-indigo-700", red: "bg-red-100 text-red-700" };
    return <span className={`text-[11px] px-2 py-0.5 rounded-full ${tones[tone] || tones.zinc}`}>{children}</span>;
}
const statusTone = (s) => ({ open: "amber", answered: "indigo", waiting_on_customer: "zinc", resolved: "emerald", closed: "zinc" }[s] || "zinc");

function TicketDetail({ id, onChanged }) {
    const [t, setT] = useState(null);
    const [reply, setReply] = useState("");
    const [note, setNote] = useState("");
    const [busy, setBusy] = useState(false);
    const [lockErr, setLockErr] = useState(null);
    const hb = useRef(null);

    const load = useCallback(async () => {
        try { const { data } = await api.get(`/staff/support/tickets/${id}`); setT(data); } catch { toast.error("Could not load ticket"); }
    }, [id]);

    useEffect(() => {
        load();
        // Collision lock with 60 s TTL, refreshed every 30 s while this ticket is open.
        const take = async () => {
            try { await api.post(`/staff/support/tickets/${id}/lock`); setLockErr(null); }
            catch (e) { const d = e?.response?.data?.detail; setLockErr(d?.by ? `Being handled by ${d.by}` : "Locked by another agent"); }
        };
        take();
        hb.current = setInterval(take, 30000);
        return () => { clearInterval(hb.current); api.delete(`/staff/support/tickets/${id}/lock`).catch(() => {}); };
    }, [id, load]);

    const act = async (fn, ok) => {
        setBusy(true);
        try { await fn(); if (ok) toast.success(ok); await load(); onChanged?.(); }
        catch (e) { const d = e?.response?.data?.detail; toast.error(typeof d === "string" ? d : d?.code === "ticket_locked" ? `Locked by ${d.by}` : "Action failed"); }
        finally { setBusy(false); }
    };

    if (!t) return <div className="text-zinc-500 text-sm">Loading…</div>;
    return (
        <div className="space-y-4" data-testid="staff-ticket-detail">
            <div className="flex flex-wrap items-start gap-3">
                <div className="flex-1 min-w-0">
                    <div className="text-lg font-semibold truncate">{t.subject}</div>
                    <div className="text-xs text-zinc-500 mt-0.5">{t.org_name || t.org_id} · {t.category} · severity {t.severity} · opened {t.created_at?.slice(0, 16).replace("T", " ")}</div>
                </div>
                <Badge tone={statusTone(t.status)}>{t.status}</Badge>
                {t.assignee_email ? <Badge tone="indigo">{t.assignee_email}</Badge> : <Badge>unassigned</Badge>}
            </div>
            {lockErr && <div className="rounded-md bg-amber-50 border border-amber-200 text-amber-800 text-xs px-3 py-2 flex items-center gap-2" data-testid="staff-ticket-locked"><Lock className="w-3.5 h-3.5" /> {lockErr} — replies are blocked until their lock expires.</div>}
            <div className="flex flex-wrap gap-2">
                <button className={`${btn} bg-zinc-100 hover:bg-zinc-200 text-brand-ink`} disabled={busy} onClick={() => act(() => api.post(`/staff/support/tickets/${id}/assign`, { staff_id: "me" }), "Assigned to you")} data-testid="staff-ticket-assign-me"><UserCheck className="w-4 h-4" /> Assign to me</button>
                <select className={sel} value={t.status} onChange={(e) => act(() => api.post(`/staff/support/tickets/${id}/status`, { status: e.target.value }), "Status updated")} data-testid="staff-ticket-status">
                    {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
                </select>
            </div>

            <div className="rounded-xl bg-white border border-brand-line p-4 space-y-3 max-h-[40vh] overflow-y-auto" data-testid="staff-ticket-messages">
                {(t.messages || []).map((m, i) => (
                    <div key={i} className={`text-sm ${m.author === "staff" ? "pl-6" : ""}`}>
                        <div className="text-[11px] text-zinc-400">{m.author === "staff" ? `Staff · ${m.email}` : `Customer · ${m.email}`} · {m.created_at?.slice(0, 16).replace("T", " ")}</div>
                        <div className={`mt-0.5 rounded-lg px-3 py-2 ${m.author === "staff" ? "bg-indigo-50" : "bg-zinc-100"}`}>{m.text}</div>
                    </div>
                ))}
            </div>
            <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1.5"><Send className="w-3.5 h-3.5" /> Reply to customer</div>
                    <textarea className={inp} rows={4} value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Visible to the customer; emailed when a provider is connected" data-testid="staff-ticket-reply" />
                    <div className="flex gap-2">
                        <button className={`${btn} bg-brand-copper hover:bg-brand-copperHover text-white`} disabled={busy || !reply.trim() || !!lockErr} onClick={() => act(async () => { await api.post(`/staff/support/tickets/${id}/reply`, { text: reply }); setReply(""); }, "Reply sent")} data-testid="staff-ticket-send">Send reply</button>
                        <button className={`${btn} bg-zinc-100 hover:bg-zinc-200 text-brand-ink`} disabled={busy || !reply.trim() || !!lockErr} onClick={() => act(async () => { await api.post(`/staff/support/tickets/${id}/reply`, { text: reply, status: "resolved" }); setReply(""); }, "Replied & resolved")} data-testid="staff-ticket-send-resolve">Send &amp; resolve</button>
                    </div>
                </div>
                <div className="space-y-2">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1.5"><StickyNote className="w-3.5 h-3.5" /> Internal notes (staff only)</div>
                    <div className="space-y-1.5 max-h-28 overflow-y-auto" data-testid="staff-ticket-notes">
                        {(t.internal_notes || []).map((n) => <div key={n.id} className="text-xs rounded-md bg-amber-50 border border-amber-200 px-2.5 py-1.5"><span className="text-zinc-400">{n.email} · {n.created_at?.slice(0, 16).replace("T", " ")}</span><div className="text-brand-ink">{n.text}</div></div>)}
                        {!(t.internal_notes || []).length && <div className="text-xs text-zinc-400">No notes yet.</div>}
                    </div>
                    <div className="flex gap-2">
                        <input className={inp} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add a private note" data-testid="staff-ticket-note-input" />
                        <button className={`${btn} bg-zinc-100 hover:bg-zinc-200 text-brand-ink`} disabled={busy || !note.trim()} onClick={() => act(async () => { await api.post(`/staff/support/tickets/${id}/notes`, { text: note }); setNote(""); }, "Note added")} data-testid="staff-ticket-note-add">Add</button>
                    </div>
                </div>
            </div>
        </div>
    );
}

function TicketsTab() {
    const [status, setStatus] = useState("open,answered,waiting_on_customer");
    const [assignee, setAssignee] = useState("");
    const [q, setQ] = useState("");
    const [rows, setRows] = useState([]);
    const [stats, setStats] = useState(null);
    const [sel, setSel] = useState(null);

    const load = useCallback(async () => {
        try {
            const [{ data }, { data: st }] = await Promise.all([
                api.get("/staff/support/tickets", { params: { status, assignee, q } }), api.get("/staff/support/stats")]);
            setRows(data.tickets || []); setStats(st);
        } catch (e) { toast.error(e?.response?.data?.detail || "Cannot load (needs tenants permission)"); }
    }, [status, assignee, q]);
    useEffect(() => { load(); }, [load]);

    return (
        <div className="space-y-5">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3" data-testid="staff-support-stats">
                <Stat label="Open" value={stats?.by_status?.open || 0} />
                <Stat label="Answered / waiting" value={(stats?.by_status?.answered || 0) + (stats?.by_status?.waiting_on_customer || 0)} />
                <Stat label="Unassigned" value={stats?.unassigned_open} />
                <Stat label="Median first response" value={stats?.median_first_response_min == null ? "—" : `${stats.median_first_response_min} min`} />
                <Stat label="Resolved (30 d)" value={stats?.resolved_in_window} />
            </div>
            <div className="flex flex-wrap gap-2 items-center">
                <select className={sel} value={status} onChange={(e) => setStatus(e.target.value)} data-testid="staff-support-filter-status">
                    <option value="open,answered,waiting_on_customer">Active</option>
                    {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
                    <option value="">All</option>
                </select>
                <select className={sel} value={assignee} onChange={(e) => setAssignee(e.target.value)} data-testid="staff-support-filter-assignee">
                    <option value="">Anyone</option><option value="me">Assigned to me</option><option value="unassigned">Unassigned</option>
                </select>
                <input className={`${inp} max-w-xs`} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search subject" data-testid="staff-support-search" />
                <button className={`${btn} bg-zinc-100 hover:bg-zinc-200 text-brand-ink ml-auto`} onClick={load}><RefreshCw className="w-4 h-4" /> Refresh</button>
            </div>
            <div className="grid lg:grid-cols-[380px_1fr] gap-5">
                <div className="rounded-2xl bg-white border border-brand-line divide-y divide-brand-line max-h-[70vh] overflow-y-auto" data-testid="staff-support-list">
                    {rows.length === 0 && <div className="p-6 text-sm text-zinc-400">No tickets match.</div>}
                    {rows.map((t) => (
                        <button key={t.id} onClick={() => setSel(t.id)} className={`w-full text-left p-4 hover:bg-zinc-50 ${sel === t.id ? "bg-brand-cream" : ""}`} data-testid={`staff-ticket-${t.id}`}>
                            <div className="flex items-center gap-2">
                                <span className="font-medium text-sm truncate flex-1">{t.subject}</span>
                                <Badge tone={statusTone(t.status)}>{t.status}</Badge>
                                {t.lock && <Lock className="w-3.5 h-3.5 text-amber-500" title={`Being handled by ${t.lock.email}`} />}
                            </div>
                            <div className="text-[11px] text-zinc-500 mt-1 truncate">{t.org_name || t.org_id} · {t.severity} · {t.assignee_email || "unassigned"} · {t.messages_count} msgs</div>
                            <div className="text-xs text-zinc-600 mt-1 truncate">{t.last_author === "staff" ? "You: " : ""}{t.last_preview}</div>
                        </button>
                    ))}
                </div>
                <div className="rounded-2xl bg-white border border-brand-line p-5 min-h-[300px]">
                    {sel ? <TicketDetail id={sel} onChanged={load} /> : <div className="text-sm text-zinc-400">Select a ticket to read, assign, note or reply.</div>}
                </div>
            </div>
        </div>
    );
}

function IncidentsTab() {
    const [rows, setRows] = useState([]);
    const [form, setForm] = useState({ title: "", status: "investigating", impact: "minor", components: "api", message: "" });
    const [upd, setUpd] = useState({});
    const load = useCallback(async () => { try { const { data } = await api.get("/staff/incidents"); setRows(data.incidents || []); } catch { toast.error("Cannot load incidents (needs health permission)"); } }, []);
    useEffect(() => { load(); }, [load]);
    const create = async () => {
        try {
            await api.post("/staff/incidents", { ...form, components: form.components.split(",").map((s) => s.trim()).filter(Boolean) });
            toast.success("Incident published to /status"); setForm({ title: "", status: "investigating", impact: "minor", components: "api", message: "" }); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not create incident"); }
    };
    const update = async (id, status) => {
        try { await api.post(`/staff/incidents/${id}/updates`, { status, message: upd[id] || "" }); setUpd((u) => ({ ...u, [id]: "" })); toast.success("Update posted"); load(); }
        catch { toast.error("Could not post update"); }
    };
    return (
        <div className="grid lg:grid-cols-[360px_1fr] gap-5">
            <div className="rounded-2xl bg-white border border-brand-line p-5 space-y-3" data-testid="staff-incident-form">
                <div className="text-sm font-medium flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-amber-400" /> Declare an incident</div>
                <input className={inp} placeholder="Title, e.g. Delayed email delivery" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} data-testid="staff-incident-title" />
                <div className="grid grid-cols-2 gap-2">
                    <select className={sel} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>{["investigating", "identified", "monitoring", "resolved"].map((s) => <option key={s}>{s}</option>)}</select>
                    <select className={sel} value={form.impact} onChange={(e) => setForm({ ...form, impact: e.target.value })}>{["none", "minor", "major", "critical"].map((s) => <option key={s}>{s}</option>)}</select>
                </div>
                <input className={inp} placeholder="Components (comma): api, database, llm" value={form.components} onChange={(e) => setForm({ ...form, components: e.target.value })} />
                <textarea className={inp} rows={3} placeholder="First public update" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
                <button className={`${btn} bg-brand-copper hover:bg-brand-copperHover text-white w-full justify-center`} disabled={form.title.trim().length < 3} onClick={create} data-testid="staff-incident-create">Publish to status page</button>
                <p className="text-[11px] text-zinc-400">Public page: <span className="font-mono">/status</span>. Active incidents mark their components degraded (critical = outage).</p>
            </div>
            <div className="space-y-3" data-testid="staff-incident-list">
                {rows.length === 0 && <div className="rounded-2xl bg-white border border-brand-line p-6 text-sm text-zinc-400">No incidents declared. The status page shows all systems operational when checks pass.</div>}
                {rows.map((i) => (
                    <div key={i.id} className="rounded-2xl bg-white border border-brand-line p-4" data-testid={`staff-incident-${i.id}`}>
                        <div className="flex flex-wrap items-center gap-2">
                            <span className="font-medium flex-1">{i.title}</span>
                            <Badge tone={i.status === "resolved" ? "emerald" : "amber"}>{i.status}</Badge>
                            <Badge tone={i.impact === "critical" ? "red" : "zinc"}>{i.impact}</Badge>
                            <span className="text-[11px] text-zinc-400">{(i.components || []).join(", ")}</span>
                        </div>
                        <div className="mt-2 space-y-1">{(i.updates || []).map((u, k) => <div key={k} className="text-xs text-zinc-700"><span className="text-zinc-400">{u.at?.slice(0, 16).replace("T", " ")} · {u.status}</span> — {u.message}</div>)}</div>
                        {i.status !== "resolved" && (
                            <div className="mt-3 flex flex-wrap gap-2 items-center">
                                <input className={`${inp} flex-1 min-w-[200px]`} placeholder="Update message" value={upd[i.id] || ""} onChange={(e) => setUpd({ ...upd, [i.id]: e.target.value })} />
                                {["identified", "monitoring", "resolved"].map((s) => <button key={s} className={`${btn} ${s === "resolved" ? "bg-emerald-600 hover:bg-emerald-500 text-white" : "bg-zinc-100 hover:bg-zinc-200 text-brand-ink"}`} onClick={() => update(i.id, s)} data-testid={`staff-incident-${i.id}-${s}`}>{s}</button>)}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
}

export default function StaffSupport() {
    const [tab, setTab] = useState("tickets");
    return (
        <div className="p-6 max-w-7xl mx-auto space-y-6 text-brand-ink" data-testid="staff-support-page">
            <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                    <h1 className="text-2xl font-semibold flex items-center gap-2"><LifeBuoy className="w-6 h-6 text-brand-copper" /> Support inbox</h1>
                    <p className="text-zinc-500 text-sm mt-1">Every tenant's tickets in one queue — assign, add private notes, reply, and avoid two agents answering at once. Incidents you declare here appear on the public status page.</p>
                </div>
                <div className="flex gap-1 bg-white border border-brand-line rounded-lg p-1">
                    {[["tickets", "Tickets"], ["incidents", "Incidents & status page"]].map(([k, l]) => (
                        <button key={k} onClick={() => setTab(k)} className={`px-3 py-1.5 rounded-md text-sm ${tab === k ? "bg-brand-cream text-brand-ink" : "text-zinc-500 hover:text-brand-ink"}`} data-testid={`staff-support-tab-${k}`}>{l}</button>
                    ))}
                </div>
            </div>
            {tab === "tickets" ? <TicketsTab /> : <IncidentsTab />}
        </div>
    );
}
