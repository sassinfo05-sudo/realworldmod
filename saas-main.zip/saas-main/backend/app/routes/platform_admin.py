"""Founder-only platform admin: white-label settings, plan pricing & limits,
and the profit/economics calculator. Mounted at /api/founder.
"""
from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db, utc_now_iso
from ..deps import require_role, require_staff
from ..models import User
from ..services import platform_settings as ps
from ..services import integrations as integ
from ..services.entitlements import (
    apply_db_overrides, entitlements_dict, plan_economics,
)

router = APIRouter(prefix="/api/founder", tags=["founder-admin"])
_founder = require_role("platform_founder")
_pricing = require_staff("pricing")
_integrations_rw = require_staff("integrations")


# ---------- Third-party integrations (owner-managed keys) ----------

@router.get("/integrations")
async def get_integrations(_: User = Depends(_founder)):
    return await integ.get_public()


@router.put("/integrations")
async def update_integrations(patch: Dict[str, Any] = Body(...),
                              _: User = Depends(_integrations_rw)):
    return await integ.update(patch or {})


@router.get("/integrations/probe/stripe")
async def probe_stripe(_: User = Depends(_integrations_rw)):
    """REAL read-only Stripe probe of the platform key (Live / Sandbox / Not connected / Error + Connect enabled).
    Never returns the key."""
    from ..services import stripe_connect
    return await stripe_connect.probe_platform()


@router.get("/integrations/probe/cloudflare")
async def probe_cloudflare(_: User = Depends(_integrations_rw)):
    """REAL read-only Cloudflare probe (Connected / Not connected / Error). Never returns the token."""
    from ..services import domain_providers
    return await domain_providers.probe_cloudflare()


# ---------- White-label settings ----------

@router.get("/settings")
async def get_platform_settings(_: User = Depends(_founder)):
    return await ps.get_settings()


@router.put("/settings")
async def update_platform_settings(patch: Dict[str, Any] = Body(...),
                                   _: User = Depends(_founder)):
    return await ps.update_settings(patch or {})


# ---------- Plans: pricing + limits ----------

async def _plan_docs() -> List[Dict[str, Any]]:
    db = get_db()
    return [p async for p in db.plans.find({}, {"_id": 0}).sort("order", 1)]


def _enrich_plan(doc: Dict[str, Any]) -> Dict[str, Any]:
    """Attach the effective limits (DB override or default) to a plan doc."""
    code = doc.get("code")
    doc = dict(doc)
    doc["limits"] = entitlements_dict(code)
    return doc


@router.get("/plans-admin")
async def list_plans_admin(_: User = Depends(_founder)):
    docs = await _plan_docs()
    return [_enrich_plan(d) for d in docs]


class PlanUpdate(BaseModel):
    price_usd: Optional[float] = None
    annual_price_usd: Optional[float] = None
    name: Optional[str] = None
    audience: Optional[str] = None
    tagline: Optional[str] = None
    features: Optional[List[str]] = None
    highlight: Optional[bool] = None
    badge: Optional[str] = None
    limits: Optional[Dict[str, Any]] = None


@router.put("/plans-admin/{code}")
async def update_plan(code: str, patch: PlanUpdate, _: User = Depends(_pricing)):
    db = get_db()
    existing = await db.plans.find_one({"code": code})
    if not existing:
        raise HTTPException(404, "Plan not found")

    upd: Dict[str, Any] = {"updated_at": utc_now_iso()}
    if patch.price_usd is not None:
        if patch.price_usd < 0 or patch.price_usd > 100000:
            raise HTTPException(422, "Monthly price must be between 0 and 100000")
        upd["price_usd"] = round(float(patch.price_usd), 2)
    if patch.annual_price_usd is not None:
        if patch.annual_price_usd < 0 or patch.annual_price_usd > 1000000:
            raise HTTPException(422, "Annual price must be between 0 and 1000000")
        upd["annual_price_usd"] = round(float(patch.annual_price_usd), 2)
    new_monthly = upd.get("price_usd", existing.get("price_usd") or 0)
    new_annual = upd.get("annual_price_usd", existing.get("annual_price_usd"))
    if new_annual is not None and new_monthly and float(new_annual) > float(new_monthly) * 12:
        raise HTTPException(422, "Annual price can't exceed 12× the monthly price")
    if new_monthly == 0 and code != "free" and ("price_usd" in upd):
        raise HTTPException(422, "Only the Free plan may be priced at $0")
    if patch.name is not None and patch.name.strip():
        upd["name"] = patch.name.strip()
    if patch.audience is not None:
        upd["audience"] = patch.audience
    if patch.tagline is not None:
        upd["tagline"] = patch.tagline
    if patch.features is not None:
        upd["features"] = patch.features
    if patch.highlight is not None:
        upd["highlight"] = bool(patch.highlight)
    if patch.badge is not None:
        upd["badge"] = patch.badge
    if patch.limits is not None:
        cur = existing.get("limits") or {}
        upd["limits"] = {**cur, **patch.limits}

    # Pricing version + history: every change to price/limits is recorded (immutable rows);
    # existing subscriptions keep their checkout-time price snapshot, new purchases use the new price.
    price_changed = any(k in upd for k in ("price_usd", "annual_price_usd", "limits"))
    if price_changed:
        version = int(existing.get("pricing_version") or 1) + 1
        upd["pricing_version"] = version
        await db.plan_pricing_history.insert_one({
            "id": str(uuid.uuid4()), "plan_code": code, "version": version,
            "actor": getattr(_, "email", None),
            "before": {"price_usd": existing.get("price_usd"), "annual_price_usd": existing.get("annual_price_usd"),
                       "limits": existing.get("limits") or {}},
            "after": {"price_usd": upd.get("price_usd", existing.get("price_usd")),
                      "annual_price_usd": upd.get("annual_price_usd", existing.get("annual_price_usd")),
                      "limits": upd.get("limits", existing.get("limits") or {})},
            "effective_at": utc_now_iso(), "created_at": utc_now_iso(),
        })

    await db.plans.update_one({"code": code}, {"$set": upd})

    # Refresh in-memory entitlement overrides so enforcement reflects edits now.
    apply_db_overrides(await _plan_docs())

    doc = await db.plans.find_one({"code": code}, {"_id": 0})
    return _enrich_plan(doc)


@router.get("/plans-admin/{code}/history")
async def plan_pricing_history(code: str, _: User = Depends(_founder)):
    """Immutable pricing/limits version history for a plan (newest first)."""
    db = get_db()
    rows = [d async for d in db.plan_pricing_history.find({"plan_code": code}, {"_id": 0})
            .sort("created_at", -1).limit(200)]
    plan = await db.plans.find_one({"code": code}, {"_id": 0, "pricing_version": 1, "price_usd": 1,
                                                    "annual_price_usd": 1})
    return {"plan_code": code, "current": plan or {}, "history": rows}


# ---------- Economics / profit calculator ----------

@router.get("/economics")
async def economics(_: User = Depends(_founder)):
    """Real plan economics: list price vs. cost at full usage (worst case) AND the actual
    picture from the database — live subscribers per plan, their real metered usage this
    month, payment-processing fees, revenue, cost and profit (monthly + annual)."""
    from datetime import datetime, timezone
    db = get_db()
    settings = await ps.get_settings()
    unit_costs = settings.get("unit_costs") or {}
    annual_discount = settings.get("annual_discount_pct", 20)
    fee_pct = float(settings.get("processing_fee_pct", 2.9))
    fee_fixed = float(settings.get("processing_fee_fixed", 0.30))
    docs = await _plan_docs()
    plans = [plan_economics(d, unit_costs, annual_discount) for d in docs]

    month_start = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    month_iso = month_start.isoformat().replace("+00:00", "Z")

    # Active subscriptions grouped by plan + interval
    subs = [s async for s in db.subscriptions.find({"status": {"$in": ["active", "trialing", "past_due"]}})]
    org_plan = {s["org_id"]: s for s in subs}
    # Orgs without a subscription doc are on Free.
    all_org_ids = [str(o["_id"]) async for o in db.organizations.find({}, {"_id": 1})]
    for oid in all_org_ids:
        org_plan.setdefault(oid, {"org_id": oid, "plan_code": "free", "interval": "monthly", "status": "active"})

    # Real usage this month (per org)
    async def _count(coll, extra=None):
        q = {"sent_at": {"$gte": month_iso}} if coll == "email_messages" else {"created_at": {"$gte": month_iso}}
        q.update(extra or {})
        out: Dict[str, int] = {}
        async for row in db[coll].aggregate([{"$match": q}, {"$group": {"_id": "$org_id", "n": {"$sum": 1}}}]):
            out[row["_id"]] = row["n"]
        return out
    emails = await _count("email_messages", {"direction": "outbound"})
    ai_convs = await _count("ai_conversations")
    sites: Dict[str, int] = {}
    async for row in db.websites.aggregate([{"$group": {"_id": "$org_id", "n": {"$sum": 1}}}]):
        sites[row["_id"]] = row["n"]
    contacts: Dict[str, int] = {}
    async for row in db.contacts.aggregate([{"$group": {"_id": "$org_id", "n": {"$sum": 1}}}]):
        contacts[row["_id"]] = row["n"]
    voice: Dict[str, float] = {}
    async for row in db.voice_calls.aggregate([{"$match": {"created_at": {"$gte": month_iso}}},
                                               {"$group": {"_id": "$org_id", "m": {"$sum": "$duration_min"}}}]):
        voice[row["_id"]] = float(row.get("m") or 0)

    uc = unit_costs
    by_plan: Dict[str, Dict[str, Any]] = {}
    for p in plans:
        by_plan[p["code"]] = {"code": p["code"], "name": p["name"], "subscribers": 0, "monthly_subs": 0, "annual_subs": 0,
                              "mrr": 0.0, "arr_from_annual": 0.0, "usage_cost": 0.0, "processing_fees": 0.0,
                              "usage": {"emails": 0, "ai_conversations": 0, "websites": 0, "contacts": 0, "voice_minutes": 0.0}}
    price_by_code = {d["code"]: d for d in docs}
    for oid, sub in org_plan.items():
        code = sub.get("plan_code") or "free"
        row = by_plan.get(code)
        if not row:
            continue
        pd = price_by_code.get(code, {})
        interval = sub.get("interval") or sub.get("billing_interval") or "monthly"
        price = float(pd.get("price_usd") or 0)
        annual = float(pd.get("annual_price_usd") or (price * 12 * (1 - float(annual_discount or 0) / 100)))
        row["subscribers"] += 1
        if interval == "annual":
            row["annual_subs"] += 1
            row["mrr"] += annual / 12.0
            row["arr_from_annual"] += annual
            if annual > 0:
                row["processing_fees"] += (annual * fee_pct / 100 + fee_fixed) / 12.0
        else:
            row["monthly_subs"] += 1
            row["mrr"] += price
            if price > 0:
                row["processing_fees"] += price * fee_pct / 100 + fee_fixed
        u = row["usage"]
        e, a, w, c, v = emails.get(oid, 0), ai_convs.get(oid, 0), sites.get(oid, 0), contacts.get(oid, 0), voice.get(oid, 0.0)
        u["emails"] += e; u["ai_conversations"] += a; u["websites"] += w; u["contacts"] += c; u["voice_minutes"] += v
        row["usage_cost"] += (e * float(uc.get("per_email", 0) or 0) + a * float(uc.get("per_ai_conversation", 0) or 0)
                              + w * float(uc.get("per_website_month", 0) or 0) + c * float(uc.get("per_contact_month", 0) or 0)
                              + v * float(uc.get("per_voice_minute", 0) or 0) + float(uc.get("base_infra_per_org_month", 0) or 0))

    actual = []
    tot = {"mrr": 0.0, "cost": 0.0, "fees": 0.0, "profit": 0.0, "subscribers": 0}
    for code, row in by_plan.items():
        row["usage_cost"] = round(row["usage_cost"], 2)
        row["processing_fees"] = round(row["processing_fees"], 2)
        row["mrr"] = round(row["mrr"], 2)
        row["profit_monthly"] = round(row["mrr"] - row["usage_cost"] - row["processing_fees"], 2)
        row["profit_annualized"] = round(row["profit_monthly"] * 12, 2)
        row["margin_pct"] = round(row["profit_monthly"] / row["mrr"] * 100, 1) if row["mrr"] > 0 else None
        row["usage"]["voice_minutes"] = round(row["usage"]["voice_minutes"], 1)
        tot["mrr"] += row["mrr"]; tot["cost"] += row["usage_cost"]; tot["fees"] += row["processing_fees"]
        tot["profit"] += row["profit_monthly"]; tot["subscribers"] += row["subscribers"]
        actual.append(row)
    tot = {k: (round(v, 2) if isinstance(v, float) else v) for k, v in tot.items()}
    tot["arr"] = round(tot["mrr"] * 12, 2)

    # Per-plan monthly vs annual profit per single customer (list price, worst-case usage, fees)
    for p in plans:
        pm = p["price_monthly"]; pa = p["annual_price"]
        fees_m = (pm * fee_pct / 100 + fee_fixed) if pm > 0 else 0.0
        fees_a = ((pa * fee_pct / 100 + fee_fixed) / 12.0) if pa > 0 else 0.0
        p["processing_fee_monthly"] = round(fees_m, 2)
        p["processing_fee_annual_monthly_equiv"] = round(fees_a, 2)
        p["net_profit_monthly_plan"] = round(pm - p["cost_at_full_usage"] - fees_m, 2)
        p["net_profit_annual_plan_per_month"] = round(p["annual_monthly_equiv"] - p["cost_at_full_usage"] - fees_a, 2)
        p["net_profit_annual_plan_per_year"] = round(p["net_profit_annual_plan_per_month"] * 12, 2)
        p["annual_vs_monthly_delta_per_year"] = round((p["net_profit_annual_plan_per_month"] - p["net_profit_monthly_plan"]) * 12, 2)

    total_profit = sum((p["profit_monthly"] or 0) for p in plans if p["code"] != "free")
    free = next((p for p in plans if p["code"] == "free"), None)

    # ---- Managed phone-numbers economics ----
    from ..services import numbers as numbers_svc
    carrier = await numbers_svc.platform_carrier()
    wholesale_num = numbers_svc.CARRIERS.get(carrier["provider"], {}).get("wholesale_number_month", 1.0)
    num_docs = [n async for n in db.phone_numbers.find({"status": {"$ne": "released"}})]
    total_numbers = len(num_docs)
    free_numbers = sum(1 for n in num_docs if n.get("is_free_allotment"))
    paid_numbers = total_numbers - free_numbers
    numbers_revenue = round(sum(float(n.get("monthly_price") or 0) for n in num_docs), 2)
    numbers_wholesale = round(total_numbers * wholesale_num, 2)
    numbers_profit = round(numbers_revenue - numbers_wholesale, 2)
    numbers_economics = {
        "carrier": carrier,
        "wholesale_number_month": wholesale_num,
        "retail_number_month": numbers_svc.RETAIL_NUMBER_MONTH,
        "retail_tollfree_month": numbers_svc.RETAIL_TOLLFREE_MONTH,
        "total_numbers": total_numbers,
        "free_numbers": free_numbers,
        "paid_numbers": paid_numbers,
        "monthly_revenue": numbers_revenue,
        "monthly_wholesale_cost": numbers_wholesale,
        "monthly_profit": numbers_profit,
        "free_allotment_cost": round(free_numbers * wholesale_num, 2),
        "plan_free_numbers": numbers_svc.PLAN_FREE_NUMBERS,
        "note": "We buy numbers wholesale and include some free per plan; extra numbers bill monthly at retail. Profit = retail revenue − wholesale cost.",
    }
    for p in plans:
        p["free_numbers_included"] = numbers_svc.PLAN_FREE_NUMBERS.get(p["code"], 0)

    return {
        "unit_costs": unit_costs,
        "annual_discount_pct": annual_discount,
        "processing_fee_pct": fee_pct,
        "processing_fee_fixed": fee_fixed,
        "plans": plans,
        "numbers": numbers_economics,
        "actual": {"by_plan": actual, "totals": tot, "month_start": month_iso,
                   "note": "Live numbers from your database: subscriptions, metered usage this month, unit costs and card fees."},
        "free_cost_per_user": (free or {}).get("cost_at_full_usage", 0),
        "free_loses_money": bool((free or {}).get("loses_money")),
        "total_profit_list_prices": round(total_profit, 2),
    }
