"""Knowledge base: source ingestion, chunking, retrieval, contradiction detection.

Two distinct classes:
- STRUCTURED FACTS (authoritative): built live from services/hours/locations/policies.
  These are always authoritative — the LLM's price/hour answers must come from these.
- UNSTRUCTURED CONTENT: extracted text from published pages, FAQs, policies, uploads.
  Used for reference / context grounding. Every retrieved chunk carries a source id
  so answers can be cited and audited.

Design notes:
- Zero external vector DB. Score with token overlap + heading-boost — plenty for the
  small corpus a small business site produces, and dependency-light for on-prem.
- Ingestion is idempotent: a page ingested twice replaces its previous chunks.
"""
from __future__ import annotations

import io
import logging
import re
from typing import Any, Dict, List, Optional, Tuple


from ..db import get_db, utc_now_iso
from ..models_ai import KnowledgeSource, KnowledgeChunk

logger = logging.getLogger(__name__)


# ---------- Text helpers ----------

_STOP = {
    "the", "a", "an", "of", "and", "or", "to", "for", "in", "on", "at", "we", "our",
    "your", "you", "with", "is", "are", "be", "this", "that", "it", "its", "from",
    "by", "as", "will", "can", "any", "all", "have", "has", "had",
}
_WORD = re.compile(r"[A-Za-z0-9']+")


def _tokens(s: str) -> List[str]:
    return [t.lower() for t in _WORD.findall(s or "") if t.lower() not in _STOP]


def _chunk_text(text: str, max_chars: int = 700) -> List[str]:
    """Split into semantic-ish chunks: paragraphs, then sentence packs."""
    text = re.sub(r"\r\n?", "\n", text or "").strip()
    if not text:
        return []
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: List[str] = []
    for p in paras:
        if len(p) <= max_chars:
            chunks.append(p); continue
        # sentence pack
        sents = re.split(r"(?<=[.!?])\s+", p)
        buf = ""
        for s in sents:
            if len(buf) + len(s) + 1 <= max_chars:
                buf = (buf + " " + s).strip()
            else:
                if buf:
                    chunks.append(buf)
                buf = s
        if buf:
            chunks.append(buf)
    return chunks


def _extract_text_from_blocks(blocks: List[Dict[str, Any]]) -> str:
    """Extract renderable text from a page's block JSON."""
    parts: List[str] = []
    for b in blocks or []:
        if b.get("hidden"):
            continue
        p = b.get("props") or {}
        for k, v in p.items():
            if isinstance(v, str) and v.strip() and len(v) < 2000:
                parts.append(v.strip())
            elif isinstance(v, list):
                for x in v:
                    if isinstance(x, dict):
                        for kk, vv in x.items():
                            if isinstance(vv, str) and vv.strip():
                                parts.append(vv.strip())
                    elif isinstance(x, str) and x.strip():
                        parts.append(x.strip())
    return "\n\n".join(parts)


async def _extract_upload_text(filename: str, raw: bytes) -> Tuple[str, Optional[str]]:
    """Return (text, error). Supports .txt/.md/.csv natively; .pdf/.docx best-effort."""
    name = (filename or "").lower()
    try:
        if name.endswith((".txt", ".md", ".csv")):
            return raw.decode("utf-8", errors="replace"), None
        if name.endswith(".pdf"):
            try:
                from pypdf import PdfReader
                r = PdfReader(io.BytesIO(raw))
                return "\n\n".join((p.extract_text() or "") for p in r.pages), None
            except Exception as e:  # noqa: BLE001
                return "", f"PDF extraction failed: {e}"
        if name.endswith(".docx"):
            try:
                from docx import Document  # python-docx
                doc = Document(io.BytesIO(raw))
                return "\n\n".join(p.text for p in doc.paragraphs if p.text), None
            except Exception as e:  # noqa: BLE001
                return "", f"DOCX extraction failed: {e}"
    except Exception as e:  # noqa: BLE001
        return "", f"read failed: {e}"
    return "", f"Unsupported file type for {filename!r} (supported: txt, md, csv, pdf, docx)"


# ---------- Ingestion ----------

async def ingest_website_pages(org_id: str) -> int:
    """Ingest every published page of every website for the org. Idempotent per (slug, page)."""
    db = get_db()
    count = 0
    async for site in db.websites.find({"org_id": org_id, "status": "published"}):
        slug = site.get("slug") or ""
        for page in (site.get("published_pages") or site.get("pages") or []):
            title = f"{slug}/{page.get('slug') or 'home'}"
            body = _extract_text_from_blocks(page.get("blocks") or [])
            if not body:
                continue
            chunks = _chunk_text(body)
            existing = await db.knowledge_sources.find_one({"org_id": org_id, "kind": "website_page",
                                                                  "origin": title})
            data = KnowledgeSource(
                org_id=org_id, kind="website_page", title=title, origin=title,
                body_text=body,
                chunks=[KnowledgeChunk(id=f"c{i}", text=c) for i, c in enumerate(chunks)],
                ingested_at=utc_now_iso(), status="active",
                version=(existing.get("version", 0) + 1) if existing else 1,
                updated_at=utc_now_iso(),
            )
            if existing:
                await db.knowledge_sources.update_one({"_id": existing["_id"]},
                                                          {"$set": data.model_dump(exclude={"id"})})
            else:
                await db.knowledge_sources.insert_one(data.to_mongo())
            count += 1
    return count


async def refresh_structured_facts(org_id: str) -> str:
    """Rebuild the structured-facts source doc. Returns source_id."""
    db = get_db()
    services = []
    async for s in db.service_offerings.find({"org_id": org_id, "active": True}).sort("name", 1):
        services.append({
            "id": str(s["_id"]), "name": s.get("name"),
            "duration_minutes": s.get("duration_minutes"),
            "price_cents": s.get("price_cents"),
            "currency": s.get("currency", "USD"),
            "description": (s.get("description") or "")[:400],
            "bookable": bool(s.get("bookable", True)),
        })
    profile = await db.business_profiles.find_one({"org_id": org_id})
    profile = profile or {}
    facts = {
        "business_name": profile.get("business_name"),
        "industry": profile.get("industry"),
        "hours": profile.get("hours") or [],
        "locations": profile.get("locations") or [],
        "differentiators": profile.get("differentiators") or [],
        "policies": profile.get("policies") or {},
        "services": services,
    }
    existing = await db.knowledge_sources.find_one({"org_id": org_id, "kind": "structured_facts"})
    ver = (existing.get("version", 0) + 1) if existing else 1
    src = KnowledgeSource(
        org_id=org_id, kind="structured_facts",
        title="Verified business facts",
        origin="records",
        facts=facts,
        chunks=[], body_text=None,
        ingested_at=utc_now_iso(), status="active", version=ver,
        updated_at=utc_now_iso(),
    )
    if existing:
        await db.knowledge_sources.update_one({"_id": existing["_id"]},
                                                  {"$set": src.model_dump(exclude={"id"})})
        return str(existing["_id"])
    r = await db.knowledge_sources.insert_one(src.to_mongo())
    return str(r.inserted_id)


async def add_faq(org_id: str, title: str, body: str, created_by: Optional[str] = None) -> str:
    db = get_db()
    src = KnowledgeSource(
        org_id=org_id, kind="faq", title=title, origin=None,
        body_text=body,
        chunks=[KnowledgeChunk(id=f"c{i}", text=c) for i, c in enumerate(_chunk_text(body))],
        ingested_at=utc_now_iso(), status="active", version=1,
        created_by=created_by,
    )
    r = await db.knowledge_sources.insert_one(src.to_mongo())
    return str(r.inserted_id)


async def add_policy(org_id: str, title: str, body: str, created_by: Optional[str] = None) -> str:
    db = get_db()
    src = KnowledgeSource(
        org_id=org_id, kind="policy", title=title, origin=None,
        body_text=body,
        chunks=[KnowledgeChunk(id=f"c{i}", text=c) for i, c in enumerate(_chunk_text(body))],
        ingested_at=utc_now_iso(), status="active", version=1,
        created_by=created_by,
    )
    r = await db.knowledge_sources.insert_one(src.to_mongo())
    return str(r.inserted_id)


async def add_upload(org_id: str, filename: str, raw: bytes,
                        created_by: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    db = get_db()
    text, err = await _extract_upload_text(filename, raw)
    if err and not text:
        return None, err
    src = KnowledgeSource(
        org_id=org_id, kind="upload", title=filename, origin=filename,
        body_text=text,
        chunks=[KnowledgeChunk(id=f"c{i}", text=c) for i, c in enumerate(_chunk_text(text))],
        ingested_at=utc_now_iso(), status="active", version=1,
        created_by=created_by,
    )
    r = await db.knowledge_sources.insert_one(src.to_mongo())
    return str(r.inserted_id), None


# ---------- Contradiction detection ----------

_MONEY_RE = re.compile(r"\$\s?(\d{1,4}(?:\.\d{2})?)")


async def detect_contradictions(org_id: str) -> int:
    """Scan unstructured sources: if a `$XX` price mention appears that doesn't match
    any current catalog service_id's price, flag the source. Coarse but useful."""
    db = get_db()
    catalog: List[Tuple[str, float]] = []
    async for s in db.service_offerings.find({"org_id": org_id, "active": True}):
        catalog.append((s.get("name") or "", (s.get("price_cents") or 0) / 100.0))
    catalog_prices = {round(p, 2) for _, p in catalog if p}
    flagged = 0
    async for src in db.knowledge_sources.find({"org_id": org_id,
                                                  "kind": {"$in": ["faq", "policy", "upload", "website_page"]},
                                                  "status": "active"}):
        text = src.get("body_text") or ""
        prices_in_text = {round(float(m.group(1)), 2) for m in _MONEY_RE.finditer(text)}
        stale = prices_in_text - catalog_prices
        # Any dollar-price in the text that doesn't match a current catalog price → contradiction.
        if stale:
            note = f"Prices mentioned that don't match current catalog: {sorted(stale)[:5]}"
            if src.get("contradiction_flag") != note:
                await db.knowledge_sources.update_one({"_id": src["_id"]},
                                                          {"$set": {"contradiction_flag": note,
                                                                       "updated_at": utc_now_iso()}})
                flagged += 1
        elif src.get("contradiction_flag"):
            await db.knowledge_sources.update_one({"_id": src["_id"]},
                                                      {"$unset": {"contradiction_flag": ""},
                                                        "$set": {"updated_at": utc_now_iso()}})
    return flagged


# ---------- Retrieval ----------

def _score(query_tokens: List[str], text: str) -> float:
    if not query_tokens or not text:
        return 0.0
    text_tokens = _tokens(text)
    if not text_tokens:
        return 0.0
    text_set = set(text_tokens)
    hits = sum(1 for t in query_tokens if t in text_set)
    return hits / max(1, len(query_tokens))


async def build_retrieval_context(org_id: str, query: str,
                                       top_k: int = 5) -> Dict[str, Any]:
    """Retrieve top-K unstructured chunks + the org's structured facts. Tenant-scoped.

    Returns:
      {
        "structured": {business_name, industry, hours, locations, services[], policies},
        "chunks": [{source_id, source_title, kind, text, score}],
        "citations": [{source_id, kind, title}],
      }
    """
    db = get_db()
    q_tokens = _tokens(query)
    structured_doc = await db.knowledge_sources.find_one({"org_id": org_id,
                                                              "kind": "structured_facts",
                                                              "status": "active"})
    structured = (structured_doc or {}).get("facts") or {}
    hits: List[Dict[str, Any]] = []
    async for src in db.knowledge_sources.find({"org_id": org_id,
                                                  "kind": {"$in": ["website_page", "faq", "policy", "upload"]},
                                                  "status": "active"}):
        for ch in src.get("chunks") or []:
            score = _score(q_tokens, ch.get("text") or "")
            if score >= 0.15:
                hits.append({
                    "source_id": str(src["_id"]),
                    "source_title": src.get("title"),
                    "kind": src.get("kind"),
                    "text": ch.get("text"),
                    "score": score,
                })
    hits.sort(key=lambda x: x["score"], reverse=True)
    hits = hits[: max(1, top_k)]
    citations = [{"source_id": h["source_id"], "kind": h["kind"], "title": h["source_title"]}
                   for h in hits]
    if structured_doc:
        citations.insert(0, {"source_id": str(structured_doc["_id"]),
                                "kind": "structured_facts",
                                "title": "Verified business facts"})
    return {"structured": structured, "chunks": hits, "citations": citations}
