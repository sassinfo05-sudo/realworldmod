# Environment Variables

All env is read at process start. Never hardcode.

## Backend (`/app/backend/.env`)

| Var | Required | Example | Notes |
|---|---|---|---|
| `MONGO_URL` | yes | `mongodb://localhost:27017` | Motor async client |
| `DB_NAME` | yes | `test_database` | Never change on a live tenant |
| `JWT_SECRET` | yes | 64+ char random | Rotating invalidates all sessions |
| `EMERGENT_LLM_KEY` | yes for AI features | `sk-emergent-…` | Used by `services/llm.py`; also OpenAI whisper / Sora / gemini nano banana / claude sonnet |
| `STRIPE_SECRET_KEY` | optional | `sk_test_…` | If unset, Stripe adapter is `not_connected`; simulated works E2E |
| `RETELL_API_KEY` | optional | | Voice; call simulator works without |
| `TWILIO_ACCOUNT_SID` | optional | | Alternative voice adapter |
| `RESEND_API_KEY` | optional (per-tenant) | | Email; each org configures its own via Setup |
| `REVENUE_OS_SKIP_QUIET_HOURS` | optional | `1` | Bypass quiet-hours guard in tests only |

## Frontend (`/app/frontend/.env`)

| Var | Required | Example | Notes |
|---|---|---|---|
| `REACT_APP_BACKEND_URL` | yes | preview URL from platform | All API calls use this |
| `WDS_SOCKET_PORT` | | `443` | dev-server hot reload |
| `ENABLE_HEALTH_CHECK` | | `false` | |

## Protected values (never rewrite)

- `MONGO_URL`, `DB_NAME`, `REACT_APP_BACKEND_URL` are set by the platform. Add new vars; don't overwrite these.

| `SECRETS_ENC_KEY` | no | urlsafe-base64 32-byte Fernet key | Encrypts integration secrets at rest; defaults to a key derived from JWT_SECRET |
| `SEED_DEMO_DATA` | no | `true` | Force demo seeding outside dev/test/demo |
| _(removed)_ `FOUNDER_INITIAL_PASSWORD` | — | — | Removed in Round 15. Founder is created by the explicit one-time command `python -m scripts.bootstrap_founder` (invite-link based, no plaintext password). |
| `MAX_JSON_BYTES` / `MAX_REQUEST_BYTES` | no | bytes | Request body limits (defaults 2 MB / 25 MB) |
| `API_GLOBAL_RPM` | no | int | Soft per-IP API rate limit per minute (default 900) |

## Optional dependency: emergentintegrations (Round 18)
`emergentintegrations` (the Emergent LLM client) is **not on PyPI** — it ships only from the public,
un-credentialed Emergent CDN wheel index. It is therefore an **optional runtime dependency**, isolated
behind `app/services/llm.py` via a lazy import and listed in `backend/requirements-emergent.txt` (NOT in
`requirements.txt`). This keeps `pip install -r requirements.txt` reproducible from public PyPI in CI,
Docker and any clean checkout. Install it only in the runtime that makes live LLM calls:

    pip install -r requirements-emergent.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/

No secret/token is committed or required for that index. If the package is absent, the app boots and all
non-LLM features work; an LLM call raises a clear `LlmError` explaining how to install it.
