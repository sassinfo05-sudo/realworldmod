"""INTERNAL competitor comparison — staff panel only.

Customer-facing pages must never show competitor names or comparison tables (see memory/
BRAND_SCREEN.md). This matrix exists for positioning, roadmap and sales enablement and is
kept honest: each Zanelvo cell reflects what a test has actually proven in this codebase.
"""
from __future__ import annotations

from typing import Any, Dict, List

from fastapi import APIRouter, Depends

from ..deps import require_staff
from ..models import User

router = APIRouter(prefix="/api/staff/competitive", tags=["staff-competitive"])

COMPETITORS = ["Zanelvo", "Wix", "Shopify", "Squarespace", "Webflow", "GoDaddy Airo"]

# status values: live | partial | sandbox | planned | no | n/a
MATRIX: List[Dict[str, Any]] = [
    {"area": "Website", "capability": "AI site generation from a short interview",
     "Zanelvo": "live", "Wix": "live", "Shopify": "partial", "Squarespace": "live", "Webflow": "partial", "GoDaddy Airo": "live",
     "note": "Zanelvo: structured block JSON, industry-specific layouts, facts never invented (FactReview gate)."},
    {"area": "Website", "capability": "Visual click-to-edit editor with drafts, revisions, rollback",
     "Zanelvo": "partial", "Wix": "live", "Shopify": "live", "Squarespace": "live", "Webflow": "live", "GoDaddy Airo": "partial",
     "note": "Zanelvo has block editor + publish/rollback; drag-reorder/inline-edit overhaul still on the roadmap."},
    {"area": "Website", "capability": "Custom domain with DNS verification + SSL states",
     "Zanelvo": "partial", "Wix": "live", "Shopify": "live", "Squarespace": "live", "Webflow": "live", "GoDaddy Airo": "live",
     "note": "Zanelvo: DNS records + verification polling shipped; provider adapter for automated SSL is replaceable/simulated."},
    {"area": "Website", "capability": "Multilingual + RTL (Hebrew) content",
     "Zanelvo": "partial", "Wix": "live", "Shopify": "live", "Squarespace": "partial", "Webflow": "live", "GoDaddy Airo": "no",
     "note": "LLM translation API + cache live; storefront language switcher UI pending."},
    {"area": "Commerce", "capability": "Products, variants, collections, discounts, inventory",
     "Zanelvo": "live", "Wix": "live", "Shopify": "live", "Squarespace": "live", "Webflow": "partial", "GoDaddy Airo": "partial"},
    {"area": "Commerce", "capability": "Shipping zones, rates, tracking, packing slips",
     "Zanelvo": "live", "Wix": "live", "Shopify": "live", "Squarespace": "live", "Webflow": "partial", "GoDaddy Airo": "partial",
     "note": "Live carrier rates/labels need a Shippo/EasyPost key (adapter listed, not connected)."},
    {"area": "Commerce", "capability": "Payments (Stripe/PayPal) with signed, idempotent webhooks",
     "Zanelvo": "sandbox", "Wix": "live", "Shopify": "live", "Squarespace": "live", "Webflow": "live", "GoDaddy Airo": "live",
     "note": "Code path verified; goes live the moment keys are entered in Staff Setup Center."},
    {"area": "Commerce", "capability": "Abandoned-checkout recovery",
     "Zanelvo": "live", "Wix": "live", "Shopify": "live", "Squarespace": "live", "Webflow": "no", "GoDaddy Airo": "partial"},
    {"area": "Bookings & CRM", "capability": "Bookings, quotes, invoices, jobs in one place",
     "Zanelvo": "live", "Wix": "partial", "Shopify": "no", "Squarespace": "partial", "Webflow": "no", "GoDaddy Airo": "no"},
    {"area": "Bookings & CRM", "capability": "CRM with lead scoring + unified inbox",
     "Zanelvo": "live", "Wix": "partial", "Shopify": "partial", "Squarespace": "no", "Webflow": "no", "GoDaddy Airo": "no"},
    {"area": "AI", "capability": "AI receptionist / chat agent grounded in the tenant's own knowledge",
     "Zanelvo": "live", "Wix": "partial", "Shopify": "partial", "Squarespace": "no", "Webflow": "no", "GoDaddy Airo": "partial"},
    {"area": "AI", "capability": "AI voice receptionist + managed phone numbers",
     "Zanelvo": "sandbox", "Wix": "no", "Shopify": "no", "Squarespace": "no", "Webflow": "no", "GoDaddy Airo": "no",
     "note": "Telnyx/Twilio adapters built; simulated until a carrier key is connected."},
    {"area": "AI", "capability": "Human takeover of AI conversations",
     "Zanelvo": "live", "Wix": "partial", "Shopify": "partial", "Squarespace": "no", "Webflow": "no", "GoDaddy Airo": "no"},
    {"area": "AI", "capability": "AI logo generation (SVG + image)",
     "Zanelvo": "live", "Wix": "live", "Shopify": "partial", "Squarespace": "no", "Webflow": "no", "GoDaddy Airo": "live"},
    {"area": "Marketing", "capability": "Email campaigns with opens/clicks/A-B + revenue attribution",
     "Zanelvo": "live", "Wix": "live", "Shopify": "live", "Squarespace": "live", "Webflow": "no", "GoDaddy Airo": "partial",
     "note": "Sending is metered; real delivery needs Resend/SendGrid/SMTP in Staff Setup Center."},
    {"area": "Marketing", "capability": "Visual multi-step automation workflows",
     "Zanelvo": "partial", "Wix": "live", "Shopify": "live", "Squarespace": "partial", "Webflow": "no", "GoDaddy Airo": "no",
     "note": "Rule-based automations exist; branching visual builder is on the roadmap."},
    {"area": "Marketing", "capability": "Ads creative studio + campaign export",
     "Zanelvo": "partial", "Wix": "partial", "Shopify": "partial", "Squarespace": "no", "Webflow": "no", "GoDaddy Airo": "partial"},
    {"area": "Platform", "capability": "Per-tenant AI cost metering with plan budgets + founder kill switches",
     "Zanelvo": "live", "Wix": "n/a", "Shopify": "n/a", "Squarespace": "n/a", "Webflow": "n/a", "GoDaddy Airo": "n/a",
     "note": "Unique to Zanelvo as a platform operator: reservations, reconciliation, ledger export, gross-margin view."},
    {"area": "Platform", "capability": "Staff panel with roles, impersonation audit, fraud view",
     "Zanelvo": "live", "Wix": "n/a", "Shopify": "n/a", "Squarespace": "n/a", "Webflow": "n/a", "GoDaddy Airo": "n/a"},
    {"area": "Platform", "capability": "Public API keys, outbound webhooks (signed) and inbound webhooks",
     "Zanelvo": "live", "Wix": "live", "Shopify": "live", "Squarespace": "partial", "Webflow": "live", "GoDaddy Airo": "no"},
    {"area": "Pricing", "capability": "Entry paid plan (USD / month, public list price)",
     "Zanelvo": "from DB (Plans & P&L)", "Wix": "$17", "Shopify": "$39", "Squarespace": "$16", "Webflow": "$14", "GoDaddy Airo": "$10",
     "note": "Competitor prices are public list prices at time of research; refresh before quoting."},
]

POSITIONING = {
    "one_liner": "Zanelvo is the only builder that combines an AI-generated website, bookings/quotes/invoices, "
                 "commerce + shipping, an AI receptionist (chat + voice) and marketing attribution in one metered, "
                 "margin-aware platform for small service businesses and shops.",
    "where_we_win": [
        "Service businesses: bookings + quotes + invoices + jobs are native, not an app-store add-on.",
        "AI employees (chat/voice receptionist) with honest human takeover and per-tenant cost caps.",
        "Founder economics: every AI call, email and message is metered against plan budgets with kill switches.",
        "Truthful integration states (Connected / Sandbox / Not connected) instead of fake success.",
    ],
    "where_we_lag": [
        "Editor depth: drag-reorder, inline editing and template library are still shallower than Wix/Webflow.",
        "Commerce long tail: subscriptions, gift cards, bundles, returns flows are partial vs Shopify.",
        "Automation: no branching visual workflow builder yet.",
        "Live carriers/payments/voice run in sandbox until provider keys are connected.",
    ],
    "rules": [
        "Never publish competitor names or comparison tables on customer-facing pages.",
        "Never quote a competitor price externally without re-checking it the same day.",
        "Mark a Zanelvo cell 'live' only when a passing test exists for it.",
    ],
}


@router.get("")
async def competitive_matrix(_: User = Depends(require_staff("metrics", "pricing", "audit"))):
    """Internal-only competitive matrix + positioning notes."""
    live = sum(1 for r in MATRIX if r.get("Zanelvo") == "live")
    partial = sum(1 for r in MATRIX if r.get("Zanelvo") in ("partial", "sandbox"))
    return {"competitors": COMPETITORS, "rows": MATRIX, "positioning": POSITIONING,
            "summary": {"live": live, "partial_or_sandbox": partial, "total": len(MATRIX)},
            "internal_only": True}
