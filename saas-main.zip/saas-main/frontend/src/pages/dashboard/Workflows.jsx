import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ReactFlow, Background, Controls, MiniMap, addEdge, applyNodeChanges, applyEdgeChanges, Handle, Position, MarkerType } from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { Plus, Play, Rocket, Pause, Trash2, ArrowLeft, CheckCircle2, AlertTriangle, ListChecks, Loader2, Workflow as WorkflowIcon, ShieldCheck } from "lucide-react";

const STATUS_STYLE = { published: "bg-emerald-100 text-emerald-800", draft: "bg-zinc-100 text-zinc-700", draft_changes: "bg-amber-100 text-amber-800", paused: "bg-rose-100 text-rose-700" };
const RUN_STYLE = { completed: "bg-emerald-100 text-emerald-800", running: "bg-blue-100 text-blue-800", waiting: "bg-amber-100 text-amber-800", awaiting_approval: "bg-violet-100 text-violet-800", dead_letter: "bg-rose-100 text-rose-800", failed: "bg-rose-100 text-rose-800", cancelled: "bg-zinc-100 text-zinc-600" };
const NODE_COLORS = { trigger: "#4F46E5", condition: "#D97706", ab_split: "#0D9488", delay: "#0891B2", wait_until: "#0891B2", send_email: "#DB2777", add_tag: "#059669", remove_tag: "#059669", create_task: "#7C3AED", notify_owner: "#7C3AED", webhook: "#475569", ai_generate: "#C026D3", approval: "#EA580C", end: "#18181B" };

/** Custom node: coloured header + one-line summary. Conditions expose "yes"/"no" source handles. */
function StepNode({ data, selected }) {
    const color = NODE_COLORS[data.type] || "#333";
    return (
        <div className={`rounded-xl bg-white shadow-sm border-2 min-w-[190px] max-w-[240px] text-xs ${selected ? "border-brand-copper" : "border-zinc-200"}`} data-testid={`wf-node-${data.type}`}>
            {data.type !== "trigger" && <Handle type="target" position={Position.Top} className="!bg-zinc-400" />}
            <div className="px-3 py-1.5 rounded-t-[10px] text-white font-medium flex items-center justify-between" style={{ background: color }}>
                <span>{data.label}</span>
            </div>
            <div className="px-3 py-2 text-zinc-600 truncate">{data.summary || "Click to configure"}</div>
            {data.type === "condition" ? (
                <>
                    <Handle type="source" id="yes" position={Position.Bottom} style={{ left: "30%" }} className="!bg-emerald-500" />
                    <Handle type="source" id="no" position={Position.Bottom} style={{ left: "70%" }} className="!bg-rose-500" />
                    <div className="flex justify-between px-4 pb-1 text-[10px]"><span className="text-emerald-600">yes</span><span className="text-rose-600">no</span></div>
                </>
            ) : data.type === "ab_split" ? (
                <>
                    <Handle type="source" id="a" position={Position.Bottom} style={{ left: "30%" }} className="!bg-teal-500" />
                    <Handle type="source" id="b" position={Position.Bottom} style={{ left: "70%" }} className="!bg-sky-500" />
                    <div className="flex justify-between px-4 pb-1 text-[10px]"><span className="text-teal-600">A</span><span className="text-sky-600">B</span></div>
                </>
            ) : data.type !== "end" ? <Handle type="source" position={Position.Bottom} className="!bg-zinc-400" /> : null}
        </div>
    );
}
const nodeTypes = { step: StepNode };

function summarize(n) {
    const c = n.config || {};
    switch (n.type) {
        case "condition": return `${c.field || "?"} ${c.op || ""} ${c.value ?? ""}`;
        case "ab_split": return `${c.percent_a ?? 50}% → A · ${100 - (c.percent_a ?? 50)}% → B${c.sticky === false ? " (random)" : ""}`;
        case "delay": return `Wait ${c.amount ?? 1} ${c.unit || "hours"}`;
        case "wait_until": return `Until ${c.hour ?? 9}:00`;
        case "send_email": return c.subject || "(no subject)";
        case "add_tag": case "remove_tag": return c.tag || "(tag)";
        case "create_task": return c.title || "Follow up";
        case "notify_owner": return c.message || "Notify";
        case "webhook": return c.url || "(url)";
        case "ai_generate": return c.prompt ? c.prompt.slice(0, 40) : "(prompt)";
        case "approval": return c.note || "Needs your approval";
        default: return "";
    }
}

const toFlowNodes = (graph, labels) => (graph.nodes || []).map((n, i) => ({
    id: n.id, type: "step", position: n.position || { x: 0, y: i * 120 }, data: { type: n.type, label: labels[n.type] || n.type, summary: summarize(n), config: n.config || {} },
}));
const toFlowEdges = (graph) => (graph.edges || []).map((e, i) => ({
    id: `e${i}-${e.from}-${e.to}`, source: e.from, target: e.to, sourceHandle: e.when || null, label: e.when || undefined, markerEnd: { type: MarkerType.ArrowClosed },
    style: { stroke: e.when === "no" ? "#e11d48" : e.when === "yes" ? "#059669" : "#71717a" },
}));
const fromFlow = (nodes, edges) => ({
    nodes: nodes.map((n) => ({ id: n.id, type: n.data.type, config: n.data.config || {}, position: n.position })),
    edges: edges.map((e) => ({ from: e.source, to: e.target, ...(e.sourceHandle ? { when: e.sourceHandle } : {}) })),
});

export default function Workflows() {
    const [catalog, setCatalog] = useState(null);
    const [list, setList] = useState([]);
    const [approvals, setApprovals] = useState([]);
    const [current, setCurrent] = useState(null);
    const [loading, setLoading] = useState(true);

    const load = useCallback(async () => {
        try {
            const [{ data: cat }, { data: wl }, { data: ap }] = await Promise.all([api.get("/workflows/catalog"), api.get("/workflows"), api.get("/workflows/runs/pending-approvals")]);
            setCatalog(cat); setList(wl.workflows || []); setApprovals(ap.runs || []);
        } catch { toast.error("Could not load workflows"); } finally { setLoading(false); }
    }, []);
    useEffect(() => { load(); }, [load]);

    const createBlank = async () => {
        try { const { data } = await api.post("/workflows", { name: "New workflow", trigger: "form_submitted" }); setCurrent(data); load(); }
        catch { toast.error("Could not create workflow"); }
    };
    const fromTemplate = async (key) => {
        try { const { data } = await api.post(`/workflows/from-template/${key}`); toast.success("Template added as a draft"); setCurrent(data); load(); }
        catch { toast.error("Could not add template"); }
    };
    const approve = async (id, ok) => {
        try { await api.post(`/workflows/runs/${id}/${ok ? "approve" : "reject"}`); toast.success(ok ? "Approved — run continued" : "Rejected"); load(); }
        catch { toast.error("Action failed"); }
    };

    if (current && catalog) return <Builder wf={current} catalog={catalog} onBack={() => { setCurrent(null); load(); }} />;

    return (
        <div className="p-6 md:p-8" data-testid="workflows-page">
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Grow</div>
                    <h1 className="font-display text-2xl md:text-3xl text-brand-ink font-medium flex items-center gap-2"><WorkflowIcon className="w-6 h-6" /> Workflows</h1>
                    <p className="mt-1 text-sm text-zinc-500">Visual automations: a trigger, branches, waits, emails, tags, tasks, AI steps and approval gates. Test-mode runs never send anything.</p>
                </div>
                <Button onClick={createBlank} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="wf-new"><Plus className="w-4 h-4 mr-1.5" /> New workflow</Button>
            </div>

            {approvals.length > 0 && (
                <div className="mt-6 rounded-2xl border border-violet-200 bg-violet-50 p-4" data-testid="wf-approvals">
                    <div className="text-sm font-medium text-violet-900 flex items-center gap-2"><ShieldCheck className="w-4 h-4" /> {approvals.length} run{approvals.length > 1 ? "s" : ""} waiting for your approval</div>
                    <div className="mt-2 space-y-2">
                        {approvals.map((r) => (
                            <div key={r.id} className="flex items-center justify-between gap-3 bg-white rounded-lg px-3 py-2 text-sm">
                                <div className="truncate"><span className="font-medium">{r.context?.contact?.name || r.context?.email || "Run"}</span> <span className="text-zinc-500">· {r.trigger} · {new Date(r.updated_at).toLocaleString()}</span>{r.context?.ai_text && <div className="text-xs text-zinc-600 mt-1 line-clamp-2">{r.context.ai_text}</div>}</div>
                                <div className="flex gap-2 shrink-0"><Button size="sm" variant="outline" onClick={() => approve(r.id, false)}>Reject</Button><Button size="sm" className="bg-violet-600 hover:bg-violet-700 text-white" onClick={() => approve(r.id, true)} data-testid={`wf-approve-${r.id}`}>Approve & send</Button></div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            <div className="mt-6 grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    {loading ? <div className="text-sm text-zinc-500 flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Loading…</div> : list.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-brand-line p-10 text-center" data-testid="wf-empty">
                            <WorkflowIcon className="w-8 h-8 mx-auto text-zinc-400" />
                            <div className="mt-3 font-medium text-brand-ink">No workflows yet</div>
                            <p className="text-sm text-zinc-500 mt-1">Start from a template on the right, or build one from scratch.</p>
                        </div>
                    ) : (
                        <div className="rounded-2xl border border-brand-line bg-white divide-y divide-brand-line" data-testid="wf-list">
                            {list.map((w) => (
                                <button key={w.id} type="button" onClick={() => setCurrent(w)} className="w-full text-left p-4 flex items-center gap-4 hover:bg-zinc-50" data-testid={`wf-row-${w.id}`}>
                                    <div className="flex-1 min-w-0">
                                        <div className="font-medium text-brand-ink truncate">{w.name}</div>
                                        <div className="text-xs text-zinc-500 mt-0.5">Trigger: {w.trigger} · v{w.version} · {w.graph?.nodes?.length || 0} steps · {w.stats?.runs || 0} runs{w.stats?.dead_letter ? ` · ${w.stats.dead_letter} dead-letter` : ""}</div>
                                    </div>
                                    <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] ${STATUS_STYLE[w.status] || "bg-zinc-100"}`}>{w.status.replace("_", " ")}</span>
                                </button>
                            ))}
                        </div>
                    )}
                </div>
                <div>
                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Templates</div>
                    <div className="space-y-3">
                        {(catalog?.templates || []).map((t) => (
                            <div key={t.key} className="rounded-2xl border border-brand-line bg-white p-4" data-testid={`wf-template-${t.key}`}>
                                <div className="font-medium text-brand-ink text-sm">{t.name}</div>
                                <p className="text-xs text-zinc-500 mt-1">{t.description}</p>
                                <Button size="sm" variant="outline" className="mt-3 border-brand-line" onClick={() => fromTemplate(t.key)} data-testid={`wf-use-${t.key}`}>Use template</Button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

function Builder({ wf: initial, catalog, onBack }) {
    const labels = useMemo(() => Object.fromEntries(catalog.node_types.map((n) => [n.type, n.label])), [catalog]);
    const [wf, setWf] = useState(initial);
    const [nodes, setNodes] = useState(() => toFlowNodes(initial.graph || {}, labels));
    const [edges, setEdges] = useState(() => toFlowEdges(initial.graph || {}));
    const [selectedId, setSelectedId] = useState(null);
    const [dirty, setDirty] = useState(false);
    const [busy, setBusy] = useState(false);
    const [runs, setRuns] = useState(null);
    const [lastTest, setLastTest] = useState(null);
    const [errors, setErrors] = useState([]);

    const selected = nodes.find((n) => n.id === selectedId);

    const onNodesChange = useCallback((ch) => { setNodes((ns) => applyNodeChanges(ch, ns)); if (ch.some((c) => c.type === "position" || c.type === "remove")) setDirty(true); }, []);
    const onEdgesChange = useCallback((ch) => { setEdges((es) => applyEdgeChanges(ch, es)); setDirty(true); }, []);
    const onConnect = useCallback((params) => {
        setEdges((es) => {
            // one outgoing edge per handle
            const cleaned = es.filter((e) => !(e.source === params.source && (e.sourceHandle || null) === (params.sourceHandle || null)));
            return addEdge({ ...params, label: params.sourceHandle || undefined, markerEnd: { type: MarkerType.ArrowClosed },
                style: { stroke: params.sourceHandle === "no" ? "#e11d48" : params.sourceHandle === "yes" ? "#059669" : params.sourceHandle === "a" ? "#0D9488" : params.sourceHandle === "b" ? "#0284C7" : "#71717a" } }, cleaned);
        });
        setDirty(true);
    }, []);

    const addNode = (type) => {
        const def = catalog.node_types.find((n) => n.type === type);
        const id = `${type}_${Math.random().toString(36).slice(2, 7)}`;
        const maxY = nodes.reduce((m, n) => Math.max(m, n.position.y), -120);
        setNodes((ns) => [...ns, { id, type: "step", position: { x: 40, y: maxY + 130 }, data: { type, label: def?.label || type, config: { ...(def?.config || {}) }, summary: "" } }]);
        setSelectedId(id); setDirty(true);
    };
    const updateConfig = (k, v) => {
        setNodes((ns) => ns.map((n) => n.id === selectedId ? { ...n, data: { ...n.data, config: { ...n.data.config, [k]: v }, summary: summarize({ type: n.data.type, config: { ...n.data.config, [k]: v } }) } } : n));
        setDirty(true);
    };
    const removeSelected = () => { if (!selected || selected.data.type === "trigger") return; setNodes((ns) => ns.filter((n) => n.id !== selectedId)); setEdges((es) => es.filter((e) => e.source !== selectedId && e.target !== selectedId)); setSelectedId(null); setDirty(true); };

    const save = async (silent) => {
        setBusy(true);
        try {
            const { data } = await api.patch(`/workflows/${wf.id}`, { name: wf.name, trigger: wf.trigger, description: wf.description || "", settings: wf.settings || {}, graph: fromFlow(nodes, edges) });
            setWf(data); setDirty(false);
            if (!silent) toast.success("Saved");
            return data;
        } catch (e) { toast.error(e?.response?.data?.detail?.message || "Could not save"); throw e; } finally { setBusy(false); }
    };
    const validate = async () => { await save(true); const { data } = await api.post(`/workflows/${wf.id}/validate`); setErrors(data.errors || []); if (data.ok) toast.success("Workflow is valid"); else toast.error(`${data.errors.length} issue(s)`); };
    const testRun = async () => {
        try { await save(true); const { data } = await api.post(`/workflows/${wf.id}/test-run`, { context: {} }); setLastTest(data); setErrors([]); toast.success("Test run finished — nothing was sent"); }
        catch (e) { const d = e?.response?.data?.detail; setErrors(d?.errors || []); toast.error(d?.error === "invalid_graph" ? "Fix the graph first" : "Test run failed"); }
    };
    const publish = async () => {
        try { await save(true); const { data } = await api.post(`/workflows/${wf.id}/publish`); setWf(data); setErrors([]); toast.success(`Published v${data.version}`); }
        catch (e) { const d = e?.response?.data?.detail; setErrors(d?.errors || []); toast.error(d?.error === "invalid_graph" ? "Fix the graph first" : "Publish failed"); }
    };
    const pause = async () => { const { data } = await api.post(`/workflows/${wf.id}/pause`); setWf(data); toast.success("Paused"); };
    const [abStats, setAbStats] = useState([]);
    const loadRuns = async () => {
        const { data } = await api.get(`/workflows/${wf.id}/runs`); setRuns(data.runs || []);
        try { const { data: ab } = await api.get(`/workflows/${wf.id}/ab-stats`); setAbStats(ab.nodes || []); } catch { setAbStats([]); }
    };
    const retry = async (id) => { try { await api.post(`/workflows/runs/${id}/retry`); toast.success("Replayed"); loadRuns(); } catch { toast.error("Retry failed"); } };
    const del = async () => { if (!window.confirm("Delete this workflow?")) return; await api.delete(`/workflows/${wf.id}`); onBack(); };

    return (
        <div className="h-[calc(100vh-4rem)] flex flex-col" data-testid="wf-builder">
            <div className="px-4 py-2 border-b border-brand-line bg-white flex items-center gap-3 flex-wrap">
                <Button variant="ghost" size="sm" onClick={onBack} data-testid="wf-back"><ArrowLeft className="w-4 h-4 mr-1" /> Workflows</Button>
                <Input value={wf.name} onChange={(e) => { setWf({ ...wf, name: e.target.value }); setDirty(true); }} className="w-56 h-8" data-testid="wf-name" />
                <Select value={wf.trigger} onValueChange={(v) => { setWf({ ...wf, trigger: v }); setDirty(true); }}>
                    <SelectTrigger className="w-60 h-8 text-xs" data-testid="wf-trigger"><SelectValue /></SelectTrigger>
                    <SelectContent>{catalog.triggers.map((t) => <SelectItem key={t.key} value={t.key}>{t.group} · {t.label}</SelectItem>)}</SelectContent>
                </Select>
                <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] ${STATUS_STYLE[wf.status] || ""}`}>{wf.status.replace("_", " ")} · v{wf.version}</span>
                <div className="ml-auto flex items-center gap-2">
                    {dirty && <span className="text-xs text-amber-600">Unsaved</span>}
                    <Button size="sm" variant="outline" className="border-brand-line" disabled={busy} onClick={() => save(false)} data-testid="wf-save">Save</Button>
                    <Button size="sm" variant="outline" className="border-brand-line" onClick={validate} data-testid="wf-validate"><ListChecks className="w-3.5 h-3.5 mr-1" /> Validate</Button>
                    <Button size="sm" variant="outline" className="border-brand-line" onClick={testRun} data-testid="wf-test"><Play className="w-3.5 h-3.5 mr-1" /> Test run</Button>
                    {wf.status === "published" ? <Button size="sm" variant="outline" className="border-brand-line" onClick={pause} data-testid="wf-pause"><Pause className="w-3.5 h-3.5 mr-1" /> Pause</Button>
                        : <Button size="sm" className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={publish} data-testid="wf-publish"><Rocket className="w-3.5 h-3.5 mr-1" /> Publish</Button>}
                    <Button size="sm" variant="ghost" className="text-rose-600" onClick={del} data-testid="wf-delete"><Trash2 className="w-3.5 h-3.5" /></Button>
                </div>
            </div>
            {errors.length > 0 && <div className="px-4 py-2 bg-rose-50 text-rose-700 text-xs flex items-center gap-2" data-testid="wf-errors"><AlertTriangle className="w-3.5 h-3.5" /> {errors.join(" · ")}</div>}
            <div className="flex-1 flex min-h-0">
                <div className="w-44 border-r border-brand-line bg-white p-2 overflow-y-auto">
                    <div className="text-[10px] uppercase tracking-widest text-zinc-500 px-1 mb-1">Add step</div>
                    {catalog.node_types.filter((n) => n.type !== "trigger").map((n) => (
                        <button key={n.type} type="button" onClick={() => addNode(n.type)} className="w-full text-left text-xs px-2 py-1.5 rounded-md hover:bg-zinc-100 flex items-center gap-2" data-testid={`wf-add-${n.type}`}>
                            <span className="w-2.5 h-2.5 rounded-sm" style={{ background: NODE_COLORS[n.type] }} /> {n.label}
                        </button>
                    ))}
                    <div className="text-[10px] uppercase tracking-widest text-zinc-500 px-1 mt-4 mb-1">Limits</div>
                    <div className="px-1 space-y-2">
                        <div><Label className="text-[10px]">AI cost cap / month ($)</Label><Input type="number" step="0.5" min="0" className="h-7 text-xs" value={wf.settings?.cost_cap_usd ?? ""} onChange={(e) => { setWf({ ...wf, settings: { ...(wf.settings || {}), cost_cap_usd: e.target.value === "" ? null : parseFloat(e.target.value) } }); setDirty(true); }} /></div>
                        <div><Label className="text-[10px]">Max runs / day</Label><Input type="number" min="0" className="h-7 text-xs" value={wf.settings?.max_runs_per_day ?? ""} onChange={(e) => { setWf({ ...wf, settings: { ...(wf.settings || {}), max_runs_per_day: e.target.value === "" ? null : parseInt(e.target.value, 10) } }); setDirty(true); }} /></div>
                    </div>
                    <Button size="sm" variant="outline" className="mt-4 w-full border-brand-line text-xs" onClick={loadRuns} data-testid="wf-runs">Run history</Button>
                </div>
                <div className="flex-1 min-w-0 bg-zinc-50" data-testid="wf-canvas">
                    <ReactFlow nodes={nodes} edges={edges} nodeTypes={nodeTypes} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} onConnect={onConnect}
                        onNodeClick={(_, n) => setSelectedId(n.id)} onPaneClick={() => setSelectedId(null)} fitView proOptions={{ hideAttribution: true }}>
                        <Background gap={16} />
                        <Controls />
                        <MiniMap pannable zoomable className="!bg-white" />
                    </ReactFlow>
                </div>
                <div className="w-80 border-l border-brand-line bg-white p-3 overflow-y-auto text-sm" data-testid="wf-inspector">
                    {runs ? (
                        <RunsPanel runs={runs} onClose={() => setRuns(null)} onRetry={retry} abStats={abStats} />
                    ) : lastTest ? (
                        <div>
                            <div className="flex items-center justify-between"><div className="font-medium flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-emerald-600" /> Test run</div><Button size="sm" variant="ghost" onClick={() => setLastTest(null)}>Close</Button></div>
                            <div className="text-xs text-zinc-500 mt-1">Status: {lastTest.status}. Nothing was sent or changed.</div>
                            <ol className="mt-3 space-y-1.5 text-xs">{(lastTest.steps || []).map((s, i) => <li key={i} className="rounded bg-zinc-50 px-2 py-1.5"><span className="font-medium">{labels[s.type] || s.type}</span> <span className="text-zinc-500">{JSON.stringify(s.result || s.error || {})}</span></li>)}</ol>
                        </div>
                    ) : selected ? (
                        <NodeInspector node={selected} labels={labels} update={updateConfig} remove={removeSelected} />
                    ) : (
                        <div className="text-zinc-500 text-xs space-y-2">
                            <p className="font-medium text-brand-ink text-sm">How it works</p>
                            <p>Add steps from the left, then drag from the bottom handle of one step to the top of the next. Conditions have green “yes” and red “no” handles.</p>
                            <p>Use <span className="font-mono">{"{{contact.name}}"}</span>, <span className="font-mono">{"{{contact.email}}"}</span>, <span className="font-mono">{"{{ai_text}}"}</span> in text fields.</p>
                            <p>Emails go through your connected sender (or are simulated and labelled). AI steps are metered and capped per workflow.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

function NodeInspector({ node, labels, update, remove }) {
    const t = node.data.type; const c = node.data.config || {};
    const F = ({ label, children }) => <div className="mt-2"><Label className="text-[10px] uppercase tracking-widest text-zinc-500">{label}</Label><div className="mt-1">{children}</div></div>;
    return (
        <div data-testid="wf-node-inspector">
            <div className="flex items-center justify-between"><div className="font-medium">{labels[t] || t}</div>{t !== "trigger" && <Button size="sm" variant="ghost" className="text-rose-600" onClick={remove} data-testid="wf-node-delete"><Trash2 className="w-3.5 h-3.5" /></Button>}</div>
            {t === "trigger" && <p className="text-xs text-zinc-500 mt-1">The trigger is chosen in the top bar. Connect this node to your first step.</p>}
            {t === "condition" && <>
                <F label="Field"><Input value={c.field || ""} onChange={(e) => update("field", e.target.value)} placeholder="contact.tags · contact.email · total_cents" /></F>
                <F label="Operator"><Select value={c.op || "contains"} onValueChange={(v) => update("op", v)}><SelectTrigger className="h-8"><SelectValue /></SelectTrigger><SelectContent>{["exists", "contains", "equals", "not_equals", "gt", "gte", "lt", "lte"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select></F>
                <F label="Value"><Input value={c.value ?? ""} onChange={(e) => update("value", e.target.value)} /></F>
            </>}
            {t === "ab_split" && <>
                <F label={`Share sent down branch A: ${c.percent_a ?? 50}%`}><input type="range" min="0" max="100" step="5" value={c.percent_a ?? 50} onChange={(e) => update("percent_a", parseInt(e.target.value, 10))} className="w-full accent-teal-600" data-testid="wf-ab-percent" /></F>
                <label className="mt-2 flex items-center gap-2 text-xs text-zinc-600"><input type="checkbox" checked={c.sticky !== false} onChange={(e) => update("sticky", e.target.checked)} /> Sticky per contact (same contact always gets the same variant)</label>
                <p className="text-[11px] text-zinc-500 mt-2">Connect the A and B handles to different steps (e.g. two subject lines). Counts per variant appear under Runs once the workflow is live; test runs are not counted.</p>
            </>}
            {t === "delay" && <div className="grid grid-cols-2 gap-2">
                <F label="Amount"><Input type="number" min="0" value={c.amount ?? 1} onChange={(e) => update("amount", parseFloat(e.target.value) || 0)} /></F>
                <F label="Unit"><Select value={c.unit || "hours"} onValueChange={(v) => update("unit", v)}><SelectTrigger className="h-8"><SelectValue /></SelectTrigger><SelectContent>{["minutes", "hours", "days"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select></F>
            </div>}
            {t === "wait_until" && <F label="Hour of day (0-23, UTC)"><Input type="number" min="0" max="23" value={c.hour ?? 9} onChange={(e) => update("hour", parseInt(e.target.value, 10) || 0)} /></F>}
            {t === "send_email" && <>
                <F label="To"><Input value={c.to ?? "{{contact.email}}"} onChange={(e) => update("to", e.target.value)} /></F>
                <F label="Subject"><Input value={c.subject || ""} onChange={(e) => update("subject", e.target.value)} data-testid="wf-email-subject" /></F>
                <F label="Body"><Textarea rows={7} value={c.body || ""} onChange={(e) => update("body", e.target.value)} /></F>
            </>}
            {(t === "add_tag" || t === "remove_tag") && <F label="Tag"><Input value={c.tag || ""} onChange={(e) => update("tag", e.target.value)} /></F>}
            {t === "create_task" && <F label="Task title"><Input value={c.title || ""} onChange={(e) => update("title", e.target.value)} /></F>}
            {t === "notify_owner" && <F label="Message"><Textarea rows={3} value={c.message || ""} onChange={(e) => update("message", e.target.value)} /></F>}
            {t === "webhook" && <>
                <F label="URL (https, public host)"><Input value={c.url || ""} onChange={(e) => update("url", e.target.value)} /></F>
                <F label="Method"><Select value={c.method || "POST"} onValueChange={(v) => update("method", v)}><SelectTrigger className="h-8"><SelectValue /></SelectTrigger><SelectContent>{["POST", "PUT", "GET"].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select></F>
            </>}
            {t === "ai_generate" && <>
                <F label="Prompt"><Textarea rows={5} value={c.prompt || ""} onChange={(e) => update("prompt", e.target.value)} /></F>
                <F label="Save result as"><Input value={c.save_as || "ai_text"} onChange={(e) => update("save_as", e.target.value)} /></F>
                <p className="text-[11px] text-zinc-500 mt-2">Metered against your plan and this workflow's monthly cap. Truth rule applies (no invented facts).</p>
            </>}
            {t === "approval" && <F label="Note for the approver"><Input value={c.note || ""} onChange={(e) => update("note", e.target.value)} /></F>}
            {t === "end" && <p className="text-xs text-zinc-500 mt-1">Marks the end of a branch.</p>}
        </div>
    );
}

function RunsPanel({ runs, onClose, onRetry, abStats = [] }) {
    return (
        <div data-testid="wf-runs-panel">
            <div className="flex items-center justify-between"><div className="font-medium">Run history</div><Button size="sm" variant="ghost" onClick={onClose}>Close</Button></div>
            {abStats.length > 0 && (
                <div className="mt-2 rounded-md border border-teal-200 bg-teal-50 p-2 text-xs" data-testid="wf-ab-stats">
                    <div className="font-medium text-teal-800 mb-1">A/B split results (live runs)</div>
                    {abStats.map((n) => (
                        <div key={n.node_id} className="flex items-center justify-between text-teal-900"><span className="font-mono">{n.node_id}</span><span>A {n.count_a} · B {n.count_b}{n.share_a != null ? ` · ${n.share_a}% A` : ""}</span></div>
                    ))}
                </div>
            )}
            {runs.length === 0 && <div className="text-xs text-zinc-500 mt-2">No runs yet.</div>}
            <div className="mt-2 space-y-2">
                {runs.map((r) => (
                    <div key={r.id} className="rounded-lg border border-brand-line p-2 text-xs" data-testid={`wf-run-${r.id}`}>
                        <div className="flex items-center justify-between gap-2">
                            <span className={`inline-flex px-1.5 py-0.5 rounded-full text-[10px] ${RUN_STYLE[r.status] || "bg-zinc-100"}`}>{r.status.replace("_", " ")}{r.test_mode ? " · test" : ""}</span>
                            <span className="text-zinc-500">{new Date(r.created_at).toLocaleString()}</span>
                        </div>
                        <div className="mt-1 text-zinc-600 truncate">{r.context?.contact?.email || r.context?.email || "—"} · {r.steps?.length || 0} steps{r.error ? ` · ${r.error}` : ""}</div>
                        {(r.status === "dead_letter" || r.status === "failed") && <Button size="sm" variant="outline" className="mt-1 h-6 text-[11px] border-brand-line" onClick={() => onRetry(r.id)}>Retry</Button>}
                    </div>
                ))}
            </div>
        </div>
    );
}
