import { Link, useLocation } from "react-router-dom";
import PublicNav from "@/components/PublicNav";
import { Button } from "@/components/ui/button";
import { useBrand } from "@/context/BrandContext";
import { Home, LifeBuoy, Search, ArrowRight, Sparkles } from "lucide-react";

export default function NotFound() {
    const brand = useBrand();
    const location = useLocation();
    return (
        <div className="min-h-screen bg-brand-surface text-brand-ink relative overflow-hidden">
            <PublicNav />
            {/* Ambient orbs */}
            <div className="pointer-events-none absolute -top-32 -left-32 w-[28rem] h-[28rem] rounded-full bg-brand-copper/10 blur-3xl animate-pulse" />
            <div className="pointer-events-none absolute bottom-0 right-0 w-[24rem] h-[24rem] rounded-full bg-brand-copper/5 blur-3xl" />

            <main className="relative mx-auto max-w-3xl px-6 py-24 text-center">
                <div className="inline-flex items-center gap-2 rounded-full border border-brand-line bg-white/70 px-3 py-1 text-xs text-zinc-600 mb-6 animate-fade-in-up">
                    <Sparkles className="w-3.5 h-3.5 text-brand-copper" /> That page doesn't exist
                </div>
                <div className="font-display text-[9rem] md:text-[11rem] leading-none text-brand-ink/10 select-none animate-fade-in-up" style={{ animationDelay: "60ms" }}>
                    404
                </div>
                <h1 className="-mt-8 font-display text-4xl md:text-5xl font-medium tracking-tight animate-fade-in-up" style={{ animationDelay: "120ms" }}>
                    We looked everywhere.
                </h1>
                <p className="mt-4 text-zinc-600 max-w-xl mx-auto animate-fade-in-up" style={{ animationDelay: "180ms" }}>
                    <code className="text-xs bg-brand-cream px-1.5 py-0.5 rounded mr-1">{location.pathname}</code>
                    isn't a page on {brand?.name || "our site"}. It might have moved, or you might be off the beaten path.
                </p>

                <div className="mt-9 flex flex-wrap justify-center gap-3 animate-fade-in-up" style={{ animationDelay: "240ms" }}>
                    <Link to="/" data-testid="notfound-home-btn">
                        <Button size="lg" className="bg-brand-ink hover:bg-black text-white">
                            <Home className="w-4 h-4 mr-2" /> Back home
                        </Button>
                    </Link>
                    <Link to="/pricing" data-testid="notfound-pricing-btn">
                        <Button size="lg" variant="outline" className="border-brand-line">See pricing</Button>
                    </Link>
                    {brand?.support_email && (
                        <a href={`mailto:${brand.support_email}`} data-testid="notfound-support-btn">
                            <Button size="lg" variant="outline" className="border-brand-line">
                                <LifeBuoy className="w-4 h-4 mr-2" /> Contact support
                            </Button>
                        </a>
                    )}
                </div>

                <div className="mt-16 rounded-2xl border border-brand-line bg-white/80 backdrop-blur p-6 text-left max-w-lg mx-auto animate-fade-in-up" style={{ animationDelay: "320ms" }}>
                    <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-brand-copper">
                        <Search className="w-3.5 h-3.5" /> Popular next steps
                    </div>
                    <ul className="mt-3 divide-y divide-brand-line">
                        {[
                            { to: "/signup", label: "Start a free trial" },
                            { to: "/pricing", label: "See pricing & plans" },
                            { to: "/product", label: "How the product works" },
                            { to: "/terms", label: "Terms of service" },
                        ].map((l) => (
                            <li key={l.to}>
                                <Link to={l.to} className="flex items-center justify-between py-2.5 text-sm text-zinc-700 hover:text-brand-copper group">
                                    {l.label} <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                                </Link>
                            </li>
                        ))}
                    </ul>
                </div>
            </main>
        </div>
    );
}
