"""Sites manager: list/create/rename/activate/delete websites for an org (plan-limited),
plus per-site private/maintenance mode. Mounted under /api/sites.
"""
from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org, require_role
from ..models import User
from ..security import hash_password
from ..services import sites as svc
from ..services.entitlements import entitlements_dict, get_org_plan as plan_code_for_org

router = APIRouter(prefix="/sites", tags=["sites"])


def _pub(doc: Dict[str, Any], active_id: Optional[str], domains: List[Dict[str, Any]]) -> Dict[str, Any]:
    m = doc.get("maintenance") or {}
    pages = doc.get("pages") or []
    return {
        "id": str(doc["_id"]),
        "name": doc.get("name") or (pages[0].get("seo", {}).get("title") if pages else None) or doc.get("slug") or "Untitled site",
        "slug": doc.get("slug"),
        "status": doc.get("status", "draft"),
        "published_at": doc.get("published_at"),
        "draft_updated_at": doc.get("draft_updated_at"),
        "pages": len(pages),
        "is_active": str(doc["_id"]) == active_id,
        "public_url_path": f"/site/{doc['slug']}" if doc.get("slug") else None,
        "maintenance": {"enabled": bool(m.get("enabled")), "title": m.get("title", ""), "message": m.get("message", ""),
                        "eta": m.get("eta", ""), "accent": m.get("accent", ""), "show_logo": m.get("show_logo", True),
                        "contact_email": m.get("contact_email", ""), "password_set": bool(m.get("password_hash"))},
        "domains": [{"id": str(d["_id"]), "hostname": d.get("hostname"), "state": d.get("state"),
                     "landing_page_slug": d.get("landing_page_slug")} for d in domains],
        "theme_primary": ((doc.get("published_theme") or doc.get("theme") or {}).get("primary")),
        "created_at": doc.get("created_at"),
    }


async def _list(org_id: str) -> Dict[str, Any]:
    db = get_db()
    org = await db.organizations.find_one({"_id": ObjectId(org_id)}) or {}
    docs = [d async for d in db.websites.find({"org_id": org_id}).sort("created_at", 1)]
    active_id = org.get("active_website_id")
    if docs and (not active_id or not any(str(d["_id"]) == active_id for d in docs)):
        active_id = str(docs[0]["_id"])
        await svc.set_active(org_id, active_id)
    domains = [d async for d in db.domains.find({"org_id": org_id})]
    limits = entitlements_dict(await plan_code_for_org(org_id))
    return {
        "sites": [_pub(d, active_id, [x for x in domains if str(x.get("website_id")) == str(d["_id"])]) for d in docs],
        "active_website_id": active_id,
        "limit": limits.get("websites", 1),
        "used": len(docs),
        "can_create": len(docs) < (limits.get("websites") or 1),
        "plan_code": limits.get("plan_code"),
    }


@router.get("")
async def list_sites(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await _list(org_id)


class SiteCreate(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    clone_from: Optional[str] = None   # website id to duplicate (pages + theme)


@router.post("", status_code=201)
async def create_site(req: SiteCreate, user: User = Depends(require_role("owner", "manager")),
                      org_id: str = Depends(require_org)):
    db = get_db()
    state = await _list(org_id)
    if not state["can_create"]:
        raise HTTPException(402, {"error": "plan_limit", "message": f"Your plan allows {state['limit']} website(s). Upgrade to add more.",
                                  "limit": state["limit"], "used": state["used"]})
    profile = await db.business_profiles.find_one({"org_id": org_id}) or {}
    src = None
    if req.clone_from:
        try:
            src = await db.websites.find_one({"_id": ObjectId(req.clone_from), "org_id": org_id})
        except Exception:
            src = None
        if not src:
            raise HTTPException(404, "Site to clone not found")
    if src:
        pages = [dict(p, id=uuid.uuid4().hex[:10]) for p in (src.get("pages") or [])]
        theme = src.get("theme") or svc.DEFAULT_THEME
        nav = src.get("nav_order") or [p["slug"] for p in pages]
    else:
        pages = svc.blank_pages(req.name)
        theme = dict(svc.DEFAULT_THEME)
        nav = ["home"]
    doc = {
        "org_id": org_id, "business_profile_id": str(profile.get("_id", "")), "name": req.name.strip(),
        "theme": theme, "pages": pages, "nav_order": nav, "slug": None, "slug_history": [],
        "status": "draft", "maintenance": {}, "draft_updated_at": utc_now_iso(),
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    }
    r = await db.websites.insert_one(doc)
    await svc.set_active(org_id, str(r.inserted_id))
    return await _list(org_id)


class SitePatch(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=60)


@router.patch("/{site_id}")
async def rename_site(site_id: str, req: SitePatch, user: User = Depends(require_role("owner", "manager")),
                      org_id: str = Depends(require_org)):
    db = get_db()
    upd = {"updated_at": utc_now_iso()}
    if req.name:
        upd["name"] = req.name.strip()
    r = await db.websites.update_one({"_id": _oid(site_id), "org_id": org_id}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(404, "Site not found")
    return await _list(org_id)


@router.post("/{site_id}/activate")
async def activate_site(site_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    if not await db.websites.find_one({"_id": _oid(site_id), "org_id": org_id}, {"_id": 1}):
        raise HTTPException(404, "Site not found")
    await svc.set_active(org_id, site_id)
    return await _list(org_id)


@router.delete("/{site_id}")
async def delete_site(site_id: str, user: User = Depends(require_role("owner")), org_id: str = Depends(require_org)):
    db = get_db()
    total = await db.websites.count_documents({"org_id": org_id})
    if total <= 1:
        raise HTTPException(400, "You must keep at least one website")
    doc = await db.websites.find_one({"_id": _oid(site_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Site not found")
    await db.websites.delete_one({"_id": doc["_id"]})
    await db.domains.delete_many({"org_id": org_id, "website_id": site_id})
    await db.revisions.delete_many({"website_id": site_id})
    return await _list(org_id)


# ---------- private / maintenance mode ----------

class MaintenancePatch(BaseModel):
    enabled: Optional[bool] = None
    title: Optional[str] = Field(default=None, max_length=120)
    message: Optional[str] = Field(default=None, max_length=1000)
    eta: Optional[str] = Field(default=None, max_length=80)
    accent: Optional[str] = Field(default=None, max_length=9)
    show_logo: Optional[bool] = None
    contact_email: Optional[str] = Field(default=None, max_length=120)
    password: Optional[str] = Field(default=None, max_length=64)   # "" clears


@router.put("/{site_id}/maintenance")
async def set_maintenance(site_id: str, req: MaintenancePatch,
                          user: User = Depends(require_role("owner", "manager")), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.websites.find_one({"_id": _oid(site_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Site not found")
    m = dict(doc.get("maintenance") or {})
    for k in ("enabled", "title", "message", "eta", "accent", "show_logo", "contact_email"):
        v = getattr(req, k)
        if v is not None:
            m[k] = v
    if req.password is not None:
        if req.password.strip():
            if len(req.password.strip()) < 4:
                raise HTTPException(400, "Password must be at least 4 characters")
            m["password_hash"] = hash_password(req.password.strip())
        else:
            m.pop("password_hash", None)
    await db.websites.update_one({"_id": doc["_id"]}, {"$set": {"maintenance": m, "updated_at": utc_now_iso()}})
    return (await _list(org_id))


class DomainLanding(BaseModel):
    landing_page_slug: Optional[str] = None
    website_id: Optional[str] = None


@router.put("/domains/{domain_id}/binding")
async def bind_domain(domain_id: str, req: DomainLanding, user: User = Depends(require_role("owner", "manager")),
                      org_id: str = Depends(require_org)):
    """Point a connected domain at a specific website and (optionally) a landing page,
    e.g. book.acme.com → site B /booking."""
    db = get_db()
    dom = await db.domains.find_one({"_id": _oid(domain_id), "org_id": org_id})
    if not dom:
        raise HTTPException(404, "Domain not found")
    upd: Dict[str, Any] = {"updated_at": utc_now_iso()}
    if req.website_id:
        site = await db.websites.find_one({"_id": _oid(req.website_id), "org_id": org_id}, {"pages": 1})
        if not site:
            raise HTTPException(404, "Website not found")
        upd["website_id"] = req.website_id
    if req.landing_page_slug is not None:
        upd["landing_page_slug"] = req.landing_page_slug or None
    await db.domains.update_one({"_id": dom["_id"]}, {"$set": upd})
    return await _list(org_id)


def _oid(v: str) -> ObjectId:
    try:
        return ObjectId(v)
    except Exception:
        raise HTTPException(404, "Not found")
