import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useEditor } from "./EditorProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Undo2, Redo2, Monitor, Tablet, Smartphone, History, Rocket, ExternalLink, ArrowLeft, Plus, Sparkles } from "lucide-react";
import api from "@/lib/api";
import { toast } from "sonner";

function SaveIndicator({ state }) {
    const label = {
        idle: "All changes saved",
        dirty: "Editing…",
        saving: "Saving…",
        saved: "Saved",
        error: "Save failed",
    }[state];
    const color = {
        idle: "text-zinc-500", dirty: "text-brand-copper", saving: "text-brand-copper",
        saved: "text-emerald-600", error: "text-red-600",
    }[state];
    return <span className={`text-xs ${color}`} data-testid="editor-save-state">{label}</span>;
}

function BlockLibrarySheet() {
    const [library, setLibrary] = useState([]);
    const { addBlock, selectedPageSlug } = useEditor();
    useEffect(() => { api.get("/editor/block-library").then((r) => setLibrary(r.data.blocks || [])).catch(() => {}); }, []);

    return (
        <Sheet>
            <SheetTrigger asChild>
                <Button variant="outline" size="sm" data-testid="editor-add-section">
                    <Plus className="w-4 h-4 mr-1" /> Add section
                </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-96">
                <SheetHeader><SheetTitle>Add a section</SheetTitle></SheetHeader>
                <div className="mt-6 space-y-2 overflow-y-auto max-h-[calc(100vh-8rem)]">
                    {library.map((it) => (
                        <button
                            key={`${it.type}-${it.variant}`}
                            className="w-full text-left p-4 rounded-lg border border-brand-line bg-white hover:border-brand-copper transition-colors flex items-start gap-3"
                            data-testid={`library-${it.type}-${it.variant}`}
                            onClick={() => addBlock(selectedPageSlug, { type: it.type, variant: it.variant, props: {} })}
                        >
                            <div className="w-10 h-10 rounded bg-brand-cream flex items-center justify-center text-brand-copper text-xs font-mono">
                                {it.type.slice(0, 2).toUpperCase()}
                            </div>
                            <div>
                                <div className="text-sm font-medium">{it.label}</div>
                                <div className="text-xs text-zinc-500 font-mono">{it.type} · {it.variant}</div>
                            </div>
                        </button>
                    ))}
                </div>
            </SheetContent>
        </Sheet>
    );
}

function RevisionsSheet() {
    const [revs, setRevs] = useState([]);
    const [open, setOpen] = useState(false);
    const { refetch } = useEditor();

    async function load() {
        try {
            const { data } = await api.get("/editor/website/revisions");
            setRevs(data.revisions || []);
        } catch (e) {
            toast.error("Could not load revisions");
        }
    }
    useEffect(() => { if (open) load(); }, [open]);

    async function rollback(id) {
        if (!window.confirm("Roll the site back to this revision? A new revision will be recorded — history is preserved.")) return;
        try {
            await api.post(`/editor/website/revisions/${id}/rollback`, { note: "UI rollback" });
            toast.success("Rolled back and re-published.");
            await refetch();
            await load();
        } catch (e) {
            toast.error("Rollback failed");
        }
    }

    return (
        <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
                <Button variant="ghost" size="sm" data-testid="editor-history-btn">
                    <History className="w-4 h-4 mr-1" /> History
                </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-96">
                <SheetHeader><SheetTitle>Publish history</SheetTitle></SheetHeader>
                <div className="mt-6 space-y-2 overflow-y-auto max-h-[calc(100vh-8rem)]">
                    {revs.length === 0 && <div className="text-sm text-zinc-500">No revisions yet — publish to create one.</div>}
                    {revs.map((r) => (
                        <div key={r.id} className="p-3 rounded-lg border border-brand-line bg-white" data-testid={`revision-${r.id}`}>
                            <div className="flex items-center justify-between">
                                <div>
                                    <div className="text-xs uppercase tracking-widest text-brand-copper">{r.kind}</div>
                                    <div className="text-sm mt-0.5">{r.note || "—"}</div>
                                    <div className="text-xs text-zinc-500 mt-0.5 font-mono">{r.created_at}</div>
                                </div>
                                <Button size="sm" variant="outline" onClick={() => rollback(r.id)}
                                        data-testid={`revision-rollback-${r.id}`}>
                                    Roll back
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            </SheetContent>
        </Sheet>
    );
}

function PublishDialog() {
    const { website, publish } = useEditor();
    const [open, setOpen] = useState(false);
    const [slug, setSlug] = useState(website?.slug || "");
    const [note, setNote] = useState("");
    const [busy, setBusy] = useState(false);
    useEffect(() => { setSlug(website?.slug || ""); }, [website?.slug]);

    async function onPublish() {
        setBusy(true);
        try {
            const res = await publish({ slug: slug || undefined, note: note || undefined });
            toast.success(`Published — live at /site/${res.slug}`);
            setNote("");
            setOpen(false);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Publish failed");
        } finally {
            setBusy(false);
        }
    }

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button size="sm" className="bg-brand-copper hover:bg-brand-copperHover text-white grain"
                        data-testid="editor-publish-btn">
                    <Rocket className="w-4 h-4 mr-1" /> Publish
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader><DialogTitle>Publish site</DialogTitle></DialogHeader>
                <div className="space-y-4">
                    <div>
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Public path</div>
                        <div className="flex items-center gap-2">
                            <span className="text-zinc-500 font-mono text-sm">/site/</span>
                            <Input value={slug} onChange={(e) => setSlug(e.target.value)} placeholder="my-business"
                                   className="font-mono text-sm" data-testid="publish-slug-input" />
                        </div>
                        {website?.slug && slug !== website.slug && (
                            <div className="mt-2 text-xs text-brand-copper">Old slug will auto-redirect to the new one.</div>
                        )}
                    </div>
                    <div>
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Note (optional)</div>
                        <Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)}
                                  placeholder="What changed?" data-testid="publish-note-input" />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
                    <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={onPublish} disabled={busy}
                            data-testid="publish-confirm-btn">
                        {busy ? "Publishing…" : "Publish now"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

export default function TopBar() {
    const { canUndo, canRedo, undo, redo, device, setDevice, saveState, website } = useEditor();
    return (
        <header className="h-14 border-b border-brand-line bg-white flex items-center px-4 gap-3" data-testid="editor-topbar">
            <Link to="/app" className="text-zinc-500 hover:text-brand-ink flex items-center gap-1 text-sm" data-testid="editor-back-btn">
                <ArrowLeft className="w-4 h-4" /> Dashboard
            </Link>
            <div className="w-px h-6 bg-brand-line" />
            <Button variant="ghost" size="sm" disabled={!canUndo} onClick={undo} data-testid="editor-undo-btn">
                <Undo2 className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" disabled={!canRedo} onClick={redo} data-testid="editor-redo-btn">
                <Redo2 className="w-4 h-4" />
            </Button>
            <div className="w-px h-6 bg-brand-line" />
            <div className="flex items-center rounded-md border border-brand-line p-0.5" data-testid="editor-device-toggle">
                {[
                    { k: "desktop", Icon: Monitor },
                    { k: "tablet", Icon: Tablet },
                    { k: "mobile", Icon: Smartphone },
                ].map(({ k, Icon }) => (
                    <button
                        key={k}
                        onClick={() => setDevice(k)}
                        className={`px-2 py-1 rounded ${device === k ? "bg-brand-ink text-white" : "text-zinc-500 hover:text-brand-ink"}`}
                        data-testid={`device-${k}`}
                    >
                        <Icon className="w-4 h-4" />
                    </button>
                ))}
            </div>
            <BlockLibrarySheet />
            <div className="flex-1" />
            <SaveIndicator state={saveState} />
            <RevisionsSheet />
            {website?.slug && (
                <a href={`/site/${website.slug}`} target="_blank" rel="noreferrer"
                   className="text-sm text-zinc-500 hover:text-brand-ink inline-flex items-center gap-1"
                   data-testid="editor-view-live">
                    <ExternalLink className="w-3.5 h-3.5" /> View live
                </a>
            )}
            <PublishDialog />
        </header>
    );
}
