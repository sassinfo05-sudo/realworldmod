import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import api, { clearImpersonation } from "@/lib/api";

const AuthContext = createContext(null);

// Round 15 (P0): the JWT is delivered ONLY as a Secure, HttpOnly cookie by the server. We keep
// ONLY a non-secret session marker ("1") + the public profile in localStorage so route guards work
// across reloads; the real session is validated against /auth/me (cookie) on mount. No raw JWT is
// ever written to JS-accessible storage.
const SESSION_KEY = "zanelvo.session";

export function AuthProvider({ children }) {
    const [user, setUser] = useState(() => {
        try {
            const raw = localStorage.getItem("zanelvo.user");
            return raw ? JSON.parse(raw) : null;
        } catch {
            return null;
        }
    });
    // `token` is a non-secret session marker (truthy when signed in), NOT the JWT.
    const [token, setToken] = useState(() => localStorage.getItem(SESSION_KEY));
    const [loading, setLoading] = useState(false);

    const persist = useCallback((signedIn, u) => {
        // Never persist the raw JWT — it lives only in the HttpOnly cookie. We store a marker + profile.
        if (signedIn) { localStorage.setItem(SESSION_KEY, "1"); }
        else { localStorage.removeItem(SESSION_KEY); }
        // One-time cleanup of any legacy raw token left by older builds.
        localStorage.removeItem("zanelvo.token");
        if (u) localStorage.setItem("zanelvo.user", JSON.stringify(u));
        else localStorage.removeItem("zanelvo.user");
        setToken(signedIn ? "1" : null);
        setUser(u || null);
    }, []);

    const login = useCallback(async (email, password, remember = false) => {
        setLoading(true);
        try {
            const { data } = await api.post("/auth/login", { email, password, remember });
            if (data.mfa_required) return { mfa_required: true, ...data };
            persist(true, data.user);
            return data.user;
        } finally {
            setLoading(false);
        }
    }, [persist]);

    /** Step-up 2FA: exchange challenge + code for a session. */
    const verify2fa = useCallback(async (challenge_id, code) => {
        const { data } = await api.post("/auth/2fa/verify", { challenge_id, code });
        persist(true, data.user);
        return data.user;
    }, [persist]);
    const resend2fa = useCallback(async (challenge_id) => {
        const { data } = await api.post("/auth/2fa/resend", { challenge_id });
        return data;
    }, []);

    const signup = useCallback(async (payload) => {
        setLoading(true);
        try {
            const { data } = await api.post("/auth/signup", payload);
            persist(true, data.user);
            return data.user;
        } finally {
            setLoading(false);
        }
    }, [persist]);

    const logout = useCallback(() => {
        api.post("/auth/logout").catch(() => {});
        clearImpersonation();
        persist(false, null);
    }, [persist]);

    const refreshMe = useCallback(async () => {
        if (!token) return null;
        try {
            const { data } = await api.get("/auth/me");
            persist(true, data);
            return data;
        } catch (e) {
            if (e?.response?.status === 401) persist(false, null);
            return null;
        }
    }, [token, persist]);

    useEffect(() => {
        if (token && !user) refreshMe();
    }, [token, user, refreshMe]);

    // Exposed for social-login / staff-login callbacks: the server has already set the HttpOnly
    // cookie, so we only record the session marker + profile (the `t` arg is ignored for storage).
    const persistToken = useCallback((t, u) => persist(true, u), [persist]);

    const value = useMemo(
        () => ({ user, token, loading, login, signup, logout, refreshMe, persistToken, verify2fa, resend2fa }),
        [user, token, loading, login, signup, logout, refreshMe, persistToken, verify2fa, resend2fa]
    );

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
    return ctx;
}
