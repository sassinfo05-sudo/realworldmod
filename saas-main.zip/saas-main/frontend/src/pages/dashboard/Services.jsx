import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Pencil } from "lucide-react";

const EMPTY = {
    name: "", description: "", duration_minutes: 60,
    buffer_before_minutes: 0, buffer_after_minutes: 15,
    price_cents: 0, deposit_cents: 0, currency: "USD",
    location_type: "on_site", required_staff_ids: [], bookable: true,
    color: null, max_daily_bookings: null,
};

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

export default function Services() {
    const [services, setServices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [open, setOpen] = useState(false);
    const [editing, setEditing] = useState(null);
    const [form, setForm] = useState(EMPTY);
    const [busy, setBusy] = useState(false);

    async function load() {
        setLoading(true);
        try {
            const { data } = await api.get("/booking/services?active_only=false");
            setServices(data.services || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    function openNew() { setEditing(null); setForm(EMPTY); setOpen(true); }
    function openEdit(s) {
        setEditing(s);
        setForm({
            name: s.name, description: s.description || "",
            duration_minutes: s.duration_minutes,
            buffer_before_minutes: s.buffer_before_minutes,
            buffer_after_minutes: s.buffer_after_minutes,
            price_cents: s.price_cents, deposit_cents: s.deposit_cents,
            currency: s.currency, location_type: s.location_type,
            required_staff_ids: s.required_staff_ids || [],
            bookable: s.bookable, color: s.color,
            max_daily_bookings: s.max_daily_bookings,
        });
        setOpen(true);
    }
    async function save() {
        setBusy(true);
        try {
            const payload = { ...form };
            if (editing) await api.patch(`/booking/services/${editing.id}`, payload);
            else await api.post("/booking/services", payload);
            toast.success(editing ? "Service updated" : "Service created");
            setOpen(false); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Save failed"); }
        finally { setBusy(false); }
    }

    return (
        <div className="p-6" data-testid="services-page">
            <div className="flex items-start justify-between mb-4 gap-3 flex-wrap">
                <div>
                    <h2 className="text-lg font-medium text-brand-ink">Services catalog</h2>
                    <p className="text-sm text-zinc-500">Bookable services with duration, buffers and price. Shown to customers on your site.</p>
                </div>
                <Button onClick={openNew} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="services-new-btn">
                    <Plus className="w-4 h-4 mr-1" /> New service
                </Button>
            </div>

            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Buffers</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Bookable</TableHead>
                        <TableHead></TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {services.map((s) => (
                            <TableRow key={s.id} data-testid={`service-row-${s.id}`}>
                                <TableCell>
                                    <div className="font-medium text-brand-ink">{s.name}</div>
                                    {s.description && <div className="text-xs text-zinc-500 mt-0.5 line-clamp-1">{s.description}</div>}
                                </TableCell>
                                <TableCell className="font-mono text-sm">{s.duration_minutes} min</TableCell>
                                <TableCell className="text-xs text-zinc-500">−{s.buffer_before_minutes} / +{s.buffer_after_minutes}</TableCell>
                                <TableCell className="font-mono text-sm">{money(s.price_cents, s.currency)}</TableCell>
                                <TableCell>
                                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs ${s.bookable ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-600"}`}>
                                        {s.bookable ? "Yes" : "No"}
                                    </span>
                                </TableCell>
                                <TableCell><Button size="sm" variant="ghost" onClick={() => openEdit(s)} data-testid={`service-edit-${s.id}`}><Pencil className="w-3.5 h-3.5" /></Button></TableCell>
                            </TableRow>
                        ))}
                        {!loading && !services.length && (
                            <TableRow><TableCell colSpan={6} className="text-center text-zinc-500 py-10" data-testid="services-empty">No services yet. Add one to open bookings.</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader><DialogTitle>{editing ? "Edit service" : "New service"}</DialogTitle></DialogHeader>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="md:col-span-2">
                            <Label className="text-xs">Name</Label>
                            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="service-form-name" />
                        </div>
                        <div className="md:col-span-2">
                            <Label className="text-xs">Description</Label>
                            <Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Duration (min)</Label>
                            <Input type="number" min="1" value={form.duration_minutes} onChange={(e) => setForm({ ...form, duration_minutes: +e.target.value })} data-testid="service-form-duration" />
                        </div>
                        <div>
                            <Label className="text-xs">Price (cents)</Label>
                            <Input type="number" min="0" value={form.price_cents} onChange={(e) => setForm({ ...form, price_cents: +e.target.value })} data-testid="service-form-price" />
                        </div>
                        <div>
                            <Label className="text-xs">Buffer before (min)</Label>
                            <Input type="number" min="0" value={form.buffer_before_minutes} onChange={(e) => setForm({ ...form, buffer_before_minutes: +e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Buffer after (min)</Label>
                            <Input type="number" min="0" value={form.buffer_after_minutes} onChange={(e) => setForm({ ...form, buffer_after_minutes: +e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Location type</Label>
                            <Select value={form.location_type} onValueChange={(v) => setForm({ ...form, location_type: v })}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="on_site">On site</SelectItem>
                                    <SelectItem value="at_business">At business</SelectItem>
                                    <SelectItem value="virtual">Virtual</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label className="text-xs">Currency</Label>
                            <Input value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} maxLength={3} />
                        </div>
                        <div className="md:col-span-2 flex items-center gap-2 pt-2">
                            <input type="checkbox" checked={form.bookable} onChange={(e) => setForm({ ...form, bookable: e.target.checked })} data-testid="service-form-bookable" />
                            <Label className="text-sm">Bookable — show on public site</Label>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
                        <Button onClick={save} disabled={busy || !form.name} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="service-form-save">
                            {editing ? "Save changes" : "Create service"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
