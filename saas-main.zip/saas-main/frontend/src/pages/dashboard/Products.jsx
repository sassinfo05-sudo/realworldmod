import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import MediaPicker from "@/pages/editor/MediaPicker";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Upload, ExternalLink, Store, Download, Rss } from "lucide-react";
import { authHeaders } from "@/lib/api";

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

function parseOptions(text) {
    return String(text || "").split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
        const [name, rest = ""] = l.split(":");
        return { name: name.trim(), values: rest.split(",").map((v) => v.trim()).filter(Boolean) };
    }).filter((o) => o.name && o.values.length);
}

const EMPTY = { name: "", description: "", price: "", compare_at: "", stock: 0, image_url: "", active: true, sku: "",
    weight_grams: 0, product_type: "physical", digital_url: "", requires_shipping: true,
    tags: "", seo_title: "", seo_description: "", variants: [], barcode: "", options_text: "",
    gift_card_amount: "", bundle_items_text: "", is_subscription: false, billing_interval: "month" };

/** Round 11 — Google Shopping / Meta product feeds (public URLs, owner toggle). */
function FeedsCard() {
    const [feeds, setFeeds] = useState(null);
    useEffect(() => { api.get("/store/feeds").then((r) => setFeeds(r.data)).catch(() => setFeeds(null)); }, []);
    if (!feeds) return null;
    const base = process.env.REACT_APP_BACKEND_URL || "";
    const toggle = async (v) => {
        try { const { data } = await api.put("/store/feeds", { enabled: v }); setFeeds(data); toast.success(v ? "Feeds enabled" : "Feeds disabled"); }
        catch { toast.error("Could not update feeds"); }
    };
    return (
        <div className="bg-white border border-brand-line rounded-xl p-4 flex flex-wrap items-center gap-4" data-testid="products-feeds-card">
            <div className="w-9 h-9 rounded-lg bg-brand-copper/10 text-brand-copper flex items-center justify-center"><Rss className="w-4 h-4" /></div>
            <div className="flex-1 min-w-[220px]">
                <div className="font-medium text-brand-ink text-sm">Product feeds</div>
                <div className="text-xs text-zinc-500">Submit these URLs to Google Merchant Center / Meta Commerce. Only active, in-stock products are listed.</div>
                {feeds.enabled && (
                    <div className="mt-1 flex flex-wrap gap-3 text-xs">
                        <a className="text-brand-copper underline" href={`${base}${feeds.xml_path}`} target="_blank" rel="noreferrer" data-testid="products-feed-xml">Google Shopping XML</a>
                        <a className="text-brand-copper underline" href={`${base}${feeds.csv_path}`} target="_blank" rel="noreferrer" data-testid="products-feed-csv">Meta / marketplace CSV</a>
                    </div>
                )}
            </div>
            <label className="flex items-center gap-2 text-sm"><Switch checked={!!feeds.enabled} onCheckedChange={toggle} data-testid="products-feeds-toggle" /> {feeds.enabled ? "Public" : "Off"}</label>
        </div>
    );
}

export default function Products() {
    const { user } = useAuth();
    const [orgId, setOrgId] = useState(user?.org_id || "");
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [open, setOpen] = useState(false);
    const [editing, setEditing] = useState(null);
    const [form, setForm] = useState(EMPTY);
    const [busy, setBusy] = useState(false);
    const [importOpen, setImportOpen] = useState(false);
    const [sourceOpen, setSourceOpen] = useState(false);

    async function load() {
        setLoading(true);
        try {
            const { data } = await api.get("/store/products");
            setProducts(data.products || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);
    useEffect(() => {
        if (orgId) return;
        api.get("/auth/me").then((r) => setOrgId(r.data?.org_id || "")).catch(() => {});
    }, [orgId]);

    function openNew() { setEditing(null); setForm(EMPTY); setOpen(true); }
    function openEdit(p) {
        setEditing(p);
        setForm({ name: p.name, description: p.description || "", price: (p.price_cents / 100).toFixed(2),
            compare_at: p.compare_at_cents ? (p.compare_at_cents / 100).toFixed(2) : "",
            stock: p.stock, image_url: p.image_url || "", active: p.active, sku: p.sku || "",
            weight_grams: p.weight_grams || 0, product_type: p.product_type || "physical",
            digital_url: p.digital_url || "", requires_shipping: p.requires_shipping !== false,
            tags: (p.tags || []).join(", "), seo_title: p.seo_title || "", seo_description: p.seo_description || "",
            barcode: p.barcode || "",
            gift_card_amount: p.gift_card_amount_cents ? (p.gift_card_amount_cents / 100).toFixed(2) : "",
            bundle_items_text: (p.bundle_items || []).map((b) => b.product_id).join(", "),
            is_subscription: !!p.is_subscription, billing_interval: p.billing_interval || "month",
            options_text: (p.options || []).map((o) => `${o.name}: ${(o.values || []).join(", ")}`).join("\n"),
            variants: (p.variants || []).map((v) => ({ name: v.name || "", stock: v.stock ?? 0, sku: v.sku || "", options: v.options,
                price: v.price_cents ? (v.price_cents / 100).toFixed(2) : "" })) });
        setOpen(true);
    }
    async function save() {
        const cents = Math.round(parseFloat(form.price || "0") * 100);
        if (!form.name.trim()) { toast.error("Name is required"); return; }
        if (isNaN(cents) || cents < 0) { toast.error("Enter a valid price"); return; }
        setBusy(true);
        try {
            const payload = { name: form.name.trim(), description: form.description,
                price_cents: cents, stock: +form.stock || 0, image_url: form.image_url,
                active: form.active, sku: form.sku, barcode: form.barcode || "",
                options: parseOptions(form.options_text),
                compare_at_cents: form.compare_at ? Math.round(parseFloat(form.compare_at) * 100) : 0,
                weight_grams: +form.weight_grams || 0,
                product_type: form.product_type || "physical",
                digital_url: form.product_type === "digital" ? form.digital_url : "",
                requires_shipping: (form.product_type === "digital" || form.product_type === "gift_card") ? false : !!form.requires_shipping,
                gift_card_amount_cents: form.product_type === "gift_card" ? (form.gift_card_amount ? Math.round(parseFloat(form.gift_card_amount) * 100) : cents) : 0,
                bundle_items: form.product_type === "bundle" ? (form.bundle_items_text || "").split(",").map((s) => s.trim()).filter(Boolean).map((id) => ({ product_id: id, qty: 1 })) : [],
                is_subscription: !!form.is_subscription,
                billing_interval: form.billing_interval || "month",
                tags: (form.tags || "").split(",").map((t) => t.trim()).filter(Boolean),
                seo_title: form.seo_title, seo_description: form.seo_description,
                variants: (form.variants || []).filter((v) => (v.name || "").trim()).map((v) => ({
                    name: v.name.trim(), stock: +v.stock || 0, sku: v.sku || "", options: v.options || undefined,
                    price_cents: v.price ? Math.round(parseFloat(v.price) * 100) : cents })) };
            if (editing) await api.put(`/store/products/${editing.id}`, payload);
            else await api.post("/store/products", payload);
            toast.success(editing ? "Product updated" : "Product created");
            setOpen(false); load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Save failed"); }
        finally { setBusy(false); }
    }
    async function remove(p) {
        if (!window.confirm(`Delete \"${p.name}\"?`)) return;
        try { await api.delete(`/store/products/${p.id}`); toast.success("Deleted"); load(); }
        catch (e) { toast.error(e?.response?.data?.detail || "Delete failed"); }
    }
    async function toggleActive(p) {
        try { await api.put(`/store/products/${p.id}`, { active: !p.active }); load(); }
        catch { toast.error("Could not update"); }
    }

    const storeUrl = `/store/${orgId}`;

    return (
        <div className="p-6" data-testid="products-page">
            <div className="flex items-start justify-between mb-4 gap-3 flex-wrap">
                <div>
                    <h2 className="text-lg font-medium text-brand-ink flex items-center gap-2"><Store className="w-5 h-5 text-brand-copper" /> Products</h2>
                    <p className="text-sm text-zinc-500">Sell products online. Stock decrements automatically when an order is paid.</p>
                </div>
                <div className="flex gap-2">
                    <a href={storeUrl} target="_blank" rel="noreferrer" className={orgId ? "" : "pointer-events-none opacity-50"} data-testid="products-view-store-link">
                        <Button variant="outline" className="border-brand-line" disabled={!orgId} data-testid="products-view-store"><ExternalLink className="w-4 h-4 mr-1" /> View storefront</Button>
                    </a>
                    <Button variant="outline" className="border-brand-line" onClick={() => setSourceOpen(true)} data-testid="products-source-btn"><Store className="w-4 h-4 mr-1" /> Source products</Button>
                    <Button variant="outline" className="border-brand-line" onClick={() => setImportOpen(true)} data-testid="products-import-btn"><Upload className="w-4 h-4 mr-1" /> Import CSV</Button>
                    <Button variant="outline" className="border-brand-line" data-testid="products-export-btn" onClick={async () => {
                        try {
                            const r = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/store/products/export.csv`, { headers: authHeaders(), credentials: "include" });
                            if (!r.ok) throw new Error("export failed");
                            const blob = await r.blob(); const url = URL.createObjectURL(blob);
                            const a = document.createElement("a"); a.href = url; a.download = "zanelvo-products.csv"; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
                        } catch { toast.error("Export failed"); }
                    }}><Download className="w-4 h-4 mr-1" /> Export CSV</Button>
                    <Button onClick={openNew} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="products-new-btn"><Plus className="w-4 h-4 mr-1" /> New product</Button>
                </div>
            </div>

            <FeedsCard />

            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Active</TableHead>
                        <TableHead></TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {products.map((p) => (
                            <TableRow key={p.id} data-testid={`product-row-${p.id}`}>
                                <TableCell>
                                    <div className="flex items-center gap-3">
                                        {p.image_url
                                            ? <img src={p.image_url} alt="" className="w-10 h-10 rounded object-cover border border-brand-line" />
                                            : <div className="w-10 h-10 rounded bg-brand-cream border border-brand-line" />}
                                        <div>
                                            <div className="font-medium text-brand-ink">{p.name}</div>
                                            {p.sku && <div className="text-xs text-zinc-400">SKU {p.sku}</div>}
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell className="font-mono text-sm">{money(p.price_cents, p.currency)}</TableCell>
                                <TableCell className={`font-mono text-sm ${p.stock <= 0 ? "text-red-600" : ""}`}>{p.stock}</TableCell>
                                <TableCell><Switch checked={p.active} onCheckedChange={() => toggleActive(p)} data-testid={`product-active-${p.id}`} /></TableCell>
                                <TableCell className="text-right">
                                    <Button size="sm" variant="ghost" onClick={() => openEdit(p)} data-testid={`product-edit-${p.id}`}><Pencil className="w-3.5 h-3.5" /></Button>
                                    <Button size="sm" variant="ghost" onClick={() => remove(p)} data-testid={`product-delete-${p.id}`}><Trash2 className="w-3.5 h-3.5 text-red-500" /></Button>
                                </TableCell>
                            </TableRow>
                        ))}
                        {!loading && !products.length && (
                            <TableRow><TableCell colSpan={5} className="text-center text-zinc-500 py-10" data-testid="products-empty">No products yet. Add one or import a CSV.</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader><DialogTitle>{editing ? "Edit product" : "New product"}</DialogTitle></DialogHeader>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="md:col-span-2">
                            <Label className="text-xs">Name</Label>
                            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="product-form-name" />
                        </div>
                        <div className="md:col-span-2">
                            <Label className="text-xs">Description</Label>
                            <Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Price (USD)</Label>
                            <Input type="number" min="0" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} data-testid="product-form-price" />
                        </div>
                        <div>
                            <Label className="text-xs">Compare-at price (USD)</Label>
                            <Input type="number" min="0" step="0.01" placeholder="Show a slashed 'was' price" value={form.compare_at} onChange={(e) => setForm({ ...form, compare_at: e.target.value })} data-testid="product-form-compare" />
                        </div>
                        <div>
                            <Label className="text-xs">Stock</Label>
                            <Input type="number" min="0" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} data-testid="product-form-stock" />
                        </div>
                        <div>
                            <Label className="text-xs">SKU (optional)</Label>
                            <Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} />
                        </div>
                        <div>
                            <Label className="text-xs">Barcode (GTIN/EAN/UPC, optional)</Label>
                            <Input value={form.barcode} onChange={(e) => setForm({ ...form, barcode: e.target.value })} data-testid="product-form-barcode" />
                        </div>
                        <div>
                            <Label className="text-xs">Product type</Label>
                            <Select value={form.product_type} onValueChange={(v) => setForm({ ...form, product_type: v })}>
                                <SelectTrigger data-testid="product-form-type"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="physical">Physical (shipped)</SelectItem>
                                    <SelectItem value="digital">Digital (download)</SelectItem>
                                    <SelectItem value="gift_card">Gift card</SelectItem>
                                    <SelectItem value="bundle">Bundle</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        {form.product_type === "gift_card" && (
                            <div className="md:col-span-2">
                                <Label className="text-xs">Gift card face value ($) — balance the buyer receives</Label>
                                <Input type="number" min="0" step="0.01" value={form.gift_card_amount} onChange={(e) => setForm({ ...form, gift_card_amount: e.target.value })} placeholder="Defaults to the price above" data-testid="product-form-giftamount" />
                                <p className="text-[11px] text-zinc-400 mt-1">A unique gift-card code is created and emailed when this is purchased.</p>
                            </div>
                        )}
                        {form.product_type === "bundle" && (
                            <div className="md:col-span-2">
                                <Label className="text-xs">Bundle contents (comma-separated product IDs)</Label>
                                <Input value={form.bundle_items_text} onChange={(e) => setForm({ ...form, bundle_items_text: e.target.value })} placeholder="id1, id2, id3" data-testid="product-form-bundle" />
                                <p className="text-[11px] text-zinc-400 mt-1">Sold as one item at the price above. Cross-sell related items via “Related products”.</p>
                            </div>
                        )}
                        <div className="md:col-span-2 rounded-lg border border-brand-line p-3 bg-brand-cream/40">
                            <label className="flex items-center gap-2 text-sm text-brand-ink cursor-pointer">
                                <input type="checkbox" checked={!!form.is_subscription} onChange={(e) => setForm({ ...form, is_subscription: e.target.checked })} className="accent-brand-copper" data-testid="product-form-subscription" />
                                Sell as a subscription (recurring)
                            </label>
                            {form.is_subscription && (
                                <div className="mt-2 flex items-center gap-2">
                                    <Label className="text-xs">Bills every</Label>
                                    <select value={form.billing_interval} onChange={(e) => setForm({ ...form, billing_interval: e.target.value })} className="border border-brand-line rounded-lg px-2 py-1 text-sm" data-testid="product-form-interval">
                                        <option value="month">Month</option>
                                        <option value="year">Year</option>
                                    </select>
                                    <span className="text-[11px] text-zinc-400">Price above is charged each period.</span>
                                </div>
                            )}
                        </div>
                        {form.product_type === "digital" ? (
                            <div className="md:col-span-2">
                                <Label className="text-xs">Download URL (sent to buyer)</Label>
                                <Input value={form.digital_url} onChange={(e) => setForm({ ...form, digital_url: e.target.value })} placeholder="https://…" data-testid="product-form-digital" />
                            </div>
                        ) : (
                            <>
                                <div>
                                    <Label className="text-xs">Weight (grams)</Label>
                                    <Input type="number" min="0" value={form.weight_grams} onChange={(e) => setForm({ ...form, weight_grams: e.target.value })} data-testid="product-form-weight" />
                                    <p className="text-[11px] text-zinc-400 mt-1">Used to calculate shipping rates.</p>
                                </div>
                                <div className="flex items-center gap-2 pt-6">
                                    <Switch checked={form.requires_shipping} onCheckedChange={(v) => setForm({ ...form, requires_shipping: v })} data-testid="product-form-requires-shipping" />
                                    <Label className="text-xs">Requires shipping</Label>
                                </div>
                            </>
                        )}
                        <div className="md:col-span-2">
                            <Label className="text-xs">Tags (comma-separated)</Label>
                            <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="summer, bestseller, gift" data-testid="product-form-tags" />
                        </div>
                        <div className="md:col-span-2 border-t border-brand-line pt-3">
                            <div className="flex items-center justify-between mb-2">
                                <Label className="text-xs font-medium">Variants (size, color…)</Label>
                                <Button type="button" size="sm" variant="outline" className="border-brand-line" onClick={() => setForm({ ...form, variants: [...(form.variants || []), { name: "", stock: 0, price: "" }] })} data-testid="product-form-add-variant"><Plus className="w-3.5 h-3.5 mr-1" /> Add variant</Button>
                            </div>
                            <div className="mb-3 rounded-lg bg-zinc-50 border border-brand-line p-3">
                                <Label className="text-xs">Options matrix — one option per line, e.g. <span className="font-mono">Size: S, M, L</span></Label>
                                <textarea rows={2} value={form.options_text} onChange={(e) => setForm({ ...form, options_text: e.target.value })}
                                    className="mt-1 w-full rounded-md border border-brand-line bg-white px-2 py-1.5 text-sm font-mono" placeholder={"Size: S, M, L\nColour: Black, White"} data-testid="product-form-options" />
                                <Button type="button" size="sm" variant="outline" className="mt-2 border-brand-line" data-testid="product-form-generate-matrix" onClick={async () => {
                                    const options = parseOptions(form.options_text);
                                    if (!options.length) { toast.error("Add at least one option line like 'Size: S, M'"); return; }
                                    try {
                                        const { data } = await api.post("/store/products/variant-matrix", { options, base_price_cents: Math.round(parseFloat(form.price || "0") * 100) || 0, base_stock: +form.stock || 0, sku_prefix: form.sku || "" });
                                        setForm({ ...form, variants: data.variants.map((v) => ({ name: v.name, stock: v.stock, sku: v.sku, options: v.options, price: (v.price_cents / 100).toFixed(2) })) });
                                        toast.success(`${data.count} variants generated`);
                                    } catch { toast.error("Could not generate variants"); }
                                }}>Generate variants from options</Button>
                            </div>
                            {(form.variants || []).map((v, i) => (
                                <div key={i} className="grid grid-cols-[1fr_90px_110px_auto] gap-2 mb-2 items-center">
                                    <Input placeholder="Variant name (e.g. Small)" value={v.name} onChange={(e) => setForm({ ...form, variants: form.variants.map((x, j) => j === i ? { ...x, name: e.target.value } : x) })} data-testid={`variant-name-${i}`} />
                                    <Input type="number" min="0" placeholder="Stock" value={v.stock} onChange={(e) => setForm({ ...form, variants: form.variants.map((x, j) => j === i ? { ...x, stock: e.target.value } : x) })} />
                                    <Input type="number" min="0" step="0.01" placeholder="Price (opt)" value={v.price} onChange={(e) => setForm({ ...form, variants: form.variants.map((x, j) => j === i ? { ...x, price: e.target.value } : x) })} />
                                    <Button type="button" size="sm" variant="ghost" className="text-rose-600" onClick={() => setForm({ ...form, variants: form.variants.filter((_, j) => j !== i) })}><Trash2 className="w-4 h-4" /></Button>
                                </div>
                            ))}
                        </div>
                        <div className="md:col-span-2 border-t border-brand-line pt-3">
                            <Label className="text-xs font-medium">Search engine listing (SEO)</Label>
                            <Input className="mt-2" placeholder="SEO title" value={form.seo_title} onChange={(e) => setForm({ ...form, seo_title: e.target.value })} data-testid="product-form-seo-title" />
                            <Textarea className="mt-2" rows={2} placeholder="SEO meta description" value={form.seo_description} onChange={(e) => setForm({ ...form, seo_description: e.target.value })} />
                        </div>
                        <div className="flex items-center gap-2 pt-2">
                            <Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} data-testid="product-form-active" />
                            <Label className="text-xs">Active (visible in storefront)</Label>
                        </div>
                        <div className="md:col-span-2">
                            <Label className="text-xs">Image</Label>
                            <MediaPicker value={form.image_url} onChange={(url) => setForm({ ...form, image_url: url })} />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={save} data-testid="product-form-save">{busy ? "Saving…" : "Save"}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <ImportDialog open={importOpen} onClose={() => setImportOpen(false)} onDone={() => { setImportOpen(false); load(); }} />
            <SourcingDialog open={sourceOpen} onClose={() => setSourceOpen(false)} onDone={() => { setSourceOpen(false); load(); }} />
        </div>
    );
}

const TARGETS = ["skip", "name", "description", "price", "stock", "sku", "image_url"];

function ImportDialog({ open, onClose, onDone }) {
    const [step, setStep] = useState(1);
    const [analysis, setAnalysis] = useState(null);
    const [mapping, setMapping] = useState([]);
    const [busy, setBusy] = useState(false);

    useEffect(() => { if (!open) { setStep(1); setAnalysis(null); setMapping([]); } }, [open]);

    async function onFile(e) {
        const file = e.target.files?.[0];
        if (!file) return;
        setBusy(true);
        try {
            const fd = new FormData();
            fd.append("file", file);
            const { data } = await api.post("/store/products/import/analyze", fd, { headers: { "Content-Type": "multipart/form-data" } });
            setAnalysis(data);
            setMapping(data.proposed_mapping || []);
            setStep(2);
        } catch (err) { toast.error(err?.response?.data?.detail || "Could not read CSV"); }
        finally { setBusy(false); }
    }
    async function execute() {
        setBusy(true);
        try {
            const { data } = await api.post(`/store/products/import/${analysis.run_id}/execute`, { mapping });
            toast.success(`Imported ${data.created} product(s)` + (data.errors?.length ? `, ${data.errors.length} skipped` : ""));
            onDone();
        } catch (err) { toast.error(err?.response?.data?.detail || "Import failed"); }
        finally { setBusy(false); }
    }

    return (
        <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
            <DialogContent className="max-w-2xl">
                <DialogHeader><DialogTitle>Import products from CSV</DialogTitle></DialogHeader>
                {step === 1 && (
                    <div className="py-4">
                        <p className="text-sm text-zinc-500 mb-3">Upload a CSV with columns like name, price, stock, sku, image. We&apos;ll auto-map and let you adjust.</p>
                        <Input type="file" accept=".csv,text/csv" onChange={onFile} disabled={busy} data-testid="product-import-file" />
                    </div>
                )}
                {step === 2 && analysis && (
                    <div className="py-2 max-h-[60vh] overflow-auto">
                        <p className="text-sm text-zinc-500 mb-3">{analysis.total_rows} rows found. Map each column:</p>
                        <div className="space-y-2">
                            {mapping.map((m, i) => (
                                <div key={m.column} className="flex items-center justify-between gap-3">
                                    <span className="text-sm font-mono text-brand-ink truncate">{m.column}</span>
                                    <Select value={m.target} onValueChange={(v) => setMapping(mapping.map((x, j) => j === i ? { ...x, target: v } : x))}>
                                        <SelectTrigger className="w-40" data-testid={`product-import-map-${i}`}><SelectValue /></SelectTrigger>
                                        <SelectContent>{TARGETS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                                    </Select>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    {step === 2 && <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" disabled={busy} onClick={execute} data-testid="product-import-execute">{busy ? "Importing…" : "Import"}</Button>}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function SourcingDialog({ open, onClose, onDone }) {
    const [providers, setProviders] = useState([]);
    const [busy, setBusy] = useState(null);

    useEffect(() => {
        if (!open) return;
        api.get("/store/sourcing/providers").then((r) => setProviders(r.data.providers || [])).catch(() => setProviders([]));
    }, [open]);

    async function run(provider) {
        setBusy(provider);
        try {
            const { data } = await api.post("/store/sourcing/import", { provider, limit: 50 });
            toast.success(`Imported ${data.imported} product(s)` + (data.updated ? `, updated ${data.updated}` : ""));
            onDone();
        } catch (e) { toast.error(e?.response?.data?.detail || "Import failed"); }
        finally { setBusy(null); }
    }

    return (
        <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
            <DialogContent className="max-w-lg">
                <DialogHeader><DialogTitle>Source products</DialogTitle></DialogHeader>
                <p className="text-sm text-zinc-500 mb-2">Add products to sell. Start with our built-in catalog, or dropship from a connected supplier.</p>
                <div className="space-y-3">
                    {providers.map((p) => (
                        <div key={p.key} className="flex items-start justify-between gap-3 border border-brand-line rounded-lg p-3" data-testid={`sourcing-${p.key}`}>
                            <div className="min-w-0">
                                <div className="font-medium text-brand-ink flex items-center gap-2">
                                    {p.label}
                                    {p.ready
                                        ? <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">Ready</span>
                                        : <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800">Needs setup</span>}
                                </div>
                                <div className="text-xs text-zinc-500 mt-0.5">{p.needs}</div>
                            </div>
                            <Button size="sm" disabled={busy === p.key} onClick={() => run(p.key)}
                                className="bg-brand-copper hover:bg-brand-copperHover text-white shrink-0"
                                data-testid={`sourcing-import-${p.key}`}>{busy === p.key ? "Importing…" : "Import"}</Button>
                        </div>
                    ))}
                    {!providers.length && <div className="text-sm text-zinc-400 py-4 text-center">Loading sources…</div>}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Close</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

