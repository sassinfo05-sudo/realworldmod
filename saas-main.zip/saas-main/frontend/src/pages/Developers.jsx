import usePageMeta from "@/hooks/usePageMeta";
import PublicNav from "@/components/PublicNav";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, KeyRound, Webhook, Terminal, ShieldCheck, Boxes } from "lucide-react";
import { useBrand } from "@/context/BrandContext";

function Code({ children }) {
    return (
        <pre className="mt-3 rounded-xl bg-brand-ink text-zinc-100 text-[13px] leading-relaxed p-4 overflow-auto border border-black/20">
            <code>{children}</code>
        </pre>
    );
}

function Endpoint({ method, path, desc }) {
    const color = { GET: "text-emerald-600 bg-emerald-50", POST: "text-indigo-600 bg-indigo-50", PUT: "text-amber-600 bg-amber-50", DELETE: "text-red-600 bg-red-50" }[method] || "text-zinc-600 bg-zinc-100";
    return (
        <div className="flex items-start gap-3 py-2.5 border-b border-brand-line last:border-b-0">
            <span className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded ${color}`}>{method}</span>
            <div className="min-w-0">
                <div className="font-mono text-sm text-brand-ink break-all">{path}</div>
                <div className="text-xs text-zinc-500 mt-0.5">{desc}</div>
            </div>
        </div>
    );
}

export default function Developers() {
    const brand = useBrand();
    const name = brand?.name || "Zanelvo";
    usePageMeta(`Developers — ${name}`);

    return (
        <div className="min-h-screen bg-brand-cream">
            <PublicNav />
            <section className="max-w-4xl mx-auto px-6 pt-16 pb-24">
                <div className="text-xs uppercase tracking-[0.24em] text-zinc-500 mb-2 flex items-center gap-2"><Terminal className="w-4 h-4 text-brand-copper" /> Developers</div>
                <h1 className="font-display text-4xl md:text-5xl text-brand-ink">Build on {name}</h1>
                <p className="mt-4 text-lg text-zinc-600 max-w-2xl">
                    A clean REST API over your contacts, bookings, invoices and quotes, secured with scoped API keys and
                    signed webhooks. Everything is served under <span className="font-mono text-brand-ink">/api/public/v1</span> at your
                    account&apos;s base URL.
                </p>

                {/* Auth */}
                <div className="mt-14">
                    <h2 className="font-display text-2xl text-brand-ink flex items-center gap-2"><KeyRound className="w-5 h-5 text-brand-copper" /> Authentication</h2>
                    <p className="mt-3 text-zinc-600">
                        Create a scoped API key in your dashboard under <span className="font-medium text-brand-ink">Settings → API keys</span>.
                        Keys start with <span className="font-mono">yv_</span> and carry per-resource scopes like
                        <span className="font-mono"> contacts:read</span> / <span className="font-mono">contacts:write</span>. The full key is shown once.
                        Send it as a bearer token (or the <span className="font-mono">X-Api-Key</span> header):
                    </p>
                    <Code>{`curl https://your-app-url/api/public/v1/contacts \\
  -H "Authorization: Bearer yv_live_xxx"`}</Code>
                    <Link to="/app/setup/api-keys" className="inline-flex items-center gap-1 mt-3 text-brand-copper text-sm font-medium">
                        Manage API keys <ArrowRight className="w-4 h-4" />
                    </Link>
                </div>

                {/* Endpoints */}
                <div className="mt-14">
                    <h2 className="font-display text-2xl text-brand-ink flex items-center gap-2"><Boxes className="w-5 h-5 text-brand-copper" /> Core endpoints</h2>
                    <p className="mt-3 text-zinc-600">All responses are JSON; ids are UUIDs. Each call needs the matching scope.</p>
                    <div className="mt-5 rounded-2xl border border-brand-line bg-white p-5">
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Contacts (CRM)</div>
                        <Endpoint method="GET" path="/api/public/v1/contacts" desc="List CRM contacts (scope contacts:read)." />
                        <Endpoint method="POST" path="/api/public/v1/contacts" desc="Create or upsert a contact by email (scope contacts:write)." />
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1 mt-5">Bookings</div>
                        <Endpoint method="GET" path="/api/public/v1/bookings" desc="List bookings (scope bookings:read)." />
                        <Endpoint method="POST" path="/api/public/v1/bookings" desc="Create a booking (scope bookings:write)." />
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1 mt-5">Billing</div>
                        <Endpoint method="GET" path="/api/public/v1/invoices" desc="List invoices (scope invoices:read)." />
                        <Endpoint method="GET" path="/api/public/v1/quotes" desc="List quotes (scope quotes:read)." />
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1 mt-5">Identity</div>
                        <Endpoint method="GET" path="/api/public/v1/whoami" desc="Confirm which account and scopes a key maps to." />
                    </div>
                    <p className="mt-3 text-xs text-zinc-500">The full interactive schema is available at <span className="font-mono">/docs</span> on your backend.</p>
                </div>

                {/* Webhooks */}
                <div className="mt-14">
                    <h2 className="font-display text-2xl text-brand-ink flex items-center gap-2"><Webhook className="w-5 h-5 text-brand-copper" /> Webhooks</h2>
                    <p className="mt-3 text-zinc-600">
                        Subscribe to events (order paid, form submitted, booking created, and more) in
                        <span className="font-medium text-brand-ink"> Settings → Webhooks</span>. We POST a signed JSON
                        payload to your endpoint and retry with backoff, with a dead-letter queue and one-click replay.
                    </p>
                    <p className="mt-3 text-zinc-600">Every delivery carries an HMAC signature header you should verify:</p>
                    <Code>{`X-Zanelvo-Signature: sha256=<hex>

# verify (python)
import hmac, hashlib
expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
assert hmac.compare_digest(expected, header_value)`}</Code>
                </div>

                {/* Rate limits / safety */}
                <div className="mt-14">
                    <h2 className="font-display text-2xl text-brand-ink flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-brand-copper" /> Limits & safety</h2>
                    <ul className="mt-3 space-y-2 text-zinc-600 list-disc pl-5">
                        <li>Requests are rate-limited per key; back off on <span className="font-mono">429</span> responses.</li>
                        <li>Amounts are always computed server-side — clients never set prices or totals.</li>
                        <li>Keys are scoped; a read key cannot write. Rotate or revoke keys anytime.</li>
                        <li>All outbound URLs you configure are checked against SSRF (no private IPs).</li>
                    </ul>
                </div>

                <div className="mt-16 rounded-2xl border border-brand-line bg-white p-8 text-center">
                    <h3 className="font-display text-2xl text-brand-ink">Ready to build?</h3>
                    <p className="mt-2 text-zinc-600">Spin up a key and make your first call in under a minute.</p>
                    <Link to="/app/setup/api-keys" className="inline-block mt-5" data-testid="developers-cta-btn">
                        <Button size="lg" className="bg-brand-copper hover:bg-brand-copperHover text-white">
                            Get an API key <ArrowRight className="ml-2 w-4 h-4" />
                        </Button>
                    </Link>
                </div>
            </section>
        </div>
    );
}
