import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { StatCard, TrendChart, fmtValue } from "@/components/InsightsDashboard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Globe2, CreditCard, Users, Inbox, Calendar, Store, Megaphone, Bot, Pencil, Sparkles, Layers } from "lucide-react";

const AREAS = [
    { key: "website", label: "Website", icon: Globe2, to: "/app/analytics", color: "#4F46E5" },
    { key: "payments", label: "Payments", icon: CreditCard, to: "/app/payments", color: "#059669" },
    { key: "crm", label: "Contacts", icon: Users, to: "/app/crm", color: "#0EA5E9" },
    { key: "inbox", label: "Inbox", icon: Inbox, to: "/app/inbox", color: "#D6289B" },
    { key: "bookings", label: "Bookings", icon: Calendar, to: "/app/calendar", color: "#F59E0B" },
    { key: "store", label: "Store", icon: Store, to: "/app/store/orders", color: "#8B5CF6" },
    { key: "marketing", label: "Marketing", icon: Megaphone, to: "/app/marketing", color: "#EF4444" },
    { key: "ai", label: "AI employees", icon: Bot, to: "/app/ai", color: "#14B8A6" },
];

export default function Overview() {
    const { user } = useAuth();
    const [data, setData] = useState(null);
    const [sites, setSites] = useState(null);
    useEffect(() => {
        api.get("/insights/overview", { params: { days: 30 } }).then((r) => setData(r.data)).catch(() => setData({ areas: {} }));
        api.get("/sites").then((r) => setSites(r.data)).catch(() => {});
    }, []);
    const active = sites?.sites?.find((s) => s.is_active);
    const hour = new Date().getHours();
    const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
    const hero = data?.areas?.payments?.cards?.[0];
    const views = data?.areas?.website?.cards?.[0];
    const contacts = data?.areas?.crm?.cards?.[1];
    return (
        <div className="px-4 md:px-8 py-6 md:py-8 max-w-[1400px] mx-auto" data-testid="overview-page">
            {/* Hero */}
            <div className="rounded-3xl p-6 md:p-8 text-white relative overflow-hidden bg-[linear-gradient(120deg,#4F46E5_0%,#7C3AED_45%,#D6289B_100%)] shadow-[0_30px_60px_-30px_rgba(79,70,229,0.7)]">
                <div className="absolute -right-20 -top-24 w-72 h-72 rounded-full bg-white/10 blur-2xl" />
                <div className="absolute right-24 bottom-[-80px] w-56 h-56 rounded-full bg-amber-300/20 blur-2xl" />
                <div className="relative flex flex-wrap items-end justify-between gap-6">
                    <div>
                        <div className="text-xs uppercase tracking-[0.2em] opacity-80">{greet}</div>
                        <h1 className="font-display text-3xl md:text-4xl mt-1">{user?.full_name?.split(" ")[0] || user?.org_name || "Welcome back"}</h1>
                        <p className="mt-2 text-sm opacity-90 max-w-lg">
                            {active ? <>Your site <b>{active.name}</b> is {active.maintenance?.enabled ? "in private mode" : active.status === "published" ? "live" : "a draft"}. Here's the last 30 days at a glance.</> : "Here's the last 30 days at a glance."}
                        </p>
                        <div className="mt-5 flex flex-wrap gap-2">
                            <Button asChild className="bg-white text-brand-copper hover:bg-white/90 shadow-none"><Link to="/app/editor" data-testid="overview-edit-site"><Pencil className="w-4 h-4" /> Edit website</Link></Button>
                            <Button asChild variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20"><Link to="/app/sites"><Layers className="w-4 h-4" /> Sites & maintenance</Link></Button>
                            <Button asChild variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20"><Link to="/app/setup"><Sparkles className="w-4 h-4" /> Setup center</Link></Button>
                        </div>
                    </div>
                    <div className="grid grid-cols-3 gap-3 md:gap-5">
                        {[hero, views, contacts].map((c, i) => c ? (
                            <div key={i} className="rounded-2xl bg-white/15 backdrop-blur px-4 py-3 min-w-[110px]">
                                <div className="text-[10px] uppercase tracking-widest opacity-80">{c.label}</div>
                                <div className="text-2xl font-semibold mt-1 tabular-nums">{fmtValue(c.value, c.format)}</div>
                                <div className="text-[11px] opacity-80">{c.delta_pct === null || c.delta_pct === undefined ? "30 days" : `${c.delta_pct > 0 ? "+" : ""}${c.delta_pct}%`}</div>
                            </div>
                        ) : <div key={i} className="rounded-2xl bg-white/10 h-20 w-28 animate-pulse" />)}
                    </div>
                </div>
            </div>

            {/* Area tiles */}
            <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4 mt-6">
                {AREAS.map((a) => {
                    const d = data?.areas?.[a.key];
                    const Icon = a.icon;
                    return (
                        <Link key={a.key} to={a.to} className="rounded-2xl border border-brand-line bg-white dark:bg-zinc-900 p-5 hover:shadow-[0_16px_40px_-20px_rgba(0,0,0,0.25)] hover:-translate-y-0.5 transition group" data-testid={`overview-tile-${a.key}`}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2"><span className="w-8 h-8 rounded-lg grid place-items-center text-white" style={{ background: a.color }}><Icon className="w-4 h-4" /></span><span className="font-medium text-sm">{a.label}</span></div>
                                <ArrowRight className="w-4 h-4 text-zinc-300 group-hover:text-brand-copper group-hover:translate-x-0.5 transition" />
                            </div>
                            <div className="mt-4 grid grid-cols-3 gap-2">
                                {(d?.cards || [1, 2, 3]).map((c, i) => typeof c === "object" ? (
                                    <div key={c.key}><div className="text-lg font-semibold tabular-nums">{fmtValue(c.value, c.format)}</div><div className="text-[10px] text-zinc-500 leading-tight">{c.label}</div></div>
                                ) : <div key={i} className="h-9 rounded bg-zinc-50 animate-pulse" />)}
                            </div>
                            <div className="mt-3 -mx-2">{d ? <TrendChart data={d.series} color={a.color} height={70} /> : <div className="h-[70px]" />}</div>
                        </Link>
                    );
                })}
            </div>
        </div>
    );
}
