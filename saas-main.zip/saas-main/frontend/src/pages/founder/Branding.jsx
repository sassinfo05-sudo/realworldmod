import React, { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Save, Globe } from "lucide-react";

const FIELDS = [
    { key: "brand_name", label: "Product / brand name", help: "Shown in the logo, dashboard, emails and browser title — everywhere." },
    { key: "product_url", label: "Public website URL", help: "Used in emails, sitemaps and share links." },
    { key: "support_email", label: "Support email", help: "Where customer replies and help requests go." },
    { key: "company_name", label: "Legal company name", help: "Shown in the footer and legal pages." },
    { key: "company_address", label: "Company address", help: "Optional — footer + invoices." },
    { key: "footer_note", label: "Footer note", help: "Optional small print in the site footer." },
];

export default function Branding() {
    const [form, setForm] = useState(null);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        api.get("/founder/settings").then((r) => setForm(r.data)).catch(() => toast.error("Failed to load settings"));
    }, []);

    async function save() {
        setSaving(true);
        try {
            const patch = {};
            FIELDS.forEach((f) => { patch[f.key] = form[f.key] || ""; });
            const { data } = await api.put("/founder/settings", patch);
            setForm(data);
            toast.success("Saved — changes are live across the product");
        } catch (e) {
            toast.error("Save failed");
        } finally { setSaving(false); }
    }

    if (!form) return <div className="p-8 text-zinc-500">Loading…</div>;

    return (
        <div className="p-6 md:p-8 max-w-3xl" data-testid="founder-branding">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-2"><Globe className="w-4 h-4" /> White-label</div>
            <h1 className="font-display text-3xl text-brand-ink">Brand &amp; identity</h1>
            <p className="mt-2 text-sm text-zinc-500">Rename the whole platform. These values propagate to the public site, dashboard, emails and metadata instantly.</p>

            <div className="mt-8 space-y-5">
                {FIELDS.map((f) => (
                    <div key={f.key}>
                        <label className="block text-sm font-medium text-brand-ink mb-1">{f.label}</label>
                        <input
                            data-testid={`branding-${f.key}`}
                            value={form[f.key] || ""}
                            onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                            className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm text-brand-ink outline-none focus:ring-2 focus:ring-brand-copper/30"
                        />
                        <div className="mt-1 text-xs text-zinc-400">{f.help}</div>
                    </div>
                ))}
            </div>

            <div className="mt-8">
                <Button onClick={save} disabled={saving} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="branding-save">
                    <Save className="w-4 h-4 mr-1.5" /> {saving ? "Saving…" : "Save changes"}
                </Button>
            </div>
        </div>
    );
}
