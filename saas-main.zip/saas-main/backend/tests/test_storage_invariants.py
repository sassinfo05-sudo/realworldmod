"""Storage invariant regression — the four direct invariants from the Round-18 brief plus the
concurrency / expiry / signed-URL / provider-switch / reference-protection guarantees.

Mix of HTTP integration tests (against the running API) and direct-service async tests (which
monkeypatch the storage provider to exercise failure + provider-switch paths deterministically).
"""
from __future__ import annotations

import asyncio
import base64
import os
import secrets
import threading
import uuid
from datetime import datetime, timedelta, timezone

import pytest
import requests

import _creds

API = _creds.api()

# valid 2x2 png
PNG_B64 = ("iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGM8YWTEwMDAxMDAwMDAAAAO0AEwUN+6GAAAAABJRU5ErkJggg==")
PNG_BYTES = 79
PNG_RAW = base64.b64decode(PNG_B64)


def _hdr(tok):
    ip = f"10.{secrets.randbelow(250)}.{secrets.randbelow(250)}.{secrets.randbelow(250)}"
    return {"Authorization": f"Bearer {tok}", "X-Forwarded-For": ip}


def _signup():
    ip = f"10.{secrets.randbelow(250)}.{secrets.randbelow(250)}.{secrets.randbelow(250)}"
    email = f"inv-{uuid.uuid4().hex[:10]}@example.com"
    r = requests.post(f"{API}/auth/signup", headers={"X-Forwarded-For": ip},
                      json={"email": email, "password": "InvTest-Pass1!", "full_name": "Inv",
                            "business_name": f"Inv {uuid.uuid4().hex[:4]}"}, timeout=30)
    assert r.status_code in (200, 201), r.text
    tok = r.json()["access_token"]
    me = requests.get(f"{API}/auth/me", headers=_hdr(tok), timeout=30).json()
    return {"token": tok, "org_id": me.get("org_id")}


def _db():
    from pymongo import MongoClient
    return MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]


def _set_plan(org_id, plan="autopilot"):
    _db().subscriptions.update_one({"org_id": org_id}, {"$set": {"plan_code": plan, "status": "active"}}, upsert=True)


def _override(org_id, nbytes):
    _db().storage_overrides.update_one({"org_id": org_id}, {"$set": {"org_id": org_id, "bytes": int(nbytes)}}, upsert=True)


def _init(tok, size, mime="image/png", visibility="public", idem=None):
    body = {"filename": "px.png", "mime": mime, "size": size, "visibility": visibility}
    if idem:
        body["idempotency_key"] = idem
    return requests.post(f"{API}/assets/upload/init", headers=_hdr(tok), json=body, timeout=30)


def _finalize(tok, uid, data=PNG_B64):
    return requests.post(f"{API}/assets/upload/{uid}/finalize", headers=_hdr(tok),
                         json={"data_base64": data}, timeout=30)


def _usage(tok):
    return requests.get(f"{API}/assets/usage", headers=_hdr(tok), timeout=30).json()


# ============================ INVARIANT 1: actual-size bypass ============================
def test_actual_size_quota_bypass_blocked():
    """Reserve 1 byte, then try to finalize a real (larger) object. The server must NOT trust the
    declared size: it reconciles the REAL bytes against the allowance and rejects when over quota,
    and must leave no reserved bytes behind."""
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    _override(o["org_id"], 40)  # allowance below the real png size
    init = _init(tok, size=1)  # reserving a single byte fits under 40
    assert init.status_code == 200, init.text
    uid = init.json()["upload_id"]
    fin = _finalize(tok, uid)
    assert fin.status_code == 402, fin.text
    assert fin.json()["detail"]["error"] == "storage_limit_reached"
    u = _usage(tok)
    assert u["reserved_bytes"] == 0 and u["active_bytes"] == 0  # nothing leaked


# ============================ INVARIANT 2: reservation leak on provider failure ============
def test_reservation_released_on_provider_failure(monkeypatch):
    """A provider exception (e.g. boto3 error) during finalize must release the reservation — the
    tenant is never charged for bytes that were never stored."""
    from app.services import assets as A
    from app.services import storage as S
    from app import db as dbmod

    org_id = "invtest-" + uuid.uuid4().hex[:12]
    _set_plan(org_id)

    class Boom:
        provider = "boom"; bucket = None; endpoint = None; region = None; public_base = None
        async def put(self, *a, **k):
            raise RuntimeError("kaboom from provider")
        async def head(self, *a, **k):
            return {"exists": False}

    async def _boom():
        return Boom()

    async def scenario():
        monkeypatch.setattr(S, "get_provider", _boom)
        init = await A.init_upload(org_id, "u", filename="a.png", mime="image/png", size=PNG_BYTES)
        uid = init["upload_id"]
        before = await A.usage_summary(org_id)
        assert before["reserved_bytes"] >= PNG_BYTES
        from fastapi import HTTPException
        with pytest.raises(HTTPException) as ei:
            await A.finalize_upload(org_id, "u", uid, PNG_RAW)
        assert ei.value.status_code == 502
        after = await A.usage_summary(org_id)
        assert after["reserved_bytes"] == 0 and after["active_bytes"] == 0

    dbmod._mongo_client = None  # fresh motor client bound to this loop
    try:
        asyncio.run(scenario())
    finally:
        _db().subscriptions.delete_many({"org_id": org_id})
        _db().storage_usage.delete_many({"org_id": org_id})
        _db().upload_reservations.delete_many({"org_id": org_id})


# ============================ INVARIANT 3: signed-URL expiry ============================
def test_signed_url_expiry_matches_requested():
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    init = _init(tok, size=PNG_BYTES, visibility="private")
    uid = init.json()["upload_id"]
    asset = _finalize(tok, uid).json()
    r = requests.get(f"{API}/assets/{asset['id']}/signed-url?ttl=3600", headers=_hdr(tok), timeout=30)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["expires_in"] == 3600
    exp = datetime.fromisoformat(body["expires_at"].replace("Z", "+00:00"))
    delta = (exp - datetime.now(timezone.utc)).total_seconds()
    assert 3000 < delta <= 3600, f"expiry not ~1h in the future: {delta}s"


# ============================ INVARIANT 4: provider switch ============================
def test_provider_switch_keeps_old_assets_readable(monkeypatch):
    """An asset written under provider A must keep resolving through provider A even after the
    tenant's active provider is switched to B."""
    from app.services import assets as A
    from app.services import storage as S
    from app import db as dbmod

    org_id = "invswitch-" + uuid.uuid4().hex[:12]
    _set_plan(org_id)

    async def scenario():
        # Upload under the default local provider (config_version 0).
        init = await A.init_upload(org_id, "u", filename="a.png", mime="image/png", size=PNG_BYTES)
        asset = await A.finalize_upload(org_id, "u", init["upload_id"], PNG_RAW)
        assert asset["provider"] == "local"
        recorded_ver = asset["provider_config_version"]
        # Now switch the ACTIVE storage config to a different (bogus) provider version.
        await S.save_storage_config({"provider": "r2", "bucket": "new-bucket",
                                     "access_key_id": "AK", "secret_access_key": "SK",
                                     "endpoint": "https://example.r2.dev"})
        assert await S.current_config_version() > recorded_ver
        # The OLD asset must still resolve through its recorded provider (local), unaffected.
        prov = await S.get_provider_for(asset)
        assert getattr(prov, "provider", None) == "local"
        data = await prov.get(asset["object_key"])  # readable from where it was written
        assert data and len(data) > 0
        return True

    dbmod._mongo_client = None
    try:
        assert asyncio.run(scenario()) is True
    finally:
        _db().subscriptions.delete_many({"org_id": org_id})
        _db().storage_usage.delete_many({"org_id": org_id})
        _db().assets.delete_many({"org_id": org_id})
        _db().upload_reservations.delete_many({"org_id": org_id})
        # reset active storage config so other tests/dev use local again
        _db().platform_settings.update_one({"key": "primary"}, {"$unset": {"storage": ""}})


# ============================ concurrency: single reservation per idempotency key ============
def test_concurrent_init_single_reservation():
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    idem = uuid.uuid4().hex
    results = {}

    def go(i):
        results[i] = _init(tok, size=PNG_BYTES, idem=idem)

    threads = [threading.Thread(target=go, args=(i,)) for i in range(6)]
    for t in threads: t.start()
    for t in threads: t.join()
    ok = [r for r in results.values() if r.status_code == 200]
    ids = {r.json()["upload_id"] for r in ok}
    assert len(ids) == 1, f"expected exactly one reservation id, got {ids}"
    u = _usage(tok)
    assert u["reserved_bytes"] == PNG_BYTES  # reserved ONCE, not six times


# ============================ duplicate finalize rejected ============================
def test_duplicate_finalize_rejected():
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    uid = _init(tok, size=PNG_BYTES).json()["upload_id"]
    first = _finalize(tok, uid)
    assert first.status_code == 200, first.text
    second = _finalize(tok, uid)
    assert second.status_code == 409, second.text


# ============================ abandoned reservation expiry ============================
def test_abandoned_reservation_expiry_released():
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    uid = _init(tok, size=PNG_BYTES).json()["upload_id"]
    assert _usage(tok)["reserved_bytes"] == PNG_BYTES
    # Force the reservation to look abandoned (expired in the past).
    past = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat().replace("+00:00", "Z")
    _db().upload_reservations.update_one({"id": uid}, {"$set": {"expires_at": past}})
    # A fresh init opportunistically sweeps this tenant's expired reservations first.
    _init(tok, size=PNG_BYTES, idem=uuid.uuid4().hex)
    resv = _db().upload_reservations.find_one({"id": uid})
    assert resv["status"] == "expired"
    # Only the new reservation's bytes are held (the abandoned one was released).
    assert _usage(tok)["reserved_bytes"] == PNG_BYTES


# ============================ referenced asset purge protection ============================
def test_referenced_asset_cannot_be_purged():
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    asset = _finalize(tok, _init(tok, size=PNG_BYTES).json()["upload_id"]).json()
    aid = asset["id"]
    ref = requests.post(f"{API}/assets/{aid}/references", headers=_hdr(tok),
                        json={"feature": "website", "record_id": "home-hero"}, timeout=30)
    assert ref.status_code == 200, ref.text
    assert requests.post(f"{API}/assets/{aid}/trash", headers=_hdr(tok), timeout=30).status_code == 200
    blocked = requests.delete(f"{API}/assets/{aid}", headers=_hdr(tok), timeout=30)
    assert blocked.status_code == 409 and blocked.json()["detail"]["error"] == "asset_referenced"
    forced = requests.delete(f"{API}/assets/{aid}?force=true", headers=_hdr(tok), timeout=30)
    assert forced.status_code == 200 and forced.json()["freed_bytes"] > 0


# ============================ private asset stays private / oversized rejected ============================
def test_oversized_direct_upload_rejected():
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    big = _init(tok, size=999_999_999)
    assert big.status_code == 413


def test_private_asset_served_only_with_signature():
    o = _signup(); _set_plan(o["org_id"]); tok = o["token"]
    asset = _finalize(tok, _init(tok, size=PNG_BYTES, visibility="private").json()["upload_id"]).json()
    assert "sig=" in asset["url"]
    assert requests.get(f"{_creds.base_url()}{asset['url']}", timeout=30).status_code == 200
    # Without a valid signature the private blob is refused (no manufactured public URL).
    key = asset["object_key"]
    bare = requests.get(f"{_creds.base_url()}/api/assets/blob/{key}", timeout=30)
    assert bare.status_code in (403, 404)
