"""Phase 6 follow-up fixes — regression + acceptance tests.

Covers:
    * Entitlement enforcement at write time (contacts create, CSV import batch, team invite,
        public AI chat over-cap fallback, website creation cap).
    * Scoped impersonation tokens (owner-context on target org, expiry, end, actions_count bump,
        audit tagging with impersonation_session_id).
    * Free-plan branding flag on public site payloads.
    * POST /api/public/v1/bookings with bookings:write scope, past-date guard.
"""
from __future__ import annotations

import io
import os
import time
import uuid
from datetime import datetime, timedelta, timezone

import pytest
import requests
from tests import _creds as _CREDS  # creds from env / test_credentials.md

# Load backend .env if not present in process env (agent may run with a stripped env)
_env_path = "/app/backend/.env"
if os.path.exists(_env_path):
    for line in open(_env_path):
        if "=" in line and not line.strip().startswith("#"):
            k, _, v = line.strip().partition("=")
            v = v.strip().strip('"').strip("'")
            os.environ.setdefault(k, v)
_fe_env = "/app/frontend/.env"
if os.path.exists(_fe_env):
    for line in open(_fe_env):
        if line.startswith("REACT_APP_BACKEND_URL"):
            _, _, v = line.strip().partition("=")
            os.environ.setdefault("REACT_APP_BACKEND_URL", v.strip().strip('"'))

BASE_URL = _CREDS.BASE_URL
assert BASE_URL, "REACT_APP_BACKEND_URL must be set"

FOUNDER = ("founder@revenueos.com", "nNYT8HwGxRPN6aeeP7")
FREE_OWNER = ("owner@free-demo.revenueos.com", "W2kFHiWBvJMUJyHC")
AUTOPILOT_OWNER = ("owner@demo.revenueos.com", "RS4zXizwfYBVtS2X")


def _login(email: str, password: str) -> str:
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": email, "password": password}, timeout=15)
    if r.status_code != 200:
        pytest.skip(f"Login failed for {email}: {r.status_code} {r.text[:200]}")
    return r.json()["access_token"]


def _headers(tok: str) -> dict:
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}


# ---------- shared fixtures ----------

@pytest.fixture(scope="module")
def founder_token():
    return _login(*FOUNDER)


@pytest.fixture(scope="module")
def free_token():
    return _login(*FREE_OWNER)


@pytest.fixture(scope="module")
def autopilot_token():
    return _login(*AUTOPILOT_OWNER)


def _me_org_id(tok: str) -> str:
    r = requests.get(f"{BASE_URL}/api/auth/me", headers=_headers(tok), timeout=10)
    assert r.status_code == 200, f"me: {r.status_code} {r.text[:200]}"
    d = r.json()
    return d.get("org_id") or d.get("user", {}).get("org_id")


@pytest.fixture(scope="module")
def free_org_id(free_token):
    return _me_org_id(free_token)


@pytest.fixture(scope="module")
def autopilot_org_id(autopilot_token):
    return _me_org_id(autopilot_token)


# ============================================================
# BLOCKER-FIX #1: Contacts entitlement enforcement
# ============================================================

def test_01_contacts_cap_free_org(free_token):
    h = _headers(free_token)
    # Count current contacts
    r = requests.get(f"{BASE_URL}/api/crm/contacts?limit=500", headers=h, timeout=15)
    assert r.status_code == 200
    existing = r.json().get("contacts", [])
    existing_count = len(existing)
    # Free plan cap = 100. Top up to 100 with TEST_ prefixed contacts.
    to_create = max(0, 100 - existing_count)
    created_ids = []
    for i in range(to_create):
        payload = {"display_name": f"TEST_cap_{uuid.uuid4().hex[:8]}",
                    "emails": [f"TEST_cap_{uuid.uuid4().hex[:8]}@example.com"]}
        r = requests.post(f"{BASE_URL}/api/crm/contacts", headers=h, json=payload, timeout=15)
        assert r.status_code == 200, f"top-up create failed at {i}: {r.status_code} {r.text[:200]}"
        created_ids.append(r.json().get("id"))
    # Now the 101st (or over-cap) must be blocked with HTTP 402
    payload = {"display_name": "TEST_over_cap",
                "emails": [f"TEST_overcap_{uuid.uuid4().hex[:8]}@example.com"]}
    r = requests.post(f"{BASE_URL}/api/crm/contacts", headers=h, json=payload, timeout=15)
    assert r.status_code == 402, f"Expected 402 got {r.status_code}: {r.text[:200]}"
    body = r.json().get("detail") or r.json()
    assert body.get("error") == "plan_limit_reached"
    assert body.get("meter") == "contacts" or body.get("feature") == "contacts"
    assert body.get("plan_code") == "free"
    assert body.get("cap") == 100
    assert body.get("used") >= 100
    assert body.get("upgrade_url") == "/app/billing"
    # Cleanup — delete only what we created
    for cid in created_ids:
        try:
            requests.post(f"{BASE_URL}/api/crm/contacts/bulk", headers=h,
                          json={"ids": [cid], "action": "delete"}, timeout=10)
        except Exception:
            pass


# ============================================================
# BLOCKER-FIX #1b: CSV import batch pre-check
# ============================================================

def _cleanup_test_contacts(token, tag_marker="TEST_csv_"):
    h = _headers(token)
    r = requests.get(f"{BASE_URL}/api/crm/contacts?limit=500", headers=h, timeout=15)
    if r.status_code != 200:
        return
    ids = [c["id"] for c in r.json().get("contacts", []) if tag_marker in (c.get("display_name") or "")]
    if ids:
        requests.post(f"{BASE_URL}/api/crm/contacts/bulk", headers=h,
                      json={"ids": ids, "action": "delete"}, timeout=15)


def test_02_csv_import_batch_precheck(free_token):
    h = _headers(free_token)
    _cleanup_test_contacts(free_token, "TEST_")
    # After cleanup, top up so we sit near cap (say 90 contacts). Cap is 100.
    r = requests.get(f"{BASE_URL}/api/crm/contacts?limit=500", headers=h, timeout=15)
    existing = len(r.json().get("contacts", []))
    to_create = max(0, 90 - existing)
    created = []
    for _ in range(to_create):
        u = uuid.uuid4().hex[:8]
        rr = requests.post(f"{BASE_URL}/api/crm/contacts", headers=h,
                           json={"display_name": f"TEST_csv_seed_{u}",
                                  "emails": [f"TEST_csv_seed_{u}@example.com"]}, timeout=10)
        if rr.status_code == 200:
            created.append(rr.json().get("id"))

    # Baseline count now
    r = requests.get(f"{BASE_URL}/api/crm/contacts?limit=500", headers=h, timeout=15)
    baseline_count = len(r.json().get("contacts", []))

    # Analyze CSV with 20 net-new rows (over cap: baseline + 20 > 100)
    rows = ["email,name"]
    for _ in range(20):
        u = uuid.uuid4().hex[:8]
        rows.append(f"TEST_csv_new_{u}@example.com,TEST_csv_new_{u}")
    csv_body = "\n".join(rows).encode()
    files = {"file": ("t.csv", csv_body, "text/csv")}
    hh = {"Authorization": f"Bearer {free_token}"}
    r = requests.post(f"{BASE_URL}/api/crm/import/analyze", headers=hh, files=files, timeout=20)
    assert r.status_code == 200, f"analyze failed: {r.status_code} {r.text[:200]}"
    run_id = r.json()["run_id"]
    mapping = r.json()["proposed_mapping"]
    # Execute — must 402 BEFORE any inserts
    r = requests.post(f"{BASE_URL}/api/crm/import/{run_id}/execute",
                      headers=_headers(free_token),
                      json={"mapping": mapping, "on_duplicate": "update"}, timeout=20)
    assert r.status_code == 402, f"Expected 402 got {r.status_code}: {r.text[:200]}"
    # Verify no inserts happened
    r2 = requests.get(f"{BASE_URL}/api/crm/contacts?limit=500", headers=h, timeout=15)
    assert len(r2.json().get("contacts", [])) == baseline_count, "Import inserted rows despite over-cap"

    # Now analyze a small 5-row CSV — should succeed (90 + 5 <= 100)
    rows2 = ["email,name"]
    for _ in range(5):
        u = uuid.uuid4().hex[:8]
        rows2.append(f"TEST_csv_ok_{u}@example.com,TEST_csv_ok_{u}")
    files2 = {"file": ("t.csv", "\n".join(rows2).encode(), "text/csv")}
    r = requests.post(f"{BASE_URL}/api/crm/import/analyze", headers=hh, files=files2, timeout=20)
    assert r.status_code == 200
    run_id2 = r.json()["run_id"]
    mapping2 = r.json()["proposed_mapping"]
    r = requests.post(f"{BASE_URL}/api/crm/import/{run_id2}/execute",
                      headers=_headers(free_token),
                      json={"mapping": mapping2, "on_duplicate": "update"}, timeout=30)
    assert r.status_code == 200, f"Small CSV execute failed: {r.status_code} {r.text[:200]}"
    assert r.json().get("created", 0) == 5

    # Cleanup all TEST_csv_* contacts
    _cleanup_test_contacts(free_token, "TEST_csv_")
    for cid in created:
        try:
            requests.post(f"{BASE_URL}/api/crm/contacts/bulk", headers=h,
                          json={"ids": [cid], "action": "delete"}, timeout=10)
        except Exception:
            pass


# ============================================================
# BLOCKER-FIX #1c: Team invite users cap
# ============================================================

def test_03_team_invite_users_cap(free_token):
    h = _headers(free_token)
    payload = {"email": f"TEST_invite_{uuid.uuid4().hex[:8]}@example.com",
                "role": "manager", "full_name": "Test Invite"}
    r = requests.post(f"{BASE_URL}/api/auth/team/invite", headers=h, json=payload, timeout=15)
    assert r.status_code == 402, f"Expected 402 got {r.status_code}: {r.text[:200]}"
    body = r.json().get("detail") or r.json()
    assert body.get("error") == "plan_limit_reached"
    assert body.get("meter") == "users" or body.get("feature") == "users"


# ============================================================
# BLOCKER-FIX #1d: Public AI chat over cap → fallback
# ============================================================

@pytest.mark.asyncio
async def test_04_public_chat_over_cap_fallback(free_org_id):
    # Seed 25 chat_conversations for the free org in current month + ensure a receptionist agent exists.
    from motor.motor_asyncio import AsyncIOMotorClient
    mongo_url = os.environ.get("MONGO_URL")
    db_name = os.environ.get("DB_NAME")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    seeded_ids = []
    for _ in range(25):
        doc = {"org_id": free_org_id, "channel": "chat",
                "session_token": f"TEST_chat_{uuid.uuid4().hex}",
                "status": "closed", "is_sandbox": False,
                "started_at": now_iso, "last_message_at": now_iso,
                "created_at": now_iso, "updated_at": now_iso}
        r = await db.chat_conversations.insert_one(doc)
        seeded_ids.append(r.inserted_id)
    # Ensure an enabled receptionist agent exists for the free org (otherwise the widget
    # short-circuits with "offline" before the entitlement check).
    seeded_agent_id = None
    existing_agent = await db.agents.find_one({"org_id": free_org_id, "agent_type": "receptionist"})
    if existing_agent:
        if not existing_agent.get("enabled"):
            await db.agents.update_one({"_id": existing_agent["_id"]},
                                        {"$set": {"enabled": True, "_test_reenabled": True}})
    else:
        agent_doc = {"org_id": free_org_id, "agent_type": "receptionist",
                      "name": "TEST_receptionist", "enabled": True,
                      "created_at": now_iso, "updated_at": now_iso}
        r = await db.agents.insert_one(agent_doc)
        seeded_agent_id = r.inserted_id
    try:
        # Hit widget start endpoint
        r = requests.post(f"{BASE_URL}/api/public/chat/start",
                          json={"website_slug": "cedar-lane-landscaping"}, timeout=15)
        assert r.status_code == 200, f"Expected 200 got {r.status_code}: {r.text[:200]}"
        body = r.json()
        assert body.get("disabled") is True
        assert body.get("over_limit") is True, f"Expected over_limit=True, got {body}"
        assert isinstance(body.get("greeting"), str) and len(body["greeting"]) > 0
        # Must NOT expose raw 402 / plan_limit_reached error to visitors
        assert "plan_limit" not in body.get("greeting", "").lower()
    finally:
        # Cleanup
        await db.chat_conversations.delete_many({"_id": {"$in": seeded_ids}})
        if seeded_agent_id:
            await db.agents.delete_one({"_id": seeded_agent_id})
        client.close()


# ============================================================
# BLOCKER-FIX #1e: Website creation cap
# ============================================================

def test_05_website_creation_cap_free(free_token):
    h = _headers(free_token)
    # Free org already has 1 website (seeded). websites cap=1.
    payload = {"source_url": "https://example.com"}
    r = requests.post(f"{BASE_URL}/api/import/start", headers=h, json=payload, timeout=20)
    assert r.status_code == 402, f"Expected 402 got {r.status_code}: {r.text[:200]}"
    body = r.json().get("detail") or r.json()
    assert body.get("error") == "plan_limit_reached"
    assert body.get("meter") == "websites" or body.get("feature") == "websites"


# ============================================================
# IMPERSONATION #2a: /founder/impersonate/start
# ============================================================

def test_06a_impersonate_start_validation(founder_token, autopilot_token, free_org_id):
    # Missing reason → 422
    h = _headers(founder_token)
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/start", headers=h,
                      json={"target_org_id": free_org_id}, timeout=15)
    assert r.status_code == 422, f"missing reason: {r.status_code} {r.text[:200]}"
    # Short reason (<6 chars) → 422
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/start", headers=h,
                      json={"target_org_id": free_org_id, "reason": "abc"}, timeout=15)
    assert r.status_code == 422, f"short reason: {r.status_code} {r.text[:200]}"
    # Non-founder role → 403
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/start",
                      headers=_headers(autopilot_token),
                      json={"target_org_id": free_org_id, "reason": "testing owner rejection"},
                      timeout=15)
    assert r.status_code == 403, f"non-founder: {r.status_code}"


@pytest.fixture(scope="module")
def impersonation_ctx(founder_token, free_org_id):
    """Start an impersonation session; yields (session_id, imp_token). Ends session at teardown."""
    h = _headers(founder_token)
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/start", headers=h,
                      json={"target_org_id": free_org_id, "reason": "phase6 followups regression"},
                      timeout=15)
    assert r.status_code == 200, f"impersonate start failed: {r.status_code} {r.text[:200]}"
    body = r.json()
    assert "impersonation_token" in body
    assert body.get("expires_in_minutes") == 30
    yield body["session_id"], body["impersonation_token"]
    # cleanup
    try:
        requests.post(f"{BASE_URL}/api/founder/impersonate/end", headers=h, timeout=10)
    except Exception:
        pass


# ============================================================
# IMPERSONATION #2b: token acts as owner on target org
# ============================================================

def test_06b_impersonate_token_scope(impersonation_ctx, free_org_id):
    sid, tok = impersonation_ctx
    h = _headers(tok)
    # /api/auth/me should show owner role + target org
    r = requests.get(f"{BASE_URL}/api/auth/me", headers=h, timeout=10)
    assert r.status_code == 200
    u = r.json()
    assert (u.get("role") or u.get("user", {}).get("role")) == "owner"
    assert (u.get("org_id") or u.get("user", {}).get("org_id")) == free_org_id
    # Tenant endpoints reachable
    r = requests.get(f"{BASE_URL}/api/billing/subscription", headers=h, timeout=10)
    assert r.status_code == 200, f"subscription: {r.status_code} {r.text[:200]}"
    r = requests.get(f"{BASE_URL}/api/crm/contacts?limit=5", headers=h, timeout=10)
    assert r.status_code == 200, f"contacts: {r.status_code} {r.text[:200]}"
    # Founder-only endpoint should reject impersonation token → 403
    r = requests.get(f"{BASE_URL}/api/founder/cockpit", headers=h, timeout=10)
    assert r.status_code == 403, f"cockpit via imp token: {r.status_code}"


# ============================================================
# IMPERSONATION #2c: actions_count bumps + audit tagging
# ============================================================

def test_06c_impersonate_actions_and_audit(impersonation_ctx, founder_token):
    sid, tok = impersonation_ctx
    fh = _headers(founder_token)
    # Get current actions_count
    r = requests.get(f"{BASE_URL}/api/founder/impersonate/current", headers=fh, timeout=10)
    assert r.status_code == 200
    before = int(r.json().get("session", {}).get("actions_count") or 0)
    # Perform 3 requests using imp token
    for _ in range(3):
        requests.get(f"{BASE_URL}/api/crm/contacts?limit=1", headers=_headers(tok), timeout=10)
    time.sleep(0.5)
    r = requests.get(f"{BASE_URL}/api/founder/impersonate/current", headers=fh, timeout=10)
    after = int(r.json().get("session", {}).get("actions_count") or 0)
    assert after >= before + 3, f"actions_count did not bump: {before} → {after}"

    # Do a mutating action under imp: create a TEST contact
    payload = {"display_name": f"TEST_imp_mut_{uuid.uuid4().hex[:8]}",
                "emails": [f"TEST_imp_{uuid.uuid4().hex[:8]}@example.com"]}
    r = requests.post(f"{BASE_URL}/api/crm/contacts", headers=_headers(tok),
                      json=payload, timeout=10)
    # May succeed (200) or 402 if over cap — either way an audit event may be recorded
    created_id = r.json().get("id") if r.status_code == 200 else None

    # Query audit for imp_sid tagging (via q filter over reason)
    r = requests.get(f"{BASE_URL}/api/founder/audit?limit=100", headers=fh, timeout=10)
    assert r.status_code == 200
    events = r.json().get("events", [])
    tagged = [e for e in events if e.get("impersonation_session_id") == sid]
    assert len(tagged) >= 1, f"No audit events tagged with imp_sid={sid}"
    # start event should be present
    assert any(e.get("action") == "impersonation.start" for e in tagged)

    # cleanup contact
    if created_id:
        requests.post(f"{BASE_URL}/api/crm/contacts/bulk", headers=_headers(tok),
                      json={"ids": [created_id], "action": "delete"}, timeout=10)


# ============================================================
# IMPERSONATION #2d: /impersonate/end kills token
# ============================================================

def test_06d_impersonate_end_invalidates_token(founder_token, free_org_id):
    fh = _headers(founder_token)
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/start", headers=fh,
                      json={"target_org_id": free_org_id, "reason": "end-token invalidation test"},
                      timeout=15)
    assert r.status_code == 200
    tok = r.json()["impersonation_token"]
    sid = r.json()["session_id"]
    # Verify works
    r = requests.get(f"{BASE_URL}/api/auth/me", headers=_headers(tok), timeout=10)
    assert r.status_code == 200
    # End
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/end", headers=fh, timeout=10)
    assert r.status_code == 200
    # Now token should 401
    r = requests.get(f"{BASE_URL}/api/auth/me", headers=_headers(tok), timeout=10)
    assert r.status_code == 401, f"Expected 401 after end, got {r.status_code}: {r.text[:200]}"
    # actions_count preserved in DB (via founder audit / can't directly hit /current after end)
    # Look via audit
    r = requests.get(f"{BASE_URL}/api/founder/audit?limit=50", headers=fh, timeout=10)
    events = r.json().get("events", [])
    assert any(e.get("action") == "impersonation.end" and e.get("impersonation_session_id") == sid
                for e in events)


# ============================================================
# IMPERSONATION #2e: Expired session → 401
# ============================================================

@pytest.mark.asyncio
async def test_06e_impersonate_expiry(founder_token, free_org_id):
    fh = _headers(founder_token)
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/start", headers=fh,
                      json={"target_org_id": free_org_id, "reason": "expiry test session"},
                      timeout=15)
    assert r.status_code == 200
    tok = r.json()["impersonation_token"]
    sid = r.json()["session_id"]
    # Force expiry directly in Mongo
    from motor.motor_asyncio import AsyncIOMotorClient
    from bson import ObjectId
    client = AsyncIOMotorClient(os.environ.get("MONGO_URL"))
    db = client[os.environ.get("DB_NAME")]
    past = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat().replace("+00:00", "Z")
    await db.impersonation_sessions.update_one({"_id": ObjectId(sid)},
                                                {"$set": {"expires_at": past}})
    # Now the token should return 401 (Impersonation session expired)
    r = requests.get(f"{BASE_URL}/api/auth/me", headers=_headers(tok), timeout=10)
    assert r.status_code == 401, f"Expected 401 got {r.status_code}: {r.text[:200]}"
    assert "expired" in r.text.lower()
    # Session should be marked ended
    doc = await db.impersonation_sessions.find_one({"_id": ObjectId(sid)})
    assert doc.get("active") is False
    assert doc.get("exit_reason") == "expired"
    client.close()


# ============================================================
# BRANDING #3: show_platform_branding flag
# ============================================================

def test_07_branding_flag_free_vs_paid():
    r = requests.get(f"{BASE_URL}/api/public/sites/cedar-lane-landscaping", timeout=15)
    assert r.status_code == 200, f"cedar-lane free site: {r.status_code} {r.text[:200]}"
    assert r.json().get("show_platform_branding") is True

    r = requests.get(f"{BASE_URL}/api/public/sites/demo-home-services", timeout=15)
    assert r.status_code == 200
    assert r.json().get("show_platform_branding") is False

    # Page-level under `site` block
    r = requests.get(f"{BASE_URL}/api/public/sites/cedar-lane-landscaping/pages/home", timeout=15)
    assert r.status_code == 200
    assert r.json().get("site", {}).get("show_platform_branding") is True

    r = requests.get(f"{BASE_URL}/api/public/sites/demo-home-services/pages/home", timeout=15)
    assert r.status_code == 200
    assert r.json().get("site", {}).get("show_platform_branding") is False


# ============================================================
# PUBLIC BOOKING API #4
# ============================================================

def _make_api_key(token, scopes):
    r = requests.post(f"{BASE_URL}/api/setup/api-keys", headers=_headers(token),
                      json={"name": f"TEST_key_{uuid.uuid4().hex[:8]}",
                             "scopes": scopes, "env": "live"}, timeout=15)
    assert r.status_code == 200, f"api key create: {r.status_code} {r.text[:200]}"
    return r.json()["id"], r.json()["key"]


def _revoke_api_key(token, kid):
    try:
        requests.post(f"{BASE_URL}/api/setup/api-keys/{kid}/revoke",
                       headers=_headers(token), timeout=10)
    except Exception:
        pass


def test_08_public_bookings_api(autopilot_token, autopilot_org_id):
    # Missing scope → 403 (key has only contacts:read)
    kid_no, key_no = _make_api_key(autopilot_token, ["contacts:read"])
    try:
        r = requests.post(f"{BASE_URL}/api/public/v1/bookings",
                          headers={"Authorization": f"Bearer {key_no}",
                                    "Content-Type": "application/json"},
                          json={"service_id": "x", "start_at": "2030-01-01T10:00:00Z",
                                 "name": "T", "email": "t@example.com"}, timeout=15)
        assert r.status_code == 403, f"missing-scope expected 403 got {r.status_code}: {r.text[:200]}"
    finally:
        _revoke_api_key(autopilot_token, kid_no)

    # Valid key with bookings:write
    kid, key = _make_api_key(autopilot_token, ["bookings:write", "bookings:read"])
    try:
        # Need a real service_id — fetch via public services endpoint (auth not needed)
        r = requests.get(f"{BASE_URL}/api/public/booking/services",
                          params={"website_slug": "demo-home-services"}, timeout=15)
        if r.status_code != 200 or not r.json().get("services"):
            pytest.skip(f"No bookable service available on demo-home-services: {r.status_code}")
        service_id = r.json()["services"][0]["id"]

        # Past start_at → 422
        past = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat().replace("+00:00", "Z")
        r = requests.post(f"{BASE_URL}/api/public/v1/bookings",
                          headers={"Authorization": f"Bearer {key}",
                                    "Content-Type": "application/json"},
                          json={"service_id": service_id, "start_at": past,
                                 "name": "TEST User", "email": "test@example.com"},
                          timeout=15)
        assert r.status_code == 422, f"past date expected 422 got {r.status_code}: {r.text[:200]}"
        body = r.json().get("detail") or r.json()
        # Body shape: {"error":"past_start_at","detail":...}
        if isinstance(body, dict):
            assert body.get("error") == "past_start_at" or "past" in str(body).lower()

        # Valid future start_at — request availability
        d1 = (datetime.now(timezone.utc) + timedelta(days=3)).isoformat().replace("+00:00", "Z")
        d2 = (datetime.now(timezone.utc) + timedelta(days=10)).isoformat().replace("+00:00", "Z")
        r = requests.get(f"{BASE_URL}/api/public/booking/availability",
                          params={"website_slug": "demo-home-services",
                                   "service_id": service_id,
                                   "date_from": d1, "date_to": d2},
                          timeout=15)
        if r.status_code != 200 or not r.json().get("slots"):
            pytest.skip("No availability slot returned")
        slots = r.json().get("slots") or []
        assert slots, "no slots returned"
        # Try slots until one accepts — availability may include already-taken ones on repeat runs.
        booked_response = None
        for slot in slots:
            start_at = slot["start_at"]
            resp = requests.post(f"{BASE_URL}/api/public/v1/bookings",
                                  headers={"Authorization": f"Bearer {key}",
                                            "Content-Type": "application/json"},
                                  json={"service_id": service_id, "start_at": start_at,
                                         "name": "TEST_APIBooking",
                                         "email": "apibook@example.com"},
                                  timeout=20)
            if resp.status_code == 200:
                booked_response = resp
                break
            if resp.status_code == 409:
                continue
            # Any other error — surface it
            assert False, f"unexpected booking status: {resp.status_code} {resp.text[:200]}"
        assert booked_response is not None, "All slots conflicted — cannot verify"
        assert booked_response.json().get("id")
        # Verify booking persisted in the KEY's org
        r2 = requests.get(f"{BASE_URL}/api/public/v1/bookings",
                          headers={"Authorization": f"Bearer {key}"}, timeout=15)
        assert r2.status_code == 200
        assert any(b.get("customer_name") == "TEST_APIBooking"
                    for b in r2.json().get("bookings", []))
    finally:
        _revoke_api_key(autopilot_token, kid)


# ============================================================
# AUDIT LOG #7: filter/search by impersonation_session_id
# ============================================================

def test_09_audit_by_impersonation_session_id(founder_token, free_org_id):
    fh = _headers(founder_token)
    # Start a short impersonation, do a mutation, end it
    r = requests.post(f"{BASE_URL}/api/founder/impersonate/start", headers=fh,
                      json={"target_org_id": free_org_id, "reason": "audit-tagging assertion"},
                      timeout=15)
    assert r.status_code == 200
    body = r.json()
    sid = body["session_id"]
    tok = body["impersonation_token"]
    # Mutation via imp token (may pass or fail — record is what matters)
    requests.post(f"{BASE_URL}/api/crm/contacts", headers=_headers(tok),
                  json={"display_name": f"TEST_audit_{uuid.uuid4().hex[:8]}",
                         "emails": [f"TEST_audit_{uuid.uuid4().hex[:8]}@example.com"]},
                  timeout=10)
    requests.post(f"{BASE_URL}/api/founder/impersonate/end", headers=fh, timeout=10)

    r = requests.get(f"{BASE_URL}/api/founder/audit?limit=200", headers=fh, timeout=15)
    assert r.status_code == 200
    events = r.json().get("events", [])
    tagged = [e for e in events if e.get("impersonation_session_id") == sid]
    actions = {e.get("action") for e in tagged}
    assert "impersonation.start" in actions
    assert "impersonation.end" in actions
    # Free-plan cleanup of any TEST_audit contact
    ftok = _login(*FREE_OWNER)
    _cleanup_test_contacts(ftok, "TEST_audit_")


# ============================================================
# REGRESSION #5 (sanity): show_platform_branding via by-host is present
# (Full Phase 5/6 regressions covered by test_phase6.py — keep this file focused.)
# ============================================================
