import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ShieldCheck, ShieldOff, Copy, Key, AlertTriangle, Mail, MonitorSmartphone, MapPin } from "lucide-react";
import { Switch } from "@/components/ui/switch";

function LoginActivityCard() {
    const [logins, setLogins] = useState(null);
    useEffect(() => {
        api.get("/auth/login-history").then((r) => setLogins(r.data.logins || [])).catch(() => setLogins([]));
    }, []);
    if (logins === null) return null;
    const fmt = (s) => { try { return new Date(s).toLocaleString(); } catch { return s; } };
    return (
        <div className="rounded-xl border border-brand-line bg-white p-5 mb-6" data-testid="security-login-activity">
            <div className="font-medium text-brand-ink flex items-center gap-2 mb-1">
                <MonitorSmartphone className="w-4 h-4 text-brand-copper" /> Recent sign-ins & devices
            </div>
            <p className="text-sm text-zinc-500 mb-3">
                We email you at your account address whenever a <b>new device or location</b> signs in.
                Review recent activity below — if you do not recognise a sign-in, change your password immediately.
            </p>
            {logins.length === 0 ? (
                <div className="text-sm text-zinc-400">No sign-ins recorded yet.</div>
            ) : (
                <ul className="divide-y divide-brand-line" data-testid="security-login-list">
                    {logins.map((l, i) => (
                        <li key={i} className="py-2.5 flex items-center justify-between gap-3 text-sm">
                            <div className="min-w-0">
                                <div className="text-brand-ink font-medium flex items-center gap-2">
                                    {l.device || "Unknown device"}
                                    {l.new_device && (
                                        <span className="text-[11px] rounded-full bg-amber-100 text-amber-800 px-2 py-0.5">new device</span>
                                    )}
                                </div>
                                <div className="text-zinc-500 flex items-center gap-1 mt-0.5">
                                    <MapPin className="w-3 h-3" />
                                    {l.country || "Unknown location"}{l.ip ? ` · ${l.ip}` : ""}
                                </div>
                            </div>
                            <div className="text-zinc-400 whitespace-nowrap">{fmt(l.created_at)}</div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}

function EmailTwoFactorCard() {
    const [pref, setPref] = useState(null);
    useEffect(() => { api.get("/auth/2fa/email-setting").then((r) => setPref(r.data)).catch(() => {}); }, []);
    async function toggle(v) {
        try { const { data } = await api.put("/auth/2fa/email-setting", { enabled: v }); setPref((p) => ({ ...p, ...data })); toast.success(v ? "Email 2FA enabled" : "Email 2FA disabled"); }
        catch (e) { toast.error(e?.response?.data?.detail || "Could not update"); }
    }
    if (!pref) return null;
    return (
        <div className="rounded-xl border border-brand-line bg-white p-5 mb-6" data-testid="security-email-2fa">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <div className="font-medium text-brand-ink flex items-center gap-2"><Mail className="w-4 h-4 text-brand-copper" /> Email sign-in codes (2FA)</div>
                    <p className="text-sm text-zinc-500 mt-1">On by default for every account. Each login emails you a 6-digit code. You can turn it off, but we recommend keeping it on.</p>
                    {!pref.platform_configured && <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-2 py-1 mt-2 inline-block">Email delivery isn&apos;t connected by the platform yet. In production, sign-in with email codes is blocked until it&apos;s configured (fail-closed); in preview/testing the code step is bypassed.</p>}
                </div>
                <Switch checked={!!pref.enabled} onCheckedChange={toggle} data-testid="security-email-2fa-toggle" />
            </div>
        </div>
    );
}

export default function Security() {
    const [status, setStatus] = useState(null);
    const [enrollment, setEnrollment] = useState(null);
    const [confirmCode, setConfirmCode] = useState("");
    const [backupCodes, setBackupCodes] = useState(null);
    const [disablePw, setDisablePw] = useState("");
    const [disableCode, setDisableCode] = useState("");
    const [busy, setBusy] = useState(false);

    async function load() {
        try {
            const { data } = await api.get("/auth/mfa/status");
            setStatus(data);
        } catch (e) { /* no-op */ }
    }
    useEffect(() => { load(); }, []);

    async function startEnroll() {
        setBusy(true);
        try {
            const { data } = await api.post("/auth/mfa/start");
            setEnrollment(data);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Enroll failed");
        } finally { setBusy(false); }
    }
    async function confirmEnroll() {
        setBusy(true);
        try {
            const { data } = await api.post("/auth/mfa/confirm", { code: confirmCode });
            setBackupCodes(data.backup_codes);
            setEnrollment(null); setConfirmCode("");
            toast.success("MFA enabled — save your backup codes");
            load();
        } catch (e) { toast.error("Invalid code"); }
        finally { setBusy(false); }
    }
    async function disable() {
        setBusy(true);
        try {
            await api.post("/auth/mfa/disable", { password: disablePw, code: disableCode });
            toast.success("MFA disabled");
            setDisablePw(""); setDisableCode("");
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Disable failed"); }
        finally { setBusy(false); }
    }

    return (
        <div className="p-6 max-w-2xl" data-testid="security-page">
            <h2 className="text-lg font-medium text-brand-ink mb-1">Security & MFA</h2>
            <p className="text-sm text-zinc-500 mb-6">Every account is protected by email codes by default. Add an authenticator app for even stronger protection.</p>
            <EmailTwoFactorCard />
            <LoginActivityCard />

            {status?.enabled ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-5" data-testid="security-mfa-enabled">
                    <div className="flex items-center gap-2 mb-2 text-emerald-800"><ShieldCheck className="w-5 h-5" /><span className="font-medium">MFA enabled</span></div>
                    <div className="text-xs text-emerald-700">Activated {status.activated_at?.slice(0, 10)}. Backup codes remaining: {status.backup_codes_remaining}.</div>

                    <div className="mt-4 border-t border-emerald-200 pt-4 space-y-2">
                        <Label className="text-xs">Disable MFA (requires password{status.role === "platform_founder" ? " + TOTP code" : ""})</Label>
                        <Input type="password" value={disablePw} onChange={(e) => setDisablePw(e.target.value)} placeholder="Current password" data-testid="security-disable-pw" />
                        <Input value={disableCode} onChange={(e) => setDisableCode(e.target.value)} placeholder="6-digit code (or backup code)" data-testid="security-disable-code" />
                        <Button variant="outline" onClick={disable} disabled={busy || !disablePw} className="mt-2" data-testid="security-disable-btn">
                            <ShieldOff className="w-4 h-4 mr-1" /> Disable MFA
                        </Button>
                    </div>
                </div>
            ) : enrollment ? (
                <div className="rounded-lg border border-brand-line bg-white p-5" data-testid="security-enrollment">
                    <div className="text-sm text-brand-ink mb-3">Scan this QR into your authenticator app, then enter the 6-digit code to confirm.</div>
                    <img src={enrollment.qr_png} alt="TOTP QR" className="w-48 h-48 border border-brand-line rounded" data-testid="security-qr" />
                    <div className="mt-3">
                        <Label className="text-xs">Manual secret (if QR cannot scan)</Label>
                        <div className="font-mono text-xs bg-brand-cream border border-brand-line rounded px-2 py-1 mt-1 break-all">{enrollment.secret}</div>
                    </div>
                    <div className="mt-4">
                        <Label className="text-xs">6-digit code</Label>
                        <Input value={confirmCode} onChange={(e) => setConfirmCode(e.target.value.replace(/\D/g, "").slice(0, 6))} maxLength={6} className="font-mono text-lg tracking-widest w-32" data-testid="security-confirm-code" />
                    </div>
                    <div className="mt-4 flex gap-2">
                        <Button onClick={confirmEnroll} disabled={busy || confirmCode.length !== 6} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="security-confirm-btn">Enable MFA</Button>
                        <Button variant="ghost" onClick={() => { setEnrollment(null); setConfirmCode(""); }}>Cancel</Button>
                    </div>
                </div>
            ) : backupCodes ? (
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-5" data-testid="security-backup-codes">
                    <div className="flex items-center gap-2 mb-2 text-amber-800"><AlertTriangle className="w-5 h-5" /><span className="font-medium">Save these backup codes</span></div>
                    <div className="text-xs text-amber-800 mb-3">Each code works once. Store them somewhere secure — we will not show them again.</div>
                    <div className="grid grid-cols-2 gap-2 mb-3">
                        {backupCodes.map((c) => (
                            <div key={c} className="font-mono text-sm bg-white border border-amber-200 rounded px-2 py-1 text-center">{c}</div>
                        ))}
                    </div>
                    <Button onClick={() => { navigator.clipboard.writeText(backupCodes.join("\n")); toast.success("Copied"); }} data-testid="security-backup-copy-btn">
                        <Copy className="w-4 h-4 mr-1" /> Copy all
                    </Button>
                    <Button onClick={() => setBackupCodes(null)} variant="ghost" className="ml-2" data-testid="security-backup-done-btn">I have saved them</Button>
                </div>
            ) : (
                <div className="rounded-lg border border-brand-line bg-white p-5" data-testid="security-not-enabled">
                    <div className="flex items-center gap-2 mb-2"><Key className="w-5 h-5 text-zinc-500" /><span className="font-medium">MFA not enabled</span></div>
                    <div className="text-sm text-zinc-500 mb-4">Enroll now to add a second factor to your login.</div>
                    <Button onClick={startEnroll} disabled={busy} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="security-enroll-btn">
                        <ShieldCheck className="w-4 h-4 mr-1" /> Set up MFA
                    </Button>
                </div>
            )}
        </div>
    );
}
