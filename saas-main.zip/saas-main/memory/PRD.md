# Zanelvo — Product Requirements Document (PRD)

_Brand: **Zanelvo** (provisional pending registration) — see /app/memory/DECISIONS.md for the full naming rationale and evidence trail. The prior provisional name was retired after discovering an active exact-name company in Germany; the rebrand was executed before Phase 2 began._

_Last updated: Phase 2 complete — 2026-02_


## Addendum (2026-09-05, fifth continuation) — Selling & shipping, product depth, logo studio
- **Sell online end-to-end (beyond Shopify):** shipping zones & rates (flat/weight/price/free-over),
  47-country selling allowlist, real carrier directory + one-connect aggregators (Shippo/EasyPost/
  ShipStation) for live rates & labels, ship-from address + handling fee, order fulfilment with
  carrier + tracking (buyer notified), printable invoices & packing slips, inventory management
  (adjust/log/low-stock/bulk). Shipping is quoted at checkout and added to the order total.
- **Product catalogue depth:** compare-at pricing, physical vs digital (download URL) products,
  per-product weight & requires-shipping, tags, variants (name/stock/price), SEO title/description.
- **Logo Studio:** instant on-brand SVG/text logo generator (styles, palettes, fonts, icons) with
  SVG/PNG download and save-to-brand; AI-image logo generation is a planned follow-up (provider TBD).


## Addendum (2026-09-06, Round 8 — second continuation)
- Central cost/usage service is the single gate for paid operations (see HANDOFF_ROUND_8.md); plan AI budgets, founder global
  budget, pause-all and provider kill switches are enforced server-side; ledger exportable; gross margin visible to founder.
- Security baseline raised to P0 list in SECOND_RUN_AUDIT.md §5; production never seeds demo data or returns reset tokens.
- Pricing: DB plans are the only source of truth; edits are validated and versioned; checkout snapshots are immutable.
- Public sites/storefronts offer an owner-enabled language switcher with RTL; translation is metered against the tenant.
- Customer-facing copy rules: no competitor names, no fake testimonials, no dev-progress language (internal competitive matrix lives in Staff panel only).

## Original Problem Statement

Build a multi-tenant SaaS for small service businesses whose **core product** is an AI website builder + hosting, with CRM, email workspace, booking, quotes/invoices/payments, AI employees, founder panel, and marketing built around it in later phases. This is **Phase 1 of 8**.

## Brand

- Chosen name: **Zanelvo** (provisional, pending trademark registration).
- Rationale: cleared exhaustive screening — zero exact-name company hits, no SaaS collisions, no adjacent-industry entities, no trademark filings. 2 syllables (YAV-ren), 6 letters, distinctive Y-start, easy to spell/pronounce. Coined; not a real word in Spanish/German/French/Portuguese/Arabic/Hindi. Not tied to any industry, not "AI + word". See `DECISIONS.md` for the 22 rejected candidates with full evidence.
- Tagline: _The quiet operating system for service businesses._
- Positioning: calm, credible, restrained neutrals + one confident copper accent. Explicitly NOT purple-gradient AI slop.
- Fonts: Fraunces (display) + DM Sans (body). Chosen to avoid Inter/Space Grotesk defaults.

## User Personas

- **Owner-operator** — plumber, salon owner, mechanic, coach. Non-technical. Values a site that reads like they wrote it and a phone that rings.
- **Manager** — trusted second-in-command. Handles day-to-day. Needs role-scoped access.
- **Staff** — front desk / technician. Sees only their queue.
- **Platform founder** — Zanelvo operator. Manages tenants, plans, and system-level config.

## Core Requirements (static)

1. Multi-tenant with strict `org_id` scoping on every query.
2. JWT auth, bcrypt passwords, roles: platform_founder, owner, manager, staff, readonly.
3. Password reset flow (token in DB; email adapter deferred to Phase 3).
4. Adaptive interview → LLM (Claude Sonnet 4.6 via Emergent Universal Key) → structured BusinessProfile + multi-page block JSON website.
5. Two different businesses in different industries must produce visibly different sites (structure, sections, copy).
6. Fact-correction review: every generated fact editable, marked owner-verified on edit/confirm.
7. Website JSON stored as `page -> ordered blocks -> typed props + style tokens`, rendered by React BlockRenderer. Ready for Phase 2's visual editor.
8. Public marketing site with dominant "Build my website" CTA; pricing page driven by DB (Free / Launch $19 / Revenue $79 / Autopilot $149 / Scale $299).
9. Tenant dashboard shell with sidebar (Website, CRM, Inbox, Calendar, Payments, AI Employees, Marketing, Settings). Honest "Coming in setup" states with a next action — no dead buttons.
10. `/api/openapi.json` accessible. Structured logging, no committed secrets.

## What's Been Implemented (Phase 2 — 2026-02)

### Visual editor (over the same block JSON as Phase 1)
- Three-panel editor at `/app/editor`: Pages panel (left), Canvas (center), Inspector (right). All actions go through a single command stack so undo/redo can be uniform.
- **Click-to-edit inline** via `contentEditable` on hero/services/about/cta/footer text fields. Blur commits, Enter commits, focus ring in copper.
- **Drag-to-reorder blocks** with `@dnd-kit/sortable` inside the canvas. Drag-to-reorder pages in the Pages panel (writes nav_order).
- **Undo/redo** with a 40-step command stack. Ctrl/Cmd+Z, Ctrl/Cmd+Shift+Z / Ctrl+Y. Every mutation snapshots the previous state; server sync is a debounced `/api/editor/website/snapshot-set`.
- **Autosave** at 900ms debounce; the top bar shows Editing → Saving → Saved.
- **Device previews** (desktop/tablet/mobile) via scaled canvas widths — mobile uses a real phone frame.
- **Block library sheet** with all 12 type × variant entries; server exposes `/api/editor/block-library`.
- **Inspector** with variant picker, image URL, CTA link fields, page SEO (title/description/social image/password), global theme (primary/secondary/background/accent + fonts).

### Publishing + revisions
- `/api/editor/website/publish` copies the draft (`theme`, `pages`, `nav_order`) into `published_*` fields on the Website doc and inserts a Revision (kind='publish'). This guarantees **draft edits never leak** to the live site until Publish.
- `/api/editor/website/revisions` lists last 50 revisions with kind/note/author/timestamp.
- `/api/editor/website/revisions/{id}/rollback` restores a revision into BOTH draft and published state and writes a new Revision (kind='rollback', `rolled_back_from_id` set). History is preserved.
- Slug history: renaming the slug records the old slug in `slug_history`; `GET /api/public/sites/{old}` returns `{redirect_to: <new>}` so the SPA can redirect.

### Public site serving
- `/site/{slug}` and `/site/{slug}/{pageSlug}` in the SPA call `/api/public/sites/{slug}` (published snapshot only). Tenant-themed via CSS custom properties.
- `/api/public/sites/{slug}/sitemap.xml` and `/robots.txt`. `sitemap` skips hidden pages.
- `/api/public/sites/by-host?host=<hostname>` looks up a site by connected custom hostname — this is the primitive host-based routing endpoint used for domain-masked traffic.
- Page-level SEO: title, description, social preview (og:image), optional password gate.

### Custom domains (provider-neutral adapter)
- `CustomHostnameProvider` interface with two implementations:
  - `SimulatedProvider` — in-memory state machine that advances Pending → Verifying on first status poll, then to Connected on the third poll. DNS records + TXT ownership record returned. For local testing.
  - `CloudflareProvider` — real Cloudflare-for-SaaS Custom Hostnames client. **Honest "Not connected — set CLOUDFLARE_API_TOKEN and CLOUDFLARE_SAAS_ZONE_ID to activate"** when env is missing. Real state mapping when connected.
- `/api/domains` CRUD + `/api/domains/{id}/status` polling + `/api/domains/{id}/retry` + `PATCH /api/domains/{id} {primary}` to set exactly one primary per website.
- Dashboard wizard (`/app/domains`) with hostname input, provider select (disabled for Cloudflare when not connected), copyable DNS records, live status polling every 4s while in transient state.
- Unit tests: `/app/backend/tests/test_domain_providers.py` covers both providers with a mocked `httpx.AsyncClient` for the Cloudflare paths (9 tests, all passing).

### "Already have a website?" URL import
- `/api/import/start` starts a background job that fetches up to 6 pages of an external URL (respects robots.txt, 10s per page, 1.5MB cap, no JS rendering).
- LLM extracts structured facts from scraped HTML (business name, industry, services text, hours, tone, contact) → seeds the Phase 1 pipeline → produces an improved BusinessProfile + Website for the same org.
- Planned redirects suggested per source path.
- Dashboard page `/app/import` with a live status card.

### Media / Forms / Analytics
- `/api/media/upload` (base64, 4MB cap) → data URL asset stored per org; list + delete endpoints.
- Public `/api/forms/submit` posts to the live site owner's Inbox (`FormSubmission` docs); owner-side `/api/forms/submissions` + mark-read. Silent no-op for unknown slugs (enumeration safety).
- Public `/api/analytics/track` for pageview / cta_click / form_submit; owner-side `/api/analytics/summary` returns 30-day totals + top pages.

### Data seed changes
- `seed_demo.py` now also seeds a `BusinessProfile` for the demo org so `/api/public/sites/demo-home-services` returns real `business_name`/`tagline` in its API contract. Backfills the website's `business_profile_id` link on subsequent starts.

## What's Been Implemented (Phase 1 — 2026-09-03)

### Backend
- FastAPI app with all routes under `/api` (`server.py`).
- Central brand config with regenerated wordmark SVG (`app/config.py`).
- Multi-tenant models with `BaseDocument` + `PyObjectId` (`app/models.py`).
- JWT + bcrypt + reset tokens (`app/security.py`).
- Shared deps: `current_user`, `require_org`, `require_role` (`app/deps.py`).
- LLM adapter (`app/services/llm.py`): `LlmChat` from emergentintegrations, retry-on-invalid-JSON.
- Curated Unsplash image map per industry/section (`app/services/images.py`).
- Two-stage generation (`app/services/generation.py`): (1) BusinessProfile JSON, (2) Website block JSON grounded on profile; server-side image + fact injection so links can't break and services/hours can't drift.
- Idempotent seed (`app/services/seed.py`): brand, plans, founder + demo owner. Writes creds to `/app/memory/test_credentials.md`, reuses on restart. Unique index on `users.email` (prevents race duplicates).
- Routes: `auth`, `public` (brand/plans/industries), `onboarding`, `business_profile`, `website`, `dashboard`.

### Frontend
- React Router v7, JWT context (`revenue_os.token` / `revenue_os.user` localStorage keys), Brand context (loads `/api/brand`).
- Public marketing: Home (single dominant CTA), Product, Pricing (from DB), 404.
- Auth: Login, Signup, Password Reset (with honest "email not yet connected" note + dev token).
- Onboarding: adaptive 10-step interview (text / textarea / industry picker / choice / multi / contact).
- Generating: live-polling loading screen with confident step labels and failure/retry.
- Fact Review: every service, hour, location, differentiator editable with owner-verified chips.
- Dashboard shell: sidebar nav (Website active, others "Coming in setup" with next action).
- Website preview: page tabs (home/services/about/contact) + desktop/mobile toggle with real phone frame.
- BlockRenderer + 7 block types × 2–3 variants each, all themed per tenant.

### Design
- Fraunces + DM Sans. Copper (#C85A17) + deep slate on cream surface. Grain texture on primary CTAs.
- Every interactive element has `data-testid`.

## Prioritized Backlog

### P0 (Phase 2 acceptance-critical, all done)
- Visual click-to-edit editor over the same block JSON (dnd-kit reorder).
- Undo/redo + debounced autosave.
- Draft vs published separation.
- Publishing target `/site/{slug}` + sitemap + robots.
- Revisions + rollback (rollback records a new revision, restores both draft and published state).
- Custom domains: provider adapter interface + Simulated wizard state machine + honest Cloudflare "Not connected".
- Host-based routing lookup `/api/public/sites/by-host`.
- "Already have a website?" import flow with LLM fact extraction.

### P1 (Phase 3 — next)
- Real transactional email (Resend/SendGrid) adapter for reset + notifications + form submit alerts.
- Verified-email enforcement + re-send flow.
- CRM (contacts, deals, notes, tags), email workspace (send from workspace, reply threads).
- Cloudflare-for-SaaS real credentials wired at platform level (or a self-serve token per tenant flow).
- Regenerate-section (individual block re-prompt) — the schema supports it; the endpoint is trivial to add.

### P2 (Phase 4+)
- Booking (Phase 4), Payments/quotes/invoices (Phase 5), AI Employees (Phase 6), Founder panel (Phase 7), Marketing/public pages expansion (Phase 8).
- Object Storage adapter for large media (data URLs work fine below 4MB).
- Full-text search across the tenant site + rate limit on form submissions.

## Known Limitations / Honesty

- Password reset email is stubbed — the token is returned in the API response and shown in the UI with a clear "email not yet connected" note.
- Verified-email flag exists but no send-verification loop yet.
- `CloudflareProvider` is fully implemented but **not connected** in this environment — the UI honestly shows "Not connected" and the wizard disables the option. Simulated provider drives the state machine end-to-end.
- Media uploads store as data URLs in Mongo (4MB cap). Object Storage adapter arrives with Phase 5 (payments/receipts).
- Analytics is first-party fire-and-forget; no bot filtering, no geo, no sessionization.
- Form submissions are not yet rate-limited; open to being hit if the site is shared before an admin knows.
- Import flow depends on external site HTML being parseable — sites that require JS-rendering or block bot UAs may fail; that surface returns `status='failed'` with an honest error.

## 2026-09-03 — Phase 4 shipped

Booking / Jobs / Quote-to-Cash delivered end-to-end.

**Implemented (verified by testing agent, 21/21 backend + 100% frontend smoke):**
- Public self-booking + tokenized reschedule/cancel + polished customer portals for quotes (accept/decline w/ reason), invoices (pay via simulated checkout), bookings (reschedule with live slot picker).
- Owner Calendar (week grid, staff filter, conflict-safe create), Quotes (tabs incl. Pending approval queue + in-app approve/reject with note), Quote builder (line items, live totals, ≥20% discount hint), Convert-to-invoice/job, Invoices (outstanding/overdue KPIs, dunning banner), Jobs dispatch board (status advance + checklist).
- Settings tabs shell: Email / Services (full CRUD) / Staff (working hours per day) / Payment providers (honest status: Simulated Active, Stripe Not connected).
- Deterministic availability engine (timezone-aware, DST-safe, buffer + capacity respected).
- Payment adapters: Simulated (in-app /pay/simulated/:id) + Stripe (present, refuses shared placeholder key).
- Every action writes a Contact-timeline Interaction.
- P0 lead-form + booking block on demo site's /contact — verified rendering.

**Deferred to a later phase (defaults ship):**
- Reminder cadence / dunning schedule editor UI (server defaults exist).
- Google / Microsoft calendar sync (out-of-scope for Phase 4).
- Real Stripe activation (adapter ready; owner must supply keys).

**Next up: Phase 5 — AI Employees (Receptionist, Quote Drafter, Reputation Manager) built on top of the CRM/quotes/booking primitives now in place.**

## 2026-09-03 — Phase 5 shipped

Knowledge Base + AI Employees + Agent Studio + Voice (simulated).

**Verified (15/15 pytest, all acceptance criteria):**
- Grounded chat: `$220` price on drain unblock quoted from catalog, honest "I don't know" for services outside catalog.
- Real booking via chat: `create_booking` tool with fresh-slot verification, source=`ai_chat`, contact auto-created, timeline entry, slot disappears from availability.
- Server-side takeover: `POST /api/ai/conversations/{cid}/takeover` → subsequent visitor messages get `{paused: true}` instead of AI reply. `resume` restores.
- Agent Studio: version history + rollback, sandbox never writes CRM, kill switch disables widget site-wide with honest fallback.
- Call simulator with transcript + summary + outcome. Retell + Twilio honestly "Not connected".
- Full per-interaction audit trail (model / tokens / cost / latency / tools) surfaced in usage rollup + conversation detail.
- Cross-tenant isolation on all new routes (knowledge, agents, conversations, calls).

**Deferred (defaults ship):**
- Reactivation + Sales agents currently draft-only endpoints — no dedicated UI. Owner still sends via existing Inbox flows.
- Contradiction detection is dollar-amount-literal only.
- Cost estimate is a per-model rough table, not per-provider actual.
- Retell / Twilio real voice: adapter cards ship, no phone traffic.

**Next up: Phase 6 — Founder Panel (multi-tenant admin, per-org usage/cost analytics, plan management, kill switches across the fleet).**

## 2026-09-03 — Phase 6 shipped

Billing/Entitlements + Founder Control Center + Setup Center + Support + Security.

**Pre-Phase-6 fixes verified (from Phase 5 acceptance):**
- Past-date booking guard: 4 code paths (availability, public book, portal reschedule, AI tool) refuse past `start_at` with 422/soft-fail; availability filters out past slots.
- Chat response `booking_id` — always propagates when a booking is created.
- LLM transient errors retry once before escalating; friendlier widget copy.
- Takeover endpoint accepts empty body (200).
- Portal tokens compared constant-time (`hmac.compare_digest`).
- Cleanup: 5 past-dated bookings + 2 tester contacts + 6 TEST agent versions purged.

**Verified end-to-end:**
- Plans + entitlements: per-plan limit table, 6 meters (AI convos, email sends, voice minutes, contacts, users, websites) with warn @80% / over @100%.
- Simulated checkout: upgrade (with `LAUNCH20` coupon → 20% off) → sub flips → billing invoice created → `subscription.upgrade` audited. Downgrade validates usage fit. Cancel/resume/simulate-dunning all functional.
- Founder cockpit: exception-first list, real orgs-over-limit, LLM error count, dead-letter count.
- Tenant directory: search / plan filter, MRR + AI cost + gross margin per org, health score with explainable factors, suspend/unsuspend.
- Audited impersonation: mandatory reason (min 6 chars), 30-min hard TTL, banner shown, `impersonation.start`/`impersonation.end` audited, exit works.
- Global kill switches: `all_ai_disabled` immediately blocks public chat with honest fallback; `all_public_chat_disabled` same. Undo restores.
- Feature flags + announcement: publish → visible on public read + tenant dashboard banner; clear removes.
- Setup Center: 21 cards with honest state + Test button; Launch Score = 6 real checks.
- Scoped API keys (`yv_live_...` / `yv_test_...`) with SHA-256 storage, scope enforcement on `/api/public/v1/*`, whoami echoes org + scopes; webhook secrets shown once.
- MFA (TOTP): enroll → QR + secret → confirm → 8 backup codes shown once → login-secure requires code → disable with password (founder additionally requires TOTP code).
- Data export ZIP downloads; org deletion soft-deletes with 30-day grace.
- Rate limits on `/api/auth/login` (10/5min), `/api/auth/signup` (8/10min), `/api/public/chat/*` (30-60/min).
- Support: 10 seeded help articles, ticket CRUD, AI support grounded to articles only (cites slugs, escalates to ticket on miss), public status.

**Extra demo orgs seeded** (visible in founder dashboard):
- Bright Path Coaching — Launch plan.
- River & Grain Salon — Autopilot plan.
- Existing Demo Home Services — subscribed to Autopilot to match marketing story.

**Deferred (honest):**
- Real Stripe activation (adapter refuses without `STRIPE_SECRET_KEY`).
- Retell/Twilio, Google/MS Calendar, Google Business Profile, Slack, QuickBooks: cards present with honest `not_connected` state.
- Data export sync-only (worker split deferred). Org purge scheduled but no worker yet — recovery within grace is a flag flip.
- MFA secret at-rest encryption (documented in SECURITY.md).
- Cluster-safe rate limiter (in-process today).

**Next up: Phase 7 — Marketing surface (public pages expansion, SEO, growth surfaces) + real integration cutovers (Stripe/Google/Microsoft Calendar) as adapters land credentials.**

## 2026-09 — Numbers/Voice cycle (this session)

Env was lost again on import (backend/.env + frontend/.env + Mongo empty) — rebuilt (DB_NAME=zanelvo_db, preview host wired, Emergent LLM key). Seed regenerated founder+owner+demo tenants. Creds in /app/memory/test_credentials.md.

Shipped & verified (15/15 backend tests pass):
- **Managed phone numbers & AI voice** (`services/numbers.py`, `routes/numbers.py`, page `dashboard/Numbers.jsx`, nav under Grow → "Phone & AI voice"). Marketplace browse-by-country (12 countries, local+tollfree), buy → instant org ownership, multi-number management, per-number voice control (persona, spoken LANGUAGE, greeting, voicemail/after-hours/hold messages, call forwarding, SMS auto-reply, recording), simulated test-call. Plan free-number allotment (revenue=1, autopilot=1, scale=3), extra numbers $3/mo local ($6 tollfree). Simulated-until-carrier-connected (Telnyx recommended; Twilio supported) via founder integrations `voice` (now supports telnyx_api_key).
- **Multi-language AI voice**: Twilio inbound webhook uses per-number voice_config for `<Say language>`/`<Gather language>` + prepends a language/style directive so the receptionist answers callers in their language.
- **Founder economics**: added managed-numbers profit/loss block (wholesale vs retail, free-allotment cost) + plans[].free_numbers_included.
- **Home.jsx visual edits** (per user annotations): interactive hero dashboard mock (working demo nav switches Overview/Store/Contacts/Inbox/Calendar/AI), replaced slow external Unsplash showcase images with fast bespoke rendered panels, upgraded the bland trust marquee to premium pill chips.

Provider research delivered to user: Telnyx cheapest (~$1/mo/number, ~$0.007/min voice, $0.004 SMS) & recommended default; Twilio pricier but best ecosystem; Platfone = disposable OTP-activation numbers, NOT suitable (no persistent lines, no voice, receive-only).

STILL OPEN (user asked for ALL): ecommerce depth (Wix/Shopify parity), no-AI "create from scratch" + template gallery + move interview into dashboard + humanized questions + niche/name logo gen, full professional redesign, drag&drop uploads everywhere, staff-panel isolation + email send/receive panel + transactional email automation (needs Resend/SendGrid + zanelvo.com DNS), IP logging/anti-abuse, marketing 100x, editor overhaul, global bug sweep, multi-language for emails/website content.

## 2026-09 — Email suite + Home polish (same session, part 2)

Shipped & verified (email suite: 9/9 backend tests pass):
- **Staff Email Center** (`/staff/emails`, staff-only "emails" perm) rebuilt into a tabbed panel: Inbox (read/reply + simulate inbound), Compose (send from support@/sales@), Automations (9 toggleable transactional emails), Templates (9 branded HTML previews via iframe), Addresses (per-role from-addresses), Provider (Resend/SendGrid/SMTP/simulated config + inbound secret + test send).
- Backend: `routes/staff_email.py` (/api/staff/email/*), `routes/email_inbound.py` (/api/webhooks/email/resend|sendgrid, idempotent via webhook_events, secured by inbound_secret), `services/transactional.py` (9 professional templates + automation registry + send_transactional), `services/email_providers.py` gained a **SendGrid adapter**; integrations `email` section now supports sendgrid_api_key + inbound_secret. Signup fires 'welcome' (fire-and-forget). All honest-simulated until a provider is connected in the staff panel.
- **Home.jsx polish round 2** (7 visual-editor annotations): marquee dark-mode fix; 4th showcase slide upgraded from skeleton to a real flower-shop preview; features bento given per-card gradient accents; "How it works" upgraded to icon+timeline; replaced the "unfitting" stock owner photo with a bespoke rendered "booked & paid" activity mock; testimonials upgraded with avatars/roles/metrics; FAQ restyled as cards.

DISCOVERED already-present: `antifraud` service (disposable-email + per-IP signup velocity) partly covers the "IP logging / no multi-account trial abuse" ask — needs auditing/strengthening + a staff view.

STILL OPEN (user wants ALL): ecommerce depth (variants/collections/discounts/inventory/shipping), no-AI "create your website from scratch" + template gallery + humanized interview moved into dashboard + niche/name logo generation (owner-panel toggle for AI-image vs SVG maker), full professional dashboard redesign, drag&drop uploads everywhere, anti-abuse hardening + staff fraud view, marketing 100x, website editor overhaul, global bug sweep, multi-language for tenant emails/website content.

---

## Module: Dynamic CMS & Extensions Foundation (Round 16)

An AI-native, no-code extensibility system. Explicitly excludes arbitrary customer JavaScript,
backend code, eval, shell or untrusted code execution (documented as a future isolated
serverless-function runtime).

### Data model (fixed, shared, tenant-scoped — every doc carries org_id from auth context)
- `content_collection_definitions`, `content_items`, `content_item_revisions`,
  `dynamic_page_templates`, `dynamic_page_template_revisions`, `external_data_connections`, `cms_audit`.
- No arbitrary physical Mongo collections from customer-supplied names.

### Capabilities (implemented)
- Custom collections: 17 controlled field types; required/unique/searchable/private/default/options;
  display field; immutable internal_id; schema_version; archived state; created/updated/by.
- Items: create/edit/duplicate/archive, filter/sort/search/pagination, bounded CSV import (5MB / 5000
  rows / 60 cols) + export, per-item revision history + rollback, atomic slug uniqueness, unique checks.
- Dynamic pages: one template renders list + detail for every item; publish + revision + rollback;
  route uniqueness per site; SEO title/meta/OG token resolution; published items in sitemap.xml;
  public routes `/site/{slug}/{route}` (directory) and `/site/{slug}/{route}/{item}` (detail).
- Permissions: owner/manager full, staff configurable, public read disabled by default, public form
  submission as controlled create-only (no generic unauthenticated DB-write API). Field-level private flag.
- External REST connector (advanced plans): HTTPS GET, encrypted+masked auth headers, params, test,
  status/last-success/errors; SSRF-hardened (blocks localhost/private/link-local/metadata/internal DNS,
  https-only, approved port, redirect re-validation, size/timeout caps); metered via central usage.
- AI-native creation: describe a feature → structured PREVIEW (nothing created) → confirm → apply;
  metered via atomic reservation; never invents business facts.

### Plans & limits (DB-backed, founder-editable, server-enforced)
free 1/100/0 · launch 3/1000/0 · revenue 20/25000/2 · autopilot 100/250000/10 · scale configurable
(collections / items / connectors).

### Security model
Tenant isolation on every query; public safe projections (published+non-archived, private+audit
stripped); server-side rich-text/HTML sanitisation (nh3); SSRF protection; encrypted connector secrets
never returned to browser; metered paid ops; audit events.

### Remaining (future increments)
Visual data binding inside the website editor Inspector; scheduled connector sync + JSON→collection
mapping; expanded theme tokens + states + approved animations + validated scoped custom CSS under CSP;
system-collection adapters; AI layout + form-mapping generation; isolated code runtime (out of phase).

---
## Module: Production Storage, Unified Asset Library & Bandwidth Controls (Round 17 (Production Storage & Asset Library))
Provider-neutral object storage (S3-compatible: R2/S3/B2/MinIO; local adapter dev/test only; prod
refuses container-local permanent storage). Mongo stores metadata + stable asset IDs only; bytes live
in storage under tenant keys `org/{org_id}/{asset_id}/{variant}`. Unified Asset Library (`/app/assets`)
+ reusable Asset Picker. Atomic upload flow (reserve→session→verify→checksum→commit) with MIME allowlist,
magic-byte sniff, SVG sanitisation, image decompression-bomb guard, dimension limits, EXIF strip, per-tenant
SHA-256 dedup. DB-backed founder-editable storage allowances (free 500MB / launch 5GB / revenue 50GB /
autopilot 200GB / scale 500GB) with per-tenant overrides; 70/90/100% behaviour; 100% blocks NEW uploads only
(never takes a site offline). Trash (30-day) counts toward quota until purge. Public assets via CDN/public URL;
private via short-lived signed URLs. Bandwidth = Estimated/Unavailable until a real provider/CDN is connected;
plan copy says "Managed bandwidth" (no fake numbers, no multi-cloud claim).
Files: services/storage.py, services/assets.py, routes/assets.py, scripts/migrate_inline_assets.py,
frontend AssetLibrary.jsx + AssetPicker.jsx.
