import { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, CreditCard, Loader2, Lock } from "lucide-react";

const API = process.env.REACT_APP_BACKEND_URL;

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

/**
 * SimulatedCheckout — the in-app "test checkout" page a customer lands on
 * from Invoice → Pay. Mimics a Stripe-like flow WITHOUT any real charges.
 */
export default function SimulatedCheckout() {
    const { sessionId } = useParams();
    const [params] = useSearchParams();
    const returnTo = params.get("return_to") || "/pay/success";
    const navigate = useNavigate();
    const [status, setStatus] = useState(null);
    const [error, setError] = useState(null);
    const [busy, setBusy] = useState(false);

    async function loadStatus() {
        try {
            const r = await fetch(`${API}/api/payments/status/${sessionId}`);
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            setStatus(await r.json());
        } catch (e) { setError(e.message); }
    }
    useEffect(() => { loadStatus(); /* eslint-disable-next-line */ }, [sessionId]);

    async function pay() {
        setBusy(true);
        try {
            const r = await fetch(`${API}/api/payments/simulated/pay`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ session_id: sessionId }),
            });
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            navigate(`${returnTo}${returnTo.includes("?") ? "&" : "?"}session_id=${sessionId}`);
        } catch (e) { setError(e.message); } finally { setBusy(false); }
    }

    if (error && !status) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-brand-surface p-6" data-testid="sim-checkout-error">
                <div className="max-w-md rounded-xl border border-brand-line bg-white p-8 text-center">
                    <XCircle className="w-8 h-8 text-red-500 mx-auto" />
                    <h1 className="font-display text-2xl text-brand-ink mt-3">This session isn't valid.</h1>
                </div>
            </div>
        );
    }
    if (!status) return <div className="min-h-screen flex items-center justify-center text-zinc-500"><Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading…</div>;

    const isPaid = status.status === "paid";

    return (
        <div className="min-h-screen bg-brand-surface flex items-center justify-center p-4 md:p-8" data-testid="sim-checkout-page">
            <div className="w-full max-w-md rounded-2xl border border-brand-line bg-white overflow-hidden shadow-sm">
                <div className="px-6 py-4 border-b border-brand-line flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper">
                    <Lock className="w-3.5 h-3.5" /> Simulated checkout
                </div>
                <div className="p-6">
                    <div className="text-xs text-zinc-500">Amount</div>
                    <div className="text-3xl font-mono font-medium text-brand-ink mt-1" data-testid="sim-checkout-amount">
                        {money(status.amount_cents, status.currency)}
                    </div>
                    <div className="text-xs text-zinc-500 mt-1">Session {status.session_id}</div>

                    <div className="mt-6 rounded-md bg-amber-50 border border-amber-200 text-amber-900 p-3 text-xs">
                        This is a test checkout — no real card is charged. Wire Stripe in Settings → Payments to accept real payments.
                    </div>

                    {isPaid ? (
                        <div className="mt-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 flex items-start gap-3" data-testid="sim-checkout-paid">
                            <CheckCircle2 className="w-5 h-5 mt-0.5" />
                            <div>
                                <div className="font-medium">Payment received.</div>
                                <div className="text-sm mt-0.5">You'll be redirected momentarily.</div>
                            </div>
                        </div>
                    ) : (
                        <>
                            <div className="mt-6 space-y-2 opacity-80 pointer-events-none">
                                <input placeholder="Card number" className="w-full rounded-md border border-brand-line px-3 py-2 text-sm bg-zinc-50 font-mono" defaultValue="4242 4242 4242 4242" />
                                <div className="grid grid-cols-2 gap-2">
                                    <input placeholder="MM / YY" className="rounded-md border border-brand-line px-3 py-2 text-sm bg-zinc-50 font-mono" defaultValue="04 / 30" />
                                    <input placeholder="CVC" className="rounded-md border border-brand-line px-3 py-2 text-sm bg-zinc-50 font-mono" defaultValue="123" />
                                </div>
                            </div>
                            <Button
                                onClick={pay}
                                disabled={busy}
                                className="mt-5 w-full h-12 text-base bg-brand-copper hover:bg-brand-copperHover text-white"
                                data-testid="sim-checkout-pay-btn"
                            >
                                {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CreditCard className="w-4 h-4 mr-2" />}
                                Pay {money(status.amount_cents, status.currency)}
                            </Button>
                            <Button
                                variant="ghost"
                                onClick={() => navigate("/pay/cancel")}
                                className="w-full mt-2 text-zinc-500"
                                data-testid="sim-checkout-cancel-btn"
                            >
                                Cancel
                            </Button>
                        </>
                    )}
                    {error && <div className="mt-3 rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm">{error}</div>}
                </div>
            </div>
        </div>
    );
}
