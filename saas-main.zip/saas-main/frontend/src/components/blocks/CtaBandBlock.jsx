import { ArrowRight } from "lucide-react";

export default function CtaBandBlock({ block, theme }) {
    const { props = {} } = block;
    const { headline, subheadline, primary_cta, background_image } = props;
    return (
        <section className="relative overflow-hidden">
            {background_image && (
                <>
                    <img src={background_image} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30" />
                    <div className="absolute inset-0" style={{ background: theme?.secondary || "#0F172A" }} />
                    <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(0,0,0,0.65), rgba(0,0,0,0.35))" }} />
                </>
            )}
            {!background_image && (
                <div className="absolute inset-0" style={{ background: theme?.secondary || "#0F172A" }} />
            )}
            <div className="relative mx-auto max-w-5xl px-6 py-20 md:py-24 text-white">
                <h2 data-heading className="text-3xl md:text-4xl font-semibold leading-tight max-w-2xl">
                    {headline}
                </h2>
                {subheadline && (
                    <p className="mt-4 max-w-xl opacity-90">{subheadline}</p>
                )}
                {primary_cta?.label && (
                    <a
                        href={primary_cta.href || "#"}
                        className="mt-8 inline-flex items-center gap-2 px-6 py-3 rounded-md font-medium"
                        style={{ background: theme?.primary, color: "#fff" }}
                    >
                        {primary_cta.label} <ArrowRight className="w-4 h-4" />
                    </a>
                )}
            </div>
        </section>
    );
}
