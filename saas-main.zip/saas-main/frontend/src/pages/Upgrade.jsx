import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import api from "@/lib/api";
import { useBrand } from "@/context/BrandContext";
import { Button } from "@/components/ui/button";
import { Check, Lock, ArrowRight, Sparkles } from "lucide-react";

export default function Upgrade() {
    const brand = useBrand();
    const [plans, setPlans] = useState([]);
    const [annual, setAnnual] = useState(true);
    const [params] = useSearchParams();
    const feature = params.get("feature");

    useEffect(() => {
        api.get("/plans").then((r) => setPlans(r.data || [])).catch(() => {});
    }, []);

    const paid = plans.filter((p) => p.code !== "free");

    return (
        <div className="min-h-screen bg-brand-surface text-brand-ink">
            <div className="mx-auto max-w-5xl px-6 py-16">
                <div className="text-center max-w-2xl mx-auto">
                    <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-4">
                        <Sparkles className="w-4 h-4" /> Unlock more of {brand?.name}
                    </div>
                    <h1 className="font-display text-4xl md:text-5xl font-medium leading-tight">
                        {feature ? `“${feature}” is a paid feature` : "Pick a plan to unlock everything"}
                    </h1>
                    <p className="mt-4 text-zinc-600">
                        Every capability is visible on your account — activate a plan to switch it on. Cancel anytime.
                    </p>
                    <div className="mt-6 inline-flex items-center gap-3 bg-white border border-brand-line rounded-full p-1">
                        <button onClick={() => setAnnual(false)} className={`px-4 py-1.5 rounded-full text-sm ${!annual ? "bg-brand-ink text-white" : "text-zinc-500"}`}>Monthly</button>
                        <button onClick={() => setAnnual(true)} className={`px-4 py-1.5 rounded-full text-sm ${annual ? "bg-brand-ink text-white" : "text-zinc-500"}`}>
                            Annual {plans[0]?.annual_discount_pct ? `· save ${plans[0].annual_discount_pct}%` : ""}
                        </button>
                    </div>
                </div>

                <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {paid.map((p) => (
                        <div key={p.code} data-testid={`upgrade-plan-${p.code}`}
                            className={`rounded-2xl p-6 border bg-white ${p.highlight ? "border-brand-copper ring-1 ring-brand-copper/20 shadow-md" : "border-brand-line"}`}>
                            {p.highlight && <div className="mb-2 inline-flex text-[10px] uppercase tracking-widest text-brand-copper bg-brand-cream rounded-full px-2 py-1">Popular</div>}
                            <div className="font-display text-xl">{p.name}</div>
                            <div className="mt-1 text-sm text-zinc-500">{p.tagline}</div>
                            <div className="mt-4">
                                <span className="font-display text-3xl">${annual ? p.price_annual_monthly : p.price_monthly}</span>
                                <span className="text-sm text-zinc-500">/mo</span>
                                {annual && p.price_annual_total > 0 && (
                                    <div className="text-xs text-zinc-400 mt-0.5">${p.price_annual_total} billed yearly</div>
                                )}
                            </div>
                            <ul className="mt-4 space-y-2 text-sm">
                                {(p.features || []).slice(0, 4).map((f) => (
                                    <li key={f} className="flex items-start gap-2"><Check className="w-4 h-4 mt-0.5 text-brand-copper shrink-0" /><span className="text-zinc-700">{f}</span></li>
                                ))}
                            </ul>
                            <Link to="/app/billing" className="block mt-6">
                                <Button className={`w-full ${p.highlight ? "bg-brand-copper hover:bg-brand-copperHover text-white" : "bg-brand-ink hover:bg-black text-white"}`}>
                                    Choose {p.name} <ArrowRight className="w-4 h-4 ml-1" />
                                </Button>
                            </Link>
                        </div>
                    ))}
                </div>

                <div className="mt-10 text-center">
                    <Link to="/app" className="text-sm text-zinc-500 hover:text-brand-ink inline-flex items-center gap-1">
                        <Lock className="w-3.5 h-3.5" /> Keep exploring on your current plan
                    </Link>
                </div>
            </div>
        </div>
    );
}
