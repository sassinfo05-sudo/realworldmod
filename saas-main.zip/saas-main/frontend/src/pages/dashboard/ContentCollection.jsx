import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import api, { API } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    ArrowLeft, Plus, Search, MoreHorizontal, Copy, Archive, History, Upload, Download,
    ChevronLeft, ChevronRight, ExternalLink, Save,
} from "lucide-react";
import FieldsEditor, { FieldInput } from "@/components/cms/FieldsEditor";
import {
    getCollection, updateCollection, listItems, createItem, updateItem, duplicateItem,
    itemRevisions, rollbackItem, importCsv, listTemplates, createTemplate, updateTemplate,
    apiErr, displayValue,
} from "@/lib/cms";

export default function ContentCollection() {
    const { cid } = useParams();
    const [coll, setColl] = useState(null);
    const reloadColl = useCallback(async () => {
        try { setColl(await getCollection(cid)); } catch (e) { toast.error(apiErr(e)); }
    }, [cid]);
    useEffect(() => { reloadColl(); }, [reloadColl]);

    if (!coll) return <div className="p-6 text-zinc-500">Loading…</div>;

    return (
        <div className="max-w-6xl mx-auto p-6 space-y-5" data-testid="collection-detail">
            <div className="flex items-center gap-3">
                <Button asChild size="icon" variant="ghost"><Link to="/app/content"><ArrowLeft className="w-4 h-4" /></Link></Button>
                <div>
                    <h1 className="text-xl font-semibold">{coll.name}</h1>
                    <div className="text-xs text-zinc-500">{coll.internal_id} · schema v{coll.schema_version}</div>
                </div>
            </div>

            <Tabs defaultValue="items">
                <TabsList>
                    <TabsTrigger value="items" data-testid="tab-items">Items</TabsTrigger>
                    <TabsTrigger value="fields" data-testid="tab-fields">Fields</TabsTrigger>
                    <TabsTrigger value="pages" data-testid="tab-pages">Dynamic pages</TabsTrigger>
                </TabsList>
                <TabsContent value="items" className="mt-4"><ItemsTab coll={coll} /></TabsContent>
                <TabsContent value="fields" className="mt-4"><FieldsTab coll={coll} onSaved={reloadColl} /></TabsContent>
                <TabsContent value="pages" className="mt-4"><PagesTab coll={coll} /></TabsContent>
            </Tabs>
        </div>
    );
}

// ------------------------------------------------------------------ Items
function ItemsTab({ coll }) {
    const fields = coll.fields || [];
    const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1 });
    const [q, setQ] = useState("");
    const [sort, setSort] = useState("-created_at");
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const [editing, setEditing] = useState(null); // item or {} for new
    const [values, setValues] = useState({});
    const [revItem, setRevItem] = useState(null);
    const [showImport, setShowImport] = useState(false);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await listItems(coll.id, { q: q || undefined, sort, page, page_size: 25, include_archived: true });
            setData(res);
        } catch (e) { toast.error(apiErr(e)); }
        setLoading(false);
    }, [coll.id, q, sort, page]);
    useEffect(() => { load(); }, [load]);

    const cols = useMemo(() => fields.slice(0, 5), [fields]);

    const openNew = () => { setValues({}); setEditing({}); };
    const openEdit = (it) => { setValues({ ...(it.values || {}) }); setEditing(it); };

    const save = async () => {
        try {
            if (editing.id) await updateItem(editing.id, { values });
            else await createItem(coll.id, values, "published");
            toast.success("Saved"); setEditing(null); load();
        } catch (e) { toast.error(apiErr(e)); }
    };
    const dup = async (it) => { try { await duplicateItem(it.id); toast.success("Duplicated"); load(); } catch (e) { toast.error(apiErr(e)); } };
    const arch = async (it) => { try { await updateItem(it.id, { archived: !it.archived }); load(); } catch (e) { toast.error(apiErr(e)); } };
    const toggleStatus = async (it) => {
        try { await updateItem(it.id, { status: it.status === "published" ? "draft" : "published" }); load(); }
        catch (e) { toast.error(apiErr(e)); }
    };

    const exportCsv = () => {
        const keys = fields.map((f) => f.key);
        const rows = [["slug", "status", ...keys]];
        data.items.forEach((it) => rows.push(["" + (it.slug || ""), it.status, ...keys.map((k) => {
            const v = it.values?.[k]; return Array.isArray(v) ? v.join("|") : (v ?? "");
        })]));
        const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
        const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
        const a = document.createElement("a"); a.href = url; a.download = `${coll.internal_id}.csv`; a.click(); URL.revokeObjectURL(url);
    };

    return (
        <div>
            <div className="flex flex-wrap items-center gap-2 mb-4">
                <div className="relative flex-1 min-w-[200px]">
                    <Search className="w-4 h-4 absolute left-2.5 top-2.5 text-zinc-400" />
                    <Input className="pl-8" placeholder="Search…" value={q} data-testid="items-search"
                           onChange={(e) => { setPage(1); setQ(e.target.value); }} />
                </div>
                <Select value={sort} onValueChange={(v) => setSort(v)}>
                    <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="-created_at">Newest first</SelectItem>
                        <SelectItem value="created_at">Oldest first</SelectItem>
                        <SelectItem value="slug">Slug A–Z</SelectItem>
                        <SelectItem value="-updated_at">Recently updated</SelectItem>
                    </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={() => setShowImport(true)} data-testid="import-csv-btn"><Upload className="w-4 h-4 mr-1" />Import</Button>
                <Button variant="outline" size="sm" onClick={exportCsv}><Download className="w-4 h-4 mr-1" />Export</Button>
                <Button size="sm" onClick={openNew} data-testid="new-item-btn"><Plus className="w-4 h-4 mr-1" />New item</Button>
            </div>

            <Card className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            {cols.map((f) => <TableHead key={f.key}>{f.label}{f.private && <span className="text-[10px] text-zinc-400 ml-1">(private)</span>}</TableHead>)}
                            <TableHead>Status</TableHead>
                            <TableHead className="w-10" />
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {data.items.map((it) => (
                            <TableRow key={it.id} className={it.archived ? "opacity-50" : ""} data-testid={`item-row-${it.slug}`}>
                                {cols.map((f) => <TableCell key={f.key} className="max-w-[220px] truncate">{displayValue(f, it.values?.[f.key])}</TableCell>)}
                                <TableCell>
                                    <Badge variant={it.status === "published" ? "default" : "secondary"} className="text-[10px] cursor-pointer" onClick={() => toggleStatus(it)}>
                                        {it.archived ? "archived" : it.status}
                                    </Badge>
                                </TableCell>
                                <TableCell>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild><Button size="icon" variant="ghost"><MoreHorizontal className="w-4 h-4" /></Button></DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuItem onClick={() => openEdit(it)}>Edit</DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => dup(it)}><Copy className="w-3.5 h-3.5 mr-2" />Duplicate</DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => setRevItem(it)}><History className="w-3.5 h-3.5 mr-2" />Revisions</DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => arch(it)}><Archive className="w-3.5 h-3.5 mr-2" />{it.archived ? "Restore" : "Archive"}</DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))}
                        {data.items.length === 0 && !loading && (
                            <TableRow><TableCell colSpan={cols.length + 2} className="text-center text-zinc-500 py-8">No items yet</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </Card>

            <div className="flex items-center justify-between mt-3 text-sm text-zinc-500">
                <span>{data.total} items</span>
                <div className="flex items-center gap-2">
                    <Button size="icon" variant="ghost" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft className="w-4 h-4" /></Button>
                    <span>{data.page} / {data.pages || 1}</span>
                    <Button size="icon" variant="ghost" disabled={page >= (data.pages || 1)} onClick={() => setPage((p) => p + 1)}><ChevronRight className="w-4 h-4" /></Button>
                </div>
            </div>

            {/* Item editor */}
            <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
                <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
                    <DialogHeader><DialogTitle>{editing?.id ? "Edit item" : "New item"}</DialogTitle></DialogHeader>
                    <div className="space-y-3">
                        {fields.map((f) => (
                            <div key={f.key}>
                                <Label className="text-sm">{f.label}{f.required && <span className="text-red-500 ml-0.5">*</span>}</Label>
                                <FieldInput field={f} value={values[f.key]} onChange={(v) => setValues((s) => ({ ...s, [f.key]: v }))} />
                            </div>
                        ))}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
                        <Button onClick={save} data-testid="save-item-btn"><Save className="w-4 h-4 mr-1" />Save</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <RevisionsDialog item={revItem} onClose={() => setRevItem(null)} onRolledBack={load} />
            <ImportDialog coll={coll} open={showImport} onClose={() => setShowImport(false)} onDone={load} />
        </div>
    );
}

function RevisionsDialog({ item, onClose, onRolledBack }) {
    const [revs, setRevs] = useState([]);
    useEffect(() => { if (item) itemRevisions(item.id).then(setRevs).catch(() => setRevs([])); }, [item]);
    const rollback = async (r) => {
        try { await rollbackItem(item.id, r.id); toast.success("Rolled back"); onClose(); onRolledBack(); }
        catch (e) { toast.error(apiErr(e)); }
    };
    return (
        <Dialog open={!!item} onOpenChange={(o) => !o && onClose()}>
            <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
                <DialogHeader><DialogTitle>Revision history</DialogTitle></DialogHeader>
                <div className="space-y-2">
                    {revs.map((r, i) => (
                        <div key={r.id} className="flex items-center justify-between border rounded-lg p-2 text-sm">
                            <div>
                                <div className="font-medium">{i === 0 ? "Current" : `Revision ${revs.length - i}`}</div>
                                <div className="text-xs text-zinc-500">{r.created_at}</div>
                            </div>
                            {i !== 0 && <Button size="sm" variant="outline" onClick={() => rollback(r)}>Restore</Button>}
                        </div>
                    ))}
                    {revs.length === 0 && <p className="text-sm text-zinc-500">No revisions.</p>}
                </div>
            </DialogContent>
        </Dialog>
    );
}

function ImportDialog({ coll, open, onClose, onDone }) {
    const fields = coll.fields || [];
    const [csvText, setCsvText] = useState("");
    const [columns, setColumns] = useState([]);
    const [mapping, setMapping] = useState({});
    const [busy, setBusy] = useState(false);

    const onFile = (e) => {
        const f = e.target.files?.[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => { const t = String(reader.result || ""); setCsvText(t); parseHeader(t); };
        reader.readAsText(f);
    };
    const parseHeader = (t) => {
        const first = (t.split("\n")[0] || "").trim();
        const cols = first.split(",").map((c) => c.replace(/^"|"$/g, "").trim());
        setColumns(cols);
        const auto = {};
        cols.forEach((c) => { const m = fields.find((f) => f.key === c || f.label.toLowerCase() === c.toLowerCase()); if (m) auto[c] = m.key; });
        setMapping(auto);
    };

    const run = async () => {
        if (!csvText.trim()) return toast.error("Paste or upload a CSV first");
        setBusy(true);
        try {
            const res = await importCsv(coll.id, csvText, mapping);
            toast.success(`Imported ${res.created} rows${res.errors?.length ? `, ${res.errors.length} skipped` : ""}`);
            onClose(); onDone(); setCsvText(""); setColumns([]); setMapping({});
        } catch (e) { toast.error(apiErr(e)); }
        setBusy(false);
    };

    return (
        <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
            <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
                <DialogHeader><DialogTitle>Import CSV</DialogTitle></DialogHeader>
                <div className="space-y-3">
                    <Input type="file" accept=".csv,text/csv" onChange={onFile} data-testid="csv-file" />
                    <div>
                        <Label className="text-xs text-zinc-500">…or paste CSV</Label>
                        <textarea className="w-full border rounded-md p-2 text-sm font-mono h-28 bg-transparent"
                                  value={csvText} onChange={(e) => { setCsvText(e.target.value); parseHeader(e.target.value); }} />
                    </div>
                    {columns.length > 0 && (
                        <div className="space-y-2">
                            <Label className="text-sm">Map columns → fields</Label>
                            {columns.map((c) => (
                                <div key={c} className="flex items-center gap-2 text-sm">
                                    <span className="w-40 truncate text-zinc-500">{c}</span>
                                    <Select value={mapping[c] || "__skip__"} onValueChange={(v) => setMapping((m) => ({ ...m, [c]: v === "__skip__" ? "" : v }))}>
                                        <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="__skip__">— skip —</SelectItem>
                                            {fields.map((f) => <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                            ))}
                        </div>
                    )}
                    <p className="text-[11px] text-zinc-400">Limits: 5MB · 5,000 rows · 60 columns. Invalid rows are reported and skipped.</p>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    <Button onClick={run} disabled={busy} data-testid="run-import-btn">{busy ? "Importing…" : "Import"}</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

// ------------------------------------------------------------------ Fields
function FieldsTab({ coll, onSaved }) {
    const [fields, setFields] = useState(coll.fields || []);
    const [displayField, setDisplayField] = useState(coll.display_field || "");
    const [busy, setBusy] = useState(false);
    const save = async () => {
        setBusy(true);
        try { await updateCollection(coll.id, { fields, display_field: displayField || undefined }); toast.success("Schema updated (new version)"); onSaved(); }
        catch (e) { toast.error(apiErr(e)); }
        setBusy(false);
    };
    return (
        <div className="max-w-3xl space-y-4">
            <p className="text-sm text-zinc-500">Editing fields creates a new schema version. Existing items are preserved.</p>
            <FieldsEditor value={fields} onChange={setFields} />
            <div className="flex items-center gap-2">
                <Label className="text-sm">Display field</Label>
                <Select value={displayField} onValueChange={setDisplayField}>
                    <SelectTrigger className="w-56"><SelectValue placeholder="Choose…" /></SelectTrigger>
                    <SelectContent>{(fields || []).filter((f) => f.label).map((f, i) => <SelectItem key={i} value={f.key || f.label}>{f.label}</SelectItem>)}</SelectContent>
                </Select>
            </div>
            <Button onClick={save} disabled={busy} data-testid="save-fields-btn"><Save className="w-4 h-4 mr-1" />{busy ? "Saving…" : "Save schema"}</Button>
        </div>
    );
}

// ------------------------------------------------------------------ Dynamic pages
function PagesTab({ coll }) {
    const [sites, setSites] = useState([]);
    const [templates, setTemplates] = useState([]);
    const [form, setForm] = useState({ site_slug: "", route_base: coll.internal_id, slug_field: "", seoTitle: "" });
    const [busy, setBusy] = useState(false);

    const slugFields = (coll.fields || []).filter((f) => f.type === "slug");
    const reload = useCallback(async () => {
        try {
            const [s, t] = await Promise.all([api.get("/sites").then((r) => r.data.sites || []), listTemplates()]);
            setSites(s);
            setTemplates(t.filter((x) => x.collection_id === coll.id));
            if (s[0]?.slug && !form.site_slug) setForm((f) => ({ ...f, site_slug: s[0].slug }));
        } catch (e) { /* noop */ }
    }, [coll.id]); // eslint-disable-line react-hooks/exhaustive-deps
    useEffect(() => { reload(); }, [reload]);

    const create = async () => {
        if (!form.site_slug) return toast.error("Choose a site");
        setBusy(true);
        try {
            await createTemplate({
                collection_id: coll.id, site_slug: form.site_slug,
                route_base: form.route_base, slug_field: form.slug_field || undefined,
                detail_layout: { blocks: [] }, list_layout: { blocks: [] },
                seo: form.seoTitle ? { title: form.seoTitle } : {},
            });
            toast.success("Dynamic page created (draft)"); reload();
        } catch (e) { toast.error(apiErr(e)); }
        setBusy(false);
    };
    const publish = async (t) => {
        try { await updateTemplate(t.id, { status: t.status === "published" ? "draft" : "published" }); toast.success("Updated"); reload(); }
        catch (e) { toast.error(apiErr(e)); }
    };

    const backendBase = API.replace(/\/api$/, "");

    return (
        <div className="max-w-3xl space-y-5">
            <Card className="p-4 space-y-3">
                <h3 className="font-medium">Create a dynamic page</h3>
                <p className="text-sm text-zinc-500">One template renders a live page for every item in this collection.</p>
                <div className="grid sm:grid-cols-2 gap-3">
                    <div>
                        <Label>Site</Label>
                        <Select value={form.site_slug} onValueChange={(v) => setForm({ ...form, site_slug: v })}>
                            <SelectTrigger data-testid="tpl-site"><SelectValue placeholder="Choose a site" /></SelectTrigger>
                            <SelectContent>{sites.map((s) => <SelectItem key={s.slug} value={s.slug}>{s.name || s.slug}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div><Label>Route</Label><Input value={form.route_base} onChange={(e) => setForm({ ...form, route_base: e.target.value })} data-testid="tpl-route" /></div>
                    <div>
                        <Label>Slug field</Label>
                        <Select value={form.slug_field || "__auto__"} onValueChange={(v) => setForm({ ...form, slug_field: v === "__auto__" ? "" : v })}>
                            <SelectTrigger><SelectValue placeholder="Auto" /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="__auto__">Auto (from display field)</SelectItem>
                                {slugFields.map((f) => <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div><Label>SEO title template</Label><Input value={form.seoTitle} onChange={(e) => setForm({ ...form, seoTitle: e.target.value })} placeholder="{{name}} — Our team" /></div>
                </div>
                <Button onClick={create} disabled={busy} data-testid="create-template-btn"><Plus className="w-4 h-4 mr-1" />Create</Button>
            </Card>

            <div className="space-y-3">
                {templates.map((t) => (
                    <Card key={t.id} className="p-4 flex items-center justify-between gap-3" data-testid={`template-${t.route_base}`}>
                        <div className="min-w-0">
                            <div className="font-medium">/{t.route_base} <Badge variant={t.status === "published" ? "default" : "secondary"} className="ml-2 text-[10px]">{t.status}</Badge></div>
                            <a className="text-xs text-brand-copper flex items-center gap-1 mt-1" href={`${backendBase}/site/${t.site_slug}/${t.route_base}`} target="_blank" rel="noreferrer">
                                {backendBase}/site/{t.site_slug}/{t.route_base} <ExternalLink className="w-3 h-3" />
                            </a>
                        </div>
                        <Button size="sm" variant={t.status === "published" ? "outline" : "default"} onClick={() => publish(t)} data-testid={`publish-${t.route_base}`}>
                            {t.status === "published" ? "Unpublish" : "Publish"}
                        </Button>
                    </Card>
                ))}
                {templates.length === 0 && <p className="text-sm text-zinc-500">No dynamic pages yet.</p>}
            </div>
        </div>
    );
}
