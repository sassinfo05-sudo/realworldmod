import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { FileText, Shield, Info, Eye, ShieldCheck, AlertTriangle } from "lucide-react";

const TABS = [
    { key: "tos_html",     label: "Terms of Service", icon: FileText, path: "/terms",
      hint: "Shown at /terms. Overrides the template. Leave blank to keep the built-in starter copy." },
    { key: "privacy_html", label: "Privacy Policy",   icon: Shield,   path: "/privacy",
      hint: "Shown at /privacy. Overrides the template. Leave blank to keep the built-in starter copy." },
    { key: "about_html",   label: "About / Company",  icon: Info,     path: "/about",
      hint: "Optional. Any HTML — headings, paragraphs, lists — will render inside the branded page shell." },
];

export default function LegalEditor() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [legal, setLegal] = useState({ tos_html: "", privacy_html: "", about_html: "" });
    const [active, setActive] = useState("tos_html");
    const [gate, setGate] = useState(null);
    const [gateSaving, setGateSaving] = useState(false);
    const [confirmChecked, setConfirmChecked] = useState(false);

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get("/founder/settings");
                setLegal(data.legal || { tos_html: "", privacy_html: "", about_html: "" });
            } catch (e) { toast.error("Couldn't load"); }
            finally { setLoading(false); }
        })();
        (async () => {
            try {
                const { data } = await api.get("/founder/launch-gate");
                setGate(data);
                setConfirmChecked(!!data.legal_reviewed);
            } catch (e) { /* gate card just won't render */ }
        })();
    }, []);

    async function saveGate(nextReviewed) {
        setGateSaving(true);
        try {
            const { data } = await api.put("/founder/launch-gate", { legal_reviewed: nextReviewed });
            setGate(data);
            setConfirmChecked(!!data.legal_reviewed);
            toast.success(nextReviewed
                ? "Legal review confirmed — launch gate is now GREEN."
                : "Legal review confirmation withdrawn — launch gate is RED.");
        } catch (e) { toast.error("Couldn't update the launch gate"); }
        finally { setGateSaving(false); }
    }

    async function save() {
        setSaving(true);
        try {
            await api.put("/founder/settings", { legal });
            toast.success("Legal copy saved");
        } catch (e) { toast.error("Save failed"); }
        finally { setSaving(false); }
    }

    if (loading) return <div className="p-10 text-zinc-500">Loading legal editor…</div>;

    const tab = TABS.find((t) => t.key === active);

    return (
        <div className="p-6 md:p-10" data-testid="founder-legal-page">
            <div className="max-w-5xl">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Legal & About</div>
                <h1 className="font-display text-3xl text-brand-ink">Your Terms, Privacy and About copy.</h1>
                <p className="mt-3 text-zinc-600 max-w-2xl">
                    Paste your own HTML for each page. Anything you leave blank keeps the built-in starter copy so
                    you&apos;re never left with an empty page. These pages inherit your brand name and footer automatically.
                </p>

                {/* ---- LEGAL REVIEW LAUNCH GATE ---- */}
                {gate && (
                    <div data-testid="legal-review-gate"
                         className={`mt-8 rounded-2xl border p-6 ${
                             gate.legal_reviewed
                                 ? "border-emerald-300 bg-emerald-50"
                                 : "border-amber-300 bg-amber-50"
                         }`}>
                        <div className="flex items-start gap-3">
                            {gate.legal_reviewed
                                ? <ShieldCheck className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                                : <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />}
                            <div className="flex-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-medium text-brand-ink">Legal review launch gate</span>
                                    <span data-testid="legal-gate-status"
                                          className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                                              gate.legal_reviewed
                                                  ? "bg-emerald-600 text-white"
                                                  : "bg-amber-600 text-white"
                                          }`}>
                                        {gate.legal_reviewed ? "GREEN — confirmed" : "RED — not confirmed"}
                                    </span>
                                </div>
                                <p className="text-sm text-zinc-600 mt-2 max-w-2xl">
                                    The built-in Terms and Privacy copy is a <strong>starting template — it is NOT
                                    legal advice and has NOT been approved by counsel</strong>. Until a human confirms
                                    review below, every public <code>/terms</code> and <code>/privacy</code> page shows
                                    a visitor banner saying the document is not yet confirmed, and this platform is not
                                    launch-ready.
                                </p>
                                {gate.legal_reviewed && gate.legal_reviewed_by && (
                                    <p className="text-xs text-emerald-700 mt-2" data-testid="legal-gate-meta">
                                        Confirmed by {gate.legal_reviewed_by}
                                        {gate.legal_reviewed_at ? ` on ${new Date(gate.legal_reviewed_at).toLocaleString()}` : ""}.
                                    </p>
                                )}
                                <label className="flex items-start gap-2 mt-4 text-sm text-brand-ink cursor-pointer select-none">
                                    <input type="checkbox"
                                           data-testid="legal-gate-checkbox"
                                           checked={confirmChecked}
                                           onChange={(e) => setConfirmChecked(e.target.checked)}
                                           className="mt-0.5 h-4 w-4 rounded border-zinc-400" />
                                    <span>
                                        I confirm that qualified legal counsel has reviewed and approved the Terms of
                                        Service and Privacy Policy for this platform.
                                    </span>
                                </label>
                                <div className="mt-4 flex items-center gap-3 flex-wrap">
                                    <Button
                                        data-testid="legal-gate-save-btn"
                                        onClick={() => saveGate(confirmChecked)}
                                        disabled={gateSaving || confirmChecked === !!gate.legal_reviewed}
                                        className={confirmChecked
                                            ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                                            : "bg-amber-600 hover:bg-amber-700 text-white"}>
                                        {gateSaving
                                            ? "Saving…"
                                            : confirmChecked
                                                ? "Confirm legal review (open the gate)"
                                                : "Withdraw confirmation (close the gate)"}
                                    </Button>
                                    <span className="text-xs text-zinc-500">
                                        Recorded in the audit log with your identity and timestamp.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                <div className="mt-8 border-b border-brand-line flex gap-1 flex-wrap" data-testid="legal-tabs">
                    {TABS.map((t) => (
                        <button key={t.key} onClick={() => setActive(t.key)}
                                data-testid={`legal-tab-${t.key}`}
                                className={`inline-flex items-center gap-1.5 px-3 py-2 text-sm rounded-t-md ${
                                    active === t.key ? "bg-white border border-b-white border-brand-line text-brand-ink font-medium -mb-px" : "text-zinc-500 hover:text-brand-ink"
                                }`}>
                            <t.icon className="w-3.5 h-3.5" /> {t.label}
                        </button>
                    ))}
                </div>

                <div className="mt-4 rounded-2xl border border-brand-line bg-white p-6">
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                        <div>
                            <div className="text-brand-ink font-medium">{tab.label} content (HTML)</div>
                            <div className="text-sm text-zinc-500 mt-1">{tab.hint}</div>
                        </div>
                        <a href={tab.path} target="_blank" rel="noreferrer"
                           className="inline-flex items-center gap-1 text-sm text-brand-copper hover:underline">
                            <Eye className="w-3.5 h-3.5" /> Preview live page
                        </a>
                    </div>
                    <textarea rows={22}
                              value={legal[active] || ""}
                              onChange={(e) => setLegal({ ...legal, [active]: e.target.value })}
                              data-testid={`legal-input-${active}`}
                              className="mt-4 w-full font-mono text-sm border border-brand-line rounded-md px-3 py-3"
                              placeholder={`<h2>1. Service</h2>\n<p>…</p>\n<h2>2. Accounts</h2>\n<p>…</p>`} />
                    <div className="mt-3 text-xs text-zinc-500">
                        Tip: use <code>&lt;h2&gt;</code>, <code>&lt;p&gt;</code>, <code>&lt;ul&gt;</code>, <code>&lt;a&gt;</code>.
                        Styling is applied automatically by our <code>prose</code> theme.
                    </div>
                </div>

                <div className="mt-6 flex items-center gap-3">
                    <Button onClick={save} disabled={saving}
                            data-testid="legal-save-btn"
                            className="bg-brand-copper hover:bg-brand-copperHover text-white">
                        {saving ? "Saving…" : "Save all legal copy"}
                    </Button>
                    <span className="text-xs text-zinc-500">Applies immediately to visitors.</span>
                </div>
            </div>
        </div>
    );
}
