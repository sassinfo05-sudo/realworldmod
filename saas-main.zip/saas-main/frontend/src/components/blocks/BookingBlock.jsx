import { useEffect, useMemo, useState } from "react";
import { getAttribution } from "@/lib/attribution";

/**
 * BookingBlock — public site block. Loads services + availability from the
 * current site's public API, lets a visitor pick a service → slot → enter
 * details → confirm.
 *
 * All calls go through window.location.origin so the block is portable to any
 * host (custom-domain support).
 */
export default function BookingBlock({ block, theme }) {
    const { props = {} } = block;
    const websiteSlug = props.website_slug || (typeof window !== "undefined" &&
        window.location.pathname.startsWith("/site/") ? window.location.pathname.split("/")[2] : null);
    const [services, setServices] = useState([]);
    const [selectedService, setSelectedService] = useState(null);
    const [slots, setSlots] = useState([]);
    const [selectedSlot, setSelectedSlot] = useState(null);
    const [form, setForm] = useState({ name: "", email: "", phone: "", customer_notes: "" });
    const [state, setState] = useState("idle"); // idle | booking | done | error
    const [confirmation, setConfirmation] = useState(null);
    const [error, setError] = useState(null);

    const API = process.env.REACT_APP_BACKEND_URL;

    useEffect(() => {
        if (!websiteSlug) return;
        (async () => {
            try {
                // Load services via the public availability endpoint's parent —
                // we simply hit /api/public/sites/{slug} to check the site, then
                // the owner-loaded service list is exposed at:
                const r = await fetch(`${API}/api/public/booking/services?website_slug=${websiteSlug}`);
                // If public services listing not implemented, degrade gracefully
                if (r.ok) {
                    const d = await r.json();
                    setServices(d.services || []);
                }
            } catch {}
        })();
    }, [websiteSlug]);

    const dateFrom = useMemo(() => new Date().toISOString().slice(0, 10), []);
    const dateTo = useMemo(() => {
        const d = new Date(); d.setDate(d.getDate() + 14);
        return d.toISOString().slice(0, 10);
    }, []);

    useEffect(() => {
        if (!selectedService || !websiteSlug) return;
        (async () => {
            const r = await fetch(`${API}/api/public/booking/availability?website_slug=${websiteSlug}&service_id=${selectedService.id}&date_from=${dateFrom}&date_to=${dateTo}`);
            if (r.ok) {
                const d = await r.json();
                setSlots((d.slots || []).slice(0, 40));
            }
        })();
    }, [selectedService, websiteSlug, dateFrom, dateTo, API]);

    async function book() {
        setState("booking"); setError(null);
        try {
            const r = await fetch(`${API}/api/public/booking/book`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    website_slug: websiteSlug,
                    attribution: getAttribution(),
                    service_id: selectedService.id,
                    start_at: selectedSlot.start_at,
                    staff_id: selectedSlot.staff_id,
                    ...form,
                }),
            });
            if (!r.ok) {
                const err = await r.json().catch(() => ({}));
                throw new Error(err?.detail?.detail || err?.detail || `HTTP ${r.status}`);
            }
            const data = await r.json();
            setConfirmation(data);
            setState("done");
        } catch (e) {
            setState("error");
            setError(e.message);
        }
    }

    if (!websiteSlug) return null;

    return (
        <section className="py-16" style={{ backgroundColor: theme?.background }} data-testid="public-booking-block">
            <div className="mx-auto max-w-3xl px-6">
                <div className="rounded-2xl border p-6 md:p-8" style={{ background: theme?.surface, borderColor: `${theme?.foreground}14` }}>
                    <h2 data-heading className="text-2xl md:text-3xl font-semibold" style={{ color: theme?.foreground }}>
                        {props.headline || "Book a visit"}
                    </h2>
                    {props.subheadline && <p className="mt-2 text-sm" style={{ color: `${theme?.foreground}A0` }}>{props.subheadline}</p>}

                    {state === "done" && confirmation ? (
                        <div className="mt-6 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 p-4" data-testid="booking-success">
                            <div className="font-medium">You're booked.</div>
                            <div className="text-sm mt-1">Confirmation number: {confirmation.booking_number}</div>
                            <div className="text-xs mt-2 font-mono">
                                Reschedule/cancel links have been emailed to you.
                            </div>
                        </div>
                    ) : (
                        <>
                            {/* Service picker */}
                            <div className="mt-6">
                                <div className="text-xs uppercase tracking-widest mb-2" style={{ color: `${theme?.foreground}90` }}>1. Pick a service</div>
                                <div className="grid sm:grid-cols-2 gap-2" data-testid="booking-services">
                                    {services.map((s) => (
                                        <button key={s.id} onClick={() => { setSelectedService(s); setSelectedSlot(null); }}
                                                data-testid={`booking-service-${s.id}`}
                                                className={`text-left rounded-md border p-3 hover:border-brand-copper ${selectedService?.id === s.id ? "border-2 border-brand-copper" : "border-brand-line"}`}>
                                            <div className="text-sm font-medium">{s.name}</div>
                                            <div className="text-xs text-zinc-500 mt-1">{s.duration_minutes} min · ${(s.price_cents/100).toFixed(0)}</div>
                                        </button>
                                    ))}
                                    {!services.length && <div className="text-xs text-zinc-500">No bookable services yet.</div>}
                                </div>
                            </div>

                            {/* Slot picker */}
                            {selectedService && (
                                <div className="mt-6">
                                    <div className="text-xs uppercase tracking-widest mb-2" style={{ color: `${theme?.foreground}90` }}>2. Pick a time</div>
                                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-64 overflow-y-auto" data-testid="booking-slots">
                                        {slots.map((s) => (
                                            <button key={`${s.start_at}-${s.staff_id}`}
                                                        onClick={() => setSelectedSlot(s)}
                                                        data-testid={`booking-slot-${s.start_at}`}
                                                        className={`text-left rounded border p-2 text-xs ${selectedSlot?.start_at === s.start_at && selectedSlot?.staff_id === s.staff_id ? "border-2 border-brand-copper" : "border-brand-line"}`}>
                                                <div className="font-mono">{new Date(s.start_at).toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</div>
                                                {s.staff_display_name && <div className="text-zinc-500">{s.staff_display_name}</div>}
                                            </button>
                                        ))}
                                        {!slots.length && <div className="text-xs text-zinc-500 col-span-3">No open slots in the next 14 days.</div>}
                                    </div>
                                </div>
                            )}

                            {/* Contact form */}
                            {selectedSlot && (
                                <div className="mt-6 space-y-3" data-testid="booking-contact-form">
                                    <div className="text-xs uppercase tracking-widest mb-2" style={{ color: `${theme?.foreground}90` }}>3. Your details</div>
                                    <input type="text" placeholder="Full name" value={form.name}
                                             onChange={(e) => setForm({ ...form, name: e.target.value })}
                                             className="w-full rounded-md border px-3 py-2 text-sm"
                                             style={{ borderColor: `${theme?.foreground}26`, background: theme?.background }}
                                             data-testid="booking-input-name" />
                                    <input type="email" placeholder="Email" value={form.email}
                                             onChange={(e) => setForm({ ...form, email: e.target.value })}
                                             className="w-full rounded-md border px-3 py-2 text-sm"
                                             style={{ borderColor: `${theme?.foreground}26`, background: theme?.background }}
                                             data-testid="booking-input-email" />
                                    <input type="tel" placeholder="Phone (optional)" value={form.phone}
                                             onChange={(e) => setForm({ ...form, phone: e.target.value })}
                                             className="w-full rounded-md border px-3 py-2 text-sm"
                                             style={{ borderColor: `${theme?.foreground}26`, background: theme?.background }}
                                             data-testid="booking-input-phone" />
                                    <textarea rows={3} placeholder="Anything we should know?" value={form.customer_notes}
                                                    onChange={(e) => setForm({ ...form, customer_notes: e.target.value })}
                                                    className="w-full rounded-md border px-3 py-2 text-sm"
                                                    style={{ borderColor: `${theme?.foreground}26`, background: theme?.background }}
                                                    data-testid="booking-input-notes" />
                                    {error && <div className="rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm">{error}</div>}
                                    <button onClick={book} disabled={state === "booking" || !form.name || !form.email}
                                                className="w-full inline-flex items-center justify-center px-5 py-3 rounded-md font-medium text-white"
                                                style={{ background: theme?.primary }}
                                                data-testid="booking-confirm-btn">
                                        {state === "booking" ? "Booking…" : (props.confirm_label || "Confirm booking")}
                                    </button>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>
        </section>
    );
}
