import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import PublicNav from "@/components/PublicNav";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Search, Check, X, Sparkles, ArrowRight } from "lucide-react";

const FIELDS = [
    { key: "business_name", label: "Business name", area: false },
    { key: "industry_freetext", label: "What they do", area: false },
    { key: "tagline", label: "Tagline", area: false },
    { key: "about", label: "About", area: true },
    { key: "services_text", label: "Services", area: true },
    { key: "service_area", label: "Service area", area: false },
    { key: "hours_text", label: "Hours", area: false },
    { key: "differentiators", label: "What makes them stand out", area: true },
];

export default function Research() {
    const navigate = useNavigate();
    const [name, setName] = useState("");
    const [country, setCountry] = useState("");
    const [extra, setExtra] = useState("");
    const [busy, setBusy] = useState(false);
    const [facts, setFacts] = useState(null);
    const [approved, setApproved] = useState({});
    const [industry, setIndustry] = useState("other");
    const [tone, setTone] = useState("professional");

    async function run() {
        if (!name.trim()) return toast.error("Enter your business name");
        setBusy(true);
        try {
            const { data } = await api.post("/onboarding/research", { business_name: name, country, extra });
            const f = data.facts || {};
            setFacts(f);
            setIndustry(f.industry || "other");
            setTone(f.tone || "professional");
            const init = {};
            FIELDS.forEach((fl) => { init[fl.key] = true; });
            setApproved(init);
            toast.success("Here's what we found — approve what's right");
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Research failed");
        } finally { setBusy(false); }
    }

    function setFact(k, v) { setFacts((f) => ({ ...f, [k]: v })); }
    function toggle(k) { setApproved((a) => ({ ...a, [k]: !a[k] })); }

    async function useThese() {
        const answers = { industry, tone };
        FIELDS.forEach((fl) => { if (approved[fl.key]) answers[fl.key] = facts[fl.key]; });
        try {
            await api.post("/onboarding/research/apply", { answers });
            toast.success("Saved — let's finish your site");
            navigate("/onboarding");
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Could not save");
        }
    }

    return (
        <div className="min-h-screen bg-brand-surface text-brand-ink">
            <PublicNav />
            <div className="mx-auto max-w-3xl px-6 py-14">
                <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-3"><Sparkles className="w-4 h-4" /> Research my business</div>
                <h1 className="font-display text-4xl text-brand-ink font-medium leading-tight">Already have a business? Let AI find the details.</h1>
                <p className="mt-3 text-zinc-600">Type your name and location — we'll pull together a starting profile you can approve or fix. Nothing is published until you say so.</p>

                <div className="mt-8 rounded-2xl border border-brand-line bg-white p-6 grid sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                        <label className="block text-xs text-zinc-500 mb-1">Business name</label>
                        <input value={name} onChange={(e) => setName(e.target.value)} data-testid="research-name"
                            className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-copper/30" placeholder="e.g., Riverside Plumbing" />
                    </div>
                    <div>
                        <label className="block text-xs text-zinc-500 mb-1">Country / city</label>
                        <input value={country} onChange={(e) => setCountry(e.target.value)} data-testid="research-country"
                            className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-copper/30" placeholder="e.g., Austin, USA" />
                    </div>
                    <div>
                        <label className="block text-xs text-zinc-500 mb-1">Anything else (optional)</label>
                        <input value={extra} onChange={(e) => setExtra(e.target.value)} data-testid="research-extra"
                            className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-copper/30" placeholder="website, specialty…" />
                    </div>
                    <div className="sm:col-span-2">
                        <Button onClick={run} disabled={busy} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="research-run">
                            <Search className="w-4 h-4 mr-1.5" /> {busy ? "Researching…" : "Find my details"}
                        </Button>
                    </div>
                </div>

                {facts && (
                    <div className="mt-8" data-testid="research-results">
                        <div className="flex items-center justify-between">
                            <h2 className="font-display text-2xl text-brand-ink">Review &amp; approve</h2>
                            {facts.confidence && <span className="text-xs text-zinc-500">confidence: {facts.confidence}</span>}
                        </div>
                        {facts.note && <p className="mt-1 text-sm text-zinc-500">{facts.note}</p>}
                        <div className="mt-5 space-y-3">
                            {FIELDS.map((fl) => (
                                <div key={fl.key} className={`rounded-xl border p-4 ${approved[fl.key] ? "border-brand-line bg-white" : "border-brand-line bg-zinc-50 opacity-60"}`}>
                                    <div className="flex items-center justify-between mb-1">
                                        <label className="text-xs uppercase tracking-widest text-zinc-500">{fl.label}</label>
                                        <button onClick={() => toggle(fl.key)} data-testid={`research-toggle-${fl.key}`}
                                            className={`inline-flex items-center gap-1 text-xs rounded-full px-2 py-0.5 border ${approved[fl.key] ? "text-emerald-600 border-emerald-200 bg-emerald-50" : "text-zinc-500 border-brand-line"}`}>
                                            {approved[fl.key] ? <><Check className="w-3 h-3" /> Keep</> : <><X className="w-3 h-3" /> Skip</>}
                                        </button>
                                    </div>
                                    {fl.area ? (
                                        <textarea value={facts[fl.key] || ""} onChange={(e) => setFact(fl.key, e.target.value)} rows={3}
                                            className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-copper/30" />
                                    ) : (
                                        <input value={facts[fl.key] || ""} onChange={(e) => setFact(fl.key, e.target.value)}
                                            className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-copper/30" />
                                    )}
                                </div>
                            ))}
                        </div>
                        <div className="mt-6">
                            <Button onClick={useThese} className="bg-brand-ink hover:bg-black text-white" data-testid="research-use">
                                Use these &amp; build my site <ArrowRight className="w-4 h-4 ml-1" />
                            </Button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
