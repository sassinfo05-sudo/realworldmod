import { useEffect, useState } from "react";

/**
 * StoreBlock — public site storefront section. Shows the tenant's active,
 * in-stock products right on their own website and lets a visitor buy.
 *
 * Portable to any host (custom domains): products + checkout are resolved by
 * the site slug via /api/public/store/by-site/{slug}/*.
 */
export default function StoreBlock({ block, theme }) {
    const { props = {} } = block;
    const {
        heading = "Shop",
        subheading = "Browse our products and check out securely.",
        columns = 3,
    } = props;

    const API = process.env.REACT_APP_BACKEND_URL;
    const websiteSlug = props.website_slug || (typeof window !== "undefined" &&
        window.location.pathname.startsWith("/site/") ? window.location.pathname.split("/")[2] : null);

    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [buying, setBuying] = useState(null); // product being bought
    const [buyer, setBuyer] = useState({ name: "", email: "", phone: "", address: "" });
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        if (!websiteSlug) { setLoading(false); return; }
        (async () => {
            try {
                const r = await fetch(`${API}/api/public/store/by-site/${websiteSlug}/products`);
                if (r.ok) {
                    const d = await r.json();
                    setProducts(d.products || []);
                }
            } catch { /* ignore */ } finally { setLoading(false); }
        })();
    }, [websiteSlug, API]);

    const money = (cents, cur = "USD") =>
        new Intl.NumberFormat(undefined, { style: "currency", currency: cur }).format((cents || 0) / 100);

    async function checkout() {
        if (!buying) return;
        setSubmitting(true); setError(null);
        try {
            const r = await fetch(`${API}/api/public/store/by-site/${websiteSlug}/buy-now`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ product_id: buying.id, qty: 1, buyer }),
            });
            const d = await r.json();
            if (!r.ok) throw new Error(d.detail || "Checkout could not start");
            // checkout_url is in-app for simulated (/pay/simulated/:sid) or hosted (Stripe)
            if (d.checkout_url) {
                window.location.href = d.checkout_url.startsWith("http")
                    ? d.checkout_url : d.checkout_url;
            }
        } catch (e) {
            setError(e.message || "Something went wrong");
            setSubmitting(false);
        }
    }

    const gridCols = { 2: "sm:grid-cols-2", 3: "sm:grid-cols-2 lg:grid-cols-3", 4: "sm:grid-cols-2 lg:grid-cols-4" }[columns] || "sm:grid-cols-2 lg:grid-cols-3";

    return (
        <section className="py-16 px-6" style={{ backgroundColor: "var(--tenant-bg)" }}>
            <div className="max-w-6xl mx-auto">
                <div className="text-center mb-10">
                    <h2 data-heading data-editable-field="heading" className="text-3xl font-semibold" style={{ color: "var(--tenant-fg)" }}>{heading}</h2>
                    {subheading && <p data-editable-field="subheading" className="mt-2 text-base opacity-70" style={{ color: "var(--tenant-fg)" }}>{subheading}</p>}
                </div>

                {loading && <div className="text-center opacity-60" style={{ color: "var(--tenant-fg)" }}>Loading products…</div>}

                {!loading && !products.length && (
                    <div className="text-center rounded-xl border border-dashed py-12 px-6"
                        style={{ borderColor: "var(--tenant-fg)", opacity: 0.6, color: "var(--tenant-fg)" }}>
                        Your products will appear here on your live site. Add products in your dashboard → Store → Products.
                    </div>
                )}

                {!loading && products.length > 0 && (
                    <div className={`grid grid-cols-1 ${gridCols} gap-6`}>
                        {products.map((p) => (
                            <div key={p.id} className="rounded-xl overflow-hidden border flex flex-col transition-transform duration-200 hover:-translate-y-1 hover:shadow-lg"
                                style={{ backgroundColor: "var(--tenant-surface)", borderColor: "rgba(0,0,0,0.08)" }}>
                                {p.image_url
                                    ? <img src={p.image_url} alt={p.name} className="w-full h-48 object-cover" loading="lazy" />
                                    : <div className="w-full h-48 flex items-center justify-center opacity-40" style={{ backgroundColor: "var(--tenant-bg)", color: "var(--tenant-fg)" }}>No image</div>}
                                <div className="p-4 flex flex-col flex-1">
                                    <h3 className="font-medium" style={{ color: "var(--tenant-fg)" }}>{p.name}</h3>
                                    {p.description && <p className="text-sm mt-1 opacity-70 line-clamp-2" style={{ color: "var(--tenant-fg)" }}>{p.description}</p>}
                                    <div className="mt-auto pt-4 flex items-center justify-between">
                                        <span className="font-semibold" style={{ color: "var(--tenant-fg)" }}>{money(p.price_cents, p.currency)}</span>
                                        <button onClick={() => { setBuying(p); setError(null); }}
                                            className="px-4 py-2 rounded-lg text-white text-sm font-medium transition-opacity hover:opacity-90"
                                            style={{ backgroundColor: "var(--tenant-primary)" }}>
                                            Buy now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Buyer modal */}
            {buying && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => !submitting && setBuying(null)}>
                    <div className="w-full max-w-md rounded-xl p-6" style={{ backgroundColor: "var(--tenant-surface)" }} onClick={(e) => e.stopPropagation()}>
                        <h3 className="text-lg font-semibold mb-1" style={{ color: "var(--tenant-fg)" }}>Checkout — {buying.name}</h3>
                        <p className="text-sm opacity-70 mb-4" style={{ color: "var(--tenant-fg)" }}>{money(buying.price_cents, buying.currency)}</p>
                        <div className="space-y-3">
                            {["name", "email", "phone", "address"].map((f) => (
                                <input key={f} type={f === "email" ? "email" : "text"}
                                    placeholder={{ name: "Full name", email: "Email", phone: "Phone (optional)", address: "Shipping address" }[f]}
                                    value={buyer[f]} onChange={(e) => setBuyer({ ...buyer, [f]: e.target.value })}
                                    className="w-full border rounded-md px-3 py-2 text-sm"
                                    style={{ borderColor: "rgba(0,0,0,0.15)", color: "var(--tenant-fg)", backgroundColor: "var(--tenant-bg)" }} />
                            ))}
                            {error && <p className="text-sm text-red-500">{error}</p>}
                        </div>
                        <div className="mt-5 flex gap-2 justify-end">
                            <button onClick={() => setBuying(null)} disabled={submitting}
                                className="px-4 py-2 rounded-lg text-sm border" style={{ borderColor: "rgba(0,0,0,0.15)", color: "var(--tenant-fg)" }}>Cancel</button>
                            <button onClick={checkout} disabled={submitting || !buyer.email}
                                className="px-4 py-2 rounded-lg text-white text-sm font-medium disabled:opacity-50"
                                style={{ backgroundColor: "var(--tenant-primary)" }}>
                                {submitting ? "Starting…" : "Continue to payment"}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </section>
    );
}
