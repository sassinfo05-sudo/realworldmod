"""URL import flow: fetch a customer's existing site, extract facts, generate an improved one.

- Respects robots.txt for the target host.
- Caps pages fetched, total bytes and time. No JS rendering — HTTP only.
- Never touches the external site (read-only).
- Runs the extracted facts through the same Phase 1 pipeline to produce an improved
  BusinessProfile + Website block JSON.
"""
import asyncio
import logging
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse
from urllib import robotparser

import httpx
from bs4 import BeautifulSoup
from bson import ObjectId
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel, HttpUrl

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import ImportRun, User
from ..services.generation import generate_business_profile, generate_website
from ..services.llm import LlmError, generate_json

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/import", tags=["import"])

_MAX_PAGES = 6
_MAX_BYTES = 1_500_000
_TIMEOUT = 10.0
_UA = "Zanelvo-Importer/1.0 (+https://zanelvo.com/bot)"
_MAX_REDIRECTS = 5


def _is_public_ip(ip_str: str) -> bool:
    import ipaddress
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
                or ip.is_reserved or ip.is_unspecified or getattr(ip, "is_site_local", False))


async def _resolve_public(host: str) -> Optional[str]:
    """Resolve `host` and return one public IP, or None when ANY resolved address is private /
    loopback / link-local / metadata (SSRF + DNS-rebinding guard: we connect to the resolved IP)."""
    import socket
    if not host or host.lower() in ("localhost",) or host.endswith(".local") or host.endswith(".internal"):
        return None
    try:
        infos = await asyncio.get_event_loop().getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except Exception:
        return None
    ips = {i[4][0] for i in infos}
    if not ips or any(not _is_public_ip(ip) for ip in ips):
        return None
    return sorted(ips)[0]


def _url_ok(url: str) -> bool:
    p = urlparse(url)
    return p.scheme in ("http", "https") and bool(p.hostname) and p.port in (None, 80, 443)


async def _safe_get(client: httpx.AsyncClient, url: str, timeout: float = _TIMEOUT) -> Optional[httpx.Response]:
    """GET with manual redirect following; every hop must be a public http(s) host."""
    cur = url
    for _ in range(_MAX_REDIRECTS + 1):
        if not _url_ok(cur):
            return None
        host = urlparse(cur).hostname or ""
        if await _resolve_public(host) is None:
            return None
        r = await client.get(cur, timeout=timeout, follow_redirects=False, headers={"User-Agent": _UA})
        if r.status_code in (301, 302, 303, 307, 308) and r.headers.get("location"):
            cur = urljoin(cur, r.headers["location"])
            continue
        return r
    return None


async def _fetch(url: str, client: httpx.AsyncClient) -> Optional[str]:
    try:
        r = await _safe_get(client, url)
        if r is None or r.status_code >= 400:
            return None
        ct = r.headers.get("content-type", "").lower()
        if "text/html" not in ct:
            return None
        if len(r.content) > _MAX_BYTES:
            return r.text[:_MAX_BYTES]
        return r.text
    except Exception:
        return None


async def _fetch_pages(source_url: str) -> List[Dict[str, Any]]:
    """Return a list of {url, title, text_snippet, links} for up to _MAX_PAGES pages of the site."""
    parsed = urlparse(source_url)
    base = f"{parsed.scheme}://{parsed.netloc}"
    if not _url_ok(source_url) or await _resolve_public(parsed.hostname or "") is None:
        return []
    # robots.txt gate
    rp = robotparser.RobotFileParser()
    try:
        async with httpx.AsyncClient() as c:
            r = await _safe_get(c, urljoin(base, "/robots.txt"), timeout=5.0)
            rp.parse(r.text.splitlines() if r is not None and r.status_code < 400 else [])
    except Exception:
        rp.parse([])

    async def _allowed(u: str) -> bool:
        try:
            return rp.can_fetch(_UA, u)
        except Exception:
            return True

    seen = set()
    queue = [source_url]
    out: List[Dict[str, Any]] = []
    async with httpx.AsyncClient() as client:
        while queue and len(out) < _MAX_PAGES:
            url = queue.pop(0)
            if url in seen or not await _allowed(url):
                continue
            seen.add(url)
            html = await _fetch(url, client)
            if not html:
                continue
            soup = BeautifulSoup(html, "html.parser")
            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()
            title = (soup.title.string.strip() if soup.title and soup.title.string else url)
            meta_desc = ""
            for m in soup.find_all("meta"):
                if (m.get("name") or "").lower() == "description":
                    meta_desc = (m.get("content") or "").strip()
            text = " ".join(soup.get_text(" ").split())[:4000]
            h1 = " | ".join(h.get_text(" ").strip() for h in soup.find_all("h1")[:3])
            h2 = " | ".join(h.get_text(" ").strip() for h in soup.find_all("h2")[:5])
            same_host_links = []
            for a in soup.find_all("a", href=True):
                href = urljoin(url, a["href"]).split("#")[0]
                if urlparse(href).netloc == parsed.netloc and href not in seen:
                    same_host_links.append(href)
            out.append({
                "url": url,
                "title": title,
                "meta_description": meta_desc,
                "h1": h1,
                "h2": h2,
                "text_snippet": text,
            })
            for link in same_host_links[:8]:
                if len(queue) < 20:
                    queue.append(link)
    return out


EXTRACT_SYSTEM = """You extract structured business facts from a set of scraped webpages.
Return ONLY a JSON object matching this schema (all fields optional except business_name):
{
  "business_name": "...",
  "industry": "home_services|automotive|beauty_wellness|professional_services|fitness|cleaning|events|other",
  "industry_label": "human label",
  "tagline": "...",
  "about": "2-4 sentence about paragraph",
  "services_text": "one per line: name — short note — price (skip prices you can't infer)",
  "service_area": "cities/regions if any",
  "hours_text": "free-form hours as written on the site",
  "differentiators": "3-5 short reasons customers pick them",
  "tone": "warm_professional|calm_confident|bold_direct|premium_editorial",
  "goals": ["more_calls","more_bookings","more_quotes","faster_payments","look_credible"],
  "contact_email": "",
  "contact_phone": ""
}
Rules: never invent facts. Only include what appears in the scraped text. If unsure, leave blank/empty list."""


async def _extract_facts(pages: List[Dict[str, Any]]) -> Dict[str, Any]:
    user_prompt = "\n\n".join(
        f"# {p['url']}\nTitle: {p['title']}\nMeta: {p['meta_description']}\nH1: {p['h1']}\nH2: {p['h2']}\n{p['text_snippet']}"
        for p in pages
    )
    return await generate_json(EXTRACT_SYSTEM, user_prompt[:12000])


def _planned_redirects(source_url: str, pages: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """Suggest sensible source-path → target-slug redirects for the owner to keep after migration."""
    mapping = []
    for p in pages:
        src_path = urlparse(p["url"]).path or "/"
        low = src_path.lower()
        if low in ("/", "/home", "/index.html"):
            target = "home"
        elif "service" in low:
            target = "services"
        elif "about" in low:
            target = "about"
        elif "contact" in low:
            target = "contact"
        else:
            target = "home"
        mapping.append({"from": src_path, "to": target, "source_title": p["title"]})
    return mapping


class ImportReq(BaseModel):
    source_url: HttpUrl


@router.post("/start")
async def start_import(req: ImportReq, background: BackgroundTasks,
                       user: User = Depends(current_user), org_id: str = Depends(require_org)):
    from ..services.entitlements import enforce_entitlement
    # SSRF guard up-front: public http(s) host only, no private / loopback / metadata targets.
    src = str(req.source_url)
    if not _url_ok(src) or await _resolve_public(urlparse(src).hostname or "") is None:
        raise HTTPException(400, "That address can't be imported. Use a public website URL (https://…).")
    # Import creates a second (or Nth) website — gate at start rather than mid-crawl.
    await enforce_entitlement(org_id, "websites", increment=1)
    db = get_db()
    run = ImportRun(org_id=org_id, user_id=user.id,
                    source_url=str(req.source_url), status="fetching")
    res = await db.import_runs.insert_one(run.to_mongo())
    run.id = str(res.inserted_id)
    background.add_task(_run_import, run.id, str(req.source_url), org_id, user.id)
    return {"ok": True, "import_run_id": run.id, "status": "fetching"}


async def _run_import(run_id: str, source_url: str, org_id: str, user_id: Optional[str]) -> None:
    db = get_db()
    try:
        pages = await _fetch_pages(source_url)
        await db.import_runs.update_one(
            {"_id": ObjectId(run_id)},
            {"$set": {"fetched_pages": pages, "status": "extracting", "updated_at": utc_now_iso()}},
        )
        if not pages:
            raise LlmError("Couldn't fetch any pages from that URL (robots.txt or unreachable)")

        facts = await _extract_facts(pages)
        redirects = _planned_redirects(source_url, pages)
        await db.import_runs.update_one(
            {"_id": ObjectId(run_id)},
            {"$set": {"extracted_facts": facts, "planned_redirects": redirects,
                      "status": "generating", "updated_at": utc_now_iso()}},
        )

        # Seed the Phase 1 pipeline with extracted facts
        answers = {
            "business_name": facts.get("business_name") or "",
            "industry": facts.get("industry") or "other",
            "services_text": facts.get("services_text") or "",
            "service_area": facts.get("service_area") or "",
            "hours_text": facts.get("hours_text") or "",
            "differentiators": facts.get("differentiators") or "",
            "tone": facts.get("tone") or "calm_confident",
            "goals": facts.get("goals") or [],
            "contact_email": facts.get("contact_email") or "",
            "contact_phone": facts.get("contact_phone") or "",
        }
        profile = await generate_business_profile(org_id, answers)
        prof_res = await db.business_profiles.insert_one(profile.to_mongo())
        profile.id = str(prof_res.inserted_id)

        website = await generate_website(org_id, profile)
        website.business_profile_id = profile.id
        web_res = await db.websites.insert_one(website.to_mongo())
        website.id = str(web_res.inserted_id)

        await db.import_runs.update_one(
            {"_id": ObjectId(run_id)},
            {"$set": {"generated_business_profile_id": profile.id,
                      "generated_website_id": website.id,
                      "status": "ready", "updated_at": utc_now_iso()}},
        )
    except LlmError as e:
        logger.warning("Import LLM error: %s", e)
        await db.import_runs.update_one(
            {"_id": ObjectId(run_id)},
            {"$set": {"status": "failed", "error": str(e), "updated_at": utc_now_iso()}},
        )
    except Exception as e:  # noqa: BLE001
        logger.exception("Import failed unexpectedly")
        await db.import_runs.update_one(
            {"_id": ObjectId(run_id)},
            {"$set": {"status": "failed", "error": f"{type(e).__name__}: {e}",
                      "updated_at": utc_now_iso()}},
        )


@router.get("/runs/{run_id}")
async def get_import_run(run_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.import_runs.find_one({"_id": ObjectId(run_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Import run not found")
    return ImportRun.from_mongo(doc).model_dump()


@router.get("/runs")
async def list_import_runs(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.import_runs.find({"org_id": org_id}).sort("created_at", -1).limit(20)
    out = []
    async for d in cursor:
        # trim heavy fields
        obj = ImportRun.from_mongo(d).model_dump()
        obj["fetched_pages"] = [{k: v for k, v in p.items() if k != "text_snippet"}
                                for p in obj.get("fetched_pages") or []]
        out.append(obj)
    return {"runs": out}
