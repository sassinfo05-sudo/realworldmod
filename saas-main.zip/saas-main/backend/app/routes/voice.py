"""Voice webhooks — Twilio inbound (TwiML) + Retell webhook — wired to the
receptionist agent pipeline (run_turn).

Both endpoints are LIVE and code-complete, but honestly labeled as
"awaiting binding": until the owner points a real Twilio number / Retell agent
at these URLs (see OWNER_SETUP_CHECKLIST.md), they only receive traffic in tests.

Org resolution: these are unauthenticated provider callbacks, so the tenant is resolved
STRICTLY from the verified dialed number (its owning org in the `phone_numbers` collection)
— for Twilio the POST `To` field, for Retell the `call.to_number` in the event envelope.
The legacy `?org_id=` selection and the "first receptionist" fallback are honoured ONLY in
non-production (dev/test/demo) so the demo works without a purchased number; in production an
unmapped number is refused. Signatures are verified before any processing (see
`_verify_voice_webhook`).

Exact bind steps:
  Twilio  -> Console > Phone Numbers > (your number) > Voice > "A CALL COMES IN"
             = Webhook, POST, URL: {BACKEND}/api/voice/twilio/inbound
  Retell  -> Dashboard > your Agent > Webhook URL: {BACKEND}/api/voice/retell/webhook
"""
from __future__ import annotations

import logging
import secrets
from typing import Any, Dict, Optional
from xml.sax.saxutils import escape as _xml_escape

from bson import ObjectId
from fastapi import APIRouter, Request
from fastapi.responses import Response

from ..db import get_db, utc_now_iso
from ..services.ai_agent_runner import run_turn

logger = logging.getLogger("zanelvo")

router = APIRouter(prefix="/voice", tags=["voice"])


async def _resolve_org_and_agent(db, *, dialed_number: Optional[str] = None,
                                 org_id_hint: Optional[str] = None):
    """Resolve the tenant STRICTLY from the verified dialed number (its owning org in the
    `phone_numbers` collection). The old `?org_id=` selection and the "first receptionist"
    fallback are only honoured in non-production so local/demo testing works without a
    purchased number; in production an unmapped number is refused (no cross-tenant leak)."""
    from .. import config
    from ..services import numbers as numbers_svc
    allow_fallback = config.APP_ENV in ("dev", "test", "demo")
    org_id = None
    if dialed_number:
        found = await numbers_svc.voice_config_for_number(dialed_number)
        if found:
            org_id = found.get("org_id")
    if not org_id and allow_fallback:
        org_id = org_id_hint
    agent = None
    if org_id:
        agent = await db.agents.find_one({"org_id": org_id, "agent_type": "receptionist"})
    if not agent and allow_fallback:
        agent = await db.agents.find_one({"agent_type": "receptionist"})
        org_id = agent.get("org_id") if agent else org_id
    return org_id, agent


async def _get_or_start_conversation(db, org_id: str, agent: Dict[str, Any],
                                       provider_call_id: str, caller: Optional[str]):
    """One chat_conversation + call_record per provider call id (idempotent)."""
    call = await db.call_records.find_one({"org_id": org_id,
                                            "provider_call_id": provider_call_id})
    if call:
        conv = await db.chat_conversations.find_one({"_id": ObjectId(call["conversation_id"])})
        return conv, call
    from ..models_ai import ChatConversation, CallRecord
    conv = ChatConversation(
        org_id=org_id, channel="call", session_token=secrets.token_urlsafe(20),
        agent_id=str(agent["_id"]), agent_version_id=agent.get("live_version_id"),
        status="ai", started_at=utc_now_iso(), last_message_at=utc_now_iso(),
        visitor_meta={"phone": caller, "provider_call_id": provider_call_id},
    )
    r = await db.chat_conversations.insert_one(conv.to_mongo())
    cid = str(r.inserted_id)
    call_doc = CallRecord(org_id=org_id, conversation_id=cid, direction="inbound",
                           duration_seconds=0, transcript="", ai_summary="",
                           extracted_fields={}, outcome="no_action",
                           simulated=False, cost_cents=0.0).to_mongo()
    call_doc["provider_call_id"] = provider_call_id
    cr = await db.call_records.insert_one(call_doc)
    call_doc["_id"] = cr.inserted_id
    return await db.chat_conversations.find_one({"_id": ObjectId(cid)}), call_doc


def _twiml(inner: str) -> Response:
    xml = f'<?xml version="1.0" encoding="UTF-8"?>\n<Response>{inner}</Response>'
    return Response(content=xml, media_type="application/xml")




async def _verify_voice_webhook(request: Request, provider: str, form: Optional[Dict[str, Any]] = None) -> bool:
    """Public voice webhooks trigger paid LLM turns, so they must be authenticated.
    - twilio: X-Twilio-Signature (HMAC-SHA1 over full URL + sorted POST params) with the auth token.
    - retell/telnyx: shared `voice.webhook_secret` via ?secret= or X-Webhook-Secret header.
    - No carrier configured: allowed only in dev/test/demo (simulated posture); refused in production.
    """
    import base64
    import hashlib
    import hmac
    from .. import config
    from ..services import integrations as integ
    from ..services import rate_limit as rl
    rl.check(f"voice_webhook_{provider}", request, limit=240, window_seconds=60)
    cfg = (await integ._raw()).get("voice", {}) or {}
    shared = cfg.get("webhook_secret") or ""
    got = request.query_params.get("secret") or request.headers.get("x-webhook-secret") or ""
    if shared and hmac.compare_digest(str(got), str(shared)):
        return True
    if provider == "twilio" and cfg.get("twilio_auth_token"):
        sig = request.headers.get("X-Twilio-Signature", "")
        url = str(request.url)
        payload = url + "".join(f"{k}{v}" for k, v in sorted((form or {}).items()))
        expected = base64.b64encode(hmac.new(cfg["twilio_auth_token"].encode(), payload.encode(),
                                             hashlib.sha1).digest()).decode()
        if sig and hmac.compare_digest(sig, expected):
            return True
    if (cfg.get("provider") or "none") == "none" and not shared:
        return config.APP_ENV in ("dev", "test", "demo")
    return False


async def _meter_public_voice(org_id: Optional[str]) -> bool:
    """Meter the turn against the tenant (public flag) and honour budgets/kill switches."""
    from fastapi import HTTPException
    from ..services.usage import set_context, enforce_budget
    set_context(org_id=org_id, feature="public_voice", public=True)
    try:
        await enforce_budget(org_id, feature="public_voice", public=True)
        return True
    except HTTPException:
        return False


@router.post("/twilio/inbound")
async def twilio_inbound(request: Request):
    """Twilio Voice webhook. Speech <Gather> loop bridged to the receptionist agent.

    On first hit (no SpeechResult) we greet + gather. On subsequent hits we feed
    the caller's transcribed speech to run_turn and <Say> the agent reply, then
    gather again. Returns valid TwiML XML the whole time.
    """
    form = dict(await request.form())
    if not await _verify_voice_webhook(request, "twilio", form):
        return _twiml('<Say>This line is not configured.</Say><Hangup/>')
    db = get_db()
    call_sid = form.get("CallSid") or f"twl_{secrets.token_hex(6)}"
    caller = form.get("From")
    called = form.get("To")
    speech = (form.get("SpeechResult") or "").strip()
    # Tenant is resolved from the verified DIALED number — never from arbitrary query data.
    org_id, agent = await _resolve_org_and_agent(
        db, dialed_number=called, org_id_hint=request.query_params.get("org_id"))
    action = "/api/voice/twilio/inbound"

    if agent and not await _meter_public_voice(org_id):
        return _twiml('<Say>Our assistant is unavailable right now. Please leave a message after the tone '
                      'or call back later.</Say><Hangup/>')
    if not agent:
        return _twiml('<Say>Sorry, no receptionist is configured for this number yet.'
                       '</Say><Hangup/>')

    # Per-number voice config (greeting, language, persona) — managed numbers.
    from ..services import numbers as numbers_svc
    vc = None
    if called:
        found = await numbers_svc.voice_config_for_number(called)
        if found:
            vc = found["voice_config"]
    if not vc:
        vc = await numbers_svc.voice_config_for_org(org_id) or numbers_svc.default_voice_config()
    lang = vc.get("language", "en-US")
    lang_name = numbers_svc.LANG_NAME.get(lang, "English")

    conv, call = await _get_or_start_conversation(db, org_id, agent, call_sid, caller)

    if not speech:
        greeting = vc.get("greeting") or "Thanks for calling. How can I help you today?"
        gather = (f'<Gather input="speech" action="{action}" method="POST" '
                   f'speechTimeout="auto" language="{lang}">'
                   f'<Say language="{lang}">{_xml_escape(greeting)}</Say></Gather>'
                   f'<Say language="{lang}">{_xml_escape(vc.get("messages", {}).get("voicemail", "Please call again."))}</Say>')
        return _twiml(gather)

    try:
        # Steer the LLM to answer in the caller's chosen language + persona style.
        directive = f"(Reply in {lang_name}. Style: {vc.get('speaking_style','warm and concise')}.) "
        result = await run_turn(
            org_id=org_id, agent_id=conv["agent_id"],
            conversation_id=str(conv["_id"]), user_text=directive + speech,
            website_slug=None, is_sandbox=False,
            agent_version_id=conv.get("agent_version_id"),
            call_record_id=str(call["_id"]),
        )
        reply = (result or {}).get("reply") or "Let me help you with that."
    except Exception as e:  # noqa: BLE001
        logger.warning("twilio run_turn failed: %s", e)
        reply = "Sorry, I'm having trouble right now. Please try again shortly."

    gather = (f'<Say language="{lang}">{_xml_escape(reply)}</Say>'
               f'<Gather input="speech" action="{action}" method="POST" '
               f'speechTimeout="auto" language="{lang}">'
               f'<Say language="{lang}">Anything else?</Say></Gather>'
               f'<Say language="{lang}">Thanks for calling. Goodbye.</Say>')
    return _twiml(gather)


@router.post("/retell/webhook")
async def retell_webhook(request: Request):
    """Retell webhook. Handles Retell's event envelope and returns a response.

    Retell posts JSON like {"event": "response_required"|"call_started"|"call_ended"|
    "reminder_required", "call": {...}, "transcript": [...] , "response_id": N}.
    On response_required / reminder_required we feed the latest user utterance to
    run_turn and return {"response": "...", "response_id": N} (Retell's expected shape).
    """
    if not await _verify_voice_webhook(request, "retell"):
        return {"response": "This line is not configured.", "response_id": 0, "end_call": True}
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}
    event = body.get("event") or body.get("interaction_type")
    call = body.get("call") or {}
    provider_call_id = call.get("call_id") or body.get("call_id") or f"rtl_{secrets.token_hex(6)}"
    db = get_db()
    # Tenant resolved from the verified dialed number in the call envelope (never query data).
    dialed = call.get("to_number") or call.get("to") or body.get("to_number")
    org_id, agent = await _resolve_org_and_agent(
        db, dialed_number=dialed, org_id_hint=request.query_params.get("org_id"))

    if event in ("call_started", "call_ended", "call_analyzed"):
        return {"ok": True, "event": event}

    if org_id and not await _meter_public_voice(org_id):
        return {"response": "Our assistant is unavailable right now. Please call back later.",
                "response_id": body.get("response_id", 0), "end_call": True}

    if event in ("call_started", "call_ended", "call_analyzed"):
        return {"ok": True, "event": event}

    if not agent:
        return {"response": "No receptionist is configured yet.",
                "response_id": body.get("response_id", 0)}

    # Extract the latest user utterance from Retell's transcript array
    user_text = ""
    for turn in reversed(body.get("transcript") or []):
        if turn.get("role") in ("user", "human"):
            user_text = (turn.get("content") or "").strip()
            break
    if not user_text:
        user_text = (body.get("transcript_text") or "").strip()

    conv, call_rec = await _get_or_start_conversation(db, org_id, agent, provider_call_id,
                                                       call.get("from_number"))
    reply = "How can I help you?"
    if user_text:
        try:
            result = await run_turn(
                org_id=org_id, agent_id=conv["agent_id"],
                conversation_id=str(conv["_id"]), user_text=user_text,
                website_slug=None, is_sandbox=False,
                agent_version_id=conv.get("agent_version_id"),
                call_record_id=str(call_rec["_id"]),
            )
            reply = (result or {}).get("reply") or reply
        except Exception as e:  # noqa: BLE001
            logger.warning("retell run_turn failed: %s", e)
            reply = "Sorry, I'm having trouble right now."
    return {"response": reply, "response_id": body.get("response_id", 0)}
