"""Stripe Connect (Express connected accounts) — platform credentials ONLY.

Design (Round 15):
  * The PLATFORM Stripe secret key + Connect webhook secret live in the encrypted Staff Setup Center
    (`integrations.payments.stripe_secret_key` / `stripe_webhook_secret`). Tenants NEVER paste secret keys.
  * Tenants connect through a Stripe-hosted onboarding flow (Account Links). We store only the
    connected `stripe_account_id` + the capability flags Stripe reports (charges_enabled, ...).
  * Charges for a tenant's storefront are DIRECT charges on the connected account (Stripe-Account header).
  * `probe_platform()` performs REAL API calls (GET /v1/account, GET /v1/accounts?limit=1) and reports
    Live / Sandbox / Not connected / Error + whether Connect is enabled. Key-pattern matching is NOT used.

If the platform key is absent or Connect is not enabled on the platform account, every tenant-facing
call honestly returns `available=False` with the reason — nothing is simulated.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import httpx
from fastapi import HTTPException

from ..db import get_db, utc_now_iso
from . import integrations as platform_integ

logger = logging.getLogger("zanelvo.stripe_connect")
API = "https://api.stripe.com/v1"
_PLACEHOLDER = {"", None, "sk_test_emergent"}


async def platform_key() -> str:
    key = await platform_integ.get_secret("payments", "stripe_secret_key")
    return key if key not in _PLACEHOLDER else ""


async def platform_webhook_secret() -> str:
    return await platform_integ.get_secret("payments", "stripe_webhook_secret") or ""


async def _probe_connect(c: httpx.AsyncClient, key: str):
    r = await c.post("/accounts", data={"type": "express", "metadata[zanelvo_probe]": "1"}, auth=(key, ""),
                     headers={"Idempotency-Key": f"zanelvo-connect-probe-{utc_now_iso()[:13]}"})
    err = (r.json().get("error", {}) or {}) if r.headers.get("content-type", "").startswith("application/json") else {}
    if r.status_code < 400:
        acct_id = r.json().get("id")
        if acct_id:
            try:
                await c.delete(f"/accounts/{acct_id}", auth=(key, ""))
            except Exception:  # noqa: BLE001
                pass
        return True, ""
    msg = err.get("message") or f"HTTP {r.status_code}"
    return False, msg


async def cached_connect_state() -> Optional[Dict[str, Any]]:
    doc = await get_db().integrations.find_one({"key": platform_integ.INTEGRATIONS_KEY}, {"payments.connect_probe": 1}) or {}
    return ((doc.get("payments") or {}).get("connect_probe")) or None


async def _store_connect_state(enabled: bool, message: str) -> None:
    await get_db().integrations.update_one(
        {"key": platform_integ.INTEGRATIONS_KEY},
        {"$set": {"payments.connect_probe": {"connect_enabled": bool(enabled), "message": message[:300],
                                              "checked_at": utc_now_iso()}}}, upsert=True)


async def probe_platform() -> Dict[str, Any]:
    """Real probe of the PLATFORM key. Never returns or logs the key."""
    key = await platform_key()
    if not key:
        return {"state": "not_connected", "connect_enabled": False,
                "message": "No platform Stripe secret key in Staff Setup Center."}
    try:
        async with httpx.AsyncClient(base_url=API, timeout=20) as c:
            r = await c.get("/account", auth=(key, ""))
            if r.status_code == 401:
                return {"state": "error", "connect_enabled": False, "message": "Stripe rejected the platform key (401)."}
            if r.status_code >= 400:
                return {"state": "error", "connect_enabled": False, "message": f"Stripe API error {r.status_code}."}
            acct = r.json()
            livemode = bool(acct.get("charges_enabled")) and not key.startswith("sk_test") and bool(acct.get("livemode", True))
            # Connect enabled? Stripe has no read-only signal for this, so the probe creates a bare Express
            # account (no KYC data) and deletes it immediately. Result is cached in the Setup Center doc.
            connect_enabled, connect_msg = await _probe_connect(c, key)
        state = "live" if (acct.get("livemode") is True or (livemode and not key.startswith("sk_test"))) else "sandbox"
        out = {"state": state, "connect_enabled": connect_enabled, "account_id": acct.get("id"),
               "country": acct.get("country"), "default_currency": acct.get("default_currency"),
               "message": ("Platform Stripe account reachable"
                           + ("; Connect enabled." if connect_enabled else
                              "; Connect NOT enabled — owner must sign up for Connect in the Stripe Dashboard before tenants can onboard."))}
        if connect_msg:
            out["connect_error"] = connect_msg[:200]
        await _store_connect_state(connect_enabled, connect_msg or out["message"])
        return out
    except Exception as e:  # noqa: BLE001
        return {"state": "error", "connect_enabled": False, "message": f"Probe failed: {type(e).__name__}"}


async def _tenant_pay(org_id: str) -> Dict[str, Any]:
    from . import tenant_integrations
    raw = await tenant_integrations._raw(org_id)  # noqa: SLF001
    return raw.get("payments", {}) or {}


async def _save_tenant_pay(org_id: str, patch: Dict[str, Any]) -> None:
    sets = {f"payments.{k}": v for k, v in patch.items()}
    sets["updated_at"] = utc_now_iso()
    await get_db().tenant_integrations.update_one({"org_id": org_id}, {"$set": sets}, upsert=True)


async def availability() -> Dict[str, Any]:
    key = await platform_key()
    if not key:
        return {"available": False, "platform_state": "not_connected", "connect_enabled": False,
                "reason": "No platform Stripe secret key in Staff Setup Center."}
    cached = await cached_connect_state()
    if cached:
        p = {"state": "sandbox" if key.startswith("sk_test") else "live", "connect_enabled": cached.get("connect_enabled"),
             "message": cached.get("message")}
    else:
        p = await probe_platform()
    ok = p.get("state") in ("live", "sandbox") and p.get("connect_enabled")
    return {"available": bool(ok), "platform_state": p.get("state"), "connect_enabled": bool(p.get("connect_enabled")),
            "reason": None if ok else p.get("message")}


async def start_onboarding(org_id: str, origin: str, email: Optional[str] = None,
                           country: str = "US") -> Dict[str, Any]:
    """Create (once) the tenant's Express account and return a fresh Account Link URL."""
    avail = await availability()
    if not avail["available"]:
        raise HTTPException(503, {"error": "stripe_connect_unavailable",
                                  "message": "Online payments are not available yet on this platform: "
                                             + (avail.get("reason") or "Stripe Connect is not enabled."),
                                  "state": avail.get("platform_state")})
    key = await platform_key()
    pay = await _tenant_pay(org_id)
    acct_id = pay.get("stripe_account_id")
    async with httpx.AsyncClient(base_url=API, timeout=30) as c:
        if not acct_id:
            data = {"type": "express", "country": (country or "US").upper(),
                    "capabilities[card_payments][requested]": "true", "capabilities[transfers][requested]": "true",
                    "metadata[zanelvo_org_id]": org_id}
            if email:
                data["email"] = email
            r = await c.post("/accounts", data=data, auth=(key, ""),
                             headers={"Idempotency-Key": f"zanelvo-connect-acct-{org_id}"})
            if r.status_code >= 400:
                msg = (r.json().get("error", {}) or {}).get("message", r.text[:200]) if r.headers.get("content-type", "").startswith("application/json") else r.text[:200]
                if "signed up for connect" in (msg or "").lower():
                    await _store_connect_state(False, msg)
                    raise HTTPException(503, {"error": "stripe_connect_unavailable",
                                              "message": "Online payments are not available yet: the platform's Stripe "
                                                         "account has not enabled Connect."})
                raise HTTPException(502, {"error": "stripe_error", "message": msg})
            acct = r.json()
            acct_id = acct["id"]
            await _save_tenant_pay(org_id, {"stripe_account_id": acct_id, "provider": "stripe_connect",
                                            "charges_enabled": False, "details_submitted": False,
                                            "payouts_enabled": False, "connect_started_at": utc_now_iso()})
        origin = (origin or "").rstrip("/")
        r = await c.post("/account_links", data={
            "account": acct_id, "type": "account_onboarding",
            "refresh_url": f"{origin}/app/settings/payments?connect=refresh",
            "return_url": f"{origin}/app/settings/payments?connect=return",
        }, auth=(key, ""))
        if r.status_code >= 400:
            raise HTTPException(502, {"error": "stripe_error", "message": "Could not create onboarding link."})
        return {"ok": True, "account_id": acct_id, "url": r.json().get("url"),
                "expires_at": r.json().get("expires_at")}


async def refresh_status(org_id: str) -> Dict[str, Any]:
    """Pull the connected account's real capability flags from Stripe and persist them."""
    pay = await _tenant_pay(org_id)
    acct_id = pay.get("stripe_account_id")
    avail = await availability()
    base = {"available": avail["available"], "platform_state": avail["platform_state"],
            "reason": avail.get("reason"), "account_id": acct_id,
            "charges_enabled": bool(pay.get("charges_enabled")), "details_submitted": bool(pay.get("details_submitted")),
            "payouts_enabled": bool(pay.get("payouts_enabled")), "store_mode": pay.get("store_mode", "test")}
    if not acct_id or not avail["available"]:
        base["status"] = "not_connected"
        return base
    key = await platform_key()
    async with httpx.AsyncClient(base_url=API, timeout=20) as c:
        r = await c.get(f"/accounts/{acct_id}", auth=(key, ""))
    if r.status_code >= 400:
        base["status"] = "error"
        return base
    a = r.json()
    flags = {"charges_enabled": bool(a.get("charges_enabled")), "details_submitted": bool(a.get("details_submitted")),
             "payouts_enabled": bool(a.get("payouts_enabled")), "connect_checked_at": utc_now_iso()}
    await _save_tenant_pay(org_id, flags)
    base.update(flags)
    base["status"] = "connected" if flags["charges_enabled"] else ("pending" if flags["details_submitted"] else "onboarding")
    return base


async def tenant_charge_context(org_id: str) -> Optional[Dict[str, str]]:
    """Return {api_key, stripe_account, webhook_secret} when this tenant can take REAL payments, else None.
    Requires: platform key present, tenant connected account with charges_enabled, store_mode == live."""
    pay = await _tenant_pay(org_id)
    if pay.get("store_mode") != "live" or not pay.get("stripe_account_id") or not pay.get("charges_enabled"):
        return None
    key = await platform_key()
    if not key:
        return None
    return {"api_key": key, "stripe_account": pay["stripe_account_id"],
            "webhook_secret": await platform_webhook_secret()}


async def org_for_connected_account(stripe_account_id: str) -> Optional[str]:
    doc = await get_db().tenant_integrations.find_one({"payments.stripe_account_id": stripe_account_id}, {"org_id": 1})
    return doc.get("org_id") if doc else None
