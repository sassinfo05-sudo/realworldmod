import { useEffect, useState } from "react";
import api from "@/lib/api";

function Stat({ label, value, sub }) {
    return (
        <div className="rounded-lg border border-brand-line bg-white p-4">
            <div className="text-xs uppercase tracking-widest text-zinc-500">{label}</div>
            <div className="mt-1 font-display text-2xl text-brand-ink">{value}</div>
            {sub && <div className="text-[11px] text-zinc-400 mt-1">{sub}</div>}
        </div>
    );
}

export default function Metrics() {
    const [data, setData] = useState(null);
    useEffect(() => {
        api.get("/founder/metrics").then((r) => setData(r.data));
    }, []);
    if (!data) return <div className="p-6 text-zinc-500">Loading metrics…</div>;
    return (
        <div className="p-6 max-w-6xl" data-testid="founder-metrics-page">
            <div className="mb-4">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">Platform metrics</div>
                <h1 className="mt-1 font-display text-2xl text-brand-ink">Revenue, activation, health</h1>
            </div>
            <div className="grid md:grid-cols-4 gap-3 mb-6">
                <Stat label="MRR" value={`$${data.mrr_usd}`} sub={`${Object.values(data.per_plan).reduce((a, b) => a + b, 0)} paying orgs`} />
                <Stat label="ARR (est)" value={`$${data.arr_usd}`} />
                <Stat label="Total orgs" value={data.orgs_total} />
                <Stat label="Churned (30d)" value={data.churned_last_30d} />
            </div>

            <div className="mb-6">
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Plan distribution</div>
                <div className="grid md:grid-cols-5 gap-2">
                    {Object.entries(data.per_plan).map(([plan, count]) => (
                        <div key={plan} className="rounded-lg border border-brand-line bg-white p-3 text-center" data-testid={`metrics-plan-${plan}`}>
                            <div className="text-[10px] uppercase tracking-widest text-zinc-500">{plan}</div>
                            <div className="mt-1 font-display text-xl text-brand-ink">{count}</div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="mb-6">
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Activation funnel</div>
                <div className="grid md:grid-cols-5 gap-2" data-testid="metrics-funnel">
                    {[
                        { k: "signups", label: "Signups" },
                        { k: "interview_done", label: "Interview done" },
                        { k: "website_created", label: "Website created" },
                        { k: "published", label: "Published" },
                        { k: "active_last_7d", label: "Active 7d" },
                    ].map((step) => (
                        <div key={step.k} className="rounded-lg border border-brand-line bg-white p-3 text-center">
                            <div className="text-[10px] uppercase tracking-widest text-zinc-500">{step.label}</div>
                            <div className="mt-1 font-display text-xl text-brand-ink">{data.funnel[step.k]}</div>
                        </div>
                    ))}
                </div>
            </div>

            <div>
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Per-org gross margin (this month)</div>
                <div className="border border-brand-line rounded-lg bg-white overflow-hidden divide-y max-h-[420px] overflow-y-auto">
                    {data.per_org
                        .sort((a, b) => (b.mrr_usd - a.mrr_usd) || (b.gross_margin_usd - a.gross_margin_usd))
                        .slice(0, 30)
                        .map((o) => (
                        <div key={o.org_id} className="p-2.5 flex items-center gap-2 text-sm" data-testid={`metrics-org-${o.org_id}`}>
                            <div className="flex-1 text-brand-ink">{o.name}</div>
                            <div className="text-xs text-zinc-500 font-mono uppercase w-16">{o.plan}</div>
                            <div className="font-mono text-xs w-20 text-right">${o.mrr_usd}</div>
                            <div className="font-mono text-xs w-20 text-right text-zinc-500">-${o.ai_cost_usd}</div>
                            <div className={`font-mono text-xs w-20 text-right ${o.gross_margin_usd >= 0 ? "text-emerald-700" : "text-red-700"}`}>=${o.gross_margin_usd}</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
