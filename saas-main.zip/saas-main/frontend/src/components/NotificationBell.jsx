import { useEffect, useRef, useState } from "react";
import { Bell, CheckCheck, Trash2, AlertCircle, CheckCircle2, Info, AlertTriangle } from "lucide-react";
import { subscribe, markAllRead, clearAll } from "@/lib/notifications";

const ICON = { success: CheckCircle2, error: AlertCircle, warning: AlertTriangle, info: Info, message: Info };
const COLOR = { success: "text-emerald-600", error: "text-red-600", warning: "text-amber-600", info: "text-brand-copper", message: "text-zinc-500" };

export default function NotificationBell({ announcement }) {
    const [items, setItems] = useState([]);
    const [open, setOpen] = useState(false);
    const ref = useRef(null);
    useEffect(() => subscribe(setItems), []);
    useEffect(() => {
        if (!open) return;
        const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
        document.addEventListener("mousedown", h);
        return () => document.removeEventListener("mousedown", h);
    }, [open]);
    const unread = items.filter((n) => !n.read).length;
    return (
        <div className="relative" ref={ref}>
            <button type="button" onClick={() => { setOpen((o) => !o); if (!open) markAllRead(); }} data-testid="notification-bell"
                className="relative h-9 w-9 grid place-items-center rounded-lg text-zinc-600 hover:bg-zinc-100 dark:hover:bg-white/10" aria-label="Notifications">
                <Bell className="w-4 h-4" />
                {unread > 0 && <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-brand-accent text-white text-[10px] font-semibold grid place-items-center" data-testid="notification-unread">{unread > 9 ? "9+" : unread}</span>}
            </button>
            {open && (
                <div className="absolute right-0 mt-2 w-80 max-h-[70vh] overflow-auto rounded-xl border border-brand-line bg-white dark:bg-zinc-900 shadow-2xl z-50" data-testid="notification-panel">
                    <div className="px-4 py-3 border-b border-brand-line flex items-center justify-between">
                        <div className="text-sm font-medium">Activity</div>
                        <div className="flex gap-1">
                            <button className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500" title="Mark all read" onClick={markAllRead}><CheckCheck className="w-4 h-4" /></button>
                            <button className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500" title="Clear" onClick={clearAll} data-testid="notification-clear"><Trash2 className="w-4 h-4" /></button>
                        </div>
                    </div>
                    {announcement && (
                        <div className="px-4 py-3 border-b border-brand-line bg-brand-copper/5 text-sm"><div className="font-medium">{announcement.title}</div>{announcement.body && <div className="text-zinc-600 text-xs mt-0.5">{announcement.body}</div>}</div>
                    )}
                    {items.length === 0 ? (
                        <div className="px-4 py-10 text-center text-sm text-zinc-500">You're all caught up.</div>
                    ) : items.map((n) => {
                        const Icon = ICON[n.level] || Info;
                        return (
                            <div key={n.id} className="px-4 py-3 border-b border-brand-line/60 flex gap-3 text-sm">
                                <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${COLOR[n.level] || ""}`} />
                                <div className="min-w-0">
                                    <div className="text-brand-ink dark:text-zinc-100 leading-snug">{n.message}</div>
                                    {n.description && <div className="text-xs text-zinc-500 mt-0.5">{n.description}</div>}
                                    <div className="text-[10px] text-zinc-400 mt-1">{new Date(n.at).toLocaleString()}</div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
