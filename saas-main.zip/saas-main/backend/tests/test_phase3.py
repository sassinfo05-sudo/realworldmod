"""Phase 3 acceptance tests — CRM + Inbox + Email + Import + Suppressions + Cross-org.

Covers all 6 numbered acceptance criteria from the review request plus carryover P0.
"""
from __future__ import annotations

import io
import os
import re
import time
import uuid
from datetime import datetime, timedelta, timezone

import pytest
import requests
from tests import _creds as _CREDS  # creds from env / test_credentials.md

BASE_URL = _CREDS.BASE_URL
DEMO_EMAIL = _CREDS.OWNER_EMAIL
DEMO_PASSWORD = _CREDS.OWNER_PASSWORD

ALLOWED_PRICE_TOKENS = {"$180", "$220", "$1,200", "$1200"}


# ---------------- Fixtures ----------------

@pytest.fixture(scope="session")
def owner_token() -> str:
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD}, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="session")
def orgb_token() -> str:
    email = f"orgb-{uuid.uuid4().hex[:8]}@example.com"
    r = requests.post(f"{BASE_URL}/api/auth/signup",
                      json={"email": email, "password": "TestPass!23",
                            "business_name": f"OrgB {uuid.uuid4().hex[:6]}"},
                      timeout=20)
    assert r.status_code in (200, 201), r.text
    tok = r.json().get("access_token")
    if not tok:
        r2 = requests.post(f"{BASE_URL}/api/auth/login",
                           json={"email": email, "password": "TestPass!23"}, timeout=20)
        tok = r2.json()["access_token"]
    return tok


def _h(token: str):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


# ---------------- Carryover P0 ----------------

class TestCarryover:
    def test_demo_hero_image_reachable(self):
        r = requests.get(f"{BASE_URL}/api/public/sites/demo-home-services", timeout=15)
        assert r.status_code == 200
        data = r.json()
        # locate hero image url anywhere in payload
        blob = str(data)
        # capture unsplash / cdn image urls (may include query params)
        urls = re.findall(r'https?://[^\s"\'\\]+', blob)
        urls = [u for u in urls if ("unsplash.com" in u or re.search(r"\.(jpe?g|png|webp|gif)(\?|$)", u, re.I))]
        assert urls, "No image URL found in public payload"
        # HEAD-check first image
        head = requests.head(urls[0], timeout=15, allow_redirects=True)
        assert head.status_code == 200, f"Hero image not reachable: {urls[0]} -> {head.status_code}"

    def test_block_patch_rejects_unknown_and_accepts_hidden(self, owner_token):
        # fetch editor draft blocks
        r = requests.get(f"{BASE_URL}/api/editor/website", headers=_h(owner_token), timeout=15)
        assert r.status_code == 200
        pages = ((r.json() or {}).get("website") or {}).get("pages") or []
        block_id = None
        for p in pages:
            for b in p.get("blocks") or []:
                block_id = b.get("id")
                if block_id:
                    break
            if block_id:
                break
        assert block_id, "No block found in editor draft"
        # Nonsense should 422
        r422 = requests.patch(f"{BASE_URL}/api/editor/website/blocks/{block_id}",
                              headers=_h(owner_token), json={"nonsense": "foo"}, timeout=15)
        assert r422.status_code == 422, f"expected 422, got {r422.status_code}: {r422.text}"
        # hidden=true accepted
        r_ok = requests.patch(f"{BASE_URL}/api/editor/website/blocks/{block_id}",
                              headers=_h(owner_token), json={"hidden": True}, timeout=15)
        assert r_ok.status_code == 200, r_ok.text
        # restore
        requests.patch(f"{BASE_URL}/api/editor/website/blocks/{block_id}",
                       headers=_h(owner_token), json={"hidden": False}, timeout=15)


# ---------------- Acceptance 1: form wiring ----------------

class TestFormWiring:
    def test_form_submit_creates_contact_conversation_timeline_owner_alert(self, owner_token):
        unique = uuid.uuid4().hex[:8]
        email = f"test-lead-{unique}@example.com"
        # Unique phone per run: the CRM (correctly) de-duplicates contacts by phone, so a
        # constant number would merge this submission into a previous run's contact (keeping
        # that run's name) and the search-by-name below would miss it on a non-fresh DB.
        phone = "+1512" + str(int(unique, 16))[:7].rjust(7, "0")
        payload = {
            "website_slug": "demo-home-services",
            "page_slug": "contact",
            "fields": {"name": f"Test Lead {unique}", "email": email,
                       "phone": phone,
                       "message": "My hot water heater has been leaking for a day. Can you send a quote?"}
        }
        r = requests.post(f"{BASE_URL}/api/forms/submit", json=payload, timeout=25)
        assert r.status_code in (200, 201), r.text

        time.sleep(1.5)

        # (i) contact exists via search
        r1 = requests.get(f"{BASE_URL}/api/crm/contacts",
                          headers=_h(owner_token), params={"q": f"Test Lead {unique}"}, timeout=15)
        assert r1.status_code == 200
        contacts = r1.json().get("contacts") or []
        assert any(email in (c.get("emails") or []) for c in contacts), f"Contact not found: {contacts}"
        contact = next(c for c in contacts if email in (c.get("emails") or []))
        assert contact.get("source") == "form"
        consents = contact.get("consents") or []
        assert any(cn.get("channel") == "email" and cn.get("status") == "granted" for cn in consents)

        cid = contact["id"]

        # (ii) conversation exists in form channel with preview
        r2 = requests.get(f"{BASE_URL}/api/inbox/conversations",
                          headers=_h(owner_token), params={"channel": "form", "limit": 100}, timeout=15)
        assert r2.status_code == 200
        convs = r2.json().get("conversations") or []
        conv = next((c for c in convs if "water heater" in (c.get("last_message_preview") or "").lower()
                     or "water heater" in (c.get("subject") or "").lower()
                     or c.get("contact_id") == cid), None)
        assert conv is not None, f"No form conversation found for lead. Got {len(convs)} convs."

        # (iii) timeline has form_submitted
        r3 = requests.get(f"{BASE_URL}/api/crm/contacts/{cid}/timeline",
                          headers=_h(owner_token), timeout=15)
        assert r3.status_code == 200
        types = [i.get("type") for i in r3.json().get("interactions") or []]
        assert "form_submitted" in types, f"types={types}"

        # (iv) conversation has an owner alert simulated message
        r4 = requests.get(f"{BASE_URL}/api/inbox/conversations/{conv['id']}",
                          headers=_h(owner_token), timeout=15)
        assert r4.status_code == 200
        msgs = r4.json().get("messages") or []
        has_sim = any((m.get("delivery") or {}).get("provider") == "simulated"
                      and (m.get("delivery") or {}).get("simulated") is True
                      for m in msgs)
        assert has_sim, f"Owner alert simulated message not found. deliveries={[m.get('delivery') for m in msgs]}"


# ---------------- Acceptance 2: AI grounding ----------------

class TestAIGrounding:
    def test_draft_reply_grounded_no_invented_prices(self, owner_token):
        # find a form conversation
        r = requests.get(f"{BASE_URL}/api/inbox/conversations",
                         headers=_h(owner_token), params={"channel": "form", "limit": 20}, timeout=15)
        assert r.status_code == 200
        convs = r.json().get("conversations") or []
        assert convs, "no form conversations"
        # prefer one about water heater / miguel
        conv = next((c for c in convs if "water heater" in (c.get("last_message_preview") or "").lower()
                     or "miguel" in (c.get("subject") or "").lower()), convs[0])
        conv_id = conv["id"]

        # summarize
        s = requests.post(f"{BASE_URL}/api/inbox/conversations/{conv_id}/ai/summarize",
                          headers=_h(owner_token), timeout=60)
        assert s.status_code == 200, s.text
        sj = s.json()
        assert "summary" in sj

        # draft-reply
        d = requests.post(f"{BASE_URL}/api/inbox/conversations/{conv_id}/ai/draft-reply",
                          headers=_h(owner_token), json={}, timeout=90)
        assert d.status_code == 200, d.text
        dj = d.json()
        for k in ("body_text", "facts_used", "facts_missing", "warning"):
            assert k in dj, f"missing key {k} in {list(dj.keys())}"
        assert dj["warning"].strip() == "AI draft — review before sending.", f"warning={dj['warning']!r}"

        # facts_used has at least one BusinessProfile service reference
        # fetch business profile to get service names
        bp = requests.get(f"{BASE_URL}/api/business-profile", headers=_h(owner_token), timeout=15).json()
        service_names = [s.get("name", "").lower() for s in (bp.get("services") or [])]
        assert service_names, "no services in business profile"
        facts_used_blob = " ".join(str(x) for x in dj.get("facts_used") or []).lower()
        assert any(name and name in facts_used_blob for name in service_names), \
            f"facts_used ({dj.get('facts_used')}) does not reference any service {service_names}"

        # any $-price in body_text must be in allowed set from profile
        prices_in_body = re.findall(r"\$\d[\d,]*", dj["body_text"])
        allowed = set()
        for s in bp.get("services") or []:
            pd = (s.get("price_display") or "")
            for p in re.findall(r"\$\d[\d,]*", pd):
                allowed.add(p)
        # also allow normalized variants
        norm = lambda x: x.replace(",", "")
        allowed_norm = {norm(x) for x in allowed}
        for p in prices_in_body:
            assert norm(p) in allowed_norm, f"Draft mentions invented price {p!r}; allowed={allowed}"


# ---------------- Acceptance 3: scheduled send + snooze ----------------

class TestScheduledSendAndSnooze:
    def test_scheduled_send_releases_and_cancel(self, owner_token):
        # simulate inbound
        sim = requests.post(f"{BASE_URL}/api/inbox/simulate-inbound",
                            headers=_h(owner_token),
                            json={"from_email": "sched-test@example.com",
                                  "from_name": "Sched Test",
                                  "subject": "Scheduling test",
                                  "body_text": "Please reply."}, timeout=15)
        assert sim.status_code == 200, sim.text
        conv_id = sim.json()["conversation_id"]

        # schedule 8s in future
        release_at = (datetime.now(timezone.utc) + timedelta(seconds=8)).isoformat()
        s = requests.post(f"{BASE_URL}/api/inbox/send", headers=_h(owner_token),
                          json={"conversation_id": conv_id,
                                "to": ["sched-test@example.com"],
                                "subject": "Reply", "body_text": "Thanks",
                                "schedule_at": release_at}, timeout=15)
        assert s.status_code == 200, s.text
        sched_id = s.json().get("scheduled_send_id")
        assert sched_id

        # wait for poller (5s tick); generous margin so full-suite load can't starve it
        time.sleep(22)

        # verify message with delivery.scheduled_send_id + delivered
        r = requests.get(f"{BASE_URL}/api/inbox/conversations/{conv_id}",
                         headers=_h(owner_token), timeout=15)
        assert r.status_code == 200
        msgs = r.json().get("messages") or []
        released = [m for m in msgs
                    if (m.get("delivery") or {}).get("scheduled_send_id") == sched_id]
        assert released, f"scheduled message not released. deliveries={[m.get('delivery') for m in msgs]}"
        assert released[0]["delivery"].get("status") == "delivered"

        # scheduled list should not contain it
        rlist = requests.get(f"{BASE_URL}/api/inbox/scheduled", headers=_h(owner_token), timeout=15)
        assert rlist.status_code == 200
        assert not any(x.get("id") == sched_id for x in rlist.json().get("scheduled") or [])

    def test_scheduled_cancel(self, owner_token):
        sim = requests.post(f"{BASE_URL}/api/inbox/simulate-inbound",
                            headers=_h(owner_token),
                            json={"from_email": "cancel-test@example.com",
                                  "subject": "Cancel test", "body_text": "hi"}, timeout=15)
        conv_id = sim.json()["conversation_id"]
        release_at = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
        s = requests.post(f"{BASE_URL}/api/inbox/send", headers=_h(owner_token),
                          json={"conversation_id": conv_id,
                                "to": ["cancel-test@example.com"],
                                "subject": "Later", "body_text": "later",
                                "schedule_at": release_at}, timeout=15)
        sched_id = s.json()["scheduled_send_id"]
        c = requests.post(f"{BASE_URL}/api/inbox/scheduled/{sched_id}/cancel",
                          headers=_h(owner_token), timeout=15)
        assert c.status_code == 200, c.text
        rlist = requests.get(f"{BASE_URL}/api/inbox/scheduled", headers=_h(owner_token), timeout=15).json()
        assert not any(x.get("id") == sched_id for x in rlist.get("scheduled") or [])

    def test_snooze_flow(self, owner_token):
        sim = requests.post(f"{BASE_URL}/api/inbox/simulate-inbound",
                            headers=_h(owner_token),
                            json={"from_email": "snooze-test@example.com",
                                  "subject": "Snooze test", "body_text": "zzz"}, timeout=15)
        conv_id = sim.json()["conversation_id"]
        until = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        p = requests.patch(f"{BASE_URL}/api/inbox/conversations/{conv_id}",
                           headers=_h(owner_token),
                           json={"status": "snoozed", "snooze_until": until}, timeout=15)
        assert p.status_code == 200, p.text
        # not in open list
        r_open = requests.get(f"{BASE_URL}/api/inbox/conversations",
                              headers=_h(owner_token), params={"status": "open", "limit": 200}, timeout=15).json()
        assert not any(c.get("id") == conv_id for c in r_open.get("conversations") or [])
        # in snoozed list
        r_sn = requests.get(f"{BASE_URL}/api/inbox/conversations",
                            headers=_h(owner_token), params={"status": "snoozed", "limit": 200}, timeout=15).json()
        assert any(c.get("id") == conv_id for c in r_sn.get("conversations") or [])
        # reopen
        requests.patch(f"{BASE_URL}/api/inbox/conversations/{conv_id}",
                       headers=_h(owner_token), json={"status": "open"}, timeout=15)
        r_open2 = requests.get(f"{BASE_URL}/api/inbox/conversations",
                               headers=_h(owner_token), params={"status": "open", "limit": 200}, timeout=15).json()
        assert any(c.get("id") == conv_id for c in r_open2.get("conversations") or [])


# ---------------- Acceptance 4: CSV import ----------------

class TestCSVImport:
    def test_import_analyze_execute_rollback(self, owner_token):
        u1 = f"csv-test-{uuid.uuid4().hex[:6]}@example.com"
        u2 = f"csv-test-{uuid.uuid4().hex[:6]}@example.com"
        csv_body = (
            "first_name,last_name,email,phone,tags\n"
            f"Sara,Klein,sara.klein@example.com,+15550001111,vip\n"
            f"CsvA,Lead,{u1},+15550002222,imported\n"
            f"CsvB,Lead,{u2},+15550003333,imported\n"
        )
        files = {"file": ("import.csv", io.BytesIO(csv_body.encode()), "text/csv")}
        headers = {"Authorization": f"Bearer {owner_token}"}
        a = requests.post(f"{BASE_URL}/api/crm/import/analyze",
                          headers=headers, files=files, timeout=30)
        assert a.status_code == 200, a.text
        aj = a.json()
        assert aj["total_rows"] == 3
        assert any(m["column"].lower() == "email" and m["target"] == "email"
                   for m in aj["proposed_mapping"])
        dups = aj.get("duplicates") or []
        assert len(dups) == 1 and (dups[0].get("match_name") or "").lower().startswith("sara")
        run_id = aj["run_id"]

        # execute with update on duplicate
        e = requests.post(f"{BASE_URL}/api/crm/import/{run_id}/execute",
                          headers=_h(owner_token),
                          json={"mapping": aj["proposed_mapping"],
                                "on_duplicate": "update"}, timeout=30)
        assert e.status_code == 200, e.text
        ej = e.json()
        assert ej["created"] == 2 and ej["updated"] == 1 and ej["errors"] == 0

        # find the 2 new contacts
        s = requests.get(f"{BASE_URL}/api/crm/contacts",
                         headers=_h(owner_token), params={"q": "csv-test"}, timeout=15).json()
        new_count = len([c for c in s.get("contacts") or []
                         if any("csv-test-" in e for e in (c.get("emails") or []))])
        assert new_count == 2, f"expected 2 new csv-test contacts, got {new_count}"

        # rollback
        rb = requests.post(f"{BASE_URL}/api/crm/import/{run_id}/rollback",
                           headers=_h(owner_token), timeout=30)
        assert rb.status_code == 200, rb.text
        rbj = rb.json()
        assert rbj["reverted_created"] == 2 and rbj["reverted_updated"] == 1

        # confirm new ones gone
        s2 = requests.get(f"{BASE_URL}/api/crm/contacts",
                          headers=_h(owner_token), params={"q": "csv-test"}, timeout=15).json()
        gone = [c for c in s2.get("contacts") or []
                if any("csv-test-" in e for e in (c.get("emails") or []))]
        assert not gone, f"rollback did not remove: {gone}"

        # Sara still exists
        sara = requests.get(f"{BASE_URL}/api/crm/contacts",
                            headers=_h(owner_token), params={"q": "Sara"}, timeout=15).json()
        assert any((c.get("first_name") or "").lower() == "sara"
                   for c in sara.get("contacts") or []), "Sara Klein missing after rollback"


# ---------------- Acceptance 5: kanban + lead score ----------------

class TestKanbanAndLeadScore:
    def test_pipelines_and_stage_move(self, owner_token):
        r = requests.get(f"{BASE_URL}/api/crm/pipelines", headers=_h(owner_token), timeout=15)
        assert r.status_code == 200
        pj = r.json()
        assert pj["default_id"]
        pipes = pj["pipelines"]
        default = next(p for p in pipes if p["id"] == pj["default_id"])
        assert default["name"] == "Leads"
        stages = default["stages"]
        assert len(stages) == 5

        d = requests.get(f"{BASE_URL}/api/crm/deals",
                         headers=_h(owner_token), params={"pipeline_id": default["id"]}, timeout=15).json()
        deals = d["deals"]
        assert len(deals) >= 1
        deal = deals[0]
        other = next(s for s in stages if s["id"] != deal["stage_id"])
        m = requests.patch(f"{BASE_URL}/api/crm/deals/{deal['id']}/stage",
                           headers=_h(owner_token), json={"stage_id": other["id"]}, timeout=15)
        assert m.status_code == 200, m.text
        assert m.json()["stage_id"] == other["id"]
        # reload
        d2 = requests.get(f"{BASE_URL}/api/crm/deals",
                          headers=_h(owner_token), params={"pipeline_id": default["id"]}, timeout=15).json()
        found = next(x for x in d2["deals"] if x["id"] == deal["id"])
        assert found["stage_id"] == other["id"]

    def test_lead_score_explainable(self, owner_token):
        contacts = requests.get(f"{BASE_URL}/api/crm/contacts",
                                headers=_h(owner_token), timeout=15).json()["contacts"]
        assert contacts
        cid = contacts[0]["id"]
        r = requests.get(f"{BASE_URL}/api/crm/contacts/{cid}/lead-score",
                         headers=_h(owner_token), params={"refresh": "true"}, timeout=60)
        assert r.status_code == 200, r.text
        j = r.json()
        assert "score" in j and 0 <= j["score"] <= 100
        factors = j.get("factors") or []
        rule_factors = [f for f in factors if f.get("source") != "ai"]
        assert len(rule_factors) >= 2, f"expected >=2 rule factors, got {rule_factors}"
        breakdown = j.get("breakdown") or {}
        for k in ("rule_score", "ai_fit_score", "max_possible"):
            assert k in breakdown


# ---------------- Acceptance 6: isolation + suppressions ----------------

class TestIsolationAndSuppressions:
    def test_cross_org_isolation(self, owner_token, orgb_token):
        demo_contacts = requests.get(f"{BASE_URL}/api/crm/contacts",
                                     headers=_h(owner_token), timeout=15).json()["contacts"]
        assert len(demo_contacts) >= 1
        demo_cid = demo_contacts[0]["id"]
        demo_convs = requests.get(f"{BASE_URL}/api/inbox/conversations",
                                  headers=_h(owner_token), timeout=15).json()["conversations"]
        assert demo_convs
        demo_conv_id = demo_convs[0]["id"]
        pipe = requests.get(f"{BASE_URL}/api/crm/pipelines",
                            headers=_h(owner_token), timeout=15).json()
        default = next(p for p in pipe["pipelines"] if p["id"] == pipe["default_id"])
        demo_deals = requests.get(f"{BASE_URL}/api/crm/deals",
                                  headers=_h(owner_token),
                                  params={"pipeline_id": default["id"]}, timeout=15).json()["deals"]
        assert demo_deals
        demo_deal_id = demo_deals[0]["id"]

        # org B sees nothing
        b_contacts = requests.get(f"{BASE_URL}/api/crm/contacts",
                                  headers=_h(orgb_token), timeout=15).json()["contacts"]
        assert not any(c["id"] == demo_cid for c in b_contacts)

        # 404s
        r1 = requests.get(f"{BASE_URL}/api/crm/contacts/{demo_cid}",
                          headers=_h(orgb_token), timeout=15)
        assert r1.status_code == 404
        r2 = requests.get(f"{BASE_URL}/api/inbox/conversations/{demo_conv_id}",
                          headers=_h(orgb_token), timeout=15)
        assert r2.status_code == 404
        # stage move — pick any stage; expect 404
        r3 = requests.patch(f"{BASE_URL}/api/crm/deals/{demo_deal_id}/stage",
                            headers=_h(orgb_token),
                            json={"stage_id": default["stages"][0]["id"]}, timeout=15)
        assert r3.status_code == 404

        # sending with demo conv from org B — either 404, or creates NEW conv for orgB (demo untouched)
        before = requests.get(f"{BASE_URL}/api/inbox/conversations/{demo_conv_id}",
                              headers=_h(owner_token), timeout=15).json()["conversation"]
        r4 = requests.post(f"{BASE_URL}/api/inbox/send", headers=_h(orgb_token),
                           json={"conversation_id": demo_conv_id,
                                 "to": ["random@example.com"],
                                 "subject": "cross org test", "body_text": "hi"}, timeout=20)
        after = requests.get(f"{BASE_URL}/api/inbox/conversations/{demo_conv_id}",
                             headers=_h(owner_token), timeout=15).json()["conversation"]
        assert before.get("last_message_at") == after.get("last_message_at"), \
            "demo conv was modified by org B send!"

    def test_suppressions_block_send(self, owner_token):
        # add suppression
        r = requests.post(f"{BASE_URL}/api/email/suppressions",
                          headers=_h(owner_token),
                          json={"email": "blocked-test@example.com",
                                "reason": "unsubscribe"}, timeout=15)
        assert r.status_code == 200, r.text
        # send should 409
        s = requests.post(f"{BASE_URL}/api/inbox/send", headers=_h(owner_token),
                          json={"to": ["blocked-test@example.com"],
                                "subject": "hi", "body_text": "test"}, timeout=15)
        assert s.status_code == 409, s.text
        det = s.json().get("detail") or {}
        assert det.get("error") == "suppressed_recipients"
        assert (det.get("suppressed") or [{}])[0].get("reason") == "unsubscribe"
        # delete suppression
        d = requests.delete(f"{BASE_URL}/api/email/suppressions/blocked-test@example.com",
                            headers=_h(owner_token), timeout=15)
        assert d.status_code == 200
        # send should now succeed (or fail for a different reason)
        s2 = requests.post(f"{BASE_URL}/api/inbox/send", headers=_h(owner_token),
                           json={"to": ["blocked-test@example.com"],
                                 "subject": "hi", "body_text": "test after unblock",
                                 "force": True}, timeout=15)
        assert s2.status_code != 409 or (s2.json().get("detail") or {}).get("error") != "suppressed_recipients"


# ---------------- OpenAPI exposure ----------------

class TestOpenAPI:
    def test_openapi_exposes_key_paths(self):
        r = requests.get(f"{BASE_URL}/api/openapi.json", timeout=15)
        assert r.status_code == 200
        paths = set((r.json().get("paths") or {}).keys())
        required = [
            "/api/crm/contacts",
            "/api/crm/deals",
            "/api/crm/deals/{deal_id}/stage",
            "/api/crm/import/analyze",
            "/api/inbox/conversations",
            "/api/inbox/send",
            "/api/inbox/scheduled",
            "/api/inbox/conversations/{conv_id}/ai/draft-reply",
            "/api/email/providers",
            "/api/email/config",
            "/api/email/test-send",
            "/api/email/suppressions",
        ]
        missing = [p for p in required if p not in paths]
        assert not missing, f"missing openapi paths: {missing}"


# ---------------- Phase 2 regression (smoke) ----------------

class TestPhase2Regression:
    def test_public_site_still_renders(self):
        r = requests.get(f"{BASE_URL}/api/public/sites/demo-home-services", timeout=15)
        assert r.status_code == 200
        assert (r.json().get("pages") or []) != []

    def test_domain_providers_list(self, owner_token):
        r = requests.get(f"{BASE_URL}/api/domains/providers", headers=_h(owner_token), timeout=15)
        assert r.status_code == 200
        provs = r.json().get("providers") or []
        keys = {p.get("key") for p in provs}
        assert {"simulated", "cloudflare"}.issubset(keys)
