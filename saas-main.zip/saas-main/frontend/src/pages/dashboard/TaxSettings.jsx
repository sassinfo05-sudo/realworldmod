import { useEffect, useState } from "react";
import { toast } from "sonner";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2, Loader2, Percent } from "lucide-react";

/** /app/store/tax — per-region tax rates applied server-side at checkout (most specific match wins). */
export default function TaxSettings() {
    const [rates, setRates] = useState([]);
    const [displayInclusive, setDisplayInclusive] = useState(false);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [preview, setPreview] = useState({ country: "US", region: "", subtotal: "100" });
    const [previewOut, setPreviewOut] = useState(null);
    const [orgId, setOrgId] = useState(null);

    useEffect(() => {
        Promise.all([api.get("/store/tax-rates"), api.get("/auth/me")]).then(([{ data }, me]) => {
            setRates(data.rates || []); setDisplayInclusive(!!data.display_inclusive); setOrgId(me.data.org_id);
        }).catch(() => toast.error("Could not load tax settings")).finally(() => setLoading(false));
    }, []);

    const save = async () => {
        setBusy(true);
        try {
            const clean = rates.map((r) => ({ country: (r.country || "*").toUpperCase().slice(0, 2), region: (r.region || "").toUpperCase(), pct: parseFloat(r.pct) || 0, inclusive: !!r.inclusive, label: r.label || "Tax" }));
            const { data } = await api.put("/store/tax-rates", { rates: clean, display_inclusive: displayInclusive });
            setRates(data.rates); toast.success("Tax rates saved");
        } catch (e) {
            const d = e?.response?.data?.detail;
            toast.error(typeof d === "string" ? d : (d?.[0]?.msg || "Could not save"));
        } finally { setBusy(false); }
    };

    const runPreview = async () => {
        if (!orgId) return;
        try {
            const { data } = await api.get(`/public/store/${orgId}/tax-preview`, { params: { country: preview.country, region: preview.region, subtotal_cents: Math.round(parseFloat(preview.subtotal || "0") * 100) } });
            setPreviewOut(data);
        } catch { toast.error("Preview failed"); }
    };

    const upd = (i, k, v) => setRates(rates.map((r, j) => (j === i ? { ...r, [k]: v } : r)));

    return (
        <div className="p-6 md:p-8 max-w-4xl" data-testid="tax-settings-page">
            <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Sell</div>
            <h1 className="font-display text-2xl md:text-3xl text-brand-ink font-medium flex items-center gap-2"><Percent className="w-6 h-6" /> Tax rates</h1>
            <p className="mt-1 text-sm text-zinc-500">Tax is computed on the server at checkout from the buyer's destination. The most specific rule wins (country + region → country → “*” everywhere). Use “inclusive” when your prices already contain tax.</p>

            {loading ? <div className="mt-8 text-sm text-zinc-500 flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Loading…</div> : (
                <>
                    <div className="mt-6 rounded-2xl border border-brand-line bg-white overflow-hidden">
                        <div className="grid grid-cols-12 gap-2 px-4 py-2 text-[11px] uppercase tracking-widest text-zinc-500 bg-zinc-50 border-b border-brand-line">
                            <div className="col-span-2">Country</div><div className="col-span-2">Region</div><div className="col-span-2">Rate %</div><div className="col-span-3">Label</div><div className="col-span-2">Inclusive</div><div />
                        </div>
                        {rates.length === 0 && <div className="px-4 py-6 text-sm text-zinc-500" data-testid="tax-empty">No tax rules yet — orders are untaxed.</div>}
                        {rates.map((r, i) => (
                            <div key={i} className="grid grid-cols-12 gap-2 px-4 py-2 items-center border-b border-brand-line last:border-0" data-testid={`tax-row-${i}`}>
                                <Input className="col-span-2 font-mono uppercase" value={r.country} onChange={(e) => upd(i, "country", e.target.value)} placeholder="US or *" maxLength={2} />
                                <Input className="col-span-2 font-mono uppercase" value={r.region} onChange={(e) => upd(i, "region", e.target.value)} placeholder="CA" maxLength={10} />
                                <Input className="col-span-2" type="number" step="0.01" min="0" max="60" value={r.pct} onChange={(e) => upd(i, "pct", e.target.value)} />
                                <Input className="col-span-3" value={r.label} onChange={(e) => upd(i, "label", e.target.value)} placeholder="VAT / Sales tax" />
                                <div className="col-span-2"><Switch checked={!!r.inclusive} onCheckedChange={(v) => upd(i, "inclusive", v)} /></div>
                                <button type="button" className="text-zinc-400 hover:text-red-600 justify-self-end" onClick={() => setRates(rates.filter((_, j) => j !== i))} data-testid={`tax-delete-${i}`}><Trash2 className="w-4 h-4" /></button>
                            </div>
                        ))}
                    </div>
                    <div className="mt-3 flex items-center justify-between flex-wrap gap-3">
                        <Button variant="outline" className="border-brand-line" onClick={() => setRates([...rates, { country: "*", region: "", pct: 0, inclusive: false, label: "Tax" }])} data-testid="tax-add"><Plus className="w-4 h-4 mr-1" /> Add rule</Button>
                        <div className="flex items-center gap-4">
                            <label className="flex items-center gap-2 text-sm text-zinc-700"><Switch checked={displayInclusive} onCheckedChange={setDisplayInclusive} /> Show tax-inclusive prices in storefront</label>
                            <Button onClick={save} disabled={busy} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="tax-save">{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save"}</Button>
                        </div>
                    </div>

                    <div className="mt-8 rounded-2xl border border-brand-line bg-white p-4">
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Preview a checkout</div>
                        <div className="grid sm:grid-cols-4 gap-2 items-end">
                            <div><Label className="text-xs">Country</Label><Input value={preview.country} onChange={(e) => setPreview({ ...preview, country: e.target.value })} className="font-mono uppercase" /></div>
                            <div><Label className="text-xs">Region</Label><Input value={preview.region} onChange={(e) => setPreview({ ...preview, region: e.target.value })} className="font-mono uppercase" /></div>
                            <div><Label className="text-xs">Subtotal</Label><Input type="number" value={preview.subtotal} onChange={(e) => setPreview({ ...preview, subtotal: e.target.value })} /></div>
                            <Button variant="outline" className="border-brand-line" onClick={runPreview} data-testid="tax-preview-run">Calculate</Button>
                        </div>
                        {previewOut && (
                            <div className="mt-3 text-sm" data-testid="tax-preview-out">
                                {previewOut.applied ? <>Applies <b>{previewOut.label}</b> at {previewOut.rate_pct}% → <b>{(previewOut.tax_cents / 100).toFixed(2)}</b> {previewOut.inclusive ? "(included in price)" : "added at checkout"}</> : "No tax rule matches this destination."}
                            </div>
                        )}
                    </div>
                </>
            )}
        </div>
    );
}
