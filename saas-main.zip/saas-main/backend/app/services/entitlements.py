"""Entitlements per plan + usage metering.

Every API-layer enforcement pulls from `ENTITLEMENTS[plan_code]`. Exceeding a limit
raises a 402-style HTTPException with a clear structure the frontend can map to
"You've hit your plan limit" + upgrade CTA.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from fastapi import HTTPException

from ..db import get_db, utc_now_iso


# ---------- Plan → entitlements table (source of truth) ----------

@dataclass(frozen=True)
class PlanLimits:
    plan_code: str
    max_users: int
    max_contacts: int
    ai_conversations_per_month: int
    voice_minutes_per_month: int
    email_sends_per_month: int
    websites: int
    custom_domain: bool
    remove_branding: bool
    campaigns_enabled: bool
    api_keys: bool
    ai_receptionist: bool
    label: str
    ai_credits_usd_per_month: float = 0.0  # monthly ceiling of our AI serving cost; 0 = unlimited
    # Round 15 closed-beta: total variable-provider hard cap (AI + all other variable provider
    # cost that consumes plan margin); 0 = unlimited. Pass-through/prepaid items (voice minutes,
    # phone numbers, SMS/WhatsApp, ad spend, shipping labels, domain registration, payment fees)
    # are billed separately and do NOT count against this.
    variable_provider_cap_usd: float = 0.0
    # Round 13 — feature flags for the newer capabilities (defaults keep old callers safe)
    max_products: int = 10
    online_store: bool = True
    subscriptions: bool = False       # recurring/subscription products
    multi_language: bool = False      # localization + authored translations
    automations: bool = False         # workflow automation builder
    advanced_analytics: bool = False  # attribution + advanced marketing reports
    ad_campaigns: bool = False        # paid ad manager
    abandoned_cart: bool = False      # cart recovery
    pos: bool = False                 # point of sale
    priority_support: bool = False


ENTITLEMENTS: Dict[str, PlanLimits] = {
    "free": PlanLimits(
        plan_code="free", max_users=1, max_contacts=100,
        ai_conversations_per_month=25, voice_minutes_per_month=0,
        email_sends_per_month=100, websites=1,
        custom_domain=False, remove_branding=False, campaigns_enabled=False,
        api_keys=False, ai_receptionist=False, label="Free",
        ai_credits_usd_per_month=0.10, variable_provider_cap_usd=0.25,
        max_products=10, online_store=True,
    ),
    "launch": PlanLimits(
        plan_code="launch", max_users=2, max_contacts=1_000,
        ai_conversations_per_month=200, voice_minutes_per_month=0,
        email_sends_per_month=2_500, websites=1,
        custom_domain=True, remove_branding=True, campaigns_enabled=False,
        api_keys=False, ai_receptionist=False, label="Starter",
        ai_credits_usd_per_month=1.00, variable_provider_cap_usd=2.04,
        max_products=100, online_store=True, multi_language=True,
    ),
    "revenue": PlanLimits(
        plan_code="revenue", max_users=5, max_contacts=10_000,
        ai_conversations_per_month=1_000, voice_minutes_per_month=60,
        email_sends_per_month=15_000, websites=2,
        custom_domain=True, remove_branding=True, campaigns_enabled=True,
        api_keys=True, ai_receptionist=False, label="Business",
        ai_credits_usd_per_month=3.00, variable_provider_cap_usd=4.68,
        max_products=2_000, online_store=True, subscriptions=True, multi_language=True,
        automations=True, advanced_analytics=True, ad_campaigns=True, abandoned_cart=True,
    ),
    "autopilot": PlanLimits(
        plan_code="autopilot", max_users=10, max_contacts=25_000,
        ai_conversations_per_month=5_000, voice_minutes_per_month=300,
        email_sends_per_month=50_000, websites=3,
        custom_domain=True, remove_branding=True, campaigns_enabled=True,
        api_keys=True, ai_receptionist=True, label="Commerce + AI",
        ai_credits_usd_per_month=8.00, variable_provider_cap_usd=11.88,
        max_products=10_000, online_store=True, subscriptions=True, multi_language=True,
        automations=True, advanced_analytics=True, ad_campaigns=True, abandoned_cart=True, pos=True,
    ),
    "scale": PlanLimits(
        plan_code="scale", max_users=100, max_contacts=250_000,
        ai_conversations_per_month=25_000, voice_minutes_per_month=2_000,
        email_sends_per_month=250_000, websites=10,
        custom_domain=True, remove_branding=True, campaigns_enabled=True,
        api_keys=True, ai_receptionist=True, label="Scale",
        ai_credits_usd_per_month=20.00, variable_provider_cap_usd=29.88,
        max_products=100_000, online_store=True, subscriptions=True, multi_language=True,
        automations=True, advanced_analytics=True, ad_campaigns=True, abandoned_cart=True,
        pos=True, priority_support=True,
    ),
}


def plan_limits(plan_code: str) -> PlanLimits:
    return ENTITLEMENTS.get(plan_code) or ENTITLEMENTS["free"]


# ---------- DB-backed overrides (founder-editable limits) ----------

# Numeric limit fields a founder may override from the owner panel.
_OVERRIDABLE_INT = (
    "max_users", "max_contacts", "ai_conversations_per_month",
    "voice_minutes_per_month", "email_sends_per_month", "websites", "max_products",
)
_OVERRIDABLE_BOOL = (
    "custom_domain", "remove_branding", "campaigns_enabled",
    "api_keys", "ai_receptionist", "online_store", "subscriptions", "multi_language",
    "automations", "advanced_analytics", "ad_campaigns", "abandoned_cart", "pos", "priority_support",
)
_OVERRIDABLE_FLOAT = (
    "ai_credits_usd_per_month",
    "variable_provider_cap_usd",
)


def apply_db_overrides(plan_docs) -> None:
    """Rebuild ENTITLEMENTS entries from DB plan docs' `limits` sub-doc.

    Mutates the module-level ENTITLEMENTS dict in place so every existing
    (sync) call site immediately sees founder edits. Unknown plan codes create
    a new entry cloned from `free`.
    """
    from dataclasses import replace as _replace
    for d in plan_docs or []:
        code = d.get("code")
        if not code:
            continue
        lim = d.get("limits") or {}
        base = ENTITLEMENTS.get(code) or ENTITLEMENTS["free"]
        patch: Dict[str, Any] = {}
        for k in _OVERRIDABLE_INT:
            if k in lim and lim[k] is not None:
                try:
                    patch[k] = int(lim[k])
                except (TypeError, ValueError):
                    pass
        for k in _OVERRIDABLE_BOOL:
            if k in lim and lim[k] is not None:
                patch[k] = bool(lim[k])
        for k in _OVERRIDABLE_FLOAT:
            if k in lim and lim[k] is not None:
                try:
                    patch[k] = float(lim[k])
                except (TypeError, ValueError):
                    pass
        if base.plan_code != code:
            patch["plan_code"] = code
            patch["label"] = d.get("name") or code.title()
        if patch:
            ENTITLEMENTS[code] = _replace(base, **patch)


# ---------- Profit / economics calculator ----------

def plan_cost_at_full_usage(plan_code: str, unit_costs: Dict[str, float]) -> float:
    """Monthly cost to serve ONE customer on this plan at 100% of every limit."""
    l = plan_limits(plan_code)
    uc = unit_costs or {}
    cost = 0.0
    cost += l.ai_conversations_per_month * float(uc.get("per_ai_conversation", 0) or 0)
    cost += l.voice_minutes_per_month * float(uc.get("per_voice_minute", 0) or 0)
    cost += l.email_sends_per_month * float(uc.get("per_email", 0) or 0)
    cost += l.websites * float(uc.get("per_website_month", 0) or 0)
    cost += l.max_contacts * float(uc.get("per_contact_month", 0) or 0)
    cost += float(uc.get("base_infra_per_org_month", 0) or 0)
    return round(cost, 2)


def plan_economics(plan_doc: Dict[str, Any], unit_costs: Dict[str, float],
                    annual_discount_pct: float) -> Dict[str, Any]:
    """Return the full profit picture for one plan."""
    code = plan_doc.get("code")
    price = float(plan_doc.get("price_usd") or 0)
    cost = plan_cost_at_full_usage(code, unit_costs)
    profit = round(price - cost, 2)
    margin = round((profit / price) * 100, 1) if price > 0 else None

    disc = max(0.0, min(90.0, float(annual_discount_pct or 0)))
    if plan_doc.get("annual_price_usd") is not None and price > 0:
        # Real annual price set by the founder wins over the generic discount %.
        annual_total = round(float(plan_doc.get("annual_price_usd") or 0), 2)
        annual_monthly_equiv = round(annual_total / 12.0, 2)
        disc = round((1 - (annual_monthly_equiv / price)) * 100, 1) if price else 0.0
    else:
        annual_monthly_equiv = round(price * (1 - disc / 100.0), 2)
        annual_total = round(annual_monthly_equiv * 12, 2)
    annual_profit = round(annual_monthly_equiv - cost, 2)
    annual_margin = round((annual_profit / annual_monthly_equiv) * 100, 1) if annual_monthly_equiv > 0 else None

    return {
        "code": code,
        "name": plan_doc.get("name"),
        "price_monthly": price,
        "annual_price": annual_total,
        "cost_at_full_usage": cost,
        "profit_monthly": profit,
        "margin_pct": margin,
        "loses_money": profit < 0,
        "annual_discount_pct": disc,
        "annual_monthly_equiv": annual_monthly_equiv,
        "annual_total": annual_total,
        "annual_profit_monthly": annual_profit,
        "annual_margin_pct": annual_margin,
        "limits": entitlements_dict(code),
    }


def entitlements_dict(plan_code: str) -> Dict[str, Any]:
    l = plan_limits(plan_code)
    return {
        "plan_code": l.plan_code, "label": l.label,
        "max_users": l.max_users, "max_contacts": l.max_contacts,
        "ai_conversations_per_month": l.ai_conversations_per_month,
        "voice_minutes_per_month": l.voice_minutes_per_month,
        "email_sends_per_month": l.email_sends_per_month,
        "websites": l.websites,
        "custom_domain": l.custom_domain,
        "remove_branding": l.remove_branding,
        "campaigns_enabled": l.campaigns_enabled,
        "api_keys": l.api_keys,
        "ai_receptionist": l.ai_receptionist,
        "ai_credits_usd_per_month": l.ai_credits_usd_per_month,
        "variable_provider_cap_usd": l.variable_provider_cap_usd,
        "max_products": l.max_products,
        "online_store": l.online_store,
        "subscriptions": l.subscriptions,
        "multi_language": l.multi_language,
        "automations": l.automations,
        "advanced_analytics": l.advanced_analytics,
        "ad_campaigns": l.ad_campaigns,
        "abandoned_cart": l.abandoned_cart,
        "pos": l.pos,
        "priority_support": l.priority_support,
    }


def ai_budget_usd(plan_code: str) -> float:
    """Monthly AI serving-cost ceiling for a plan (0 = unlimited/not enforced)."""
    return float(plan_limits(plan_code).ai_credits_usd_per_month or 0.0)


def variable_provider_cap_usd(plan_code: str) -> float:
    """Total variable-provider hard cap for a plan (0 = unlimited). Covers AI + other
    margin-consuming variable provider cost; excludes pass-through/prepaid items."""
    return float(plan_limits(plan_code).variable_provider_cap_usd or 0.0)


# ---------- Public feature-comparison matrix (pricing page) ----------

# (group, key, label, type). `type` is "bool" or "number"; values come from entitlements_dict.
FEATURE_MATRIX_ROWS = [
    ("Websites & content", "websites", "Websites", "number"),
    ("Websites & content", "custom_domain", "Custom domain + free SSL", "bool"),
    ("Websites & content", "remove_branding", "Remove Zanelvo badge", "bool"),
    ("Websites & content", "multi_language", "Multi-language + authored translations", "bool"),
    ("Online store", "online_store", "Online store & checkout", "bool"),
    ("Online store", "max_products", "Products", "number"),
    ("Online store", "subscriptions", "Subscription (recurring) products", "bool"),
    ("Online store", "abandoned_cart", "Abandoned-cart recovery", "bool"),
    ("Online store", "pos", "Point of sale (POS)", "bool"),
    ("Marketing & AI", "campaigns_enabled", "Email marketing campaigns", "bool"),
    ("Marketing & AI", "automations", "Workflow automations", "bool"),
    ("Marketing & AI", "ad_campaigns", "Paid ad campaign manager", "bool"),
    ("Marketing & AI", "advanced_analytics", "Advanced analytics & A/B testing", "bool"),
    ("Marketing & AI", "ai_conversations_per_month", "AI chat conversations / mo", "number"),
    ("Marketing & AI", "ai_receptionist", "AI receptionist (chat + email)", "bool"),
    ("Marketing & AI", "voice_minutes_per_month", "AI voice minutes / mo", "number"),
    ("Team & limits", "max_users", "Team seats", "number"),
    ("Team & limits", "max_contacts", "Contacts", "number"),
    ("Team & limits", "email_sends_per_month", "Emails / mo", "number"),
    ("Team & limits", "api_keys", "API access & keys", "bool"),
    ("Team & limits", "priority_support", "Priority support + SLA", "bool"),
]


# Features that depend on an external provider being CONNECTED and production-tested. Until then the
# public matrix must not show them as included (truthful pricing). `availability` is computed at request
# time from the platform Setup Center / provider probes.
PROVIDER_GATED_FEATURES = {
    "subscriptions": "recurring_billing",     # Stripe Billing for recurring products
    "pos": "pos",                             # point-of-sale hardware/provider
    "ad_campaigns": "ads",                    # Google/Meta ad-account OAuth
    "voice_minutes_per_month": "voice",       # Telnyx/Twilio/Retell
    "custom_domain": "domains",               # Cloudflare for SaaS custom hostnames + SSL
}


async def provider_availability() -> Dict[str, Dict[str, Any]]:
    """Honest availability of provider-backed features (never derived from a key-name pattern)."""
    out: Dict[str, Dict[str, Any]] = {
        "recurring_billing": {"available": False, "note": "Recurring card billing is not available yet."},
        "pos": {"available": False, "note": "Point of sale is not available yet."},
        "ads": {"available": False, "note": "Ad-account connections (Google/Meta) are not available yet."},
        "voice": {"available": False, "note": "AI voice is not connected yet; voice minutes are billed pass-through when enabled."},
        "domains": {"available": False, "note": "Custom domains are not available until the platform connects its DNS/SSL provider."},
    }
    try:
        from . import domain_providers
        await domain_providers.refresh_credentials()
        cf = domain_providers.get_provider("cloudflare")
        if getattr(cf, "probe_state", "") == "connected":
            out["domains"] = {"available": True, "note": ""}
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import integrations as _integ
        if await _integ.is_configured("voice"):
            out["voice"] = {"available": True, "note": ""}
    except Exception:  # noqa: BLE001
        pass
    return out


def feature_matrix(plan_codes: list, availability: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Grouped feature rows with each plan's value — drives the pricing comparison grid.
    Provider-gated rows carry `available=False` + `note` when the provider isn't connected, so the public page
    renders "Not yet available" instead of a check."""
    ents = {c: entitlements_dict(c) for c in plan_codes}
    groups: Dict[str, list] = {}
    order: list = []
    for group, key, label, ftype in FEATURE_MATRIX_ROWS:
        if group not in groups:
            groups[group] = []
            order.append(group)
        row = {
            "key": key, "label": label, "type": ftype,
            "values": {c: ents[c].get(key) for c in plan_codes},
            "available": True, "note": "",
        }
        gate = PROVIDER_GATED_FEATURES.get(key)
        if gate and availability is not None:
            av = availability.get(gate) or {}
            row["available"] = bool(av.get("available"))
            row["note"] = av.get("note", "")
        groups[group].append(row)
    return {"groups": [{"name": g, "rows": groups[g]} for g in order]}


# ---------- Subscription resolution ----------

async def get_org_plan(org_id: str) -> str:
    """Resolve the current active plan for an org. Defaults to 'free'."""
    db = get_db()
    sub = await db.subscriptions.find_one({"org_id": org_id})
    if not sub:
        return "free"
    if sub.get("status") in ("canceled",):
        return "free"
    return sub.get("plan_code") or "free"


async def get_or_create_subscription(org_id: str, plan_code: str = "free") -> Dict[str, Any]:
    db = get_db()
    sub = await db.subscriptions.find_one({"org_id": org_id})
    if sub:
        return sub
    now = datetime.now(timezone.utc)
    period_end = now + timedelta(days=30)
    doc = {
        "org_id": org_id,
        "plan_code": plan_code,
        "status": "active",
        "provider": "simulated",
        "current_period_start": now.isoformat().replace("+00:00", "Z"),
        "current_period_end": period_end.isoformat().replace("+00:00", "Z"),
        "cancel_at_period_end": False,
        "failed_payment_count": 0,
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }
    r = await db.subscriptions.insert_one(doc)
    doc["_id"] = r.inserted_id
    return doc


# ---------- Usage metering ----------

def _month_bounds(now: Optional[datetime] = None) -> tuple[str, str]:
    now = now or datetime.now(timezone.utc)
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if start.month == 12:
        end = start.replace(year=start.year + 1, month=1)
    else:
        end = start.replace(month=start.month + 1)
    return (start.isoformat().replace("+00:00", "Z"),
            end.isoformat().replace("+00:00", "Z"))


async def measure_usage(org_id: str) -> Dict[str, Any]:
    """Compute current-period usage counters from raw data (never cache stale)."""
    db = get_db()
    month_start, month_end = _month_bounds()

    ai_conversations = await db.chat_conversations.count_documents({
        "org_id": org_id, "is_sandbox": {"$ne": True},
        "started_at": {"$gte": month_start, "$lt": month_end},
    })
    email_sends = await db.email_messages.count_documents({
        "org_id": org_id, "direction": "outbound",
        "sent_at": {"$gte": month_start, "$lt": month_end},
    })
    voice_seconds = 0
    async for c in db.call_records.find({
        "org_id": org_id,
        "created_at": {"$gte": month_start, "$lt": month_end},
    }):
        voice_seconds += int(c.get("duration_seconds") or 0)
    voice_minutes = round(voice_seconds / 60.0, 1)
    contacts = await db.contacts.count_documents({"org_id": org_id})
    users = await db.users.count_documents({"org_id": org_id})
    websites = await db.websites.count_documents({"org_id": org_id})
    products = await db.store_products.count_documents({"org_id": org_id})
    return {
        "month_start": month_start, "month_end": month_end,
        "ai_conversations": ai_conversations,
        "email_sends": email_sends,
        "voice_minutes": voice_minutes,
        "contacts": contacts, "users": users, "websites": websites,
        "products": products,
    }


async def usage_with_limits(org_id: str) -> Dict[str, Any]:
    plan = await get_org_plan(org_id)
    ent = entitlements_dict(plan)
    usage = await measure_usage(org_id)

    def _meter(used, cap):
        pct = 0
        if cap > 0:
            pct = min(200, int((used / cap) * 100))
        return {"used": used, "cap": cap, "pct": pct,
                 "over": used >= cap and cap > 0,
                 "warn": pct >= 80 and pct < 100}

    return {
        "plan": ent,
        "usage": usage,
        "meters": {
            "ai_conversations": _meter(usage["ai_conversations"], ent["ai_conversations_per_month"]),
            "email_sends": _meter(usage["email_sends"], ent["email_sends_per_month"]),
            "voice_minutes": _meter(usage["voice_minutes"], ent["voice_minutes_per_month"]),
            "contacts": _meter(usage["contacts"], ent["max_contacts"]),
            "users": _meter(usage["users"], ent["max_users"]),
            "websites": _meter(usage["websites"], ent["websites"]),
            "products": _meter(usage["products"], ent.get("max_products", 0)),
        },
    }


# ---------- Enforcement primitives ----------

def _limit_exceeded_error(feature: str, plan_code: str, used: int, cap: int,
                             suggest_plan: str) -> HTTPException:
    return HTTPException(status_code=402, detail={
        "error": "plan_limit_reached",
        "feature": feature, "plan_code": plan_code,
        "used": used, "cap": cap,
        "message": (f"You've reached the {feature} limit for the {plan_code.title()} plan "
                    f"({used}/{cap}). Upgrade to {suggest_plan.title()} to continue."),
        "suggest_plan": suggest_plan,
    })


def _next_plan(current: str) -> str:
    order = ["free", "launch", "revenue", "autopilot", "scale"]
    try:
        i = order.index(current)
        return order[min(i + 1, len(order) - 1)]
    except ValueError:
        return "revenue"


async def enforce_feature_enabled(org_id: str, feature_flag: str) -> None:
    """Boolean entitlement (custom_domain, campaigns_enabled, api_keys, ai_receptionist)."""
    plan = await get_org_plan(org_id)
    ent = entitlements_dict(plan)
    if not ent.get(feature_flag):
        raise HTTPException(status_code=402, detail={
            "error": "feature_not_in_plan",
            "feature": feature_flag, "plan_code": plan,
            "message": f"The {feature_flag.replace('_', ' ')} feature isn't in the {plan.title()} plan.",
            "suggest_plan": _next_plan(plan),
            "upgrade_url": "/app/billing",
        })


async def enforce_metered(org_id: str, meter_key: str, increment: int = 1) -> None:
    """Metered entitlement (ai_conversations, email_sends, voice_minutes, contacts, users, websites).
    Called at the point of adding one more (or `increment` more) of the resource.

    Refuses BEFORE the write when `used + increment > cap`. `increment=0` still refuses
    if already over cap — safe default for "check without incrementing".
    """
    plan = await get_org_plan(org_id)
    ent = entitlements_dict(plan)
    usage = await measure_usage(org_id)
    caps = {
        "ai_conversations": ent["ai_conversations_per_month"],
        "email_sends": ent["email_sends_per_month"],
        "voice_minutes": ent["voice_minutes_per_month"],
        "contacts": ent["max_contacts"],
        "users": ent["max_users"],
        "websites": ent["websites"],
        "products": ent.get("max_products", 0),
    }
    cap = caps.get(meter_key, 0)
    used = usage.get(meter_key, 0)
    if cap == 0:
        raise HTTPException(status_code=402, detail={
            "error": "feature_not_in_plan",
            "feature": meter_key, "plan_code": plan,
            "message": f"{meter_key.replace('_', ' ').title()} isn't included in the {plan.title()} plan.",
            "suggest_plan": _next_plan(plan),
            "upgrade_url": "/app/billing",
        })
    if used + max(0, int(increment or 0)) > cap:
        raise HTTPException(status_code=402, detail={
            "error": "plan_limit_reached",
            "meter": meter_key, "feature": meter_key, "plan_code": plan,
            "used": used, "cap": cap, "increment": increment,
            "message": (f"You've reached the {meter_key.replace('_', ' ')} limit for the "
                        f"{plan.title()} plan ({used}/{cap}). Upgrade to {_next_plan(plan).title()}."),
            "suggest_plan": _next_plan(plan),
            "upgrade_url": "/app/billing",
        })


# Alias — clearer name for callers ("enforce that org can grow meter by increment").
async def enforce_entitlement(org_id: str, meter: str, increment: int = 1) -> None:
    await enforce_metered(org_id, meter, increment=increment)


async def check_metered(org_id: str, meter_key: str) -> bool:
    """True when the org still has headroom on this meter (>=1). Non-raising."""
    try:
        await enforce_metered(org_id, meter_key, increment=1)
        return True
    except HTTPException:
        return False


async def branding_removed(org_id: str) -> bool:
    plan = await get_org_plan(org_id)
    return entitlements_dict(plan).get("remove_branding", False)
