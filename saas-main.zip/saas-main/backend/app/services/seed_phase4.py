"""Seed Phase 4 demo data — staff, bookable services, bookings, quotes, invoices, jobs."""
from __future__ import annotations

import logging
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from bson import ObjectId

from ..db import get_db, utc_now_iso
from ..models_bookings import (
    ApprovalRule, Booking, ChecklistItem, Invoice, InvoiceLine, Job, Payment,
    Quote, QuoteLine, QuoteTotals, ServiceOffering, Staff, WorkingHours,
)

logger = logging.getLogger(__name__)

DEMO_ORG_SLUG = "demo-home-services"


async def seed_phase4_demo() -> None:
    db = get_db()
    org = await db.organizations.find_one({"slug": DEMO_ORG_SLUG})
    if not org:
        return
    org_id = str(org["_id"])
    owner = await db.users.find_one({"org_id": org_id, "role": "owner"})
    owner_user_id = str(owner["_id"]) if owner else None

    # Indexes (idempotent)
    try:
        await db.bookings.create_index([("org_id", 1), ("staff_id", 1), ("start_at", 1)])
        await db.quotes.create_index([("org_id", 1), ("status", 1)])
        await db.invoices.create_index([("org_id", 1), ("status", 1)])
        await db.jobs.create_index([("org_id", 1), ("status", 1)])
    except Exception as e:  # noqa: BLE001
        logger.warning("Phase4 index warning: %s", e)

    if await db.staff.count_documents({"org_id": org_id}) >= 2:
        logger.info("Phase 4 demo already seeded.")
        return

    # ----- Staff -----
    weekday_hours = [WorkingHours(day=d, start="09:00", end="17:00") for d in range(0, 5)]
    weekend = [WorkingHours(day=5, start="10:00", end="14:00")]
    staff1 = Staff(org_id=org_id, display_name="Alex Rivera", email="alex@demo.zanelvo.local",
                    role="senior_technician", timezone="America/Los_Angeles",
                    working_hours=weekday_hours + weekend, capacity=1, color="#D95A2B")
    staff2 = Staff(org_id=org_id, display_name="Jordan Lee", email="jordan@demo.zanelvo.local",
                    role="technician", timezone="America/Los_Angeles",
                    working_hours=weekday_hours, capacity=1, color="#0EA5E9")
    s1 = await db.staff.insert_one(staff1.to_mongo()); staff1.id = str(s1.inserted_id)
    s2 = await db.staff.insert_one(staff2.to_mongo()); staff2.id = str(s2.inserted_id)

    # ----- Approval rule: any discount ≥ 20% needs owner approval -----
    # NOTE: threshold_value is on the 0-100 percent scale (matches API contract).
    rule = ApprovalRule(org_id=org_id, name="Discount ≥ 20% needs owner",
                          threshold_type="discount_percent", threshold_value=20.0,
                          required_role="owner")
    await db.approval_rules.insert_one(rule.to_mongo())

    # ----- Bookable Services -----
    svc_leak = ServiceOffering(org_id=org_id, name="Emergency leak visit",
                                 description="On-site diagnosis + first-hour fix.",
                                 duration_minutes=60, buffer_before_minutes=15, buffer_after_minutes=30,
                                 price_cents=18000, deposit_cents=0, currency="USD",
                                 location_type="on_site", color="#D95A2B")
    svc_drain = ServiceOffering(org_id=org_id, name="Drain unblock",
                                 description="Most jobs fixed in one visit.",
                                 duration_minutes=90, buffer_before_minutes=15, buffer_after_minutes=30,
                                 price_cents=22000, currency="USD", location_type="on_site")
    svc_water = ServiceOffering(org_id=org_id, name="Water heater install",
                                 description="Includes haul-away.",
                                 duration_minutes=180, buffer_before_minutes=30, buffer_after_minutes=60,
                                 price_cents=120000, deposit_cents=20000, currency="USD",
                                 location_type="on_site")
    for s in (svc_leak, svc_drain, svc_water):
        r = await db.service_offerings.insert_one(s.to_mongo())
        s.id = str(r.inserted_id)

    # ----- Sample bookings across the week -----
    now = datetime.now(timezone.utc)
    tomorrow_10 = (now + timedelta(days=1)).replace(hour=17, minute=0, second=0, microsecond=0)  # 10 AM PT
    two_days_15 = (now + timedelta(days=2)).replace(hour=22, minute=0, second=0, microsecond=0)  # 3 PM PT
    contacts = [c async for c in db.contacts.find({"org_id": org_id}).limit(6)]
    for i, (svc, staff_obj, when, contact) in enumerate([
        (svc_leak, staff1, tomorrow_10, contacts[0] if contacts else None),
        (svc_drain, staff2, two_days_15, contacts[1] if len(contacts) > 1 else None),
        (svc_water, staff1, tomorrow_10 + timedelta(days=2), contacts[2] if len(contacts) > 2 else None),
    ]):
        b = Booking(
            org_id=org_id, service_id=svc.id, staff_id=staff_obj.id,
            contact_id=str(contact["_id"]) if contact else None,
            start_at=when.isoformat().replace("+00:00", "Z"),
            end_at=(when + timedelta(minutes=svc.duration_minutes)).isoformat().replace("+00:00", "Z"),
            buffer_before_minutes=svc.buffer_before_minutes,
            buffer_after_minutes=svc.buffer_after_minutes,
            source="manual", booking_number=f"B-{now.year}-{i+1:04d}",
            tokens={"cancel": secrets.token_urlsafe(20), "reschedule": secrets.token_urlsafe(20)},
        )
        await db.bookings.insert_one(b.to_mongo())

    # ----- Quotes: 1 draft, 1 pending_approval (big discount), 1 accepted -----
    def _quote(*, contact_id, discount_pct, note, status_override=None):
        # discount_pct is on the 0-100 percent scale (e.g. 25.0 = 25%).
        lines = [
            {"id": uuid.uuid4().hex[:8], "kind": "service", "ref_id": svc_water.id,
              "label": "Water heater install", "quantity": 1, "unit_price_cents": 120000,
              "discount_percent": discount_pct, "tax_rate": 8.0, "taxable": True,
              "discount_amount_cents": 0, "description": ""},
            {"id": uuid.uuid4().hex[:8], "kind": "custom",
              "label": "Old unit haul-away", "quantity": 1, "unit_price_cents": 8000,
              "discount_percent": 0.0, "tax_rate": 8.0, "taxable": True,
              "discount_amount_cents": 0, "description": "", "ref_id": None},
        ]
        from .bookings_seed_math import compute_totals_like_route  # noqa
        totals = compute_totals_like_route(lines, tax_rate=8.0)
        approval = "pending" if discount_pct >= 20.0 else "not_required"
        status = status_override or ("pending_approval" if discount_pct >= 20.0 else "draft")
        return Quote(org_id=org_id, number=f"Q-{now.year}-{uuid.uuid4().hex[:4]}",
                      contact_id=contact_id, author_user_id=owner_user_id,
                      status=status, approval_state=approval,
                      approval_reason=(f"Discount {int(round(discount_pct))}% ≥ threshold 20%"
                                        if approval == "pending" else None),
                      lines=[QuoteLine(**l) for l in lines],
                      tax_rate=8.0, global_discount_percent=0.0,
                      currency="USD", notes=note,
                      totals=QuoteTotals(**totals), version=1,
                      versions=[{"version": 1, "created_at": utc_now_iso(),
                                   "author_user_id": owner_user_id,
                                   "lines": lines, "totals": totals}],
                      portal_token=secrets.token_urlsafe(24))

    if contacts:
        q_draft = _quote(contact_id=str(contacts[0]["_id"]), discount_pct=5.0,
                          note="Standard water heater replacement.")
        q_pending = _quote(contact_id=str(contacts[1]["_id"]) if len(contacts) > 1 else None,
                            discount_pct=25.0, note="Long-time customer courtesy discount.")
        q_accepted = _quote(contact_id=str(contacts[2]["_id"]) if len(contacts) > 2 else None,
                             discount_pct=10.0, note="Deposit paid.", status_override="accepted")
        for q in (q_draft, q_pending, q_accepted):
            r = await db.quotes.insert_one(q.to_mongo())
            q.id = str(r.inserted_id)
        # Also mark the accepted one as accepted with meta
        await db.quotes.update_one({"_id": ObjectId(q_accepted.id)},
                                     {"$set": {"accepted_at": utc_now_iso(),
                                                 "accepted_meta": {"ip": "192.0.2.10"}}})

        # ----- Invoices: create 1 from q_accepted (send-status) + 1 paid + 1 overdue -----
        inv_lines = [InvoiceLine(id=uuid.uuid4().hex[:8], label=l.label, description=l.description,
                                     quantity=l.quantity, unit_price_cents=l.unit_price_cents,
                                     tax_rate=l.tax_rate, taxable=l.taxable) for l in q_accepted.lines]
        inv_from_q = Invoice(org_id=org_id, number=f"INV-{now.year}-{uuid.uuid4().hex[:4]}",
                              contact_id=q_accepted.contact_id, quote_id=q_accepted.id,
                              author_user_id=owner_user_id, status="sent",
                              lines=inv_lines, tax_rate=8.0,
                              subtotal_cents=q_accepted.totals.subtotal_cents,
                              tax_cents=q_accepted.totals.tax_cents,
                              total_cents=q_accepted.totals.total_cents,
                              currency="USD",
                              due_at=(now + timedelta(days=14)).isoformat().replace("+00:00", "Z"),
                              portal_token=secrets.token_urlsafe(24))
        await db.invoices.insert_one(inv_from_q.to_mongo())

        # Paid invoice
        inv_paid = Invoice(org_id=org_id, number=f"INV-{now.year}-{uuid.uuid4().hex[:4]}",
                            contact_id=str(contacts[0]["_id"]), author_user_id=owner_user_id,
                            status="paid",
                            lines=[InvoiceLine(id=uuid.uuid4().hex[:8], label="Drain unblock",
                                                 quantity=1, unit_price_cents=22000,
                                                 tax_rate=8.0, taxable=True)],
                            tax_rate=8.0, subtotal_cents=22000, tax_cents=1760,
                            total_cents=23760, amount_paid_cents=23760,
                            currency="USD",
                            due_at=(now - timedelta(days=1)).isoformat().replace("+00:00", "Z"),
                            portal_token=secrets.token_urlsafe(24))
        p_res = await db.invoices.insert_one(inv_paid.to_mongo())
        inv_paid.id = str(p_res.inserted_id)
        # Attach a simulated payment
        pay = Payment(org_id=org_id, invoice_id=inv_paid.id, amount_cents=23760,
                       currency="USD", method="simulated", provider="simulated",
                       provider_session_id="sim_seed_paid", status="paid")
        await db.payments.insert_one(pay.to_mongo())

        # Overdue invoice
        inv_overdue = Invoice(org_id=org_id, number=f"INV-{now.year}-{uuid.uuid4().hex[:4]}",
                               contact_id=str(contacts[3]["_id"]) if len(contacts) > 3 else str(contacts[0]["_id"]),
                               author_user_id=owner_user_id, status="overdue",
                               lines=[InvoiceLine(id=uuid.uuid4().hex[:8],
                                                    label="Emergency leak visit", quantity=1,
                                                    unit_price_cents=18000, tax_rate=8.0, taxable=True)],
                               tax_rate=8.0, subtotal_cents=18000, tax_cents=1440,
                               total_cents=19440, currency="USD",
                               due_at=(now - timedelta(days=20)).isoformat().replace("+00:00", "Z"),
                               portal_token=secrets.token_urlsafe(24))
        await db.invoices.insert_one(inv_overdue.to_mongo())

        # ----- Jobs: 1 completed with checklist, 1 in progress -----
        job_completed = Job(org_id=org_id, number=f"J-{now.year}-0001",
                             name="Water heater install — Sara K", contact_id=str(contacts[0]["_id"]),
                             quote_id=q_accepted.id, invoice_id=inv_from_q.id,
                             staff_id=staff1.id, status="completed",
                             started_at=(now - timedelta(days=1)).isoformat().replace("+00:00", "Z"),
                             completed_at=(now - timedelta(days=1, hours=-4)).isoformat().replace("+00:00", "Z"),
                             checklist=[
                                 ChecklistItem(id=uuid.uuid4().hex[:8], label="Confirmed model",
                                                done=True, done_at=utc_now_iso(),
                                                done_by_user_id=owner_user_id),
                                 ChecklistItem(id=uuid.uuid4().hex[:8], label="Installed new unit",
                                                done=True, done_at=utc_now_iso(),
                                                done_by_user_id=owner_user_id),
                                 ChecklistItem(id=uuid.uuid4().hex[:8], label="Hauled away old unit",
                                                done=True, done_at=utc_now_iso(),
                                                done_by_user_id=owner_user_id),
                             ])
        await db.jobs.insert_one(job_completed.to_mongo())
        job_progress = Job(org_id=org_id, number=f"J-{now.year}-0002",
                            name="Drain unblock — Priya M", contact_id=str(contacts[2]["_id"]),
                            staff_id=staff2.id, status="scheduled",
                            checklist=[
                                ChecklistItem(id=uuid.uuid4().hex[:8], label="Camera inspection"),
                                ChecklistItem(id=uuid.uuid4().hex[:8], label="Snake main line"),
                                ChecklistItem(id=uuid.uuid4().hex[:8], label="Test flow"),
                            ])
        await db.jobs.insert_one(job_progress.to_mongo())

    logger.info("Phase 4 demo seed complete: staff=2, services=3, bookings=3, quotes=3, invoices=3, jobs=2")
