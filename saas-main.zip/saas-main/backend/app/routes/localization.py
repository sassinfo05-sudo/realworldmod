"""Multi-language tenant output: owner language settings + LLM translation with cache."""
from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..services import llm

router = APIRouter(prefix="/localization", tags=["localization"])
public_router = APIRouter(prefix="/public/localization", tags=["localization-public"])

LANGUAGES = [
    {"code": "en", "name": "English"}, {"code": "es", "name": "Spanish"},
    {"code": "fr", "name": "French"}, {"code": "de", "name": "German"},
    {"code": "it", "name": "Italian"}, {"code": "pt", "name": "Portuguese"},
    {"code": "nl", "name": "Dutch"}, {"code": "ar", "name": "Arabic"},
    {"code": "hi", "name": "Hindi"}, {"code": "zh", "name": "Chinese (Simplified)"},
    {"code": "ja", "name": "Japanese"}, {"code": "ko", "name": "Korean"},
    {"code": "ru", "name": "Russian"}, {"code": "tr", "name": "Turkish"},
    {"code": "pl", "name": "Polish"}, {"code": "sv", "name": "Swedish"},
    {"code": "id", "name": "Indonesian"}, {"code": "vi", "name": "Vietnamese"},
    {"code": "th", "name": "Thai"}, {"code": "he", "name": "Hebrew"},
]
_LANG_NAME = {x["code"]: x["name"] for x in LANGUAGES}


def _settings_out(d: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    d = d or {}
    return {
        "enabled": bool(d.get("enabled", False)),
        "default_language": d.get("default_language", "en"),
        "languages": d.get("languages", ["en"]),
    }


@router.get("/languages")
async def list_languages(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"languages": LANGUAGES}


@router.get("/settings")
async def get_settings(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.org_localization.find_one({"org_id": org_id})
    return _settings_out(doc)


class SettingsIn(BaseModel):
    enabled: bool = False
    default_language: str = "en"
    languages: List[str] = Field(default_factory=lambda: ["en"])


@router.put("/settings")
async def put_settings(req: SettingsIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    valid = {x["code"] for x in LANGUAGES}
    langs = [c for c in req.languages if c in valid] or ["en"]
    if req.default_language not in valid:
        raise HTTPException(400, "Unknown default language")
    # Multi-language (more than the single default language) is a paid feature.
    if req.enabled and len([c for c in langs if c != req.default_language]) > 0:
        from ..services.entitlements import enforce_feature_enabled
        await enforce_feature_enabled(org_id, "multi_language")
    doc = {"org_id": org_id, "enabled": req.enabled, "default_language": req.default_language,
           "languages": langs, "updated_at": utc_now_iso()}
    await db.org_localization.update_one({"org_id": org_id}, {"$set": doc}, upsert=True)
    return _settings_out(doc)


class TranslateIn(BaseModel):
    texts: List[str] = Field(default_factory=list)
    target: str
    source: str = "en"


async def _translate(org_id: str, texts: List[str], target: str, source: str) -> List[str]:
    if target not in _LANG_NAME:
        raise HTTPException(400, "Unsupported target language")
    texts = [t for t in texts][:60]
    if not texts:
        return []
    if target == source:
        return list(texts)
    db = get_db()
    out: List[Optional[str]] = [None] * len(texts)
    missing: List[int] = []
    for i, t in enumerate(texts):
        key = hashlib.sha256(f"{target}|{t}".encode()).hexdigest()
        cached = await db.translation_cache.find_one({"org_id": org_id, "key": key})
        if cached:
            out[i] = cached["value"]
        else:
            missing.append(i)
    if missing:
        payload = {str(j): texts[j] for j in missing}
        system = (
            f"You are a professional localizer. Translate each value from {_LANG_NAME.get(source, source)} "
            f"into {_LANG_NAME[target]}. Keep meaning, tone and any placeholders like {{name}} intact. "
            "Return ONLY a JSON object with the SAME keys, values translated."
        )
        import json as _json
        try:
            from ..services.usage import set_context as _set_ctx
            _set_ctx(org_id=org_id, feature="localization/translate")
        except Exception:  # noqa: BLE001
            pass
        data = await llm.generate_json(system, _json.dumps(payload, ensure_ascii=False))
        now = utc_now_iso()
        for j in missing:
            val = data.get(str(j))
            if not isinstance(val, str) or not val:
                val = texts[j]
            out[j] = val
            key = hashlib.sha256(f"{target}|{texts[j]}".encode()).hexdigest()
            await db.translation_cache.update_one(
                {"org_id": org_id, "key": key},
                {"$set": {"org_id": org_id, "key": key, "target": target, "value": val, "created_at": now}},
                upsert=True,
            )
    return [o if o is not None else texts[i] for i, o in enumerate(out)]


@router.post("/translate")
async def translate(req: TranslateIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    out = await _translate(org_id, req.texts, req.target, req.source)
    return {"translations": out, "target": req.target}


# ============================ AUTHORED TRANSLATIONS (per-language overrides) ============================
# Owners can author EXACT translations for the visible copy on their published site. These override the
# machine translation (which the public language switcher otherwise generates) for the given language,
# keyed by the ORIGINAL (default-language) source string. Everything not authored still falls back to
# machine translation, so a partial glossary is fine.

_SKIP_STRING_KEYS = {
    "image", "background_image", "url", "href", "target", "social_image", "logo_svg",
    "website_slug", "page_slug", "id", "type", "variant", "icon", "video_url", "map_query",
    "provider", "color", "bg", "align", "layout",
}
_NUMERIC_RE = re.compile(r"^[\d\s.,:;$€£₪%()+\-]+$")


def _collect_strings(obj: Any, out: set, key: Optional[str] = None) -> None:
    if isinstance(obj, str):
        s = obj.strip()
        if (len(s) >= 2 and not s.lower().startswith(("http://", "https://", "data:", "#", "/", "mailto:", "tel:"))
                and not _NUMERIC_RE.match(s) and (key is None or key not in _SKIP_STRING_KEYS)):
            out.add(s)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            if k in _SKIP_STRING_KEYS:
                continue
            _collect_strings(v, out, k)
    elif isinstance(obj, list):
        for v in obj:
            _collect_strings(v, out, key)


async def _site_source_strings(org_id: str) -> List[str]:
    """Extract the visible copy from the tenant's active/published site so owners have a fill-in list."""
    from ..services.sites import active_website_doc
    doc = await active_website_doc(org_id)
    out: set = set()
    if doc:
        for p in (doc.get("published_pages") or doc.get("pages") or []):
            for b in (p.get("blocks") or []):
                _collect_strings(b.get("props", {}), out)
    return sorted(out, key=lambda s: s.lower())


def _clean_entries(entries: Dict[str, str], cap: int = 800) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for k, v in (entries or {}).items():
        ks, vs = (k or "").strip(), (v or "").strip()
        if ks and vs and ks != vs:
            out[ks[:400]] = vs[:800]
        if len(out) >= cap:
            break
    return out


@router.get("/overrides")
async def get_overrides(lang: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Owner: authored overrides for a language + the list of source strings on the live site."""
    if lang not in _LANG_NAME:
        raise HTTPException(400, "Unsupported language")
    db = get_db()
    doc = await db.org_translation_overrides.find_one({"org_id": org_id, "lang": lang})
    return {"lang": lang, "entries": (doc or {}).get("entries", {}), "sources": await _site_source_strings(org_id)}


class OverridesIn(BaseModel):
    lang: str
    entries: Dict[str, str] = Field(default_factory=dict)


@router.put("/overrides")
async def put_overrides(req: OverridesIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    if req.lang not in _LANG_NAME:
        raise HTTPException(400, "Unsupported language")
    db = get_db()
    entries = _clean_entries(req.entries)
    await db.org_translation_overrides.update_one(
        {"org_id": org_id, "lang": req.lang},
        {"$set": {"org_id": org_id, "lang": req.lang, "entries": entries, "updated_at": utc_now_iso()}},
        upsert=True)
    return {"lang": req.lang, "entries": entries, "count": len(entries)}


class AutoFillIn(BaseModel):
    lang: str
    sources: List[str] = Field(default_factory=list)


@router.post("/overrides/auto")
async def auto_fill_overrides(req: AutoFillIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Suggest machine translations for the source strings the owner has NOT authored yet (not saved)."""
    if req.lang not in _LANG_NAME:
        raise HTTPException(400, "Unsupported language")
    db = get_db()
    doc = await db.org_translation_overrides.find_one({"org_id": org_id, "lang": req.lang})
    existing = (doc or {}).get("entries", {})
    sources = req.sources or await _site_source_strings(org_id)
    todo = [s for s in sources if s and s not in existing][:60]
    translated = await _translate(org_id, todo, req.lang, "en") if todo else []
    return {"suggestions": dict(zip(todo, translated)), "lang": req.lang}


@public_router.get("/{org_id}/overrides")
async def public_overrides(org_id: str, lang: str):
    """Public: authored overrides for a language (only when localization is enabled for it)."""
    st = _settings_out(await get_db().org_localization.find_one({"org_id": org_id}))
    if not st["enabled"] or (lang not in set(st["languages"]) | {st["default_language"]}):
        return {"lang": lang, "entries": {}}
    doc = await get_db().org_translation_overrides.find_one({"org_id": org_id, "lang": lang})
    return {"lang": lang, "entries": (doc or {}).get("entries", {})}


@public_router.get("/{org_id}/settings")
async def public_settings(org_id: str):
    """Public: which languages a storefront/site offers (only when the owner enabled it)."""
    doc = await get_db().org_localization.find_one({"org_id": org_id})
    st = _settings_out(doc)
    if not st["enabled"]:
        return {"enabled": False, "default_language": st["default_language"], "languages": []}
    langs = [x for x in LANGUAGES if x["code"] in set(st["languages"]) | {st["default_language"]}]
    return {"enabled": True, "default_language": st["default_language"], "languages": langs,
            "rtl": ["he", "ar"]}


@public_router.post("/{org_id}/translate")
async def public_translate(org_id: str, req: TranslateIn, request: Request):
    """Visitor-triggered translation: rate-limited per IP, metered against the TENANT's budget
    (flagged public so caps apply), and only for orgs that enabled public translation."""
    from ..services import rate_limit as rl
    from ..services.usage import set_context, enforce_budget
    rl.check("public_translate", request, limit=30, window_seconds=60)
    if len(req.texts) > 60 or sum(len(t or "") for t in req.texts) > 8000:
        raise HTTPException(413, "Too much text in one request")
    st = _settings_out(await get_db().org_localization.find_one({"org_id": org_id}))
    if not st["enabled"] or (req.target not in set(st["languages"]) | {st["default_language"]}):
        raise HTTPException(403, "Translation is not enabled for this language on this site")
    set_context(org_id=org_id, feature="public_translate", public=True)
    try:
        await enforce_budget(org_id, feature="public_translate", public=True)
    except HTTPException:
        return {"translations": list(req.texts), "target": req.target, "over_limit": True}
    out = await _translate(org_id, req.texts, req.target, req.source)
    return {"translations": out, "target": req.target}
