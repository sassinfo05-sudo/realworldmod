# Zanelvo — OWNER LAUNCH RUNBOOK (Round 15)

_This runbook is the owner's pre-GA checklist. Zanelvo currently reports **PRODUCTION_GATE:
FAIL** — do not launch to real paying customers until the P0 items in `CURRENT_STATUS.md`
§"RESIDUAL P0/P1 BACKLOG" are closed and a full fresh production-mode regression passes._

## 0. Production environment variables (backend/.env)
Set these before deploying with `APP_ENV=production`. Startup FAILS FAST if prod config is
incomplete (`server.py::_validate_production_config`).
```
APP_ENV=production
MONGO_URL=<managed MongoDB connection string>
DB_NAME=<prod db name>
JWT_SECRET=<48+ char random secret>           # rotate = invalidates all sessions
JWT_ALG=HS256
SECRETS_ENC_KEY=<32+ char random>             # encrypts stored provider secrets
CORS_ORIGINS=https://app.zanelvo.com,https://zanelvo.com   # explicit, NEVER "*"
EMERGENT_LLM_KEY=<platform LLM key>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
# SEED_DEMO_DATA must be UNSET or false in production (demo seeding is refused in prod).
```
Frontend build: `yarn install --frozen-lockfile && GENERATE_SOURCEMAP=false INLINE_RUNTIME_CHUNK=false yarn build`
then serve `/app/frontend/build` behind your CDN/static host.

## 1. Security posture already enforced (verified)
- Auth uses HttpOnly `zv_access` + readable `zv_csrf` (CSRF double-submit); no raw JWT in JS storage.
- CORS fails closed in production (explicit allow-list only).
- Staff + owner MFA FAIL CLOSED in production — if the MFA provider is down, no session is issued.
- Demo seeding refused in production.
- Simulated domain provider can never reach "Connected" in production.
- Atomic AI + variable-provider spend caps (per-plan, DB-editable) — see `PRODUCTION_COST_MODEL.md`.
- Stored HTML/SVG sanitized server-side (strict allowlist).

## 2. First-login / password reset (never in chat/commit)
- Owner: `/login`. Founder/staff: `/staff/login` (MFA required in prod → connect a platform
  email provider FIRST via Staff Setup, else staff cannot sign in — by design, fail-closed).
- Reset: `POST /api/auth/password-reset/request` emails a token via the configured sender.
- Rotate the seeded demo passwords / disable demo accounts before GA.

## 3. Connect providers (Staff Setup Center — encrypted; never paste live keys in chat)
Each provider stays honestly **Not connected / Sandbox** until real credentials + a sandbox
probe pass. Owner actions still OUTSTANDING before those features may be advertised as live:
- **Payments**: Stripe Connect (platform account) — recurring billing stays "unavailable"
  until real Stripe Billing passes a sandbox flow. PayPal stays off until a signed sandbox flow.
- **Email**: Resend/SendGrid/SMTP + zanelvo.com SPF/DKIM/MX (separate platform vs tenant domains).
- **Voice/SMS**: Telnyx/Twilio + A2P 10DLC; bind numbers so voice webhooks resolve the tenant
  from the dialed number.
- **Custom domains**: Cloudflare for SaaS (`CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_SAAS_ZONE_ID`).
- **Ads**: Google/Meta OAuth. **Shipping**: Shippo/EasyPost.

## 4. Data, backups & rollback (OUTSTANDING — set up before GA)
- Managed MongoDB with automated daily backups + a tested restore.
- Object storage for uploads with lifecycle + backup.
- A dedicated worker + durable queue for recurring jobs (currently still in the web-startup
  loop — a P0 to move out before scaling horizontally).
- Health check: `GET /api/health`. Rollback: redeploy the previous release commit + restore DB
  snapshot if a migration ran.

## 5. Legal (owner gate — DO NOT auto-launch)
Generated Terms/Privacy are drafts. Have counsel review before enabling public sign-ups; ensure
the privacy policy matches real auth/analytics/subprocessors/retention.

## 6. Deterministic verification you can re-run any time
```
cd /app/backend && python tests/test_atomic_metering.py    # spend caps can't be exceeded
cd /app/backend && python tests/test_xss_sanitizer.py       # stored-XSS neutralized
```

## Round 15 pass 4 — owner actions added
1. **Founder account (production)**: `cd backend && python -m scripts.bootstrap_founder --public-url https://<your-host>`
   → open the printed single-use `/staff/set-password?token=…` link within 48 h. Never set a password via env.
2. **Stripe Connect**: in the *platform* Stripe dashboard go to *Connect → Get started* and complete the
   platform profile. Then Staff → Payments → *Run probe* must show `Connect: Enabled`. Only after that can
   tenants use *Settings → Payments → Connect with Stripe*. Run one Express onboarding + one sandbox charge
   before flipping the platform key to live.
3. **Staff invitations**: create members WITHOUT a password → they receive a set-password link (requires a
   platform email provider; in dev the link is shown in the dialog).
4. **Cloudflare for SaaS**: Staff → Setup Center → Domains → token + zone id → *Run probe*
   (`/api/founder/integrations/probe/cloudflare`) must be `connected` before offering custom domains.
5. **Legal review**: have counsel review Terms/Privacy, then `PUT /api/founder/launch-gate {"legal_reviewed": true}`
   — this removes the public "not yet confirmed by legal review" notice.
