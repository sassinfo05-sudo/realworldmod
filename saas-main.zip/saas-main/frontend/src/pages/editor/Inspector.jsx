import { useState } from "react";
import { useEditor } from "./EditorProvider";
import MediaPicker from "./MediaPicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Trash2, Copy, Palette, Type, Sparkles, Loader2, Bookmark } from "lucide-react";
import { toast } from "sonner";

const VARIANTS = {
    hero: [{ v: "a", label: "Split" }, { v: "b", label: "Dark + stats" }, { v: "c", label: "Editorial" }],
    services_grid: [{ v: "a", label: "3-column" }, { v: "b", label: "2-col chips" }, { v: "c", label: "Dense list" }],
    about_split: [{ v: "a", label: "Image left" }],
    testimonials: [{ v: "a", label: "3 cards" }],
    cta_band: [{ v: "a", label: "Dark band" }],
    contact_hours: [{ v: "a", label: "Standard" }],
    footer: [{ v: "a", label: "Simple" }],
};

const SKIP_KEYS = new Set(["image", "background_image", "primary_cta", "secondary_cta", "fields"]);

/** Generic content editor: strings/numbers/booleans + arrays of flat objects (add/remove). */
function GenericProps({ block, onChange }) {
    const p = block.props || {};
    const entries = Object.entries(p).filter(([k]) => !SKIP_KEYS.has(k));
    if (!entries.length) return null;
    const labelOf = (k) => k.replace(/_/g, " ");
    return (
        <div className="space-y-3 pt-3 border-t border-brand-line" data-testid="inspector-generic">
            <div className="text-[10px] uppercase tracking-widest text-zinc-500">Content</div>
            {entries.map(([k, v]) => {
                if (typeof v === "boolean") return (
                    <label key={k} className="flex items-center justify-between text-sm"><span className="capitalize">{labelOf(k)}</span>
                        <input type="checkbox" checked={v} onChange={(e) => onChange(k, e.target.checked)} /></label>);
                if (typeof v === "number") return (
                    <div key={k}><Label className="text-xs capitalize">{labelOf(k)}</Label>
                        <Input type="number" defaultValue={v} onBlur={(e) => onChange(k, Number(e.target.value))} className="mt-1" /></div>);
                if (typeof v === "string") return (
                    <div key={k}><Label className="text-xs capitalize">{labelOf(k)}</Label>
                        {v.length > 60 || k === "body" || k === "answer" ? (
                            <textarea defaultValue={v} rows={3} onBlur={(e) => e.target.value !== v && onChange(k, e.target.value)}
                                className="mt-1 w-full text-sm rounded-md border border-brand-line px-3 py-2" />
                        ) : (
                            <Input defaultValue={v} onBlur={(e) => e.target.value !== v && onChange(k, e.target.value)} className="mt-1" data-testid={`inspector-prop-${k}`} />
                        )}</div>);
                if (Array.isArray(v) && (v.length === 0 || (typeof v[0] === "object" && v[0]))) {
                    const template = v[0] ? Object.fromEntries(Object.keys(v[0]).map((kk) => [kk, typeof v[0][kk] === "boolean" ? false : ""])) : { title: "", description: "" };
                    return (
                        <div key={k} className="space-y-2">
                            <div className="flex items-center justify-between"><Label className="text-xs capitalize">{labelOf(k)} ({v.length})</Label>
                                <button type="button" className="text-xs text-brand-copper" onClick={() => onChange(k, [...v, { ...template }])} data-testid={`inspector-add-${k}`}>+ Add</button></div>
                            {v.map((item, i) => (
                                <div key={i} className="rounded-md border border-brand-line p-2 space-y-1.5 bg-zinc-50/60">
                                    {Object.entries(item).map(([ik, iv]) => (
                                        typeof iv === "boolean" ? (
                                            <label key={ik} className="flex items-center justify-between text-xs"><span className="capitalize">{labelOf(ik)}</span>
                                                <input type="checkbox" checked={iv} onChange={(e) => { const n = v.map((x, j) => j === i ? { ...x, [ik]: e.target.checked } : x); onChange(k, n); }} /></label>
                                        ) : (
                                            <input key={ik} defaultValue={iv ?? ""} placeholder={labelOf(ik)}
                                                onBlur={(e) => { if (e.target.value === (iv ?? "")) return; const n = v.map((x, j) => j === i ? { ...x, [ik]: e.target.value } : x); onChange(k, n); }}
                                                className="w-full text-xs rounded border border-brand-line px-2 py-1 bg-white" />
                                        )))}
                                    <button type="button" className="text-[11px] text-red-600" onClick={() => onChange(k, v.filter((_, j) => j !== i))}>Remove</button>
                                </div>
                            ))}
                        </div>);
                }
                return null;
            })}
        </div>
    );
}

function BlockInspector() {
    const { selectedBlock, setBlockVariant, updateBlockProp, duplicateBlock, removeBlock, regenerateBlock, saveBlockAsSection } = useEditor();
    const [regenBusy, setRegenBusy] = useState(false);
    const [regenNote, setRegenNote] = useState("");
    const [saveBusy, setSaveBusy] = useState(false);
    const doSaveSection = async () => {
        if (!selectedBlock || saveBusy) return;
        const name = window.prompt("Name this reusable section", `${selectedBlock.type.replace("_", " ")} — saved`);
        if (!name || !name.trim()) return;
        setSaveBusy(true);
        try {
            await saveBlockAsSection(selectedBlock.id, name.trim().slice(0, 80));
            toast.success("Saved. Find it under Add section → Saved sections");
        } catch (e) {
            const d = e?.response?.data?.detail;
            toast.error(typeof d === "string" ? d : "Could not save this section");
        } finally { setSaveBusy(false); }
    };
    const doRegenerate = async () => {
        if (!selectedBlock || regenBusy) return;
        setRegenBusy(true);
        try {
            await regenerateBlock(selectedBlock.id, regenNote.trim() || undefined);
            toast.success("Section copy regenerated");
            setRegenNote("");
        } catch (e) {
            const d = e?.response?.data?.detail;
            toast.error(typeof d === "string" ? d : (d?.message || "Could not regenerate this section"));
        } finally { setRegenBusy(false); }
    };
    if (!selectedBlock) return null;
    const variants = VARIANTS[selectedBlock.type] || [];
    const p = selectedBlock.props || {};
    return (
        <div className="p-4 space-y-5" data-testid="inspector-block">
            <div>
                <div className="text-[10px] uppercase tracking-widest text-zinc-500">Section</div>
                <div className="font-medium capitalize">{selectedBlock.type.replace("_", " ")}</div>
            </div>
            {variants.length > 1 && (
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Variant</Label>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                        {variants.map((v) => (
                            <button
                                key={v.v}
                                onClick={() => setBlockVariant(selectedBlock.id, v.v)}
                                className={`text-xs px-2 py-2 rounded-md border transition-colors ${
                                    selectedBlock.variant === v.v
                                        ? "border-brand-copper bg-brand-cream text-brand-ink"
                                        : "border-brand-line bg-white text-zinc-600 hover:border-zinc-300"
                                }`}
                                data-testid={`variant-${v.v}`}
                            >
                                {v.label}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {/* Image */}
            {"image" in p && (
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Image</Label>
                    <div className="mt-1">
                        <MediaPicker
                            value={p.image || ""}
                            onChange={(url) => updateBlockProp(selectedBlock.id, "image", url)}
                            testid="inspector-image" />
                    </div>
                    {p.image && (
                        <div className="mt-2 rounded-md overflow-hidden border border-brand-line bg-zinc-50">
                            <img src={p.image} alt={p.image_alt || "preview"} className="w-full h-32 object-cover" />
                        </div>
                    )}
                    <Label className="mt-2 block text-xs uppercase tracking-widest text-zinc-500">Image alt text</Label>
                    <Input
                        defaultValue={p.image_alt || ""}
                        onBlur={(e) => e.target.value !== (p.image_alt || "") && updateBlockProp(selectedBlock.id, "image_alt", e.target.value)}
                        placeholder="Describe the image for accessibility and SEO"
                        className="mt-1 text-sm"
                        data-testid="inspector-image-alt"
                    />
                </div>
            )}
            {"background_image" in p && (
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Background image</Label>
                    <div className="mt-1">
                        <MediaPicker
                            value={p.background_image || ""}
                            onChange={(url) => updateBlockProp(selectedBlock.id, "background_image", url)}
                            testid="inspector-bg-image" />
                    </div>
                </div>
            )}
            {/* CTA targets */}
            {p.primary_cta && (
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Primary CTA link</Label>
                    <Input
                        defaultValue={p.primary_cta.href || ""}
                        onBlur={(e) => e.target.value !== p.primary_cta.href &&
                            updateBlockProp(selectedBlock.id, "primary_cta.href", e.target.value)}
                        placeholder="/contact"
                        className="mt-1"
                        data-testid="inspector-primary-cta-href"
                    />
                </div>
            )}
            {p.secondary_cta && (
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Secondary CTA link</Label>
                    <Input
                        defaultValue={p.secondary_cta.href || ""}
                        onBlur={(e) => e.target.value !== p.secondary_cta.href &&
                            updateBlockProp(selectedBlock.id, "secondary_cta.href", e.target.value)}
                        className="mt-1"
                    />
                </div>
            )}
            <GenericProps block={selectedBlock} onChange={(k, v) => updateBlockProp(selectedBlock.id, k, v)} />
            {selectedBlock.type !== "footer" && selectedBlock.type !== "store" && selectedBlock.type !== "booking" && (
                <div className="pt-3 border-t border-brand-line space-y-2" data-testid="inspector-regenerate-panel">
                    <Label className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5" /> Regenerate copy with AI</Label>
                    <Input value={regenNote} onChange={(e) => setRegenNote(e.target.value)} placeholder="Optional: e.g. shorter, warmer, mention weekend service"
                        className="text-sm" data-testid="inspector-regenerate-note" />
                    <Button size="sm" variant="outline" onClick={doRegenerate} disabled={regenBusy} className="w-full" data-testid="inspector-regenerate">
                        {regenBusy ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> Rewriting…</> : <><Sparkles className="w-3.5 h-3.5 mr-1.5" /> Regenerate this section</>}
                    </Button>
                    <p className="text-[11px] text-zinc-500">Rewrites text only (images, links and form fields are kept). Uses your plan's AI budget.</p>
                </div>
            )}
            <div className="pt-3 border-t border-brand-line flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={() => duplicateBlock(selectedBlock.id)} data-testid="inspector-duplicate">
                    <Copy className="w-3.5 h-3.5 mr-1.5" /> Duplicate
                </Button>
                <Button variant="outline" size="sm" onClick={doSaveSection} disabled={saveBusy} data-testid="inspector-save-section">
                    {saveBusy ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Bookmark className="w-3.5 h-3.5 mr-1.5" />} Save as reusable
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700" onClick={() => removeBlock(selectedBlock.id)} data-testid="inspector-delete">
                    <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Delete
                </Button>
            </div>
        </div>
    );
}

function GlobalStyles() {
    const { draft, patchTheme } = useEditor();
    if (!draft) return null;
    const t = draft.theme || {};
    return (
        <div className="p-4 space-y-4" data-testid="inspector-global">
            <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-brand-copper" />
                <div className="font-medium">Global style</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Primary</Label>
                    <div className="mt-1 flex items-center gap-2">
                        <input type="color" value={t.primary || "#C85A17"}
                               onChange={(e) => patchTheme({ primary: e.target.value })}
                               className="w-9 h-9 rounded-md border border-brand-line cursor-pointer"
                               data-testid="theme-primary-color" />
                        <Input defaultValue={t.primary}
                               onBlur={(e) => e.target.value !== t.primary && patchTheme({ primary: e.target.value })}
                               className="font-mono text-xs" />
                    </div>
                </div>
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Secondary</Label>
                    <div className="mt-1 flex items-center gap-2">
                        <input type="color" value={t.secondary || "#18181B"}
                               onChange={(e) => patchTheme({ secondary: e.target.value })}
                               className="w-9 h-9 rounded-md border border-brand-line cursor-pointer" />
                        <Input defaultValue={t.secondary}
                               onBlur={(e) => e.target.value !== t.secondary && patchTheme({ secondary: e.target.value })}
                               className="font-mono text-xs" />
                    </div>
                </div>
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Background</Label>
                    <div className="mt-1 flex items-center gap-2">
                        <input type="color" value={t.background || "#FAFAFA"}
                               onChange={(e) => patchTheme({ background: e.target.value })}
                               className="w-9 h-9 rounded-md border border-brand-line cursor-pointer" />
                        <Input defaultValue={t.background}
                               onBlur={(e) => e.target.value !== t.background && patchTheme({ background: e.target.value })}
                               className="font-mono text-xs" />
                    </div>
                </div>
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Accent</Label>
                    <div className="mt-1 flex items-center gap-2">
                        <input type="color" value={t.accent || "#2563EB"}
                               onChange={(e) => patchTheme({ accent: e.target.value })}
                               className="w-9 h-9 rounded-md border border-brand-line cursor-pointer" />
                        <Input defaultValue={t.accent}
                               onBlur={(e) => e.target.value !== t.accent && patchTheme({ accent: e.target.value })}
                               className="font-mono text-xs" />
                    </div>
                </div>
            </div>
            <div className="grid grid-cols-1 gap-3">
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500 flex items-center gap-1">
                        <Type className="w-3 h-3" /> Heading font
                    </Label>
                    <Input defaultValue={t.font_heading || "Fraunces, serif"}
                           onBlur={(e) => e.target.value !== t.font_heading && patchTheme({ font_heading: e.target.value })}
                           className="mt-1 font-mono text-xs" />
                </div>
                <div>
                    <Label className="text-xs uppercase tracking-widest text-zinc-500">Body font</Label>
                    <Input defaultValue={t.font_body || "DM Sans, sans-serif"}
                           onBlur={(e) => e.target.value !== t.font_body && patchTheme({ font_body: e.target.value })}
                           className="mt-1 font-mono text-xs" />
                </div>
            </div>
        </div>
    );
}

function PageSeoPanel() {
    const { currentPage, renamePage } = useEditor();
    if (!currentPage) return null;
    const seo = currentPage.seo || {};
    return (
        <div className="p-4 space-y-4" data-testid="inspector-page-seo">
            <div className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-brand-copper" /><div className="font-medium">Page settings</div></div>
            <div>
                <Label className="text-xs uppercase tracking-widest text-zinc-500">Page title</Label>
                <Input defaultValue={currentPage.title}
                       onBlur={(e) => e.target.value !== currentPage.title && renamePage(currentPage.slug, { title: e.target.value })}
                       className="mt-1" data-testid="page-title-input" />
            </div>
            <div>
                <Label className="text-xs uppercase tracking-widest text-zinc-500">URL slug</Label>
                <Input defaultValue={currentPage.slug}
                       onBlur={(e) => e.target.value !== currentPage.slug && renamePage(currentPage.slug, { slug: e.target.value })}
                       className="mt-1 font-mono text-xs" data-testid="page-slug-input" />
            </div>
            <div>
                <Label className="text-xs uppercase tracking-widest text-zinc-500">SEO title</Label>
                <Input defaultValue={seo.title || ""}
                       onBlur={(e) => e.target.value !== seo.title && renamePage(currentPage.slug, { seo: { title: e.target.value } })}
                       className="mt-1" />
            </div>
            <div>
                <Label className="text-xs uppercase tracking-widest text-zinc-500">SEO description</Label>
                <Textarea rows={3} defaultValue={seo.description || ""}
                          onBlur={(e) => e.target.value !== seo.description && renamePage(currentPage.slug, { seo: { description: e.target.value } })}
                          className="mt-1" />
            </div>
            <div>
                <Label className="text-xs uppercase tracking-widest text-zinc-500">Social preview image URL</Label>
                <Input defaultValue={seo.social_image || ""}
                       onBlur={(e) => e.target.value !== seo.social_image && renamePage(currentPage.slug, { seo: { social_image: e.target.value } })}
                       className="mt-1" />
            </div>
            <div>
                <Label className="text-xs uppercase tracking-widest text-zinc-500">Password protect (optional)</Label>
                <Input defaultValue={seo.password || ""}
                       onBlur={(e) => e.target.value !== seo.password && renamePage(currentPage.slug, { seo: { password: e.target.value } })}
                       placeholder="Leave blank for public" className="mt-1 font-mono text-xs" />
            </div>
        </div>
    );
}

export default function Inspector() {
    const { selectedBlock } = useEditor();
    return (
        <aside className="w-80 border-l border-brand-line bg-white overflow-y-auto" data-testid="editor-inspector">
            {selectedBlock ? <BlockInspector /> : (
                <div className="divide-y divide-brand-line">
                    <PageSeoPanel />
                    <GlobalStyles />
                </div>
            )}
        </aside>
    );
}
