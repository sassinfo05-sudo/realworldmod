"""HttpOnly session cookies + CSRF double-submit (Round 10, Gate 1B-cookie).

Dual-mode auth:
  * `Authorization: Bearer <jwt>` keeps working (API clients, tests, impersonation tokens).
  * Browsers get the SAME jwt in an HttpOnly cookie (`zv_access`) at login/signup/2FA-verify/
    staff login/OAuth exchange, plus a readable CSRF cookie (`zv_csrf`). When a request authenticates
    via the cookie (no bearer header) and is state-changing (POST/PUT/PATCH/DELETE), the client must
    echo the CSRF cookie in `X-CSRF-Token`; otherwise 403 `csrf_failed`.

The token is therefore no longer required in JS-accessible storage; the frontend keeps only a
non-secret "session marker" + profile in localStorage.
"""
from __future__ import annotations

import hmac
import secrets

from fastapi import HTTPException, Request, Response

from .. import config

ACCESS_COOKIE = "zv_access"
CSRF_COOKIE = "zv_csrf"
CSRF_HEADER = "x-csrf-token"
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}

# POST endpoints whose 200 JSON body carries `access_token` → we mirror it into cookies.
TOKEN_ISSUING_PATHS = {
    "/api/auth/login", "/api/auth/signup", "/api/auth/2fa/verify",
    "/api/staff/auth/login", "/api/staff/auth/2fa/verify",
    "/api/auth/oauth/session-exchange", "/api/auth/set-password", "/api/auth/password-reset/confirm",
}


def _secure(request: Request) -> bool:
    proto = (request.headers.get("x-forwarded-proto") or request.url.scheme or "").lower()
    return proto == "https" or config.is_production()


def set_session_cookies(response: Response, token: str, request: Request) -> None:
    # Cookie lifetime follows the token's own exp so "remember me" (a longer-lived token) is honoured
    # automatically, and normal sessions keep the default TTL.
    ttl = int(getattr(config, "JWT_ACCESS_TTL_MIN", 1440) or 1440) * 60
    try:
        import jwt as _jwt
        exp = int(_jwt.decode(token, options={"verify_signature": False}).get("exp") or 0)
        import time as _t
        remaining = exp - int(_t.time())
        if remaining > 60:
            ttl = remaining
    except Exception:  # noqa: BLE001
        pass
    sec = _secure(request)
    response.set_cookie(ACCESS_COOKIE, token, max_age=ttl, httponly=True, secure=sec,
                        samesite="lax", path="/")
    response.set_cookie(CSRF_COOKIE, secrets.token_urlsafe(24), max_age=ttl, httponly=False,
                        secure=sec, samesite="lax", path="/")


def clear_session_cookies(response: Response) -> None:
    response.delete_cookie(ACCESS_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")


def token_from_cookie(request: Request) -> str:
    """Return the jwt from the HttpOnly cookie after CSRF double-submit validation."""
    tok = request.cookies.get(ACCESS_COOKIE) or ""
    if not tok:
        return ""
    if request.method.upper() not in SAFE_METHODS:
        want = request.cookies.get(CSRF_COOKIE) or ""
        got = request.headers.get(CSRF_HEADER) or ""
        if not want or not got or not hmac.compare_digest(want, got):
            raise HTTPException(status_code=403, detail={"code": "csrf_failed",
                                                         "message": "Missing or invalid CSRF token"})
    return tok
