import { useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import api from "@/lib/api";

/**
 * Public renderer for dynamic CMS pages served under /site/{slug}/{routeBase}[/{itemSlug}].
 * Data comes from the safe public endpoints (/api/public/cms/*), which already strip private
 * fields, drafts and archived items. This is a generic, theme-light renderer that shows the
 * bound field values; the block-level visual layout is authored in the editor.
 */
function fieldEntries(values) {
    return Object.entries(values || {}).filter(([, v]) => v !== null && v !== "" && v !== undefined);
}

function renderVal(v) {
    if (Array.isArray(v)) return v.join(", ");
    if (typeof v === "string" && /^https?:\/\/\S+\.(png|jpe?g|webp|gif|svg)(\?|$)/i.test(v)) {
        return <img src={v} alt="" className="rounded-lg max-h-64 object-cover" />;
    }
    if (typeof v === "string" && /<[a-z][\s\S]*>/i.test(v)) {
        // rich_text is server-sanitised; safe to render.
        return <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: v }} />;
    }
    return <span>{String(v)}</span>;
}

export default function DynamicCollectionPage({ mode = "detail" }) {
    const { slug, routeBase: rbParam, itemSlug, pageSlug } = useParams();
    const routeBase = rbParam || pageSlug;
    const [sp] = useSearchParams();
    const [state, setState] = useState({ loading: true });
    const [q, setQ] = useState(sp.get("q") || "");

    useEffect(() => {
        let cancel = false;
        (async () => {
            setState({ loading: true });
            try {
                if (mode === "detail") {
                    const { data } = await api.get(`/public/cms/${slug}/${routeBase}/${itemSlug}`);
                    if (!cancel) {
                        setState({ loading: false, detail: data });
                        if (data?.seo?.title) document.title = data.seo.title;
                    }
                } else {
                    const { data } = await api.get(`/public/cms/${slug}/${routeBase}`, { params: { q: q || undefined } });
                    if (!cancel) setState({ loading: false, list: data });
                }
            } catch (e) {
                if (!cancel) setState({ loading: false, error: e?.response?.status === 404 ? "notfound" : "error" });
            }
        })();
        return () => { cancel = true; };
    }, [slug, routeBase, itemSlug, mode, q]);

    if (state.loading) return <div className="min-h-screen flex items-center justify-center text-zinc-400">Loading…</div>;
    if (state.error === "notfound") return (
        <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
            <div className="text-xs uppercase tracking-[0.28em] text-zinc-400 mb-2">404</div>
            <h1 className="text-2xl font-semibold">Not found</h1>
            <Link to={`/site/${slug}`} className="text-brand-copper mt-3 text-sm">Back to site</Link>
        </div>
    );
    if (state.error) return <div className="min-h-screen flex items-center justify-center text-zinc-500">Couldn't load this page.</div>;

    // ---- Detail ----
    if (mode === "detail") {
        const item = state.detail?.item;
        const values = item?.values || {};
        const entries = fieldEntries(values);
        const title = entries[0]?.[1];
        return (
            <div className="min-h-screen bg-white text-zinc-900">
                <div className="max-w-3xl mx-auto px-6 py-14">
                    <Link to={`/site/${slug}/${routeBase}`} className="text-sm text-brand-copper">← All {routeBase}</Link>
                    <h1 className="text-3xl font-semibold mt-4 mb-6" data-testid="dynamic-detail-title">{typeof title === "string" ? title : routeBase}</h1>
                    <div className="space-y-5">
                        {entries.slice(1).map(([k, v]) => (
                            <div key={k}>
                                <div className="text-xs uppercase tracking-wide text-zinc-400 mb-1">{k.replace(/_/g, " ")}</div>
                                <div className="text-[15px]">{renderVal(v)}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    // ---- List / directory ----
    const list = state.list || { items: [] };
    return (
        <div className="min-h-screen bg-white text-zinc-900">
            <div className="max-w-5xl mx-auto px-6 py-14">
                <div className="flex items-center justify-between flex-wrap gap-3 mb-8">
                    <h1 className="text-3xl font-semibold capitalize" data-testid="dynamic-list-title">{routeBase}</h1>
                    <input
                        className="border rounded-lg px-3 py-2 text-sm w-full sm:w-64"
                        placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} data-testid="dynamic-list-search"
                    />
                </div>
                {list.items.length === 0 ? (
                    <p className="text-zinc-500">Nothing here yet.</p>
                ) : (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                        {list.items.map((it) => {
                            const entries = fieldEntries(it.values);
                            const title = entries[0]?.[1];
                            const img = Object.values(it.values || {}).find((v) => typeof v === "string" && /^https?:\/\/\S+\.(png|jpe?g|webp|gif)/i.test(v));
                            return (
                                <Link key={it.id} to={`/site/${slug}/${routeBase}/${it.slug}`}
                                      className="block rounded-xl border border-zinc-200 hover:shadow-lg transition-shadow overflow-hidden"
                                      data-testid={`dynamic-list-item-${it.slug}`}>
                                    {img && <img src={img} alt="" className="w-full h-40 object-cover" />}
                                    <div className="p-4">
                                        <div className="font-medium">{typeof title === "string" ? title : it.slug}</div>
                                        {entries[1] && <div className="text-sm text-zinc-500 mt-1 line-clamp-2">{String(entries[1][1]).replace(/<[^>]*>/g, "")}</div>}
                                    </div>
                                </Link>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
}
