import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, GripVertical } from "lucide-react";
import { FIELD_TYPES, OPTION_TYPES } from "@/lib/cms";
import AssetPicker from "@/components/AssetPicker";

/** Media field backed by the unified Asset Library picker. Stores the asset's permanent URL. */
function MediaField({ value, onChange }) {
    const [open, setOpen] = useState(false);
    return (
        <div className="flex items-center gap-2">
            {value ? <img src={value} alt="" className="w-12 h-12 rounded object-cover border" /> : null}
            <Button type="button" variant="outline" size="sm" onClick={() => setOpen(true)} data-testid="pick-media-btn">
                {value ? "Change" : "Choose from library"}
            </Button>
            {value ? <Button type="button" variant="ghost" size="sm" onClick={() => onChange("")}>Clear</Button> : null}
            <AssetPicker open={open} onOpenChange={setOpen} category="cms"
                         onSelect={(a) => onChange(a?.url || "")} />
        </div>
    );
}

const NEW_FIELD = () => ({
    label: "", type: "short_text", required: false, unique: false,
    searchable: false, private: false, options: [],
});

/** Visual builder for a collection's field schema. `value` is an array of field defs. */
export default function FieldsEditor({ value, onChange }) {
    const fields = value || [];

    const patch = (idx, upd) => onChange(fields.map((f, i) => (i === idx ? { ...f, ...upd } : f)));
    const add = () => onChange([...fields, NEW_FIELD()]);
    const remove = (idx) => onChange(fields.filter((_, i) => i !== idx));

    return (
        <div className="space-y-3" data-testid="fields-editor">
            {fields.map((f, idx) => (
                <div key={idx} className="rounded-lg border border-zinc-200 dark:border-zinc-700 p-3 space-y-2 bg-white/50 dark:bg-zinc-900/40">
                    <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-zinc-400 shrink-0" />
                        <Input
                            data-testid={`field-label-${idx}`}
                            placeholder="Field label (e.g. Full name)"
                            value={f.label}
                            onChange={(e) => patch(idx, { label: e.target.value })}
                            className="flex-1"
                        />
                        <Select value={f.type} onValueChange={(v) => patch(idx, { type: v })}>
                            <SelectTrigger className="w-44" data-testid={`field-type-${idx}`}><SelectValue /></SelectTrigger>
                            <SelectContent>
                                {FIELD_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                            </SelectContent>
                        </Select>
                        <Button type="button" variant="ghost" size="icon" onClick={() => remove(idx)} title="Remove field"
                                data-testid={`field-remove-${idx}`}>
                            <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                    </div>
                    {OPTION_TYPES.includes(f.type) && (
                        <div>
                            <Label className="text-xs text-zinc-500">Options (one per line)</Label>
                            <Textarea
                                rows={3}
                                value={(f.options || []).join("\n")}
                                onChange={(e) => patch(idx, { options: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean) })}
                                placeholder={"Option A\nOption B"}
                            />
                        </div>
                    )}
                    <div className="flex flex-wrap gap-4 text-xs text-zinc-600 dark:text-zinc-300 pl-6">
                        <label className="flex items-center gap-2"><Switch checked={!!f.required} onCheckedChange={(v) => patch(idx, { required: v })} /> Required</label>
                        <label className="flex items-center gap-2"><Switch checked={!!f.unique} onCheckedChange={(v) => patch(idx, { unique: v })} /> Unique</label>
                        <label className="flex items-center gap-2"><Switch checked={!!f.searchable} onCheckedChange={(v) => patch(idx, { searchable: v })} /> Searchable</label>
                        <label className="flex items-center gap-2" title="Private fields are never shown on public pages or in the API">
                            <Switch checked={!!f.private} onCheckedChange={(v) => patch(idx, { private: v })} /> Private
                        </label>
                    </div>
                </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={add} data-testid="add-field-btn">
                <Plus className="w-4 h-4 mr-1" /> Add field
            </Button>
        </div>
    );
}

/** Single input for one field, used by the item editor. */
export function FieldInput({ field, value, onChange }) {
    const set = (v) => onChange(v);
    const common = { "data-testid": `item-field-${field.key || field.label}`, value: value ?? "", onChange: (e) => set(e.target.value) };
    switch (field.type) {
        case "media":
            return <MediaField value={value} onChange={set} />;
        case "rich_text":
            return <Textarea rows={4} {...common} />;
        case "boolean":
            return <div className="pt-1"><Switch checked={!!value} onCheckedChange={set} /></div>;
        case "number":
        case "currency":
            return <Input type="number" {...common} />;
        case "date":
            return <Input type="date" {...common} />;
        case "datetime":
            return <Input type="datetime-local" {...common} />;
        case "single_select":
            return (
                <Select value={value || ""} onValueChange={set}>
                    <SelectTrigger data-testid={`item-field-${field.key}`}><SelectValue placeholder="Select…" /></SelectTrigger>
                    <SelectContent>{(field.options || []).map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                </Select>
            );
        case "multi_select":
            return (
                <Textarea rows={2} placeholder="One value per line"
                          value={Array.isArray(value) ? value.join("\n") : (value || "")}
                          onChange={(e) => set(e.target.value.split("\n").map((s) => s.trim()).filter(Boolean))} />
            );
        default:
            return <Input {...common} />;
    }
}
