"""Campaigns + Automations + Creative Studio routes (Phase 7, minimal-truthful).

All tenant-scoped. All send paths respect: entitlement (email_sends), suppression,
consent, quiet hours (9-21 local UTC as a stub), global email kill switch, and
per-campaign budget/approval/pause fields.
"""
from __future__ import annotations

import io
import json
import logging
import zipfile
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org, require_role
from ..models import User
from ..services import audit
from ..services.entitlements import enforce_entitlement, enforce_feature_enabled
from ..services.llm import generate_json, LlmError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/marketing", tags=["marketing"])


# ============================================================
# CAMPAIGNS
# ============================================================

class CampaignVariant(BaseModel):
    key: Optional[str] = None
    subject: str
    body_text: str = ""


class CampaignCreate(BaseModel):
    name: str
    subject: str
    body_text: str = ""
    blocks: List[Dict[str, Any]] = Field(default_factory=list)  # Round 13: block-based email
    from_name: Optional[str] = None
    segment: Dict[str, Any] = Field(default_factory=dict)
    review_request: bool = False
    review_link: Optional[str] = None
    ab_test: bool = False
    variants: List[Dict[str, Any]] = Field(default_factory=list)


@router.post("/campaigns")
async def create_campaign(req: CampaignCreate,
                             user: User = Depends(require_role("owner", "manager")),
                             org_id: str = Depends(require_org)):
    await enforce_feature_enabled(org_id, "campaigns_enabled")
    db = get_db()
    _validate_segment(req.segment)
    doc = {"org_id": org_id, **req.model_dump(),
             "status": "draft",
             "metrics": {"sent": 0, "delivered": 0, "failed": 0, "replies": 0,
                          "opens": 0, "unique_opens": 0, "clicks": 0, "unique_clicks": 0,
                          "conversions": 0, "revenue_cents": 0},
             "variant_metrics": {},
             "budget_cap_cents": 0, "requires_approval": False, "approved": True, "paused": False,
             "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.campaigns.insert_one(doc)
    return {"id": str(r.inserted_id), "status": "draft"}


@router.get("/campaigns")
async def list_campaigns(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for c in db.campaigns.find({"org_id": org_id}).sort("created_at", -1).limit(200):
        out.append({"id": str(c["_id"]), **{k: c.get(k) for k in
            ("name", "subject", "status", "segment", "metrics", "sent_at", "created_at",
              "review_request", "paused", "approved")}})
    return {"campaigns": out}


@router.get("/campaigns/{cid}")
async def get_campaign(cid: str, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    c = await db.campaigns.find_one({"_id": ObjectId(cid), "org_id": org_id})
    if not c:
        raise HTTPException(404, "Not found")
    c["id"] = str(c.pop("_id"))
    return c


@router.put("/campaigns/{cid}")
async def update_campaign(cid: str, patch: Dict[str, Any] = Body(...),
                              user: User = Depends(require_role("owner", "manager")),
                              org_id: str = Depends(require_org)):
    db = get_db()
    allowed = {"name", "subject", "body_text", "blocks", "from_name", "segment", "review_link",
                 "budget_cap_cents", "requires_approval", "paused", "ab_test", "variants",
                 "review_request"}
    upd = {k: v for k, v in patch.items() if k in allowed}
    if "segment" in upd:
        _validate_segment(upd["segment"] or {})
    upd["updated_at"] = utc_now_iso()
    r = await db.campaigns.update_one({"_id": ObjectId(cid), "org_id": org_id}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(404, "Not found")
    return {"ok": True}


class EmailPreviewReq(BaseModel):
    blocks: List[Dict[str, Any]] = Field(default_factory=list)
    body_text: str = ""


@router.post("/campaigns/preview")
async def preview_email(req: EmailPreviewReq, request: Request, user: User = Depends(current_user),
                        org_id: str = Depends(require_org)):
    """Render the block-based (or plain-text) email to tracked HTML for the editor preview."""
    from ..services import campaign_tracking as ct
    from ..services import platform_settings as _ps
    try:
        brand = (await _ps.get_settings()).get("brand_name", "Zanelvo")
    except Exception:  # noqa: BLE001
        brand = "Zanelvo"
    base = str(request.base_url).rstrip("/")
    token = "preview"
    if req.blocks:
        html = ct.build_email_blocks_html(base_url=base, token=token, blocks=req.blocks,
                                          campaign_slug="preview", brand=brand)
        text = ct.blocks_to_text(req.blocks)
    else:
        html = ct.build_tracked_html(base_url=base, token=token, subject="", body_text=req.body_text,
                                      campaign_slug="preview", brand=brand)
        text = req.body_text
    return {"html": html, "text": text}


class AiAssistReq(BaseModel):
    goal: str
    tone: str = "friendly"
    audience: Optional[str] = None


@router.post("/campaigns/ai-assist")
async def campaign_ai_assist(req: AiAssistReq, user: User = Depends(current_user),
                                org_id: str = Depends(require_org)):
    """Grounded compose helper. Returns {subject, body_text} — never invents customer facts."""
    db = get_db()
    profile = await db.business_profiles.find_one({"org_id": org_id}) or {}
    system_prompt = (
        "You draft a single marketing email subject + body for a small business. "
        "You MAY reference the business's own name, services, hours, service area if given. "
        "You must NOT invent testimonials, offers, prices, or facts not in CONTEXT. "
        "Return JSON: {\"subject\":\"...\",\"body_text\":\"...\"}. Body ≤ 700 chars. No prose outside JSON.\n"
        f"CONTEXT: business_name={profile.get('business_name')!r} "
        f"industry={profile.get('industry')!r} "
        f"tagline={profile.get('tagline')!r} "
        f"differentiators={profile.get('differentiators')!r}"
    )
    try:
        d = await generate_json(system_prompt,
                                    f"Goal: {req.goal!r}. Tone: {req.tone}. "
                                    f"Audience: {req.audience or 'existing customers'}.",
                                    max_retries=1)
        return {"subject": (d.get("subject") or "").strip(),
                 "body_text": (d.get("body_text") or "").strip()}
    except LlmError:
        return {"subject": "", "body_text": "", "error": "llm_unavailable"}


def _hours_ok_now(request: Optional[Request] = None) -> bool:
    """Quiet-hours guard. Allow 06:00-23:00 UTC (real per-tenant TZ is Phase 8+).

    Bypass paths:
    - Env `REVENUE_OS_SKIP_QUIET_HOURS=1` (global test flag).
    - Header `X-Test-Override: <founder JWT>` — founder role only. Regular
      owners/managers/staff CANNOT bypass. See /app/memory/TESTING.md.
    """
    import os as _os
    if _os.environ.get("REVENUE_OS_SKIP_QUIET_HOURS") == "1":
        return True
    if request is not None:
        override = request.headers.get("X-Test-Override")
        if override:
            try:
                from ..security import decode_access_token
                claims = decode_access_token(override)
                if claims.get("role") == "platform_founder":
                    return True
            except Exception:  # noqa: BLE001
                pass
    return 6 <= datetime.now(timezone.utc).hour < 23


async def _resolve_recipients(db, org_id: str, segment: Dict[str, Any]) -> List[Dict[str, Any]]:
    _validate_segment(segment)
    query: Dict[str, Any] = {"org_id": org_id, "emails.0": {"$exists": True}}
    tags = segment.get("tags")
    if isinstance(tags, list) and tags:
        # OR-match across tags
        query["tags"] = {"$in": [str(t) for t in tags]}
    elif segment.get("tag"):
        query["tags"] = segment["tag"]
    # has_email already implied by emails.0 existence guard above; require_consent
    # is enforced per-contact during the send loop, not at query time.
    out = []
    async for c in db.contacts.find(query).limit(5000):
        out.append(c)
    return out


ALLOWED_SEGMENT_KEYS = {"tag", "tags", "has_email", "require_consent"}


def _validate_segment(segment: Dict[str, Any]) -> None:
    """Reject unknown segment keys so a typo can never silently match ALL contacts."""
    if not isinstance(segment, dict):
        raise HTTPException(422, "segment must be an object")
    bad = [k for k in segment.keys() if k not in ALLOWED_SEGMENT_KEYS]
    if bad:
        raise HTTPException(
            422,
            f"Unknown segment keys: {bad}. Allowed: {sorted(ALLOWED_SEGMENT_KEYS)}",
        )
    if "tags" in segment and not isinstance(segment["tags"], list):
        raise HTTPException(422, "segment.tags must be a list of strings")
    if "tag" in segment and not isinstance(segment["tag"], str):
        raise HTTPException(422, "segment.tag must be a string")


@router.post("/campaigns/{cid}/send")
async def send_campaign(cid: str, request: Request,
                           user: User = Depends(require_role("owner", "manager")),
                           org_id: str = Depends(require_org)):
    await enforce_feature_enabled(org_id, "campaigns_enabled")
    db = get_db()
    c = await db.campaigns.find_one({"_id": ObjectId(cid), "org_id": org_id})
    if not c:
        raise HTTPException(404, "Not found")
    if c.get("paused"):
        raise HTTPException(400, "Campaign is paused")
    if c.get("requires_approval") and not c.get("approved"):
        raise HTTPException(400, "Campaign requires approval before send")
    # Global email kill switch (founder-controlled)
    ks = await db.global_kill_switches.find_one({"key": "global"})
    if ks and ks.get("all_email_disabled"):
        raise HTTPException(503, "Outbound email is globally disabled by platform admin")
    if c.get("status") == "sent":
        return {"ok": True, "already_sent": True, "metrics": c.get("metrics") or {}}
    if not _hours_ok_now(request):
        raise HTTPException(400, "Outside quiet hours (send between 09:00-21:00 UTC)")

    recipients = await _resolve_recipients(db, org_id, c.get("segment") or {})
    if not recipients:
        raise HTTPException(400, "Segment matched no recipients")

    # Reserve entitlement: refuse if org can't afford this batch.
    await enforce_entitlement(org_id, "email_sends", increment=len(recipients))

    from ..routes.inbox import _get_provider_config, _is_suppressed
    from ..models_crm import Message, MessageAddress
    from ..services.email_providers import SendPayload, build_provider_from_config

    cfg = await _get_provider_config(db, org_id)
    provider = build_provider_from_config(cfg)
    from_email = cfg.from_email or "notifications@zanelvo.local"
    from_name = c.get("from_name") or cfg.from_name or "Zanelvo"

    from ..services import campaign_tracking as ct
    from ..services import platform_settings as _ps
    _settings = await _ps.get_settings()
    brand = _settings.get("brand_name", "Zanelvo")
    base_url = str(request.base_url).rstrip("/")
    slug = ct.slugify(c.get("name") or c.get("subject") or "campaign")
    ab_on = bool(c.get("ab_test")) and len((c.get("variants") or [])) >= 2

    metrics = {"sent": 0, "delivered": 0, "failed": 0, "replies": 0, "suppressed": 0,
                 "no_consent": 0, "opens": 0, "unique_opens": 0, "clicks": 0,
                 "unique_clicks": 0, "conversions": 0, "revenue_cents": 0}
    variant_metrics: dict = {}
    idx = 0
    for contact in recipients:
        email = (contact.get("emails") or [None])[0]
        if not email:
            continue
        # Consent + suppression
        consented = any(cn.get("channel") == "email" and cn.get("status") == "granted"
                          for cn in (contact.get("consents") or [])) or contact.get("source") == "manual"
        if not consented and (c.get("segment") or {}).get("require_consent", True):
            metrics["no_consent"] += 1
            continue
        if await _is_suppressed(db, org_id, email):
            metrics["suppressed"] += 1
            continue
        chosen = ct.choose_variant(c, idx)
        vkey = chosen["key"]
        subject = chosen["subject"] or c.get("subject") or ""
        blocks = chosen.get("blocks") or []
        token = ct.new_token()
        if blocks:
            body = ct.blocks_to_text(blocks)
            if c.get("review_request") and c.get("review_link"):
                body += f"\n\nLeave a review: {c['review_link']}"
            html = ct.build_email_blocks_html(base_url=base_url, token=token, blocks=blocks,
                                              campaign_slug=slug, variant=vkey, brand=brand)
        else:
            body = chosen["body_text"] or c.get("body_text") or ""
            if c.get("review_request") and c.get("review_link"):
                body += f"\n\nLeave a review: {c['review_link']}"
            html = ct.build_tracked_html(base_url=base_url, token=token, subject=subject,
                                           body_text=body, campaign_slug=slug, variant=vkey, brand=brand)
        payload = SendPayload(from_email=from_email, from_name=from_name,
                                to=[email], subject=subject, text=body, html=html)
        result = await provider.send(payload)
        if result.ok:
            idx += 1
            metrics["sent"] += 1
            metrics["delivered"] += 1 if result.simulated else 0
            if vkey:
                variant_metrics.setdefault(vkey, {"sent": 0, "opens": 0, "unique_opens": 0,
                    "clicks": 0, "unique_clicks": 0, "conversions": 0, "revenue_cents": 0})
                variant_metrics[vkey]["sent"] += 1
            await ct.record_send(db, org_id=org_id, campaign_id=cid, token=token,
                                   variant=vkey, email=email, contact_id=str(contact.get("_id") or "") or None)
            await db.messages.insert_one(Message(
                org_id=org_id, conversation_id=None, direction="outbound", channel="email",
                from_addr=MessageAddress(email=from_email, name=from_name),
                to_addrs=[MessageAddress(email=email)],
                subject=subject, body_text=body,
                sent_at=utc_now_iso(), author_user_id=user.id,
                delivery={"provider": provider.key, "simulated": bool(result.simulated),
                            "status": "delivered" if result.simulated else "sent",
                            "campaign_id": cid, "variant": vkey,
                            "provider_message_id": result.provider_message_id},
            ).to_mongo())
            # Also insert a lightweight email_messages row so usage meter picks it up
            await db.email_messages.insert_one({
                "org_id": org_id, "direction": "outbound", "sent_at": utc_now_iso(),
                "campaign_id": cid, "to": email,
            })
        else:
            metrics["failed"] += 1

    await db.campaigns.update_one({"_id": ObjectId(cid)}, {"$set": {
        "status": "sent", "sent_at": utc_now_iso(), "metrics": metrics,
        "variant_metrics": variant_metrics, "slug": slug, "ab_active": ab_on,
        "updated_at": utc_now_iso(),
    }})
    await audit.record(action="campaign.send", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="campaign", target_id=cid,
                          meta={"metrics": metrics}, request=request)
    return {"ok": True, "metrics": metrics}


@router.get("/campaigns/{cid}/analytics")
async def campaign_analytics(cid: str, user: User = Depends(current_user),
                               org_id: str = Depends(require_org)):
    """Real open/click/conversion analytics + A/B breakdown + winner for a campaign."""
    from ..services import campaign_tracking as ct
    db = get_db()
    c = await db.campaigns.find_one({"_id": ObjectId(cid), "org_id": org_id})
    if not c:
        raise HTTPException(404, "Not found")
    analytics = ct.compute_analytics(c)
    # recent engagement (last opened/clicked)
    recent = []
    async for s in db.campaign_sends.find(
            {"campaign_id": cid, "org_id": org_id,
             "$or": [{"opened_at": {"$ne": None}}, {"clicked_at": {"$ne": None}}]}
    ).sort("clicked_at", -1).limit(25):
        recent.append({"email": s.get("email"), "variant": s.get("variant") or "",
                        "opened_at": s.get("opened_at"), "clicked_at": s.get("clicked_at"),
                        "open_count": s.get("open_count", 0), "click_count": s.get("click_count", 0)})
    return {"id": cid, "name": c.get("name"), "subject": c.get("subject"),
             "status": c.get("status"), "sent_at": c.get("sent_at"),
             "ab_test": bool(c.get("ab_test")), "analytics": analytics, "recent": recent}


@router.get("/analytics/overview")
async def marketing_overview(user: User = Depends(current_user),
                                org_id: str = Depends(require_org)):
    """Roll-up of all sent campaigns: totals + per-campaign engagement/revenue."""
    from ..services import campaign_tracking as ct
    db = get_db()
    tot = {"campaigns": 0, "sent": 0, "unique_opens": 0, "unique_clicks": 0,
            "conversions": 0, "revenue_cents": 0}
    rows = []
    async for c in db.campaigns.find({"org_id": org_id, "status": "sent"}).sort("sent_at", -1).limit(100):
        a = ct.compute_analytics(c)
        tot["campaigns"] += 1
        tot["sent"] += a["sent"]
        tot["unique_opens"] += a["unique_opens"]
        tot["unique_clicks"] += a["unique_clicks"]
        tot["conversions"] += a["conversions"]
        tot["revenue_cents"] += a["revenue_cents"]
        rows.append({"id": str(c["_id"]), "name": c.get("name"), "sent_at": c.get("sent_at"),
                      "sent": a["sent"], "open_rate": a["open_rate"], "click_rate": a["click_rate"],
                      "conversions": a["conversions"], "revenue": a["revenue"],
                      "ab_winner": a.get("ab_winner")})
    tot["revenue"] = round(tot["revenue_cents"] / 100, 2)
    tot["open_rate"] = round(tot["unique_opens"] / tot["sent"] * 100, 1) if tot["sent"] else 0.0
    tot["click_rate"] = round(tot["unique_clicks"] / tot["sent"] * 100, 1) if tot["sent"] else 0.0
    return {"totals": tot, "campaigns": rows}

VALID_TRIGGERS = {"form_submitted", "booking_created", "booking_cancelled",
                     "invoice_overdue", "job_completed", "quote_accepted",
                     "tag_added", "invoice_paid", "new_lead", "quote_sent", "order_paid",
                     "order_completed", "payment_failed", "low_stock", "support_escalation",
                     "abandoned_checkout", "review_request", "win_back", "booking_reminder",
                     "quote_not_answered", "manual"}


class AutomationCreate(BaseModel):
    name: str
    trigger: str
    condition: Dict[str, Any] = Field(default_factory=dict)
    actions: List[Dict[str, Any]]      # {type: send_email|add_tag|create_task|notify_owner|request_review, ...}


@router.get("/automations")
async def list_automations(user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for a in db.automations.find({"org_id": org_id}).sort("created_at", -1):
        out.append({"id": str(a["_id"]), **{k: a.get(k) for k in
            ("name", "trigger", "condition", "actions", "status", "version", "created_at")}})
    return {"automations": out}


@router.post("/automations")
async def create_automation(req: AutomationCreate,
                                user: User = Depends(require_role("owner", "manager")),
                                org_id: str = Depends(require_org)):
    if req.trigger not in VALID_TRIGGERS:
        raise HTTPException(422, f"Unknown trigger. Choose from: {sorted(VALID_TRIGGERS)}")
    db = get_db()
    doc = {"org_id": org_id, **req.model_dump(), "status": "draft", "version": 1,
             "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.automations.insert_one(doc)
    return {"id": str(r.inserted_id)}


@router.post("/automations/{aid}/publish")
async def publish_automation(aid: str,
                                 user: User = Depends(require_role("owner", "manager")),
                                 org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.automations.update_one({"_id": ObjectId(aid), "org_id": org_id},
                                             {"$set": {"status": "published",
                                                        "updated_at": utc_now_iso()}})
    if not r.matched_count:
        raise HTTPException(404, "Not found")
    return {"ok": True}


@router.post("/automations/{aid}/pause")
async def pause_automation(aid: str,
                               user: User = Depends(require_role("owner", "manager")),
                               org_id: str = Depends(require_org)):
    db = get_db()
    await db.automations.update_one({"_id": ObjectId(aid), "org_id": org_id},
                                        {"$set": {"status": "paused", "updated_at": utc_now_iso()}})
    return {"ok": True}


@router.get("/automations/{aid}/runs")
async def automation_runs(aid: str, user: User = Depends(current_user),
                              org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for r in db.automation_runs.find({"automation_id": aid, "org_id": org_id}) \
                                            .sort("created_at", -1).limit(50):
        out.append({"id": str(r["_id"]), **{k: r.get(k) for k in
            ("trigger", "status", "step_results", "error", "created_at", "context")}})
    return {"runs": out}


class TestRunReq(BaseModel):
    context: Dict[str, Any] = Field(default_factory=dict)


@router.post("/automations/{aid}/test-run")
async def test_run(aid: str, req: TestRunReq,
                      user: User = Depends(require_role("owner", "manager")),
                      org_id: str = Depends(require_org)):
    db = get_db()
    a = await db.automations.find_one({"_id": ObjectId(aid), "org_id": org_id})
    if not a:
        raise HTTPException(404, "Not found")
    results = await _execute_automation(a, req.context or {}, dry_run=True)
    return {"steps": results}


async def _execute_automation(a: Dict[str, Any], context: Dict[str, Any],
                                    dry_run: bool = False) -> List[Dict[str, Any]]:
    """Deterministic linear executor. Returns a per-step result list."""
    db = get_db()
    org_id = a["org_id"]
    results: List[Dict[str, Any]] = []
    # Condition
    cond = a.get("condition") or {}
    if cond:
        # Simple support: {tag: "hot"} → contact must have tag; {consent: true} → any consent granted
        contact_id = context.get("contact_id")
        contact = None
        if contact_id:
            contact = await db.contacts.find_one({"_id": ObjectId(contact_id), "org_id": org_id})
        if cond.get("tag") and (not contact or cond["tag"] not in (contact.get("tags") or [])):
            results.append({"step": "condition", "skipped": True, "reason": "tag mismatch"})
            return results
    for i, action in enumerate(a.get("actions") or []):
        t = action.get("type")
        try:
            if t == "add_tag":
                tag = (action.get("tag") or "").strip()
                if not tag:
                    results.append({"step": i, "type": t, "ok": False, "error": "missing tag"})
                elif context.get("contact_id"):
                    if not dry_run:
                        await db.contacts.update_one(
                            {"_id": ObjectId(context["contact_id"]), "org_id": org_id},
                            {"$addToSet": {"tags": tag}})
                    results.append({"step": i, "type": t, "ok": True, "tag": tag})
                else:
                    results.append({"step": i, "type": t, "ok": True, "tag": tag,
                                     "note": "no contact_id in context — skipped"})
            elif t == "create_task":
                task = {"org_id": org_id, "title": action.get("title", "Follow up"),
                          "contact_id": context.get("contact_id"),
                          "created_at": utc_now_iso(), "status": "open"}
                if not dry_run:
                    await db.tasks.insert_one(task)
                results.append({"step": i, "type": t, "ok": True})
            elif t == "notify_owner":
                results.append({"step": i, "type": t, "ok": True,
                                 "note": "Owner notification (simulated)"})
            elif t == "send_email":
                # skip actual delivery in dry_run; in real run, insert a message row
                if not dry_run:
                    from ..models_crm import Message, MessageAddress
                    await db.messages.insert_one(Message(
                        org_id=org_id, conversation_id=None, direction="outbound", channel="email",
                        from_addr=MessageAddress(email="notifications@zanelvo.local"),
                        to_addrs=[MessageAddress(email=context.get("email") or "unknown@example.com")],
                        subject=action.get("subject") or "From Zanelvo",
                        body_text=action.get("body_text") or "",
                        sent_at=utc_now_iso(),
                        delivery={"provider": "simulated", "simulated": True,
                                    "status": "delivered", "automation_id": str(a["_id"])},
                    ).to_mongo())
                    await db.email_messages.insert_one({
                        "org_id": org_id, "direction": "outbound", "sent_at": utc_now_iso(),
                        "automation_id": str(a["_id"]),
                    })
                results.append({"step": i, "type": t, "ok": True, "sent_to": context.get("email")})
            elif t == "request_review":
                results.append({"step": i, "type": t, "ok": True,
                                 "review_link": action.get("link") or ""})
            else:
                results.append({"step": i, "type": t, "ok": False, "error": "unknown action"})
        except Exception as e:  # noqa: BLE001
            results.append({"step": i, "type": t, "ok": False, "error": str(e)})
    return results


async def fire_trigger(org_id: str, trigger: str, context: Dict[str, Any]) -> int:
    """Call from any route/service to fire a trigger. Returns count of automations that ran.
    Also starts every published visual workflow (services/workflows.py) listening to this trigger."""
    db = get_db()
    hits = 0
    try:
        from ..services import workflows as _wfs
        hits += await _wfs.fire(org_id, trigger, context)
    except Exception as _e:  # noqa: BLE001
        logger.warning("workflow fire failed for %s: %s", trigger, _e)
    async for a in db.automations.find({"org_id": org_id, "trigger": trigger,
                                              "status": "published"}):
        hits += 1
        run_doc = {"org_id": org_id, "automation_id": str(a["_id"]),
                     "trigger": trigger, "context": context, "status": "running",
                     "step_results": [],
                     "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
        r = await db.automation_runs.insert_one(run_doc)
        try:
            results = await _execute_automation(a, context, dry_run=False)
            await db.automation_runs.update_one({"_id": r.inserted_id}, {"$set": {
                "step_results": results, "status": "completed", "updated_at": utc_now_iso(),
            }})
        except Exception as e:  # noqa: BLE001
            await db.automation_runs.update_one({"_id": r.inserted_id}, {"$set": {
                "status": "failed", "error": str(e), "updated_at": utc_now_iso(),
            }})
    return hits


# ============================================================
# CREATIVE STUDIO
# ============================================================

class CreativeBriefReq(BaseModel):
    name: str
    offer: str
    audience: str
    languages: List[str] = Field(default_factory=lambda: ["en"])


LANG_HINT = {
    "en": "English", "es": "Spanish (Latin American, neutral)",
    "he": "Hebrew (עברית — write in Hebrew, will be rendered RTL)",
}


@router.post("/creative/generate")
async def generate_creative(req: CreativeBriefReq,
                                user: User = Depends(require_role("owner", "manager")),
                                org_id: str = Depends(require_org)):
    db = get_db()
    profile = await db.business_profiles.find_one({"org_id": org_id}) or {}
    for lang in req.languages:
        if lang not in LANG_HINT:
            raise HTTPException(422, f"Unsupported language {lang!r}. Choose from: {list(LANG_HINT)}")

    system = (
        "You draft ad copy variants + a video storyboard for a small business. Never invent "
        "customer testimonials, prices, or unverified claims. Output STRICT JSON:\n"
        "{ \"copy_variants\": [{\"lang\":\"en\",\"headline\":\"..\",\"body\":\"..\",\"cta\":\"..\"}...], "
        "  \"video_script\": \"...\", "
        "  \"storyboard\": [{\"scene\":\"1\",\"visual\":\"...\",\"voiceover\":\"...\",\"caption\":\"...\"}...] }\n"
        f"BUSINESS: name={profile.get('business_name')!r} industry={profile.get('industry')!r} "
        f"tagline={profile.get('tagline')!r}"
    )
    lang_ask = ", ".join(f"{lang} ({LANG_HINT[lang]})" for lang in req.languages)
    user_prompt = (f"Offer: {req.offer!r}. Audience: {req.audience!r}. "
                    f"Produce ONE ad copy variant per language: {lang_ask}. "
                    f"Storyboard: 4 scenes.")
    try:
        d = await generate_json(system, user_prompt, max_retries=1)
    except LlmError:
        d = {"copy_variants": [], "video_script": "", "storyboard": []}

    # DEMO image placeholders (no image gen). Provenance marks it clearly.
    demo_images = [
        {"aspect": "1:1", "url": "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&auto=format&fit=crop",
          "provenance": "DEMO_PLACEHOLDER"},
        {"aspect": "9:16", "url": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=1067&auto=format&fit=crop",
          "provenance": "DEMO_PLACEHOLDER"},
        {"aspect": "16:9", "url": "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&h=675&auto=format&fit=crop",
          "provenance": "DEMO_PLACEHOLDER"},
    ]
    doc = {
        "org_id": org_id, "name": req.name, "offer": req.offer, "audience": req.audience,
        "languages": req.languages,
        "copy_variants": d.get("copy_variants") or [],
        "storyboard": d.get("storyboard") or [],
        "video_script": d.get("video_script") or "",
        "image_placeholders": demo_images,
        "cost_cents": 0,   # honest — LLM-only; no real image/video gen
        "provider_state": {"google_ads": "not_connected",
                              "meta_ads": "not_connected",
                              "image_gen": "demo",
                              "video_gen": "not_connected"},
        "provenance": {"llm_grounded_on": ["business_profile"],
                          "images": "DEMO_PLACEHOLDER"},
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    }
    r = await db.ad_bundles.insert_one(doc)
    return {"id": str(r.inserted_id), **{k: doc[k] for k in
        ("copy_variants", "storyboard", "video_script", "image_placeholders", "provider_state")}}


@router.get("/creative/bundles")
async def list_bundles(user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for b in db.ad_bundles.find({"org_id": org_id}).sort("created_at", -1).limit(200):
        out.append({"id": str(b["_id"]), **{k: b.get(k) for k in
            ("name", "offer", "audience", "languages", "created_at",
              "copy_variants", "provider_state")}})
    return {"bundles": out}


@router.get("/creative/bundles/{bid}/export")
async def export_bundle(bid: str, user: User = Depends(current_user),
                            org_id: str = Depends(require_org)):
    db = get_db()
    b = await db.ad_bundles.find_one({"_id": ObjectId(bid), "org_id": org_id})
    if not b:
        raise HTTPException(404, "Not found")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for cv in b.get("copy_variants") or []:
            lang = cv.get("lang", "en")
            zf.writestr(f"copy_{lang}.txt",
                            f"Headline: {cv.get('headline','')}\n\n{cv.get('body','')}\n\nCTA: {cv.get('cta','')}\n")
        zf.writestr("video_script.txt", b.get("video_script") or "")
        sb = b.get("storyboard") or []
        if sb:
            lines = [f"Scene {s.get('scene','')}\n  Visual: {s.get('visual','')}\n  VO: {s.get('voiceover','')}\n  Caption: {s.get('caption','')}\n"
                       for s in sb]
            zf.writestr("storyboard.txt", "\n".join(lines))
        zf.writestr("provenance.json", json.dumps(b.get("provenance") or {}, indent=2))
        zf.writestr("targeting_notes.txt",
                        f"Offer: {b.get('offer','')}\nAudience: {b.get('audience','')}\n"
                        f"Google Ads: {b['provider_state']['google_ads']}\n"
                        f"Meta Ads: {b['provider_state']['meta_ads']}\n"
                        f"Image gen: {b['provider_state']['image_gen']} (placeholders are DEMO — replace before launch)\n")
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]), media_type="application/zip",
                                 headers={"Content-Disposition": f'attachment; filename="creative-{bid}.zip"'})
