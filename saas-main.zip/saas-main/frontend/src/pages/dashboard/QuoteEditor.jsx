import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2, Copy, Send, FileCheck2, Loader2, ExternalLink } from "lucide-react";

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

function emptyLine() {
    return {
        id: undefined,
        kind: "custom",
        label: "",
        description: "",
        quantity: 1,
        unit_price_cents: 0,
        discount_percent: 0,
        tax_rate: 0,
        taxable: true,
    };
}

function computeTotals(lines, globalDiscount, taxRate) {
    let subtotal = 0, discount = 0, taxable = 0;
    const gd = Math.max(0, Math.min(100, +globalDiscount || 0)) / 100;
    const tr = Math.max(0, Math.min(100, +taxRate || 0)) / 100;
    for (const l of lines) {
        const gross = Math.round((+l.quantity || 0) * (+l.unit_price_cents || 0));
        subtotal += gross;
        const lineDiscPct = Math.max(0, Math.min(100, +l.discount_percent || 0)) / 100;
        const lineDisc = Math.min(gross, Math.round(gross * lineDiscPct));
        discount += lineDisc;
        const net = Math.max(0, gross - lineDisc);
        if (l.taxable) taxable += net;
    }
    const gDisc = Math.round((subtotal - discount) * gd);
    discount = Math.min(subtotal, discount + gDisc);
    const taxableFinal = Math.max(0, taxable - Math.round(taxable * gd));
    const tax = Math.round(taxableFinal * tr);
    const total = Math.max(0, subtotal - discount + tax);
    return { subtotal_cents: subtotal, discount_cents: discount, tax_cents: tax, total_cents: total };
}

export default function QuoteEditor() {
    const { qid } = useParams();
    const isNew = qid === "new";
    const navigate = useNavigate();
    const [contacts, setContacts] = useState([]);
    const [services, setServices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [quote, setQuote] = useState(null);
    const [busy, setBusy] = useState(false);

    // Editable state (for new/draft quotes)
    const [contactId, setContactId] = useState("");
    const [lines, setLines] = useState([emptyLine()]);
    const [taxRate, setTaxRate] = useState(0);
    const [globalDiscount, setGlobalDiscount] = useState(0);
    const [deposit, setDeposit] = useState(0);
    const [currency, setCurrency] = useState("USD");
    const [notes, setNotes] = useState("");
    const [terms, setTerms] = useState("");

    async function load() {
        setLoading(true);
        try {
            const [c, s] = await Promise.all([
                api.get("/crm/contacts?limit=200"),
                api.get("/booking/services"),
            ]);
            setContacts(c.data.contacts || []);
            setServices(s.data.services || []);
            if (!isNew) {
                const { data } = await api.get(`/quotes/${qid}`);
                setQuote(data);
                setContactId(data.contact_id || "");
                setLines(data.lines?.length ? data.lines : [emptyLine()]);
                setTaxRate(data.tax_rate || 0);
                setGlobalDiscount(data.global_discount_percent || 0);
                setDeposit(data.deposit_required_cents || 0);
                setCurrency(data.currency || "USD");
                setNotes(data.notes || "");
                setTerms(data.terms || "");
            }
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [qid]);

    const totals = useMemo(() => computeTotals(lines, globalDiscount, taxRate), [lines, globalDiscount, taxRate]);
    const readOnly = !!quote && quote.status !== "draft" && quote.approval_state !== "pending";

    function addLine() { setLines([...lines, emptyLine()]); }
    function delLine(idx) { setLines(lines.filter((_, i) => i !== idx)); }
    function updateLine(idx, patch) {
        setLines(lines.map((l, i) => i === idx ? { ...l, ...patch } : l));
    }
    function pickService(idx, svcId) {
        const svc = services.find((s) => s.id === svcId);
        if (!svc) return;
        updateLine(idx, {
            kind: "service", ref_id: svc.id,
            label: svc.name, description: svc.description || "",
            unit_price_cents: svc.price_cents, quantity: 1,
        });
    }

    async function save() {
        setBusy(true);
        try {
            const payload = {
                contact_id: contactId || null,
                lines: lines.map((l) => ({
                    id: l.id, kind: l.kind, ref_id: l.ref_id,
                    label: l.label, description: l.description || null,
                    quantity: +l.quantity || 1, unit_price_cents: +l.unit_price_cents || 0,
                    discount_percent: +l.discount_percent || 0,
                    discount_amount_cents: +l.discount_amount_cents || 0,
                    tax_rate: +l.tax_rate || 0, taxable: !!l.taxable,
                })),
                tax_rate: +taxRate || 0,
                global_discount_percent: +globalDiscount || 0,
                deposit_required_cents: +deposit || 0,
                currency,
                notes: notes || null,
                terms: terms || null,
                expires_at: null,
            };
            const { data } = await api.post("/quotes", payload);
            toast.success(`Quote created${data.approval_state === "pending" ? " — awaiting approval" : ""}`);
            navigate(`/app/quotes/${data.id}`);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Save failed");
        } finally { setBusy(false); }
    }

    async function sendQuote() {
        setBusy(true);
        try {
            await api.post(`/quotes/${qid}/send`);
            toast.success("Sent to customer.");
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Could not send"); }
        finally { setBusy(false); }
    }
    async function convert(kind) {
        setBusy(true);
        try {
            const body = { to_invoice: kind !== "job_only", to_job: kind !== "invoice_only", due_days: 14 };
            const { data } = await api.post(`/quotes/${qid}/convert`, body);
            if (data.invoice_id) toast.success("Invoice created");
            if (data.job_id) toast.success("Job created");
            if (data.invoice_id) navigate(`/app/payments/${data.invoice_id}`);
            else if (data.job_id) navigate("/app/jobs");
        } catch (e) { toast.error(e?.response?.data?.detail || "Convert failed"); }
        finally { setBusy(false); }
    }

    if (loading) return <div className="p-10 text-zinc-500">Loading…</div>;

    return (
        <div className="p-6 max-w-5xl" data-testid="quote-editor-page">
            <button onClick={() => navigate("/app/quotes")} className="text-xs text-brand-copper mb-2 inline-flex items-center gap-1 hover:underline">
                <ArrowLeft className="w-3.5 h-3.5" /> Back to quotes
            </button>
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Quote</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">
                        {isNew ? "New quote" : (quote?.number || qid?.slice(0, 8))}
                    </h1>
                    {quote && (
                        <div className="mt-1 flex items-center gap-2 flex-wrap">
                            <span className="text-xs uppercase tracking-widest rounded-full px-2 py-0.5 bg-brand-cream text-brand-ink" data-testid="quote-status-badge">{quote.status}</span>
                            {quote.approval_state === "pending" && (
                                <span className="text-xs uppercase tracking-widest rounded-full px-2 py-0.5 bg-amber-100 text-amber-800">Awaiting approval</span>
                            )}
                            {quote.approval_reason && <span className="text-xs text-amber-700">{quote.approval_reason}</span>}
                        </div>
                    )}
                </div>
                {!isNew && quote && (
                    <div className="flex items-center gap-2">
                        {quote.portal_token && (
                            <>
                                <Button variant="outline" onClick={() => {
                                    navigator.clipboard.writeText(`${window.location.origin}/portal/quote/${quote.id}?tk=${quote.portal_token}`);
                                    toast.success("Portal link copied");
                                }} data-testid="quote-copy-portal-btn">
                                    <Copy className="w-4 h-4 mr-1" /> Copy portal link
                                </Button>
                                <a href={`/portal/quote/${quote.id}?tk=${quote.portal_token}`} target="_blank" rel="noreferrer">
                                    <Button variant="ghost" data-testid="quote-open-portal-btn"><ExternalLink className="w-4 h-4 mr-1" /> Preview</Button>
                                </a>
                            </>
                        )}
                        {quote.status === "draft" && quote.approval_state !== "pending" && (
                            <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={sendQuote} disabled={busy} data-testid="quote-send-btn">
                                <Send className="w-4 h-4 mr-1" /> Send to customer
                            </Button>
                        )}
                        {quote.status === "accepted" && (
                            <>
                                <Button variant="outline" onClick={() => convert("invoice_only")} disabled={busy} data-testid="quote-convert-invoice-btn">
                                    <FileCheck2 className="w-4 h-4 mr-1" /> Convert to invoice
                                </Button>
                                <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={() => convert("both")} disabled={busy} data-testid="quote-convert-both-btn">
                                    Invoice + job
                                </Button>
                            </>
                        )}
                    </div>
                )}
            </div>

            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 rounded-2xl border border-brand-line bg-white p-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                            <Label className="text-xs">Contact</Label>
                            <Select value={contactId || "none"} onValueChange={(v) => setContactId(v === "none" ? "" : v)} disabled={readOnly}>
                                <SelectTrigger data-testid="quote-contact-select"><SelectValue placeholder="Select a contact" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="none">No contact</SelectItem>
                                    {contacts.slice(0, 100).map((c) => (
                                        <SelectItem key={c.id} value={c.id}>{c.display_name || (c.emails || [])[0] || c.id.slice(-6)}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label className="text-xs">Currency</Label>
                            <Input value={currency} onChange={(e) => setCurrency(e.target.value)} disabled={readOnly} maxLength={3} />
                        </div>
                    </div>

                    <div className="mt-4">
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Line items</div>
                        <div className="space-y-2" data-testid="quote-lines">
                            {lines.map((l, idx) => (
                                <div key={idx} className="grid grid-cols-12 gap-2 items-start rounded-md border border-brand-line p-2" data-testid={`quote-line-${idx}`}>
                                    <div className="col-span-12 md:col-span-4">
                                        <Input placeholder="Item / service" value={l.label} onChange={(e) => updateLine(idx, { label: e.target.value })} disabled={readOnly} data-testid={`quote-line-label-${idx}`} />
                                        {services.length > 0 && !readOnly && (
                                            <Select value={l.ref_id || "custom"} onValueChange={(v) => v !== "custom" && pickService(idx, v)}>
                                                <SelectTrigger className="mt-1 h-7 text-xs" data-testid={`quote-line-service-${idx}`}><SelectValue placeholder="Or pick a service" /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="custom">Custom</SelectItem>
                                                    {services.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                                                </SelectContent>
                                            </Select>
                                        )}
                                    </div>
                                    <div className="col-span-4 md:col-span-2">
                                        <Input type="number" step="0.01" min="0" placeholder="Qty" value={l.quantity} onChange={(e) => updateLine(idx, { quantity: +e.target.value })} disabled={readOnly} data-testid={`quote-line-qty-${idx}`} />
                                    </div>
                                    <div className="col-span-4 md:col-span-2">
                                        <Input type="number" min="0" placeholder="Unit ¢" value={l.unit_price_cents} onChange={(e) => updateLine(idx, { unit_price_cents: +e.target.value })} disabled={readOnly} data-testid={`quote-line-price-${idx}`} />
                                    </div>
                                    <div className="col-span-4 md:col-span-2">
                                        <Input type="number" step="0.01" min="0" max="100" placeholder="Disc %" value={l.discount_percent} onChange={(e) => updateLine(idx, { discount_percent: +e.target.value })} disabled={readOnly} data-testid={`quote-line-disc-${idx}`} />
                                        <div className="text-[10px] text-zinc-400 mt-0.5">0-100 (%)</div>
                                    </div>
                                    <div className="col-span-10 md:col-span-1 flex items-center justify-end font-mono text-sm text-brand-ink pt-2">
                                        {money(Math.round((+l.quantity || 0) * (+l.unit_price_cents || 0) * (1 - Math.max(0, Math.min(100, +l.discount_percent || 0)) / 100)), currency)}
                                    </div>
                                    <div className="col-span-2 md:col-span-1 flex justify-end">
                                        {!readOnly && lines.length > 1 && (
                                            <Button size="sm" variant="ghost" onClick={() => delLine(idx)} data-testid={`quote-line-del-${idx}`}>
                                                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                        {!readOnly && (
                            <Button variant="outline" size="sm" onClick={addLine} className="mt-2" data-testid="quote-add-line-btn">
                                <Plus className="w-3.5 h-3.5 mr-1" /> Add line
                            </Button>
                        )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-6">
                        <div>
                            <Label className="text-xs">Tax rate (%)</Label>
                            <Input type="number" step="0.01" min="0" max="50" value={taxRate} onChange={(e) => setTaxRate(+e.target.value)} disabled={readOnly} data-testid="quote-tax" />
                            <div className="text-[10px] text-zinc-400 mt-0.5">e.g. 8 for 8%</div>
                        </div>
                        <div>
                            <Label className="text-xs">Global discount (%)</Label>
                            <Input type="number" step="0.01" min="0" max="100" value={globalDiscount} onChange={(e) => setGlobalDiscount(+e.target.value)} disabled={readOnly} data-testid="quote-global-disc" />
                            <div className="text-[10px] text-zinc-400 mt-0.5">e.g. 25 for 25%</div>
                        </div>
                        <div>
                            <Label className="text-xs">Deposit (cents)</Label>
                            <Input type="number" min="0" value={deposit} onChange={(e) => setDeposit(+e.target.value)} disabled={readOnly} data-testid="quote-deposit" />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                        <div>
                            <Label className="text-xs">Notes for customer</Label>
                            <Textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} disabled={readOnly} data-testid="quote-notes" />
                        </div>
                        <div>
                            <Label className="text-xs">Terms</Label>
                            <Textarea rows={3} value={terms} onChange={(e) => setTerms(e.target.value)} disabled={readOnly} data-testid="quote-terms" />
                        </div>
                    </div>
                </div>

                <aside className="rounded-2xl border border-brand-line bg-white p-5 h-fit sticky top-6">
                    <div className="text-xs uppercase tracking-widest text-zinc-500">Totals</div>
                    <div className="mt-3 space-y-1 text-sm">
                        <div className="flex justify-between"><span className="text-zinc-500">Subtotal</span><span className="font-mono">{money(totals.subtotal_cents, currency)}</span></div>
                        {totals.discount_cents > 0 && <div className="flex justify-between text-emerald-700"><span>Discount</span><span className="font-mono">−{money(totals.discount_cents, currency)}</span></div>}
                        <div className="flex justify-between"><span className="text-zinc-500">Tax</span><span className="font-mono">{money(totals.tax_cents, currency)}</span></div>
                        <div className="flex justify-between pt-2 border-t border-brand-line"><span className="text-brand-ink font-medium">Total</span><span className="font-mono text-lg text-brand-ink" data-testid="quote-total">{money(totals.total_cents, currency)}</span></div>
                    </div>
                    {isNew && (
                        <Button className="w-full mt-4 bg-brand-copper hover:bg-brand-copperHover text-white" onClick={save} disabled={busy || !lines.some((l) => l.label)} data-testid="quote-save-btn">
                            {busy ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : null} Create quote
                        </Button>
                    )}
                    {globalDiscount >= 20 && (
                        <div className="mt-3 rounded-md bg-amber-50 border border-amber-200 text-amber-900 p-2 text-xs" data-testid="approval-hint">
                            This will need owner approval before sending (discount ≥ 20%).
                        </div>
                    )}
                </aside>
            </div>
        </div>
    );
}
