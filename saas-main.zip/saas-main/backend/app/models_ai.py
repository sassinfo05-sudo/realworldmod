"""Phase 5 domain models: knowledge base, AI agents (with versioning), chat conversations,
messages, per-call audit interactions, simulated call records, and the org-wide kill switch.

All tenant-scoped via org_id. Sensitive tokens (session_token, portal-style) are opaque strings.
"""
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .db import BaseDocument


AgentType = Literal["receptionist", "sales", "reactivation", "support", "admin"]
AgentTool = Literal[
    "get_services", "get_availability", "create_booking",
    "get_booking", "get_invoice", "take_message",
    "get_hours", "get_locations", "get_policies",
]


# ---------- Knowledge Base ----------

class KnowledgeChunk(BaseModel):
    id: str
    text: str
    heading: Optional[str] = None


class KnowledgeSource(BaseDocument):
    org_id: str
    kind: Literal["website_page", "faq", "policy", "upload", "structured_facts"]
    title: str
    origin: Optional[str] = None      # URL or file name
    body_text: Optional[str] = None    # raw extracted text (for uploads/pages)
    chunks: List[KnowledgeChunk] = Field(default_factory=list)
    facts: Optional[Dict[str, Any]] = None    # snapshot of structured facts if kind='structured_facts'
    ingested_at: str
    status: Literal["active", "excluded", "stale"] = "active"
    contradiction_flag: Optional[str] = None   # detected mismatch note
    version: int = 1
    created_by: Optional[str] = None
    updated_at: Optional[str] = None


# ---------- Agents (with versioning) ----------

class QualificationQuestion(BaseModel):
    name: str
    prompt: str
    required: bool = False


class EscalationRule(BaseModel):
    kind: Literal["topic", "keyword", "sentiment", "low_confidence"]
    value: str
    note: Optional[str] = None


class AgentVersion(BaseDocument):
    """Immutable snapshot of an agent's config. Only one version is `is_live` at a time.
    Editing an agent creates a new version (draft or promoted to live)."""
    org_id: str
    agent_id: str
    version: int
    label: Optional[str] = None       # human-readable label ("Friendlier tone")
    purpose: str
    tone: str = "warm, concise, helpful"
    languages: List[str] = Field(default_factory=lambda: ["en"])
    allowed_tools: List[AgentTool] = Field(default_factory=list)
    qualification_questions: List[QualificationQuestion] = Field(default_factory=list)
    escalation_rules: List[EscalationRule] = Field(default_factory=list)
    allowed_claims: Optional[str] = None
    confidence_threshold: float = 0.4  # below → escalate
    require_approval: bool = False
    system_prompt_override: Optional[str] = None
    model: str = "claude-sonnet-4-6"
    is_live: bool = False
    is_sandbox: bool = False           # transient draft used only for the sandbox
    created_by: Optional[str] = None


class Agent(BaseDocument):
    """Stable identity per (org, agent_type). Points at the currently live version."""
    org_id: str
    agent_type: AgentType
    name: str
    enabled: bool = True
    live_version_id: Optional[str] = None
    draft_version_id: Optional[str] = None
    updated_at: Optional[str] = None


class KillSwitch(BaseDocument):
    """Org-level master AI kill switch. When ai_enabled=False, no agent runs."""
    org_id: str
    ai_enabled: bool = True
    reason: Optional[str] = None
    updated_by: Optional[str] = None
    updated_at: Optional[str] = None


# ---------- Conversations / Messages ----------

class ChatConversation(BaseDocument):
    org_id: str
    channel: Literal["chat", "call"] = "chat"
    session_token: str                # visitor cookie / call sim token
    contact_id: Optional[str] = None
    website_slug: Optional[str] = None
    agent_id: Optional[str] = None
    agent_version_id: Optional[str] = None
    status: Literal["ai", "human", "closed", "sandbox"] = "ai"
    assigned_user_id: Optional[str] = None    # human who took over
    started_at: str
    last_message_at: str
    needs_human: bool = False
    escalation_reason: Optional[str] = None
    visitor_meta: Optional[Dict[str, Any]] = None    # {name, email, phone} once collected
    is_sandbox: bool = False           # sandbox conversations never touch CRM


class ChatMessage(BaseDocument):
    org_id: str
    conversation_id: str
    role: Literal["visitor", "ai", "human", "system"]
    author_user_id: Optional[str] = None
    content: str
    tool_calls: Optional[List[Dict[str, Any]]] = None
    citations: Optional[List[Dict[str, str]]] = None
    confidence: Optional[float] = None
    created_at_iso: Optional[str] = None   # avoid clash with BaseDocument.created_at


# ---------- Audit ----------

class AgentInteraction(BaseDocument):
    """One record per LLM invocation. Audit + cost trail visible to owners."""
    org_id: str
    agent_id: str
    agent_version_id: str
    conversation_id: Optional[str] = None
    call_record_id: Optional[str] = None
    action: str                        # answer / tool_call / escalate / take_message / error
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_cents: float = 0.0            # estimated
    latency_ms: int = 0
    tools_used: List[Dict[str, Any]] = Field(default_factory=list)
    outcome: str = ""
    confidence: float = 0.0
    error: Optional[str] = None
    is_sandbox: bool = False


# ---------- Simulated calls ----------

class CallRecord(BaseDocument):
    org_id: str
    conversation_id: str
    contact_id: Optional[str] = None
    direction: Literal["inbound", "outbound"] = "inbound"
    duration_seconds: int = 0
    transcript: str = ""              # full text transcript
    ai_summary: str = ""
    extracted_fields: Dict[str, Any] = Field(default_factory=dict)
    outcome: Literal["booked", "took_message", "escalated", "no_action"] = "no_action"
    simulated: bool = True
    cost_cents: float = 0.0
    ended_at: Optional[str] = None


# ---------- Daily digest ----------

class DailyDigest(BaseDocument):
    org_id: str
    for_date: str                      # YYYY-MM-DD
    todays_bookings_count: int = 0
    new_leads_count: int = 0
    overdue_invoices_count: int = 0
    pending_approvals_count: int = 0
    scheduling_conflicts: int = 0
    summary_markdown: str = ""
    facts: Dict[str, Any] = Field(default_factory=dict)
