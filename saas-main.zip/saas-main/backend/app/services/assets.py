"""Asset + storage-quota service (tenant-scoped).

Production stores ONLY metadata + stable asset IDs in Mongo (never base64 blobs). Bytes live in
object storage via services.storage. Atomic per-tenant byte reservation prevents quota bypass.

Collections: assets, asset_references, upload_reservations, storage_usage, storage_overrides.
All docs carry org_id resolved from the authenticated server context (never client input).
"""
from __future__ import annotations

import hashlib
import io
import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from fastapi import HTTPException

from ..db import get_db, utc_now_iso
from . import storage
from .svg_safe import sanitize_svg

ASSETS = "assets"
REFS = "asset_references"
RESV = "upload_reservations"
USAGE = "storage_usage"
OVERRIDES = "storage_overrides"

MB = 1024 * 1024
GB = 1024 * MB
MAX_FILE_BYTES = 25 * MB
RESERVATION_TTL_S = 3600
TRASH_RETENTION_DAYS = 30

# DB-backed, founder-editable defaults (platform_settings.storage_limits[plan]).
DEFAULT_STORAGE_LIMITS = {
    "free": 500 * MB, "launch": 5 * GB, "revenue": 50 * GB,
    "autopilot": 200 * GB, "scale": 500 * GB,
}

ALLOWED_MIME = {
    "image/png", "image/jpeg", "image/webp", "image/gif", "image/svg+xml",
    "application/pdf", "text/plain", "text/csv",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}
IMAGE_MIME = {"image/png", "image/jpeg", "image/webp", "image/gif", "image/svg+xml"}
CATEGORIES = {"brand", "website", "photo", "product", "marketing", "email", "document",
              "cms", "ai", "private", "other"}


def _media_type(mime: str) -> str:
    if mime.startswith("image/"):
        return "image"
    if mime == "application/pdf" or mime.startswith("text/") or "officedocument" in mime:
        return "document"
    return "file"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.isoformat().replace("+00:00", "Z")


async def sweep_expired_reservations(org_id: Optional[str] = None) -> int:
    """Release bytes held by reservations that were never finalized/cancelled past their TTL.
    Safe to call opportunistically or from a cron. Returns the number swept."""
    db = get_db()
    cutoff = _iso(_now())
    q: Dict[str, Any] = {"status": "reserved", "expires_at": {"$lt": cutoff}}
    if org_id:
        q["org_id"] = org_id
    swept = 0
    async for r in db[RESV].find(q):
        claimed = await db[RESV].find_one_and_update(
            {"_id": r["_id"], "status": "reserved"},
            {"$set": {"status": "expired", "expired_at": utc_now_iso()}})
        if claimed:
            await _release_reserved(r["org_id"], int(r.get("reserved_bytes", 0)))
            swept += 1
    return swept


def _sniff(raw: bytes) -> Optional[str]:
    if len(raw) < 4:
        return None
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if raw[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if raw[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "image/webp"
    if raw[:5] == b"%PDF-":
        return "application/pdf"
    head = raw[:512].lstrip().lower()
    if head.startswith(b"<?xml") or head.startswith(b"<svg") or b"<svg" in head:
        return "image/svg+xml"
    return None


def safe_name(name: str) -> str:
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", (name or "file").strip())[:180]
    return name or "file"


# --------------------------------------------------------------------------- limits + usage
async def storage_limit(org_id: str) -> int:
    from .entitlements import get_org_plan
    plan = await get_org_plan(org_id)
    limit = DEFAULT_STORAGE_LIMITS.get(plan, DEFAULT_STORAGE_LIMITS["free"])
    db = get_db()
    doc = await db.platform_settings.find_one({"key": "primary"}, {"storage_limits": 1})
    ov = ((doc or {}).get("storage_limits") or {}).get(plan)
    if isinstance(ov, (int, float)):
        limit = int(ov)
    tenant = await db[OVERRIDES].find_one({"org_id": org_id}, {"bytes": 1})
    if tenant and isinstance(tenant.get("bytes"), (int, float)):
        limit = int(tenant["bytes"])
    return int(limit)


async def _usage_doc(org_id: str) -> Dict[str, Any]:
    db = get_db()
    doc = await db[USAGE].find_one({"org_id": org_id}, {"_id": 0})
    if not doc:
        doc = {"org_id": org_id, "active_bytes": 0, "trashed_bytes": 0, "reserved_bytes": 0,
               "file_count": 0, "updated_at": utc_now_iso()}
        await db[USAGE].update_one({"org_id": org_id}, {"$setOnInsert": doc}, upsert=True)
    return doc


async def usage_summary(org_id: str) -> Dict[str, Any]:
    u = await _usage_doc(org_id)
    limit = await storage_limit(org_id)
    used = int(u.get("active_bytes", 0)) + int(u.get("trashed_bytes", 0))
    total = used + int(u.get("reserved_bytes", 0))
    pct = round(100 * total / limit, 1) if limit else 0
    return {
        "active_bytes": int(u.get("active_bytes", 0)),
        "trashed_bytes": int(u.get("trashed_bytes", 0)),
        "reserved_bytes": int(u.get("reserved_bytes", 0)),
        "used_bytes": used,
        "available_bytes": max(0, limit - total),
        "limit_bytes": limit,
        "file_count": int(u.get("file_count", 0)),
        "percent": pct,
        "warn": pct >= 70,
        "critical": pct >= 90,
        "full": pct >= 100,
    }


async def _reserve_bytes(org_id: str, n: int) -> bool:
    """Atomically reserve n bytes iff active+trashed+reserved+n <= limit."""
    await _usage_doc(org_id)
    limit = await storage_limit(org_id)
    db = get_db()
    res = await db[USAGE].find_one_and_update(
        {"org_id": org_id,
         "$expr": {"$lte": [{"$add": ["$active_bytes", "$trashed_bytes", "$reserved_bytes", n]}, limit]}},
        {"$inc": {"reserved_bytes": n}, "$set": {"updated_at": utc_now_iso()}})
    return res is not None


async def _release_reserved(org_id: str, n: int) -> None:
    if n <= 0:
        return
    await get_db()[USAGE].update_one({"org_id": org_id}, {"$inc": {"reserved_bytes": -n}})
    await get_db()[USAGE].update_one({"org_id": org_id, "reserved_bytes": {"$lt": 0}},
                                     {"$set": {"reserved_bytes": 0}})


async def _commit_active(org_id: str, reserved: int, actual: int) -> None:
    db = get_db()
    await db[USAGE].update_one({"org_id": org_id},
                              {"$inc": {"reserved_bytes": -reserved, "active_bytes": actual, "file_count": 1},
                               "$set": {"updated_at": utc_now_iso()}})
    await db[USAGE].update_one({"org_id": org_id, "reserved_bytes": {"$lt": 0}},
                              {"$set": {"reserved_bytes": 0}})


# --------------------------------------------------------------------------- upload flow
async def init_upload(org_id: str, user_id: str, *, filename: str, mime: str, size: int,
                      category: str = "other", visibility: str = "public",
                      idempotency_key: Optional[str] = None) -> Dict[str, Any]:
    if mime not in ALLOWED_MIME:
        raise HTTPException(415, {"error": "mime_not_allowed", "mime": mime})
    if size <= 0 or size > MAX_FILE_BYTES:
        raise HTTPException(413, {"error": "file_too_large", "max_bytes": MAX_FILE_BYTES})
    db = get_db()
    # Opportunistically release any of this tenant's abandoned reservations before checking quota.
    try:
        await sweep_expired_reservations(org_id)
    except Exception:  # noqa: BLE001
        pass
    if idempotency_key:
        ex = await db[RESV].find_one({"org_id": org_id, "idempotency_key": idempotency_key,
                                      "status": "reserved"}, {"_id": 0})
        if ex:
            return {"upload_id": ex["id"], "max_bytes": MAX_FILE_BYTES, "reused": True}
    if not await _reserve_bytes(org_id, size):
        raise HTTPException(402, {"error": "storage_limit_reached",
                                  "message": "You've reached your plan's storage allowance. Free space or upgrade.",
                                  "upgrade_url": "/app/billing"})
    rid = uuid.uuid4().hex
    doc = {
        "id": rid, "org_id": org_id, "user_id": user_id, "expected_size": int(size),
        "reserved_bytes": int(size), "mime": mime, "category": category, "visibility": visibility,
        "filename": safe_name(filename), "idempotency_key": idempotency_key,
        "status": "reserved", "created_at": utc_now_iso(),
        "expires_at": _iso(_now() + timedelta(seconds=RESERVATION_TTL_S)),
    }
    try:
        await db[RESV].insert_one(doc)
    except Exception:  # noqa: BLE001 — unique idempotency clash → a concurrent init already reserved
        await _release_reserved(org_id, int(size))
        if idempotency_key:
            ex = await db[RESV].find_one({"org_id": org_id, "idempotency_key": idempotency_key,
                                          "status": "reserved"}, {"_id": 0})
            if ex:
                return {"upload_id": ex["id"], "max_bytes": MAX_FILE_BYTES, "reused": True}
        raise HTTPException(409, {"error": "reservation_conflict"})
    return {"upload_id": rid, "max_bytes": MAX_FILE_BYTES}


async def cancel_upload(org_id: str, upload_id: str) -> Dict[str, Any]:
    db = get_db()
    r = await db[RESV].find_one_and_update(
        {"org_id": org_id, "id": upload_id, "status": "reserved"},
        {"$set": {"status": "cancelled", "cancelled_at": utc_now_iso()}})
    if r:
        await _release_reserved(org_id, int(r.get("reserved_bytes", 0)))
    return {"ok": bool(r)}


async def finalize_upload(org_id: str, user_id: str, upload_id: str, raw: bytes, *,
                          alt_text: Optional[str] = None, caption: Optional[str] = None,
                          folder: Optional[str] = None, tags: Optional[List[str]] = None,
                          source: str = "upload") -> Dict[str, Any]:
    db = get_db()
    # Atomically CLAIM the reservation (reserved → finalizing) so two concurrent finalize calls for
    # the same upload can never both commit bytes / create two assets.
    resv = await db[RESV].find_one_and_update(
        {"org_id": org_id, "id": upload_id, "status": "reserved"},
        {"$set": {"status": "finalizing", "finalizing_at": utc_now_iso()}})
    if not resv:
        existing = await db[RESV].find_one({"org_id": org_id, "id": upload_id}, {"_id": 0, "status": 1})
        if existing and existing.get("status") in ("finalizing", "completed", "deduped"):
            raise HTTPException(409, {"error": "reservation_already_finalized"})
        raise HTTPException(404, {"error": "reservation_not_found"})
    reserved = int(resv.get("reserved_bytes", 0))
    mime = resv["mime"]
    extra_reserved = 0  # any delta reserved above the original reservation
    try:
        actual = len(raw)
        if actual == 0 or actual > MAX_FILE_BYTES:
            raise HTTPException(413, {"error": "file_too_large"})
        sniffed = _sniff(raw)
        # documents (pdf/text/office) trust declared allowed mime; images must match magic bytes
        if mime in IMAGE_MIME and sniffed != mime:
            raise HTTPException(415, {"error": "content_mismatch", "declared": mime, "detected": sniffed})
        width = height = None
        if mime == "image/svg+xml":
            clean = sanitize_svg(raw.decode("utf-8", errors="ignore"))
            if not clean:
                raise HTTPException(400, {"error": "svg_unsafe"})
            raw = clean.encode("utf-8")
            actual = len(raw)
        elif mime in ("image/png", "image/jpeg", "image/webp", "image/gif"):
            raw, width, height = _process_image(raw, mime)
            actual = len(raw)
        # INVARIANT: never trust the client-declared size — reconcile the REAL stored byte count
        # against the tenant allowance before committing. If the object is larger than reserved,
        # atomically reserve the delta; if that would exceed the plan, reject (and release below).
        if actual > reserved:
            delta = actual - reserved
            if not await _reserve_bytes(org_id, delta):
                raise HTTPException(402, {"error": "storage_limit_reached",
                                          "message": "This file would exceed your plan's storage allowance.",
                                          "upgrade_url": "/app/billing"})
            extra_reserved = delta
        sha = hashlib.sha256(raw).hexdigest()
        # duplicate detection WITHIN the same tenant only (never cross-tenant)
        dup = await db[ASSETS].find_one({"org_id": org_id, "sha256": sha, "trashed_at": None}, {"_id": 0})
        if dup:
            await _release_reserved(org_id, reserved + extra_reserved)
            await db[RESV].update_one({"id": upload_id}, {"$set": {"status": "deduped", "asset_id": dup["id"]}})
            dup["url"] = await public_or_signed_url(dup)
            return {**dup, "deduplicated": True}
        asset_id = uuid.uuid4().hex
        key = storage.object_key(org_id, asset_id, "original")
        provider = await storage.get_provider()
        await provider.put(key, raw, content_type=mime)
        # verify the bytes are actually there
        head = await provider.head(key)
        if not head.get("exists"):
            raise HTTPException(502, {"error": "provider_verify_failed"})
        cfg_version = await storage.current_config_version()
        doc = {
            "id": asset_id, "org_id": org_id, "provider": getattr(provider, "provider", "local"),
            "bucket": getattr(provider, "bucket", None), "endpoint": getattr(provider, "endpoint", None),
            "region": getattr(provider, "region", None), "public_base": getattr(provider, "public_base", None),
            "provider_config_version": cfg_version, "object_key": key,
            "filename": resv.get("filename") or "file", "display_name": resv.get("filename") or "file",
            "mime": mime, "media_type": _media_type(mime), "size_bytes": actual, "sha256": sha,
            "width": width, "height": height, "duration": None,
            "visibility": (resv.get("visibility") or "public"),
            "category": (resv.get("category") if resv.get("category") in CATEGORIES else "other"),
            "folder": folder, "tags": [str(t)[:60] for t in (tags or [])][:30],
            "alt_text": alt_text, "caption": caption, "source": source, "provenance": {},
            "original_asset_id": None, "variants": {}, "thumb": None,
            "uploaded_by": user_id, "processing_status": "ready", "scan_status": "skipped",
            "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
            "trashed_at": None, "purge_at": None,
        }
        await db[ASSETS].insert_one(dict(doc))
        # commit EXACTLY the real byte count; release the full (original + delta) reservation.
        await _commit_active(org_id, reserved + extra_reserved, actual)
        await db[RESV].update_one({"id": upload_id}, {"$set": {"status": "completed", "asset_id": asset_id}})
        await _audit(org_id, user_id, "asset.create", {"asset_id": asset_id, "bytes": actual})
        doc.pop("_id", None)
        doc["url"] = await public_or_signed_url(doc)
        return doc
    except HTTPException:
        # Client/validation/verify failure → release EVERYTHING held for this upload.
        await _release_reserved(org_id, reserved + extra_reserved)
        await db[RESV].update_one({"id": upload_id}, {"$set": {"status": "failed", "failed_at": utc_now_iso()}})
        raise
    except Exception as e:  # noqa: BLE001 — provider/unexpected error must ALSO release the reservation
        await _release_reserved(org_id, reserved + extra_reserved)
        await db[RESV].update_one({"id": upload_id},
                                  {"$set": {"status": "failed", "failed_at": utc_now_iso(),
                                            "error": str(e)[:200]}})
        raise HTTPException(502, {"error": "upload_failed",
                                  "message": "Storage provider error — nothing was charged to your quota."})


def _process_image(raw: bytes, mime: str):
    """Decompression-bomb guard, dimension read, EXIF strip (re-encode), orientation."""
    from PIL import Image, ImageOps
    Image.MAX_IMAGE_PIXELS = 40_000_000  # ~40MP bomb guard
    try:
        im = Image.open(io.BytesIO(raw))
        im.verify()
        im = Image.open(io.BytesIO(raw))
        if mime == "image/gif":
            return raw, im.width, im.height  # keep animation; no re-encode
        im = ImageOps.exif_transpose(im)
        w, h = im.size
        if w > 8000 or h > 8000:
            raise HTTPException(413, {"error": "image_dimensions_too_large"})
        out = io.BytesIO()
        fmt = {"image/png": "PNG", "image/jpeg": "JPEG", "image/webp": "WEBP"}[mime]
        if fmt == "JPEG" and im.mode in ("RGBA", "P"):
            im = im.convert("RGB")
        im.save(out, format=fmt)  # re-encode drops EXIF/location metadata
        return out.getvalue(), w, h
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(400, {"error": "invalid_image"})


# --------------------------------------------------------------------------- listing / crud
async def list_assets(org_id: str, *, category: Optional[str] = None, folder: Optional[str] = None,
                      q: Optional[str] = None, trashed: bool = False, unused: bool = False,
                      sort: str = "-created_at", page: int = 1, page_size: int = 40) -> Dict[str, Any]:
    db = get_db()
    page = max(1, int(page)); page_size = min(100, max(1, int(page_size)))
    query: Dict[str, Any] = {"org_id": org_id, "trashed_at": ({"$ne": None} if trashed else None)}
    if category and category in CATEGORIES:
        query["category"] = category
    if folder:
        query["folder"] = folder
    if q:
        rx = {"$regex": re.escape(str(q)[:120]), "$options": "i"}
        query["$or"] = [{"filename": rx}, {"display_name": rx}, {"alt_text": rx},
                        {"caption": rx}, {"tags": rx}]
    field = sort.lstrip("-")
    direction = -1 if sort.startswith("-") else 1
    field = field if field in ("created_at", "updated_at", "filename", "size_bytes") else "created_at"
    total = await db[ASSETS].count_documents(query)
    cur = db[ASSETS].find(query, {"_id": 0}).sort(field, direction).skip((page - 1) * page_size).limit(page_size)
    items = [a async for a in cur]
    if unused:
        keep = []
        for a in items:
            if await db[REFS].count_documents({"org_id": org_id, "asset_id": a["id"]}) == 0:
                keep.append(a)
        items = keep
    for a in items:
        a["url"] = await public_or_signed_url(a)
    return {"assets": items, "total": total, "page": page, "page_size": page_size,
            "pages": (total + page_size - 1) // page_size}


async def get_asset(org_id: str, asset_id: str) -> Dict[str, Any]:
    doc = await get_db()[ASSETS].find_one({"org_id": org_id, "id": asset_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, {"error": "asset_not_found"})
    doc["url"] = await public_or_signed_url(doc)
    return doc


async def public_or_signed_url(asset: Dict[str, Any]) -> str:
    # Resolve through the asset's OWN recorded provider (never the tenant's current provider),
    # so switching the active provider never breaks already-uploaded assets.
    prov = await storage.get_provider_for(asset)
    key = asset["object_key"]
    if asset.get("visibility") == "public":
        return prov.public_url(key)
    return prov.signed_url(key, ttl=600)


async def signed_url_info(org_id: str, asset_id: str, ttl: int = 3600) -> Dict[str, Any]:
    """Return a time-limited URL for an asset whose reported `expires_at` equals the requested
    future expiry (now + ttl) — never the current time."""
    ttl = max(60, min(int(ttl or 3600), 7 * 24 * 3600))
    asset = await get_asset(org_id, asset_id)
    prov = await storage.get_provider_for(asset)
    url = prov.signed_url(asset["object_key"], ttl=ttl)
    expires = _now() + timedelta(seconds=ttl)
    return {"url": url, "expires_at": _iso(expires), "expires_in": ttl,
            "visibility": asset.get("visibility")}


async def update_asset(org_id: str, asset_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    upd = {"updated_at": utc_now_iso()}
    for k in ("display_name", "alt_text", "caption", "folder", "visibility"):
        if k in patch and patch[k] is not None:
            upd[k] = str(patch[k])[:300]
    if "category" in patch and patch["category"] in CATEGORIES:
        upd["category"] = patch["category"]
    if "tags" in patch and isinstance(patch["tags"], list):
        upd["tags"] = [str(t)[:60] for t in patch["tags"]][:30]
    r = await get_db()[ASSETS].update_one({"org_id": org_id, "id": asset_id}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(404, {"error": "asset_not_found"})
    return await get_asset(org_id, asset_id)


# --------------------------------------------------------------------------- references
async def list_references(org_id: str, asset_id: str) -> List[Dict[str, Any]]:
    out = []
    async for r in get_db()[REFS].find({"org_id": org_id, "asset_id": asset_id}, {"_id": 0}):
        out.append(r)
    return out


async def add_reference(org_id: str, asset_id: str, *, feature: str, record_id: str,
                        usage_type: str = "content", meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    doc = {"id": uuid.uuid4().hex, "org_id": org_id, "asset_id": asset_id, "feature": feature,
           "record_id": record_id, "usage_type": usage_type, "meta": meta or {},
           "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    await get_db()[REFS].update_one(
        {"org_id": org_id, "asset_id": asset_id, "feature": feature, "record_id": record_id},
        {"$set": doc}, upsert=True)
    return doc


async def remove_reference(org_id: str, asset_id: str, feature: str, record_id: str) -> None:
    await get_db()[REFS].delete_one({"org_id": org_id, "asset_id": asset_id,
                                     "feature": feature, "record_id": record_id})


# --------------------------------------------------------------------------- trash / restore / purge
async def trash_asset(org_id: str, user_id: str, asset_id: str) -> Dict[str, Any]:
    db = get_db()
    # Atomically flip active → trashed so byte accounting moves exactly once even under concurrency.
    a = await db[ASSETS].find_one_and_update(
        {"org_id": org_id, "id": asset_id, "trashed_at": None},
        {"$set": {"trashed_at": utc_now_iso(),
                  "purge_at": _iso(_now() + timedelta(days=TRASH_RETENTION_DAYS)),
                  "updated_at": utc_now_iso()}})
    if not a:
        raise HTTPException(404, {"error": "asset_not_found"})
    n = int(a.get("size_bytes", 0))
    await db[USAGE].update_one({"org_id": org_id}, {"$inc": {"active_bytes": -n, "trashed_bytes": n, "file_count": -1}})
    await _fix_neg(org_id)
    await _audit(org_id, user_id, "asset.trash", {"asset_id": asset_id})
    return {"ok": True}


async def restore_asset(org_id: str, user_id: str, asset_id: str) -> Dict[str, Any]:
    db = get_db()
    a = await db[ASSETS].find_one_and_update(
        {"org_id": org_id, "id": asset_id, "trashed_at": {"$ne": None}},
        {"$set": {"trashed_at": None, "purge_at": None, "updated_at": utc_now_iso()}})
    if not a:
        raise HTTPException(404, {"error": "asset_not_found"})
    n = int(a.get("size_bytes", 0))
    await db[USAGE].update_one({"org_id": org_id}, {"$inc": {"trashed_bytes": -n, "active_bytes": n, "file_count": 1}})
    await _fix_neg(org_id)
    await _audit(org_id, user_id, "asset.restore", {"asset_id": asset_id})
    return {"ok": True}


async def purge_asset(org_id: str, user_id: str, asset_id: str, *, force: bool = False) -> Dict[str, Any]:
    db = get_db()
    # Block permanent deletion of an asset still referenced by live content unless the caller has
    # explicitly resolved/replaced those references (force). Prevents silently breaking published pages.
    ref_count = await db[REFS].count_documents({"org_id": org_id, "asset_id": asset_id})
    if ref_count > 0 and not force:
        raise HTTPException(409, {"error": "asset_referenced", "references": ref_count,
                                  "message": "This asset is still used. Replace or remove those uses first."})
    # Atomically CLAIM (delete) the trashed asset so concurrent purges can't double-count freed bytes.
    a = await db[ASSETS].find_one_and_delete({"org_id": org_id, "id": asset_id, "trashed_at": {"$ne": None}})
    if not a:
        raise HTTPException(404, {"error": "asset_not_found_in_trash"})
    try:
        prov = await storage.get_provider_for(a)
        await prov.delete(a["object_key"])
        for v in (a.get("variants") or {}).values():
            if isinstance(v, dict) and v.get("key"):
                await prov.delete(v["key"])
    except Exception:  # noqa: BLE001 — record for dead-letter reconciliation
        await db.storage_delete_failures.insert_one({"org_id": org_id, "asset_id": asset_id,
                                                     "key": a["object_key"], "at": utc_now_iso()})
    await db[REFS].delete_many({"org_id": org_id, "asset_id": asset_id})
    n = int(a.get("size_bytes", 0))
    # bytes reconciled exactly once (this caller won the atomic delete claim above)
    await db[USAGE].update_one({"org_id": org_id}, {"$inc": {"trashed_bytes": -n}})
    await _fix_neg(org_id)
    await _audit(org_id, user_id, "asset.purge", {"asset_id": asset_id, "bytes": n})
    return {"ok": True, "freed_bytes": n}


async def _fix_neg(org_id: str) -> None:
    for f in ("active_bytes", "trashed_bytes", "reserved_bytes", "file_count"):
        await get_db()[USAGE].update_one({"org_id": org_id, f: {"$lt": 0}}, {"$set": {f: 0}})


async def reconcile(org_id: str) -> Dict[str, Any]:
    """Recompute usage counters from the assets collection (source of truth)."""
    db = get_db()
    active = trashed = fcount = 0
    async for a in db[ASSETS].find({"org_id": org_id}, {"size_bytes": 1, "trashed_at": 1}):
        b = int(a.get("size_bytes", 0))
        if a.get("trashed_at"):
            trashed += b
        else:
            active += b; fcount += 1
    await db[USAGE].update_one({"org_id": org_id},
                               {"$set": {"active_bytes": active, "trashed_bytes": trashed,
                                         "reserved_bytes": 0, "file_count": fcount,
                                         "last_reconciliation": utc_now_iso()}}, upsert=True)
    return await usage_summary(org_id)


async def breakdown(org_id: str) -> Dict[str, Any]:
    db = get_db()
    cats: Dict[str, Dict[str, int]] = {}
    async for a in db[ASSETS].find({"org_id": org_id, "trashed_at": None}, {"category": 1, "size_bytes": 1}):
        c = a.get("category") or "other"
        cats.setdefault(c, {"bytes": 0, "count": 0})
        cats[c]["bytes"] += int(a.get("size_bytes", 0)); cats[c]["count"] += 1
    largest = [x async for x in db[ASSETS].find({"org_id": org_id, "trashed_at": None},
               {"_id": 0, "id": 1, "filename": 1, "size_bytes": 1}).sort("size_bytes", -1).limit(10)]
    return {"by_category": cats, "largest": largest}


async def _audit(org_id: str, user_id: Optional[str], action: str, meta: Dict[str, Any]) -> None:
    try:
        await get_db().storage_audit.insert_one({"id": uuid.uuid4().hex, "org_id": org_id,
                                                 "user_id": user_id, "action": action, "meta": meta,
                                                 "created_at": utc_now_iso()})
    except Exception:  # noqa: BLE001
        pass


async def ensure_indexes() -> None:
    db = get_db()

    async def _mk(coll, keys, **opts):
        try:
            await db[coll].create_index(keys, **opts)
        except Exception:  # noqa: BLE001 — isolate each index so one conflict can't block the rest
            pass

    await _mk(ASSETS, [("org_id", 1), ("trashed_at", 1), ("created_at", -1)])
    await _mk(ASSETS, [("org_id", 1), ("sha256", 1)])
    await _mk(ASSETS, [("org_id", 1), ("category", 1)])
    await _mk(REFS, [("org_id", 1), ("asset_id", 1)])
    # DB-enforced idempotency: at most one ACTIVE reservation per (org, idempotency_key).
    try:
        await db[RESV].drop_index("org_id_1_idempotency_key_1")
    except Exception:  # noqa: BLE001
        pass
    # Collapse any pre-existing duplicate active reservations so the unique index can build.
    try:
        seen: set = set()
        async for r in db[RESV].find({"status": "reserved", "idempotency_key": {"$type": "string"}},
                                     {"org_id": 1, "idempotency_key": 1}).sort("_id", 1):
            k = (r["org_id"], r["idempotency_key"])
            if k in seen:
                await db[RESV].update_one({"_id": r["_id"]}, {"$set": {"status": "superseded"}})
            else:
                seen.add(k)
    except Exception:  # noqa: BLE001
        pass
    await _mk(RESV, [("org_id", 1), ("idempotency_key", 1)], unique=True, name="uniq_active_idem",
              partialFilterExpression={"idempotency_key": {"$type": "string"}, "status": "reserved"})
    await _mk(RESV, [("status", 1), ("expires_at", 1)])
    await _mk(RESV, [("org_id", 1), ("id", 1)], unique=True, name="uniq_org_upload")
    await _mk(USAGE, [("org_id", 1)], unique=True)
