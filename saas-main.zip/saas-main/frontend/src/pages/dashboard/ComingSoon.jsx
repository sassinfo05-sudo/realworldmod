import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Sparkles } from "lucide-react";

const COPY = {
    crm: {
        title: "CRM",
        promise: "Every customer, quote and conversation — one place.",
        details: "The CRM opens with your Launch plan. It'll import contacts, dedupe them, and thread every message, quote and payment against the right person.",
    },
    inbox: {
        title: "Inbox",
        promise: "One inbox for calls, emails and web messages.",
        details: "Connect your business email and phone number in Settings → Integrations. Your AI receptionist drafts replies; you approve them with a tap.",
    },
    calendar: {
        title: "Calendar",
        promise: "Online booking that respects your real schedule.",
        details: "Set your working hours, buffers and travel time. Customers pick a slot from your site; the calendar handles reminders and no-shows.",
    },
    payments: {
        title: "Payments",
        promise: "Quote → approval → paid, without the paper trail.",
        details: "Send quotes from any job. Take deposits, milestone payments and final invoices via card or ACH. Payouts direct to your bank.",
    },
    ai_employees: {
        title: "AI Employees",
        promise: "A receptionist, a quote drafter, and a reputation manager.",
        details: "Configure tone and boundaries. They work from your business profile, so they never invent facts.",
    },
    marketing: {
        title: "Marketing",
        promise: "The next campaign, already written.",
        details: "Email + SMS follow-ups triggered by real events: new lead, missed call, invoice paid, review requested.",
    },
    settings: {
        title: "Settings",
        promise: "You'll edit the essentials here.",
        details: "Team seats, roles, brand, plan and payout accounts live here. Some sections come online with their module.",
    },
};

export default function ComingSoon({ moduleKey }) {
    const c = COPY[moduleKey] || { title: moduleKey, promise: "", details: "" };
    const [next, setNext] = useState(null);

    useEffect(() => {
        api.get("/dashboard/summary").then((r) => {
            const m = (r.data.modules || []).find((x) => x.key === moduleKey);
            setNext(m?.next_action || null);
        }).catch(() => {});
    }, [moduleKey]);

    return (
        <div className="p-6 md:p-10 max-w-2xl" data-testid={`coming-soon-${moduleKey}`}>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">
                <Sparkles className="w-3.5 h-3.5" />
                Coming in setup
            </div>
            <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium leading-tight">
                {c.title}: {c.promise}
            </h1>
            <p className="mt-4 text-zinc-600 leading-relaxed">{c.details}</p>

            <div className="mt-8 rounded-2xl border border-brand-line bg-white p-5">
                <div className="text-xs uppercase tracking-widest text-zinc-500">Next action</div>
                <div className="mt-1 text-brand-ink font-medium" data-testid={`coming-soon-${moduleKey}-next`}>
                    {next || "Nothing required — we'll notify you when this opens."}
                </div>
            </div>
        </div>
    );
}
