"""FastAPI app entrypoint.

- All routes under /api
- CORS from env
- Seed on startup (idempotent)
"""
import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

# Import after load_dotenv so config picks up env
from app.routes import ai as ai_routes  # noqa: E402
from app.routes import auth as auth_routes  # noqa: E402
from app.routes import auth_ext as auth_ext_routes  # noqa: E402
from app.routes import auth_oauth as auth_oauth_routes  # noqa: E402
from app.routes import billing as billing_routes  # noqa: E402
from app.routes import bookings as bookings_routes  # noqa: E402
from app.routes import business_profile as bp_routes  # noqa: E402
from app.routes import crm as crm_routes  # noqa: E402
from app.routes import dashboard as dash_routes  # noqa: E402
from app.routes import domains as domain_routes  # noqa: E402
from app.routes import editor as editor_routes  # noqa: E402
from app.routes import blog as blog_routes  # noqa: E402
from app.routes import commerce_ext as commerce_ext_routes  # noqa: E402
from app.routes import analytics as analytics_reports_routes  # noqa: E402
from app.routes import workflows as workflow_routes  # noqa: E402
from app.routes import founder as founder_routes  # noqa: E402
from app.routes import import_site as import_routes  # noqa: E402
from app.routes import inbox as inbox_routes  # noqa: E402
from app.routes import media_forms_analytics as mfa_routes  # noqa: E402
from app.routes import onboarding as ob_routes  # noqa: E402
from app.routes import platform_admin as platform_admin_routes  # noqa: E402
from app.routes import public as public_routes  # noqa: E402
from app.routes import public_api as public_api_routes  # noqa: E402
from app.routes import public_sites as public_sites_routes  # noqa: E402
from app.routes import tenant as tenant_routes  # noqa: E402
from app.routes import marketing as marketing_routes  # noqa: E402
from app.routes import setup as setup_routes  # noqa: E402
from app.routes import store as store_routes  # noqa: E402
from app.routes import ecommerce as ecommerce_routes  # noqa: E402
from app.routes import shipping as shipping_routes  # noqa: E402
from app.routes import branding as branding_routes  # noqa: E402
from app.routes import localization as localization_routes  # noqa: E402
from app.routes import voice as voice_routes  # noqa: E402
from app.routes import support as support_routes  # noqa: E402
from app.routes import website as website_routes  # noqa: E402
from app.routes import staff as staff_routes  # noqa: E402
from app.routes import staff_email as staff_email_routes  # noqa: E402
from app.routes import email_inbound as email_inbound_routes  # noqa: E402
from app.routes import staff_support as staff_support_routes  # noqa: E402
from app.routes import sites as sites_routes  # noqa: E402
from app.routes import numbers as numbers_routes  # noqa: E402
from app.routes import insights as insights_routes  # noqa: E402
from app.routes import usage as usage_routes  # noqa: E402
from app.routes import gift_cards as gift_cards_routes  # noqa: E402
from app.routes import shop_customers as shop_customers_routes  # noqa: E402
from app.routes import subscriptions as subscription_routes  # noqa: E402
from app.services.seed import seed_all  # noqa: E402
from app.services.seed_crm import seed_crm_demo, backfill_existing_form_submissions  # noqa: E402
from app.services.seed_demo import seed_demo_site  # noqa: E402
from app.services.seed_phase4 import seed_phase4_demo  # noqa: E402
from app.services.seed_phase5 import seed_phase5_demo  # noqa: E402
from app.services.seed_phase6 import seed_phase6  # noqa: E402
from app.services.seed_phase7 import seed_phase7  # noqa: E402
from app.services.migrations import run_phase4_percent_migration  # noqa: E402


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("zanelvo")



def _read_build_sha() -> str:
    """Best effort: env BUILD_SHA / GIT_SHA, else .git HEAD (short). Empty string when unknown."""
    for k in ("BUILD_SHA", "GIT_SHA", "SOURCE_VERSION"):
        if os.environ.get(k):
            return os.environ[k][:12]
    try:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        head = open(os.path.join(root, ".git", "HEAD")).read().strip()
        if head.startswith("ref:"):
            ref = head.split(" ", 1)[1]
            return open(os.path.join(root, ".git", ref)).read().strip()[:12]
        return head[:12]
    except Exception:  # noqa: BLE001
        return ""


BUILD_SHA = _read_build_sha()
PROCESS_STARTED_AT = __import__("time").time()

app = FastAPI(
    title="Zanelvo API",
    description="Zanelvo — build, publish and grow your business website with AI.",
    version="0.8.0",
    openapi_url="/api/openapi.json",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

api = APIRouter(prefix="/api")


@api.get("/")
async def root():
    return {"service": "zanelvo", "status": "ok"}


@api.get("/readiness")
async def readiness():
    """Production readiness: DB, public origin, storage and platform-email state. Distinguishes
    'application ready' (code + DB) from 'external provider not configured' (owner setup pending).
    Never leaks secrets. 200 with ready=false when the app is up but external setup is incomplete."""
    import time as _time
    out = {"app": {"ok": True, "build": BUILD_SHA, "env": os.environ.get("APP_ENV", "dev")},
           "checks": {}, "external": {}}
    # DB connectivity (required for app-ready)
    db_ok = False
    try:
        t0 = _time.perf_counter()
        from app.db import get_db as _gdb
        await _gdb().command("ping")
        db_ok = True
        out["checks"]["database"] = {"ok": True, "latency_ms": round((_time.perf_counter() - t0) * 1000, 1)}
    except Exception as e:  # noqa: BLE001
        out["checks"]["database"] = {"ok": False, "error": str(e)[:120]}
    # Public origin / product URL (required in production)
    try:
        from app.services import platform_settings as _ps
        settings = await _ps.get_settings()
        origin = (settings.get("product_url") or os.environ.get("PUBLIC_BASE_URL") or "").strip()
    except Exception:  # noqa: BLE001
        origin = (os.environ.get("PUBLIC_BASE_URL") or "").strip()
    out["checks"]["public_origin"] = {"ok": bool(origin), "value": origin or None}
    # Storage provider (external — owner setup)
    try:
        from app.services import storage as _st
        st = await _st.provider_status()
        out["external"]["storage"] = {"configured": bool(st.get("configured")), "status": st.get("status")}
    except Exception as e:  # noqa: BLE001
        out["external"]["storage"] = {"configured": False, "error": str(e)[:120]}
    # Platform email sender (external — owner setup)
    try:
        from app.services import twofa as _twofa
        out["external"]["platform_email"] = {"configured": bool(await _twofa.email_2fa_available())}
    except Exception as e:  # noqa: BLE001
        out["external"]["platform_email"] = {"configured": False, "error": str(e)[:120]}
    # app_ready = code + DB (+ origin in production). external_ready = every external provider connected.
    is_prod = os.environ.get("APP_ENV", "dev").strip().lower() not in ("dev", "test", "demo")
    app_ready = bool(db_ok and (origin or not is_prod))
    external_ready = bool(out["external"].get("storage", {}).get("configured")
                          and out["external"].get("platform_email", {}).get("configured"))
    out["app_ready"] = app_ready
    out["external_ready"] = external_ready
    out["ready"] = app_ready  # liveness/readiness of the APPLICATION itself
    out["pending_owner_setup"] = [k for k, v in out["external"].items() if not v.get("configured")]
    return out


@api.get("/health")
async def health():
    """Liveness + deployment info (Round 11): build SHA, uptime, DB ping latency. Never leaks secrets."""
    import time as _time
    out = {"ok": True, "build": BUILD_SHA, "env": os.environ.get("APP_ENV", "dev"),
           "uptime_seconds": int(_time.time() - PROCESS_STARTED_AT)}
    try:
        t0 = _time.perf_counter()
        from app.db import get_db as _gdb_h
        await _gdb_h().command("ping")
        out["db"] = {"ok": True, "latency_ms": round((_time.perf_counter() - t0) * 1000, 1)}
    except Exception as e:  # noqa: BLE001
        out["ok"] = False
        out["db"] = {"ok": False, "error": str(e)[:120]}
    return out


api.include_router(public_routes.router)
api.include_router(auth_routes.router)
api.include_router(ob_routes.router)
api.include_router(bp_routes.router)
api.include_router(website_routes.router)
api.include_router(dash_routes.router)
api.include_router(editor_routes.router)
api.include_router(public_sites_routes.router)
api.include_router(blog_routes.router)
api.include_router(blog_routes.public_router)
api.include_router(domain_routes.router)
api.include_router(mfa_routes.router)
api.include_router(import_routes.router)
api.include_router(crm_routes.router)
api.include_router(inbox_routes.router)
api.include_router(inbox_routes.email_router)
api.include_router(bookings_routes.router)
api.include_router(bookings_routes.quotes_router)
api.include_router(bookings_routes.invoices_router)
api.include_router(bookings_routes.jobs_router)
api.include_router(bookings_routes.public_router)
api.include_router(bookings_routes.public_portal)
api.include_router(bookings_routes.payments_router)
api.include_router(tenant_routes.router)
api.include_router(store_routes.router)
api.include_router(ecommerce_routes.router)
api.include_router(shipping_routes.router)
api.include_router(branding_routes.router)
api.include_router(localization_routes.router)
api.include_router(localization_routes.public_router)
api.include_router(shipping_routes.public_router)
api.include_router(store_routes.public_router)
api.include_router(commerce_ext_routes.router)
api.include_router(analytics_reports_routes.router)
api.include_router(workflow_routes.router)
api.include_router(commerce_ext_routes.public_router)
api.include_router(gift_cards_routes.router)
api.include_router(gift_cards_routes.public_router)
api.include_router(shop_customers_routes.router)
api.include_router(subscription_routes.router)
from app.routes import cms as cms_routes  # noqa: E402
api.include_router(cms_routes.router)
api.include_router(cms_routes.public_router)
from app.routes import assets as assets_routes  # noqa: E402
api.include_router(assets_routes.router)
api.include_router(assets_routes.public_router)
api.include_router(assets_routes.founder_router)
api.include_router(subscription_routes.public_router)
api.include_router(voice_routes.router)
api.include_router(sites_routes.router)
api.include_router(numbers_routes.router)
api.include_router(insights_routes.router)
api.include_router(usage_routes.router)
app.include_router(staff_routes.router)
app.include_router(staff_email_routes.router)
app.include_router(email_inbound_routes.router)
app.include_router(staff_support_routes.router)
# --- Strip the /api prefix from routers that already declare it themselves ---
app.include_router(ai_routes.router)
app.include_router(ai_routes.public_ai)
app.include_router(billing_routes.router)
app.include_router(founder_routes.router)
app.include_router(platform_admin_routes.router)
app.include_router(setup_routes.router)
app.include_router(support_routes.router)
app.include_router(marketing_routes.router)
app.include_router(auth_ext_routes.router)
app.include_router(auth_oauth_routes.router)
app.include_router(public_api_routes.router)
app.include_router(usage_routes.staff_router)
from app.routes import tracking as tracking_routes  # noqa: E402
app.include_router(tracking_routes.router)
from app.routes import competitive as competitive_routes  # noqa: E402
app.include_router(competitive_routes.router)
from app.routes import provider_status as provider_status_routes  # noqa: E402
app.include_router(provider_status_routes.router)

app.include_router(api)

# --- CORS: echo the request Origin so cookie credentials work for any preview/deployed host. ---
# Starlette sends `Access-Control-Allow-Origin: <origin>` (never the literal "*") when a regex is used
# WITH allow_credentials=True, which satisfies the browser's credentials rule. An explicit allow-list
# (CORS_ORIGINS=a,b,c) still restricts to those origins.
from app.config import is_production as _is_prod  # noqa: E402
_origins = [o.strip() for o in os.environ.get("CORS_ORIGINS", "*").split(",") if o.strip()] or ["*"]
_wildcard = "*" in _origins
if _is_prod():
    # PRODUCTION: fail closed. Never combine a wildcard origin / allow_origin_regex=".*"
    # with allow_credentials=True. Require an explicit CORS_ORIGINS allow-list.
    _explicit = [o for o in _origins if o != "*"]
    if _wildcard or not _explicit:
        logger.error(
            "CORS misconfiguration: production requires an explicit CORS_ORIGINS allow-list "
            "(no '*'). Credentialed cross-origin requests are DENIED until CORS_ORIGINS is set."
        )
        # Fail closed: no cross-origin credentialed access is permitted. Same-origin still works.
        app.add_middleware(
            CORSMiddleware,
            allow_credentials=True,
            allow_origins=[],
            allow_methods=["*"],
            allow_headers=["*"],
        )
    else:
        app.add_middleware(
            CORSMiddleware,
            allow_credentials=True,
            allow_origins=_explicit,
            allow_methods=["*"],
            allow_headers=["*"],
        )
elif _wildcard:
    # NON-PRODUCTION only (dev/test/demo preview): echo the request Origin so cookie
    # credentials work across per-job preview hosts. Never used when APP_ENV is production.
    app.add_middleware(
        CORSMiddleware,
        allow_credentials=True,
        allow_origin_regex=".*",
        allow_methods=["*"],
        allow_headers=["*"],
    )
else:
    app.add_middleware(
        CORSMiddleware,
        allow_credentials=True,
        allow_origins=_origins,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# --- Hardening middleware: request-size limit, security headers, request id ---
_MAX_BODY = int(os.environ.get("MAX_REQUEST_BYTES", str(25 * 1024 * 1024)))   # 25 MB (uploads are chunked)
_MAX_JSON_BODY = int(os.environ.get("MAX_JSON_BYTES", str(2 * 1024 * 1024)))  # 2 MB for JSON bodies


@app.middleware("http")
async def _hardening(request, call_next):
    import uuid as _uuid
    from starlette.responses import JSONResponse as _JR
    cl = request.headers.get("content-length")
    if cl and cl.isdigit():
        n = int(cl)
        ctype = (request.headers.get("content-type") or "").lower()
        limit = _MAX_BODY if ("multipart/form-data" in ctype or "octet-stream" in ctype) else _MAX_JSON_BODY
        if n > limit:
            return _JR({"detail": "Request body too large"}, status_code=413)
    rid = request.headers.get("x-request-id") or _uuid.uuid4().hex[:16]
    # Observe + softly rate-limit ALL API traffic (CRUD/auth are never metered as paid usage,
    # but they are counted and abusive clients get 429).
    if request.url.path.startswith("/api/") and request.url.path not in ("/api/health", "/api/"):
        try:
            from app.services import rate_limit as _rl
            _rl.check("api_global", request, limit=int(os.environ.get("API_GLOBAL_RPM", "900")), window_seconds=60)
            _rl.observe(request.url.path)
        except Exception as exc:  # noqa: BLE001
            detail = getattr(exc, "detail", None)
            if getattr(exc, "status_code", None) == 429:
                return _JR({"detail": detail}, status_code=429)
    try:
        from app.services.usage import set_context as _set_ctx, reset_context as _reset_ctx
        _reset_ctx()
        _set_ctx(request_id=rid)
    except Exception:  # noqa: BLE001
        pass
    try:
        resp = await call_next(request)
    except Exception as exc:  # noqa: BLE001
        from bson.errors import InvalidId
        from app.services.llm import LlmError
        if isinstance(exc, InvalidId):
            return _JR({"detail": "Invalid id"}, status_code=400)
        if isinstance(exc, LlmError):
            logger.warning("LLM error on %s: %s", request.url.path, exc)
            return _JR({"detail": "The AI service is temporarily unavailable. Please try again."}, status_code=503)
        raise
    resp.headers["X-Request-Id"] = rid
    # Mirror freshly-issued access tokens into HttpOnly session cookies (dual-mode auth).
    _p0 = request.url.path or ""
    if request.method == "POST" and resp.status_code == 200:
        from app.services import session_cookies as _sc
        if _p0 in _sc.TOKEN_ISSUING_PATHS:
            import json as _json
            from starlette.responses import Response as _Resp
            body = b"".join([chunk async for chunk in resp.body_iterator])
            tok = None
            try:
                tok = (_json.loads(body or b"{}") or {}).get("access_token")
            except Exception:  # noqa: BLE001
                tok = None
            new = _Resp(content=body, status_code=resp.status_code, headers=dict(resp.headers),
                        media_type=resp.media_type)
            if tok:
                _sc.set_session_cookies(new, tok, request)
            resp = new
        elif _p0 in ("/api/auth/logout", "/api/staff/auth/logout"):
            _sc.clear_session_cookies(resp)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    resp.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
    resp.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    # Strict CSP for JSON API responses. Swagger UI (/docs, /redoc) needs inline scripts/CDN,
    # so it is exempted; everything else is locked down (API returns JSON, never HTML/JS).
    _p = request.url.path or ""
    if not (_p.startswith("/docs") or _p.startswith("/redoc") or _p.startswith("/openapi")):
        resp.headers.setdefault("Content-Security-Policy",
                                "default-src 'none'; frame-ancestors 'none'; base-uri 'none'")
    return resp


@app.exception_handler(Exception)
async def _unhandled(request, exc):
    """Invalid Mongo ids and similar caller mistakes must be 400s, never 500s. Everything else
    returns a generic 500 without leaking internals."""
    from bson.errors import InvalidId
    from starlette.responses import JSONResponse as _JR
    if isinstance(exc, InvalidId):
        return _JR({"detail": "Invalid id"}, status_code=400)
    from app.services.llm import LlmError
    if isinstance(exc, LlmError):
        logger.warning("LLM error on %s: %s", request.url.path, exc)
        return _JR({"detail": "The AI service is temporarily unavailable. Please try again."}, status_code=503)
    logger.exception("Unhandled error on %s %s: %s", request.method, request.url.path, exc)
    # Founder "API errors" view: capture a redacted record (no body/PII) in db.error_events.
    try:
        from app.db import get_db as _gdb, utc_now_iso as _now
        await _gdb().error_events.insert_one({
            "method": request.method, "path": request.url.path, "status": 500,
            "error_type": type(exc).__name__, "message": str(exc)[:300],
            "request_id": request.headers.get("x-request-id"), "created_at": _now(),
        })
    except Exception:  # noqa: BLE001
        pass
    return _JR({"detail": "Internal server error"}, status_code=500)

# Demo/seed data requires an EXPLICIT opt-in flag AND a non-production environment.
# It is never enabled implicitly by APP_ENV, so a production deploy that forgets to set
# APP_ENV (which then defaults to "dev") can NEVER silently seed demo data.
from app.config import simulation_allowed as _sim_allowed, is_production as _is_production  # noqa: E402
_SEED_FLAG = os.environ.get("SEED_DEMO_DATA", os.environ.get("SEED_DEMO", "")).lower() in ("1", "true", "yes")
SEED_DEMO = _SEED_FLAG and _sim_allowed()


def _validate_production_config():
    """Fail startup if a production deployment is missing required configuration.
    Never blocks dev/test/demo. This makes APP_ENV meaningful and prevents shipping
    production with wildcard CORS, missing encryption keys, or accidental demo seeding."""
    if not _is_production():
        return
    problems = []
    if not os.environ.get("APP_ENV"):
        problems.append("APP_ENV must be set explicitly in production")
    _co = [o.strip() for o in os.environ.get("CORS_ORIGINS", "").split(",") if o.strip()]
    if not _co or "*" in _co:
        problems.append("CORS_ORIGINS must be an explicit allow-list (no '*') in production")
    if not os.environ.get("SECRETS_ENC_KEY"):
        problems.append("SECRETS_ENC_KEY is required in production")
    if len(os.environ.get("JWT_SECRET", "")) < 32:
        problems.append("JWT_SECRET must be a strong (>=32 char) secret in production")
    if _SEED_FLAG:
        problems.append("SEED_DEMO_DATA must NOT be enabled in production")
    if problems:
        raise RuntimeError("Production configuration incomplete: " + "; ".join(problems))


@app.on_event("startup")
async def _on_startup():
    _validate_production_config()
    try:
        # unique email index — prevents concurrent-signup race duplicates
        from app.db import get_db as _get_db
        await _get_db().users.create_index("email", unique=True)
        await _get_db().organizations.create_index("slug", unique=True)
        await _get_db().llm_usage_events.create_index([("org_id", 1), ("month", 1)])
        await _get_db().llm_usage_events.create_index([("org_id", 1), ("month", 1), ("kind", 1)])
        await _get_db().llm_usage_events.create_index([("idempotency_key", 1)], sparse=True)
        await _get_db().usage_reservations.create_index([("org_id", 1), ("status", 1), ("month", 1)])
        await _get_db().usage_reservations.create_index(
            [("org_id", 1), ("month", 1), ("status", 1), ("kind", 1), ("created_at", 1)])
        await _get_db().password_reset_tokens.create_index("token_hash", sparse=True)
    except Exception as e:  # noqa: BLE001
        logger.warning("Index creation failed: %s", e)
    try:
        from app.services.assets import ensure_indexes as _asset_idx
        await _asset_idx()
    except Exception:  # noqa: BLE001
        pass
    try:
        from app.services.usage import set_context as _seed_ctx
        _seed_ctx(feature="platform/seed")
    except Exception:  # noqa: BLE001
        pass
    try:
        await seed_all()
        from app.routes.staff import ensure_owner_seed
        await ensure_owner_seed()
    except Exception as e:  # noqa: BLE001
        logger.exception("Seed failed: %s", e)
    if not SEED_DEMO:
        logger.info("APP_ENV=%s — demo seeding skipped (set SEED_DEMO_DATA=true to enable).",
                    os.environ.get("APP_ENV"))
    if SEED_DEMO:
      try:
        await seed_demo_site()
      except Exception as e:  # noqa: BLE001
        logger.exception("Demo site seed failed: %s", e)
      try:
        await seed_crm_demo()
      except Exception as e:  # noqa: BLE001
        logger.exception("CRM demo seed failed: %s", e)
      try:
        await seed_phase4_demo()
      except Exception as e:  # noqa: BLE001
        logger.exception("Phase 4 demo seed failed: %s", e)
    try:
        await run_phase4_percent_migration()
    except Exception as e:  # noqa: BLE001
        logger.exception("Phase 4 percent-scale migration failed: %s", e)
    if SEED_DEMO:
      try:
        await seed_phase5_demo()
      except Exception as e:  # noqa: BLE001
        logger.exception("Phase 5 seed failed: %s", e)
      try:
        await seed_phase6()
      except Exception as e:  # noqa: BLE001
        logger.exception("Phase 6 seed failed: %s", e)
      try:
        await seed_phase7()
      except Exception as e:  # noqa: BLE001
        logger.exception("Phase 7 seed failed: %s", e)
    try:
        await backfill_existing_form_submissions()
    except Exception as e:  # noqa: BLE001
        logger.exception("Form submission backfill failed: %s", e)
    # ---- Recurring background jobs (SINGLETON) --------------------------------------------
    # These must run in exactly ONE place: the dedicated worker in production
    # (RUN_SCHEDULERS=true), or the sole web process in dev. A Mongo leader lock ensures that
    # even with multiple replicas only the leader fires them, so no job runs N times.
    import os as _os
    _run_sched = _os.environ.get("RUN_SCHEDULERS")
    if _run_sched is None:
        _run_sched = "false" if _is_production() else "true"
    if str(_run_sched).strip().lower() == "true":
        try:
            import asyncio as _aio

            async def _scheduler_supervisor():
                """Acquire leadership (retrying past a stale lock's TTL after a restart) and start
                the recurring loops exactly once when leadership is first won; keep renewing."""
                from app.services import leader_lock
                from app.services import webhooks as _wh
                from app.services import workflows as _wfs
                started = False
                while True:
                    try:
                        got = await leader_lock.acquire("schedulers")
                        if got and not started:
                            started = True
                            inbox_routes.start_scheduled_send_loop()
                            _aio.get_event_loop().create_task(_wfs.scheduler_loop())
                            store_routes.start_abandoned_sweep_loop()
                            subscription_routes.start_renewal_loop()
                            _aio.get_event_loop().create_task(_wh.retry_loop())
                            logger.info("Recurring schedulers started (leader=%s)", leader_lock.INSTANCE_ID)
                    except Exception as e:  # noqa: BLE001
                        logger.warning("scheduler supervisor error: %s", e)
                    await _aio.sleep(30)

            _aio.get_event_loop().create_task(_scheduler_supervisor())
        except Exception as e:  # noqa: BLE001
            logger.exception("Scheduler startup failed: %s", e)
    else:
        logger.info("RUN_SCHEDULERS=false — recurring loops disabled here (a dedicated worker runs them).")
    # Load founder-editable plan limit overrides into the entitlements table.
    try:
        from app.services.entitlements import apply_db_overrides
        from app.db import get_db as _gdb
        _plans = [p async for p in _gdb().plans.find({})]
        apply_db_overrides(_plans)
    except Exception as e:  # noqa: BLE001
        logger.exception("Plan override load failed: %s", e)
    # Cost/usage indexes: unique tenant-scoped idempotency + reservation lookups.
    # (expires_at is stored as an ISO string and checked in code, so no TTL index here.)
    try:
        from app.db import get_db as _gdb2
        _db = _gdb2()
        await _db.usage_idempotency.create_index("skey", unique=True, sparse=True)
        await _db.usage_reservations.create_index([("org_id", 1), ("status", 1), ("month", 1)])
    except Exception as e:  # noqa: BLE001
        logger.exception("Usage index creation failed: %s", e)


@app.on_event("shutdown")
async def _on_shutdown():
    from app.db import get_client
    get_client().close()
