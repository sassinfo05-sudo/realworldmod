import { useEditor } from "./EditorProvider";
import BlockRenderer from "@/components/BlockRenderer";
import AddSectionMenu from "./AddSectionMenu";
import {
    DndContext, PointerSensor, useSensor, useSensors, closestCenter,
} from "@dnd-kit/core";
import { SortableContext, useSortable, verticalListSortingStrategy, arrayMove } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
    GripVertical, Trash2, Copy, ArrowUp, ArrowDown, Eye, EyeOff,
} from "lucide-react";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const DEVICE_WIDTHS = { desktop: 1280, tablet: 820, mobile: 390 };
const DEVICE_SCALES = { desktop: 0.62, tablet: 0.72, mobile: 1.0 };

/** BlockToolbar — explicit, keyboard-accessible controls for every section.
 *  Rendered outside the scaled canvas transform so it's always crisp and easy to hit. */
function BlockToolbar({ block, isFirst, isLast, dragAttributes, dragListeners }) {
    const {
        selectedBlockId, setSelectedBlockId,
        moveBlock, duplicateBlock, removeBlock, toggleBlockHidden,
    } = useEditor();
    const isSelected = selectedBlockId === block.id;
    const btn = "p-1.5 rounded text-zinc-600 hover:text-brand-ink hover:bg-brand-cream focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-copper disabled:opacity-40 disabled:pointer-events-none";
    return (
        <div
            className={`absolute z-40 left-3 top-3 flex items-center gap-0.5 rounded-md bg-white border border-brand-line shadow-sm px-1 py-1 transition-opacity ${
                isSelected ? "opacity-100" : "opacity-0 group-hover:opacity-100 focus-within:opacity-100"
            }`}
            data-testid={`block-toolbar-${block.id}`}
            role="toolbar"
            aria-label={`Section: ${block.type}`}
            onClick={(e) => { e.stopPropagation(); setSelectedBlockId(block.id); }}
        >
            <button
                {...dragAttributes}
                {...dragListeners}
                type="button"
                className={`${btn} cursor-grab active:cursor-grabbing`}
                data-testid={`block-drag-${block.id}`}
                aria-label="Drag to reorder section"
                title="Drag to reorder"
                onClick={(e) => e.stopPropagation()}
            >
                <GripVertical className="w-4 h-4" aria-hidden="true" />
            </button>
            <span className="px-1.5 text-[10px] uppercase tracking-widest text-zinc-500 border-r border-brand-line mr-0.5 select-none">
                {block.type}·{block.variant}
            </span>
            <button
                type="button"
                className={btn}
                data-testid={`block-move-up-${block.id}`}
                aria-label="Move section up"
                title="Move up"
                disabled={isFirst}
                onClick={(e) => { e.stopPropagation(); moveBlock(block.id, "up"); }}
            >
                <ArrowUp className="w-4 h-4" aria-hidden="true" />
            </button>
            <button
                type="button"
                className={btn}
                data-testid={`block-move-down-${block.id}`}
                aria-label="Move section down"
                title="Move down"
                disabled={isLast}
                onClick={(e) => { e.stopPropagation(); moveBlock(block.id, "down"); }}
            >
                <ArrowDown className="w-4 h-4" aria-hidden="true" />
            </button>
            <button
                type="button"
                className={btn}
                data-testid={`block-duplicate-${block.id}`}
                aria-label="Duplicate section"
                title="Duplicate"
                onClick={(e) => { e.stopPropagation(); duplicateBlock(block.id); }}
            >
                <Copy className="w-4 h-4" aria-hidden="true" />
            </button>
            <button
                type="button"
                className={btn}
                data-testid={`block-hide-${block.id}`}
                aria-label={block.hidden ? "Show section on live site" : "Hide section from live site"}
                aria-pressed={!!block.hidden}
                title={block.hidden ? "Show on live site" : "Hide from live site"}
                onClick={(e) => { e.stopPropagation(); toggleBlockHidden(block.id); }}
            >
                {block.hidden
                    ? <EyeOff className="w-4 h-4" aria-hidden="true" />
                    : <Eye className="w-4 h-4" aria-hidden="true" />}
            </button>
            <AlertDialog>
                <AlertDialogTrigger asChild>
                    <button
                        type="button"
                        className={`${btn} hover:text-red-600 hover:bg-red-50`}
                        data-testid={`block-delete-${block.id}`}
                        aria-label="Delete section"
                        title="Delete"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                    </button>
                </AlertDialogTrigger>
                <AlertDialogContent data-testid={`block-delete-confirm-${block.id}`}>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Delete this section?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This removes the “{block.type}” section from your draft. You can undo this action
                            immediately with Cmd/Ctrl+Z, and it won't affect your live site until you publish.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel data-testid={`block-delete-cancel-${block.id}`}>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                            className="bg-red-600 hover:bg-red-700 text-white"
                            data-testid={`block-delete-confirm-btn-${block.id}`}
                            onClick={() => removeBlock(block.id)}
                        >
                            Delete section
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}

function SortableBlockWrapper({ block, isFirst, isLast, isSelected, onSelect, children }) {
    const {
        attributes, listeners, setNodeRef, transform, transition, isDragging,
    } = useSortable({ id: block.id });
    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
    };
    return (
        <div
            ref={setNodeRef}
            style={style}
            className={`relative group ${isSelected ? "ring-2 ring-brand-copper" : "ring-1 ring-transparent"} ${block.hidden ? "opacity-50" : ""} transition-shadow`}
            data-testid={`editor-block-${block.id}`}
            data-block-type={block.type}
            data-block-hidden={block.hidden ? "true" : "false"}
            onClick={(e) => { e.stopPropagation(); onSelect(); }}
        >
            <BlockToolbar
                block={block}
                isFirst={isFirst}
                isLast={isLast}
                dragAttributes={attributes}
                dragListeners={listeners}
            />
            {block.hidden && (
                <div className="absolute z-30 right-3 top-3 text-[10px] uppercase tracking-widest px-2 py-1 rounded bg-zinc-900/80 text-white"
                     data-testid={`block-hidden-badge-${block.id}`}>
                    Hidden on live site
                </div>
            )}
            {children}
        </div>
    );
}

/** InlineText — contentEditable wrapper. Emits blur → updateBlockProp. */
function InlineText({ blockId, path, value, className = "", tag = "span" }) {
    const { updateBlockProp } = useEditor();
    const Tag = tag;
    return (
        <Tag
            contentEditable
            suppressContentEditableWarning
            className={`${className} outline-none focus:ring-2 focus:ring-brand-copper/40 rounded-sm px-0.5 -mx-0.5`}
            onBlur={(e) => {
                const next = e.currentTarget.innerText.trim();
                if (next !== value) updateBlockProp(blockId, path, next);
            }}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); e.currentTarget.blur(); } }}
            data-testid={`inline-${blockId}-${path}`}
        >
            {value}
        </Tag>
    );
}

/**
 * EditableBlock — thin wrapper over BlockRenderer that adds inline-editable overlays
 * on the key text fields. It reuses the same block DOM as the public renderer so
 * "what you see" really is what the visitor sees.
 */
function EditableBlock({ block, theme }) {
    const p = block.props || {};
    if (block.type === "hero") {
        return (
            <section style={{ backgroundColor: theme?.background }}>
                <div className="mx-auto max-w-6xl px-6 py-20 md:py-28 grid md:grid-cols-2 gap-12 items-center">
                    <div>
                        {p.eyebrow !== undefined && (
                            <InlineText blockId={block.id} path="eyebrow" value={p.eyebrow || ""}
                                        className="block text-xs uppercase tracking-[0.24em] mb-4"
                                        tag="div" />
                        )}
                        <InlineText blockId={block.id} path="headline" value={p.headline || "Add a headline"}
                                    tag="h1" className="font-display text-4xl md:text-5xl lg:text-6xl font-semibold leading-[1.05]" />
                        {p.subheadline !== undefined && (
                            <InlineText blockId={block.id} path="subheadline" value={p.subheadline || ""}
                                        tag="p" className="block mt-5 text-base md:text-lg text-zinc-600" />
                        )}
                        <div className="mt-8 flex gap-3">
                            {p.primary_cta && (
                                <span className="inline-flex items-center gap-2 px-5 py-3 rounded-md font-medium text-white"
                                      style={{ background: theme?.primary }}>
                                    <InlineText blockId={block.id} path="primary_cta.label" value={p.primary_cta.label || "Button"} />
                                </span>
                            )}
                            {p.secondary_cta && (
                                <span className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-zinc-300">
                                    <InlineText blockId={block.id} path="secondary_cta.label" value={p.secondary_cta.label || ""} />
                                </span>
                            )}
                        </div>
                    </div>
                    {p.image && (
                        <div className="rounded-2xl overflow-hidden border border-zinc-200">
                            <img src={p.image} alt="" className="w-full h-80 md:h-[440px] object-cover" />
                        </div>
                    )}
                </div>
            </section>
        );
    }
    if (block.type === "cta_band") {
        return (
            <section className="relative overflow-hidden">
                <div className="absolute inset-0" style={{ background: theme?.secondary || "#0F172A" }} />
                <div className="relative mx-auto max-w-5xl px-6 py-20 md:py-24 text-white">
                    <InlineText blockId={block.id} path="headline" value={p.headline || "CTA headline"}
                                tag="h2" className="font-display text-3xl md:text-4xl font-semibold leading-tight max-w-2xl" />
                    <InlineText blockId={block.id} path="subheadline" value={p.subheadline || ""}
                                tag="p" className="block mt-4 max-w-xl opacity-90" />
                    {p.primary_cta && (
                        <span className="mt-8 inline-flex items-center gap-2 px-6 py-3 rounded-md font-medium text-white"
                              style={{ background: theme?.primary }}>
                            <InlineText blockId={block.id} path="primary_cta.label" value={p.primary_cta.label || "Button"} />
                        </span>
                    )}
                </div>
            </section>
        );
    }
    if (block.type === "about_split") {
        return (
            <section className="py-20" style={{ backgroundColor: theme?.background }}>
                <div className="mx-auto max-w-6xl px-6 grid md:grid-cols-2 gap-12 items-center">
                    {p.image && <img src={p.image} alt="" className="rounded-2xl w-full h-80 md:h-[440px] object-cover border border-zinc-200" />}
                    <div>
                        {p.eyebrow !== undefined && (
                            <InlineText blockId={block.id} path="eyebrow" value={p.eyebrow || ""}
                                        className="block text-xs uppercase tracking-[0.24em] mb-3" tag="div" />
                        )}
                        <InlineText blockId={block.id} path="headline" value={p.headline || "About"}
                                    tag="h2" className="font-display text-3xl md:text-4xl font-semibold leading-tight" />
                        <InlineText blockId={block.id} path="body" value={p.body || ""}
                                    tag="p" className="block mt-5 text-base leading-relaxed text-zinc-600" />
                    </div>
                </div>
            </section>
        );
    }
    if (block.type === "services_grid") {
        return (
            <section className="py-16" style={{ backgroundColor: theme?.background }}>
                <div className="mx-auto max-w-6xl px-6">
                    <InlineText blockId={block.id} path="eyebrow" value={p.eyebrow || ""}
                                className="block text-xs uppercase tracking-[0.24em] mb-3"
                                tag="div" />
                    <InlineText blockId={block.id} path="headline" value={p.headline || "Services"}
                                tag="h2" className="font-display text-3xl md:text-4xl font-semibold leading-tight" />
                    <InlineText blockId={block.id} path="subheadline" value={p.subheadline || ""}
                                tag="p" className="block mt-3 text-zinc-600" />
                    <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {(p.services || []).map((s) => (
                            <div key={s.id} className="rounded-xl p-5 border bg-white"
                                 style={{ borderColor: `${theme?.foreground}14` }}>
                                <div className="flex items-start justify-between gap-3">
                                    <div className="font-medium" style={{ color: theme?.foreground }}>{s.name}</div>
                                    {s.price_display && (
                                        <span className="text-xs font-mono px-2 py-1 rounded-full"
                                              style={{ background: `${theme?.primary}14`, color: theme?.primary }}>
                                            {s.price_display}
                                        </span>
                                    )}
                                </div>
                                {s.description && (
                                    <p className="mt-2 text-sm" style={{ color: `${theme?.foreground}A0` }}>{s.description}</p>
                                )}
                            </div>
                        ))}
                    </div>
                    {(p.services || []).length === 0 && (
                        <div className="mt-8 rounded-lg border border-dashed border-zinc-300 p-6 text-sm text-zinc-500">
                            Services are pulled from your business profile. Add services in Review facts.
                        </div>
                    )}
                </div>
            </section>
        );
    }
    if (block.type === "footer") {
        return (
            <footer className="py-10 border-t border-zinc-200" style={{ backgroundColor: theme?.background }}>
                <div className="mx-auto max-w-6xl px-6 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="text-sm">
                        <InlineText blockId={block.id} path="business_name" value={p.business_name || "Business"}
                                    tag="span" className="font-semibold text-zinc-900" />
                        <span className="mx-2 text-zinc-400">·</span>
                        <InlineText blockId={block.id} path="tagline" value={p.tagline || ""} tag="span"
                                    className="text-zinc-600" />
                    </div>
                    <div className="text-sm text-zinc-600">
                        <InlineText blockId={block.id} path="phone" value={p.phone || ""} tag="span" className="mr-4" />
                        <InlineText blockId={block.id} path="email" value={p.email || ""} tag="span" />
                    </div>
                </div>
            </footer>
        );
    }
    // Fallback — render the read-only block so nothing is invisible in the editor.
    return <BlockRenderer page={{ blocks: [block] }} theme={theme} testidPrefix="editor-render" />;
}

export default function Canvas() {
    const {
        currentPage, draft, device,
        selectedBlockId, setSelectedBlockId,
        reorderBlocks, addBlock,
    } = useEditor();
    const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

    if (!currentPage || !draft) return null;

    const width = DEVICE_WIDTHS[device];
    const scale = DEVICE_SCALES[device];
    const blockIds = currentPage.blocks.map((b) => b.id);

    function onDragEnd(event) {
        const { active, over } = event;
        if (!over || active.id === over.id) return;
        const oldIdx = blockIds.indexOf(active.id);
        const newIdx = blockIds.indexOf(over.id);
        if (oldIdx < 0 || newIdx < 0) return;
        const next = arrayMove(blockIds, oldIdx, newIdx);
        reorderBlocks(currentPage.slug, next);
    }

    return (
        <div className="flex-1 overflow-auto bg-zinc-100 p-6" onClick={() => setSelectedBlockId(null)} data-testid="editor-canvas">
            <div
                className={`mx-auto bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden ${device === "mobile" ? "rounded-[36px] border-[10px] border-brand-ink" : ""}`}
                style={{ width: device === "mobile" ? 390 : Math.min(width, 1400), maxWidth: "100%" }}
            >
                <div className="relative" style={{
                    width: device === "mobile" ? 700 : width,
                    transform: device === "mobile" ? "scale(0.557)" : `scale(${scale})`,
                    transformOrigin: "top left",
                    marginBottom: device === "mobile" ? -370 : 0,
                }}>
                    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
                        <SortableContext items={blockIds} strategy={verticalListSortingStrategy}>
                            {currentPage.blocks.map((b, idx) => (
                                <SortableBlockWrapper
                                    key={b.id}
                                    block={b}
                                    isFirst={idx === 0}
                                    isLast={idx === currentPage.blocks.length - 1}
                                    isSelected={selectedBlockId === b.id}
                                    onSelect={() => setSelectedBlockId(b.id)}
                                >
                                    <EditableBlock block={b} theme={draft.theme} />
                                </SortableBlockWrapper>
                            ))}
                        </SortableContext>
                    </DndContext>
                    {currentPage.blocks.length === 0 && (
                        <div className="py-24 text-center">
                            <div className="text-sm text-zinc-500">This page is empty.</div>
                        </div>
                    )}
                </div>
            </div>
            {/* Sticky "+ Add section" pill under the canvas — always click-target-friendly (rendered outside the scaled div). */}
            <div className="mt-6 flex justify-center" onClick={(e) => e.stopPropagation()}>
                <AddSectionMenu
                    onAdd={(block) => addBlock(currentPage.slug, block)}
                    testid="canvas-add-section" />
            </div>
        </div>
    );
}
