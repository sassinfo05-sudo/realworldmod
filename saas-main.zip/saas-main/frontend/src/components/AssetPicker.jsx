import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload, Search, ImageIcon, Check } from "lucide-react";
import { listAssets, uploadFile, CATEGORIES, humanBytes, apiErr } from "@/lib/assets";

/**
 * Reusable Asset Picker. Opens a dialog to browse/search/upload assets and returns a stable
 * asset via onSelect({ id, url, alt_text, ... }). Consumers should store the asset_id.
 */
export default function AssetPicker({ open, onOpenChange, onSelect, category = "photo", visibility = "public" }) {
    const [items, setItems] = useState([]);
    const [q, setQ] = useState("");
    const [loading, setLoading] = useState(false);
    const [selected, setSelected] = useState(null);
    const fileRef = useRef(null);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await listAssets({ q: q || undefined, page_size: 40 });
            setItems(res.assets || []);
        } catch (e) { /* noop */ }
        setLoading(false);
    }, [q]);
    useEffect(() => { if (open) load(); }, [open, load]);

    const doUpload = async (files) => {
        for (const f of files) {
            try {
                const a = await uploadFile(f, { category, visibility });
                toast.success(`Uploaded ${a.filename}`);
                setSelected(a);
            } catch (e) { toast.error(apiErr(e)); }
        }
        load();
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col" data-testid="asset-picker">
                <DialogHeader><DialogTitle>Choose an asset</DialogTitle></DialogHeader>
                <div className="flex items-center gap-2 mb-3">
                    <div className="relative flex-1">
                        <Search className="w-4 h-4 absolute left-2.5 top-2.5 text-zinc-400" />
                        <Input className="pl-8" placeholder="Search assets…" value={q} onChange={(e) => setQ(e.target.value)} data-testid="picker-search" />
                    </div>
                    <input ref={fileRef} type="file" hidden multiple onChange={(e) => doUpload(Array.from(e.target.files || []))} />
                    <Button onClick={() => fileRef.current?.click()} data-testid="picker-upload"><Upload className="w-4 h-4 mr-1" />Upload</Button>
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 overflow-y-auto flex-1">
                    {items.map((a) => (
                        <button key={a.id} onClick={() => setSelected(a)}
                                className={`relative rounded-lg border overflow-hidden aspect-square bg-zinc-50 dark:bg-zinc-800 ${selected?.id === a.id ? "ring-2 ring-brand-copper" : ""}`}
                                data-testid={`picker-item-${a.id}`}>
                            {a.media_type === "image"
                                ? <img src={a.url} alt={a.alt_text || ""} className="w-full h-full object-cover" />
                                : <div className="w-full h-full flex items-center justify-center text-zinc-400"><ImageIcon className="w-8 h-8" /></div>}
                            {selected?.id === a.id && <div className="absolute top-1 right-1 bg-brand-copper text-white rounded-full p-1"><Check className="w-3 h-3" /></div>}
                        </button>
                    ))}
                    {!loading && items.length === 0 && <p className="col-span-full text-sm text-zinc-500 py-8 text-center">No assets yet — upload one.</p>}
                </div>
                <div className="flex items-center justify-between pt-3 border-t mt-3">
                    <span className="text-xs text-zinc-500">{selected ? `${selected.filename} · ${humanBytes(selected.size_bytes)}` : "Select an asset"}</span>
                    <div className="flex gap-2">
                        <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button disabled={!selected} onClick={() => { onSelect?.(selected); onOpenChange(false); }} data-testid="picker-confirm">Use asset</Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
