# ZANELVO — CURRENT STATE & WHAT'S LEFT (handoff)
_Last updated: Round 18 (2026-09-07). READ FIRST: HANDOFF_ROUND_18.md + ROUND_18_AUDIT.md. Preview host = `env | grep preview_endpoint`._

## ROUND 18 — CODE_GATE: PASS, PRODUCTION_GATE: PENDING_OWNER_SETUP. Remaining increments/owner actions:
- **D (Asset Library):** picker + stable `asset_id` refs wired into CMS only; still to wire into
  website/product/blog/email/marketing/logo/AI/private editors; execute legacy base64→asset migration.
- **E (Founder storage):** provider config + probe + status done; expand staff dashboards (per-tenant
  bytes, orphaned objects, cleanup jobs, cost estimates).
- **Owner/live (PRODUCTION_GATE):** object-storage/CDN creds+bucket+DNS; platform email sender; Stripe
  live keys+webhook; a FUNDED LLM key (current EMERGENT_LLM_KEY budget is exhausted → 6 AI-grounding
  tests fail as an external billing issue, not code); Docker image builds on a real daemon; run
  `scripts/bootstrap_founder.py`; set APP_ENV=production and re-check `/api/readiness`.


## ROUND 8 DONE: central cost service (pause/kill/global budget/ledger/margin), P0 security list, pricing versioning, provider status cards, internal competitive matrix, storefront language switcher + RTL. Per-item status of the whole A–N prompt + how to build each missing piece: HANDOFF_ROUND_8.md §2; next-round order: §3.

## SESSION UPDATE (latest) — shipping suite + product depth + logo studio
Shipped & TESTED this session (backend agent + frontend agent, all green):
- **Online-selling & shipping suite** ("better than Shopify"): `services/shipping.py` + `routes/shipping.py` (registered in server.py incl. `public_router`) + page `pages/dashboard/Shipping.jsx` (nav Sell → Shipping, route /app/store/shipping). 47-country directory, real carrier directory + aggregators (Shippo/EasyPost/ShipStation) filtered by destination, shipping zones (flat/weight-tier/price-tier/free-over), owner+public quote engine, countries-served allowlist, ship-from + handling fee, inventory adjust/log/low-stock/bulk (`/api/store/inventory/*`), order Ship+tracking (+buyer email) & printable Invoice/Packing-slip (`/api/store/orders/{id}/ship` & `/invoice`), buy-now shipping wired into checkout total. Backend 8/8 pass.
- **Product form depth**: Products.jsx form now edits compare-at, weight_grams, requires_shipping, product_type (physical/digital) + download URL, tags, variants (name/stock/price), SEO title/description. Backend added weight_grams+requires_shipping to ProductIn/Patch/_out. Backend 6/6 pass, UI verified.
- **Logo Studio** (item 3, SVG half): `routes/branding.py` (`/api/branding` GET+PUT, owner-scoped; upserts db.org_branding + mirrors logo_svg into website theme; WebsiteTheme gained optional `logo_svg=""`) + page `pages/dashboard/LogoStudio.jsx` (nav → Logo studio, route /app/logo-studio). Client-side SVG generator: monogram/wordmark/icon+text/badge styles, palettes, fonts, icons, live preview, Download SVG/PNG, Save-to-brand. Backend 6/6 pass, UI verified.
STILL PENDING on logo: the **AI-image logo** half (Gemini Nano Banana vs OpenAI gpt-image-1) — needs the user's provider choice + Emergent key, then integration_playbook_expert_v2 + a backend gen endpoint + a tab in LogoStudio.jsx. Also: wire the saved tenant logo into the PUBLIC site header renderer (currently only stored on theme.logo_svg, not yet rendered).

## 0. CRITICAL: env is wiped on import
Every time this project is re-imported, `backend/.env`, `frontend/.env` and the Mongo DB are EMPTY.
Rebuild them before anything else:

**/app/backend/.env**
```
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=<any long random string>
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
EMERGENT_LLM_KEY=<get via emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
CORS_ORIGINS=*
```
**/app/frontend/.env**
```
REACT_APP_BACKEND_URL=<the preview host, e.g. https://bootstrap-fix-2.preview.emergentagent.com>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
```
Then: `pip install -r /app/backend/requirements.txt` (+ `pip install emergentintegrations --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/`), `cd /app/frontend && yarn install`, then `sudo supervisorctl restart all`. The seed auto-recreates founder + owner + demo tenant on backend start (~20s).

## 1. Credentials (also /app/memory/test_credentials.md)
- Customer/owner: **owner@zanelvo.com** / (see test_credentials.md — regenerated each seed unless creds file persists)
- Founder/staff-owner: **founder@zanelvo.com** / (same file)
- Customer login: `POST /api/auth/login {email,password}` → {access_token}
- Staff login: `POST /api/staff/auth/login` (separate `staff_accounts` DB; NO 2FA until an email provider is connected). Staff panel at `/staff`.

## 2. Architecture
- Backend: FastAPI, `/app/backend/server.py` mounts routers. Most under `api` router (adds `/api`); staff/staff_email/email_inbound routers include `/api` in their own prefix and are added via `app.include_router`.
- Frontend: React (CRA), `/app/frontend/src`. `lib/api.js` → axios baseURL = `${REACT_APP_BACKEND_URL}/api`. Dashboard shell `components/DashboardShell.jsx`; staff shell `pages/staff/StaffShell.jsx`; router in `App.js`.
- DB: Mongo via motor, DB_NAME from env. USE UUIDs / stringified ObjectIds (never raw ObjectId in JSON).
- Dark mode: `html.dark` class + overrides in `src/index.css` (remaps `.bg-white`, `.text-brand-ink`, `.text-zinc-*`, `.border-brand-line`). NOTE: opacity variants like `text-brand-ink/80` are NOT overridden — use full tokens (`text-zinc-700`) or `dark:` variants.
- Integrations config stored in DB (`integrations` collection) via `services/integrations.py` (`update`, `get_public` masks secrets, `get_secret`, `is_configured`). Platform settings (brand, emails, unit costs) in `services/platform_settings.py`.

## 3. DONE & VERIFIED this session
### A. Managed Phone Numbers & AI Voice (15/15 backend tests pass)
- `services/numbers.py`, `routes/numbers.py` (/api/numbers/*), page `pages/dashboard/Numbers.jsx`, nav item under Grow.
- Marketplace by country (12), buy→org ownership, multi-number mgmt, per-number voice_config (persona, language, greeting, messages, forwarding, sms_auto_reply, recording), test-call, plan free allotment (PLAN_FREE_NUMBERS), extra $3/mo local/$6 tollfree.
- Carrier abstraction: Telnyx (recommended/default) + Twilio via platform integrations `voice` section (telnyx_api_key added). Simulated until connected.
- Voice webhook `routes/voice.py` twilio inbound now multi-language (per-number greeting/language + directive to run_turn).
- Founder economics (`routes/platform_admin.py`) has a `numbers` profit/loss block + plans[].free_numbers_included.

### B. Staff Email Suite (9/9 backend tests pass)
- `routes/staff_email.py` (/api/staff/email/*), `routes/email_inbound.py` (/api/webhooks/email/resend|sendgrid), `services/transactional.py` (9 templates + automations), `services/email_providers.py` (+SendGrid adapter). Frontend: `pages/founder/EmailCenter.jsx` (tabs: Inbox, Compose, Automations, Templates, Addresses, Provider).
- Simulated until a provider (Resend/SendGrid/SMTP) is connected in the Provider tab. Sent+received logs. Inbound idempotent via `webhook_events`. Signup fires 'welcome' automation.

### C. Home.jsx redesign (visual-editor notes, 2 rounds)
- Interactive hero mock, fast bespoke showcase (no external imgs), dark-mode marquee, premium feature bento, icon timeline "How it works", rendered "booked & paid" visual (replaced stock photo), richer testimonials + FAQ.

## 4. Pre-existing (verify, don't rebuild)
- `services/antifraud.py`: per-IP signup velocity + disposable-email blocking (used in `routes/auth.py` signup). Partly covers the "IP logging / no multi-account abuse" ask — needs strengthening + a staff fraud view.
- Store engine (`routes/store.py`), CRM, bookings, marketing (`routes/marketing.py`), sites/multi-site + maintenance mode (`routes/sites.py`), plans/billing, 2FA, staff roles, payments (Stripe+PayPal in integrations). See old `/app/memory/NEXT_CHAT_HANDOFF.md` for the pre-session detail.

## 5. STILL TO DO (user wants ALL) — priority order
1. **Ecommerce depth:** ✅ DONE (backend+frontend, tested 5/5): discount codes, collections, product variants/compare-at/SEO/tags/digital in `routes/ecommerce.py` + extended `routes/store.py` + page `pages/dashboard/Discounts.jsx` (nav: Store → Discounts). STILL PENDING: variant/compare-at/tags editing UI inside the existing Products.jsx product form (backend supports it; form not yet updated).
1b. **Online-selling & shipping suite ("better than Shopify"):** ✅ DONE (backend tested 8/8, frontend verified). `services/shipping.py` + `routes/shipping.py` + page `pages/dashboard/Shipping.jsx` (nav: Sell → Shipping). Features: 47-country directory, real carrier directory + aggregators (Shippo/EasyPost/ShipStation) filtered by destination, shipping zones with flat/weight/price/free-over rates, quote engine (public + owner), countries-served allowlist, ship-from address + handling fee, inventory adjust/log/low-stock/bulk (/api/store/inventory/*), order Ship+tracking (+buyer email) and printable Invoice/Packing-slip (Orders.jsx), product weight_grams/requires_shipping, buy-now shipping wired into checkout total. STILL PENDING (nice-to-have): live carrier-rate fetch via Shippo/EasyPost when a key is connected; shipping-rate variant per product.
2. **Onboarding rework:** (a) move the "interview" OUT of signup — signup should just create account; interview lives in dashboard. (b) Add a **"Create your website from scratch"** (no-AI) path = blank editor + template gallery on ONE screen (user choice 4=C). (c) Add a **template gallery** (pick a pre-built design). (d) Rewrite interview questions in `backend/app/config.py` (the INTERVIEW/QUESTIONS list near bottom) to feel human, not a job interview.
3. **Logo generation:** ✅ SVG/text maker DONE (`routes/branding.py` + `pages/dashboard/LogoStudio.jsx`). PENDING: AI image gen half (Gemini Nano Banana or OpenAI via integration_playbook_expert_v2 + Emergent key) as a 2nd tab, and rendering the saved logo (theme.logo_svg) in the public site header.
4. **Professional redesign** of ALL dashboards (customer + staff) — less "gaming dashboard", more premium Wix/Shopify. DashboardShell + each page.
5. **Drag & drop uploads everywhere:** reuse/replace the existing MediaPicker; chunked uploads; store to persistent path; use in editor, products, marketing, profile, email.
6. **Anti-abuse hardening:** device fingerprint + IP log table, block repeat trials/discounts, staff fraud view page.
7. **Marketing 100x:** real analytics (sends/opens/clicks/conversions, revenue attribution, UTM, A/B), AI-written editable copy, turn thin pages into stat dashboards. Backend mostly in `routes/marketing.py`.
8. **Website editor overhaul (10000x):** better block editing, drag-reorder, inline edit, more block types, live preview.
9. **Multi-language for tenant-facing output:** the AI voice already localizes; extend to tenant emails + generated website content + AI chat (org-level service_language). (Our OWN marketing site stays English.)
10. **Global bug sweep** + run frontend+backend testing agents.

## 6. Testing protocol
- Update `/app/test_result.md` before invoking testing agents. Test BACKEND via `deep_testing_backend_v2`. ASK USER before frontend testing. Never edit the Testing Protocol section.
- Use REACT_APP_BACKEND_URL (not localhost) when giving tasks to test agents.

## 7. Integrations needing user keys (all built connect-and-go / simulated until keys)
- Email: Resend OR SendGrid OR SMTP (+ zanelvo.com DNS: SPF/DKIM/MX) — configured in Staff → Email → Provider tab.
- Numbers/voice/SMS: Telnyx (recommended) or Twilio — platform integrations `voice` section. SMS needs A2P 10DLC.
- Payments: Stripe + PayPal — integrations `payments` section.
- Logo AI image / dropshipping (AliExpress/CJ): as those features land.


## After Round 15 pass 4 (authoritative — see CURRENT_STATUS.md)
Blocked on owner/merchant action: Stripe Connect enablement, Stripe Billing for recurring products (not built,
labelled unavailable), PayPal (unavailable), Cloudflare for SaaS credentials, legal review confirmation.
Needs staging sweep: browser E2E, axe, Lighthouse, worker restart/duplicate-scheduler drill, backup/restore rehearsal.

## Round 17 — Storage & Asset Library (status)
DONE: provider-neutral storage service, unified Asset Library + reusable Asset Picker (wired into CMS media),
atomic upload + validation + per-tenant dedup + quota, trash lifecycle, signed private URLs, DB-backed
founder-editable allowances + overrides + 70/90/100%, idempotent legacy migration, founder storage config
(encrypted/masked/status), staff overview/override, backend tests 10/10, prod build OK.
REMAINING (owner): connect R2/S3 creds in Setup Center → test → migrate.
REMAINING (build): responsive variants + srcset, presigned direct upload, bandwidth reconciliation from
provider logs, auto reference-tracking + replace-everywhere from all editors, purge/reservation cron,
staff storage/bandwidth margin rows.
