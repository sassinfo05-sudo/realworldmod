"""Shopper accounts + saved carts (public storefront customers).

Round 12. Separate identity from tenant staff/owners: a *shopper* is a person who buys from a
tenant's storefront. Passwordless login (email + one-time code). On verify we mint a scoped JWT
(role="shopper", org bound) that only unlocks that org's storefront account endpoints. Shoppers
get a server-side saved cart and an order history keyed to their email.

This does NOT touch owner/staff auth. Shopper tokens are refused by owner/staff dependencies
because their role is "shopper" and they carry no staff/org-owner claims.
"""
from __future__ import annotations

import hashlib
import secrets
import uuid
from typing import Any, Dict, List, Optional

import jwt
from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, EmailStr, Field

from .. import config
from ..db import get_db, utc_now_iso
from ..security import create_access_token
from ..services import rate_limit as rl

router = APIRouter(prefix="/public/shop", tags=["shop-customers"])


def _hash_code(code: str) -> str:
    return hashlib.sha256(f"{code}:{config.JWT_SECRET}".encode()).hexdigest()


def _cust_out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": d["_id"], "email": d.get("email"), "name": d.get("name", ""),
        "phone": d.get("phone", ""), "customer_group": d.get("customer_group", ""),
        "created_at": d.get("created_at"),
    }


async def current_shopper(org_id: str, authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    """Decode a shopper JWT from the Authorization header and ensure it is bound to this org."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Sign in to continue")
    token = authorization.split(" ", 1)[1].strip()
    try:
        payload = jwt.decode(token, config.JWT_SECRET, algorithms=[config.JWT_ALG])
    except jwt.PyJWTError:
        raise HTTPException(401, "Session expired — sign in again")
    if payload.get("role") != "shopper" or not payload.get("shop"):
        raise HTTPException(403, "Not a shopper session")
    if payload.get("org_id") != org_id:
        raise HTTPException(403, "This account is for a different store")
    db = get_db()
    cust = await db.shop_customers.find_one({"_id": payload.get("sub"), "org_id": org_id})
    if not cust:
        raise HTTPException(401, "Account not found")
    return cust


# ============================ AUTH (passwordless) ============================

class RequestCodeIn(BaseModel):
    email: EmailStr
    name: str = Field(default="", max_length=120)


async def _org_exists(db, org_id: str) -> bool:
    if len(org_id) == 24 and all(c in "0123456789abcdef" for c in org_id.lower()):
        try:
            from bson import ObjectId
            if await db.organizations.find_one({"_id": ObjectId(org_id)}, {"_id": 1}):
                return True
        except Exception:  # noqa: BLE001
            pass
    return bool(await db.organizations.find_one({"_id": org_id}, {"_id": 1}))


@router.post("/{org_id}/auth/request")
async def request_code(org_id: str, req: RequestCodeIn, request: Request):
    db = get_db()
    if not await _org_exists(db, org_id):
        raise HTTPException(404, "Store not found")
    rl.check(f"shop_auth:{org_id}", request, limit=8, window_seconds=900)
    email = req.email.lower().strip()
    now = utc_now_iso()
    cust = await db.shop_customers.find_one({"org_id": org_id, "email": email})
    if not cust:
        cust = {"_id": uuid.uuid4().hex, "org_id": org_id, "email": email,
                "name": req.name.strip(), "phone": "", "customer_group": "",
                "created_at": now, "updated_at": now}
        await db.shop_customers.insert_one(cust)
    code = f"{secrets.randbelow(1000000):06d}"
    await db.shop_login_codes.update_one(
        {"org_id": org_id, "email": email},
        {"$set": {"code_hash": _hash_code(code), "expires_at": _plus_minutes(15),
                  "attempts": 0, "updated_at": now}},
        upsert=True)
    # Try to email the code via the tenant's provider; always safe in dev (returned inline).
    sent = False
    try:
        from ..services.transactional import send_login_code  # optional helper
        sent = await send_login_code(db, org_id, email, code)
    except Exception:  # noqa: BLE001
        sent = False
    resp = {"ok": True, "sent": sent, "message": "We sent a 6-digit code to your email."}
    if config.simulation_allowed():
        resp["dev_code"] = code  # dev/demo only — never in production
    return resp


def _plus_minutes(mins: int) -> str:
    from datetime import datetime, timedelta, timezone
    return (datetime.now(timezone.utc) + timedelta(minutes=mins)).isoformat()


class VerifyIn(BaseModel):
    email: EmailStr
    code: str = Field(min_length=4, max_length=8)


@router.post("/{org_id}/auth/verify")
async def verify_code(org_id: str, req: VerifyIn):
    db = get_db()
    email = req.email.lower().strip()
    rec = await db.shop_login_codes.find_one({"org_id": org_id, "email": email})
    if not rec:
        raise HTTPException(400, "Request a code first")
    if int(rec.get("attempts", 0)) >= 6:
        raise HTTPException(429, "Too many attempts — request a new code")
    if str(rec.get("expires_at", "")) < utc_now_iso():
        raise HTTPException(400, "That code expired — request a new one")
    if _hash_code(req.code.strip()) != rec.get("code_hash"):
        await db.shop_login_codes.update_one({"_id": rec["_id"]}, {"$inc": {"attempts": 1}})
        raise HTTPException(400, "Incorrect code")
    await db.shop_login_codes.delete_one({"_id": rec["_id"]})
    cust = await db.shop_customers.find_one({"org_id": org_id, "email": email})
    if not cust:
        raise HTTPException(404, "Account not found")
    token = create_access_token(cust["_id"], org_id, "shopper", extra={"shop": True, "email": email})
    return {"access_token": token, "token_type": "bearer", "customer": _cust_out(cust)}


# ============================ PROFILE ============================

class ProfilePatch(BaseModel):
    name: Optional[str] = Field(default=None, max_length=120)
    phone: Optional[str] = Field(default=None, max_length=40)


@router.get("/{org_id}/me")
async def get_me(org_id: str, cust: Dict[str, Any] = Depends(current_shopper)):
    return _cust_out(cust)


@router.put("/{org_id}/me")
async def update_me(org_id: str, patch: ProfilePatch, cust: Dict[str, Any] = Depends(current_shopper)):
    db = get_db()
    updates = {k: v for k, v in patch.model_dump(exclude_none=True).items()}
    updates["updated_at"] = utc_now_iso()
    await db.shop_customers.update_one({"_id": cust["_id"], "org_id": org_id}, {"$set": updates})
    cust = await db.shop_customers.find_one({"_id": cust["_id"], "org_id": org_id})
    return _cust_out(cust)


# ============================ SAVED CART ============================

class CartItem(BaseModel):
    product_id: str
    qty: int = Field(ge=1, le=999)


class CartIn(BaseModel):
    items: List[CartItem] = Field(default_factory=list)


async def _hydrate_cart(db, org_id: str, items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Attach live product name/price/image and drop items that no longer exist."""
    out: List[Dict[str, Any]] = []
    subtotal = 0
    for it in items:
        p = await db.store_products.find_one({"_id": it.get("product_id"), "org_id": org_id})
        if not p or not p.get("active", True):
            continue
        qty = int(it.get("qty", 1))
        price = int(p.get("price_cents", 0))
        subtotal += price * qty
        out.append({"product_id": p["_id"], "qty": qty, "name": p.get("name"),
                    "price_cents": price, "image_url": p.get("image_url", ""),
                    "currency": p.get("currency", "USD")})
    return {"items": out, "subtotal_cents": subtotal}


@router.get("/{org_id}/cart")
async def get_cart(org_id: str, cust: Dict[str, Any] = Depends(current_shopper)):
    db = get_db()
    doc = await db.shop_carts.find_one({"_id": cust["_id"], "org_id": org_id})
    return await _hydrate_cart(db, org_id, (doc or {}).get("items", []))


@router.put("/{org_id}/cart")
async def save_cart(org_id: str, req: CartIn, cust: Dict[str, Any] = Depends(current_shopper)):
    db = get_db()
    items = [{"product_id": i.product_id, "qty": i.qty} for i in req.items]
    await db.shop_carts.update_one(
        {"_id": cust["_id"], "org_id": org_id},
        {"$set": {"items": items, "updated_at": utc_now_iso(), "org_id": org_id}}, upsert=True)
    return await _hydrate_cart(db, org_id, items)


# ============================ ORDER HISTORY ============================

@router.get("/{org_id}/orders")
async def my_orders(org_id: str, cust: Dict[str, Any] = Depends(current_shopper)):
    db = get_db()
    email = cust.get("email")
    q = {"org_id": org_id, "$or": [{"customer_id": cust["_id"]}, {"buyer.email": email}]}
    rows = []
    async for o in db.store_orders.find(q).sort("created_at", -1).limit(100):
        rows.append({
            "id": o["_id"], "status": o.get("status"), "total_cents": int(o.get("total_cents", 0) or 0),
            "currency": o.get("currency", "USD"), "items": o.get("items", []),
            "created_at": o.get("created_at"), "paid_at": o.get("paid_at"),
            "shipping_method": o.get("shipping_method", ""),
            "fulfillment": o.get("fulfillment", {}),
        })
    return {"orders": rows}
