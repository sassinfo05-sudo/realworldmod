# ROUND 18 — PROGRESS TRACKER (live)

_Starting SHA: `169084cff639a9611e05e6b373a24fb519075150`. Env WIPED on import — rebuild .env, `pip install -r`,
`yarn install`, `supervisorctl restart all`. Owner login owner@zanelvo.com; founder founder@zanelvo.com
(creds in gitignored memory/test_credentials.md). Agent does NOT push — user uses "Save to Github"._

## GATE TARGET
- CODE_GATE: PASS (every code-controlled criterion)
- PRODUCTION_GATE: PENDING_OWNER_SETUP (live creds/DNS/payment/email/storage/CDN are owner actions)

## ✅ COMPLETED & VERIFIED THIS ROUND
1. **Env rebuilt**, all services RUNNING, /api/health 200, owner+founder login 200.
2. **Login Alerts UI** (`Security.jsx` "Recent sign-ins & devices" card) + backend verified (new-device/
   location email, history/devices endpoints). DONE.
3. **Session Length "remember me"** — checkbox on `Login.jsx`; 30-day token+cookie (43200 vs 1440 min). DONE.
4. **yarn.lock** regenerated from package.json (was missing; includes @xyflow/react). DONE.
5. **STORAGE INVARIANTS (Section B) — all 4 fixed + tested (10/10 in tests/test_storage_invariants.py):**
   - Actual-size bypass: finalize now reconciles REAL bytes vs allowance (reserves delta atomically,
     rejects 402 + releases if over). `services/assets.py finalize_upload`.
   - Reservation leak: finalize now catches ANY exception (provider failure) → releases reservation + 502.
   - Signed-URL expiry: new `signed_url_info()` + `GET /api/assets/{id}/signed-url?ttl=` returns
     expires_at = now+ttl (not now). 
   - Provider switch: `storage.get_provider_for(asset)` resolves reads/sign/delete via the asset's OWN
     recorded provider+bucket+`provider_config_version`; `save_storage_config()` mints immutable config
     versions in `storage_config_versions`. Old assets stay readable after switching provider.
   - Plus: atomic finalize claim (reserved→finalizing, dup finalize→409); DB-unique idempotency index
     `uniq_active_idem` (concurrent init reserves ONCE); reservation TTL + `sweep_expired_reservations()`;
     atomic trash/restore/purge (find_one_and_delete, bytes reconciled once); referenced-asset purge
     blocked (409) unless `?force=true`; blob serving sets content-disposition/nosniff/CSP + attachment
     for svg/html/docs.
6. **Founder auto-promotion hardened (Section F):** removed hardcoded `idoyiron@gmail.com` default in
   `config.py` (now env-only, empty default); OAuth email-match promotion gated to non-prod via
   `config.is_founder_autopromote_allowed()`. Tests: tests/test_founder_provisioning.py 4/4 PASS.
7. **Ruff (Section A):** added `backend/ruff.toml` (E9+F rules), added `ruff==0.6.9` to requirements,
   fixed 103 unused imports + 6 unused vars → `ruff check app` EXIT 0. Backend compiles.
8. **Dependency audit (Section A):** upgraded fastapi 0.110.1→0.116.1, starlette 0.37.2→0.47.3 (cleared
   PYSEC-2026-1941/1943; app boots, 40 tests pass). Residual advisories (starlette-1.x-only fixes,
   litellm pinned by emergentintegrations wheel, ecdsa won't-fix) documented in
   `backend/.pip-audit-ignore` with honest reasons → `pip-audit ... --ignore-vuln` EXIT 0.
9. **CI (Section A) rewritten** `.github/workflows/ci.yml`: removed ALL `|| true`; blocking ruff, compile,
   pip-audit (with documented ignores), deterministic unit tests, self-contained integration tests
   (starts `uvicorn server:app`, waits for health, runs storage/invariants/CMS/security suites),
   frozen-lockfile install, prod build, customer-facing stale-brand scan job, gitleaks.
10. **Stale brand + secret scan:** no "Revenue OS" in frontend/src; no secret patterns in tracked code.

## ⏳ IN PROGRESS
- Frontend production build running in background (`/tmp/fe_build.log`, look for BUILD_EXIT=0).

## ✅ ROUND 18 COMPLETE — CODE_GATE: PASS / PRODUCTION_GATE: PENDING_OWNER_SETUP
Final evidence recorded in ROUND_18_AUDIT.md + HANDOFF_ROUND_18.md. Verified this session from the
rebuilt checkout: env rebuilt + all services RUNNING; /api/health 200; /api/readiness app_ready:true;
founder+owner login 200; frozen frontend install PASS; frontend prod build PASS (main.9d6b247b.js);
ruff EXIT 0; compile EXIT 0; storage/founder/config suites 47 passed/1 skipped; full suite 193 passed/
6 failed (all LLM-budget-exhausted, external billing — NOT code)/18 skipped; pip-audit 0 vulns/21
documented ignores; secret scan clean; no "Revenue OS" in frontend/src; frontend lint clean; login page
renders with remember-me checkbox. Docker builds NOT runnable (no daemon) — reported honestly.
Increments left: D cross-editor asset wiring, E expanded staff storage dashboards.

## ⬜ (historical) STILL TO DO list — superseded by the COMPLETE block above
- Confirm frontend prod build succeeded (BUILD_EXIT=0).
- Section C: verify plan storage/bandwidth allowances surfaced (mostly exist: storage_limit, usage,
  categories, overrides, 70/90/100%; bandwidth honestly Estimated). Light verification + doc.
- Section D: Asset Library cross-editor picker — CMS wired already; wiring into product/blog/email/
  marketing/logo editors is LARGE. HONEST STATUS: partial; document remaining as increment.
- Section E: founder storage card/probe + staff overview exist; expanded dashboards = increment.
- Section F: bootstrap CLI exists (scripts.bootstrap_founder); readiness endpoint — verify includes
  db/url/storage/email state; MFA "codes skipped" UI copy is dev-accurate (prod fails closed).
- Section G: update PRD/REQUIREMENTS_LEDGER/BUILD_LEDGER/WHATS_LEFT/SECURITY/OWNER_SETUP_CHECKLIST/
  CURRENT_STATUS/CHANGELOG + write HANDOFF_ROUND_18.md + finalize ROUND_18_AUDIT.md.
- Section H: run the consolidated test set from clean; note Docker builds CANNOT be run here (no docker
  daemon in this env) — must be stated honestly (Dockerfiles static-reviewed only).
- Docker: `which docker` → none. Cannot prove Docker builds in-session; report honestly.

## KEY FILES TOUCHED
- backend/app/services/assets.py, storage.py; routes/assets.py; routes/auth_oauth.py; config.py;
  services/usage.py; routes/{bookings,import_site,insights,media_forms_analytics}.py;
  services/email_providers.py
- backend/ruff.toml, backend/.pip-audit-ignore, backend/requirements.txt
- backend/tests/test_storage_invariants.py, tests/test_founder_provisioning.py
- frontend/src/pages/Login.jsx, pages/dashboard/Security.jsx, frontend/yarn.lock
- .github/workflows/ci.yml
- memory/ROUND_18_AUDIT.md, CHANGELOG.md, this file
