import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Mail, Check } from "lucide-react";

export default function Forms() {
    const [subs, setSubs] = useState([]);
    async function load() {
        try {
            const { data } = await api.get("/forms/submissions");
            setSubs(data.submissions || []);
        } catch { /* ignore */ }
    }
    useEffect(() => { load(); }, []);

    async function markRead(id) {
        try {
            await api.post(`/forms/submissions/${id}/mark-read`);
            await load();
        } catch { toast.error("Could not mark read"); }
    }

    return (
        <div className="p-6 md:p-10 max-w-4xl" data-testid="forms-page">
            <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Form submissions</div>
            <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium">Everyone who reached out.</h1>
            <p className="mt-3 text-zinc-600">Every submission becomes a CRM contact automatically.</p>

            <div className="mt-6 space-y-3" data-testid="forms-list">
                {subs.length === 0 && (
                    <div className="rounded-lg border border-dashed border-brand-line p-6 text-sm text-center text-zinc-500">
                        No submissions yet.
                    </div>
                )}
                {subs.map((s) => (
                    <div key={s.id} className={`rounded-xl border p-4 ${s.read_at ? "bg-zinc-50 border-brand-line" : "bg-white border-brand-copper/40"}`}
                         data-testid={`submission-${s.id}`}>
                        <div className="flex items-start justify-between gap-4">
                            <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2 text-xs text-zinc-500">
                                    <Mail className="w-3.5 h-3.5" />
                                    <span className="font-mono">{s.page_slug}</span>
                                    <span>·</span>
                                    <span>{s.created_at}</span>
                                </div>
                                <div className="mt-2 grid sm:grid-cols-[140px_1fr] gap-x-4 gap-y-1 text-sm">
                                    {Object.entries(s.fields || {}).map(([k, v]) => (
                                        <>
                                            <dt key={k + "-k"} className="text-xs uppercase tracking-widest text-zinc-500">{k}</dt>
                                            <dd key={k + "-v"} className="text-brand-ink break-words">{String(v || "")}</dd>
                                        </>
                                    ))}
                                </div>
                            </div>
                            {!s.read_at && (
                                <Button size="sm" variant="ghost" onClick={() => markRead(s.id)} data-testid={`submission-mark-read-${s.id}`}>
                                    <Check className="w-3.5 h-3.5 mr-1" /> Mark read
                                </Button>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
