"""Usage & cost dashboards.

- Owner: GET /api/usage/ai  → their org's AI spend vs plan budget, by feature.
- Founder: GET /api/staff/usage/ai → platform-wide AI spend, by feature/model/org.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from ..deps import current_user, require_org, require_staff
from ..models import User
from ..services import usage as usage_svc

router = APIRouter(prefix="/usage", tags=["usage"])
staff_router = APIRouter(prefix="/api/staff/usage", tags=["usage"])


@router.get("/ai")
async def my_ai_usage(month: str | None = None,
                       org_id: str = Depends(require_org),
                       _u: User = Depends(current_user)):
    """Current org's AI usage & cost this month, with plan budget + per-feature breakdown."""
    return await usage_svc.org_usage_summary(org_id, month=month)


class OwnerCapPatch(BaseModel):
    monthly_cap_usd: float = Field(0, ge=0, le=100000)


@router.get("/cap")
async def get_ai_cap(org_id: str = Depends(require_org), _u: User = Depends(current_user)):
    """The owner's self-imposed hard monthly AI spend cap (0 = no cap)."""
    return {"monthly_cap_usd": await usage_svc.owner_ai_cap(org_id)}


@router.put("/cap")
async def put_ai_cap(patch: OwnerCapPatch, org_id: str = Depends(require_org),
                     _u: User = Depends(current_user)):
    """Set (or clear with 0) the owner's hard monthly AI spend cap. Enforced across all AI features."""
    return await usage_svc.set_owner_ai_cap(org_id, patch.monthly_cap_usd)


@staff_router.get("/ai")
async def platform_ai_usage(month: str | None = None,
                             _staff: User = Depends(require_staff("audit"))):
    """Platform-wide AI spend this month (founder). By feature, model, org + daily series."""
    summary = await usage_svc.global_usage_summary(month=month)
    # Enrich org rows with org names for readability.
    try:
        from ..db import get_db
        db = get_db()
        ids = [r["key"] for r in summary.get("by_org", []) if r.get("key") and r["key"] != "unknown"]
        names = {}
        if ids:
            from bson import ObjectId
            obj_ids = []
            for i in ids:
                try:
                    obj_ids.append(ObjectId(i))
                except Exception:  # noqa: BLE001
                    pass
            async for o in db.organizations.find({"_id": {"$in": obj_ids}}):
                names[str(o["_id"])] = o.get("name") or o.get("slug") or str(o["_id"])
        for r in summary.get("by_org", []):
            r["name"] = names.get(r.get("key"), "Anonymous / public" if r.get("key") in (None, "unknown") else r.get("key"))
    except Exception:  # noqa: BLE001
        pass
    return summary


# ---------------------------------------------------------------------------
# Founder controls, margin, ledger export, audit
# ---------------------------------------------------------------------------
from typing import Any, Dict, Optional  # noqa: E402

from fastapi import Response  # noqa: E402
from pydantic import BaseModel  # noqa: E402


class ControlsPatch(BaseModel):
    pause_all: Optional[bool] = None
    provider_kill: Optional[Dict[str, bool]] = None
    global_monthly_budget_usd: Optional[float] = None
    warn_pct: Optional[int] = None
    per_user_share_pct: Optional[int] = None
    feature_caps_usd: Optional[Dict[str, float]] = None
    public_visitor_daily_cap_usd: Optional[float] = None


@staff_router.get("/controls")
async def get_usage_controls(_staff: User = Depends(require_staff("audit"))):
    """Pause-all switch, provider kill switches, founder global budget, caps + audit history."""
    return {"controls": await usage_svc.get_controls(force=True),
            "audit": await usage_svc.controls_audit(limit=50),
            "known_providers": ["anthropic", "openai", "gemini", "email", "sms", "voice", "shipping", "ads"]}


@staff_router.put("/controls")
async def put_usage_controls(patch: ControlsPatch, staff: User = Depends(require_staff("controls", "pricing"))):
    data: Dict[str, Any] = {k: v for k, v in patch.model_dump().items() if v is not None}
    new = await usage_svc.set_controls(data, actor=staff.email)
    return {"controls": new}


@staff_router.post("/pause-all")
async def pause_all(staff: User = Depends(require_staff("controls", "pricing"))):
    """Emergency stop: every paid operation (LLM, email, …) refuses until resumed."""
    return {"controls": await usage_svc.set_controls({"pause_all": True}, actor=staff.email)}


@staff_router.post("/resume-all")
async def resume_all(staff: User = Depends(require_staff("controls", "pricing"))):
    return {"controls": await usage_svc.set_controls({"pause_all": False}, actor=staff.email)}


@staff_router.get("/margin")
async def platform_margin(month: str | None = None, _staff: User = Depends(require_staff("audit"))):
    """Gross margin: MRR (price snapshots of active subscriptions) vs metered cost, per org."""
    return await usage_svc.margin_summary(month=month)


@staff_router.get("/ledger")
async def platform_ledger(month: str | None = None, org_id: str | None = None,
                          limit: int = 500, _staff: User = Depends(require_staff("audit"))):
    rows = await usage_svc.ledger_rows(month=month, org_id=org_id, limit=max(1, min(limit, 5000)))
    return {"rows": rows, "count": len(rows)}


@staff_router.get("/ledger.csv")
async def platform_ledger_csv(month: str | None = None, org_id: str | None = None,
                              _staff: User = Depends(require_staff("audit"))):
    rows = await usage_svc.ledger_rows(month=month, org_id=org_id, limit=20000)
    csv_text = usage_svc.ledger_csv(rows)
    fname = f"zanelvo-usage-ledger-{month or usage_svc._month_key()}.csv"
    return Response(content=csv_text, media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{fname}"'})


@router.get("/ledger")
async def my_ledger(month: str | None = None, limit: int = 200,
                    org_id: str = Depends(require_org), _u: User = Depends(current_user)):
    """Owner's own usage ledger (no prompts, no secrets)."""
    rows = await usage_svc.ledger_rows(month=month, org_id=org_id, limit=max(1, min(limit, 2000)))
    return {"rows": rows, "count": len(rows)}


@router.get("/ledger.csv")
async def my_ledger_csv(month: str | None = None, org_id: str = Depends(require_org),
                        _u: User = Depends(current_user)):
    rows = await usage_svc.ledger_rows(month=month, org_id=org_id, limit=20000)
    return Response(content=usage_svc.ledger_csv(rows), media_type="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="usage-ledger.csv"'})


@staff_router.get("/traffic")
async def platform_traffic(_staff: User = Depends(require_staff("audit", "health"))):
    """Observed (unmetered) API traffic by path group since process start — CRUD/auth are
    counted here, never billed as usage."""
    from ..services import rate_limit as rl
    return rl.observed()
