"""Auth: signup, login, password-reset request/confirm."""
import logging
import re
from datetime import datetime, timedelta, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user
from ..models import User
from ..security import (
    create_access_token,
    generate_reset_token,
    hash_password,
    verify_password,
)
from ..services import rate_limit
from ..services import antifraud
from ..services import twofa, mfa as mfa_svc
from ..services import platform_settings as ps
from .. import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["auth"])


def _slug_from_email(email: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", email.split("@")[0].lower()).strip("-")
    return s or "workspace"


class SignupReq(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: str | None = None
    business_name: str | None = None


class LoginReq(BaseModel):
    email: EmailStr
    password: str
    remember: bool = False


REMEMBER_TTL_MIN = 60 * 24 * 30  # 30 days


class TokenResp(BaseModel):
    access_token: str = ""
    token_type: str = "bearer"
    user: dict = {}
    # 2FA step-up (when set, access_token is empty and the client must call /auth/2fa/verify)
    mfa_required: bool = False
    method: str | None = None          # "email" | "totp"
    challenge_id: str | None = None
    masked_email: str | None = None
    expires_in_sec: int | None = None
    delivery: str | None = None
    dev_code: str | None = None


class ResetRequestReq(BaseModel):
    email: EmailStr


class ResetConfirmReq(BaseModel):
    token: str
    new_password: str = Field(min_length=8, max_length=128)


def _user_public(u: User, org: dict | None = None) -> dict:
    return {
        "id": u.id,
        "email": u.email,
        "full_name": u.full_name,
        "role": u.role,
        "org_id": u.org_id,
        "org_name": (org or {}).get("name") if org else None,
        "inbound_email": (org or {}).get("inbound_email") if org else None,
        "org_slug": (org or {}).get("slug") if org else None,
        "email_verified": u.email_verified,
        "mfa_email_enabled": u.mfa_email_enabled,
    }


async def _issue_token(user: User, request: Request = None, remember: bool = False) -> TokenResp:
    db = get_db()
    org = None
    if user.org_id:
        try:
            org = await db.organizations.find_one({"_id": ObjectId(user.org_id)})
        except Exception:
            org = None
    ttl = REMEMBER_TTL_MIN if remember else None
    token = create_access_token(user.id, user.org_id, user.role, ttl_min=ttl)
    if request is not None:
        try:
            from ..services import login_alerts
            await login_alerts.record_and_alert(user, request)
        except Exception:  # noqa: BLE001
            pass
    return TokenResp(access_token=token, user=_user_public(user, org))


@router.post("/signup", response_model=TokenResp)
async def signup(req: SignupReq, request: Request):
    await rate_limit.check_persistent("signup", request, limit=8, window_seconds=600)
    db = get_db()
    email = req.email.lower().strip()
    # Anti-fraud: disposable-email + per-IP velocity checks (real, fail-open).
    await antifraud.note_signup_attempt(email, request)
    try:
        await antifraud.assess_signup(email, request)
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))
    if await db.users.find_one({"email": email}):
        raise HTTPException(status_code=409, detail="Email already registered")

    # Auto-provision org for the new owner
    base_slug = _slug_from_email(email)
    slug = base_slug
    n = 1
    while await db.organizations.find_one({"slug": slug}):
        n += 1
        slug = f"{base_slug}-{n}"

    org_res = await db.organizations.insert_one({
        "slug": slug,
        "name": req.business_name or f"{req.full_name or 'New'}'s workspace",
        "industry": None,
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    })
    org_id = str(org_res.inserted_id)

    user_res = await db.users.insert_one({
        "email": email,
        "password_hash": hash_password(req.password),
        "full_name": req.full_name,
        "org_id": org_id,
        "role": "owner",
        "email_verified": False,
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    })

    user = User.from_mongo(await db.users.find_one({"_id": user_res.inserted_id}))
    org = await db.organizations.find_one({"_id": org_res.inserted_id})
    token = create_access_token(user.id, user.org_id, user.role)
    # Fire-and-forget welcome email (transactional automation; simulated until a provider is connected).
    try:
        import asyncio
        from ..services import transactional as _tx
        asyncio.create_task(_tx.send_transactional("welcome", email, {"name": req.full_name or "there"}))
    except Exception:  # noqa: BLE001
        pass
    return TokenResp(access_token=token, user=_user_public(user, org))


@router.post("/login", response_model=TokenResp)
async def login(req: LoginReq, request: Request):
    await rate_limit.check_persistent("login", request, limit=10, window_seconds=300)
    db = get_db()
    email = req.email.lower().strip()
    doc = await db.users.find_one({"email": email})
    if not doc:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not verify_password(req.password, doc["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    user = User.from_mongo(doc)

    # --- Step-up 2FA -------------------------------------------------------
    # 1) Authenticator app (TOTP) enrolled → TOTP challenge (code verified by /2fa/verify).
    totp_doc = await db.mfa_secrets.find_one({"user_id": user.id, "enabled": True})
    if totp_doc:
        ch = await db.mfa_challenges.insert_one({"subject_id": user.id, "kind": "user_totp", "email": email,
                                                 "code": "", "attempts": 0, "consumed": False,
                                                 "remember": bool(req.remember),
                                                 "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=10))
                                                 .isoformat().replace("+00:00", "Z"),
                                                 "created_at": utc_now_iso()})
        return TokenResp(mfa_required=True, method="totp", challenge_id=str(ch.inserted_id),
                         masked_email=twofa._mask(email), expires_in_sec=600)
    # 2) Email code — ON by default for every account; user may disable it; skipped when the
    #    platform 2FA sender isn't configured (Staff panel → Integrations → Email).
    if twofa.user_email_2fa_enabled(doc):
        if await twofa.email_2fa_available():
            brand = (await ps.get_settings()).get("brand_name", "Zanelvo")
            payload = await twofa.create_challenge(user.id, email, "user", brand)
            if payload.get("challenge_id"):
                await db.login_remember.update_one({"challenge_id": payload["challenge_id"]},
                                                   {"$set": {"remember": bool(req.remember),
                                                             "created_at": utc_now_iso()}}, upsert=True)
            return TokenResp(**payload)
        # 2FA is enabled on this account but the verification provider is unavailable.
        # FAIL CLOSED in production — never bypass an enrolled second factor.
        if config.APP_ENV not in ("dev", "test", "demo"):
            raise HTTPException(503, detail={
                "error": "mfa_unavailable",
                "message": "Two-factor authentication is enabled on this account but the verification "
                           "provider is temporarily unavailable. Please try again shortly."})
    return await _issue_token(user, request, req.remember)


class Verify2faReq(BaseModel):
    challenge_id: str
    code: str


@router.post("/2fa/verify", response_model=TokenResp)
async def verify_2fa(req: Verify2faReq, request: Request):
    await rate_limit.check_persistent("2fa_verify", request, limit=20, window_seconds=300)
    db = get_db()
    # TOTP challenge?
    try:
        ch = await db.mfa_challenges.find_one({"_id": ObjectId(req.challenge_id), "consumed": False})
    except Exception:
        ch = None
    if not ch:
        raise HTTPException(400, "Challenge expired or already used")
    if ch.get("kind") == "user_totp":
        if datetime.fromisoformat(ch["expires_at"].replace("Z", "+00:00")) < datetime.now(timezone.utc):
            raise HTTPException(400, "Challenge expired — sign in again")
        secret = await db.mfa_secrets.find_one({"user_id": ch["subject_id"], "enabled": True})
        code = (req.code or "").strip()
        ok = bool(secret) and mfa_svc.verify_code(mfa_svc.secret_from_doc(secret), code)
        if not ok and secret:
            h = mfa_svc.hash_backup(code)
            # Atomic single-use consumption: only ONE concurrent request can $pull the code.
            pull = await db.mfa_secrets.update_one(
                {"_id": secret["_id"], "backup_codes_hashed": h},
                {"$pull": {"backup_codes_hashed": h}})
            if pull.modified_count == 1:
                ok = True
        if not ok:
            await db.mfa_challenges.update_one({"_id": ch["_id"]}, {"$inc": {"attempts": 1}})
            if ch.get("attempts", 0) + 1 >= 5:
                await db.mfa_challenges.update_one({"_id": ch["_id"]}, {"$set": {"consumed": True}})
            raise HTTPException(401, "Incorrect authenticator code")
        # Atomically claim the challenge so a valid code can't be replayed concurrently.
        claimed = await db.mfa_challenges.update_one(
            {"_id": ch["_id"], "consumed": False}, {"$set": {"consumed": True}})
        if claimed.modified_count != 1:
            raise HTTPException(400, "Challenge already used")
    else:
        ch = await twofa.verify_challenge(req.challenge_id, req.code, "user")
    doc = await db.users.find_one({"_id": ObjectId(ch["subject_id"])})
    if not doc:
        raise HTTPException(401, "User not found")
    # Honour "remember me" chosen at the login step (TOTP challenge doc or email challenge flag).
    remember = bool(ch.get("remember"))
    if not remember:
        rf = await db.login_remember.find_one({"challenge_id": req.challenge_id})
        remember = bool(rf and rf.get("remember"))
    return await _issue_token(User.from_mongo(doc), request, remember)


@router.post("/2fa/resend", response_model=TokenResp)
async def resend_2fa(req: dict, request: Request):
    await rate_limit.check_persistent("2fa_resend", request, limit=5, window_seconds=300)
    brand = (await ps.get_settings()).get("brand_name", "Zanelvo")
    return TokenResp(**(await twofa.resend_challenge(str(req.get("challenge_id", "")), "user", brand)))


class Email2faPref(BaseModel):
    enabled: bool


@router.get("/2fa/email-setting")
async def get_email_2fa(user: User = Depends(current_user)):
    return {"enabled": user.mfa_email_enabled, "platform_configured": await twofa.email_2fa_available(),
            "effective": user.mfa_email_enabled and await twofa.email_2fa_available()}


@router.put("/2fa/email-setting")
async def set_email_2fa(req: Email2faPref, user: User = Depends(current_user)):
    if getattr(user, "staff_role", None):
        raise HTTPException(400, "Staff accounts always use 2FA")
    db = get_db()
    await db.users.update_one({"_id": ObjectId(user.id)}, {"$set": {"mfa_email_enabled": bool(req.enabled),
                                                                    "updated_at": utc_now_iso()}})
    return {"enabled": bool(req.enabled), "platform_configured": await twofa.email_2fa_available()}


@router.post("/logout")
async def logout():
    """Clears the HttpOnly session cookies (done by the server middleware on this path).
    Bearer tokens are stateless; clients simply drop them."""
    return {"ok": True}



@router.get("/me")
async def me(user: User = Depends(current_user)):
    db = get_db()
    org = None
    if user.org_id:
        try:
            org = await db.organizations.find_one({"_id": ObjectId(user.org_id)})
        except Exception:
            org = None
    return _user_public(user, org)


class ProfileUpdateReq(BaseModel):
    full_name: str | None = None
    org_name: str | None = None
    inbound_email: str | None = None   # address customers write to; inbound webhooks route it to this org's inbox


class ChangePasswordReq(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


@router.put("/profile")
async def update_profile(req: ProfileUpdateReq, user: User = Depends(current_user)):
    db = get_db()
    upd = {"updated_at": utc_now_iso()}
    if req.full_name is not None:
        upd["full_name"] = req.full_name.strip()
    await db.users.update_one({"_id": ObjectId(user.id)}, {"$set": upd})
    if req.org_name is not None and user.org_id:
        await db.organizations.update_one(
            {"_id": ObjectId(user.org_id)},
            {"$set": {"name": req.org_name.strip(), "updated_at": utc_now_iso()}},
        )
    if req.inbound_email is not None and user.org_id:
        addr = req.inbound_email.strip().lower()
        if addr and ("@" not in addr or len(addr) > 254):
            raise HTTPException(status_code=422, detail="Invalid inbound email address")
        if addr:
            clash = await db.organizations.find_one({"inbound_email": addr, "_id": {"$ne": ObjectId(user.org_id)}}, {"_id": 1})
            if clash:
                raise HTTPException(status_code=409, detail="That inbound address is already used by another workspace")
        await db.organizations.update_one({"_id": ObjectId(user.org_id)},
                                          {"$set": {"inbound_email": addr, "updated_at": utc_now_iso()}})
    fresh = User.from_mongo(await db.users.find_one({"_id": ObjectId(user.id)}))
    org = None
    if fresh.org_id:
        try:
            org = await db.organizations.find_one({"_id": ObjectId(fresh.org_id)})
        except Exception:
            org = None
    return _user_public(fresh, org)


@router.get("/login-history")
async def login_history(user: User = Depends(current_user)):
    """Recent sign-ins for the current account (device, IP, country, time, new-device flag)."""
    from ..services import login_alerts
    return {"logins": await login_alerts.recent_logins(user.id)}


@router.get("/devices")
async def login_devices(user: User = Depends(current_user)):
    """Devices/browsers that have signed in to this account."""
    from ..services import login_alerts
    return {"devices": await login_alerts.list_devices(user.id)}



@router.post("/change-password")
async def change_password(req: ChangePasswordReq, user: User = Depends(current_user)):
    db = get_db()
    doc = await db.users.find_one({"_id": ObjectId(user.id)})
    if not doc:
        raise HTTPException(status_code=404, detail="User not found")
    stored = doc.get("password_hash") or ""
    if not verify_password(req.current_password, stored):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    await db.users.update_one(
        {"_id": ObjectId(user.id)},
        {"$set": {"password_hash": hash_password(req.new_password), "updated_at": utc_now_iso()}},
    )
    return {"ok": True}


def _hash_token(raw: str) -> str:
    import hashlib
    return hashlib.sha256((raw or "").encode("utf-8")).hexdigest()


async def _send_reset_email(email: str, token: str) -> bool:
    """Deliver the reset link through the platform email sender (configured in Staff Setup Center).
    Returns True when a real provider accepted the message."""
    try:
        from ..services import platform_mail, platform_settings as ps
        settings = await ps.get_settings()
        base = (settings.get("product_url") or "").rstrip("/") or "https://zanelvo.com"
        link = f"{base}/reset-password?token={token}"
        r = await platform_mail.send(
            "support", email, "Reset your Zanelvo password",
            f"Use this link within 2 hours to reset your password:\n{link}\n\nIf you didn't ask for this, ignore this email.",
            f"<p>Use this link within 2 hours to reset your password:</p><p><a href=\"{link}\">{link}</a></p>"
            f"<p style=\"color:#777\">If you didn't ask for this, you can ignore this email.</p>")
        return bool(r.get("ok") and not r.get("simulated"))
    except Exception as e:  # noqa: BLE001
        logger.warning("reset email failed: %s", e)
        return False


@router.post("/password-reset/request")
async def request_password_reset(req: ResetRequestReq, request: Request):
    """Generate a single-use reset token (stored HASHED), email it via the configured platform
    sender. The raw token is only echoed back in a development environment when no email
    provider is connected (never in production)."""
    from ..services import rate_limit as rl
    await rl.check_persistent("password_reset", request, limit=5, window_seconds=600)
    db = get_db()
    email = req.email.lower().strip()
    user = await db.users.find_one({"email": email})
    generic = {"ok": True, "message": "If that email exists, a reset link has been sent.", "sender_wired": None}
    if not user:
        return generic

    token = generate_reset_token()
    expires = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat()
    # Invalidate any previous outstanding tokens for this user (one active token at a time).
    await db.password_reset_tokens.update_many({"user_id": str(user["_id"]), "consumed": False},
                                               {"$set": {"consumed": True, "superseded": True}})
    await db.password_reset_tokens.insert_one({
        "user_id": str(user["_id"]),
        "token_hash": _hash_token(token),
        "expires_at": expires,
        "consumed": False,
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    })
    sent = await _send_reset_email(email, token)
    logger.info("password reset issued: user=%s expires=%s emailed=%s", str(user["_id"]), expires, sent)
    out = {**generic, "sender_wired": sent}
    if not sent and config.APP_ENV in ("dev", "test", "demo"):
        # Development convenience only — production never returns the token.
        out["dev_token"] = token
        out["message"] = "Development mode: no email provider connected, token returned inline."
    return out


@router.post("/password-reset/confirm")
async def confirm_password_reset(req: ResetConfirmReq, request: Request):
    from ..services import rate_limit as rl
    await rl.check_persistent("password_reset_confirm", request, limit=10, window_seconds=600)
    if len(req.new_password or "") < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    db = get_db()
    now = datetime.now(timezone.utc)
    # Atomic single-use consumption: only ONE caller can flip consumed False→True.
    doc = await db.password_reset_tokens.find_one_and_update(
        {"token_hash": _hash_token(req.token), "consumed": False, "expires_at": {"$gt": now.isoformat()}},
        {"$set": {"consumed": True, "updated_at": utc_now_iso()}},
    )
    if not doc:
        raise HTTPException(status_code=400, detail="Invalid, expired or already-used token")
    # Rotate the password and invalidate every existing session (JWTs issued before this instant).
    await db.users.update_one(
        {"_id": ObjectId(doc["user_id"])},
        {"$set": {"password_hash": hash_password(req.new_password), "updated_at": utc_now_iso(),
                  "sessions_invalidated_at": int(now.timestamp())}},
    )
    return {"ok": True}
