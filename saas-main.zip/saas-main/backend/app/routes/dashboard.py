"""Dashboard summary — what's set up, what's next."""
from fastapi import APIRouter, Depends

from ..db import get_db
from ..deps import current_user, require_org
from ..models import User

from ..services.sites import active_filter as _active_filter

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary")
async def summary(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    website_doc = await db.websites.find_one(await _active_filter(org_id), {"_id": 1, "pages": 1, "status": 1, "theme": 1})
    profile_doc = await db.business_profiles.find_one({"org_id": org_id}, {"_id": 1, "business_name": 1, "industry_label": 1, "services": 1, "hours": 1, "locations": 1})

    def _verified_ratio(items):
        if not items:
            return 0.0
        v = sum(1 for i in items if i.get("verified"))
        return round(v / len(items), 2)

    unverified_ratio = None
    if profile_doc:
        all_ratios = []
        for key in ("services", "hours", "locations"):
            items = profile_doc.get(key) or []
            if items:
                all_ratios.append(_verified_ratio(items))
        unverified_ratio = round(1 - (sum(all_ratios) / len(all_ratios)) if all_ratios else 1.0, 2)

    modules = [
        {"key": "website", "label": "Website", "status": "ready" if website_doc else "pending",
         "next_action": None if website_doc else "Finish the onboarding interview."},
        {"key": "crm", "label": "CRM", "status": "coming_soon",
         "next_action": "Bring your customer list — imports open in Launch."},
        {"key": "inbox", "label": "Inbox", "status": "coming_soon",
         "next_action": "Connect your business email in a later step."},
        {"key": "calendar", "label": "Calendar", "status": "coming_soon",
         "next_action": "Set your booking hours to open bookings."},
        {"key": "payments", "label": "Payments", "status": "coming_soon",
         "next_action": "Add a payout account when you're ready to invoice."},
        {"key": "ai_employees", "label": "AI Employees", "status": "coming_soon",
         "next_action": "Meet your AI receptionist after your first live day."},
        {"key": "marketing", "label": "Marketing", "status": "coming_soon",
         "next_action": "Auto-generated campaigns follow your first 10 contacts."},
        {"key": "settings", "label": "Settings", "status": "ready", "next_action": None},
    ]
    return {
        "org_id": org_id,
        "website_ready": bool(website_doc),
        "profile_ready": bool(profile_doc),
        "unverified_fact_ratio": unverified_ratio,
        "modules": modules,
    }
