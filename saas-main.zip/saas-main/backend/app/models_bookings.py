"""Phase 4 domain models — booking/calendar + jobs + quotes/invoices/payments.

Design principles:
- Money as integer cents (never float). Currency stored per-record.
- Timezones stored as IANA (`America/Los_Angeles`); slot computation always
  timezone-aware.
- Approvals recorded with full audit trail (who + when + note).
- Every accept/pay/refund action produces an Interaction on the linked contact.
"""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .db import BaseDocument


# ============ Services / Staff / Locations ============

class ServiceOffering(BaseDocument):
    """A bookable service. Extends the marketing 'services' with scheduling metadata."""
    org_id: str
    name: str
    description: Optional[str] = None
    duration_minutes: int = 60
    buffer_before_minutes: int = 0
    buffer_after_minutes: int = 15
    price_cents: int = 0
    deposit_cents: int = 0
    currency: str = "USD"
    location_type: Literal["on_site", "at_business", "virtual"] = "on_site"
    location_id: Optional[str] = None
    required_staff_ids: List[str] = Field(default_factory=list)  # if empty → any staff
    resource_ids: List[str] = Field(default_factory=list)  # future — rooms/equipment
    bookable: bool = True
    color: Optional[str] = None  # calendar chip color
    max_daily_bookings: Optional[int] = None
    active: bool = True


class WorkingHours(BaseModel):
    """Weekly schedule row. `day` is 0=Mon..6=Sun."""
    day: int
    start: str  # HH:MM
    end: str    # HH:MM


class TimeOff(BaseModel):
    start: str  # ISO
    end: str
    reason: Optional[str] = None


class Staff(BaseDocument):
    org_id: str
    user_id: Optional[str] = None  # linked to User if the staff can log in
    display_name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    role: str = "technician"
    timezone: str = "America/Los_Angeles"
    working_hours: List[WorkingHours] = Field(default_factory=list)
    breaks: List[WorkingHours] = Field(default_factory=list)  # weekly breaks
    time_off: List[TimeOff] = Field(default_factory=list)
    capacity: int = 1  # max overlapping bookings
    active: bool = True
    color: Optional[str] = None


# ============ Bookings ============

class Booking(BaseDocument):
    org_id: str
    service_id: str
    staff_id: Optional[str] = None  # may be assigned round-robin
    contact_id: Optional[str] = None
    start_at: str  # ISO UTC
    end_at: str    # ISO UTC (start + duration; buffers stored separately for editing)
    buffer_before_minutes: int = 0
    buffer_after_minutes: int = 15
    status: Literal["confirmed", "completed", "cancelled", "no_show"] = "confirmed"
    notes: Optional[str] = None
    customer_notes: Optional[str] = None
    source: Literal["public", "manual", "reschedule", "ai_chat", "ai_call"] = "public"
    booking_number: Optional[str] = None
    reminders_scheduled_ids: List[str] = Field(default_factory=list)
    tokens: Dict[str, str] = Field(default_factory=dict)  # {kind: token}
    cancellation_reason: Optional[str] = None


# ============ Quotes ============

class QuoteLine(BaseModel):
    id: str
    kind: Literal["service", "product", "custom"] = "custom"
    ref_id: Optional[str] = None  # ServiceOffering.id if kind=service
    label: str
    description: Optional[str] = None
    quantity: float = 1.0
    unit_price_cents: int = 0
    discount_percent: float = 0.0
    discount_amount_cents: int = 0
    tax_rate: float = 0.0  # 0..1
    taxable: bool = True


class QuoteTotals(BaseModel):
    subtotal_cents: int = 0
    discount_cents: int = 0
    tax_cents: int = 0
    total_cents: int = 0
    deposit_cents: int = 0
    currency: str = "USD"


class Quote(BaseDocument):
    org_id: str
    number: Optional[str] = None  # human-readable "Q-2026-001"
    contact_id: Optional[str] = None
    author_user_id: str
    status: Literal["draft", "pending_approval", "sent", "viewed",
                     "accepted", "declined", "expired", "rejected"] = "draft"
    lines: List[QuoteLine] = Field(default_factory=list)
    tax_rate: float = 0.0
    global_discount_percent: float = 0.0
    deposit_required_cents: int = 0
    currency: str = "USD"
    totals: QuoteTotals = Field(default_factory=QuoteTotals)
    notes: Optional[str] = None
    terms: Optional[str] = None
    expires_at: Optional[str] = None
    version: int = 1
    versions: List[Dict[str, Any]] = Field(default_factory=list)  # snapshot history
    # approvals
    approval_state: Literal["not_required", "pending", "approved", "rejected"] = "not_required"
    approval_reason: Optional[str] = None  # e.g. "discount 25% > 20%"
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    rejected_by: Optional[str] = None
    rejected_at: Optional[str] = None
    approval_note: Optional[str] = None
    # customer portal
    portal_token: Optional[str] = None
    accepted_at: Optional[str] = None
    accepted_meta: Optional[Dict[str, Any]] = None  # {ip, user_agent}


class ApprovalRule(BaseDocument):
    org_id: str
    name: str
    threshold_type: Literal["discount_percent", "total_cents"] = "discount_percent"
    threshold_value: float = 0.2  # 0.2 = 20%, or cents if total_cents
    required_role: Literal["owner", "manager"] = "manager"
    active: bool = True


# ============ Jobs ============

class ChecklistItem(BaseModel):
    id: str
    label: str
    done: bool = False
    done_at: Optional[str] = None
    done_by_user_id: Optional[str] = None


class Job(BaseDocument):
    org_id: str
    number: Optional[str] = None
    name: str
    address: Optional[str] = None
    contact_id: Optional[str] = None
    booking_id: Optional[str] = None
    quote_id: Optional[str] = None
    invoice_id: Optional[str] = None
    staff_id: Optional[str] = None
    status: Literal["scheduled", "in_progress", "completed", "cancelled"] = "scheduled"
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    checklist: List[ChecklistItem] = Field(default_factory=list)
    notes: Optional[str] = None
    photos: List[Dict[str, Any]] = Field(default_factory=list)  # {url, uploaded_at, uploaded_by}


# ============ Invoices / Payments ============

class InvoiceLine(BaseModel):
    id: str
    label: str
    description: Optional[str] = None
    quantity: float = 1.0
    unit_price_cents: int = 0
    tax_rate: float = 0.0
    taxable: bool = True


class Invoice(BaseDocument):
    org_id: str
    number: Optional[str] = None
    contact_id: Optional[str] = None
    quote_id: Optional[str] = None
    job_id: Optional[str] = None
    author_user_id: str
    status: Literal["draft", "sent", "partial", "paid", "overdue", "void"] = "draft"
    lines: List[InvoiceLine] = Field(default_factory=list)
    tax_rate: float = 0.0
    subtotal_cents: int = 0
    tax_cents: int = 0
    total_cents: int = 0
    amount_paid_cents: int = 0
    currency: str = "USD"
    due_at: Optional[str] = None
    portal_token: Optional[str] = None
    notes: Optional[str] = None
    reminder_scheduled_ids: List[str] = Field(default_factory=list)


class Payment(BaseDocument):
    """A charge attempt or completed payment against an invoice."""
    org_id: str
    invoice_id: str
    amount_cents: int
    currency: str = "USD"
    method: Literal["stripe_checkout", "cash", "bank_transfer", "other", "simulated"] = "simulated"
    provider: Literal["stripe", "simulated", "manual"] = "simulated"
    provider_session_id: Optional[str] = None
    provider_payment_intent_id: Optional[str] = None
    status: Literal["initiated", "pending", "paid", "failed", "refunded"] = "initiated"
    refunded_amount_cents: int = 0
    author_user_id: Optional[str] = None
    receipt_url: Optional[str] = None
    raw_events: List[Dict[str, Any]] = Field(default_factory=list)


class Refund(BaseDocument):
    org_id: str
    payment_id: str
    invoice_id: str
    amount_cents: int
    reason: Optional[str] = None
    requested_by: str
    approved_by: Optional[str] = None  # if org requires approval
    status: Literal["requested", "approved", "rejected", "processed", "failed"] = "requested"
    provider_refund_id: Optional[str] = None
