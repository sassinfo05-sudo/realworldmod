import { Link, useSearchParams } from "react-router-dom";
import { CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function PaySuccess() {
    const [params] = useSearchParams();
    const iid = params.get("iid");
    const tk = params.get("tk");
    return (
        <div className="min-h-screen flex items-center justify-center bg-brand-surface p-6" data-testid="pay-success-page">
            <div className="max-w-md rounded-2xl border border-brand-line bg-white p-8 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h1 className="font-display text-3xl text-brand-ink mt-3">Payment received</h1>
                <p className="text-sm text-zinc-500 mt-2">Thanks — a receipt has been emailed to you.</p>
                {iid && tk && (
                    <Link to={`/portal/invoice/${iid}?tk=${tk}`}>
                        <Button variant="outline" className="mt-6" data-testid="pay-success-view-invoice-btn">
                            View invoice
                        </Button>
                    </Link>
                )}
            </div>
        </div>
    );
}

export function PayCancel() {
    const [params] = useSearchParams();
    const iid = params.get("iid");
    const tk = params.get("tk");
    return (
        <div className="min-h-screen flex items-center justify-center bg-brand-surface p-6" data-testid="pay-cancel-page">
            <div className="max-w-md rounded-2xl border border-brand-line bg-white p-8 text-center">
                <XCircle className="w-10 h-10 text-zinc-400 mx-auto" />
                <h1 className="font-display text-3xl text-brand-ink mt-3">Payment cancelled</h1>
                <p className="text-sm text-zinc-500 mt-2">No worries — nothing was charged. You can try again anytime.</p>
                {iid && tk && (
                    <Link to={`/portal/invoice/${iid}?tk=${tk}`}>
                        <Button className="mt-6 bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="pay-cancel-retry-btn">
                            Back to invoice
                        </Button>
                    </Link>
                )}
            </div>
        </div>
    );
}
