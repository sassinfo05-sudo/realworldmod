"""Provider-neutral email adapter interface + three implementations.

- `SimulatedProvider` — active in this environment. `send()` stores the message
  with delivery.status='delivered' and delivery.simulated=True. Test-send always
  succeeds and is clearly labeled in the UI as simulated.
- `ResendProvider`  — real Resend HTTP client. is_connected=False until
  RESEND_API_KEY is set. verify_config performs a lightweight domains list call.
- `SmtpProvider`    — generic SMTP over aiosmtplib. is_connected=False until
  SMTP_HOST etc. are set.

Every provider returns a `SendResult`:
    {ok: bool, provider_message_id: str|None, error: str|None, hint: str|None, simulated: bool}

The route layer walks a per-org `EmailProviderConfig` doc to pick which adapter
to use; provider handles suppression checks *before* dispatch so simulated / real
paths share the same suppression semantics.
"""
from __future__ import annotations

import asyncio
import logging
import os
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol

import httpx

logger = logging.getLogger(__name__)


@dataclass
class SendPayload:
    from_email: str
    from_name: Optional[str]
    to: List[str]  # email addresses only
    cc: List[str] = field(default_factory=list)
    subject: str = ""
    html: str = ""
    text: str = ""
    reply_to: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)


@dataclass
class SendResult:
    ok: bool
    provider_message_id: Optional[str] = None
    error: Optional[str] = None
    hint: Optional[str] = None
    simulated: bool = False


class EmailProvider(Protocol):
    key: str

    @property
    def is_connected(self) -> bool: ...

    @property
    def honest_status(self) -> str: ...

    async def verify_config(self) -> Dict[str, Any]: ...

    async def send(self, payload: SendPayload) -> SendResult: ...


# ---------------- Simulated ----------------

_SIMULATED_LOG: List[Dict[str, Any]] = []  # in-memory recent send log (test-only)


class SimulatedProvider:
    """Records sends in DB via caller; also keeps an in-memory tail for the test-send UI."""

    key = "simulated"

    @property
    def is_connected(self) -> bool:
        return True

    @property
    def honest_status(self) -> str:
        return "Simulated — messages record as delivered but are not actually sent."

    async def verify_config(self) -> Dict[str, Any]:
        return {"ok": True, "message": "Simulated provider is always available.", "simulated": True}

    async def send(self, payload: SendPayload) -> SendResult:
        mid = f"sim_{uuid.uuid4().hex[:16]}"
        _SIMULATED_LOG.append({"id": mid, "to": payload.to, "subject": payload.subject})
        if len(_SIMULATED_LOG) > 200:
            del _SIMULATED_LOG[:100]
        return SendResult(ok=True, provider_message_id=mid, simulated=True)


# ---------------- Resend ----------------

class ResendProvider:
    key = "resend"
    API_BASE = "https://api.resend.com"

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("RESEND_API_KEY") or ""

    @property
    def is_connected(self) -> bool:
        return bool(self.api_key)

    @property
    def honest_status(self) -> str:
        if self.is_connected:
            return "Connected — real delivery via Resend."
        return "Not connected — set RESEND_API_KEY on the org's email provider config to activate."

    def _headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

    async def verify_config(self) -> Dict[str, Any]:
        if not self.is_connected:
            return {"ok": False, "message": self.honest_status}
        async with httpx.AsyncClient(base_url=self.API_BASE, timeout=10) as c:
            try:
                r = await c.request("GET", "/domains", headers=self._headers())
                if r.status_code >= 400:
                    return {"ok": False, "message": f"Resend API {r.status_code}: {r.text[:200]}"}
                return {"ok": True, "message": "Resend API responded.", "raw": r.json()}
            except Exception as e:  # noqa: BLE001
                return {"ok": False, "message": f"Resend API error: {e}"}

    async def send(self, payload: SendPayload) -> SendResult:
        if not self.is_connected:
            return SendResult(ok=False, error="Resend not connected",
                              hint="Set RESEND_API_KEY on the email provider config.")
        from_line = f"{payload.from_name} <{payload.from_email}>" if payload.from_name else payload.from_email
        body: Dict[str, Any] = {
            "from": from_line,
            "to": payload.to,
            "subject": payload.subject,
            "html": payload.html or None,
            "text": payload.text or None,
        }
        if payload.cc:
            body["cc"] = payload.cc
        if payload.reply_to:
            body["reply_to"] = payload.reply_to
        if payload.tags:
            body["tags"] = [{"name": k, "value": v} for k, v in payload.tags.items()]
        async with httpx.AsyncClient(base_url=self.API_BASE, timeout=30) as c:
            try:
                r = await c.request("POST", "/emails", headers=self._headers(), json=body)
                data = r.json() if r.content else {}
                if r.status_code >= 400:
                    return SendResult(ok=False, error=f"HTTP {r.status_code}: {data}")
                return SendResult(ok=True, provider_message_id=str(data.get("id")))
            except Exception as e:  # noqa: BLE001
                return SendResult(ok=False, error=f"Resend send error: {e}")


# ---------------- SMTP ----------------

class SendGridProvider:
    key = "sendgrid"
    API_BASE = "https://api.sendgrid.com"

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("SENDGRID_API_KEY") or ""

    @property
    def is_connected(self) -> bool:
        return bool(self.api_key)

    @property
    def honest_status(self) -> str:
        if self.is_connected:
            return "Connected — real delivery via SendGrid."
        return "Not connected — paste a SendGrid API key (Mail Send scope) to activate."

    def _headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

    async def verify_config(self) -> Dict[str, Any]:
        if not self.is_connected:
            return {"ok": False, "message": self.honest_status}
        async with httpx.AsyncClient(base_url=self.API_BASE, timeout=10) as c:
            try:
                r = await c.request("GET", "/v3/scopes", headers=self._headers())
                if r.status_code >= 400:
                    return {"ok": False, "message": f"SendGrid API {r.status_code}: {r.text[:200]}"}
                return {"ok": True, "message": "SendGrid API responded."}
            except Exception as e:  # noqa: BLE001
                return {"ok": False, "message": f"SendGrid API error: {e}"}

    async def send(self, payload: SendPayload) -> SendResult:
        if not self.is_connected:
            return SendResult(ok=False, error="SendGrid not connected",
                              hint="Set a SendGrid API key on the email provider config.")
        content = []
        if payload.text:
            content.append({"type": "text/plain", "value": payload.text})
        if payload.html:
            content.append({"type": "text/html", "value": payload.html})
        body: Dict[str, Any] = {
            "personalizations": [{"to": [{"email": e} for e in payload.to]}],
            "from": {"email": payload.from_email, "name": payload.from_name or payload.from_email},
            "subject": payload.subject,
            "content": content or [{"type": "text/plain", "value": " "}],
        }
        if payload.reply_to:
            body["reply_to"] = {"email": payload.reply_to}
        if payload.cc:
            body["personalizations"][0]["cc"] = [{"email": e} for e in payload.cc]
        async with httpx.AsyncClient(base_url=self.API_BASE, timeout=30) as c:
            try:
                r = await c.request("POST", "/v3/mail/send", headers=self._headers(), json=body)
                if r.status_code >= 400:
                    return SendResult(ok=False, error=f"HTTP {r.status_code}: {r.text[:200]}")
                return SendResult(ok=True, provider_message_id=r.headers.get("X-Message-Id", "sendgrid-accepted"))
            except Exception as e:  # noqa: BLE001
                return SendResult(ok=False, error=f"SendGrid send error: {e}")


class SmtpProvider:
    key = "smtp"

    def __init__(self,
                 host: Optional[str] = None,
                 port: Optional[int] = None,
                 username: Optional[str] = None,
                 password: Optional[str] = None,
                 use_tls: bool = True):
        self.host = host or os.environ.get("SMTP_HOST") or ""
        self.port = port or int(os.environ.get("SMTP_PORT") or 0)
        self.username = username or os.environ.get("SMTP_USERNAME")
        self.password = password or os.environ.get("SMTP_PASSWORD")
        self.use_tls = use_tls

    @property
    def is_connected(self) -> bool:
        return bool(self.host and self.port)

    @property
    def honest_status(self) -> str:
        if self.is_connected:
            return f"Connected — sending via {self.host}:{self.port}"
        return "Not connected — configure SMTP host/port/credentials on the email provider config."

    async def verify_config(self) -> Dict[str, Any]:
        if not self.is_connected:
            return {"ok": False, "message": self.honest_status}
        # Non-invasive check: attempt a TCP connect only.
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(self.host, self.port), timeout=5.0)
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            return {"ok": True, "message": f"TCP handshake to {self.host}:{self.port} succeeded."}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "message": f"Cannot reach SMTP host: {e}"}

    async def send(self, payload: SendPayload) -> SendResult:
        if not self.is_connected:
            return SendResult(ok=False, error="SMTP not connected",
                              hint="Set SMTP host/port/credentials on the email provider config.")
        # Minimal aiosmtplib send — kept lightweight; MIME construction via stdlib.
        try:
            from email.message import EmailMessage
            import aiosmtplib  # optional dependency; only imported when needed
        except ImportError:
            return SendResult(ok=False, error="aiosmtplib not installed",
                              hint="Install `aiosmtplib` to use the SMTP provider.")
        msg = EmailMessage()
        from_line = f"{payload.from_name} <{payload.from_email}>" if payload.from_name else payload.from_email
        msg["From"] = from_line
        msg["To"] = ", ".join(payload.to)
        if payload.cc:
            msg["Cc"] = ", ".join(payload.cc)
        msg["Subject"] = payload.subject
        if payload.reply_to:
            msg["Reply-To"] = payload.reply_to
        if payload.text:
            msg.set_content(payload.text)
        if payload.html:
            msg.add_alternative(payload.html, subtype="html")
        try:
            await aiosmtplib.send(
                msg, hostname=self.host, port=self.port,
                username=self.username, password=self.password, start_tls=self.use_tls,
                timeout=15,
            )
            return SendResult(ok=True, provider_message_id=f"smtp_{uuid.uuid4().hex[:12]}")
        except Exception as e:  # noqa: BLE001
            return SendResult(ok=False, error=f"SMTP send error: {e}")


# ---------------- Registry ----------------

class MeteredProvider:
    """Wraps any adapter so every send passes through the central cost service
    (`services/usage.py`): kill switches / pause-all are enforced, and one ledger row per
    send is written (units = recipients, cost 0 when simulated)."""

    def __init__(self, inner):
        self._inner = inner
        self.key = getattr(inner, "key", "unknown")

    @property
    def is_connected(self) -> bool:
        return self._inner.is_connected

    @property
    def honest_status(self) -> str:
        return self._inner.honest_status

    async def verify_config(self) -> Dict[str, Any]:
        return await self._inner.verify_config()

    async def send(self, payload: SendPayload) -> SendResult:
        import time as _t
        from . import usage
        n = len(payload.to or []) + len(payload.cc or [])
        ctx = usage.get_context()
        try:
            await usage.enforce_budget(ctx.get("org_id"), provider="email",
                                       feature=ctx.get("feature") or "email", kind="email")
        except Exception as e:  # noqa: BLE001 — paused / provider disabled
            detail = getattr(e, "detail", None)
            msg = detail.get("message") if isinstance(detail, dict) else str(e)
            return SendResult(ok=False, error=msg or "Email sending is paused.")
        t0 = _t.monotonic()
        res: Optional[SendResult] = None
        err: Optional[str] = None
        try:
            res = await self._inner.send(payload)
            return res
        except Exception as e:  # noqa: BLE001
            err = f"{type(e).__name__}: {e}"
            raise
        finally:
            try:
                await usage.record_usage(
                    kind="email", provider=self.key, operation="email.send", units=n,
                    ok=bool(res and res.ok), error=err or (res.error if res else None),
                    simulated=bool(res and res.simulated), latency_ms=int((_t.monotonic() - t0) * 1000),
                    feature=ctx.get("feature") or "email",
                )
            except Exception:  # noqa: BLE001
                pass


def build_provider_from_config(cfg) -> EmailProvider:
    """Given an EmailProviderConfig doc, instantiate the corresponding adapter (metered).

    Precedence:
    - cfg.provider == 'resend' + resend_api_key on cfg  → ResendProvider(that key)
    - cfg.provider == 'smtp' + smtp_host on cfg          → SmtpProvider(those fields)
    - cfg.provider == 'simulated' or fallback             → SimulatedProvider
    """
    return MeteredProvider(_build_raw_provider(cfg))


def _build_raw_provider(cfg) -> EmailProvider:
    if cfg is None:
        return SimulatedProvider()
    provider_key = getattr(cfg, "provider", "simulated") if not isinstance(cfg, dict) else cfg.get("provider", "simulated")
    getf = (lambda k: getattr(cfg, k, None)) if not isinstance(cfg, dict) else cfg.get
    if provider_key == "resend":
        return ResendProvider(api_key=getf("resend_api_key") or os.environ.get("RESEND_API_KEY"))
    if provider_key == "sendgrid":
        return SendGridProvider(api_key=getf("sendgrid_api_key") or os.environ.get("SENDGRID_API_KEY"))
    if provider_key == "smtp":
        return SmtpProvider(
            host=getf("smtp_host"),
            port=getf("smtp_port"),
            username=getf("smtp_username"),
            password=getf("smtp_password"),
            use_tls=bool(getf("smtp_use_tls") if getf("smtp_use_tls") is not None else True),
        )
    return SimulatedProvider()


def list_providers() -> List[Dict[str, Any]]:
    """Return the catalog of provider adapters, with honest connection state.
    Used to render the provider selector cards in Settings > Email."""
    return [
        {"key": "simulated", "label": "Simulated (dev)",
         "is_connected": True,
         "honest_status": SimulatedProvider().honest_status,
         "docs": "Use this while you connect a real provider — nothing leaves the app."},
        {"key": "resend", "label": "Resend",
         "is_connected": bool(os.environ.get("RESEND_API_KEY")),
         "honest_status": ResendProvider().honest_status,
         "docs": "Get an API key at resend.com/api-keys, then paste it below."},
        {"key": "sendgrid", "label": "SendGrid",
         "is_connected": bool(os.environ.get("SENDGRID_API_KEY")),
         "honest_status": SendGridProvider().honest_status,
         "docs": "Create a Mail Send API key at sendgrid.com, then paste it below."},
        {"key": "smtp", "label": "SMTP (generic)",
         "is_connected": bool(os.environ.get("SMTP_HOST")),
         "honest_status": SmtpProvider().honest_status,
         "docs": "Configure any SMTP relay (SES SMTP, Mailgun SMTP, self-hosted)."},
    ]
