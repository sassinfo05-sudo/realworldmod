"""Unit tests for the Stripe webhook primitives + store-order paid idempotency.

No real Stripe calls: we craft the signed payload ourselves (mocked stripe client)
and exercise signature verification (valid / invalid / replayed-old-timestamp) plus
the idempotent stock-decrement guarantee that both the webhook and the simulated-pay
endpoint rely on.

Run: cd /app/backend && python -m pytest tests/test_store_stripe_webhook.py -q
"""
import asyncio
import hashlib
import hmac
import time

import pytest

# Load backend/.env so importing app.* (which reads JWT_SECRET at import time) works.
import os
from pathlib import Path
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parents[1] / ".env")
except Exception:  # noqa: BLE001
    pass
os.environ.setdefault("JWT_SECRET", "test-secret")
os.environ.setdefault("DB_NAME", "revenueos")
os.environ.setdefault("MONGO_URL", "mongodb://localhost:27017")

from app.services.payment_providers import StripeProvider


def _sign(secret: str, payload: bytes, ts: int) -> str:
    signed = f"{ts}.{payload.decode()}".encode()
    v1 = hmac.new(secret.encode(), signed, hashlib.sha256).hexdigest()
    return f"t={ts},v1={v1}"


def test_signature_valid():
    p = StripeProvider(api_key="sk_test_x", webhook_secret="whsec_test")
    payload = b'{"id":"evt_1","type":"checkout.session.completed"}'
    ts = int(time.time())
    assert p.verify_webhook(payload, _sign("whsec_test", payload, ts)) is True


def test_signature_invalid():
    p = StripeProvider(api_key="sk_test_x", webhook_secret="whsec_test")
    payload = b'{"id":"evt_1"}'
    ts = int(time.time())
    # wrong secret
    assert p.verify_webhook(payload, _sign("whsec_WRONG", payload, ts)) is False
    # tampered payload
    good = _sign("whsec_test", payload, ts)
    assert p.verify_webhook(b'{"id":"evt_TAMPERED"}', good) is False
    # missing header
    assert p.verify_webhook(payload, None) is False


def test_signature_replay_old_timestamp():
    p = StripeProvider(api_key="sk_test_x", webhook_secret="whsec_test")
    payload = b'{"id":"evt_1"}'
    old = int(time.time()) - 3600  # 1h old -> outside 5min tolerance
    assert p.verify_webhook(payload, _sign("whsec_test", payload, old)) is False


def test_no_secret_rejects():
    p = StripeProvider(api_key="sk_test_x", webhook_secret="")
    payload = b'{"id":"evt_1"}'
    ts = int(time.time())
    assert p.verify_webhook(payload, _sign("whsec_test", payload, ts)) is False


# ---------------- idempotent stock decrement ----------------

class _Coll:
    def __init__(self):
        self.docs = []

    @staticmethod
    def _match(doc, q):
        for k, v in q.items():
            if isinstance(v, dict):
                if "$nin" in v and doc.get(k) in v["$nin"]:
                    return False
                if "$in" in v and doc.get(k) not in v["$in"]:
                    return False
                if "$gte" in v and not (doc.get(k, 0) >= v["$gte"]):
                    return False
            elif doc.get(k) != v:
                return False
        return True

    async def find_one(self, q, *a, **k):
        return next((d for d in self.docs if self._match(d, q)), None)

    async def find_one_and_update(self, q, update, **k):
        d = await self.find_one(q)
        if d:
            before = dict(d)
            self._apply(d, update)
            return before
        return None

    async def insert_one(self, doc):
        self.docs.append(doc)
        return type("R", (), {"inserted_id": doc.get("_id")})()

    async def update_one(self, q, update, **k):
        d = await self.find_one(q)
        if d:
            self._apply(d, update)
        return type("R", (), {"modified_count": 1 if d else 0, "matched_count": 1 if d else 0})()

    async def update_many(self, q, update):
        n = 0
        for d in self.docs:
            if self._match(d, q):
                self._apply(d, update)
                n += 1
        return type("R", (), {"modified_count": n, "matched_count": n})()

    @staticmethod
    def _apply(d, update):
        for k, v in update.get("$set", {}).items():
            d[k] = v
        for k, v in update.get("$inc", {}).items():
            d[k] = d.get(k, 0) + v
        for k, v in update.get("$push", {}).items():
            d.setdefault(k, []).append(v)


class _FakeDB:
    def __init__(self):
        self._colls = {}

    def __getattr__(self, name):
        return self._colls.setdefault(name, _Coll())


def test_store_order_paid_idempotent_stock():
    from app.routes.store import mark_store_order_paid_by_id

    db = _FakeDB()

    async def run():
        await db.store_products.insert_one({"_id": "prod1", "org_id": "org1", "stock": 10})
        await db.store_orders.insert_one({
            "_id": "ord1", "org_id": "org1", "status": "pending",
            "subtotal_cents": 2000, "currency": "USD",
            "items": [{"product_id": "prod1", "name": "Widget", "price_cents": 1000, "qty": 2}],
            "buyer": {},  # no email/phone -> skip contact + email side-effects
        })
        await db.payments.insert_one({"_id": "pay1", "org_id": "org1", "kind": "store_order",
                                       "order_id": "ord1", "status": "initiated"})
        r1 = await mark_store_order_paid_by_id(db, "ord1")
        r2 = await mark_store_order_paid_by_id(db, "ord1")  # replay
        return r1, r2

    r1, r2 = asyncio.get_event_loop().run_until_complete(run())
    assert r1 is True and r2 is True
    order = next(d for d in db.store_orders.docs if d["_id"] == "ord1")
    product = next(d for d in db.store_products.docs if d["_id"] == "prod1")
    assert order["status"] == "paid"
    assert product["stock"] == 8  # decremented exactly once (10 - 2), not twice


def test_real_provider_order_never_labelled_simulated():
    """P0 truth: a Stripe-paid order must not produce 'simulated payment' records/emails."""
    from app.routes.store import mark_store_order_paid_by_id, _order_is_simulated

    db = _FakeDB()

    async def run():
        await db.store_products.insert_one({"_id": "p", "org_id": "org1", "stock": 3})
        await db.store_orders.insert_one({
            "_id": "o2", "org_id": "org1", "status": "pending", "provider": "stripe",
            "subtotal_cents": 5000, "discount_cents": 500, "shipping_cents": 700, "total_cents": 5200,
            "currency": "USD", "items": [{"product_id": "p", "name": "W", "price_cents": 5000, "qty": 1}],
            "buyer": {},
        })
        return await mark_store_order_paid_by_id(db, "o2")

    assert asyncio.get_event_loop().run_until_complete(run()) is True
    order = next(d for d in db.store_orders.docs if d["_id"] == "o2")
    assert _order_is_simulated(order) is False
    assert _order_is_simulated({"provider": "simulated"}) is True
    assert _order_is_simulated({}) is True


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
