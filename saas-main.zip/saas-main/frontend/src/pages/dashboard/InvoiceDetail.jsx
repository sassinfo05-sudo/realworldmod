import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { ArrowLeft, Copy, ExternalLink, CheckCircle2, AlertTriangle } from "lucide-react";

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

const STATUS_TONES = {
    draft: "bg-zinc-100 text-zinc-700",
    sent: "bg-blue-100 text-blue-800",
    partial: "bg-amber-100 text-amber-800",
    paid: "bg-emerald-100 text-emerald-800",
    overdue: "bg-red-100 text-red-800",
    void: "bg-zinc-100 text-zinc-500",
};

export default function InvoiceDetail() {
    const { iid } = useParams();
    const navigate = useNavigate();
    const [inv, setInv] = useState(null);

    async function load() {
        try {
            const { data } = await api.get(`/invoices/${iid}`);
            setInv(data);
        } catch (e) { toast.error("Invoice not found"); navigate("/app/payments"); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [iid]);

    if (!inv) return <div className="p-10 text-zinc-500">Loading…</div>;

    const outstanding = (inv.total_cents || 0) - (inv.amount_paid_cents || 0);
    const isOverdue = inv.status === "overdue";
    const isPaid = inv.status === "paid";

    return (
        <div className="p-6 max-w-4xl" data-testid="invoice-detail-page">
            <button onClick={() => navigate("/app/payments")} className="text-xs text-brand-copper mb-2 inline-flex items-center gap-1 hover:underline">
                <ArrowLeft className="w-3.5 h-3.5" /> Back to invoices
            </button>
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Invoice</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium" data-testid="invoice-number">{inv.number || iid.slice(0, 8)}</h1>
                    <div className="mt-1 flex items-center gap-2 flex-wrap">
                        <span className={`text-xs uppercase tracking-widest rounded-full px-2 py-0.5 ${STATUS_TONES[inv.status] || "bg-zinc-100"}`} data-testid="invoice-status-badge">
                            {isOverdue && <AlertTriangle className="w-3 h-3 mr-1 inline" />}
                            {inv.status}
                        </span>
                        {inv.due_at && <span className="text-xs text-zinc-500">Due {new Date(inv.due_at).toLocaleDateString()}</span>}
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    {inv.portal_token && (
                        <>
                            <Button variant="outline" onClick={() => {
                                navigator.clipboard.writeText(`${window.location.origin}/portal/invoice/${inv.id}?tk=${inv.portal_token}`);
                                toast.success("Payment link copied");
                            }} data-testid="invoice-copy-portal-btn">
                                <Copy className="w-4 h-4 mr-1" /> Copy pay link
                            </Button>
                            <a href={`/portal/invoice/${inv.id}?tk=${inv.portal_token}`} target="_blank" rel="noreferrer">
                                <Button variant="ghost" data-testid="invoice-open-portal-btn"><ExternalLink className="w-4 h-4 mr-1" /> Preview</Button>
                            </a>
                        </>
                    )}
                </div>
            </div>

            {isOverdue && (
                <div className="mt-4 rounded-lg bg-red-50 border border-red-200 text-red-800 p-3 text-sm flex items-start gap-2" data-testid="invoice-overdue-banner">
                    <AlertTriangle className="w-4 h-4 mt-0.5" />
                    <div>
                        <div className="font-medium">Overdue.</div>
                        <div className="mt-0.5">A polite reminder is scheduled — dunning cadence is default (day 3, 7, 14 after due).</div>
                    </div>
                </div>
            )}
            {isPaid && (
                <div className="mt-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 text-sm flex items-start gap-2" data-testid="invoice-paid-banner">
                    <CheckCircle2 className="w-4 h-4 mt-0.5" />
                    <div><div className="font-medium">Paid in full.</div></div>
                </div>
            )}

            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 rounded-2xl border border-brand-line bg-white p-5">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-3">Line items</div>
                    <div className="divide-y divide-brand-line">
                        {(inv.lines || []).map((l, idx) => (
                            <div key={l.id || idx} className="py-3 flex items-center justify-between gap-4">
                                <div className="min-w-0">
                                    <div className="font-medium text-brand-ink truncate">{l.label}</div>
                                    {l.description && <div className="text-xs text-zinc-500 mt-0.5">{l.description}</div>}
                                    <div className="text-xs text-zinc-500 mt-0.5">{l.quantity} × {money(l.unit_price_cents, inv.currency)}</div>
                                </div>
                                <div className="font-mono text-sm">{money(l.quantity * l.unit_price_cents, inv.currency)}</div>
                            </div>
                        ))}
                    </div>
                </div>
                <aside className="rounded-2xl border border-brand-line bg-white p-5 h-fit">
                    <div className="text-xs uppercase tracking-widest text-zinc-500">Totals</div>
                    <div className="mt-3 space-y-1 text-sm">
                        <div className="flex justify-between"><span className="text-zinc-500">Subtotal</span><span className="font-mono">{money(inv.subtotal_cents, inv.currency)}</span></div>
                        <div className="flex justify-between"><span className="text-zinc-500">Tax</span><span className="font-mono">{money(inv.tax_cents, inv.currency)}</span></div>
                        <div className="flex justify-between text-emerald-700"><span>Paid</span><span className="font-mono">−{money(inv.amount_paid_cents, inv.currency)}</span></div>
                        <div className="flex justify-between pt-2 border-t border-brand-line">
                            <span className="text-brand-ink font-medium">{isPaid ? "Total" : "Amount due"}</span>
                            <span className="font-mono text-lg" data-testid="invoice-outstanding">{money(isPaid ? inv.total_cents : outstanding, inv.currency)}</span>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    );
}
