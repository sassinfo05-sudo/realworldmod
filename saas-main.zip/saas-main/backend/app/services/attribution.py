"""Round 11 — marketing attribution + funnel events.

Visitors arrive with UTM / click-id parameters. The public site stores them client-side (`zv_attr`) and
sends the same allow-listed dict with every conversion (form submit, booking, buy-now). Server-side we
keep ONLY these fields (no PII, no free-form blobs) on the contact / booking / order and emit funnel
events into `analytics_events` so `routes/analytics.py` can build funnel + channel reports.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from ..db import utc_now_iso

ATTR_KEYS = ("source", "medium", "campaign", "content", "term", "referrer", "landing", "gclid", "fbclid", "first_seen")
FUNNEL_KINDS = {"pageview", "cta_click", "form_submit", "booking_created", "checkout_started", "order_paid",
                "order_refunded", "quote_sent", "quote_accepted"}


def clean_attribution(raw: Any) -> Dict[str, str]:
    """Allow-list + truncate. Returns {} when nothing usable was sent."""
    if not isinstance(raw, dict):
        return {}
    out: Dict[str, str] = {}
    for k in ATTR_KEYS:
        v = raw.get(k)
        if v is None or v == "":
            continue
        out[k] = str(v)[:200]
    if out and "source" not in out:
        out["source"] = "direct" if not out.get("referrer") else "referral"
    return out


def channel_of(attr: Optional[Dict[str, Any]]) -> str:
    """Collapse source/medium into a reporting channel."""
    a = attr or {}
    src = (a.get("source") or "").lower()
    med = (a.get("medium") or "").lower()
    if not src and not med:
        return "direct"
    if a.get("gclid") or med in ("cpc", "ppc", "paid", "paid_search") or src in ("google_ads", "adwords"):
        return "paid_search"
    if a.get("fbclid") or med in ("paid_social", "social_paid") or src in ("facebook_ads", "meta_ads", "instagram_ads"):
        return "paid_social"
    if med == "email" or src in ("email", "newsletter", "zanelvo_campaign"):
        return "email"
    if med in ("social", "organic_social") or src in ("facebook", "instagram", "linkedin", "tiktok", "x", "twitter", "youtube", "pinterest"):
        return "social"
    if med == "organic" or src in ("google", "bing", "duckduckgo", "yahoo"):
        return "organic_search"
    if med == "referral" or src == "referral":
        return "referral"
    if src == "direct":
        return "direct"
    return "other"


async def emit(db, org_id: str, kind: str, *, website_id: Optional[str] = None, page_slug: Optional[str] = None,
               attribution: Optional[Dict[str, Any]] = None, meta: Optional[Dict[str, Any]] = None) -> None:
    """Insert a funnel event. Never raises (analytics must not break a customer flow)."""
    if kind not in FUNNEL_KINDS:
        return
    try:
        attr = clean_attribution(attribution)
        doc = {"org_id": org_id, "website_id": website_id or "", "kind": kind, "page_slug": page_slug,
               "referrer": attr.get("referrer"), "user_agent": None,
               "meta": {**(meta or {}), "attribution": attr, "channel": channel_of(attr)},
               "created_at": utc_now_iso()}
        await db.analytics_events.insert_one(doc)
    except Exception:  # noqa: BLE001
        return
