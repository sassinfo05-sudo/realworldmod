"""Multi-website helpers. An org can own several websites (plan-limited); exactly one is
`active` for the editor/dashboard (org.active_website_id). All legacy code that used to
run `db.websites.find_one({"org_id": org_id})` now goes through `active_filter()`.
"""
from __future__ import annotations

import hashlib
import hmac
import time
import uuid
from typing import Any, Dict, Optional

from bson import ObjectId

from .. import config
from ..db import get_db, utc_now_iso


async def active_filter(org_id: str) -> Dict[str, Any]:
    """Mongo filter selecting the org's active website (falls back to any org site)."""
    db = get_db()
    try:
        org = await db.organizations.find_one({"_id": ObjectId(org_id)}, {"active_website_id": 1})
    except Exception:
        org = None
    aid = (org or {}).get("active_website_id")
    if aid:
        try:
            if await db.websites.count_documents({"_id": ObjectId(aid), "org_id": org_id}) == 1:
                return {"org_id": org_id, "_id": ObjectId(aid)}
        except Exception:
            pass
    return {"org_id": org_id}


async def active_website_doc(org_id: str, projection: Optional[Dict[str, int]] = None) -> Optional[Dict[str, Any]]:
    db = get_db()
    flt = await active_filter(org_id)
    if projection:
        return await db.websites.find_one(flt, projection)
    return await db.websites.find_one(flt)


async def set_active(org_id: str, website_id: str) -> None:
    db = get_db()
    await db.organizations.update_one({"_id": ObjectId(org_id)},
                                      {"$set": {"active_website_id": website_id, "updated_at": utc_now_iso()}})


def blank_pages(business_name: str) -> list:
    def b(t, props, variant="a"):
        return {"id": uuid.uuid4().hex[:10], "type": t, "variant": variant, "props": props, "style": {}, "hidden": False}
    return [
        {"id": uuid.uuid4().hex[:10], "slug": "home", "title": "Home", "seo": {"title": business_name}, "hidden": False,
         "blocks": [
             b("hero", {"headline": f"Welcome to {business_name}", "subheadline": "Tell visitors what you do in one clear sentence.",
                        "cta_label": "Get in touch", "cta_href": "#contact"}),
             b("services_grid", {"title": "What we offer", "items": [
                 {"title": "Service one", "description": "Describe it."},
                 {"title": "Service two", "description": "Describe it."},
                 {"title": "Service three", "description": "Describe it."}]}),
             b("cta_band", {"headline": "Ready to start?", "cta_label": "Contact us", "cta_href": "#contact"}),
             b("form", {"title": "Contact us", "fields": ["name", "email", "message"]}),
             b("footer", {"text": f"© {business_name}"}),
         ]},
    ]


DEFAULT_THEME = {
    "primary": "#4F46E5", "secondary": "#D6289B", "background": "#FFFFFF", "surface": "#F6F6FA",
    "foreground": "#0B0A16", "accent": "#F59E0B", "font_heading": "Inter", "font_body": "Inter",
    "radius": "0.75rem", "industry": "professional_services",
}


# ---------- maintenance-mode unlock tokens (HMAC, stateless) ----------

def _sig(site_id: str, exp: int) -> str:
    return hmac.new(config.JWT_SECRET.encode(), f"{site_id}:{exp}".encode(), hashlib.sha256).hexdigest()[:32]


def make_unlock_token(site_id: str, hours: int = 24) -> str:
    exp = int(time.time()) + hours * 3600
    return f"{exp}.{_sig(site_id, exp)}"


def unlock_token_valid(site_id: str, token: Optional[str]) -> bool:
    if not token or "." not in token:
        return False
    try:
        exp_s, sig = token.split(".", 1)
        exp = int(exp_s)
    except Exception:
        return False
    return exp > time.time() and hmac.compare_digest(sig, _sig(site_id, exp))


# ---------- per-page unlock tokens (HMAC, stateless, page + site scoped) ----------

def _page_sig(site_id: str, page_slug: str, exp: int) -> str:
    return hmac.new(config.JWT_SECRET.encode(),
                    f"page:{site_id}:{page_slug}:{exp}".encode(),
                    hashlib.sha256).hexdigest()[:32]


def make_page_unlock_token(site_id: str, page_slug: str, hours: int = 12) -> str:
    exp = int(time.time()) + hours * 3600
    return f"{exp}.{_page_sig(site_id, page_slug, exp)}"


def page_unlock_token_valid(site_id: str, page_slug: str, token: Optional[str]) -> bool:
    if not token or "." not in token:
        return False
    try:
        exp_s, sig = token.split(".", 1)
        exp = int(exp_s)
    except Exception:
        return False
    return exp > time.time() and hmac.compare_digest(sig, _page_sig(site_id, page_slug, exp))


def maintenance_public(site_doc: Dict[str, Any], business_name: str) -> Dict[str, Any]:
    m = site_doc.get("maintenance") or {}
    return {
        "maintenance": True,
        "slug": site_doc.get("slug"),
        "business_name": business_name,
        "title": m.get("title") or "We'll be right back",
        "message": m.get("message") or "This site is currently private or under maintenance.",
        "eta": m.get("eta") or "",
        "accent": m.get("accent") or ((site_doc.get("published_theme") or site_doc.get("theme") or {}).get("primary")) or "#4F46E5",
        "show_logo": m.get("show_logo", True),
        "password_protected": bool(m.get("password_hash")),
        "contact_email": m.get("contact_email") or "",
    }
