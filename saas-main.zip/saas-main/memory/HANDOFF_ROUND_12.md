# ZANELVO — HANDOFF ROUND 12 (for a NEW chat)

_Living document for Round 12. Read this first, then `HANDOFF_ROUND_11.md`, `HANDOFF_ROUND_10.md`,
`HANDOFF_ROUND_9.md`, then `HANDOFF_ROUND_8.md` §2 (the authoritative A–N backlog with "how to build"
notes). Source code + fresh test evidence override any older ✅ claims._

---------------------------------------------------------------------------------------------------
## 0. HOW TO CONTINUE (first 10 minutes) — env is WIPED on import
---------------------------------------------------------------------------------------------------
```bash
env | grep -i preview_endpoint                       # preview host changes per job
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && \
SEK=$(python3 -c "import secrets;print(secrets.token_urlsafe(32))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
SECRETS_ENC_KEY=$SEK
EMERGENT_LLM_KEY=<emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
SEED_DEMO=true
CORS_ORIGINS=*
EOF
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile
sudo supervisorctl restart backend frontend && sleep 35 && curl -s localhost:8001/api/health
cat /app/memory/test_credentials.md      # regenerated with FRESH passwords on seed; send the NEW ones
```
Logins: owner `/login` → `/app`; founder/staff `/staff/login`; public demo `/site/demo-home-services`;
storefront `/store/<org_id>` (org_id is in `GET /api/public/sites/demo-home-services`).
NOTE: a FRESH seed has NO demo products in the store — create some via the owner Products page or
`POST /api/store/products` before testing storefront/commerce.

---------------------------------------------------------------------------------------------------
## 1. ROUND 12 PROGRESS TRACKER (⬜ todo · 🟨 in progress · ✅ done & verified)
---------------------------------------------------------------------------------------------------
### R12-B1 Commerce depth  — ✅ CODE DONE, curl-verified by main; backend agent retest pending
- ✅ Gift cards: owner CRUD + adjust/activate/deactivate, issue-on-purchase (product_type=gift_card),
  public balance check, checkout redemption (partial + fully-covered free order), decrement on PAID only.
- ✅ Shopper accounts: passwordless email-code login (`/api/public/shop/{org}/auth/request|verify`),
  scoped shopper JWT (role="shopper", org-bound), profile GET/PUT.
- ✅ Saved carts: `GET/PUT /api/public/shop/{org}/cart` (hydrated, drops dead products).
- ✅ Order history: `GET /api/public/shop/{org}/orders`; buy-now `customer_token` stamps `order.customer_id`.
- ✅ Customer groups: `contact.customer_group` + discount `eligible_groups[]` (group-only offers).
- ✅ Product bundles: `bundle_items[]` + `product_type: bundle`; gift_card product type.
- ✅ Frontend: Storefront gift-card field + shopper account dialog (sign-in + orders); Discounts page
  "Gift cards" tab + customer-group field on discounts; Products form gift_card/bundle types;
  CRM contact detail customer-group editor.

### R12 remaining (NOT started) — priority order
- ⬜ Subscriptions (recurring products) — model + simulated renewal; live needs Stripe Billing creds.
- ⬜ Drag-and-drop / block-based email editor (currently plain body).
- ⬜ Per-language AUTHORED site content (editor overlay `page.translations[lang].blocks`; runtime switcher already live).
- ⬜ Developer docs page (`pages/Developers.jsx`) documenting `/api/v1/*` + scoped API keys.  → ✅ DONE (see 2.2)
- ⬜ Home + Pricing "wow" redesign + Lighthouse/axe pass.
- 🟨 Docs: CHANGELOG / SECOND_RUN_AUDIT entries for Round 12 (in progress); PRD refresh pending.

### Tests / docs
- ✅ backend testing agent run for Round 12 Batch 1 (38/38 PASS — gift cards 8/8, shopper accounts+carts 11/11, customer groups 3/3)
- ⬜ frontend testing (ask user first) · ⬜ CHANGELOG/audit updates

---------------------------------------------------------------------------------------------------
## 2. WHAT ROUND 12 SHIPPED (appended per task as it completes)
---------------------------------------------------------------------------------------------------
### 2.1 R12-B1 Commerce depth
- NEW `routes/gift_cards.py` (`/api/store/gift-cards` owner + `/api/public/store/{org}/gift-card/{code}`):
  `db.gift_cards` {code, initial/balance_cents, active, source manual|purchase, history[]}. Helpers
  `preview_gift_card`, `redeem_gift_card` (idempotent per order via history scan), `issue_gift_card_for_purchase`.
- NEW `routes/shop_customers.py` (`/api/public/shop/{org}/*`): passwordless auth (`db.shop_login_codes`,
  sha256(code:JWT_SECRET), 15-min TTL, rl.check 8/15min, dev_code echoed only when `config.simulation_allowed()`),
  `create_access_token(cust_id, org, "shopper", extra={shop:True,email})`, `current_shopper` dep (role+org bound),
  saved cart (`db.shop_carts`, hydrated), order history (by customer_id or buyer.email).
- `routes/store.py`: BuyNowReq gained `gift_card_code` + `customer_token`; `_product_out`/ProductIn/Patch gained
  `bundle_items` + `gift_card_amount_cents`; `_order_out` gained `gift_card_cents/gift_card_code/amount_charged_cents/
  customer_id`; buy-now resolves buyer group + gift card, supports a fully-covered FREE order (provider "gift_card",
  finalized immediately), else charges `amount_charged`; `_finalize_paid_order` redeems the gift card + issues gift
  cards for `gift_card` products (both idempotent under the atomic finalize claim). `_shopper_id_from_token` helper.
- `routes/ecommerce.py`: `DiscountIn.eligible_groups` + `_discount_out`; `compute_discount(…, buyer_group)` skips
  group-limited rules for non-members; `best_discount(…, buyer_group)`; `resolve_buyer_group(db, org, cust_id, email)`
  (shop account first, then CRM contact by email).
- `models_crm.Contact.customer_group` + `crm.ContactPatch.customer_group`.
- `server.py`: registered gift_cards router+public_router and shop_customers router.
- FRONTEND: `pages/public/Storefront.jsx` (gift-card input + "Apply", account dialog `ShopAccountDialog` with
  passwordless sign-in + order history + sign out; testids `storefront-gift-code/-check/-line`, `storefront-account-btn`,
  `shop-login-email/-send/-code/-verify`, `shop-orders`, `shop-signout`); `pages/dashboard/Discounts.jsx`
  ("Gift cards" tab `GiftCardsTab`, testids `giftcard-*`; discount `eligible_groups` input `discount-groups`);
  `pages/dashboard/Products.jsx` (gift_card/bundle product types + fields `product-form-giftamount/-bundle`);
  `pages/dashboard/CrmContactDetail.jsx` (`contact-group-input`).
- Verified by main via curl: full gift-card lifecycle, shopper auth→cart→buy-now→pay→history, free order, issue-on-purchase.

### 2.2 R12-B2 Developer docs page
- NEW `pages/Developers.jsx` (route `/developers`, nav link `nav-developers-link` in `PublicNav.jsx`): brand-aware public
  docs — authentication with scoped `yv_` API keys, the REAL `/api/public/v1/*` endpoints (contacts GET/POST,
  bookings GET/POST, invoices GET, quotes GET, whoami), signed-webhook verification (`X-Zanelvo-Signature` HMAC),
  and limits/safety notes. Reuses `PublicNav` + `useBrand` + `usePageMeta`. Endpoints/paths were cross-checked
  against `routes/public_api.py` so the docs are truthful. No backend change; lint clean; renders verified.

---------------------------------------------------------------------------------------------------
## 3. STILL NOT DONE (do NOT claim live) — carried from Round 11 §3 + Round 12 remaining
---------------------------------------------------------------------------------------------------
- 🔒 BLOCKED ON OWNER CREDENTIALS: PayPal live rail · real SSL issuance (Cloudflare for SaaS / Vercel) ·
  live carrier rates (Shippo/EasyPost key) · ad-account OAuth (Google/Meta) · SMS/WhatsApp provider · Stripe Connect.
- ⬜ Subscriptions (Stripe Billing) · drag-and-drop email editor · per-language authored site content ·
  Redis-backed rate limits · developer docs page · Home + Pricing "wow" redesign · Lighthouse/axe pass.

---------------------------------------------------------------------------------------------------
## 4. GIT / RULES
---------------------------------------------------------------------------------------------------
Do NOT push from the agent — use the chat's **Save to Github** button. Never modify `.env` MONGO_URL/DB_NAME,
never hardcode URLs, all backend routes under `/api`, UUIDs not ObjectId for new collections.
