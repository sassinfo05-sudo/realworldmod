import { createContext, useContext, useEffect, useState } from "react";
import api from "@/lib/api";

const BrandContext = createContext(null);

const FALLBACK = {
    name: "",  // no hardcoded default — API supplies the real brand name
    status: "loading",
    tagline: "",
    promise: "Everything your business needs to get found, book work, and get paid.",
    cta_label: "Build my website",
    logo_svg: null,
    support_email: "",
    product_url: "",
    company_name: "",
    footer_note: "",
    emails: {},
};

export function BrandProvider({ children }) {
    const [brand, setBrand] = useState(FALLBACK);

    useEffect(() => {
        let mounted = true;
        api.get("/brand").then((r) => {
            if (mounted && r.data && r.data.name) setBrand(r.data);
        }).catch(() => {});
        return () => { mounted = false; };
    }, []);

    return <BrandContext.Provider value={brand}>{children}</BrandContext.Provider>;
}

export function useBrand() {
    const ctx = useContext(BrandContext);
    return ctx || FALLBACK;
}
