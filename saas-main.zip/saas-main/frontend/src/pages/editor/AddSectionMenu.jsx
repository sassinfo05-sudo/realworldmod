/**
 * AddSectionMenu — an "+ Add section" menu that lists the block library and inserts
 * a new block at a specified position (append if `atIndex` is undefined). Blocks come
 * from GET /api/editor/block-library and are given sensible default props by the
 * `DEFAULT_PROPS` map so the freshly-inserted section looks intentional.
 */
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import api from "@/lib/api";
import { Plus, Sparkles, Layout, Grid, Users, Star, Zap, Clock, FormInput, Layers, Search, ShoppingBag, HelpCircle, Image as ImageIcon, Tags, Video, MapPin, BarChart3, UserRound, Building2, Timer, Share2, AlignLeft, Bookmark, Trash2 } from "lucide-react";
import { EXTRA_DEFAULT_PROPS } from "@/components/blocks/ExtraBlocks";

const TYPE_META = {
    hero:           { icon: Sparkles, label: "Hero" },
    services_grid:  { icon: Grid, label: "Services" },
    about_split:    { icon: Users, label: "About" },
    testimonials:   { icon: Star, label: "Testimonials" },
    cta_band:       { icon: Zap, label: "Call to action" },
    contact_hours:  { icon: Clock, label: "Contact & hours" },
    form:           { icon: FormInput, label: "Form" },
    store:          { icon: ShoppingBag, label: "Store" },
    faq:            { icon: HelpCircle, label: "FAQ" },
    gallery:        { icon: ImageIcon, label: "Gallery" },
    pricing_table:  { icon: Tags, label: "Pricing table" },
    video:          { icon: Video, label: "Video" },
    map:            { icon: MapPin, label: "Map" },
    stats:          { icon: BarChart3, label: "Stats / numbers" },
    team:           { icon: UserRound, label: "Team" },
    logo_cloud:     { icon: Building2, label: "Logo cloud" },
    countdown:      { icon: Timer, label: "Countdown" },
    social_links:   { icon: Share2, label: "Social links" },
    text:           { icon: AlignLeft, label: "Rich text" },
    blog_list:      { icon: AlignLeft, label: "Blog — latest articles" },
    booking:        { icon: Clock, label: "Booking — live availability" },
    footer:         { icon: Layout, label: "Footer" },
};

const DEFAULT_PROPS = {
    ...EXTRA_DEFAULT_PROPS,
    blog_list: { title: "Latest articles", subtitle: "Tips and news from our team.", limit: 3 },
    booking: { headline: "Book a visit", subheadline: "Pick a time that suits you — confirmation is instant.", confirm_label: "Confirm booking" },
    hero: {
        eyebrow: "Welcome",
        headline: "A great headline goes here",
        subheadline: "One line that explains what you do and why customers pick you.",
        primary_cta: { label: "Get started", href: "#contact" },
        secondary_cta: { label: "Learn more", href: "#services" },
        image: "",
    },
    services_grid: {
        eyebrow: "What we do",
        headline: "Services",
        subheadline: "",
        services: [],
    },
    about_split: {
        eyebrow: "About",
        headline: "Our story",
        body: "Tell customers who you are — one paragraph. Real, not corporate.",
        image: "",
    },
    testimonials: {
        eyebrow: "Loved by customers",
        headline: "What people say",
        items: [
            { quote: "They made the process painless.", author: "Happy customer" },
            { quote: "Fast, friendly, would use again.", author: "Repeat client" },
            { quote: "Set-up was under an afternoon.", author: "Local business" },
        ],
    },
    cta_band: {
        headline: "Ready to get started?",
        subheadline: "One quick call. We'll take it from there.",
        primary_cta: { label: "Contact us", href: "#contact" },
    },
    contact_hours: {
        headline: "Come see us",
        address: "",
        phone: "",
        email: "",
        hours: [{ day: "Mon–Fri", time: "9am – 6pm" }, { day: "Sat", time: "10am – 4pm" }],
    },
    form: {
        headline: "Get in touch",
        submit_label: "Send message",
        fields: [
            { name: "name",  label: "Your name",  type: "text",     required: true },
            { name: "email", label: "Email",       type: "email",    required: true },
            { name: "message", label: "Message",   type: "textarea", required: true },
        ],
    },
    store: {
        heading: "Shop",
        subheading: "Browse our products and check out securely.",
        columns: 3,
    },
    footer: {
        business_name: "",
        tagline: "",
        phone: "",
        email: "",
    },
};

export default function AddSectionMenu({ onAdd, testid = "add-section" }) {
    const [open, setOpen] = useState(false);
    const [library, setLibrary] = useState([]);
    const [saved, setSaved] = useState([]);
    const [q, setQ] = useState("");

    useEffect(() => {
        if (!open) return;
        (async () => {
            try {
                if (!library.length) {
                    const { data } = await api.get("/editor/block-library");
                    setLibrary(data?.blocks || []);
                }
                const { data: sv } = await api.get("/editor/saved-sections");
                setSaved(sv?.sections || []);
            } catch (e) { /* silent */ }
        })();
    }, [open, library.length]);

    async function removeSaved(id) {
        try { await api.delete(`/editor/saved-sections/${id}`); setSaved((s) => s.filter((x) => x.id !== id)); } catch (e) { /* silent */ }
    }
    function insertSaved(sec) {
        onAdd({ type: sec.type, variant: sec.variant || "a", props: JSON.parse(JSON.stringify(sec.props || {})), style: { ...(sec.style || {}) } });
        setOpen(false); setQ("");
    }
    const visibleSaved = saved.filter((sec) => !q.trim() || (sec.name || "").toLowerCase().includes(q.trim().toLowerCase()));

    // Group by type
    const grouped = library.reduce((acc, b) => {
        (acc[b.type] = acc[b.type] || []).push(b);
        return acc;
    }, {});

    const filter = q.trim().toLowerCase();
    const visibleTypes = Object.keys(grouped).filter((t) =>
        !filter || t.includes(filter) || (grouped[t].some((v) => v.label?.toLowerCase().includes(filter)))
    );

    function insert(entry) {
        const type = entry.type;
        const variant = entry.variant || "a";
        const props = DEFAULT_PROPS[type] ? JSON.parse(JSON.stringify(DEFAULT_PROPS[type])) : {};
        onAdd({ type, variant, props, style: {} });
        setOpen(false);
        setQ("");
    }

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button
                    size="sm"
                    className="bg-brand-copper hover:bg-brand-copperHover text-white shadow-md"
                    data-testid={testid}>
                    <Plus className="w-4 h-4 mr-1" /> Add section
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
                <DialogHeader>
                    <DialogTitle>Add a section</DialogTitle>
                </DialogHeader>
                <div className="flex items-center gap-2 border border-brand-line rounded-md px-3 py-2 bg-white">
                    <Search className="w-4 h-4 text-zinc-400" />
                    <input value={q} onChange={(e) => setQ(e.target.value)}
                            placeholder="Search sections (hero, services, testimonials…)"
                            className="flex-1 outline-none text-sm bg-transparent"
                            data-testid="add-section-search" />
                </div>
                <div className="mt-4 max-h-[60vh] overflow-y-auto pr-1 space-y-6">
                    {visibleSaved.length > 0 && (
                        <div data-testid="add-section-group-saved">
                            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-brand-copper mb-2">
                                <Bookmark className="w-3.5 h-3.5" /> Saved sections
                            </div>
                            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                {visibleSaved.map((sec) => (
                                    <div key={sec.id} className="relative rounded-lg border border-brand-line bg-white hover:border-brand-copper transition-colors p-3 text-left" data-testid={`add-saved-${sec.id}`}>
                                        <button onClick={() => insertSaved(sec)} className="w-full text-left">
                                            <div className="text-sm font-medium text-brand-ink truncate">{sec.name}</div>
                                            <div className="text-[11px] text-zinc-500 capitalize">{(sec.type || "").replace("_", " ")} · variant {sec.variant || "a"}</div>
                                        </button>
                                        <button onClick={() => removeSaved(sec.id)} className="absolute top-2 right-2 text-zinc-400 hover:text-red-600" title="Delete saved section" data-testid={`add-saved-delete-${sec.id}`}>
                                            <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    {visibleTypes.map((type) => {
                        const meta = TYPE_META[type] || { icon: Layers, label: type };
                        const Icon = meta.icon;
                        return (
                            <div key={type} data-testid={`add-section-group-${type}`}>
                                <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-brand-copper mb-2">
                                    <Icon className="w-3.5 h-3.5" /> {meta.label}
                                </div>
                                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                    {grouped[type].map((entry) => (
                                        <button key={`${entry.type}-${entry.variant}`}
                                                onClick={() => insert(entry)}
                                                data-testid={`add-section-${entry.type}-${entry.variant}`}
                                                className="group text-left rounded-xl border border-brand-line bg-white p-4 hover:border-brand-copper hover:shadow-md transition-all">
                                            <div className="aspect-[4/2] rounded-md bg-gradient-to-br from-brand-cream to-white border border-brand-line flex items-center justify-center text-brand-copper/60">
                                                <Icon className="w-8 h-8 group-hover:scale-110 transition-transform" />
                                            </div>
                                            <div className="mt-3 text-sm font-medium text-brand-ink">{entry.label}</div>
                                            <div className="text-[11px] text-zinc-500 font-mono mt-0.5">
                                                {entry.type} · {entry.variant}
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        );
                    })}
                    {library.length === 0 && (
                        <div className="text-sm text-zinc-500 py-8 text-center">Loading section library…</div>
                    )}
                    {library.length > 0 && visibleTypes.length === 0 && (
                        <div className="text-sm text-zinc-500 py-8 text-center">No sections match &quot;{q}&quot;.</div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}
