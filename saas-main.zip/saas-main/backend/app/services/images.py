"""Curated Unsplash image URLs per industry + section type.

Rules from spec:
- Vetted URLs only — no broken links.
- No LLM credits burned on image generation in Phase 1.
- Renderer selects by (industry, section_type) and cycles for variety.
"""
from typing import Dict, List

# 8-12 vetted, deterministic Unsplash IDs (using /photo-id?w=1600&auto=format&fit=crop&q=80)
# These are well-known, long-lived Unsplash photos across relevant categories.
_UNSPLASH = "https://images.unsplash.com/photo-{id}?w=1600&auto=format&fit=crop&q=80"

INDUSTRY_IMAGES: Dict[str, Dict[str, List[str]]] = {
    "home_services": {
        "hero": [
            "1621905251189-08b45d6a269e",  # tools flat lay
            "1607472586893-edb57bdc0e39",  # plumber wrench pipes
            "1504307651254-35680f356dfd",  # workshop hands
        ],
        "services": [
            "1558618666-fcd25c85cd64",  # tool box
            "1607472586893-edb57bdc0e39",  # plumber wrench pipes
            "1590959651373-a3db0f38a961",  # electrical
            "1556909114-f6e7ad7d3136",  # home exterior
        ],
        "about": [
            "1591955506264-3f5a6834570a",  # team on site
            "1521791136064-7986c2920216",  # handshake
        ],
        "cta": ["1497366216548-37526070297c"],
    },
    "automotive": {
        "hero": [
            "1486262715619-67b85e0b08d3",  # car engine
            "1493238792000-8113da705763",  # workshop bay
            "1449965408869-eaa3f722e40d",  # mechanic hand tools
        ],
        "services": [
            "1487754180451-c456f719a1fc",  # under car
            "1552519507-da3b142c6e3d",  # sports car
            "1503376780353-7e6692767b70",  # tire
            "1568605114967-8130f3a36994",  # dash detail
        ],
        "about": [
            "1580273916550-e323be2ae537",  # garage door
            "1494976388531-d1058494cdd8",  # detail
        ],
        "cta": ["1494976388531-d1058494cdd8"],
    },
    "beauty_wellness": {
        "hero": [
            "1560066984-138dadb4c035",  # salon interior
            "1522337360788-8b13dee7a37e",  # hair styling
            "1560750588-73207b1ef5b8",  # spa
        ],
        "services": [
            "1522337660859-02fbefca4702",  # hairdresser
            "1607779097040-26e80aa78e66",  # nails
            "1519415943484-9fa1873496d4",  # facial
            "1596178065887-1198b6148b2b",  # calm spa
        ],
        "about": [
            "1600948836101-f9ffda59d250",  # stylist portrait
            "1580618672591-eb180b1a973f",  # products flat lay
        ],
        "cta": ["1522336572468-97b06e8ef143"],
    },
    "professional_services": {
        "hero": [
            "1454165804606-c3d57bc86b40",  # laptop workspace
            "1590650046871-92c887180603",  # meeting
            "1450101499163-c8848c66ca85",  # abstract office
        ],
        "services": [
            "1552664730-d307ca884978",  # collaboration
            "1552581234-26160f608093",  # discussion
            "1573497019940-1c28c88b4f3e",  # advisor
            "1521737604893-d14cc237f11d",  # meeting 2
        ],
        "about": [
            "1520607162513-77705b0f0d4a",  # portrait
            "1521737711867-e3b97375f902",  # workshop meeting
        ],
        "cta": ["1521737852567-6949f3f9f2b5"],
    },
    "fitness": {
        "hero": [
            "1517836357463-d25dfeac3438",
            "1571019613454-1cb2f99b2d8b",
            "1534438327276-14e5300c3a48",
        ],
        "services": [
            "1517963628607-235ccdd5476f",
            "1518611012118-696072aa579a",
            "1526506118085-60ce8714f8c5",
            "1546484475-7f7bd55792da",
        ],
        "about": ["1571019614242-c5c5dee9f50b"],
        "cta": ["1571902943202-507ec2618e8f"],
    },
    "cleaning": {
        "hero": [
            "1581578731548-c64695cc6952",  # spray bottle
            "1584622650111-993a426fbf0a",  # cleaner
            "1527515637462-cff94eecc1ac",
        ],
        "services": [
            "1583947215259-38e31be8751f",
            "1596263576925-d90b90b3812c",
            "1600585154340-be6161a56a0c",
            "1527515637462-cff94eecc1ac",
        ],
        "about": ["1585421514738-01798e348b17"],
        "cta": ["1585421514738-01798e348b17"],
    },
    "events": {
        "hero": [
            "1519671482749-fd09be7ccebf",
            "1464366400600-7168b8af9bc3",
            "1478147427282-58a87a120781",
        ],
        "services": [
            "1519741497674-611481863552",
            "1467810563316-b5476525c0f9",
            "1470753937643-efeb931202a9",
            "1464366400600-7168b8af9bc3",
        ],
        "about": ["1519741497674-611481863552"],
        "cta": ["1519671482749-fd09be7ccebf"],
    },
    "other": {
        "hero": [
            "1454165804606-c3d57bc86b40",
            "1497366216548-37526070297c",
            "1521737711867-e3b97375f902",
        ],
        "services": [
            "1454165804606-c3d57bc86b40",
            "1521737604893-d14cc237f11d",
            "1521737711867-e3b97375f902",
            "1497366216548-37526070297c",
        ],
        "about": ["1454165804606-c3d57bc86b40"],
        "cta": ["1454165804606-c3d57bc86b40"],
    },
}


def build_url(photo_id: str) -> str:
    return _UNSPLASH.format(id=photo_id)


def pick_images(industry: str, section: str, count: int = 1) -> List[str]:
    industry = industry if industry in INDUSTRY_IMAGES else "other"
    pool = INDUSTRY_IMAGES[industry].get(section) or INDUSTRY_IMAGES[industry]["hero"]
    urls = [build_url(pid) for pid in pool]
    if count <= 0:
        return []
    # Repeat pool if needed
    out = []
    while len(out) < count:
        out.extend(urls)
    return out[:count]
