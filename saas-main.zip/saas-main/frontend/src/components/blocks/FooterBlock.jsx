export default function FooterBlock({ block, theme }) {
    const { props = {} } = block;
    const { business_name, tagline, email, phone } = props;
    return (
        <footer className="py-10 border-t"
                style={{ borderColor: `${theme?.foreground}14`, backgroundColor: theme?.background }}>
            <div className="mx-auto max-w-6xl px-6 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="text-sm">
                    <span className="font-semibold" data-heading style={{ color: theme?.foreground }}>
                        {business_name}
                    </span>
                    {tagline && (
                        <span className="ml-2" style={{ color: `${theme?.foreground}90` }}>· {tagline}</span>
                    )}
                </div>
                <div className="text-sm" style={{ color: `${theme?.foreground}90` }}>
                    {phone && <a href={`tel:${phone}`} className="mr-4">{phone}</a>}
                    {email && <a href={`mailto:${email}`}>{email}</a>}
                </div>
            </div>
        </footer>
    );
}
