"""CRM routes — Contacts, Companies, Custom Fields, Pipelines, Deals, Notes,
Tasks, Interactions timeline, Lead scoring, Merge, CSV import.

Every route uses require_org and NEVER trusts a client-supplied org_id.
Auto-created contacts (from forms/inbound emails) share the same collections
so timeline entries and lead scoring work uniformly.
"""
from __future__ import annotations

import csv
import io
import logging
import uuid
from typing import Any, Dict, List, Literal, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel, EmailStr, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User, BusinessProfile
from ..models_crm import (
    Company, ConsentRecord, Contact, ContactImportRun, CustomFieldDef, Deal,
    ImportMapping, Interaction, Note, Pipeline, Stage, Task,
)
from ..services.lead_scoring import score_contact
from ..services.entitlements import enforce_entitlement

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/crm", tags=["crm"])


# ---------------- helpers ----------------

def _norm_email(e: Optional[str]) -> Optional[str]:
    return e.strip().lower() if e else None


async def _record_interaction(db, org_id: str, *, contact_id: Optional[str], type_: str,
                               summary: str, ref_type: Optional[str] = None,
                               ref_id: Optional[str] = None, meta: Optional[Dict[str, Any]] = None,
                               author_user_id: Optional[str] = None,
                               deal_id: Optional[str] = None) -> None:
    inter = Interaction(org_id=org_id, contact_id=contact_id, deal_id=deal_id,
                        type=type_, summary=summary,
                        ref_type=ref_type, ref_id=ref_id, meta=meta or {},
                        author_user_id=author_user_id)
    await db.interactions.insert_one(inter.to_mongo())
    # bump last_activity_at on the contact
    if contact_id:
        await db.contacts.update_one({"_id": ObjectId(contact_id), "org_id": org_id},
                                      {"$set": {"last_activity_at": utc_now_iso(),
                                                "updated_at": utc_now_iso()}})


async def upsert_contact_from_form(db, org_id: str, fields: Dict[str, Any],
                                    source: str = "form",
                                    submission_id: Optional[str] = None,
                                    website_id: Optional[str] = None) -> Optional[str]:
    """Auto-create/update a Contact from a public form submission. Idempotent on email/phone.

    Returns the contact_id. Also emits a `form_submitted` interaction.
    """
    email = _norm_email(fields.get("email") or fields.get("Email"))
    phone = (fields.get("phone") or fields.get("Phone") or "").strip() or None
    name = (fields.get("name") or fields.get("Name") or "").strip() or None
    first, last = (name.split(" ", 1) + [None])[:2] if name else (None, None)
    message = (fields.get("message") or fields.get("Message") or "").strip() or None

    # Match on email first, then phone
    existing = None
    if email:
        existing = await db.contacts.find_one({"org_id": org_id, "emails": email})
    if not existing and phone:
        existing = await db.contacts.find_one({"org_id": org_id, "phones": phone})

    if existing:
        cid = str(existing["_id"])
        # Merge: append any new email/phone; keep names if present else fill in
        set_updates: Dict[str, Any] = {"updated_at": utc_now_iso(),
                                        "last_activity_at": utc_now_iso()}
        add_to_set: Dict[str, Any] = {}
        if email and email not in (existing.get("emails") or []):
            add_to_set["emails"] = email
        if phone and phone not in (existing.get("phones") or []):
            add_to_set["phones"] = phone
        if first and not existing.get("first_name"):
            set_updates["first_name"] = first
        if last and not existing.get("last_name"):
            set_updates["last_name"] = last
        update: Dict[str, Any] = {"$set": set_updates}
        if add_to_set:
            update["$addToSet"] = add_to_set
        await db.contacts.update_one({"_id": existing["_id"]}, update)
    else:
        # Create new — enforce entitlement first. Over-cap raises 402 which the public
        # form handler catches and surfaces as a friendly "form couldn't accept — please
        # try again later" (never a raw plan-limit leak to a visitor).
        await enforce_entitlement(org_id, "contacts", increment=1)
        emails = [email] if email else []
        phones = [phone] if phone else []
        display = name or email or phone or "Unnamed contact"
        contact = Contact(
            org_id=org_id, first_name=first, last_name=last,
            display_name=display, emails=emails, phones=phones,
            source=source, tags=[], custom_fields={},
            consents=[ConsentRecord(channel="email", status="granted",
                                     ts=utc_now_iso(), source=source)] if email else [],
            last_activity_at=utc_now_iso(),
        )
        res = await db.contacts.insert_one(contact.to_mongo())
        cid = str(res.inserted_id)
        try:  # workflow trigger: new lead / contact created
            from ..services import workflows as _wfs
            await _wfs.fire(org_id, "new_lead", {"contact_id": cid, "email": email, "phone": phone,
                                                 "name": display, "source": source})
        except Exception as _e:  # noqa: BLE001
            logger.warning("new_lead workflow trigger failed: %s", _e)

    await _record_interaction(db, org_id, contact_id=cid, type_="form_submitted",
                               summary=(message[:120] + "…") if (message and len(message) > 120)
                                       else (message or "Form submission received"),
                               ref_type="form_submission", ref_id=submission_id,
                               meta={"fields": fields, "website_id": website_id})
    return cid


# ---------------- Contacts ----------------

class ContactCreate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    display_name: Optional[str] = None
    emails: List[EmailStr] = Field(default_factory=list)
    phones: List[str] = Field(default_factory=list)
    company_id: Optional[str] = None
    title: Optional[str] = None
    address: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    custom_fields: Dict[str, Any] = Field(default_factory=dict)
    language: Optional[str] = None
    source: str = "manual"


@router.post("/contacts")
async def create_contact(req: ContactCreate, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    await enforce_entitlement(org_id, "contacts", increment=1)
    emails = [_norm_email(e) for e in req.emails if e]
    contact = Contact(org_id=org_id, **{**req.model_dump(), "emails": emails,
                                          "owner_user_id": user.id})
    res = await db.contacts.insert_one(contact.to_mongo())
    contact.id = str(res.inserted_id)
    await _record_interaction(db, org_id, contact_id=contact.id, type_="contact_created",
                               summary="Contact created", author_user_id=user.id)
    return contact.model_dump()


@router.get("/contacts")
async def list_contacts(q: Optional[str] = None, tag: Optional[str] = None,
                         owner_user_id: Optional[str] = None, limit: int = 100,
                         user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    query: Dict[str, Any] = {"org_id": org_id}
    if tag:
        query["tags"] = tag
    if owner_user_id:
        query["owner_user_id"] = owner_user_id
    if q:
        rx = {"$regex": q, "$options": "i"}
        query["$or"] = [{"display_name": rx}, {"first_name": rx},
                         {"last_name": rx}, {"emails": rx}, {"phones": rx}]
    cursor = db.contacts.find(query).sort("last_activity_at", -1).limit(min(limit, 500))
    return {"contacts": [Contact.from_mongo(d).model_dump() async for d in cursor]}


@router.get("/contacts/{contact_id}")
async def get_contact(contact_id: str, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.contacts.find_one({"_id": ObjectId(contact_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Contact not found")
    return Contact.from_mongo(doc).model_dump()


class ContactPatch(BaseModel):
    model_config = {"extra": "forbid"}
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    display_name: Optional[str] = None
    emails: Optional[List[EmailStr]] = None
    phones: Optional[List[str]] = None
    company_id: Optional[str] = None
    title: Optional[str] = None
    address: Optional[str] = None
    tags: Optional[List[str]] = None
    customer_group: Optional[str] = None
    custom_fields: Optional[Dict[str, Any]] = None
    language: Optional[str] = None
    owner_user_id: Optional[str] = None


@router.patch("/contacts/{contact_id}")
async def patch_contact(contact_id: str, patch: ContactPatch,
                         user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    updates = {k: v for k, v in patch.model_dump(exclude_none=True).items()}
    if "emails" in updates:
        updates["emails"] = [_norm_email(e) for e in updates["emails"] if e]
    updates["updated_at"] = utc_now_iso()
    res = await db.contacts.update_one({"_id": ObjectId(contact_id), "org_id": org_id},
                                        {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(404, "Contact not found")
    doc = await db.contacts.find_one({"_id": ObjectId(contact_id), "org_id": org_id})
    await _record_interaction(db, org_id, contact_id=contact_id, type_="contact_updated",
                               summary="Contact details updated", author_user_id=user.id)
    return Contact.from_mongo(doc).model_dump()


class BulkAction(BaseModel):
    ids: List[str]
    action: Literal["tag", "untag", "assign", "delete"]
    payload: Dict[str, Any] = Field(default_factory=dict)


@router.post("/contacts/bulk")
async def bulk_contact_action(req: BulkAction, user: User = Depends(current_user),
                               org_id: str = Depends(require_org)):
    db = get_db()
    ids = [ObjectId(x) for x in req.ids]
    q = {"_id": {"$in": ids}, "org_id": org_id}
    if req.action == "delete":
        # Also delete related notes/interactions? Cascade for now to keep data tight.
        await db.notes.delete_many({"org_id": org_id, "entity_id": {"$in": req.ids}, "entity_type": "contact"})
        await db.interactions.delete_many({"org_id": org_id, "contact_id": {"$in": req.ids}})
        res = await db.contacts.delete_many(q)
        return {"ok": True, "deleted": res.deleted_count}
    if req.action == "tag":
        tag = req.payload.get("tag")
        if not tag:
            raise HTTPException(400, "payload.tag required")
        await db.contacts.update_many(q, {"$addToSet": {"tags": tag},
                                            "$set": {"updated_at": utc_now_iso()}})
        return {"ok": True}
    if req.action == "untag":
        tag = req.payload.get("tag")
        if not tag:
            raise HTTPException(400, "payload.tag required")
        await db.contacts.update_many(q, {"$pull": {"tags": tag},
                                            "$set": {"updated_at": utc_now_iso()}})
        return {"ok": True}
    if req.action == "assign":
        assignee = req.payload.get("owner_user_id")
        await db.contacts.update_many(q, {"$set": {"owner_user_id": assignee,
                                                     "updated_at": utc_now_iso()}})
        return {"ok": True}
    raise HTTPException(400, "unknown action")


class MergeReq(BaseModel):
    primary_id: str
    duplicate_id: str


@router.post("/contacts/merge")
async def merge_contacts(req: MergeReq, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    if req.primary_id == req.duplicate_id:
        raise HTTPException(400, "primary and duplicate must differ")
    p = await db.contacts.find_one({"_id": ObjectId(req.primary_id), "org_id": org_id})
    d = await db.contacts.find_one({"_id": ObjectId(req.duplicate_id), "org_id": org_id})
    if not p or not d:
        raise HTTPException(404, "Contact not found")
    # Merge fields: unions for lists; keep primary's names/owner
    merged_emails = list({*(p.get("emails") or []), *(d.get("emails") or [])})
    merged_phones = list({*(p.get("phones") or []), *(d.get("phones") or [])})
    merged_tags = list({*(p.get("tags") or []), *(d.get("tags") or [])})
    await db.contacts.update_one({"_id": p["_id"]}, {"$set": {
        "emails": merged_emails, "phones": merged_phones, "tags": merged_tags,
        "first_name": p.get("first_name") or d.get("first_name"),
        "last_name": p.get("last_name") or d.get("last_name"),
        "updated_at": utc_now_iso(),
    }})
    # Re-parent related items
    await db.notes.update_many({"org_id": org_id, "entity_type": "contact",
                                 "entity_id": req.duplicate_id}, {"$set": {"entity_id": req.primary_id}})
    await db.interactions.update_many({"org_id": org_id, "contact_id": req.duplicate_id},
                                       {"$set": {"contact_id": req.primary_id}})
    await db.conversations.update_many({"org_id": org_id, "contact_id": req.duplicate_id},
                                        {"$set": {"contact_id": req.primary_id}})
    await db.deals.update_many({"org_id": org_id, "contact_id": req.duplicate_id},
                                {"$set": {"contact_id": req.primary_id}})
    await db.contacts.delete_one({"_id": d["_id"]})
    await _record_interaction(db, org_id, contact_id=req.primary_id, type_="contact_merged",
                               summary=f"Merged duplicate contact ({d.get('display_name') or ''})",
                               author_user_id=user.id)
    return {"ok": True}


@router.get("/contacts/{contact_id}/timeline")
async def contact_timeline(contact_id: str, limit: int = 100,
                            user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.interactions.find({"org_id": org_id, "contact_id": contact_id}) \
                             .sort("created_at", -1).limit(min(limit, 500))
    return {"interactions": [Interaction.from_mongo(d).model_dump() async for d in cursor]}


@router.get("/contacts/{contact_id}/lead-score")
async def contact_lead_score(contact_id: str, refresh: bool = False,
                              user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.contacts.find_one({"_id": ObjectId(contact_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Contact not found")
    if not refresh and doc.get("lead_score") is not None:
        return {"score": doc.get("lead_score"),
                "factors": doc.get("lead_score_factors") or [],
                "breakdown": doc.get("lead_score_breakdown") or {},
                "cached": True,
                "updated_at": doc.get("lead_score_updated_at")}
    business = await db.business_profiles.find_one({"org_id": org_id})
    business_dict = None
    if business:
        business_dict = BusinessProfile.from_mongo(business).model_dump()
    contact_dict = Contact.from_mongo(doc).model_dump()
    result = await score_contact(contact_dict, business_dict)
    await db.contacts.update_one(
        {"_id": doc["_id"]},
        {"$set": {"lead_score": result["score"],
                   "lead_score_factors": result["factors"],
                   "lead_score_breakdown": result["breakdown"],
                   "lead_score_updated_at": utc_now_iso(),
                   "updated_at": utc_now_iso()}},
    )
    return {**result, "cached": False, "updated_at": utc_now_iso()}


# ---------------- Companies ----------------

class CompanyCreate(BaseModel):
    name: str
    domain: Optional[str] = None
    website: Optional[str] = None
    industry: Optional[str] = None
    size: Optional[str] = None
    tags: List[str] = Field(default_factory=list)


@router.post("/companies")
async def create_company(req: CompanyCreate, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    co = Company(org_id=org_id, **req.model_dump())
    res = await db.companies.insert_one(co.to_mongo())
    co.id = str(res.inserted_id)
    return co.model_dump()


@router.get("/companies")
async def list_companies(q: Optional[str] = None, limit: int = 100,
                          user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    query: Dict[str, Any] = {"org_id": org_id}
    if q:
        query["name"] = {"$regex": q, "$options": "i"}
    cursor = db.companies.find(query).sort("created_at", -1).limit(min(limit, 500))
    return {"companies": [Company.from_mongo(d).model_dump() async for d in cursor]}


# ---------------- Custom fields ----------------

class CustomFieldCreate(BaseModel):
    entity: Literal["contact", "company", "deal"] = "contact"
    key: str
    label: str
    type: Literal["text", "number", "date", "select", "multi_select", "boolean", "url"] = "text"
    options: List[str] = Field(default_factory=list)
    required: bool = False
    order: int = 0


@router.post("/custom-fields")
async def create_custom_field(req: CustomFieldCreate, user: User = Depends(current_user),
                                org_id: str = Depends(require_org)):
    db = get_db()
    existing = await db.custom_field_defs.find_one(
        {"org_id": org_id, "entity": req.entity, "key": req.key})
    if existing:
        raise HTTPException(409, "custom field key already exists for this entity")
    d = CustomFieldDef(org_id=org_id, **req.model_dump())
    res = await db.custom_field_defs.insert_one(d.to_mongo())
    d.id = str(res.inserted_id)
    return d.model_dump()


@router.get("/custom-fields")
async def list_custom_fields(entity: str = "contact", user: User = Depends(current_user),
                                org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.custom_field_defs.find({"org_id": org_id, "entity": entity}).sort("order", 1)
    return {"defs": [CustomFieldDef.from_mongo(d).model_dump() async for d in cursor]}


# ---------------- Pipelines & Deals ----------------

DEFAULT_STAGES = [
    Stage(id=uuid.uuid4().hex[:8], name="New lead", order=0, kind="open", color="#f59e0b"),
    Stage(id=uuid.uuid4().hex[:8], name="Qualified", order=1, kind="open", color="#0ea5e9"),
    Stage(id=uuid.uuid4().hex[:8], name="Quoted", order=2, kind="open", color="#8b5cf6"),
    Stage(id=uuid.uuid4().hex[:8], name="Booked / Won", order=3, kind="won", color="#22c55e"),
    Stage(id=uuid.uuid4().hex[:8], name="Lost", order=4, kind="lost", color="#71717a"),
]


async def _ensure_default_pipeline(db, org_id: str) -> Pipeline:
    doc = await db.pipelines.find_one({"org_id": org_id, "is_default": True})
    if doc:
        return Pipeline.from_mongo(doc)
    pl = Pipeline(org_id=org_id, name="Leads", is_default=True,
                   stages=[Stage(id=uuid.uuid4().hex[:8], name=s.name, order=s.order,
                                  kind=s.kind, color=s.color) for s in DEFAULT_STAGES])
    res = await db.pipelines.insert_one(pl.to_mongo())
    pl.id = str(res.inserted_id)
    return pl


@router.get("/pipelines")
async def list_pipelines(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    default = await _ensure_default_pipeline(db, org_id)
    cursor = db.pipelines.find({"org_id": org_id}).sort("created_at", 1)
    pls = [Pipeline.from_mongo(d).model_dump() async for d in cursor]
    return {"pipelines": pls, "default_id": default.id}


class DealCreate(BaseModel):
    pipeline_id: str
    stage_id: str
    name: str
    value: Optional[float] = None
    contact_id: Optional[str] = None
    company_id: Optional[str] = None
    expected_close_at: Optional[str] = None


@router.post("/deals")
async def create_deal(req: DealCreate, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    db = get_db()
    pl = await db.pipelines.find_one({"_id": ObjectId(req.pipeline_id), "org_id": org_id})
    if not pl:
        raise HTTPException(404, "Pipeline not found")
    if not any(s["id"] == req.stage_id for s in (pl.get("stages") or [])):
        raise HTTPException(400, "stage_id not in pipeline")
    if req.contact_id:
        cc = await db.contacts.find_one({"_id": ObjectId(req.contact_id), "org_id": org_id})
        if not cc:
            raise HTTPException(404, "Contact not found")
    deal = Deal(org_id=org_id, owner_user_id=user.id, stage_updated_at=utc_now_iso(),
                 **req.model_dump())
    res = await db.deals.insert_one(deal.to_mongo())
    deal.id = str(res.inserted_id)
    await _record_interaction(db, org_id, contact_id=req.contact_id, deal_id=deal.id,
                               type_="deal_created",
                               summary=f"Deal created: {req.name}", author_user_id=user.id)
    return deal.model_dump()


@router.get("/deals")
async def list_deals(pipeline_id: Optional[str] = None,
                      user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if pipeline_id:
        q["pipeline_id"] = pipeline_id
    cursor = db.deals.find(q).sort("stage_updated_at", -1)
    return {"deals": [Deal.from_mongo(d).model_dump() async for d in cursor]}


class DealStageMove(BaseModel):
    stage_id: str


@router.patch("/deals/{deal_id}/stage")
async def move_deal_stage(deal_id: str, req: DealStageMove,
                            user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.deals.find_one({"_id": ObjectId(deal_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Deal not found")
    pl = await db.pipelines.find_one({"_id": ObjectId(doc["pipeline_id"]), "org_id": org_id})
    stages = {s["id"]: s for s in (pl.get("stages") or [])}
    if req.stage_id not in stages:
        raise HTTPException(400, "stage_id not in pipeline")
    old_stage_id = doc.get("stage_id")
    await db.deals.update_one({"_id": doc["_id"]},
                                {"$set": {"stage_id": req.stage_id,
                                            "stage_updated_at": utc_now_iso(),
                                            "updated_at": utc_now_iso()}})
    await _record_interaction(db, org_id, contact_id=doc.get("contact_id"), deal_id=deal_id,
                               type_="deal_stage_changed",
                               summary=f"Moved from {stages.get(old_stage_id,{}).get('name','?')} → {stages[req.stage_id]['name']}",
                               author_user_id=user.id)
    fresh = await db.deals.find_one({"_id": doc["_id"]})
    return Deal.from_mongo(fresh).model_dump()


class DealPatch(BaseModel):
    model_config = {"extra": "forbid"}
    name: Optional[str] = None
    value: Optional[float] = None
    expected_close_at: Optional[str] = None
    contact_id: Optional[str] = None
    owner_user_id: Optional[str] = None


@router.patch("/deals/{deal_id}")
async def patch_deal(deal_id: str, req: DealPatch,
                      user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    updates = {k: v for k, v in req.model_dump(exclude_none=True).items()}
    updates["updated_at"] = utc_now_iso()
    res = await db.deals.update_one({"_id": ObjectId(deal_id), "org_id": org_id},
                                     {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(404, "Deal not found")
    fresh = await db.deals.find_one({"_id": ObjectId(deal_id), "org_id": org_id})
    return Deal.from_mongo(fresh).model_dump()


# ---------------- Notes & Tasks ----------------

class NoteCreate(BaseModel):
    entity_type: Literal["contact", "deal", "company", "conversation"] = "contact"
    entity_id: str
    body: str


@router.post("/notes")
async def create_note(req: NoteCreate, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    db = get_db()
    note = Note(org_id=org_id, author_user_id=user.id, **req.model_dump())
    res = await db.notes.insert_one(note.to_mongo())
    note.id = str(res.inserted_id)
    contact_id = req.entity_id if req.entity_type == "contact" else None
    deal_id = req.entity_id if req.entity_type == "deal" else None
    await _record_interaction(db, org_id, contact_id=contact_id, deal_id=deal_id,
                               type_="note_added",
                               summary=(req.body[:120] + "…") if len(req.body) > 120 else req.body,
                               ref_type="note", ref_id=note.id, author_user_id=user.id)
    if req.entity_type == "contact":
        await db.contacts.update_one({"_id": ObjectId(req.entity_id), "org_id": org_id},
                                       {"$inc": {"notes_count": 1}})
    return note.model_dump()


@router.get("/notes")
async def list_notes(entity_type: str, entity_id: str,
                      user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.notes.find({"org_id": org_id, "entity_type": entity_type,
                             "entity_id": entity_id}).sort("created_at", -1)
    return {"notes": [Note.from_mongo(d).model_dump() async for d in cursor]}


class TaskCreate(BaseModel):
    title: str
    body: Optional[str] = None
    entity_type: Optional[Literal["contact", "deal", "company"]] = None
    entity_id: Optional[str] = None
    due_at: Optional[str] = None
    assignee_user_id: Optional[str] = None


@router.post("/tasks")
async def create_task(req: TaskCreate, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    db = get_db()
    task = Task(org_id=org_id, **req.model_dump())
    res = await db.tasks.insert_one(task.to_mongo())
    task.id = str(res.inserted_id)
    return task.model_dump()


@router.get("/tasks")
async def list_tasks(done: Optional[bool] = None, entity_type: Optional[str] = None,
                      entity_id: Optional[str] = None,
                      user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if done is not None:
        q["done"] = done
    if entity_type:
        q["entity_type"] = entity_type
    if entity_id:
        q["entity_id"] = entity_id
    cursor = db.tasks.find(q).sort("due_at", 1)
    return {"tasks": [Task.from_mongo(d).model_dump() async for d in cursor]}


@router.post("/tasks/{task_id}/complete")
async def complete_task(task_id: str, user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    res = await db.tasks.update_one({"_id": ObjectId(task_id), "org_id": org_id},
                                     {"$set": {"done": True, "done_at": utc_now_iso(),
                                                 "updated_at": utc_now_iso()}})
    if res.matched_count == 0:
        raise HTTPException(404, "Task not found")
    return {"ok": True}


# ---------------- CSV Import ----------------

_STANDARD_TARGETS = {
    "first_name", "last_name", "display_name", "email", "phone", "company",
    "title", "address", "tag", "language", "skip",
}


@router.post("/import/analyze")
async def import_analyze(file: UploadFile = File(...),
                           user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Upload a CSV, parse the header + rows, propose a default mapping, and
    flag potential duplicates on email/phone against existing contacts."""
    db = get_db()
    _raw = await file.read()
    if len(_raw) > 8 * 1024 * 1024:
        raise HTTPException(413, "CSV file too large (max 8 MB).")
    content = _raw.decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        raise HTTPException(400, "CSV has no header row")
    rows = list(reader)[:2000]  # cap
    # Propose a default mapping
    proposed: List[ImportMapping] = []
    for col in reader.fieldnames:
        low = col.strip().lower()
        target = "skip"
        if low in ("email", "e-mail"): target = "email"
        elif low in ("phone", "phone_number", "mobile"): target = "phone"
        elif low in ("first name", "firstname", "given name", "first_name"): target = "first_name"
        elif low in ("last name", "lastname", "surname", "last_name"): target = "last_name"
        elif low in ("name", "full name", "display name"): target = "display_name"
        elif low in ("company", "company name"): target = "company"
        elif low in ("title", "job title"): target = "title"
        elif low in ("address",): target = "address"
        elif low in ("tag", "tags"): target = "tag"
        elif low in ("language", "lang"): target = "language"
        proposed.append(ImportMapping(column=col, target=target))

    # Pre-check duplicates using proposed mapping
    email_col = next((m.column for m in proposed if m.target == "email"), None)
    phone_col = next((m.column for m in proposed if m.target == "phone"), None)
    duplicates: List[Dict[str, Any]] = []
    if email_col or phone_col:
        for i, row in enumerate(rows):
            email = _norm_email(row.get(email_col) if email_col else None)
            phone = (row.get(phone_col) or "").strip() if phone_col else None
            match = None
            if email:
                match = await db.contacts.find_one({"org_id": org_id, "emails": email},
                                                    {"_id": 1, "display_name": 1, "emails": 1})
            if not match and phone:
                match = await db.contacts.find_one({"org_id": org_id, "phones": phone},
                                                    {"_id": 1, "display_name": 1, "phones": 1})
            if match:
                duplicates.append({"row_index": i,
                                   "match_id": str(match["_id"]),
                                   "match_name": match.get("display_name"),
                                   "row": row})

    run = ContactImportRun(
        org_id=org_id, author_user_id=user.id, filename=file.filename or "upload.csv",
        total_rows=len(rows), mapping=proposed, rows_json=rows,
        duplicates=duplicates, status="mapping",
    )
    res = await db.contact_import_runs.insert_one(run.to_mongo())
    run.id = str(res.inserted_id)
    return {
        "run_id": run.id,
        "columns": reader.fieldnames,
        "proposed_mapping": [m.model_dump() for m in proposed],
        "duplicates": duplicates,
        "row_sample": rows[:5],
        "total_rows": len(rows),
    }


class ImportExecuteReq(BaseModel):
    mapping: List[ImportMapping]
    on_duplicate: Literal["update", "skip", "create_new"] = "update"


@router.post("/import/{run_id}/execute")
async def import_execute(run_id: str, req: ImportExecuteReq,
                           user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.contact_import_runs.find_one({"_id": ObjectId(run_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Import run not found")
    run = ContactImportRun.from_mongo(doc)
    # Pre-flight cap check: estimate net-new contacts from the mapping+dedupe rules and
    # validate the entire batch fits BEFORE we start writing. This prevents partial imports.
    email_col_idx = phone_col_idx = None
    for m in req.mapping:
        if m.target == "email" and email_col_idx is None:
            email_col_idx = m.column
        if m.target == "phone" and phone_col_idx is None:
            phone_col_idx = m.column
    net_new = 0
    for row in run.rows_json:
        email = _norm_email((row.get(email_col_idx) or "").strip()) if email_col_idx else ""
        phone = ((row.get(phone_col_idx) or "").strip()) if phone_col_idx else ""
        if not email and not phone:
            continue
        existing = None
        if email:
            existing = await db.contacts.find_one({"org_id": org_id, "emails": email},
                                                       projection={"_id": 1})
        if not existing and phone:
            existing = await db.contacts.find_one({"org_id": org_id, "phones": phone},
                                                       projection={"_id": 1})
        if existing and req.on_duplicate != "create_new":
            continue
        net_new += 1
    if net_new > 0:
        await enforce_entitlement(org_id, "contacts", increment=net_new)
    run.mapping = req.mapping
    run.status = "executing"
    await db.contact_import_runs.update_one({"_id": doc["_id"]},
                                              {"$set": {"mapping": [m.model_dump() for m in req.mapping],
                                                          "status": "executing",
                                                          "updated_at": utc_now_iso()}})
    created: List[str] = []
    updated: List[str] = []
    errors: List[Dict[str, Any]] = []
    rollback_backup: List[Dict[str, Any]] = []
    for i, row in enumerate(run.rows_json):
        try:
            values: Dict[str, Any] = {}
            tags: List[str] = []
            custom: Dict[str, Any] = {}
            for m in req.mapping:
                v = (row.get(m.column) or "").strip()
                if not v or m.target == "skip":
                    continue
                if m.target == "email":
                    values.setdefault("emails", []).append(_norm_email(v))
                elif m.target == "phone":
                    values.setdefault("phones", []).append(v)
                elif m.target == "tag":
                    tags.append(v)
                elif m.target.startswith("custom:") and m.custom_key:
                    custom[m.custom_key] = v
                elif m.target in {"first_name", "last_name", "display_name", "title",
                                    "address", "language"}:
                    values[m.target] = v
            if not values.get("emails") and not values.get("phones"):
                errors.append({"row_index": i, "error": "missing email and phone"})
                continue
            email = (values.get("emails") or [None])[0]
            phone = (values.get("phones") or [None])[0]
            existing = None
            if email:
                existing = await db.contacts.find_one({"org_id": org_id, "emails": email})
            if not existing and phone:
                existing = await db.contacts.find_one({"org_id": org_id, "phones": phone})
            if existing and req.on_duplicate == "skip":
                continue
            if existing and req.on_duplicate == "update":
                rollback_backup.append({"contact_id": str(existing["_id"]),
                                        "before": {k: existing.get(k) for k in
                                                    ("first_name", "last_name", "display_name",
                                                     "emails", "phones", "title", "address",
                                                     "tags", "custom_fields", "language")}})
                add_to_set: Dict[str, Any] = {}
                if values.get("emails"):
                    add_to_set["emails"] = {"$each": values["emails"]}
                if values.get("phones"):
                    add_to_set["phones"] = {"$each": values["phones"]}
                if tags:
                    add_to_set["tags"] = {"$each": tags}
                setu: Dict[str, Any] = {"updated_at": utc_now_iso()}
                for k in ("first_name", "last_name", "display_name", "title", "address", "language"):
                    if k in values and not existing.get(k):
                        setu[k] = values[k]
                if custom:
                    setu["custom_fields"] = {**(existing.get("custom_fields") or {}), **custom}
                update: Dict[str, Any] = {"$set": setu}
                if add_to_set:
                    update["$addToSet"] = add_to_set
                await db.contacts.update_one({"_id": existing["_id"]}, update)
                updated.append(str(existing["_id"]))
            else:
                contact = Contact(
                    org_id=org_id, source="import",
                    display_name=values.get("display_name") or f"{values.get('first_name','')} {values.get('last_name','')}".strip() or email or phone,
                    first_name=values.get("first_name"), last_name=values.get("last_name"),
                    emails=values.get("emails") or [], phones=values.get("phones") or [],
                    title=values.get("title"), address=values.get("address"),
                    language=values.get("language"), tags=tags, custom_fields=custom,
                    owner_user_id=user.id,
                )
                res = await db.contacts.insert_one(contact.to_mongo())
                created.append(str(res.inserted_id))
        except Exception as e:  # noqa: BLE001
            errors.append({"row_index": i, "error": str(e)})
    await db.contact_import_runs.update_one(
        {"_id": ObjectId(run_id)},
        {"$set": {"status": "completed",
                    "created_contact_ids": created,
                    "updated_contact_ids": updated,
                    "error_rows": errors,
                    "rollback_backup": rollback_backup,
                    "updated_at": utc_now_iso()}},
    )
    return {"ok": True, "created": len(created), "updated": len(updated),
            "errors": len(errors)}


@router.post("/import/{run_id}/rollback")
async def import_rollback(run_id: str, user: User = Depends(current_user),
                            org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.contact_import_runs.find_one({"_id": ObjectId(run_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Import run not found")
    # Delete all contacts created by this import
    created_ids = [ObjectId(x) for x in (doc.get("created_contact_ids") or [])]
    if created_ids:
        await db.contacts.delete_many({"_id": {"$in": created_ids}, "org_id": org_id})
    # Restore backups for updated contacts
    for b in (doc.get("rollback_backup") or []):
        cid = b.get("contact_id")
        before = b.get("before") or {}
        if not cid:
            continue
        await db.contacts.update_one({"_id": ObjectId(cid), "org_id": org_id},
                                        {"$set": {**before, "updated_at": utc_now_iso()}})
    await db.contact_import_runs.update_one(
        {"_id": doc["_id"]},
        {"$set": {"status": "rolled_back", "updated_at": utc_now_iso()}},
    )
    return {"ok": True, "reverted_created": len(created_ids),
            "reverted_updated": len(doc.get("rollback_backup") or [])}


@router.get("/import/runs")
async def list_imports(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.contact_import_runs.find({"org_id": org_id}, {"rows_json": 0, "rollback_backup": 0}) \
                                       .sort("created_at", -1).limit(50)
    out = []
    async for d in cursor:
        d["_id"] = str(d["_id"])
        out.append(d)
    return {"runs": out}


@router.get("/import/{run_id}")
async def get_import(run_id: str, user: User = Depends(current_user),
                      org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.contact_import_runs.find_one({"_id": ObjectId(run_id), "org_id": org_id},
                                                  {"rows_json": {"$slice": 5}})
    if not doc:
        raise HTTPException(404, "Import run not found")
    doc["_id"] = str(doc["_id"])
    return doc
