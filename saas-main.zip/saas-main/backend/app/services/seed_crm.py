"""Seed the demo org with realistic CRM + Inbox data so the UI demos well.

Idempotent — runs on every startup, only inserts what's missing.

Data:
- ~15 contacts across industries
- 1 default pipeline with default stages
- ~8 deals spread across stages, each linked to a contact
- Several form/email/chat conversations with messages
- A few suppressed addresses
- 1 EmailProviderConfig (simulated)
- 3 lead scores computed on a sample of contacts
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from .lead_scoring import score_contact
from ..db import get_db, utc_now_iso
from ..models_crm import (
    ConsentRecord, Contact, Conversation, Deal, EmailProviderConfig,
    Interaction, Message, MessageAddress, Note, Suppression,
)

logger = logging.getLogger(__name__)


DEMO_ORG_SLUG = "demo-home-services"


_CONTACT_ROWS: List[Dict[str, Any]] = [
    {"first_name": "Sara",   "last_name": "Klein",       "emails": ["sara.klein@example.com"],
     "phones": ["+15125550101"], "source": "form",      "tags": ["hot", "residential"],
     "notes": "Burst pipe under kitchen sink — asked about weekend availability."},
    {"first_name": "Miguel", "last_name": "Ruiz",        "emails": ["miguel@ruizfamily.example"],
     "phones": ["+15125550102"], "source": "form",      "tags": ["residential"],
     "notes": "Wants a quote for water heater replacement."},
    {"first_name": "Priya",  "last_name": "Menon",       "emails": ["p.menon@example.com"],
     "phones": ["+15125550103"], "source": "form",      "tags": ["residential", "priority"],
     "notes": "Recurring drain unblock — 3rd time this year."},
    {"first_name": "Aaron",  "last_name": "Cohen",       "emails": ["aaron.cohen@example.com"],
     "phones": [],                "source": "import",   "tags": ["cold"]},
    {"first_name": "Nora",   "last_name": "Ivanova",     "emails": ["nora.i@example.com"],
     "phones": ["+15125550105"], "source": "referral",  "tags": ["hot", "commercial"]},
    {"first_name": "Deven",  "last_name": "Patel",       "emails": ["deven.patel@example.com"],
     "phones": ["+15125550106"], "source": "manual",    "tags": ["residential"]},
    {"first_name": "Ashley", "last_name": "Wong",        "emails": ["ashley.wong@example.com"],
     "phones": ["+15125550107"], "source": "form",      "tags": ["priority"]},
    {"first_name": "Tomás",  "last_name": "Fernández",   "emails": ["tomas.f@example.com"],
     "phones": [],                "source": "import",   "tags": []},
    {"first_name": "Hana",   "last_name": "Kobayashi",   "emails": ["hana.k@example.com"],
     "phones": ["+15125550109"], "source": "referral",  "tags": ["commercial"]},
    {"first_name": "Malik",  "last_name": "Johnson",     "emails": ["malik.j@example.com"],
     "phones": ["+15125550110"], "source": "manual",    "tags": ["residential"]},
    {"first_name": "Beatrix","last_name": "Nowak",       "emails": ["beatrix.n@example.com"],
     "phones": [],                "source": "import",   "tags": []},
    {"first_name": "Rafael", "last_name": "Alvarez",     "emails": ["rafael.a@example.com"],
     "phones": ["+15125550112"], "source": "form",      "tags": ["residential"]},
    {"first_name": "Chika",  "last_name": "Nwosu",       "emails": ["chika.n@example.com"],
     "phones": ["+15125550113"], "source": "referral",  "tags": ["priority"]},
    {"first_name": "Jonas",  "last_name": "Lindqvist",   "emails": ["jonas.l@example.com"],
     "phones": [],                "source": "manual",   "tags": []},
    {"first_name": "Anaya",  "last_name": "Sharma",      "emails": ["anaya.s@example.com"],
     "phones": ["+15125550115"], "source": "form",      "tags": ["hot"]},
]

_SUPPRESSED_EMAILS = [
    ("bounced@example.com", "bounce"),
    ("optout@example.com", "unsubscribe"),
    ("angry-customer@example.com", "complaint"),
]


async def seed_crm_demo() -> None:
    db = get_db()
    org = await db.organizations.find_one({"slug": DEMO_ORG_SLUG})
    if not org:
        return
    org_id = str(org["_id"])
    owner = await db.users.find_one({"org_id": org_id, "role": "owner"})
    owner_user_id = str(owner["_id"]) if owner else None

    # Ensure indexes
    try:
        await db.contacts.create_index([("org_id", 1), ("emails", 1)])
        await db.contacts.create_index([("org_id", 1), ("phones", 1)])
        await db.conversations.create_index([("org_id", 1), ("last_message_at", -1)])
        await db.messages.create_index([("org_id", 1), ("conversation_id", 1), ("created_at", 1)])
        await db.interactions.create_index([("org_id", 1), ("contact_id", 1), ("created_at", -1)])
        await db.suppressions.create_index([("org_id", 1), ("email", 1)], unique=True)
    except Exception as e:  # noqa: BLE001
        logger.warning("CRM index creation warning: %s", e)

    # Idempotent guard: if we already have >= 10 contacts, assume seeded.
    existing_count = await db.contacts.count_documents({"org_id": org_id})
    if existing_count >= 10:
        logger.info("CRM demo already seeded (%d contacts)", existing_count)
        await _ensure_email_config(db, org_id, owner)
        return

    # Ensure email provider config (simulated)
    await _ensure_email_config(db, org_id, owner)

    # Ensure default pipeline
    from .. import routes  # noqa: F401 — ensure package loads
    from ..routes.crm import _ensure_default_pipeline
    pipeline = await _ensure_default_pipeline(db, org_id)

    # Insert contacts
    contact_ids: List[str] = []
    for row in _CONTACT_ROWS:
        contact = Contact(
            org_id=org_id,
            first_name=row["first_name"], last_name=row["last_name"],
            display_name=f"{row['first_name']} {row['last_name']}",
            emails=row["emails"], phones=row["phones"],
            source=row["source"], tags=row["tags"],
            owner_user_id=owner_user_id,
            consents=[ConsentRecord(channel="email", status="granted",
                                     ts=utc_now_iso(), source=row["source"])] if row["emails"] else [],
            last_activity_at=utc_now_iso(),
        )
        res = await db.contacts.insert_one(contact.to_mongo())
        cid = str(res.inserted_id)
        contact_ids.append(cid)
        # timeline: contact_created
        await db.interactions.insert_one(Interaction(
            org_id=org_id, contact_id=cid, type="contact_created",
            summary=f"Contact created (source: {row['source']})",
        ).to_mongo())
        # note if provided
        if row.get("notes"):
            note = Note(org_id=org_id, author_user_id=owner_user_id or "system",
                          entity_type="contact", entity_id=cid, body=row["notes"])
            nr = await db.notes.insert_one(note.to_mongo())
            await db.interactions.insert_one(Interaction(
                org_id=org_id, contact_id=cid, type="note_added",
                summary=row["notes"][:120],
                ref_type="note", ref_id=str(nr.inserted_id),
                author_user_id=owner_user_id,
            ).to_mongo())
            await db.contacts.update_one({"_id": res.inserted_id}, {"$inc": {"notes_count": 1}})

    # Deals across stages (spread first 8 contacts through stages 0..3)
    stages = pipeline.stages
    for i, cid in enumerate(contact_ids[:8]):
        stage = stages[i % 4]  # cycle through open/won stages
        deal = Deal(
            org_id=org_id, pipeline_id=pipeline.id, stage_id=stage.id,
            name=f"{_CONTACT_ROWS[i]['first_name']} — plumbing job",
            value=180.0 + (i * 240.0), currency="USD",
            contact_id=cid, owner_user_id=owner_user_id,
            stage_updated_at=utc_now_iso(),
        )
        dr = await db.deals.insert_one(deal.to_mongo())
        await db.interactions.insert_one(Interaction(
            org_id=org_id, contact_id=cid, deal_id=str(dr.inserted_id),
            type="deal_created", summary=f"Deal created: {deal.name}",
            author_user_id=owner_user_id,
        ).to_mongo())

    # Conversations & messages: one form conv, one email conv (inbound), one chat conv
    await _seed_conversation(db, org_id, contact_ids[0], channel="form",
                                subject="Form: contact — Sara Klein",
                                inbound_text="Hi — my kitchen sink pipe is dripping under the cabinet. "
                                               "Can someone come by this weekend? Willing to pay the emergency fee.",
                                inbound_from={"email": "sara.klein@example.com", "name": "Sara Klein"})
    await _seed_conversation(db, org_id, contact_ids[1], channel="email",
                                subject="Water heater replacement quote?",
                                inbound_text="Hi team, our 12-year-old gas water heater is leaking. "
                                               "Could you send me a rough quote for a like-for-like replacement, "
                                               "install and haul-away included? Thanks — Miguel",
                                inbound_from={"email": "miguel@ruizfamily.example", "name": "Miguel Ruiz"})
    await _seed_conversation(db, org_id, contact_ids[2], channel="chat",
                                subject="Chat: repeat drain problem",
                                inbound_text="This is the 3rd time the same drain has blocked in 4 months. "
                                               "Do we need a camera inspection?",
                                inbound_from={"email": "p.menon@example.com", "name": "Priya Menon"})

    # Suppressions
    for email, reason in _SUPPRESSED_EMAILS:
        await db.suppressions.update_one(
            {"org_id": org_id, "email": email},
            {"$set": Suppression(org_id=org_id, email=email, reason=reason).to_mongo()},
            upsert=True,
        )

    # Score first 3 contacts so the UI has non-empty lead-score chips
    profile_doc = await db.business_profiles.find_one({"org_id": org_id})
    business_dict = profile_doc  # already a dict from mongo
    if business_dict and business_dict.get("business_name"):
        for cid in contact_ids[:3]:
            cdoc = await db.contacts.find_one({"_id": {"$eq": _oid(cid)}})
            if not cdoc:
                continue
            try:
                result = await score_contact({**cdoc, "id": cid}, business_dict)
                await db.contacts.update_one(
                    {"_id": cdoc["_id"]},
                    {"$set": {"lead_score": result["score"],
                                "lead_score_factors": result["factors"],
                                "lead_score_breakdown": result["breakdown"],
                                "lead_score_updated_at": utc_now_iso()}},
                )
            except Exception as e:  # noqa: BLE001
                logger.warning("Skipping lead score for %s: %s", cid, e)

    logger.info("CRM demo seed complete — %d contacts inserted", len(contact_ids))


async def _seed_conversation(db, org_id: str, contact_id: str, *, channel: str,
                                subject: str, inbound_text: str,
                                inbound_from: Dict[str, str]) -> None:
    conv = Conversation(
        org_id=org_id, channel=channel, contact_id=contact_id,
        subject=subject, status="open", unread=True,
        last_message_at=utc_now_iso(), last_message_preview=inbound_text[:160],
    )
    cr = await db.conversations.insert_one(conv.to_mongo())
    conv_id = str(cr.inserted_id)
    msg = Message(
        org_id=org_id, conversation_id=conv_id, direction="inbound",
        channel="email" if channel == "email" else channel,  # noqa
        from_addr=MessageAddress(**inbound_from), subject=subject,
        body_text=inbound_text, sent_at=utc_now_iso(),
        delivery={"provider": "simulated_inbound", "simulated": True, "status": "received"},
    )
    await db.messages.insert_one(msg.to_mongo())
    await db.interactions.insert_one(Interaction(
        org_id=org_id, contact_id=contact_id, type=f"{channel}_received",
        summary=f"Received: {subject}",
        ref_type="message", ref_id=str((await db.messages.find_one({"conversation_id": conv_id}))["_id"]),
        meta={"conversation_id": conv_id, "simulated": True},
    ).to_mongo())


async def _ensure_email_config(db, org_id: str, owner) -> None:
    if await db.email_provider_configs.find_one({"org_id": org_id}):
        return
    cfg = EmailProviderConfig(
        org_id=org_id, provider="simulated",
        from_email=(owner or {}).get("email") or f"team@{DEMO_ORG_SLUG}.local",
        from_name="Demo Home Services",
    )
    await db.email_provider_configs.insert_one(cfg.to_mongo())


def _oid(v: str):
    from bson import ObjectId
    return ObjectId(v)


async def backfill_existing_form_submissions() -> None:
    """One-shot: for orgs with existing form_submissions but no CRM contact,
    upsert the contact + conversation retroactively so the demo isn't empty."""
    db = get_db()
    async for sub in db.form_submissions.find({}):
        # If we've already produced an interaction for this submission, skip.
        already = await db.interactions.find_one({"org_id": sub["org_id"],
                                                     "ref_type": "form_submission",
                                                     "ref_id": str(sub["_id"])})
        if already:
            continue
        try:
            from ..routes.crm import upsert_contact_from_form
            fields = sub.get("fields") or {}
            await upsert_contact_from_form(
                db, sub["org_id"], fields, source="form",
                submission_id=str(sub["_id"]), website_id=sub.get("website_id"),
            )
        except Exception as e:  # noqa: BLE001
            logger.warning("backfill: skipped submission %s: %s", sub.get("_id"), e)
