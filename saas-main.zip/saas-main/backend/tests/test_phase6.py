"""Phase 6 backend tests — Billing/entitlements, Founder cockpit, Setup Center,
Support, MFA, Rate limits, Public v1 API + cross-tenant isolation.
Also verifies Phase 5 remediation: past-date guard, empty-body takeover, portal token.
"""
from __future__ import annotations

import os
import time
import uuid
from datetime import date, datetime, timedelta, timezone

import pytest
import requests
from tests import _creds as _CREDS  # creds from env / test_credentials.md

BASE_URL = _CREDS.BASE_URL
FOUNDER_EMAIL = _CREDS.FOUNDER_EMAIL
FOUNDER_PW = _CREDS.FOUNDER_PASSWORD
OWNER_EMAIL = _CREDS.OWNER_EMAIL                    # autopilot
OWNER_PW = _CREDS.OWNER_PASSWORD
LAUNCH_EMAIL = "owner@launch-demo.zanelvo.com"            # launch plan (different org)
LAUNCH_PW = _CREDS.password_for("owner@launch-demo.zanelvo.com")
SITE_SLUG = "demo-home-services"
LLM_TIMEOUT = 90


def _login(email, pw):
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": email, "password": pw}, timeout=30)
    assert r.status_code == 200, f"login failed: {r.status_code} {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def owner_token():
    return _login(OWNER_EMAIL, OWNER_PW)


@pytest.fixture(scope="module")
def owner_headers(owner_token):
    return {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def founder_token():
    return _login(FOUNDER_EMAIL, FOUNDER_PW)


@pytest.fixture(scope="module")
def founder_headers(founder_token):
    return {"Authorization": f"Bearer {founder_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def launch_owner_headers():
    try:
        tok = _login(LAUNCH_EMAIL, LAUNCH_PW)
    except AssertionError:
        pytest.skip("secondary demo owner not seeded")
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}


# ==========================================================================
# Phase 5 remediation checks
# ==========================================================================

class TestPhase5Fixes:
    def test_public_availability_no_past_slots(self):
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        r = requests.get(f"{BASE_URL}/api/public/booking/availability",
                         params={"website_slug": SITE_SLUG, "date_from": yesterday,
                                 "date_to": yesterday}, timeout=30)
        # Endpoint may return 200 with 0 slots or 422; accept both but if 200
        # ensure zero slots
        assert r.status_code in (200, 422), r.text
        if r.status_code == 200:
            body = r.json()
            slots = body.get("slots") or body.get("availability") or []
            assert not slots, f"Past date should yield no slots, got: {slots}"

    def test_public_booking_book_past_returns_422(self):
        past = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat().replace("+00:00", "Z")
        payload = {
            "website_slug": SITE_SLUG,
            "service_slug": "drain-unblock",
            "start_at": past,
            "customer_name": "TEST Past",
            "customer_email": "past@example.com",
            "customer_phone": "555-0000",
        }
        r = requests.post(f"{BASE_URL}/api/public/booking/book", json=payload, timeout=30)
        assert r.status_code == 422, f"expected 422, got {r.status_code} {r.text}"
        detail = r.json().get("detail") or {}
        if isinstance(detail, dict):
            assert detail.get("error") == "past_start_at", detail

    def test_takeover_accepts_empty_body(self, owner_headers):
        # Create a widget session
        s = requests.post(f"{BASE_URL}/api/public/chat/start",
                          json={"website_slug": SITE_SLUG}, timeout=30).json()
        if s.get("disabled"):
            # kill switch active — turn AI on and retry
            requests.put(f"{BASE_URL}/api/ai/kill-switch",
                         json={"ai_enabled": True, "reason": "phase6-test"},
                         headers=owner_headers, timeout=30)
            s = requests.post(f"{BASE_URL}/api/public/chat/start",
                              json={"website_slug": SITE_SLUG}, timeout=30).json()
        cid = s["conversation_id"]
        # Empty body
        r = requests.post(f"{BASE_URL}/api/ai/conversations/{cid}/takeover",
                          headers={"Authorization": owner_headers["Authorization"]},
                          timeout=30)
        assert r.status_code == 200, f"empty body should be 200, got {r.status_code} {r.text}"
        # With body
        r2 = requests.post(f"{BASE_URL}/api/ai/conversations/{cid}/takeover",
                           headers=owner_headers, json={"reply": "hi from human"},
                           timeout=30)
        assert r2.status_code == 200, r2.text


# ==========================================================================
# Billing
# ==========================================================================

class TestBilling:
    def test_plans_returns_5_with_entitlements(self):
        r = requests.get(f"{BASE_URL}/api/billing/plans", timeout=30)
        assert r.status_code == 200, r.text
        plans = r.json()["plans"]
        assert len(plans) == 5, f"expected 5 plans, got {len(plans)}: {[p['code'] for p in plans]}"
        for p in plans:
            assert "entitlements" in p and isinstance(p["entitlements"], dict)

    def test_subscription_autopilot(self, owner_headers):
        r = requests.get(f"{BASE_URL}/api/billing/subscription", headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("plan_code") == "autopilot", f"got {d.get('plan_code')}"
        assert d.get("subscription") and d.get("entitlements")

    def test_usage_returns_6_meters(self, owner_headers):
        r = requests.get(f"{BASE_URL}/api/billing/usage", headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        expected = {"ai_conversations", "email_sends", "voice_minutes",
                    "contacts", "users", "websites"}
        meters = d.get("meters") or d
        # meters can be a dict at top-level or nested
        keys = set()
        if isinstance(meters, dict) and "ai_conversations" in meters:
            keys = set(meters.keys()) & expected
            sample = meters["ai_conversations"]
        else:
            # try list
            for m in (meters if isinstance(meters, list) else []):
                keys.add(m.get("key") or m.get("meter"))
            sample = None
        missing = expected - keys
        assert not missing, f"missing meters: {missing}. Payload keys: {list(meters.keys()) if isinstance(meters, dict) else meters}"
        # sample shape
        if sample:
            for f in ("used", "cap"):
                assert f in sample, f"missing field {f} in {sample}"

    def test_checkout_lifecycle_with_launch20_coupon(self, owner_headers):
        # Start checkout for revenue with LAUNCH20
        r = requests.post(f"{BASE_URL}/api/billing/checkout",
                          headers=owner_headers,
                          json={"plan_code": "revenue", "coupon_code": "LAUNCH20"},
                          timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("id") and d.get("checkout_url")
        assert d.get("coupon_valid") is True, f"coupon should be valid: {d}"
        # Verify discount ≈ 20% off
        plans = requests.get(f"{BASE_URL}/api/billing/plans", timeout=30).json()["plans"]
        revenue = next(p for p in plans if p["code"] == "revenue")
        expected_amount = int(revenue["price_usd"] * 100 * 0.8)
        assert abs(d["amount_cents"] - expected_amount) <= 1, \
            f"amount_cents {d['amount_cents']} != expected {expected_amount}"
        sid = d["id"]

        # Complete
        c = requests.post(f"{BASE_URL}/api/billing/checkout/{sid}/complete",
                          headers=owner_headers, timeout=30)
        assert c.status_code == 200, c.text
        cd = c.json()
        assert cd.get("ok") is True
        assert cd.get("plan_code") == "revenue"
        assert cd.get("invoice_number")

        # Sub should now be revenue + active
        sub = requests.get(f"{BASE_URL}/api/billing/subscription",
                           headers=owner_headers, timeout=30).json()
        assert sub["plan_code"] == "revenue"
        assert sub["subscription"]["status"] == "active"

        # Invoice exists
        inv = requests.get(f"{BASE_URL}/api/billing/invoices",
                           headers=owner_headers, timeout=30).json()
        assert any(i.get("number") == cd["invoice_number"] for i in inv["invoices"])

        # Cleanup: restore back to autopilot
        r2 = requests.post(f"{BASE_URL}/api/billing/checkout",
                           headers=owner_headers,
                           json={"plan_code": "autopilot"}, timeout=30)
        if r2.status_code == 200:
            sid2 = r2.json()["id"]
            requests.post(f"{BASE_URL}/api/billing/checkout/{sid2}/complete",
                          headers=owner_headers, timeout=30)

    def test_cancel_resume_and_dunning(self, owner_headers):
        c = requests.post(f"{BASE_URL}/api/billing/subscription/cancel",
                          headers=owner_headers, json={"reason": "testing"}, timeout=30)
        assert c.status_code == 200, c.text
        r = requests.post(f"{BASE_URL}/api/billing/subscription/resume",
                          headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = requests.post(f"{BASE_URL}/api/billing/subscription/simulate-payment-failure",
                          headers=owner_headers, timeout=30)
        assert d.status_code == 200, d.text
        # restore active
        sub = requests.get(f"{BASE_URL}/api/billing/subscription",
                           headers=owner_headers, timeout=30).json()
        if sub["subscription"].get("status") == "past_due":
            # Trigger completion of a no-op checkout to restore
            r2 = requests.post(f"{BASE_URL}/api/billing/checkout",
                               headers=owner_headers,
                               json={"plan_code": sub["plan_code"]}, timeout=30).json()
            requests.post(f"{BASE_URL}/api/billing/checkout/{r2['id']}/complete",
                          headers=owner_headers, timeout=30)


# ==========================================================================
# Founder
# ==========================================================================

class TestFounder:
    def test_cockpit_shape_and_owner_forbidden(self, founder_headers, owner_headers):
        r = requests.get(f"{BASE_URL}/api/founder/cockpit", headers=founder_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        for k in ("orgs_over_limit", "failing_webhooks", "dead_webhooks",
                  "pending_approvals", "past_due_subscriptions",
                  "llm_errors_24h", "active_impersonations"):
            assert k in d, f"missing key {k}"
        # Owner should be forbidden
        ro = requests.get(f"{BASE_URL}/api/founder/cockpit", headers=owner_headers, timeout=30)
        assert ro.status_code == 403, f"owner should be forbidden, got {ro.status_code}"

    def test_tenants_list_and_detail(self, founder_headers):
        r = requests.get(f"{BASE_URL}/api/founder/tenants", headers=founder_headers, timeout=30)
        assert r.status_code == 200, r.text
        tenants = r.json()["tenants"]
        assert tenants, "expected at least one tenant"
        t0 = tenants[0]
        for k in ("plan", "activation", "usage", "mrr_usd", "health_score", "health_factors"):
            assert k in t0, f"missing {k} in tenant: {t0}"
        # Detail
        rd = requests.get(f"{BASE_URL}/api/founder/tenants/{t0['id']}",
                          headers=founder_headers, timeout=30)
        assert rd.status_code == 200, rd.text
        d = rd.json()
        for k in ("org", "subscription", "users", "website", "business_profile", "usage"):
            assert k in d, f"missing {k}"

    def test_metrics_shape(self, founder_headers):
        r = requests.get(f"{BASE_URL}/api/founder/metrics", headers=founder_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        for k in ("mrr_usd", "arr_usd", "per_plan", "funnel",
                  "churned_last_30d", "per_org"):
            assert k in d, f"missing {k}"
        for f in ("signups", "interview_done", "website_created", "published", "active_last_7d"):
            assert f in d["funnel"], f"missing funnel key {f}"

    def test_impersonation_flow(self, founder_headers):
        tenants = requests.get(f"{BASE_URL}/api/founder/tenants",
                               headers=founder_headers, timeout=30).json()["tenants"]
        target = tenants[0]["id"]
        # short reason rejected
        bad = requests.post(f"{BASE_URL}/api/founder/impersonate/start",
                            headers=founder_headers,
                            json={"target_org_id": target, "reason": "x"}, timeout=30)
        assert bad.status_code in (400, 422), f"expected 422/400, got {bad.status_code}"
        # good reason
        good = requests.post(f"{BASE_URL}/api/founder/impersonate/start",
                             headers=founder_headers,
                             json={"target_org_id": target,
                                   "reason": "phase6 acceptance test"}, timeout=30)
        assert good.status_code == 200, good.text
        sid = good.json().get("session_id")
        assert sid
        cur = requests.get(f"{BASE_URL}/api/founder/impersonate/current",
                           headers=founder_headers, timeout=30).json()
        assert cur.get("active") is True
        end = requests.post(f"{BASE_URL}/api/founder/impersonate/end",
                            headers=founder_headers, timeout=30)
        assert end.status_code == 200
        # Audit contains events
        aud = requests.get(f"{BASE_URL}/api/founder/audit",
                           headers=founder_headers,
                           params={"action": "impersonation"}, timeout=30).json()
        actions = [e["action"] for e in aud.get("events", [])]
        assert any(a.startswith("impersonation.start") for a in actions)
        assert any(a.startswith("impersonation.end") for a in actions)

    def test_global_kill_disables_public_chat(self, founder_headers):
        # Turn on the global kill
        r = requests.put(f"{BASE_URL}/api/founder/global-controls/kill",
                         headers=founder_headers,
                         json={"all_ai_disabled": True, "reason": "phase6-test"},
                         timeout=30)
        assert r.status_code == 200, r.text
        # widget disabled?
        s = requests.post(f"{BASE_URL}/api/public/chat/start",
                          json={"website_slug": SITE_SLUG}, timeout=30).json()
        assert s.get("disabled") is True, f"expected disabled=true: {s}"
        assert s.get("greeting"), "should contain an honest greeting"
        # Undo
        r2 = requests.put(f"{BASE_URL}/api/founder/global-controls/kill",
                          headers=founder_headers,
                          json={"all_ai_disabled": False, "reason": "restore"},
                          timeout=30)
        assert r2.status_code == 200
        s2 = requests.post(f"{BASE_URL}/api/public/chat/start",
                           json={"website_slug": SITE_SLUG}, timeout=30).json()
        assert not s2.get("disabled"), f"widget should be back on: {s2}"

    def test_announcement_and_public_visibility(self, founder_headers):
        r = requests.post(f"{BASE_URL}/api/founder/global-controls/announcement",
                          headers=founder_headers,
                          json={"title": "TEST", "body": "phase6 test", "level": "info"},
                          timeout=30)
        assert r.status_code == 200, r.text
        pub = requests.get(f"{BASE_URL}/api/support/announcement", timeout=30).json()
        assert pub.get("active") is True
        assert pub.get("title") == "TEST"
        # cleanup
        requests.delete(f"{BASE_URL}/api/founder/global-controls/announcement",
                        headers=founder_headers, timeout=30)


# ==========================================================================
# Setup Center
# ==========================================================================

class TestSetup:
    def test_cards_returns_21(self, owner_headers):
        r = requests.get(f"{BASE_URL}/api/setup/cards", headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        cards = r.json()["cards"]
        assert len(cards) == 21, f"expected 21 cards, got {len(cards)}"
        for c in cards:
            for f in ("key", "label", "category", "state"):
                assert f in c, f"missing {f} in {c}"

    def test_test_endpoint(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/setup/cards/brand/test",
                          headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "ok" in d and "message" in d

    def test_launch_score(self, owner_headers):
        r = requests.get(f"{BASE_URL}/api/setup/launch-score",
                         headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "score" in d and "done" in d and "total" in d
        assert isinstance(d["checks"], list) and len(d["checks"]) == 6, \
            f"expected 6 checks, got {len(d['checks'])}"

    def test_api_key_lifecycle_and_scope_enforcement(self, owner_headers):
        # Create
        r = requests.post(f"{BASE_URL}/api/setup/api-keys",
                          headers=owner_headers,
                          json={"name": f"TEST_{uuid.uuid4().hex[:6]}",
                                "scopes": ["contacts:read"]}, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("key") and d.get("prefix")
        full_key = d["key"]
        kid = d["id"]

        # whoami
        w = requests.get(f"{BASE_URL}/api/public/v1/whoami",
                         headers={"Authorization": f"Bearer {full_key}"}, timeout=30)
        assert w.status_code == 200, w.text
        wd = w.json()
        assert wd.get("org_id") and "contacts:read" in wd.get("scopes", [])

        # list contacts — allowed scope
        lc = requests.get(f"{BASE_URL}/api/public/v1/contacts",
                          headers={"Authorization": f"Bearer {full_key}"}, timeout=30)
        assert lc.status_code == 200, lc.text

        # write scope not granted — should 403
        cw = requests.post(f"{BASE_URL}/api/public/v1/contacts",
                           headers={"Authorization": f"Bearer {full_key}",
                                    "Content-Type": "application/json"},
                           json={"display_name": "TEST"}, timeout=30)
        assert cw.status_code == 403, f"expected 403 for missing write scope, got {cw.status_code}"

        # bookings:read not granted — 403
        b = requests.get(f"{BASE_URL}/api/public/v1/bookings",
                         headers={"Authorization": f"Bearer {full_key}"}, timeout=30)
        assert b.status_code == 403, f"expected 403 for missing bookings:read, got {b.status_code}"

        # Revoke
        rv = requests.post(f"{BASE_URL}/api/setup/api-keys/{kid}/revoke",
                           headers=owner_headers, timeout=30)
        assert rv.status_code == 200
        # After revoke -> 401
        w2 = requests.get(f"{BASE_URL}/api/public/v1/whoami",
                          headers={"Authorization": f"Bearer {full_key}"}, timeout=30)
        assert w2.status_code == 401, f"expected 401 for revoked, got {w2.status_code}"

    def test_webhook_lifecycle(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/setup/webhooks",
                          headers=owner_headers,
                          json={"url": "https://example.com/hook",
                                "events": ["contact.created", "booking.created"]},
                          timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("secret") and d.get("id")
        wid = d["id"]
        # Delete
        dl = requests.delete(f"{BASE_URL}/api/setup/webhooks/{wid}",
                             headers=owner_headers, timeout=30)
        assert dl.status_code == 200

    def test_data_export_zip(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/setup/data-export",
                          headers=owner_headers, timeout=60)
        assert r.status_code == 200, r.text
        assert "application/zip" in r.headers.get("content-type", "").lower()
        assert len(r.content) > 100

    def test_delete_and_cancel(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/setup/delete-org",
                          headers=owner_headers,
                          json={"confirm": "DELETE", "reason": "testing"}, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("purge_at") and d.get("grace_days") == 30
        # Cancel it — critical, we DON'T want to actually delete this org
        c = requests.post(f"{BASE_URL}/api/setup/delete-org/cancel",
                          headers=owner_headers, timeout=30)
        assert c.status_code == 200

        # wrong confirm string
        bad = requests.post(f"{BASE_URL}/api/setup/delete-org",
                            headers=owner_headers,
                            json={"confirm": "nope"}, timeout=30)
        assert bad.status_code == 422


# ==========================================================================
# MFA
# ==========================================================================

class TestMFA:
    def test_mfa_status_and_start_shape(self, owner_headers):
        s = requests.get(f"{BASE_URL}/api/auth/mfa/status",
                         headers=owner_headers, timeout=30)
        assert s.status_code == 200, s.text
        assert "enabled" in s.json()

        # Start returns secret + qr_png
        st = requests.post(f"{BASE_URL}/api/auth/mfa/start",
                           headers=owner_headers, timeout=30)
        # If already enabled -> 400, otherwise 200
        if st.status_code == 400:
            return
        assert st.status_code == 200, st.text
        d = st.json()
        assert d.get("secret") and d.get("qr_png", "").startswith("data:image/png")

    def test_mfa_disable_requires_password(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/auth/mfa/disable",
                          headers=owner_headers,
                          json={"password": "wrongpass"}, timeout=30)
        # Since MFA might not be enabled, we accept 401 (bad pw) — but shape must reject wrong pw
        assert r.status_code == 401, f"expected 401 for wrong password, got {r.status_code}"


# ==========================================================================
# Support
# ==========================================================================

class TestSupport:
    def test_articles_and_detail(self):
        r = requests.get(f"{BASE_URL}/api/support/articles", timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert len(d["articles"]) >= 10, f"expected >=10 articles, got {len(d['articles'])}"
        assert d.get("categories")
        # detail on first article
        slug = d["articles"][0]["slug"]
        dd = requests.get(f"{BASE_URL}/api/support/articles/{slug}", timeout=30)
        assert dd.status_code == 200
        assert dd.json().get("body_markdown")

    def test_tickets_crud(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/support/tickets",
                          headers=owner_headers,
                          json={"subject": f"TEST_{uuid.uuid4().hex[:6]}",
                                "body": "test body", "category": "general",
                                "severity": "low"}, timeout=30)
        assert r.status_code == 200, r.text
        tid = r.json()["id"]
        # list
        lr = requests.get(f"{BASE_URL}/api/support/tickets",
                          headers=owner_headers, timeout=30)
        assert lr.status_code == 200
        assert any(t["id"] == tid for t in lr.json()["tickets"])

    def test_ai_support_shape(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/support/ai/ask",
                          headers=owner_headers,
                          json={"message": "How do I publish my website?"},
                          timeout=LLM_TIMEOUT)
        assert r.status_code == 200, r.text
        d = r.json()
        for f in ("intent", "reply_text", "cited_slugs", "confidence"):
            assert f in d, f"missing {f}"

    def test_status_page(self):
        r = requests.get(f"{BASE_URL}/api/support/status", timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("overall") in ("operational", "degraded", "outage")
        assert isinstance(d.get("checks"), list) and d["checks"]


# ==========================================================================
# Cross-tenant isolation
# ==========================================================================

class TestCrossTenantIsolation:
    def test_owner_a_cannot_see_owner_b_tickets(self, owner_headers, launch_owner_headers):
        # Create a ticket in demo org
        r = requests.post(f"{BASE_URL}/api/support/tickets",
                          headers=owner_headers,
                          json={"subject": f"TEST_iso_{uuid.uuid4().hex[:6]}",
                                "body": "isolation body"}, timeout=30)
        assert r.status_code == 200, r.text
        tid = r.json()["id"]
        # Access from other org
        r2 = requests.get(f"{BASE_URL}/api/support/tickets/{tid}",
                          headers=launch_owner_headers, timeout=30)
        assert r2.status_code == 404, f"expected 404 for cross-org read, got {r2.status_code}"

    def test_owner_a_cannot_see_owner_b_api_keys(self, owner_headers, launch_owner_headers):
        # Create key in demo
        r = requests.post(f"{BASE_URL}/api/setup/api-keys",
                          headers=owner_headers,
                          json={"name": f"TEST_{uuid.uuid4().hex[:6]}",
                                "scopes": ["contacts:read"]}, timeout=30)
        if r.status_code != 200:
            pytest.skip(f"api key create failed: {r.text}")
        kid = r.json()["id"]
        # Other org lists — shouldn't see this id
        l = requests.get(f"{BASE_URL}/api/setup/api-keys",
                         headers=launch_owner_headers, timeout=30).json()
        assert not any(k["id"] == kid for k in l.get("api_keys", []))
        # Cleanup
        requests.post(f"{BASE_URL}/api/setup/api-keys/{kid}/revoke",
                      headers=owner_headers, timeout=30)


# ==========================================================================
# Rate limit (last — pollutes IP counter for 5 minutes)
# ==========================================================================

class TestRateLimit:
    def test_login_rate_limit_returns_429(self):
        last_status = None
        got_429 = False
        for _ in range(15):
            r = requests.post(f"{BASE_URL}/api/auth/login-secure",
                              json={"email": "nobody@example.com", "password": "wrong"},
                              timeout=30)
            last_status = r.status_code
            if r.status_code == 429:
                got_429 = True
                body = r.json()
                # detail may be str or dict
                d = body.get("detail")
                assert d, f"expected detail in 429: {body}"
                break
        assert got_429, f"never got 429, last status: {last_status}"
