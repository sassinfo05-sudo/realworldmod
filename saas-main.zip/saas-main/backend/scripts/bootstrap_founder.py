"""One-time founder bootstrap (explicit command — NEVER run implicitly at web startup).

Usage (from /app/backend, with backend/.env present):
    python -m scripts.bootstrap_founder                       # invite link (recommended)
    python -m scripts.bootstrap_founder --email you@corp.com  # override FOUNDER_EMAIL
    python -m scripts.bootstrap_founder --prompt-password     # type a password interactively (never echoed)

What it does (idempotent):
  * Creates the founder in `users` (role platform_founder) and mirrors it into `staff_accounts` (role owner)
    if either is missing. Existing accounts are NOT overwritten unless --reset is given.
  * Default mode issues a single-use, 48h set-password invitation (token stored hashed) and prints the
    /staff/set-password?token=... link ONCE to stdout. No plaintext password is generated or stored.
  * --prompt-password sets the password from an interactive prompt (getpass), for air-gapped setups.

Exit codes: 0 ok, 1 refused (account exists without --reset), 2 config error.
"""
from __future__ import annotations

import argparse
import asyncio
import getpass
import hashlib
import os
import secrets
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))

from app import config  # noqa: E402
from app.db import get_client, get_db, utc_now_iso  # noqa: E402
from app.security import hash_password  # noqa: E402


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


async def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Zanelvo one-time founder bootstrap")
    ap.add_argument("--email", default=config.FOUNDER_EMAIL)
    ap.add_argument("--name", default="Zanelvo Founder")
    ap.add_argument("--prompt-password", action="store_true", help="set password interactively instead of an invite link")
    ap.add_argument("--reset", action="store_true", help="re-issue credentials for an EXISTING founder (invalidates sessions)")
    ap.add_argument("--public-url", default=os.environ.get("PUBLIC_APP_URL", ""), help="origin used to build the invite link")
    args = ap.parse_args(argv)

    email = (args.email or "").lower().strip()
    if not email or "@" not in email:
        print("ERROR: a valid --email (or FOUNDER_EMAIL) is required", file=sys.stderr)
        return 2
    if not os.environ.get("MONGO_URL") or not os.environ.get("DB_NAME"):
        print("ERROR: MONGO_URL and DB_NAME must be set", file=sys.stderr)
        return 2

    db = get_db()
    try:
        user = await db.users.find_one({"email": email})
        staff = await db.staff_accounts.find_one({"email": email})
        if (user or staff) and not args.reset:
            print(f"REFUSED: an account for {email} already exists. Re-run with --reset to re-issue credentials.")
            return 1

        now = utc_now_iso()
        inv_ts = int(datetime.now(timezone.utc).timestamp())
        if args.prompt_password:
            pw1 = getpass.getpass("New founder password (min 12 chars): ")
            pw2 = getpass.getpass("Confirm: ")
            if pw1 != pw2 or len(pw1) < 12:
                print("ERROR: passwords did not match or too short", file=sys.stderr)
                return 2
            pw_hash = hash_password(pw1)
            pending = False
        else:
            pw_hash = hash_password(secrets.token_urlsafe(32))  # unusable until the invite is accepted
            pending = True

        base_user = {"email": email, "password_hash": pw_hash, "full_name": args.name, "org_id": None,
                     "role": "platform_founder", "email_verified": True, "updated_at": now,
                     "sessions_invalidated_at": inv_ts}
        if user:
            await db.users.update_one({"_id": user["_id"]}, {"$set": base_user})
        else:
            await db.users.insert_one({**base_user, "created_at": now})

        base_staff = {"email": email, "password_hash": pw_hash, "full_name": args.name, "role": "owner",
                      "active": True, "updated_at": now, "sessions_invalidated_at": inv_ts,
                      "invite_pending": pending}
        if staff:
            await db.staff_accounts.update_one({"_id": staff["_id"]}, {"$set": base_staff})
            staff_id = staff["_id"]
        else:
            r = await db.staff_accounts.insert_one({**base_staff, "work_email": "founder@zanelvo.com",
                                                    "created_at": now})
            staff_id = r.inserted_id

        await db.audit_log.insert_one({"action": "founder.bootstrap", "actor": "cli", "target_type": "staff",
                                       "target_id": str(staff_id), "mode": "prompt" if args.prompt_password else "invite",
                                       "reset": bool(args.reset), "at": now})

        if not pending:
            print(f"OK: founder {email} is ready. Sign in at /staff/login (MFA required in production).")
            return 0

        raw = secrets.token_urlsafe(32)
        exp = datetime.now(timezone.utc) + timedelta(hours=48)
        await db.staff_invitations.update_many({"staff_id": str(staff_id), "used_at": None},
                                               {"$set": {"revoked_at": now}})
        await db.staff_invitations.insert_one({
            "staff_id": str(staff_id), "email": email, "token_hash": hashlib.sha256(raw.encode()).hexdigest(),
            "created_by": "cli:bootstrap_founder", "created_at": now,
            "expires_at": exp.isoformat().replace("+00:00", "Z"), "used_at": None, "revoked_at": None,
        })
        origin = (args.public_url or "").rstrip("/")
        link = f"{origin}/staff/set-password?token={raw}"
        print("OK: founder account created. Open this SINGLE-USE link within 48h to set the password:")
        print(link)
        print("(This link is shown once and is not stored anywhere in plaintext.)")
        return 0
    finally:
        get_client().close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
