# Zanelvo — Deployment (web + worker)

_Zanelvo currently reports **PRODUCTION_GATE: FAIL** — see `/app/memory/CURRENT_STATUS.md`.
Deploy to staging only until the residual P0 backlog is closed._

## Topology
- **web**  — `Dockerfile.backend` (FastAPI, `uvicorn server:app`), `RUN_SCHEDULERS=false`.
- **worker** — `Dockerfile.worker` (`python worker.py`), `RUN_SCHEDULERS=true`. Owns the Mongo
  scheduler leader lock; runs scheduled email, workflow scheduler, abandoned-cart sweep and
  subscription renewal as a singleton (safe with >1 replica — only the leader fires jobs).
- **frontend** — `Dockerfile.frontend` (static build behind nginx with a strict CSP).

## Required managed services
- **MongoDB** (managed, replica set) — `MONGO_URL`, `DB_NAME`. Enable automated daily backups
  and TEST a restore before GA.
- **Object storage** (S3/GCS) for uploads — with lifecycle + backup. (Wire before scaling web >1.)
- Redis/queue is NOT required by this design (leader lock + Mongo idempotency), but recommended
  later for a proper durable job queue + non-auth rate limits across replicas.

## Env (production) — startup FAILS FAST if incomplete
See `/app/memory/OWNER_LAUNCH_RUNBOOK.md` §0. Key: `APP_ENV=production`, explicit `CORS_ORIGINS`
(never `*`), strong `JWT_SECRET` + `SECRETS_ENC_KEY`, `SEED_DEMO_DATA` unset/false.

## Health / rollback
- Liveness/readiness: `GET /api/health` (checks DB).
- Rollback: redeploy the previous image tag / release commit; restore the latest DB snapshot if a
  migration ran. The worker is stateless — safe to restart; the leader lock lapses within its TTL
  and another worker takes over.

## Reproducible builds
- Backend: pinned `requirements.txt`. Frontend: `yarn install --frozen-lockfile` (committed
  `yarn.lock`) + `GENERATE_SOURCEMAP=false INLINE_RUNTIME_CHUNK=false yarn build`.
