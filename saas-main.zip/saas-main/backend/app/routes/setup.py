"""Setup Center: connection cards, scoped API keys, webhooks, Launch Score.

Each connection card returns an honest state: connected, requires_credential, not_connected,
error. Test buttons ping the underlying provider where possible; otherwise say so.
"""
from __future__ import annotations

import io
import json
import logging
import os
import zipfile
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_role, require_org
from ..models import User
from ..services import audit
from ..services.entitlements import entitlements_dict, get_org_plan
from ..services.webhooks import new_api_key, new_webhook_secret

logger = logging.getLogger(__name__)
from ..services.sites import active_filter as _active_filter

router = APIRouter(prefix="/api/setup", tags=["setup"])


# ============ CONNECTION CARDS ============

CARDS: List[Dict[str, Any]] = [
    # Identity & brand
    {"key": "brand", "category": "identity", "label": "Brand identity",
      "purpose": "Set business name, tagline, colors, logo.",
      "enables": "Consistent look across your site, portal, and emails.",
      "route": "/api/business-profile"},
    # Domain
    {"key": "domain", "category": "identity", "label": "Custom domain",
      "purpose": "Publish your site on your own hostname.",
      "enables": "Trusted URL for customers + SEO.",
      "route": "/api/domains"},
    # Team
    {"key": "team", "category": "identity", "label": "Team & seats",
      "purpose": "Invite teammates by email; assign roles.",
      "enables": "Managers see inbox + calendar; staff see their queue.",
      "route": "/api/auth/team"},
    # Email
    {"key": "email_sending", "category": "email", "label": "Email sending (Resend/SMTP)",
      "purpose": "Send transactional + workspace emails.",
      "enables": "Booking confirmations, quote emails, reminders.",
      "route": "/api/email/providers"},
    {"key": "mailbox_sync", "category": "email", "label": "Mailbox sync (Gmail/Outlook/IMAP)",
      "purpose": "Two-way sync of your team inbox.",
      "enables": "Reply from Zanelvo; incoming shows up as inbox conversations.",
      "route": "/api/inbox/mailboxes"},
    # Voice
    {"key": "voice", "category": "channels", "label": "Voice (Retell/Twilio)",
      "purpose": "Route incoming calls to the AI receptionist.",
      "enables": "AI answers, books, and captures leads on the phone.",
      "route": "/api/ai/voice/providers"},
    {"key": "whatsapp", "category": "channels", "label": "WhatsApp / social DMs",
      "purpose": "Route messaging into the unified inbox.",
      "enables": "Single queue for all conversations."},
    # Calendars
    {"key": "google_calendar", "category": "channels", "label": "Google Calendar",
      "purpose": "Sync bookings both ways with Google.",
      "enables": "Team calendar stays honest; no double-books."},
    {"key": "outlook_calendar", "category": "channels", "label": "Microsoft Calendar",
      "purpose": "Sync bookings both ways with Outlook."},
    # Payments
    {"key": "payments_stripe", "category": "payments", "label": "Stripe (Recommended)",
      "purpose": "Card, Apple Pay, Google Pay, ACH.",
      "enables": "Accept payments on invoices + subscriptions.",
      "route": "/api/payments/providers"},
    {"key": "payments_paypal", "category": "payments", "label": "PayPal",
      "purpose": "PayPal + Venmo checkout.",
      "enables": "Additional payment option."},
    {"key": "payments_mollie", "category": "payments", "label": "Mollie",
      "purpose": "European payments (iDEAL, SEPA)."},
    {"key": "payments_square", "category": "payments", "label": "Square",
      "purpose": "Alternate card processor."},
    # Google Business + marketing
    {"key": "google_business", "category": "marketing", "label": "Google Business Profile",
      "purpose": "Sync hours, contact, reviews with Google.",
      "enables": "Local SEO parity."},
    {"key": "ga4", "category": "marketing", "label": "Google Analytics 4",
      "purpose": "Add GA4 tracking to your site.",
      "enables": "See traffic sources in Zanelvo + GA4."},
    {"key": "google_ads", "category": "marketing", "label": "Google Ads",
      "purpose": "Attribution + conversion tracking."},
    {"key": "meta_ads", "category": "marketing", "label": "Meta Ads",
      "purpose": "Pixel + attribution for Facebook/Instagram."},
    # Accounting
    {"key": "quickbooks", "category": "accounting", "label": "QuickBooks",
      "purpose": "Sync invoices + payments to QuickBooks."},
    {"key": "xero", "category": "accounting", "label": "Xero",
      "purpose": "Sync invoices + payments to Xero."},
    # Devtools
    {"key": "slack", "category": "devtools", "label": "Slack notifications",
      "purpose": "Post new leads / bookings / payments to Slack."},
    {"key": "zapier_make", "category": "devtools", "label": "Zapier / Make / n8n",
      "purpose": "Use scoped API keys + webhooks below.",
      "enables": "Wire Zanelvo into any tool that speaks HTTP."},
]


@router.get("/cards")
async def list_cards(user: User = Depends(current_user),
                        org_id: str = Depends(require_org)):
    db = get_db()
    cards_out = []
    for c in CARDS:
        state = "not_connected"
        error_hint = None
        # Special cases with real state
        if c["key"] == "email_sending":
            cfg = await db.email_provider_configs.find_one({"org_id": org_id})
            if cfg and cfg.get("provider") and cfg.get("api_key_secret"):
                state = "connected"
            elif cfg and cfg.get("provider"):
                state = "requires_credential"
        elif c["key"] == "payments_stripe":
            cfg = await db.payment_provider_configs.find_one({"org_id": org_id,
                                                                    "provider": "stripe"})
            if cfg and cfg.get("active"):
                state = "connected"
            elif not os.environ.get("STRIPE_SECRET_KEY"):
                state = "requires_credential"
                error_hint = "Set STRIPE_SECRET_KEY or use the simulated provider."
        elif c["key"] == "voice":
            if os.environ.get("RETELL_API_KEY") or os.environ.get("TWILIO_ACCOUNT_SID"):
                state = "connected"
            else:
                state = "requires_credential"
                error_hint = "Add RETELL_API_KEY or TWILIO_ACCOUNT_SID."
        elif c["key"] == "domain":
            d = await db.domains.find_one({"org_id": org_id, "state": "connected"})
            state = "connected" if d else "not_connected"
        elif c["key"] == "brand":
            p = await db.business_profiles.find_one({"org_id": org_id})
            state = "connected" if p else "not_connected"
        elif c["key"] == "team":
            u = await db.users.count_documents({"org_id": org_id})
            state = "connected" if u >= 1 else "not_connected"
        # Persistent state from provider_connections (for cards we haven't wired yet)
        pc = await db.provider_connections.find_one({"org_id": org_id, "key": c["key"]})
        if pc and state == "not_connected":
            state = pc.get("status", state)
            error_hint = pc.get("error_hint") or error_hint
        cards_out.append({**c, "state": state, "error_hint": error_hint})
    return {"cards": cards_out}


class ConnectReq(BaseModel):
    key: str
    config_blob: Dict[str, Any] = Field(default_factory=dict)


@router.post("/cards/connect")
async def connect_card(req: ConnectReq, request: Request,
                          user: User = Depends(require_role("owner", "manager")),
                          org_id: str = Depends(require_org)):
    """Save a card's non-secret metadata. Secrets go through their dedicated route."""
    db = get_db()
    doc = {"org_id": org_id, "key": req.key, "status": "connected",
             "config_blob": req.config_blob, "last_test_at": None,
             "last_test_ok": None, "updated_at": utc_now_iso()}
    await db.provider_connections.update_one(
        {"org_id": org_id, "key": req.key},
        {"$set": doc, "$setOnInsert": {"created_at": utc_now_iso()}}, upsert=True,
    )
    await audit.record(action=f"setup.{req.key}.connect", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="provider_connection", target_id=req.key,
                          request=request)
    return {"ok": True}


@router.post("/cards/{key}/test")
async def test_card(key: str, user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    """Real test where possible, honest 'requires credential' otherwise."""
    db = get_db()
    if key == "email_sending":
        cfg = await db.email_provider_configs.find_one({"org_id": org_id})
        if not cfg:
            return {"ok": False, "message": "No email provider configured."}
        # We already have a real provider builder; test is a no-op send in dry-run
        return {"ok": True, "message": f"Provider {cfg.get('provider')} configured."}
    if key == "payments_stripe":
        cfg = await db.payment_provider_configs.find_one({"org_id": org_id, "provider": "stripe"})
        if not cfg:
            return {"ok": False,
                     "message": "Not connected. Set STRIPE_SECRET_KEY or use simulated."}
        return {"ok": True, "message": "Stripe adapter present."}
    if key == "domain":
        d = await db.domains.find_one({"org_id": org_id})
        if not d:
            return {"ok": False, "message": "No custom domain added yet."}
        return {"ok": d.get("state") == "connected",
                 "message": f"State: {d.get('state')}",
                 "state": d.get("state")}
    # Generic — reflect provider_connections state
    pc = await db.provider_connections.find_one({"org_id": org_id, "key": key})
    if not pc:
        return {"ok": False,
                 "message": "Not connected. This card is architecture-ready; add a credential to enable."}
    return {"ok": pc.get("status") == "connected", "message": f"State: {pc.get('status')}"}


@router.post("/cards/{key}/disconnect")
async def disconnect_card(key: str, request: Request,
                              user: User = Depends(require_role("owner", "manager")),
                              org_id: str = Depends(require_org)):
    db = get_db()
    await db.provider_connections.update_one({"org_id": org_id, "key": key},
                                                 {"$set": {"status": "not_connected",
                                                            "updated_at": utc_now_iso()}})
    await audit.record(action=f"setup.{key}.disconnect", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          request=request)
    return {"ok": True}


# ============ LAUNCH SCORE ============

@router.get("/launch-score")
async def launch_score(user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    checks = []
    # Site published
    website = await db.websites.find_one(await _active_filter(org_id))
    checks.append({"key": "site_published",
                     "label": "Website published",
                     "done": (website or {}).get("status") == "published",
                     "action": "Publish from the Editor" if website else "Generate your site"})
    # Brand
    profile = await db.business_profiles.find_one({"org_id": org_id})
    checks.append({"key": "brand_verified",
                     "label": "Brand facts verified",
                     "done": bool(profile),
                     "action": "Answer the interview + review facts"})
    # Email provider
    email_cfg = await db.email_provider_configs.find_one({"org_id": org_id})
    checks.append({"key": "email_provider",
                     "label": "Email provider connected",
                     "done": bool(email_cfg and email_cfg.get("api_key_secret")),
                     "action": "Add a provider in Setup → Email"})
    # Payment provider
    pay_cfg = await db.payment_provider_configs.find_one({"org_id": org_id, "active": True})
    checks.append({"key": "payment_provider",
                     "label": "Payment provider active",
                     "done": bool(pay_cfg),
                     "action": "Enable Simulated or add Stripe keys"})
    # AI receptionist enabled
    ai = await db.agents.find_one({"org_id": org_id, "agent_type": "receptionist",
                                        "enabled": True})
    ks = await db.kill_switches.find_one({"org_id": org_id})
    ai_on = bool(ai) and not (ks and not ks.get("ai_enabled", True))
    checks.append({"key": "ai_enabled",
                     "label": "AI receptionist enabled",
                     "done": ai_on,
                     "action": "Enable in AI Employees"})
    # Custom domain (optional but scored)
    d = await db.domains.find_one({"org_id": org_id, "state": "connected"})
    checks.append({"key": "custom_domain",
                     "label": "Custom domain connected",
                     "done": bool(d),
                     "action": "Add a domain in Setup"})
    done = sum(1 for c in checks if c["done"])
    return {"score": int(round(done / len(checks) * 100)),
             "done": done, "total": len(checks),
             "checks": checks}


# ============ API KEYS (scoped) ============

class ApiKeyCreate(BaseModel):
    name: str
    scopes: List[str]
    env: str = "live"


@router.get("/api-keys")
async def list_api_keys(user: User = Depends(require_role("owner", "manager")),
                            org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for k in db.api_keys.find({"org_id": org_id}).sort("created_at", -1):
        out.append({"id": str(k["_id"]), "name": k.get("name"),
                     "prefix": k.get("prefix"), "scopes": k.get("scopes") or [],
                     "revoked": bool(k.get("revoked")),
                     "created_at": k.get("created_at"),
                     "last_used_at": k.get("last_used_at")})
    return {"api_keys": out}


@router.post("/api-keys")
async def create_api_key(req: ApiKeyCreate, request: Request,
                             user: User = Depends(require_role("owner", "manager")),
                             org_id: str = Depends(require_org)):
    plan = await get_org_plan(org_id)
    if not entitlements_dict(plan).get("api_keys"):
        raise HTTPException(402, {"error": "feature_not_in_plan",
                                     "feature": "api_keys", "plan_code": plan,
                                     "message": "API keys need Revenue or higher.",
                                     "suggest_plan": "revenue"})
    valid_scopes = {"contacts:read", "contacts:write", "bookings:read",
                     "bookings:write", "invoices:read", "invoices:write",
                     "quotes:read", "quotes:write"}
    for s in req.scopes:
        if s not in valid_scopes:
            raise HTTPException(422, f"Unknown scope {s!r}. Choose from: "
                                        + ", ".join(sorted(valid_scopes)))
    full, prefix, h = new_api_key(req.env)
    db = get_db()
    doc = {"org_id": org_id, "name": req.name, "prefix": prefix,
             "key_hash": h, "scopes": req.scopes,
             "created_by_user_id": user.id,
             "revoked": False,
             "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.api_keys.insert_one(doc)
    await audit.record(action="api_key.create", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="api_key", target_id=str(r.inserted_id),
                          meta={"name": req.name, "scopes": req.scopes},
                          request=request)
    return {"id": str(r.inserted_id), "prefix": prefix, "key": full,
             "note": "This is the only time we'll show the full key. Copy it now."}


@router.post("/api-keys/{kid}/revoke")
async def revoke_api_key(kid: str, request: Request,
                             user: User = Depends(require_role("owner", "manager")),
                             org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.api_keys.update_one({"_id": ObjectId(kid), "org_id": org_id},
                                          {"$set": {"revoked": True,
                                                     "revoked_at": utc_now_iso()}})
    if r.matched_count == 0:
        raise HTTPException(404, "Not found")
    await audit.record(action="api_key.revoke", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="api_key", target_id=kid, request=request)
    return {"ok": True}


# ============ WEBHOOKS ============

WEBHOOK_EVENTS = ["contact.created", "booking.created", "booking.cancelled",
                    "invoice.created", "invoice.paid", "quote.accepted",
                    "form.submitted", "chat.message"]


class WebhookCreate(BaseModel):
    url: str
    events: List[str]


@router.get("/webhooks")
async def list_webhooks(user: User = Depends(require_role("owner", "manager")),
                            org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for w in db.webhooks.find({"org_id": org_id}).sort("created_at", -1):
        out.append({"id": str(w["_id"]), "url": w.get("url"),
                     "events": w.get("events") or [],
                     "active": bool(w.get("active", True)),
                     "last_delivery_at": w.get("last_delivery_at"),
                     "last_error": w.get("last_error")})
    return {"webhooks": out, "available_events": WEBHOOK_EVENTS}


@router.post("/webhooks")
async def create_webhook(req: WebhookCreate, request: Request,
                             user: User = Depends(require_role("owner", "manager")),
                             org_id: str = Depends(require_org)):
    for e in req.events:
        if e != "*" and e not in WEBHOOK_EVENTS:
            raise HTTPException(422, f"Unknown event {e!r}. Choose from: "
                                        + ", ".join(WEBHOOK_EVENTS))
    plain, secret_enc = new_webhook_secret()
    from ..services.netsafe import url_is_safe
    if not await url_is_safe(str(req.url), allow_http=False):
        raise HTTPException(422, "Webhook URL must be a public https:// endpoint.")
    db = get_db()
    doc = {"org_id": org_id, "url": req.url, "events": req.events,
             "active": True, "secret_enc": secret_enc,
             "created_by_user_id": user.id,
             "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.webhooks.insert_one(doc)
    await audit.record(action="webhook.create", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="webhook", target_id=str(r.inserted_id),
                          meta={"url": req.url, "events": req.events},
                          request=request)
    return {"id": str(r.inserted_id), "secret": plain,
             "note": "Save this secret — it's shown once. Verify with HMAC-SHA256 over "
                     "'<t>.<body>' and compare X-Zanelvo-Signature (t=<ts>,v1=<hex>)."}


@router.post("/webhooks/{wid}/rotate-secret")
async def rotate_webhook_secret(wid: str, request: Request,
                                user: User = Depends(require_role("owner", "manager")),
                                org_id: str = Depends(require_org)):
    """Rotate the signing secret. Returns the new plaintext ONCE; old secret stops working."""
    db = get_db()
    plain, secret_enc = new_webhook_secret()
    r = await db.webhooks.update_one({"_id": ObjectId(wid), "org_id": org_id},
                                     {"$set": {"secret_enc": secret_enc,
                                               "updated_at": utc_now_iso()},
                                      "$unset": {"secret_hash": ""}})
    if r.matched_count == 0:
        raise HTTPException(404, "Not found")
    await audit.record(action="webhook.rotate_secret", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="webhook", target_id=wid, request=request)
    return {"id": wid, "secret": plain, "note": "New signing secret — shown once."}


@router.delete("/webhooks/{wid}")
async def delete_webhook(wid: str, request: Request,
                             user: User = Depends(require_role("owner", "manager")),
                             org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.webhooks.delete_one({"_id": ObjectId(wid), "org_id": org_id})
    if r.deleted_count == 0:
        raise HTTPException(404, "Not found")
    await audit.record(action="webhook.delete", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="webhook", target_id=wid, request=request)
    return {"ok": True}


# ============ DATA EXPORT / ORG DELETION ============

_ORG_COLLECTIONS = [
    "business_profiles", "websites", "revisions", "domains", "media_assets",
    "form_submissions", "analytics_events", "import_runs",
    "contacts", "deals", "notes", "interactions", "tags",
    "email_provider_configs", "email_messages", "email_threads",
    "service_offerings", "staff", "bookings", "quotes", "invoices",
    "payments", "jobs", "refunds",
    "knowledge_sources", "agents", "agent_versions",
    "chat_conversations", "chat_messages", "call_records", "agent_interactions",
    "subscriptions", "billing_invoices", "checkout_sessions",
    "api_keys", "webhooks", "provider_connections",
    "support_tickets",
]


@router.post("/data-export")
async def data_export(user: User = Depends(require_role("owner")),
                          org_id: str = Depends(require_org)):
    """Streams a ZIP of every org-owned collection as JSON. Runs synchronously —
    fine for a Phase 6 tenant footprint; a Celery job would be Phase 8.
    """
    db = get_db()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for coll in _ORG_COLLECTIONS:
            items: List[Dict[str, Any]] = []
            async for d in db[coll].find({"org_id": org_id}):
                d["_id"] = str(d["_id"])
                items.append(d)
            zf.writestr(f"{coll}.json", json.dumps(items, default=str, indent=2))
    buf.seek(0)
    await audit.record(action="data.export", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id)
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="zanelvo-export-{org_id}.zip"'},
    )


class DeleteOrgReq(BaseModel):
    confirm: str
    reason: Optional[str] = None


@router.post("/delete-org")
async def request_delete_org(req: DeleteOrgReq, request: Request,
                                 user: User = Depends(require_role("owner")),
                                 org_id: str = Depends(require_org)):
    """Soft-delete workflow. Sets org.suspended + org_deletion_request with a 30-day grace."""
    if req.confirm.upper() != "DELETE":
        raise HTTPException(422, "Type DELETE to confirm.")
    db = get_db()
    purge_at = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat().replace("+00:00", "Z")
    await db.organizations.update_one({"_id": ObjectId(org_id)},
                                          {"$set": {"suspended": True,
                                                     "suspension_reason": "pending_deletion",
                                                     "updated_at": utc_now_iso()}})
    r = await db.org_deletion_requests.insert_one({
        "org_id": org_id, "requested_by_user_id": user.id,
        "reason": req.reason, "status": "scheduled",
        "scheduled_purge_at": purge_at,
        "created_at": utc_now_iso(), "updated_at": utc_now_iso(),
    })
    await audit.record(action="org.delete_scheduled", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          reason=req.reason, request=request,
                          meta={"purge_at": purge_at})
    return {"ok": True, "purge_at": purge_at, "request_id": str(r.inserted_id),
             "grace_days": 30}


@router.post("/delete-org/cancel")
async def cancel_delete(request: Request,
                            user: User = Depends(require_role("owner")),
                            org_id: str = Depends(require_org)):
    db = get_db()
    await db.org_deletion_requests.update_many({"org_id": org_id, "status": "scheduled"},
                                                    {"$set": {"status": "canceled",
                                                               "updated_at": utc_now_iso()}})
    await db.organizations.update_one({"_id": ObjectId(org_id)},
                                          {"$set": {"suspended": False,
                                                     "suspension_reason": None,
                                                     "updated_at": utc_now_iso()}})
    await audit.record(action="org.delete_canceled", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          request=request)
    return {"ok": True}

@router.get("/webhooks/{wid}/deliveries")
async def webhook_deliveries(wid: str, limit: int = 50, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Round 11 — recent deliveries for one endpoint (status, attempts, response code)."""
    db = get_db()
    rows = []
    async for d in db.webhook_deliveries.find({"org_id": org_id, "webhook_id": wid}).sort("created_at", -1).limit(max(1, min(int(limit), 200))):
        rows.append({"id": str(d["_id"]), "event": d.get("event"), "status": d.get("status"), "attempts": d.get("attempts", 1),
                     "last_response_code": d.get("last_response_code"), "error": (d.get("error") or "")[:200],
                     "created_at": d.get("created_at"), "replayed_from": d.get("replayed_from")})
    return {"deliveries": rows}


@router.post("/webhooks/{wid}/replay/{delivery_id}")
async def webhook_replay(wid: str, delivery_id: str, request: Request, user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    """Round 11 — re-send ONE past delivery (same event + redacted payload) to the same endpoint.
    Owner-scoped; the new delivery row references `replayed_from`."""
    from bson import ObjectId as _OID
    from ..services.webhooks import dispatch_event
    db = get_db()
    try:
        d = await db.webhook_deliveries.find_one({"_id": _OID(delivery_id), "org_id": org_id})
    except Exception:  # noqa: BLE001
        d = None
    if not d:
        raise HTTPException(404, "Delivery not found")
    before = await db.webhook_deliveries.count_documents({"org_id": org_id})
    await dispatch_event(org_id, d["event"], {**(d.get("payload") or {}), "_replay_of": delivery_id})
    await db.webhook_deliveries.update_many({"org_id": org_id, "created_at": {"$gt": d.get("created_at", "")}, "replayed_from": {"$exists": False},
                                             "event": d["event"], "payload._replay_of": delivery_id},
                                            {"$set": {"replayed_from": delivery_id}})
    after = await db.webhook_deliveries.count_documents({"org_id": org_id})
    return {"ok": True, "deliveries_created": max(0, after - before)}
