# ZANELVO — HANDOFF ROUND 9 (for a NEW chat)

_Written at the end of Round 9. Read this first, then `HANDOFF_ROUND_8.md` (§2 has the full A–N
item map + "how to build" notes that are still the authoritative backlog), then `SECOND_RUN_AUDIT.md`
and `WHATS_LEFT.md`. Source code + fresh test evidence override any older ✅ claims._

---------------------------------------------------------------------------------------------------
## 0. HOW TO CONTINUE (first 10 minutes)
---------------------------------------------------------------------------------------------------
The environment is WIPED on import (both `.env` empty, no `node_modules`, no pip packages).

```bash
# 1. Preview host (changes per job)
env | grep -i preview_endpoint

# 2. backend/.env  (MONGO_URL + DB_NAME are the only protected ones)
cd /app/backend && JWT=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))") && \
SEK=$(python3 -c "import secrets;print(secrets.token_urlsafe(32))") && cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=zanelvo_db
JWT_SECRET=$JWT
JWT_ALG=HS256
JWT_ACCESS_TTL_MIN=1440
SECRETS_ENC_KEY=$SEK
EMERGENT_LLM_KEY=<emergent_integrations_manager tool>
LLM_PROVIDER=anthropic
LLM_MODEL=claude-sonnet-4-6
FOUNDER_EMAIL=founder@zanelvo.com
DEMO_OWNER_EMAIL=owner@zanelvo.com
FOUNDER_EMAILS=idoyiron@gmail.com,founder@zanelvo.com
APP_ENV=dev
SEED_DEMO=true
CORS_ORIGINS=*
EOF

# 3. frontend/.env
cat > /app/frontend/.env <<EOF
REACT_APP_BACKEND_URL=<preview host from step 1>
WDS_SOCKET_PORT=443
ENABLE_HEALTH_CHECK=false
EOF

# 4. deps
cd /app/backend && pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cd /app/frontend && yarn install --frozen-lockfile   # yarn.lock is now committed (Round 9)
sudo supervisorctl restart backend frontend && sleep 25 && curl -s localhost:8001/api/health
```

- Fresh random credentials are regenerated into `/app/memory/test_credentials.md` on seed when it is
  empty. Always send the NEW file contents, never old passwords.
- **Round-9 requirements.txt fix:** the direct `litellm @ <wheel>` pin was REMOVED because it conflicted
  with `emergentintegrations==0.2.0` (which pins the same wheel) causing `ResolutionImpossible`. Keep it removed.

---------------------------------------------------------------------------------------------------
## 1. WHAT ROUND 9 SHIPPED (backend testing agent: 15/15 PASS)
---------------------------------------------------------------------------------------------------
Focus this round was **Gate 1 (P0 security)** — the highest-risk money/XSS defects — plus repo
reproducibility. All items below are code-complete AND verified by the backend testing agent
(APP_ENV=dev preview) and by manual APP_ENV=production checks where noted.

1. **Payment integrity (Gate 1A) — FIXED & VERIFIED.**
   - New `config.simulation_allowed()` / `config.is_production()`. Simulated money flows exist ONLY when
     `APP_ENV` ∈ {dev,test,demo}.
   - `POST /api/billing/checkout/{sid}/complete`: hard-gated — 403 `simulated_completion_forbidden` in
     production; 400 `provider_completion_required` for any non-simulated (stripe/paypal) session even in dev.
   - `POST /api/billing/checkout`: 400 `payments_not_configured` for simulated in production; when provider=stripe
     it now creates a REAL Stripe Checkout session (server-computed immutable amount, metadata
     {checkout_session_id, org_id, plan_code}) and returns the real URL — completion happens ONLY via the
     signature-verified idempotent webhook `POST /api/billing/webhook/stripe`. Stores immutable price snapshot
     (`price_cents`, `plan_price_snapshot`, `currency`, `interval`, coupon).
   - `POST /api/payments/simulated/pay` (public store/invoice sim confirm): 403 in production.
   - Store buy-now: 400 `payments_not_configured` when no live provider and in production.
   - `POST /api/billing/subscription/simulate-payment-failure`: 403 in production.
   - PayPal live rail intentionally refused (400 `provider_not_available`) until signed webhook verification is built.
   - Manual prod check (APP_ENV=production restart) confirmed all three 403/400 gates; dev happy-path still 200.
2. **SVG XSS sanitization (Gate 1B) — FIXED & VERIFIED.** New `services/svg_safe.py::sanitize_svg()`
   (allow-list: strips `<script>/<foreignObject>/<iframe>/<object>/<embed>`, `on*` handlers, remote/js
   href/src, dangerous `<style>`/style attrs; rejects non-SVG). Applied via pydantic validator on
   `BrandingIn.logo_svg`/`logomark_svg` so all branding endpoints sanitize on write.
3. **custom_head_html arbitrary-script XSS (Gate 1B) — REMOVED & VERIFIED.** Backend
   `PATCH /api/tenant/website/seo-and-pixels` no longer accepts `custom_head_html` (purged on write) and now
   STRICT-validates every analytics id (`_PIXEL_FORMATS`, 422 on bad format). Frontend `PublicSite.jsx`
   no longer injects raw HTML; the SEO settings textarea was removed. Only typed, format-checked pixels remain.
4. **Usage idempotency cross-tenant leak (Gate 1D) — FIXED & VERIFIED.** `usage.find_idempotent` /
   `remember_idempotent` now hash a composite scope (org · user/session · feature · operation · provider ·
   model · key) into `skey`; a UNIQUE index on `usage_idempotency.skey` is created at startup. One tenant can
   no longer read another tenant's cached output. Added `usage_reservations` (org,status,month) index.
5. **Repo reproducibility.** `frontend/yarn.lock` generated (commit it). requirements.txt litellm conflict fixed.

---------------------------------------------------------------------------------------------------
## 2. WHAT IS **NOT** DONE (do NOT claim these as live) — the rest of the Round-9 mega-prompt
---------------------------------------------------------------------------------------------------
Round 9 deliberately prioritized the P0 money/XSS defects. The remaining Gate 1 items and Gates 2–7
are NOT done this round. The authoritative backlog with exact files + "how to build" notes is
**HANDOFF_ROUND_8.md §2 (A–N)** and `WHATS_LEFT.md`. Highest-priority carry-overs still open:

### Gate 1 (P0) leftovers still open
- **JWT in localStorage → HttpOnly cookie migration + CSRF** — NOT done (big auth refactor; tokens still in JS storage).
- **Public-site origin isolation + strict CSP** — NOT done (custom HTML disabled instead, which mitigates the worst XSS).
- **Page-password server-side hashing + unlock token (Gate 1C)** — NOT done; per-page passwords still compared in published JSON. HIGH PRIORITY NEXT.
- **Webhook signing secret reversible encryption (Gate 1F)** — NOT done; outbound signing still uses a stored hash as the key.
- **Inbound email provider-signature verification + org resolution (Gate 1G)** — partial (shared-secret only).
- **Voice/SMS/WhatsApp provider-native signatures + tenant binding (Gate 1H)** — partial (voice authed; no SMS/WhatsApp).
- **MFA/login unification, hashed email codes, encrypted TOTP, single-use invite links (Gate 1I)** — partial.
- **Secret scanning + rotate creds that appeared in repo/tests (Gate 1J)** — earlier rounds redacted; a full scanner + rotation pass NOT done this round.
- **Usage: atomic budget counters vs "sum then insert", holds counted in caps, budget-warning emails (Gate 1D/B)** — partial.
- **PayPal signed webhook, Stripe Connect for tenant funds** — NOT done (PayPal live refused; Stripe is platform-account only).
- **Chunked uploads, CSV row caps, MIME-by-bytes, media SVG sanitize on upload** — NOT done (SVG sanitize is on branding save only).
- **Redis-backed rate limits for non-auth buckets** — NOT done (in-process).

### Gates 2–7 (breadth) — essentially all NOT done this round
- Gate 2 fresh full regression of ALL modules; Gate 3 template gallery / build-from-scratch / section
  regeneration / blog / booking block / media object-storage / real custom-domain SSL; Gate 4 commerce depth
  (variants matrix, stock reservations, tax, returns/RMA, subscriptions, gift cards, customer accounts);
  Gate 5 visual workflow builder + drag-drop email editor + ads studio depth + analytics CAC/LTV/funnels;
  Gate 6 discovery/i18n/support inbox/status page/OAuth framework; Gate 7 public UX "wow" redesign + brand
  sweep of remaining stale terms + help-article rewrite + doc canonicalization.

---------------------------------------------------------------------------------------------------
## 3. PROVIDER / INTEGRATION STATE (unchanged from Round 8 unless noted)
---------------------------------------------------------------------------------------------------
LLM (Emergent key) **Connected** · Email **Sandbox** · Stripe **Not connected** (now creates REAL sessions
once STRIPE_SECRET_KEY + STRIPE_WEBHOOK_SECRET are set) · PayPal **Not connected / live refused** · Voice
**Sandbox** · Carriers **Not connected** · Ads **Not connected** · Domains/SSL **Sandbox** (DNS verify real).
Recurring provider cost: LLM only, metered. Everything else $0 until connected.

---------------------------------------------------------------------------------------------------
## 4. RECOMMENDED ORDER FOR ROUND 10
---------------------------------------------------------------------------------------------------
1. Page-password server-side (Gate 1C) + webhook signing-secret encryption (Gate 1F) — small, high-value P0.
2. JWT→HttpOnly cookie + CSRF (Gate 1I/B) — unlocks removing tokens from JS storage.
3. Full fresh regression (Gate 2) of untested modules.
4. Website breadth: template gallery + build-from-scratch + section regeneration + blog (Gate 3).
5. Visual workflow builder (Gate 5) — biggest parity gap.
Finish every round with: SECOND_RUN_AUDIT + CHANGELOG + rename this handoff to ROUND_10 + test_result.md.

GIT: do NOT push from the agent — use the chat's **Save to Github** button (platform rule).
