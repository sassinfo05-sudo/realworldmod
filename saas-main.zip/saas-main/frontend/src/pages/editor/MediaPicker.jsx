/**
 * MediaPicker — modal that lists the org's uploaded media and lets the user pick one
 * OR upload a new file (base64 → /api/media/upload) OR paste an external URL.
 *
 * Usage:
 *   <MediaPicker value={url} onChange={(url) => …} />
 *
 * Renders a small input + "Browse" button; the modal opens on click.
 */
import { useEffect, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import api from "@/lib/api";
import { Image, Upload, Link2, X, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";

const MAX_SIZE = 4 * 1024 * 1024;

export default function MediaPicker({ value, onChange, testid = "media-picker", placeholder = "https://… or click Browse" }) {
    const [open, setOpen] = useState(false);
    const [assets, setAssets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [urlInput, setUrlInput] = useState(value || "");
    const fileRef = useRef(null);

    useEffect(() => setUrlInput(value || ""), [value]);

    useEffect(() => {
        if (!open) return;
        setLoading(true);
        api.get("/media")
            .then((r) => setAssets(r.data?.assets || []))
            .catch(() => setAssets([]))
            .finally(() => setLoading(false));
    }, [open]);

    const [progress, setProgress] = useState(0);

    /** Round 11 — files above 1 MB go through the chunked path (init → 512 KB chunks → complete) so the
     *  proxy body limit is never hit; small files keep the single-shot upload. */
    async function upload(file) {
        if (!file) return;
        if (file.size > MAX_SIZE) { toast.error("File too large (max 4MB)"); return; }
        setUploading(true); setProgress(0);
        try {
            let data;
            if (file.size > 1024 * 1024) {
                const { data: init } = await api.post("/media/upload/init", { filename: file.name, mime: file.type, total_bytes: file.size });
                const size = init.chunk_bytes;
                for (let i = 0; i < init.chunks; i++) {
                    const slice = file.slice(i * size, Math.min(file.size, (i + 1) * size));
                    const b64 = await new Promise((resolve, reject) => {
                        const r = new FileReader();
                        r.onload = () => { const s = r.result || ""; const idx = s.indexOf("base64,"); resolve(idx >= 0 ? s.slice(idx + 7) : s); };
                        r.onerror = reject; r.readAsDataURL(slice);
                    });
                    await api.post(`/media/upload/${init.upload_id}/chunk`, { index: i, data_base64: b64 });
                    setProgress(Math.round(((i + 1) / init.chunks) * 90));
                }
                ({ data } = await api.post(`/media/upload/${init.upload_id}/complete`, {}));
            } else {
                const b64 = await new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = () => {
                        const s = reader.result || "";
                        const idx = s.indexOf("base64,");
                        resolve(idx >= 0 ? s.slice(idx + 7) : s);
                    };
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                });
                ({ data } = await api.post("/media/upload", { filename: file.name, mime: file.type, data_base64: b64 }));
            }
            setProgress(100);
            setAssets((prev) => [data, ...prev]);
            onChange(data.url);
            setOpen(false);
            toast.success("Uploaded");
        } catch (e) {
            const d = e?.response?.data?.detail;
            toast.error(typeof d === "string" ? d : d?.error === "chunks_missing" ? "Upload incomplete — please retry" : "Upload failed");
        } finally { setUploading(false); setProgress(0); }
    }

    function pick(url) {
        onChange(url);
        setUrlInput(url);
        setOpen(false);
    }

    return (
        <div className="flex items-center gap-2" data-testid={testid}>
            <input
                type="text"
                value={urlInput}
                onChange={(e) => { setUrlInput(e.target.value); onChange(e.target.value); }}
                placeholder={placeholder}
                className="flex-1 border border-brand-line rounded-md px-3 py-2 text-sm"
                data-testid={`${testid}-input`} />
            <Button size="sm" variant="outline" onClick={() => setOpen(true)} data-testid={`${testid}-browse-btn`}>
                <Image className="w-3.5 h-3.5 mr-1" aria-hidden="true" /> Browse
            </Button>
            {value && (
                <button onClick={() => { onChange(""); setUrlInput(""); }}
                        className="text-zinc-400 hover:text-red-600" aria-label="Clear image"
                        data-testid={`${testid}-clear`}>
                    <X className="w-4 h-4" />
                </button>
            )}

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="max-w-4xl">
                    <DialogHeader>
                        <DialogTitle>Pick or upload an image</DialogTitle>
                    </DialogHeader>

                    {/* Upload strip */}
                    <div className="flex items-center gap-3 p-4 rounded-xl border border-dashed border-brand-line bg-brand-cream/30">
                        <input ref={fileRef} type="file" accept="image/*" className="hidden"
                                onChange={(e) => upload(e.target.files?.[0])} />
                        <Button onClick={() => fileRef.current?.click()} disabled={uploading}
                                data-testid={`${testid}-upload-btn`}
                                className="bg-brand-copper hover:bg-brand-copperHover text-white">
                            {uploading ? <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Uploading{progress > 0 ? ` ${progress}%` : "…"}</> : <><Upload className="w-4 h-4 mr-1" /> Upload from computer</>}
                        </Button>
                        <div className="text-xs text-zinc-500">PNG, JPG, WebP, GIF or SVG · max 4MB</div>
                    </div>

                    {/* URL paste */}
                    <div className="mt-4 flex items-center gap-2 p-3 rounded-xl border border-brand-line">
                        <Link2 className="w-4 h-4 text-brand-copper" />
                        <input placeholder="Paste an external image URL (https://…)"
                                value={urlInput}
                                onChange={(e) => setUrlInput(e.target.value)}
                                data-testid={`${testid}-url-input`}
                                className="flex-1 outline-none text-sm bg-transparent" />
                        <Button size="sm" variant="outline" onClick={() => urlInput && pick(urlInput)}
                                data-testid={`${testid}-url-use-btn`}>
                            <Check className="w-3.5 h-3.5 mr-1" /> Use
                        </Button>
                    </div>

                    {/* Library */}
                    <div className="mt-4 text-xs uppercase tracking-widest text-brand-copper">Your media library</div>
                    <div className="mt-2 max-h-[45vh] overflow-y-auto">
                        {loading ? (
                            <div className="py-8 text-center text-zinc-500 text-sm">Loading…</div>
                        ) : assets.length === 0 ? (
                            <div className="py-8 text-center text-zinc-500 text-sm">
                                No uploads yet — click "Upload from computer" above to add your first.
                            </div>
                        ) : (
                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                                {assets.map((a) => (
                                    <button key={a.id} onClick={() => pick(a.url)}
                                            data-testid={`${testid}-asset-${a.id}`}
                                            className={`group rounded-lg border overflow-hidden text-left ${
                                                a.url === value ? "border-brand-copper ring-2 ring-brand-copper/40" : "border-brand-line hover:border-brand-copper"
                                            }`}>
                                        <div className="aspect-square bg-zinc-100 flex items-center justify-center">
                                            <img src={a.url} alt={a.alt_text || a.filename}
                                                 className="w-full h-full object-cover"
                                                 onError={(e) => { e.currentTarget.style.display = "none"; }} />
                                        </div>
                                        <div className="p-1.5 text-[10px] text-zinc-500 truncate font-mono">{a.filename}</div>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}
