import React, { useEffect, useMemo, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Save, TrendingUp, AlertTriangle } from "lucide-react";

const COST_FIELDS = [
    { key: "per_ai_conversation", label: "Per AI conversation" },
    { key: "per_voice_minute", label: "Per voice minute" },
    { key: "per_email", label: "Per email sent" },
    { key: "per_website_month", label: "Per website / mo" },
    { key: "per_contact_month", label: "Per contact / mo" },
    { key: "base_infra_per_org_month", label: "Base infra / org / mo" },
];

const LIMIT_FIELDS = [
    { key: "ai_conversations_per_month", label: "AI conversations / mo" },
    { key: "voice_minutes_per_month", label: "Voice minutes / mo" },
    { key: "email_sends_per_month", label: "Emails / mo" },
    { key: "max_contacts", label: "Contacts" },
    { key: "max_users", label: "Team seats" },
    { key: "websites", label: "Websites" },
];

function costAtFull(limits, uc) {
    return (
        (limits.ai_conversations_per_month || 0) * (+uc.per_ai_conversation || 0) +
        (limits.voice_minutes_per_month || 0) * (+uc.per_voice_minute || 0) +
        (limits.email_sends_per_month || 0) * (+uc.per_email || 0) +
        (limits.websites || 0) * (+uc.per_website_month || 0) +
        (limits.max_contacts || 0) * (+uc.per_contact_month || 0) +
        (+uc.base_infra_per_org_month || 0)
    );
}

function money(n) { return `$${(Math.round((n + Number.EPSILON) * 100) / 100).toLocaleString()}`; }

export default function PricingEconomics() {
    const [settings, setSettings] = useState(null);
    const [plans, setPlans] = useState([]);
    const [saving, setSaving] = useState(false);

    async function load() {
        const [s, p] = await Promise.all([api.get("/founder/settings"), api.get("/founder/plans-admin")]);
        setSettings(s.data);
        setPlans(p.data.map((pl) => ({ ...pl, limits: { ...pl.limits } })));
    }
    useEffect(() => { load().catch(() => toast.error("Failed to load")); }, []);

    const uc = settings?.unit_costs || {};
    const disc = +(settings?.annual_discount_pct ?? 20);

    const rows = useMemo(() => plans.map((p) => {
        const cost = costAtFull(p.limits, uc);
        const profit = (p.price_usd || 0) - cost;
        const margin = p.price_usd > 0 ? (profit / p.price_usd) * 100 : null;
        const annualMo = (p.price_usd || 0) * (1 - disc / 100);
        const annualProfit = annualMo - cost;
        return { ...p, cost, profit, margin, annualMo, annualProfit };
    }), [plans, uc, disc]);

    async function saveSettings() {
        setSaving(true);
        try {
            const { data } = await api.put("/founder/settings", { unit_costs: uc, annual_discount_pct: disc });
            setSettings(data);
            toast.success("Costs & discount saved");
        } catch { toast.error("Save failed"); } finally { setSaving(false); }
    }

    async function savePlan(p) {
        try {
            await api.put(`/founder/plans-admin/${p.code}`, { price_usd: +p.price_usd, limits: p.limits });
            toast.success(`${p.name} saved`);
            await load();
        } catch { toast.error("Save failed"); }
    }

    if (!settings) return <div className="p-8 text-zinc-500">Loading…</div>;

    const free = rows.find((r) => r.code === "free");

    return (
        <div className="p-6 md:p-8" data-testid="founder-pricing">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-2"><TrendingUp className="w-4 h-4" /> Pricing &amp; economics</div>
            <h1 className="font-display text-3xl text-brand-ink">Plans, prices &amp; profit</h1>
            <p className="mt-2 text-sm text-zinc-500">Edit prices and usage limits. Profit is shown live — assuming a customer uses 100% of every limit.</p>

            {/* Costs + discount */}
            <div className="mt-6 rounded-2xl border border-brand-line bg-white p-5">
                <div className="flex items-center justify-between mb-4">
                    <div className="font-display text-lg text-brand-ink">Your unit costs</div>
                    <Button size="sm" onClick={saveSettings} disabled={saving} className="bg-brand-ink text-white hover:bg-black" data-testid="save-costs">
                        <Save className="w-3.5 h-3.5 mr-1" /> Save costs
                    </Button>
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                    {COST_FIELDS.map((c) => (
                        <div key={c.key}>
                            <label className="block text-xs text-zinc-500 mb-1">{c.label}</label>
                            <div className="flex items-center rounded-lg border border-brand-line bg-white px-2">
                                <span className="text-zinc-400 text-sm">$</span>
                                <input type="number" step="0.0001" data-testid={`cost-${c.key}`}
                                    value={uc[c.key] ?? 0}
                                    onChange={(e) => setSettings({ ...settings, unit_costs: { ...uc, [c.key]: e.target.value } })}
                                    className="w-full py-2 px-1 text-sm text-brand-ink outline-none bg-transparent" />
                            </div>
                        </div>
                    ))}
                    <div>
                        <label className="block text-xs text-zinc-500 mb-1">Annual discount %</label>
                        <input type="number" step="1" data-testid="annual-discount"
                            value={disc}
                            onChange={(e) => setSettings({ ...settings, annual_discount_pct: e.target.value })}
                            className="w-full rounded-lg border border-brand-line bg-white py-2 px-2 text-sm text-brand-ink outline-none" />
                    </div>
                </div>
            </div>

            {free && (
                <div className={`mt-4 rounded-xl border p-4 text-sm flex items-start gap-2 ${free.cost > 0 ? "border-amber-300 bg-amber-50 text-amber-800" : "border-emerald-300 bg-emerald-50 text-emerald-800"}`}>
                    <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                    <div>Free plan costs you <b>{money(free.cost)}/mo</b> per user at 100% usage. {free.cost > 0 ? "Lower the free limits to reduce this." : "You don’t lose money on free."}</div>
                </div>
            )}

            {/* Per-plan editor */}
            <div className="mt-6 space-y-4">
                {rows.map((p) => (
                    <div key={p.code} data-testid={`plan-editor-${p.code}`} className="rounded-2xl border border-brand-line bg-white p-5">
                        <div className="flex flex-wrap items-center gap-4 justify-between">
                            <div className="font-display text-lg text-brand-ink">{p.name}</div>
                            <div className="flex items-center gap-4 text-sm">
                                <div className="flex items-center rounded-lg border border-brand-line px-2">
                                    <span className="text-zinc-400">$</span>
                                    <input type="number" data-testid={`price-${p.code}`} value={p.price_usd}
                                        onChange={(e) => setPlans(plans.map((x) => x.code === p.code ? { ...x, price_usd: e.target.value } : x))}
                                        className="w-24 py-1.5 px-1 text-sm text-brand-ink outline-none bg-transparent" />
                                    <span className="text-zinc-400 text-xs">/mo</span>
                                </div>
                                <div className="text-right">
                                    <div className={`font-medium ${p.profit < 0 ? "text-red-600" : "text-emerald-600"}`} data-testid={`profit-${p.code}`}>
                                        {money(p.profit)}/mo profit
                                    </div>
                                    <div className="text-xs text-zinc-400">cost {money(p.cost)} · {p.margin == null ? "—" : `${p.margin.toFixed(0)}% margin`}</div>
                                </div>
                                <Button size="sm" onClick={() => savePlan(plans.find((x) => x.code === p.code))} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid={`save-plan-${p.code}`}>Save</Button>
                            </div>
                        </div>
                        <div className="mt-4 grid sm:grid-cols-3 lg:grid-cols-6 gap-3">
                            {LIMIT_FIELDS.map((l) => (
                                <div key={l.key}>
                                    <label className="block text-[11px] text-zinc-500 mb-1">{l.label}</label>
                                    <input type="number" data-testid={`limit-${p.code}-${l.key}`}
                                        value={p.limits[l.key] ?? 0}
                                        onChange={(e) => setPlans(plans.map((x) => x.code === p.code ? { ...x, limits: { ...x.limits, [l.key]: +e.target.value } } : x))}
                                        className="w-full rounded-lg border border-brand-line bg-white py-1.5 px-2 text-sm text-brand-ink outline-none" />
                                </div>
                            ))}
                        </div>
                        <div className="mt-3 text-xs text-zinc-400">Annual (billed yearly): {money(p.annualMo)}/mo · {money(p.annualProfit)}/mo profit</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
