"""Insights — real stat-card + trend aggregations powering every dashboard page.

GET /api/insights/overview                → whole-business snapshot (home dashboard)
GET /api/insights/{area}?days=30          → area ∈ marketing | bookings | inbox | payments | crm | ai | store | website
Every number is computed from the org's own collections; nothing is invented.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from ..db import get_db
from ..deps import current_user, require_org
from ..models import User

router = APIRouter(prefix="/insights", tags=["insights"])

AREAS = {"marketing", "bookings", "inbox", "payments", "crm", "ai", "store", "website"}


def _iso(dt: datetime) -> str:
    return dt.isoformat().replace("+00:00", "Z")


def _window(days: int):
    now = datetime.now(timezone.utc)
    start = now - timedelta(days=days)
    prev_start = start - timedelta(days=days)
    return now, start, prev_start


def _day(s: Optional[str]) -> Optional[str]:
    return (s or "")[:10] or None


def _pct(cur: float, prev: float) -> Optional[float]:
    if prev in (0, None):
        return None if cur == 0 else 100.0
    return round((cur - prev) / prev * 100, 1)


async def _rows(db, coll: str, org_id: str, since: str, field: str = "created_at", extra: Optional[Dict[str, Any]] = None,
                proj: Optional[Dict[str, int]] = None, limit: int = 20000) -> List[Dict[str, Any]]:
    q = {"org_id": org_id, field: {"$gte": since}}
    q.update(extra or {})
    cur = db[coll].find(q, proj or {"_id": 0}).limit(limit)
    return [r async for r in cur]


def _series(rows: List[Dict[str, Any]], days: int, start: datetime, field: str = "created_at",
            value=lambda r: 1) -> List[Dict[str, Any]]:
    buckets: Dict[str, float] = defaultdict(float)
    for r in rows:
        d = _day(r.get(field))
        if d:
            buckets[d] += value(r)
    out = []
    for i in range(days + 1):
        d = (start + timedelta(days=i)).date().isoformat()
        out.append({"date": d, "value": round(buckets.get(d, 0), 2)})
    return out


def _split(rows: List[Dict[str, Any]], start_iso: str, field: str = "created_at"):
    cur = [r for r in rows if (r.get(field) or "") >= start_iso]
    prev = [r for r in rows if (r.get(field) or "") < start_iso]
    return cur, prev


def card(key: str, label: str, value, prev=None, fmt: str = "int", hint: str = "") -> Dict[str, Any]:
    return {"key": key, "label": label, "value": value, "prev": prev, "delta_pct": _pct(value or 0, prev or 0) if prev is not None else None,
            "format": fmt, "hint": hint}


# ---------------- area builders ----------------

async def _marketing(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    campaigns = [c async for c in db.campaigns.find({"org_id": org_id}, {"_id": 0, "name": 1, "subject": 1, "status": 1, "metrics": 1,
                                                                       "sent_at": 1, "created_at": 1, "utm": 1, "variants": 1, "revenue_cents": 1})]
    emails = await _rows(db, "email_messages", org_id, _iso(prev_start), "sent_at", {"direction": "outbound"},
                         {"_id": 0, "sent_at": 1, "campaign_id": 1, "opened_at": 1, "clicked_at": 1})
    events = await _rows(db, "analytics_events", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "kind": 1, "meta": 1, "referrer": 1})
    orders = await _rows(db, "store_orders", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "total_cents": 1, "status": 1, "utm": 1, "campaign_id": 1})
    autos = [a async for a in db.automations.find({"org_id": org_id}, {"_id": 0, "status": 1})]
    runs = await _rows(db, "automation_runs", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "status": 1})

    s_iso = _iso(start)
    e_cur, e_prev = _split(emails, s_iso, "sent_at")
    opens = [e for e in e_cur if e.get("opened_at")]
    clicks = [e for e in e_cur if e.get("clicked_at")]
    # metrics recorded on campaigns at send time (opens/clicks tracked when provider webhooks exist)
    sent_total = sum((c.get("metrics") or {}).get("sent", 0) for c in campaigns)
    open_total = sum((c.get("metrics") or {}).get("opened", 0) for c in campaigns) or len(opens)
    click_total = sum((c.get("metrics") or {}).get("clicked", 0) for c in campaigns) or len(clicks)
    utm_orders = [o for o in orders if (o.get("utm") or {}).get("source") or o.get("campaign_id")]
    attributed = sum(o.get("total_cents", 0) for o in utm_orders if o.get("status") in ("paid", "fulfilled", "completed")) / 100
    conv_events = [e for e in events if e.get("kind") in ("form_submit", "cta_click")]
    c_cur, c_prev = _split(conv_events, s_iso)

    utm: Dict[str, Dict[str, float]] = defaultdict(lambda: {"visits": 0, "conversions": 0, "revenue": 0.0})
    for e in events:
        src = (e.get("meta") or {}).get("utm_source") or (e.get("referrer") or "direct").split("/")[2] if (e.get("referrer") or "").startswith("http") else ((e.get("meta") or {}).get("utm_source") or "direct")
        if e.get("kind") == "pageview":
            utm[src]["visits"] += 1
        else:
            utm[src]["conversions"] += 1
    for o in orders:
        src = (o.get("utm") or {}).get("source") or ("campaign" if o.get("campaign_id") else "direct")
        if o.get("status") in ("paid", "fulfilled", "completed"):
            utm[src]["revenue"] += (o.get("total_cents") or 0) / 100

    ab = []
    for c in campaigns:
        for v in (c.get("variants") or []):
            ab.append({"campaign": c.get("name") or c.get("subject"), "variant": v.get("label") or v.get("id"),
                       "sent": v.get("sent", 0), "opened": v.get("opened", 0), "clicked": v.get("clicked", 0),
                       "open_rate": round(v.get("opened", 0) / v["sent"] * 100, 1) if v.get("sent") else 0})

    return {
        "cards": [
            card("sends", "Emails sent", len(e_cur), len(e_prev), hint=f"{sent_total} lifetime via campaigns"),
            card("open_rate", "Open rate", round(open_total / sent_total * 100, 1) if sent_total else 0, fmt="pct",
                 hint="Needs provider open-tracking (Resend) for real opens"),
            card("click_rate", "Click rate", round(click_total / sent_total * 100, 1) if sent_total else 0, fmt="pct"),
            card("conversions", "Conversions", len(c_cur), len(c_prev), hint="Form submits + CTA clicks"),
            card("revenue", "Attributed revenue", round(attributed, 2), fmt="usd", hint="Orders with UTM / campaign tags"),
            card("automations", "Live automations", sum(1 for a in autos if a.get("status") == "live"), hint=f"{len(runs)} runs in window"),
        ],
        "series": {"sends": _series(e_cur, days, start, "sent_at"), "conversions": _series(c_cur, days, start),
                   "revenue": _series([o for o in orders if (o.get("created_at") or "") >= s_iso], days, start,
                                      value=lambda o: (o.get("total_cents") or 0) / 100)},
        "utm": [{"source": k, **{kk: round(vv, 2) for kk, vv in v.items()}} for k, v in sorted(utm.items(), key=lambda x: -x[1]["visits"])[:10]],
        "ab_tests": ab[:20],
        "campaigns": [{"name": c.get("name") or c.get("subject"), "status": c.get("status"), "sent_at": c.get("sent_at"),
                       **{k: (c.get("metrics") or {}).get(k, 0) for k in ("sent", "delivered", "failed", "suppressed")}} for c in campaigns[:25]],
    }


async def _bookings(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    rows = await _rows(db, "bookings", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "status": 1, "start_at": 1, "starts_at": 1, "service_name": 1, "price_cents": 1})
    s_iso = _iso(start)
    cur, prev = _split(rows, s_iso)
    upcoming = await db.bookings.count_documents({"org_id": org_id, "status": "confirmed",
                                                  "$or": [{"start_at": {"$gte": _iso(now)}}, {"starts_at": {"$gte": _iso(now)}}]})
    by_service: Dict[str, int] = defaultdict(int)
    for r in cur:
        by_service[r.get("service_name") or "Other"] += 1
    return {
        "cards": [
            card("bookings", "Bookings", len(cur), len(prev)),
            card("upcoming", "Upcoming confirmed", upcoming),
            card("completed", "Completed", sum(1 for r in cur if r.get("status") == "completed"), sum(1 for r in prev if r.get("status") == "completed")),
            card("cancel_rate", "Cancel / no-show", round(sum(1 for r in cur if r.get("status") in ("cancelled", "no_show")) / len(cur) * 100, 1) if cur else 0, fmt="pct"),
            card("value", "Booked value", round(sum(r.get("price_cents", 0) for r in cur) / 100, 2), round(sum(r.get("price_cents", 0) for r in prev) / 100, 2), fmt="usd"),
        ],
        "series": {"bookings": _series(cur, days, start)},
        "breakdown": [{"label": k, "value": v} for k, v in sorted(by_service.items(), key=lambda x: -x[1])[:8]],
    }


async def _inbox(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    convs = await _rows(db, "conversations", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "status": 1, "channel": 1, "unread": 1, "first_response_at": 1})
    msgs = await _rows(db, "messages", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "direction": 1, "channel": 1})
    s_iso = _iso(start)
    c_cur, c_prev = _split(convs, s_iso)
    m_cur, m_prev = _split(msgs, s_iso)
    open_now = await db.conversations.count_documents({"org_id": org_id, "status": "open"})
    unread = await db.conversations.count_documents({"org_id": org_id, "unread": True})
    by_channel: Dict[str, int] = defaultdict(int)
    for c in c_cur:
        by_channel[c.get("channel") or "email"] += 1
    return {
        "cards": [
            card("conversations", "New conversations", len(c_cur), len(c_prev)),
            card("open", "Open now", open_now),
            card("unread", "Unread", unread),
            card("inbound", "Inbound messages", sum(1 for m in m_cur if m.get("direction") == "inbound"), sum(1 for m in m_prev if m.get("direction") == "inbound")),
            card("outbound", "Replies sent", sum(1 for m in m_cur if m.get("direction") == "outbound"), sum(1 for m in m_prev if m.get("direction") == "outbound")),
        ],
        "series": {"messages": _series(m_cur, days, start)},
        "breakdown": [{"label": k, "value": v} for k, v in by_channel.items()],
    }


async def _payments(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    payments = await _rows(db, "payments", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "status": 1, "amount_cents": 1, "provider": 1})
    orders = await _rows(db, "store_orders", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "status": 1, "total_cents": 1})
    s_iso = _iso(start)
    p_cur, p_prev = _split(payments, s_iso)
    paid_cur = [p for p in p_cur if p.get("status") == "paid"]
    paid_prev = [p for p in p_prev if p.get("status") == "paid"]
    o_cur = [o for o in orders if (o.get("created_at") or "") >= s_iso and o.get("status") in ("paid", "fulfilled", "completed")]
    overdue = await db.invoices.count_documents({"org_id": org_id, "status": "overdue"})
    outstanding = 0
    async for i in db.invoices.find({"org_id": org_id, "status": {"$in": ["sent", "partial", "overdue"]}}, {"total_cents": 1}):
        outstanding += i.get("total_cents", 0)
    rev_cur = sum(p.get("amount_cents", 0) for p in paid_cur) / 100 + sum(o.get("total_cents", 0) for o in o_cur) / 100
    rev_prev = sum(p.get("amount_cents", 0) for p in paid_prev) / 100
    by_provider: Dict[str, float] = defaultdict(float)
    for p in paid_cur:
        by_provider[p.get("provider") or "simulated"] += p.get("amount_cents", 0) / 100
    return {
        "cards": [
            card("revenue", "Revenue collected", round(rev_cur, 2), round(rev_prev, 2), fmt="usd", hint="Paid invoices + store orders"),
            card("payments", "Payments", len(paid_cur), len(paid_prev)),
            card("outstanding", "Outstanding", round(outstanding / 100, 2), fmt="usd"),
            card("overdue", "Overdue invoices", overdue),
            card("avg", "Avg payment", round(rev_cur / len(paid_cur), 2) if paid_cur else 0, fmt="usd"),
        ],
        "series": {"revenue": _series(paid_cur + o_cur, days, start, value=lambda r: (r.get("amount_cents") or r.get("total_cents") or 0) / 100)},
        "breakdown": [{"label": k, "value": round(v, 2)} for k, v in by_provider.items()],
    }


async def _crm(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    contacts = await _rows(db, "contacts", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "source": 1, "score": 1})
    deals = [d async for d in db.deals.find({"org_id": org_id}, {"_id": 0, "created_at": 1, "stage_id": 1, "value": 1, "won": 1, "status": 1})]
    s_iso = _iso(start)
    c_cur, c_prev = _split(contacts, s_iso)
    total = await db.contacts.count_documents({"org_id": org_id})
    open_deals = [d for d in deals if d.get("status") not in ("won", "lost")]
    won = [d for d in deals if d.get("status") == "won" or d.get("won")]
    by_source: Dict[str, int] = defaultdict(int)
    for c in c_cur:
        by_source[c.get("source") or "manual"] += 1
    return {
        "cards": [
            card("contacts", "Total contacts", total),
            card("new", "New contacts", len(c_cur), len(c_prev)),
            card("pipeline", "Open pipeline", round(sum(float(d.get("value") or 0) for d in open_deals), 2), fmt="usd", hint=f"{len(open_deals)} open deals"),
            card("won", "Won value", round(sum(float(d.get("value") or 0) for d in won), 2), fmt="usd", hint=f"{len(won)} won"),
            card("win_rate", "Win rate", round(len(won) / len(deals) * 100, 1) if deals else 0, fmt="pct"),
        ],
        "series": {"contacts": _series(c_cur, days, start)},
        "breakdown": [{"label": k, "value": v} for k, v in sorted(by_source.items(), key=lambda x: -x[1])[:8]],
    }


async def _ai(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    convs = await _rows(db, "chat_conversations", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "status": 1, "outcome": 1, "agent_id": 1, "handoff": 1})
    inter = await _rows(db, "agent_interactions", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "agent_id": 1, "tokens": 1})
    calls = await _rows(db, "call_records", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "duration_min": 1, "outcome": 1})
    agents = await db.agents.count_documents({"org_id": org_id})
    s_iso = _iso(start)
    c_cur, c_prev = _split(convs, s_iso)
    i_cur, _ = _split(inter, s_iso)
    k_cur, k_prev = _split(calls, s_iso)
    resolved = sum(1 for c in c_cur if c.get("status") in ("resolved", "closed") and not c.get("handoff"))
    by_agent: Dict[str, int] = defaultdict(int)
    for c in c_cur:
        by_agent[str(c.get("agent_id") or "default")[-6:]] += 1
    return {
        "cards": [
            card("agents", "AI employees", agents),
            card("conversations", "AI conversations", len(c_cur), len(c_prev)),
            card("resolved", "Resolved without handoff", round(resolved / len(c_cur) * 100, 1) if c_cur else 0, fmt="pct"),
            card("interactions", "Messages handled", len(i_cur)),
            card("calls", "Voice calls", len(k_cur), len(k_prev), hint=f"{round(sum(float(k.get('duration_min') or 0) for k in k_cur), 1)} min"),
        ],
        "series": {"conversations": _series(c_cur, days, start)},
        "breakdown": [{"label": f"Agent …{k}", "value": v} for k, v in by_agent.items()][:8],
    }


async def _store(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    orders = await _rows(db, "store_orders", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "status": 1, "total_cents": 1, "items": 1})
    s_iso = _iso(start)
    o_cur, o_prev = _split(orders, s_iso)
    paid = lambda o: o.get("status") in ("paid", "fulfilled", "completed")  # noqa: E731
    rev_cur = sum(o.get("total_cents", 0) for o in o_cur if paid(o)) / 100
    rev_prev = sum(o.get("total_cents", 0) for o in o_prev if paid(o)) / 100
    products = await db.store_products.count_documents({"org_id": org_id})
    top: Dict[str, int] = defaultdict(int)
    for o in o_cur:
        for it in (o.get("items") or []):
            top[it.get("name") or it.get("title") or "Item"] += int(it.get("qty") or it.get("quantity") or 1)
    return {
        "cards": [
            card("revenue", "Store revenue", round(rev_cur, 2), round(rev_prev, 2), fmt="usd"),
            card("orders", "Orders", len(o_cur), len(o_prev)),
            card("aov", "Avg order", round(rev_cur / max(1, sum(1 for o in o_cur if paid(o))), 2), fmt="usd"),
            card("products", "Products", products),
            card("refunded", "Refunded", sum(1 for o in o_cur if o.get("status") == "refunded")),
        ],
        "series": {"revenue": _series([o for o in o_cur if paid(o)], days, start, value=lambda o: (o.get("total_cents") or 0) / 100)},
        "breakdown": [{"label": k, "value": v} for k, v in sorted(top.items(), key=lambda x: -x[1])[:8]],
    }


async def _website(db, org_id: str, days: int) -> Dict[str, Any]:
    now, start, prev_start = _window(days)
    events = await _rows(db, "analytics_events", org_id, _iso(prev_start), proj={"_id": 0, "created_at": 1, "kind": 1, "page_slug": 1, "referrer": 1})
    s_iso = _iso(start)
    e_cur, e_prev = _split(events, s_iso)
    pv_cur = [e for e in e_cur if e.get("kind") == "pageview"]
    pv_prev = [e for e in e_prev if e.get("kind") == "pageview"]
    forms_cur = sum(1 for e in e_cur if e.get("kind") == "form_submit")
    pages: Dict[str, int] = defaultdict(int)
    for e in pv_cur:
        pages[e.get("page_slug") or "home"] += 1
    sites = await db.websites.count_documents({"org_id": org_id})
    return {
        "cards": [
            card("views", "Page views", len(pv_cur), len(pv_prev)),
            card("forms", "Form submissions", forms_cur, sum(1 for e in e_prev if e.get("kind") == "form_submit")),
            card("cta", "CTA clicks", sum(1 for e in e_cur if e.get("kind") == "cta_click")),
            card("conv", "Visit → lead", round(forms_cur / len(pv_cur) * 100, 1) if pv_cur else 0, fmt="pct"),
            card("sites", "Websites", sites),
        ],
        "series": {"views": _series(pv_cur, days, start)},
        "breakdown": [{"label": k, "value": v} for k, v in sorted(pages.items(), key=lambda x: -x[1])[:8]],
    }


BUILDERS = {"marketing": _marketing, "bookings": _bookings, "inbox": _inbox, "payments": _payments,
            "crm": _crm, "ai": _ai, "store": _store, "website": _website}


@router.get("/overview")
async def overview(days: int = Query(30, ge=7, le=365), user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    out: Dict[str, Any] = {"days": days, "areas": {}}
    for k in ("website", "payments", "crm", "inbox", "bookings", "store", "marketing", "ai"):
        try:
            data = await BUILDERS[k](db, org_id, days)
            out["areas"][k] = {"cards": data["cards"][:3], "series": next(iter(data["series"].values()), [])}
        except Exception as e:  # noqa: BLE001
            out["areas"][k] = {"cards": [], "series": [], "error": str(e)}
    return out


@router.get("/{area}")
async def area_insights(area: str, days: int = Query(30, ge=7, le=365),
                        user: User = Depends(current_user), org_id: str = Depends(require_org)):
    if area not in BUILDERS:
        raise HTTPException(404, f"Unknown area. Choose one of {sorted(BUILDERS)}")
    return {"area": area, "days": days, **(await BUILDERS[area](get_db(), org_id, days))}
