import React, { useEffect, useState, useCallback } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import {
    Phone, Plus, Globe2, Bot, Trash2, PhoneForwarded, MessageSquare,
    PlayCircle, Check, Languages, Sparkles, ShoppingCart,
} from "lucide-react";

const card = "rounded-2xl border border-brand-line bg-white p-5 shadow-sm";

function Toast({ msg, onClose }) {
    useEffect(() => { if (msg) { const t = setTimeout(onClose, 3200); return () => clearTimeout(t); } }, [msg, onClose]);
    if (!msg) return null;
    return <div className="fixed bottom-6 right-6 z-50 rounded-xl bg-brand-ink text-white px-4 py-3 shadow-xl text-sm">{msg}</div>;
}

export default function Numbers() {
    const [settings, setSettings] = useState(null);
    const [owned, setOwned] = useState([]);
    const [allot, setAllot] = useState(null);
    const [toast, setToast] = useState("");
    const [buyOpen, setBuyOpen] = useState(false);
    const [manage, setManage] = useState(null); // number being configured

    const load = useCallback(async () => {
        try {
            const [s, list] = await Promise.all([api.get("/numbers/settings"), api.get("/numbers")]);
            setSettings(s.data);
            setOwned(list.data.numbers || []);
            setAllot(list.data.allotment);
        } catch { setToast("Could not load numbers"); }
    }, []);
    useEffect(() => { load(); }, [load]);

    if (!settings) return <div className="p-8 text-brand-ink/50">Loading numbers…</div>;

    const carrier = settings.carrier;
    const modeBadge = carrier.mode === "live"
        ? <span className="text-[11px] px-2 py-1 rounded-full bg-emerald-100 text-emerald-700">Live · {carrier.provider}</span>
        : <span className="text-[11px] px-2 py-1 rounded-full bg-amber-100 text-amber-700">Simulated — connect a carrier to go live</span>;

    return (
        <div className="max-w-5xl mx-auto p-6 space-y-6">
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <h1 className="font-display text-2xl text-brand-ink flex items-center gap-2"><Phone className="w-6 h-6 text-brand-copper" /> Phone numbers & AI voice</h1>
                    <p className="text-brand-ink/60 mt-1 text-sm">Buy business numbers, point them at your AI receptionist, and control exactly how it talks — in any language.</p>
                </div>
                <div className="flex items-center gap-2">{modeBadge}
                    <Button onClick={() => setBuyOpen(true)} className="bg-brand-copper hover:bg-brand-copperHover text-white"><Plus className="w-4 h-4 mr-1" /> Buy a number</Button>
                </div>
            </div>

            {/* Allotment banner */}
            {allot && (
                <div className={`${card} flex flex-wrap items-center gap-x-8 gap-y-3`}>
                    <Stat label="Numbers owned" value={allot.owned} />
                    <Stat label="Free with your plan" value={allot.free_included} sub={`${allot.free_used} used`} />
                    <Stat label="Extra (paid)" value={allot.extra_count} />
                    <Stat label="Monthly number cost" value={`$${allot.monthly_extra_cost.toFixed(2)}`} sub={`then $${allot.retail_number_month}/mo each`} />
                    <div className="ml-auto text-xs text-brand-ink/50 max-w-xs">Each plan includes free numbers. Extra numbers bill monthly. Metered: ${settings.metered.voice_min}/AI voice min · ${settings.metered.sms}/SMS.</div>
                </div>
            )}

            {/* Owned numbers */}
            {owned.length === 0 ? (
                <div className={`${card} text-center py-12`}>
                    <Phone className="w-10 h-10 text-brand-ink/20 mx-auto mb-3" />
                    <div className="font-medium text-brand-ink">No numbers yet</div>
                    <p className="text-brand-ink/50 text-sm mt-1">Buy your first number and your AI receptionist can start answering calls & texts.</p>
                    <Button onClick={() => setBuyOpen(true)} className="mt-4 bg-brand-copper hover:bg-brand-copperHover text-white"><Plus className="w-4 h-4 mr-1" /> Buy a number</Button>
                </div>
            ) : (
                <div className="grid gap-3">
                    {owned.map((n) => (
                        <div key={n.id} className={`${card} flex items-center gap-4 flex-wrap`}>
                            <div className="w-11 h-11 rounded-xl bg-brand-copper/10 text-brand-copper flex items-center justify-center"><Phone className="w-5 h-5" /></div>
                            <div className="min-w-0">
                                <div className="font-display text-lg text-brand-ink">{n.number}</div>
                                <div className="text-xs text-brand-ink/50 flex items-center gap-2 flex-wrap">
                                    <span>{n.country} · {n.kind}</span>
                                    {n.is_free_allotment ? <span className="text-emerald-600">Free with plan</span> : <span>${n.monthly_price}/mo</span>}
                                    <span className="inline-flex items-center gap-1"><Languages className="w-3 h-3" /> {settings.languages.find(l => l.code === (n.voice_config?.language))?.name || "English"}</span>
                                    {n.voice_config?.enabled ? <span className="inline-flex items-center gap-1 text-emerald-600"><Bot className="w-3 h-3" /> AI on</span> : <span className="text-brand-ink/40">AI off</span>}
                                </div>
                            </div>
                            <div className="ml-auto flex items-center gap-2">
                                <Button variant="outline" size="sm" onClick={() => setManage(n)}><Bot className="w-4 h-4 mr-1" /> Voice settings</Button>
                                <Button variant="ghost" size="sm" onClick={async () => { if (window.confirm("Release this number?")) { await api.delete(`/numbers/${n.id}`); setToast("Number released"); load(); } }}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {buyOpen && <BuyModal settings={settings} onClose={() => setBuyOpen(false)} onBought={() => { setBuyOpen(false); setToast("Number purchased — ownership assigned to your account"); load(); }} />}
            {manage && <VoiceModal number={manage} settings={settings} onClose={() => setManage(null)} onSaved={() => { setManage(null); setToast("Voice settings saved"); load(); }} setToast={setToast} />}
            <Toast msg={toast} onClose={() => setToast("")} />
        </div>
    );
}

function Stat({ label, value, sub }) {
    return (
        <div>
            <div className="text-xs uppercase tracking-wide text-brand-ink/40">{label}</div>
            <div className="font-display text-xl text-brand-ink">{value}</div>
            {sub && <div className="text-[11px] text-brand-ink/40">{sub}</div>}
        </div>
    );
}

function BuyModal({ settings, onClose, onBought }) {
    const [country, setCountry] = useState("US");
    const [kind, setKind] = useState("local");
    const [list, setList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [buying, setBuying] = useState("");

    const search = useCallback(async () => {
        setLoading(true);
        try { const { data } = await api.get(`/numbers/marketplace?country=${country}&kind=${kind}`); setList(data.numbers || []); }
        finally { setLoading(false); }
    }, [country, kind]);
    useEffect(() => { search(); }, [search]);

    const buy = async (n) => {
        setBuying(n.catalog_id);
        try { await api.post("/numbers/buy", { number: n.number, country, kind, catalog_id: n.catalog_id }); onBought(); }
        catch { setBuying(""); }
    };

    return (
        <Modal onClose={onClose} title="Buy a phone number" wide>
            <div className="flex gap-3 flex-wrap mb-4">
                <label className="text-sm">
                    <div className="text-xs text-brand-ink/50 mb-1 flex items-center gap-1"><Globe2 className="w-3 h-3" /> Country</div>
                    <select value={country} onChange={(e) => setCountry(e.target.value)} className="border border-brand-line rounded-lg px-3 py-2 min-w-[200px]">
                        {settings.countries.map((c) => <option key={c.code} value={c.code}>{c.flag} {c.name} ({c.dial})</option>)}
                    </select>
                </label>
                <label className="text-sm">
                    <div className="text-xs text-brand-ink/50 mb-1">Type</div>
                    <select value={kind} onChange={(e) => setKind(e.target.value)} className="border border-brand-line rounded-lg px-3 py-2">
                        <option value="local">Local</option>
                        <option value="tollfree">Toll-free</option>
                    </select>
                </label>
            </div>
            {loading ? <div className="py-10 text-center text-brand-ink/40">Finding numbers…</div> : (
                <div className="grid gap-2 max-h-[46vh] overflow-auto">
                    {list.length === 0 && <div className="text-brand-ink/40 text-sm py-6 text-center">No numbers available for that selection.</div>}
                    {list.map((n) => (
                        <div key={n.catalog_id} className="flex items-center gap-3 border border-brand-line rounded-xl px-4 py-3">
                            <Phone className="w-4 h-4 text-brand-copper" />
                            <div className="font-medium text-brand-ink">{n.number}</div>
                            <div className="text-xs text-brand-ink/40">{n.capabilities.join(" · ")}</div>
                            <div className="ml-auto flex items-center gap-3">
                                <span className="text-sm text-brand-ink/60">${n.monthly_price}/mo</span>
                                <Button size="sm" disabled={!!buying} onClick={() => buy(n)} className="bg-brand-copper hover:bg-brand-copperHover text-white">
                                    {buying === n.catalog_id ? "Buying…" : <><ShoppingCart className="w-4 h-4 mr-1" /> Buy</>}
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
            <p className="text-xs text-brand-ink/40 mt-3">Numbers bought here are instantly provisioned and assigned to your account. First number(s) may be free with your plan.</p>
        </Modal>
    );
}

function VoiceModal({ number, settings, onClose, onSaved, setToast }) {
    const [vc, setVc] = useState(() => ({ ...number.voice_config }));
    const [saving, setSaving] = useState(false);
    const [test, setTest] = useState(null);
    const set = (k, v) => setVc((p) => ({ ...p, [k]: v }));
    const setNested = (grp, k, v) => setVc((p) => ({ ...p, [grp]: { ...(p[grp] || {}), [k]: v } }));

    const save = async () => {
        setSaving(true);
        try { await api.put(`/numbers/${number.id}/voice`, vc); onSaved(); }
        catch { setSaving(false); }
    };
    const runTest = async () => {
        try { const { data } = await api.post(`/numbers/${number.id}/test-call`, { message: "Do you have a slot Thursday?" }); setTest(data); }
        catch { setToast && setToast("Test failed"); }
    };

    const input = "w-full border border-brand-line rounded-lg px-3 py-2 text-sm";
    return (
        <Modal onClose={onClose} title={`Voice settings · ${number.number}`} wide>
            <div className="grid md:grid-cols-2 gap-5">
                <Field label="AI receptionist"><Toggle checked={vc.enabled} onChange={(v) => set("enabled", v)} label={vc.enabled ? "Answering calls & texts" : "Off"} /></Field>
                <Field label="Voice & persona">
                    <select className={input} value={vc.persona} onChange={(e) => set("persona", e.target.value)}>
                        {settings.personas.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
                    </select>
                </Field>
                <Field label={<span className="flex items-center gap-1"><Languages className="w-3.5 h-3.5" /> Spoken language</span>}>
                    <select className={input} value={vc.language} onChange={(e) => set("language", e.target.value)}>
                        {settings.languages.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
                    </select>
                    <p className="text-[11px] text-brand-ink/40 mt-1">The AI greets & answers callers in this language.</p>
                </Field>
                <Field label="Speaking style">
                    <input className={input} value={vc.speaking_style} onChange={(e) => set("speaking_style", e.target.value)} />
                </Field>
                <Field label="Greeting" full>
                    <input className={input} value={vc.greeting} onChange={(e) => set("greeting", e.target.value)} />
                </Field>
                <Field label="Voicemail message" full>
                    <input className={input} value={vc.messages?.voicemail || ""} onChange={(e) => setNested("messages", "voicemail", e.target.value)} />
                </Field>
                <Field label="After-hours message" full>
                    <input className={input} value={vc.messages?.after_hours || ""} onChange={(e) => setNested("messages", "after_hours", e.target.value)} />
                </Field>
                <Field label={<span className="flex items-center gap-1"><PhoneForwarded className="w-3.5 h-3.5" /> Call forwarding</span>}>
                    <Toggle checked={vc.forwarding?.enabled} onChange={(v) => setNested("forwarding", "enabled", v)} label={vc.forwarding?.enabled ? "On" : "Off"} />
                    {vc.forwarding?.enabled && <input className={`${input} mt-2`} placeholder="Forward to +1…" value={vc.forwarding?.forward_to || ""} onChange={(e) => setNested("forwarding", "forward_to", e.target.value)} />}
                </Field>
                <Field label={<span className="flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5" /> SMS auto-reply</span>}>
                    <Toggle checked={vc.sms_auto_reply?.enabled} onChange={(v) => setNested("sms_auto_reply", "enabled", v)} label={vc.sms_auto_reply?.enabled ? "On" : "Off"} />
                    {vc.sms_auto_reply?.enabled && <input className={`${input} mt-2`} value={vc.sms_auto_reply?.message || ""} onChange={(e) => setNested("sms_auto_reply", "message", e.target.value)} />}
                </Field>
                <Field label="Record calls"><Toggle checked={vc.record_calls} onChange={(v) => set("record_calls", v)} label={vc.record_calls ? "Recording on" : "Off"} /></Field>
            </div>

            <div className="mt-5 rounded-xl bg-brand-cream/50 border border-brand-line p-4">
                <div className="flex items-center justify-between">
                    <div className="text-sm font-medium text-brand-ink flex items-center gap-1"><Sparkles className="w-4 h-4 text-brand-copper" /> Preview a call</div>
                    <Button size="sm" variant="outline" onClick={runTest}><PlayCircle className="w-4 h-4 mr-1" /> Run test</Button>
                </div>
                {test && (
                    <div className="mt-3 space-y-2">
                        {test.transcript.map((t, i) => (
                            <div key={i} className={`max-w-[85%] text-sm rounded-xl px-3 py-2 ${t.role === "caller" ? "ml-auto bg-brand-copper text-white" : "bg-white border border-brand-line text-brand-ink"}`}>{t.text}</div>
                        ))}
                        <div className="text-[11px] text-brand-ink/40">Language: {test.language_name} · mode: {test.mode}</div>
                    </div>
                )}
            </div>

            <div className="flex justify-end gap-2 mt-5">
                <Button variant="ghost" onClick={onClose}>Cancel</Button>
                <Button onClick={save} disabled={saving} className="bg-brand-copper hover:bg-brand-copperHover text-white">{saving ? "Saving…" : <><Check className="w-4 h-4 mr-1" /> Save</>}</Button>
            </div>
        </Modal>
    );
}

function Field({ label, children, full }) {
    return (
        <div className={full ? "md:col-span-2" : ""}>
            <div className="text-xs font-medium text-brand-ink/60 mb-1.5">{label}</div>
            {children}
        </div>
    );
}

function Toggle({ checked, onChange, label }) {
    return (
        <button type="button" onClick={() => onChange(!checked)} className="flex items-center gap-2">
            <span className={`w-10 h-6 rounded-full transition-colors relative ${checked ? "bg-brand-copper" : "bg-brand-line"}`}>
                <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all ${checked ? "left-[18px]" : "left-0.5"}`} />
            </span>
            <span className="text-sm text-brand-ink/70">{label}</span>
        </button>
    );
}

function Modal({ title, children, onClose, wide }) {
    return (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
            <div className={`bg-white rounded-2xl shadow-2xl w-full ${wide ? "max-w-2xl" : "max-w-md"} max-h-[90vh] overflow-auto`} onClick={(e) => e.stopPropagation()}>
                <div className="flex items-center justify-between px-6 py-4 border-b border-brand-line sticky top-0 bg-white">
                    <div className="font-display text-lg text-brand-ink">{title}</div>
                    <button onClick={onClose} className="text-brand-ink/40 hover:text-brand-ink text-xl leading-none">×</button>
                </div>
                <div className="p-6">{children}</div>
            </div>
        </div>
    );
}
