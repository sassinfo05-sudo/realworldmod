"""Media (uploads), forms (submissions), analytics (track + summary)."""
import base64
import mimetypes
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import AnalyticsEvent, FormSubmission, MediaAsset, User

router = APIRouter()

# -------- Media ----------
media_router = APIRouter(prefix="/media", tags=["media"])

# Accept base64 payloads in Phase 2 (Object Storage arrives in Phase 6 payments/receipts phase)
_MAX_MEDIA_BYTES = 4 * 1024 * 1024  # 4 MB
_ALLOWED_MIME = {"image/png", "image/jpeg", "image/webp", "image/gif", "image/svg+xml"}


def _sniff_image_mime(raw: bytes) -> Optional[str]:
    """Detect image type from magic bytes (content), not the declared mime/filename."""
    if len(raw) < 12:
        return None
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if raw[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if raw[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "image/webp"
    head = raw[:512].lstrip().lower()
    if head.startswith(b"<?xml") or head.startswith(b"<svg") or b"<svg" in head:
        return "image/svg+xml"
    return None


class MediaUpload(BaseModel):
    filename: str
    mime: str
    data_base64: str  # data content only (no data URI prefix)
    alt_text: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None


@media_router.post("/upload")
async def upload_media(req: MediaUpload, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    if req.mime not in _ALLOWED_MIME:
        raise HTTPException(415, f"Unsupported mime type: {req.mime}")
    try:
        raw = base64.b64decode(req.data_base64, validate=True)
    except Exception:
        raise HTTPException(400, "Invalid base64 data")
    if len(raw) > _MAX_MEDIA_BYTES:
        raise HTTPException(413, f"Media exceeds {_MAX_MEDIA_BYTES // 1024}KB limit")
    # Validate the ACTUAL bytes match the claimed type (never trust the mime string / filename).
    sniffed = _sniff_image_mime(raw)
    if sniffed != req.mime:
        raise HTTPException(415, f"File content does not match declared type {req.mime!r} "
                                 f"(detected {sniffed or 'unknown'}).")
    data_base64 = req.data_base64
    # Sanitize SVG server-side before it is ever stored/rendered.
    if req.mime == "image/svg+xml":
        from ..services.svg_safe import sanitize_svg
        clean = sanitize_svg(raw.decode("utf-8", errors="ignore"))
        if not clean:
            raise HTTPException(400, "SVG failed sanitisation (no safe SVG content).")
        raw = clean.encode("utf-8")
        data_base64 = base64.b64encode(raw).decode("ascii")
    ext = mimetypes.guess_extension(req.mime) or ""
    # Store inline as data URL (small assets only for Phase 2)
    data_url = f"data:{req.mime};base64,{data_base64}"
    db = get_db()
    asset = MediaAsset(
        org_id=org_id,
        filename=req.filename or f"asset{ext}",
        mime=req.mime,
        size_bytes=len(raw),
        url=data_url,
        alt_text=req.alt_text,
        width=req.width,
        height=req.height,
        uploaded_by_user_id=user.id,
    )
    res = await db.media.insert_one(asset.to_mongo())
    asset.id = str(res.inserted_id)
    return asset.model_dump()


# ---------------------------------------------------------------- chunked uploads (Round 11)
# Large files bypass proxy body limits by arriving in ≤512 KB base64 chunks. Chunks are staged on disk under
# UPLOAD_DIR/chunks/<upload_id>/ and assembled on `complete`, which then runs the SAME validation path as the
# single-shot upload (mime allow-list, byte sniffing, SVG sanitisation, size cap).
import os as _os
import shutil as _shutil

_UPLOAD_DIR = _os.environ.get("UPLOAD_DIR", "/app/backend/uploads")
_CHUNK_MAX_BYTES = 512 * 1024
_CHUNKED_MAX_TOTAL = 25 * 1024 * 1024   # 25 MB total (images are still capped by _MAX_MEDIA_BYTES on complete)
_CHUNK_TTL_MIN = 60


class ChunkInit(BaseModel):
    filename: str = Field(min_length=1, max_length=200)
    mime: str
    total_bytes: int = Field(gt=0)
    alt_text: Optional[str] = None


class ChunkPart(BaseModel):
    index: int = Field(ge=0, le=4096)
    data_base64: str


def _chunk_dir(upload_id: str) -> str:
    return _os.path.join(_UPLOAD_DIR, "chunks", upload_id)


@media_router.post("/upload/init")
async def chunk_init(req: ChunkInit, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    if req.mime not in _ALLOWED_MIME:
        raise HTTPException(415, f"Unsupported mime type: {req.mime}")
    if req.total_bytes > _CHUNKED_MAX_TOTAL:
        raise HTTPException(413, f"File exceeds {_CHUNKED_MAX_TOTAL // (1024 * 1024)} MB")
    upload_id = uuid.uuid4().hex
    _os.makedirs(_chunk_dir(upload_id), exist_ok=True)
    await get_db().media_uploads.insert_one({"_id": upload_id, "org_id": org_id, "user_id": user.id, "filename": req.filename,
                                             "mime": req.mime, "total_bytes": req.total_bytes, "alt_text": req.alt_text,
                                             "received": [], "status": "uploading", "created_at": utc_now_iso()})
    return {"upload_id": upload_id, "chunk_bytes": _CHUNK_MAX_BYTES,
            "chunks": (req.total_bytes + _CHUNK_MAX_BYTES - 1) // _CHUNK_MAX_BYTES}


@media_router.post("/upload/{upload_id}/chunk")
async def chunk_part(upload_id: str, req: ChunkPart, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    up = await db.media_uploads.find_one({"_id": upload_id, "org_id": org_id, "status": "uploading"})
    if not up:
        raise HTTPException(404, "Upload not found or already completed")
    try:
        raw = base64.b64decode(req.data_base64, validate=True)
    except Exception:  # noqa: BLE001
        raise HTTPException(400, "Invalid base64 chunk")
    if len(raw) > _CHUNK_MAX_BYTES:
        raise HTTPException(413, f"Chunk exceeds {_CHUNK_MAX_BYTES // 1024} KB")
    d = _chunk_dir(upload_id)
    _os.makedirs(d, exist_ok=True)
    with open(_os.path.join(d, f"{req.index:05d}.part"), "wb") as f:
        f.write(raw)
    await db.media_uploads.update_one({"_id": upload_id}, {"$addToSet": {"received": req.index}})
    return {"ok": True, "index": req.index}


@media_router.post("/upload/{upload_id}/complete")
async def chunk_complete(upload_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    up = await db.media_uploads.find_one({"_id": upload_id, "org_id": org_id, "status": "uploading"})
    if not up:
        raise HTTPException(404, "Upload not found or already completed")
    d = _chunk_dir(upload_id)
    parts = sorted(p for p in _os.listdir(d) if p.endswith(".part")) if _os.path.isdir(d) else []
    expected = (int(up["total_bytes"]) + _CHUNK_MAX_BYTES - 1) // _CHUNK_MAX_BYTES
    if len(parts) != expected:
        raise HTTPException(400, {"error": "chunks_missing", "received": len(parts), "expected": expected})
    raw = b"".join(open(_os.path.join(d, p), "rb").read() for p in parts)
    _shutil.rmtree(d, ignore_errors=True)
    if len(raw) != int(up["total_bytes"]):
        await db.media_uploads.update_one({"_id": upload_id}, {"$set": {"status": "failed", "error": "size_mismatch"}})
        raise HTTPException(400, "Assembled size does not match total_bytes")
    # Re-use the single-shot validation path (mime sniff, SVG sanitise, size cap).
    try:
        asset = await upload_media(MediaUpload(filename=up["filename"], mime=up["mime"],
                                               data_base64=base64.b64encode(raw).decode("ascii"), alt_text=up.get("alt_text")),
                                   user=user, org_id=org_id)
    except HTTPException as e:
        await db.media_uploads.update_one({"_id": upload_id}, {"$set": {"status": "failed", "error": str(e.detail)[:200]}})
        raise
    await db.media_uploads.update_one({"_id": upload_id}, {"$set": {"status": "completed", "asset_id": asset.get("id"),
                                                                    "completed_at": utc_now_iso()}})
    return asset


@media_router.delete("/upload/{upload_id}")
async def chunk_abort(upload_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.media_uploads.update_one({"_id": upload_id, "org_id": org_id}, {"$set": {"status": "aborted"}})
    _shutil.rmtree(_chunk_dir(upload_id), ignore_errors=True)
    return {"ok": bool(r.matched_count)}


@media_router.get("")
async def list_media(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.media.find({"org_id": org_id}).sort("created_at", -1).limit(200)
    out = []
    async for d in cursor:
        out.append(MediaAsset.from_mongo(d).model_dump())
    return {"assets": out}


@media_router.delete("/{asset_id}")
async def delete_media(asset_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    res = await db.media.delete_one({"_id": ObjectId(asset_id), "org_id": org_id})
    if res.deleted_count == 0:
        raise HTTPException(404, "Asset not found")
    return {"ok": True}


# -------- Forms ----------
forms_router = APIRouter(prefix="/forms", tags=["forms"])


class FormSubmit(BaseModel):
    website_slug: str
    page_slug: str
    block_id: Optional[str] = None
    fields: Dict[str, Any] = Field(default_factory=dict)
    attribution: Dict[str, Any] = Field(default_factory=dict)  # Round 11: UTM / click-id first-touch (allow-listed server-side)
    collection_id: Optional[str] = None                        # CMS: controlled create-only mapping
    collection_map: Dict[str, str] = Field(default_factory=dict)  # form field -> collection field key


@forms_router.post("/submit")
async def submit_form(req: FormSubmit, request: Request):
    """PUBLIC: form submissions from the live site.

    Side effects (all synchronous, on the caller path — the visitor waits for them
    so we can return one honest response):
    - Insert FormSubmission doc.
    - Insert analytics event.
    - Upsert a Contact from the fields and open a new email-channel Conversation.
    - Record a `form_submitted` interaction on the contact timeline.
    - Fire an owner-alert email via the org's email provider (silent no-op if the
      org has no provider config or no owner email — never blocks the visitor).
    """
    db = get_db()
    site = await db.websites.find_one({"slug": req.website_slug.lower(), "status": "published"})
    if not site:
        raise HTTPException(404, "Site not found")
    org_id = site["org_id"]
    sub = FormSubmission(
        org_id=org_id, website_id=str(site["_id"]),
        page_slug=req.page_slug, block_id=req.block_id, fields=req.fields,
        visitor_ip=(request.client.host if request.client else None),
        user_agent=request.headers.get("user-agent"),
    )
    res = await db.form_submissions.insert_one(sub.to_mongo())
    sub.id = str(res.inserted_id)
    # analytics event
    from ..services import attribution as _attr
    attr = _attr.clean_attribution(req.attribution)
    ev = AnalyticsEvent(
        org_id=org_id, website_id=str(site["_id"]),
        kind="form_submit", page_slug=req.page_slug,
        referrer=request.headers.get("referer"),
        user_agent=request.headers.get("user-agent"),
        meta={"submission_id": sub.id, "attribution": attr, "channel": _attr.channel_of(attr)},
    )
    await db.analytics_events.insert_one(ev.to_mongo())
    if attr:
        await db.form_submissions.update_one({"_id": res.inserted_id}, {"$set": {"attribution": attr}})
    # Round 11 — outbound webhooks (`form.submitted`) now fire from the in-app form path too (fire-and-forget).
    try:
        import asyncio as _asyncio
        from ..services.webhooks import dispatch_event as _dispatch
        _asyncio.create_task(_dispatch(org_id, "form.submitted", {"submission_id": sub.id, "page_slug": req.page_slug,
                                                                  "fields": req.fields, "attribution": attr}))
    except Exception:  # noqa: BLE001
        pass
    # CMS: controlled create-only write to a custom collection (org resolved from the site).
    cms_item_id = None
    if req.collection_id:
        try:
            from ..services import cms as _cms
            values = {}
            for form_key, field_key in (req.collection_map or {}).items():
                if field_key and form_key in req.fields:
                    values[field_key] = req.fields[form_key]
            if not values:  # fall back to same-named keys
                values = {k: v for k, v in req.fields.items()}
            item = await _cms.create_item(org_id, req.fields.get("_actor") or "public-form",
                                          req.collection_id, values, "published")
            cms_item_id = item["id"]
        except Exception as _e:  # noqa: BLE001 — never break the visitor path or leak plan limits
            import logging as _logging
            _logging.getLogger(__name__).info("form->collection mapping skipped: %s", str(_e)[:160])
    # CRM auto-wiring (import locally to avoid startup circular)
    contact_id = None
    try:
        from .crm import upsert_contact_from_form
        contact_id = await upsert_contact_from_form(
            db, org_id, req.fields, source="form",
            submission_id=sub.id, website_id=str(site["_id"]),
        )
        if contact_id and attr:
            # First-touch only: never overwrite an existing attribution on the contact.
            from bson import ObjectId as _OID
            try:
                await db.contacts.update_one({"_id": _OID(contact_id), "attribution": {"$exists": False}},
                                             {"$set": {"attribution": attr}})
            except Exception:  # noqa: BLE001
                pass
        # Create a conversation on the form channel so it lives in the inbox
        from ..models_crm import Conversation, Message, MessageAddress
        first = (req.fields.get("name") or req.fields.get("Name") or "").strip() or None
        email = (req.fields.get("email") or req.fields.get("Email") or "").strip().lower() or None
        preview = (req.fields.get("message") or req.fields.get("Message")
                    or "Form submission received").strip()
        conv = Conversation(
            org_id=org_id, channel="form", contact_id=contact_id,
            subject=f"Form: {req.page_slug} — {first or email or 'new lead'}",
            status="open", unread=True,
            last_message_at=utc_now_iso(),
            last_message_preview=preview[:160],
        )
        cr = await db.conversations.insert_one(conv.to_mongo())
        conv_id = str(cr.inserted_id)
        # Inline the submission text as an inbound message so the thread UI works
        msg = Message(
            org_id=org_id, conversation_id=conv_id, direction="inbound", channel="form",
            from_addr=MessageAddress(email=email or "no-reply@form.local", name=first),
            subject=conv.subject, body_text=preview,
            sent_at=utc_now_iso(),
            delivery={"provider": "form", "simulated": True, "status": "received"},
        )
        await db.messages.insert_one(msg.to_mongo())

        # Owner alert email — go through the org's provider (simulated by default).
        cfg_doc = await db.email_provider_configs.find_one({"org_id": org_id})
        owner = await db.users.find_one({"org_id": org_id, "role": {"$in": ["owner", "manager"]}})
        if owner and cfg_doc:
            from ..models_crm import EmailProviderConfig
            cfg = EmailProviderConfig.from_mongo(cfg_doc)
            from ..services.email_providers import (
                SendPayload, build_provider_from_config,
            )
            provider = build_provider_from_config(cfg)
            payload = SendPayload(
                from_email=cfg.from_email or "notifications@zanelvo.local",
                from_name=cfg.from_name or "Zanelvo",
                to=[owner["email"]],
                subject=f"New form submission — {first or email or 'lead'}",
                text=f"You have a new form submission on {req.page_slug}.\n\n{preview}\n\n"
                     f"Open in the inbox to review + reply.",
            )
            alert_result = await provider.send(payload)
            await db.messages.insert_one(Message(
                org_id=org_id, conversation_id=conv_id, direction="outbound", channel="internal",
                subject="[system] Owner alerted",
                body_text=f"Owner alert email {'delivered (simulated)' if alert_result.simulated else 'sent'} to {owner['email']}.",
                sent_at=utc_now_iso(),
                delivery={"provider": provider.key, "simulated": bool(alert_result.simulated),
                           "provider_message_id": alert_result.provider_message_id,
                           "status": "delivered" if alert_result.simulated else "sent"},
            ).to_mongo())
    except Exception as e:  # noqa: BLE001
        # Never fail the visitor's request because of CRM/inbox side-effects.
        import logging as _log
        _log.getLogger(__name__).exception("Form submission side-effects failed: %s", e)
    # Fire form_submitted automations (never fails the visitor).
    try:
        from .marketing import fire_trigger
        await fire_trigger(org_id, "form_submitted", {
            "submission_id": sub.id,
            "contact_id": contact_id,
            "email": (req.fields.get("email") or "").lower().strip() or None,
            "name": (req.fields.get("name") or "").strip() or None,
            "message": (req.fields.get("message") or "").strip() or None,
        })
    except Exception:  # noqa: BLE001
        pass
    return {"ok": True, "submission_id": sub.id, "cms_item_id": cms_item_id}


@forms_router.get("/submissions")
async def list_submissions(website_id: Optional[str] = None,
                            user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q = {"org_id": org_id}
    if website_id:
        q["website_id"] = website_id
    cursor = db.form_submissions.find(q).sort("created_at", -1).limit(200)
    out = []
    async for d in cursor:
        out.append(FormSubmission.from_mongo(d).model_dump())
    return {"submissions": out}


@forms_router.post("/submissions/{sub_id}/mark-read")
async def mark_read(sub_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    res = await db.form_submissions.update_one(
        {"_id": ObjectId(sub_id), "org_id": org_id},
        {"$set": {"read_at": utc_now_iso(), "updated_at": utc_now_iso()}},
    )
    if res.matched_count == 0:
        raise HTTPException(404, "Submission not found")
    return {"ok": True}


# -------- Analytics ----------
analytics_router = APIRouter(prefix="/analytics", tags=["analytics"])


class TrackEvent(BaseModel):
    website_slug: str
    kind: str = "pageview"  # pageview | cta_click
    page_slug: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


@analytics_router.post("/track")
async def track(req: TrackEvent, request: Request):
    """PUBLIC: fire-and-forget analytics from the live site."""
    if req.kind not in {"pageview", "cta_click"}:
        raise HTTPException(400, "invalid kind")
    db = get_db()
    site = await db.websites.find_one({"slug": req.website_slug.lower(), "status": "published"},
                                        {"_id": 1, "org_id": 1})
    if not site:
        return {"ok": True}  # silent no-op — never leak site existence via analytics
    from ..services import attribution as _attr
    attr = _attr.clean_attribution((req.meta or {}).get("attribution"))
    safe_meta = {k: v for k, v in (req.meta or {}).items() if k in ("label", "href", "block_id") and isinstance(v, str)}
    safe_meta["attribution"] = attr
    safe_meta["channel"] = _attr.channel_of(attr)
    ev = AnalyticsEvent(
        org_id=site["org_id"],
        website_id=str(site["_id"]),
        kind=req.kind,
        page_slug=req.page_slug,
        referrer=request.headers.get("referer"),
        user_agent=request.headers.get("user-agent"),
        meta=safe_meta,
    )
    await db.analytics_events.insert_one(ev.to_mongo())
    return {"ok": True}


@analytics_router.get("/summary")
async def summary(website_id: Optional[str] = None,
                   user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    q = {"org_id": org_id}
    if website_id:
        q["website_id"] = website_id
    since = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
    q_recent = {**q, "created_at": {"$gte": since}}

    total_pv = await db.analytics_events.count_documents({**q, "kind": "pageview"})
    total_submits = await db.analytics_events.count_documents({**q, "kind": "form_submit"})
    total_clicks = await db.analytics_events.count_documents({**q, "kind": "cta_click"})
    recent_pv = await db.analytics_events.count_documents({**q_recent, "kind": "pageview"})

    # per-page breakdown (top 10)
    pipeline = [
        {"$match": {**q, "kind": "pageview"}},
        {"$group": {"_id": "$page_slug", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 10},
    ]
    by_page = [{"page_slug": r["_id"], "views": r["count"]}
               async for r in db.analytics_events.aggregate(pipeline)]

    return {
        "totals": {"pageviews": total_pv, "form_submits": total_submits, "cta_clicks": total_clicks},
        "last_30_days": {"pageviews": recent_pv},
        "by_page": by_page,
    }


# Aggregate router mount helper
router.include_router(media_router)
router.include_router(forms_router)
router.include_router(analytics_router)
