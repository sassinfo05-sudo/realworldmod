import React, { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Plug, CreditCard, ShoppingCart, Image as ImageIcon, Phone, Save, CheckCircle2, Circle } from "lucide-react";

function StatusBadge({ ok }) {
    return ok ? (
        <span className="inline-flex items-center gap-1 text-xs text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-full px-2 py-0.5"><CheckCircle2 className="w-3.5 h-3.5" /> Connected</span>
    ) : (
        <span className="inline-flex items-center gap-1 text-xs text-zinc-500 bg-zinc-50 border border-brand-line rounded-full px-2 py-0.5"><Circle className="w-3.5 h-3.5" /> Not connected</span>
    );
}

function Text({ label, value, onChange, placeholder, type = "text", testid }) {
    return (
        <div>
            <label className="block text-xs text-zinc-500 mb-1">{label}</label>
            <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
                data-testid={testid}
                className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm text-brand-ink outline-none focus:ring-2 focus:ring-brand-copper/30" />
        </div>
    );
}

function Select({ label, value, onChange, options, testid }) {
    return (
        <div>
            <label className="block text-xs text-zinc-500 mb-1">{label}</label>
            <select value={value} onChange={(e) => onChange(e.target.value)} data-testid={testid}
                className="w-full rounded-lg border border-brand-line bg-white px-3 py-2 text-sm text-brand-ink outline-none focus:ring-2 focus:ring-brand-copper/30">
                {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
            </select>
        </div>
    );
}

function Card({ title, icon: Icon, ok, children, onSave, saving, testid }) {
    return (
        <div className="rounded-2xl border border-brand-line bg-white p-6" data-testid={testid}>
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4 text-brand-copper" />
                    <h2 className="font-display text-lg text-brand-ink">{title}</h2>
                </div>
                <StatusBadge ok={ok} />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">{children}</div>
            <div className="mt-4">
                <Button size="sm" onClick={onSave} disabled={saving} className="bg-brand-ink text-white hover:bg-black">
                    <Save className="w-3.5 h-3.5 mr-1" /> {saving ? "Saving…" : "Save"}
                </Button>
            </div>
        </div>
    );
}

export default function Integrations() {
    const [data, setData] = useState(null);
    const [sec, setSec] = useState({}); // typed secrets, keyed "section.field"
    const [saving, setSaving] = useState("");

    async function load() {
        const { data } = await api.get("/founder/integrations");
        setData(data);
    }
    useEffect(() => { load().catch(() => toast.error("Failed to load integrations")); }, []);

    function setField(section, field, v) {
        setData((d) => ({ ...d, [section]: { ...d[section], [field]: v } }));
    }
    function setSecret(section, field, v) { setSec((s) => ({ ...s, [`${section}.${field}`]: v })); }
    function secVal(section, field) { return sec[`${section}.${field}`] ?? ""; }
    function ph(section, field) { const m = data?.[section]?.[field]; return m?.set ? `${m.hint} — leave blank to keep` : "Not set"; }

    async function save(section, nonSecretFields, secretFields) {
        setSaving(section);
        try {
            const payload = {};
            nonSecretFields.forEach((f) => { payload[f] = data[section][f]; });
            secretFields.forEach((f) => { const v = secVal(section, f); if (v) payload[f] = v; });
            const res = await api.put("/founder/integrations", { [section]: payload });
            setData(res.data);
            setSec((s) => { const c = { ...s }; secretFields.forEach((f) => delete c[`${section}.${f}`]); return c; });
            toast.success("Saved");
        } catch { toast.error("Save failed"); } finally { setSaving(""); }
    }

    if (!data) return <div className="p-8 text-zinc-500">Loading…</div>;

    return (
        <div className="p-6 md:p-8 max-w-4xl" data-testid="founder-integrations">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-brand-copper mb-2"><Plug className="w-4 h-4" /> Integrations</div>
            <h1 className="font-display text-3xl text-brand-ink">Connect your providers</h1>
            <p className="mt-2 text-sm text-zinc-500">Paste your API keys here once — the whole platform uses them. Keys are stored securely and shown masked. A provider stays "Not connected" until its key is set (nothing is faked).</p>

            <div className="mt-8 space-y-5">
                <Card title="Payments" icon={CreditCard} ok={data.payments.configured} saving={saving === "payments"} testid="integ-payments"
                    onSave={() => save("payments", ["provider", "stripe_publishable_key", "paypal_client_id"], ["stripe_secret_key", "paypal_secret"])}>
                    <Select label="Active provider" testid="integ-payments-provider" value={data.payments.provider} onChange={(v) => setField("payments", "provider", v)}
                        options={[{ v: "none", l: "None" }, { v: "stripe", l: "Stripe" }, { v: "paypal", l: "PayPal" }]} />
                    <div />
                    <Text label="Stripe secret key" type="password" testid="integ-stripe-secret" value={secVal("payments", "stripe_secret_key")} onChange={(v) => setSecret("payments", "stripe_secret_key", v)} placeholder={ph("payments", "stripe_secret_key")} />
                    <Text label="Stripe publishable key" testid="integ-stripe-pub" value={data.payments.stripe_publishable_key || ""} onChange={(v) => setField("payments", "stripe_publishable_key", v)} placeholder="pk_live_…" />
                    <Text label="PayPal client ID" value={data.payments.paypal_client_id || ""} onChange={(v) => setField("payments", "paypal_client_id", v)} placeholder="Axx…" />
                    <Text label="PayPal secret" type="password" value={secVal("payments", "paypal_secret")} onChange={(v) => setSecret("payments", "paypal_secret", v)} placeholder={ph("payments", "paypal_secret")} />
                </Card>

                <Card title="E-commerce source (dropshipping)" icon={ShoppingCart} ok={data.ecommerce.configured} saving={saving === "ecommerce"} testid="integ-ecommerce"
                    onSave={() => save("ecommerce", ["provider"], ["ecommerce_api_key", "ecommerce_api_secret"])}>
                    <Select label="Source" testid="integ-ecommerce-provider" value={data.ecommerce.provider} onChange={(v) => setField("ecommerce", "provider", v)}
                        options={[{ v: "none", l: "None" }, { v: "aliexpress", l: "AliExpress (affiliate/dropship API)" }, { v: "cj_dropshipping", l: "CJ Dropshipping" }]} />
                    <div />
                    <Text label="API key" type="password" testid="integ-ecom-key" value={secVal("ecommerce", "ecommerce_api_key")} onChange={(v) => setSecret("ecommerce", "ecommerce_api_key", v)} placeholder={ph("ecommerce", "ecommerce_api_key")} />
                    <Text label="API secret" type="password" value={secVal("ecommerce", "ecommerce_api_secret")} onChange={(v) => setSecret("ecommerce", "ecommerce_api_secret", v)} placeholder={ph("ecommerce", "ecommerce_api_secret")} />
                </Card>

                <Card title="AI media (images & logos)" icon={ImageIcon} ok={data.ai_media.configured} saving={saving === "ai_media"} testid="integ-aimedia"
                    onSave={() => save("ai_media", ["image_provider"], ["openai_api_key", "gemini_api_key"])}>
                    <Select label="Image provider" testid="integ-image-provider" value={data.ai_media.image_provider} onChange={(v) => setField("ai_media", "image_provider", v)}
                        options={[{ v: "emergent", l: "Built-in (platform key)" }, { v: "openai", l: "OpenAI (your key)" }, { v: "gemini", l: "Gemini (your key)" }]} />
                    <div />
                    <Text label="OpenAI API key" type="password" value={secVal("ai_media", "openai_api_key")} onChange={(v) => setSecret("ai_media", "openai_api_key", v)} placeholder={ph("ai_media", "openai_api_key")} />
                    <Text label="Gemini API key" type="password" value={secVal("ai_media", "gemini_api_key")} onChange={(v) => setSecret("ai_media", "gemini_api_key", v)} placeholder={ph("ai_media", "gemini_api_key")} />
                </Card>

                <Card title="Voice (phone calls)" icon={Phone} ok={data.voice.configured} saving={saving === "voice"} testid="integ-voice"
                    onSave={() => save("voice", ["provider", "twilio_account_sid"], ["retell_api_key", "twilio_auth_token"])}>
                    <Select label="Provider" testid="integ-voice-provider" value={data.voice.provider} onChange={(v) => setField("voice", "provider", v)}
                        options={[{ v: "none", l: "None" }, { v: "retell", l: "Retell" }, { v: "twilio", l: "Twilio" }]} />
                    <div />
                    <Text label="Retell API key" type="password" testid="integ-retell-key" value={secVal("voice", "retell_api_key")} onChange={(v) => setSecret("voice", "retell_api_key", v)} placeholder={ph("voice", "retell_api_key")} />
                    <div />
                    <Text label="Twilio Account SID" value={data.voice.twilio_account_sid || ""} onChange={(v) => setField("voice", "twilio_account_sid", v)} placeholder="AC…" />
                    <Text label="Twilio Auth token" type="password" value={secVal("voice", "twilio_auth_token")} onChange={(v) => setSecret("voice", "twilio_auth_token", v)} placeholder={ph("voice", "twilio_auth_token")} />
                </Card>
            </div>
        </div>
    );
}
