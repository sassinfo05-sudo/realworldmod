"""Deterministic concurrency tests for the atomic cost/usage reservation system.

Proves (without any real LLM/provider calls, so no credit spend):
  1. Simultaneous AI reservations can NEVER settle more than the plan's AI hard cap.
  2. Simultaneous variable-provider reservations can NEVER exceed the variable cap.
  3. Pass-through kinds (e.g. voice minutes) are NOT gated by plan margin caps.
  4. reserve() fails closed (503) — verified structurally in usage.reserve.

Run:  cd /app/backend && python -m pytest tests/test_atomic_metering.py -q
 or:  cd /app/backend && python tests/test_atomic_metering.py
"""
import asyncio
import os
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))
except Exception:  # noqa: BLE001
    pass

from app.db import get_db  # noqa: E402
from app.services import usage  # noqa: E402
from app.services.entitlements import ai_budget_usd, variable_provider_cap_usd  # noqa: E402


async def _seed_plan(org_id: str, plan_code: str):
    """Give the throwaway org a subscription on `plan_code`."""
    await get_db().subscriptions.update_one(
        {"org_id": org_id},
        {"$set": {"org_id": org_id, "plan_code": plan_code, "status": "active"}},
        upsert=True,
    )


async def _cleanup(org_id: str):
    db = get_db()
    await db.usage_reservations.delete_many({"org_id": org_id})
    await db.llm_usage_events.delete_many({"org_id": org_id})
    await db.subscriptions.delete_many({"org_id": org_id})


async def _one_reservation(org_id: str, kind: str, provider: str, model: str, est: float):
    """Reserve + confirm + settle exactly like llm.py does. Returns True if it survived."""
    usage.set_context(org_id=org_id, feature="test_metering")
    res = await usage.reserve(kind=kind, provider=provider, model=model, est_cost=est,
                              org_id=org_id, feature="test_metering")
    try:
        await usage.confirm_reservation(res, org_id=org_id)
    except Exception:  # 402 — over budget; the hold released itself
        return False
    # Simulate the real call succeeding and settle at the estimated cost.
    await usage.settle(res, kind=kind, provider=provider, model=model,
                       units=1 if kind not in ("text", "json", "image") else 0,
                       images=1 if kind == "image" else 0, ok=True,
                       actual_cost_usd=est, org_id=org_id, feature="test_metering")
    return True


async def _survivors_cost(org_id: str, scope: str) -> float:
    match = {"org_id": org_id, **usage._kind_match(scope)}
    total = 0.0
    async for row in get_db().llm_usage_events.aggregate(
            [{"$match": match}, {"$group": {"_id": None, "c": {"$sum": "$cost_usd"}}}]):
        total = float(row.get("c") or 0.0)
    return round(total, 6)


async def _run_concurrent(org_id: str, kind: str, est: float, n: int):
    tasks = [_one_reservation(org_id, kind, "anthropic", "claude-sonnet-4-6", est) for _ in range(n)]
    results = await asyncio.gather(*tasks)
    return sum(1 for r in results if r)


async def scenario_ai_cap():
    org = f"test-ai-{uuid.uuid4()}"
    await _seed_plan(org, "free")
    cap = ai_budget_usd("free")            # 0.10
    est = 0.03
    n = 20
    survived = await _run_concurrent(org, "text", est, n)
    settled = await _survivors_cost(org, "ai")
    await _cleanup(org)
    print(f"[AI CAP]      cap=${cap:.2f} est=${est} fired={n} survived={survived} settled=${settled:.4f}")
    assert settled <= cap + 1e-6, f"AI cap breached: {settled} > {cap}"
    assert survived >= 1, "at least one AI reservation should fit under the cap"
    return settled, cap


async def scenario_variable_cap():
    org = f"test-var-{uuid.uuid4()}"
    await _seed_plan(org, "starter")       # ai=1.00, variable=2.04
    var_cap = variable_provider_cap_usd("starter")
    est = 0.25
    n = 20
    # kind="email" counts ONLY toward the variable cap (not the AI cap).
    survived = await _run_concurrent(org, "email", est, n)
    settled = await _survivors_cost(org, "variable")
    await _cleanup(org)
    print(f"[VARIABLE CAP] cap=${var_cap:.2f} est=${est} fired={n} survived={survived} settled=${settled:.4f}")
    assert settled <= var_cap + 1e-6, f"Variable cap breached: {settled} > {var_cap}"
    assert survived >= 1
    return settled, var_cap


async def scenario_passthrough_not_gated():
    org = f"test-pt-{uuid.uuid4()}"
    await _seed_plan(org, "free")          # tiny caps
    est = 5.00                             # far above any cap
    n = 5
    # voice_second is pass-through/prepaid — must NOT be blocked by plan margin caps.
    survived = await _run_concurrent(org, "voice_second", est, n)
    await _cleanup(org)
    print(f"[PASSTHROUGH]  est=${est} fired={n} survived={survived} (should equal {n})")
    assert survived == n, "pass-through kinds must never be gated by plan caps"
    return survived, n


async def scenario_ai_counts_toward_variable():
    """An AI spend also consumes the variable-provider cap. On a plan where the variable cap
    is the binding constraint for a pure-AI burst, AI settlement must respect BOTH."""
    org = f"test-both-{uuid.uuid4()}"
    await _seed_plan(org, "free")          # ai=0.10, variable=0.25
    est = 0.04
    n = 20
    survived = await _run_concurrent(org, "image", est, n)
    ai_settled = await _survivors_cost(org, "ai")
    var_settled = await _survivors_cost(org, "variable")
    await _cleanup(org)
    print(f"[AI⊂VARIABLE]  ai_cap=0.10 var_cap=0.25 settled_ai=${ai_settled:.4f} settled_var=${var_settled:.4f}")
    assert ai_settled <= ai_budget_usd("free") + 1e-6
    assert var_settled <= variable_provider_cap_usd("free") + 1e-6
    return ai_settled, var_settled


async def main():
    print("=== Atomic metering concurrency proof ===")
    await scenario_ai_cap()
    await scenario_variable_cap()
    await scenario_passthrough_not_gated()
    await scenario_ai_counts_toward_variable()
    print("ALL ATOMIC METERING ASSERTIONS PASSED")


# pytest entry points
def test_ai_cap():
    asyncio.get_event_loop().run_until_complete(scenario_ai_cap())


def test_variable_cap():
    asyncio.get_event_loop().run_until_complete(scenario_variable_cap())


def test_passthrough_not_gated():
    asyncio.get_event_loop().run_until_complete(scenario_passthrough_not_gated())


def test_ai_counts_toward_variable():
    asyncio.get_event_loop().run_until_complete(scenario_ai_counts_toward_variable())


if __name__ == "__main__":
    asyncio.run(main())
