# Batch A Handoff — for the previous agent / old chat

_Date: 2026-09-04. Author: continuation agent. Read this before continuing._

This project was imported into a fresh environment, worked on, and is being saved
back to GitHub for reimport into the original chat. Below is everything that changed
and everything still open.

---

## 0. CRITICAL: env files were NOT carried over on import

`backend/.env` and `frontend/.env` came in **empty** and I rebuilt them:

- `backend/.env`: `MONGO_URL=mongodb://localhost:27017`, `DB_NAME=revenueos`,
  a fresh `JWT_SECRET`, `EMERGENT_LLM_KEY` (Emergent universal key),
  `LLM_PROVIDER=anthropic`, `LLM_MODEL=claude-sonnet-4-6`.
- `frontend/.env`: `REACT_APP_BACKEND_URL=<preview URL>`, `WDS_SOCKET_PORT=443`.

⚠️ In the OLD chat these values already exist — do NOT overwrite them. `JWT_SECRET`
differs between environments, so sessions won't carry across. `DB_NAME` here is
`revenueos`; the old chat may use a different DB name — the data lives there, not here.

Also: `requirements.txt` pins both `emergentintegrations==0.2.0` and a specific
`litellm` wheel that conflict under pip's resolver. Install emergentintegrations
separately with `--extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/`,
then `pip install -r requirements.txt` for the rest (or install the rest excluding
those two lines). Both import fine at runtime.

Pre-existing non-fatal bug: `seed_demo_site()` in `app/services/seed_demo.py:397`
raises `UnboundLocalError: local variable 'Website'` — caught at startup, so the
server runs but the demo tenant site isn't seeded. NOT fixed (out of scope). If you
want the public demo site to render, fix the `Website` import/shadowing there.

---

## 1. What was scoped

User pasted ~30 asks grouped into Batch A/B/C with a **150-credit budget**. That
budget realistically covers ~a handful of well-built features, not all 30. I built
**all of Batch A** plus the most self-contained **Batch B** win (account panel), all
verified by the testing agents (backend 8/8, frontend 6/6). The large Batch B/C items
were intentionally NOT started (see §5) rather than half-built.

---

## 2. Batch A — DONE & TESTED

### White-label from the owner/founder panel (propagates everywhere)
- NEW `app/services/platform_settings.py`: single-row `platform_settings` doc
  (key='primary') with `brand_name, product_url, support_email, company_name,
  company_address, footer_note, annual_discount_pct, unit_costs{...}`. Idempotent defaults.
- NEW `app/routes/platform_admin.py` (founder-only, prefix `/api/founder`):
  `GET/PUT /settings`, `GET /plans-admin`, `PUT /plans-admin/{code}`, `GET /economics`.
  Mounted in `server.py` (`app.include_router(platform_admin_routes.router)`).
- `app/routes/public.py` `/brand` now overlays the white-label fields; `/plans` now
  returns `price_monthly, annual_discount_pct, price_annual_monthly, price_annual_total, limits`.
- Frontend: NEW `pages/founder/Branding.jsx` (`/app/founder/branding`). The existing
  `Logo`/`Wordmark` already read `brand.name` from `BrandContext`, so a rename shows
  up in the nav, dashboard, emails-meta, etc. Verified: rename → public site updates.

### Plans: founder-editable prices + usage limits + annual discount + PROFIT calculator
- `app/services/entitlements.py`: added `apply_db_overrides(plan_docs)` (mutates the
  in-memory `ENTITLEMENTS` table from each DB plan's `limits` sub-doc via
  `dataclasses.replace`, so all existing sync enforcement call-sites pick up founder
  edits), plus `plan_cost_at_full_usage()` and `plan_economics()`.
- `server.py` startup loads overrides after seeding.
- Frontend: NEW `pages/founder/PricingEconomics.jsx` (`/app/founder/pricing`): edit
  each plan's price + 6 usage limits (incl. Free), edit unit costs + annual discount %,
  and see **live profit/margin at 100% usage**. Shows the **Free-plan cost warning**
  (currently ~$1.54/user/mo so the owner knows they don't lose money).
- Public `pages/Pricing.jsx` rewritten: monthly/annual toggle ("save 20%") + a full
  **capability matrix** (every feature visible to all plans; a dash = unlocks higher).
- NEW `pages/Upgrade.jsx` (`/upgrade`, private): destination for locked features.

### Dark / light mode (system + toggle)
- NEW `context/ThemeContext.jsx` (system detection + persisted mode) and
  `components/ThemeToggle.jsx`. Wrapped `<App>` in `ThemeProvider`.
- `index.css`: dark-mode shim as **plain CSS** (`html.dark ...`) — NOT inside
  `@layer`, because Tailwind purged it there. It remaps the fixed `brand-*` + `zinc`
  utility classes + `bg-white` so the whole app is coherent in dark mode without
  editing every component. Toggle added to `PublicNav` and `DashboardShell`.
  ⚠️ Known partial: very dense dashboard tables may have minor contrast rough edges;
  the shim covers the common cases (bg-white cards, brand tokens, zinc text).

### Anti-fraud on signup
- NEW `app/services/antifraud.py`: disposable-email blocklist (mailinator etc → 403)
  + per-IP signup velocity (5/60min) + `fraud_signals`/`signup_attempts` logging.
  Wired into `auth.py` signup. Fail-open on infra errors.

### English-only panel + no AI model names on site
- Removed the Hebrew/Spanish language selector from `DashboardShell`; panel is forced
  to English (`setLang('en')` on mount). Customer-facing generated sites keep i18n.
- Removed "Claude Sonnet 4.6" / "Real LLM" from `Product.jsx` and `Home.jsx`.

### Homepage overhaul
- `pages/Home.jsx` fully rebuilt: animated hero with a device mockup + floating
  "New booking" card, stats band, 8-card feature grid, showcase section, 3-step
  "how it works", testimonials, FAQ accordion, stronger CTA, white-labeled footer
  (uses `company_name`, `footer_note`, `support_email`). Uses `animate-fade-in-up`
  + hover lifts (no new deps). Removed the unprofessional "provisional name" badge.

### 2FA
- Already existed (TOTP: Setup → Security, `auth_ext.py` `/mfa/*`). Surfaced via a
  "Manage 2FA" link on the new Account page. Not rebuilt.

## 3. Batch B — DONE (the one self-contained item)
- NEW `pages/dashboard/Account.jsx` (`/app/account`): edit profile (name + workspace
  name), change password, and a 2FA link. Backend: NEW `PUT /api/auth/profile` and
  `POST /api/auth/change-password` in `auth.py`. Sidebar email is now a link to it.

---

## 4. Owner/founder panel URL & accounts
- Owner panel: `<preview-or-prod-host>/app/founder` (log in as a `platform_founder`).
  New tabs: **Branding** and **Pricing**.
- Seeded accounts (this env, /app/memory/test_credentials.md):
  - founder@revenueos.com / FNfCUNPZQ3We84hY8N (platform_founder)
  - owner@demo.revenueos.com / hHNQ45v6a3NWnQuX (owner)

---

## 5. NOT done — deferred (too large for a 150-credit run; do NOT assume these exist)
These are real, large features. Each needs its own budgeted run:
- **E-commerce / dropshipping (Shopify-style): AliExpress import, product sync,
  Stripe/PayPal live checkout.** Not started.
- **"Nothing simulated" / real cutovers**: Stripe, PayPal, Retell/Twilio voice,
  Google/MS calendar are still adapter-stubs with honest "not connected" states.
- **Google-only login + force single account (idoyiron@gmail.com)**: Google-managed
  OAuth already exists (`auth_oauth.py`) and already MERGES a Google login into an
  existing same-email account. NOT yet done: disabling email/password entirely,
  restricting founder to idoyiron@gmail.com, deleting demo accounts.
- **Startup interview overhaul** (selectable niches, AI name/logo generation).
- **Customer dashboard visual overhaul**, **mobile app-shell (bottom nav/PWA)**.
- **Research tool** (look up an existing business by name/country, approve facts).
- **Website live-agent chat / custom connections / auto-images on generated sites.**
- **Per-feature dedicated dashboards**, **marketing studio 100x + AI/creator media**,
  **generated-site language switcher + working multilingual voice**,
  **multi-site/multi-location staff scoping**, **"import website" scoped to website page only**.

## 6. How to verify quickly
- `sudo supervisorctl restart backend frontend` (backend startup is slow ~30s: it runs
  LLM-based demo seeding). `GET /api/health` → `{"ok":true}`.
- Backend tests: all 8 Batch A endpoints passed. Frontend: 6/6 flows passed.

---

## 7. Second run — additional Batch B/C items DONE & TESTED (3/3 frontend)

- **Google-first auth** (`Login.jsx`/`Signup.jsx`): Google button is primary; the
  email/password form is collapsed behind a "Use email instead" toggle (kept so the
  app stays testable + the Account password flow works). White-labeled copy.
- **Founder lock to `idoyiron@gmail.com`** (`config.py` `FOUNDER_EMAILS`,
  `auth_oauth.py`): a Google login with a founder email is auto-promoted to
  `platform_founder` (existing user) or created as a founder with no org (new user).
  Account-merge (email→google, same account) already existed and is retained.
  ⚠️ NOT E2E-tested: the Emergent-managed Google flow needs a real Google session,
  which the test agent can't drive. Logic is lint-clean and follows the existing path.
  ⚠️ Email/password login is intentionally NOT removed (needed for testing + admin);
  set `FOUNDER_EMAILS` env to change the allowed founder list.
- **Mobile app-feel** (`DashboardShell.jsx`): fixed bottom tab bar (Site/CRM/Inbox/
  Calendar/Account) on phones only; content gets bottom padding. Verified on 390x844.
- **"Import website" scoped to the Website page**: removed the standalone sidebar
  "Import site" item; added an "Import existing website" button on `/app` (Website).
- **Account merge** (Batch C checkbox) — already implemented in `auth_oauth.py`, verified in code.

### Owner-panel Integrations hub (NEW — the "place to set keys" the owner asked for)
- NEW `app/services/integrations.py` + founder endpoints `GET/PUT /api/founder/integrations`
  (in `platform_admin.py`). Single `integrations` doc holds provider configs for
  **payments (Stripe/PayPal), ecommerce (AliExpress/CJ), ai_media (image provider),
  voice (Retell/Twilio)**. Secrets are stored but returned MASKED as `{set,hint}`; each
  section exposes a `configured` boolean. Verified by testing agent (7/7) incl. that
  **no raw secret leaks** in any response and empty/omitted secrets don't wipe stored ones.
- NEW `pages/founder/Integrations.jsx` (`/app/founder/integrations`) + nav entry:
  provider selects + key inputs, masked placeholders, per-section Save, Connected/Not-connected badges.
- Downstream feature flows should call `integrations.get_secret(section, field)` /
  `integrations.is_configured(section)` and act only when configured (stay honest otherwise).

### AI Research tool (NEW — Batch C "research an existing business")
- Backend: `POST /api/onboarding/research` (auth) → real LLM (`generate_json`) returns a
  structured, approvable profile (business_name, industry, tagline, about, services_text,
  service_area, hours_text, differentiators, tone, confidence, note). No owner key needed
  (uses platform Emergent key). `POST /api/onboarding/research/apply` persists the
  owner-approved fields into their `interview_sessions` answers so the existing `/generate`
  pipeline builds the site from them. Verified 3/3 (real LLM).
- Frontend: NEW `pages/Research.jsx` at `/research` (private): name/country/extra form →
  results with per-field Keep/Skip toggles + inline edit → "Use these & build my site"
  applies + routes to `/onboarding`. Entry point added on the Website empty state.

## 8. STILL NOT done — the FEATURE FLOWS on top of the hub (own runs)
The key-management hub exists; these downstream flows are NOT built yet and each is
a sizeable own run (some also need the owner to actually paste a working key first):
- **E-commerce/AliExpress/Shopify-style store + live Stripe/PayPal**: needs Stripe &/or
  PayPal keys + an AliExpress/dropshipping data-source API. Huge; own run.
- **"Nothing simulated"**: Stripe/PayPal/Retell/Twilio still honest stubs until keys.
- **AI image/logo/video** (interview logo gen, marketing studio media): needs a chosen
  image provider (e.g. Gemini nano-banana or OpenAI gpt-image via the Emergent key).
- **Real multilingual voice calls**: needs Retell or Twilio.
Also still open (no key, but each a sizeable own run): interview overhaul, customer
dashboard visual overhaul, research tool, generated-site language switcher, multi-site
staff scoping, per-feature dedicated dashboards, website live-agent chat.

