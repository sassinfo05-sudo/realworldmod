import { useEffect, useMemo, useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { Wordmark } from "@/components/Logo";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import api, { getImpersonationToken, clearImpersonation } from "@/lib/api";
import { toast } from "sonner";
import { useT, setLang } from "@/lib/i18n";
import ThemeToggle from "@/components/ThemeToggle";
import NotificationBell from "@/components/NotificationBell";
import SiteSwitcher from "@/components/SiteSwitcher";
import usePageMeta from "@/hooks/usePageMeta";
import {
    Globe2, Users, Inbox, Calendar, CreditCard, Bot, Megaphone, Settings, LogOut,
    Link2, BarChart3, MessageSquare, FileText, Wrench, BookOpen, Zap, Sparkles, HelpCircle, Percent,
    Shield, UserCheck, Search, Plug, Store, ShoppingBag, LayoutDashboard, ChevronDown, Pencil,
    Layers, Menu, X, ExternalLink, Phone, Ticket, Truck, Languages, Repeat, Database, ImageIcon,
} from "lucide-react";

/** Grouped navigation — Build / Sell / Grow / Operate / Account. Keys keep legacy testids. */
const GROUPS = [
    { label: "Overview", items: [
        { to: "/app", label: "Dashboard", icon: LayoutDashboard, key: "dashboard", end: true },
    ]},
    { label: "Build", items: [
        { to: "/app/website", label: "Website", icon: Globe2, key: "website" },
        { to: "/app/blog", label: "Blog", icon: FileText, key: "blog" },
        { to: "/app/logo-studio", label: "Logo studio", icon: Sparkles, key: "logo-studio" },
        { to: "/app/languages", label: "Languages", icon: Languages, key: "languages" },
        { to: "/app/sites", label: "Sites & maintenance", icon: Layers, key: "sites" },
        { to: "/app/domains", label: "Domains", icon: Link2, key: "domains" },
        { to: "/app/seo", label: "SEO", icon: Search, key: "seo" },
        { to: "/app/analytics", label: "Analytics", icon: BarChart3, key: "analytics" },
        { to: "/app/forms", label: "Forms", icon: MessageSquare, key: "forms" },
        { to: "/app/content", label: "Content Manager", icon: Database, key: "content" },
        { to: "/app/assets", label: "Asset Library", icon: ImageIcon, key: "assets" },
    ]},
    { label: "Sell", items: [
        { to: "/app/store/products", label: "Products", icon: Store, key: "store-products" },
        { to: "/app/store/orders", label: "Orders", icon: ShoppingBag, key: "store-orders" },
        { to: "/app/store/discounts", label: "Discounts", icon: Ticket, key: "store-discounts" },
        { to: "/app/store/subscriptions", label: "Subscriptions", icon: Repeat, key: "store-subscriptions" },
        { to: "/app/store/shipping", label: "Shipping", icon: Truck, key: "store-shipping" },
        { to: "/app/store/tax", label: "Tax", icon: Percent, key: "store-tax" },
        { to: "/app/calendar", label: "Bookings", icon: Calendar, key: "calendar" },
        { to: "/app/quotes", label: "Quotes", icon: FileText, key: "quotes" },
        { to: "/app/jobs", label: "Jobs", icon: Wrench, key: "jobs" },
        { to: "/app/payments", label: "Invoices & payments", icon: CreditCard, key: "payments" },
    ]},
    { label: "Grow", items: [
        { to: "/app/crm", label: "Contacts (CRM)", icon: Users, key: "crm" },
        { to: "/app/crm/deals", label: "Deals", icon: BarChart3, key: "crm-deals" },
        { to: "/app/inbox", label: "Inbox", icon: Inbox, key: "inbox" },
        { to: "/app/marketing", label: "Marketing", icon: Megaphone, key: "marketing" },
        { to: "/app/workflows", label: "Workflows", icon: Zap, key: "workflows" },
        { to: "/app/ai", label: "AI employees", icon: Bot, key: "ai_employees" },
        { to: "/app/numbers", label: "Phone & AI voice", icon: Phone, key: "numbers" },
        { to: "/app/knowledge", label: "Knowledge base", icon: BookOpen, key: "knowledge" },
    ]},
    { label: "Operate", items: [
        { to: "/app/integrations", label: "Integrations", icon: Plug, key: "integrations" },
        { to: "/app/billing", label: "Plan & billing", icon: Zap, key: "billing" },
        { to: "/app/setup", label: "Setup center", icon: Sparkles, key: "setup" },
        { to: "/app/support", label: "Support", icon: HelpCircle, key: "support" },
        { to: "/app/settings", label: "Settings", icon: Settings, key: "settings" },
    ]},
];

const TITLES = {
    "/app": "Dashboard", "/app/website": "Website", "/app/website/new": "New design", "/app/blog": "Blog", "/app/logo-studio": "Logo studio", "/app/languages": "Languages", "/app/sites": "Sites", "/app/domains": "Domains", "/app/seo": "SEO",
    "/app/analytics": "Analytics", "/app/forms": "Forms", "/app/crm": "Contacts", "/app/crm/deals": "Deals", "/app/inbox": "Inbox",
    "/app/calendar": "Bookings", "/app/quotes": "Quotes", "/app/jobs": "Jobs", "/app/payments": "Payments",
    "/app/store/products": "Products", "/app/store/orders": "Orders", "/app/store/shipping": "Shipping", "/app/store/tax": "Tax", "/app/ai": "AI employees", "/app/knowledge": "Knowledge base",
    "/app/marketing": "Marketing", "/app/workflows": "Workflows", "/app/integrations": "Integrations", "/app/billing": "Billing", "/app/setup": "Setup",
    "/app/support": "Support", "/app/settings": "Settings", "/app/account": "Account",
};

function ImpersonationBanner() {
    const [orgName, setOrgName] = useState(() => { try { return sessionStorage.getItem("zv.impersonation_org_name"); } catch (e) { return null; } });
    const navigate = useNavigate();
    useEffect(() => {
        const t = setInterval(() => {
            let cur = null;
            try { cur = sessionStorage.getItem("zv.impersonation_org_name"); } catch (e) { cur = null; }
            if (cur !== orgName) setOrgName(cur);
        }, 1000);
        return () => clearInterval(t);
    }, [orgName]);
    async function exit() {
        try { await api.post("/founder/impersonate/end"); } catch { /* clear anyway */ }
        clearImpersonation();
        setOrgName(null);
        toast.success("Impersonation ended");
        navigate("/staff/tenants");
    }
    if (!getImpersonationToken() || !orgName) return null;
    return (
        <div className="bg-amber-500 text-white px-4 py-2 flex items-center justify-between gap-3" data-testid="global-impersonation-banner">
            <div className="text-sm flex items-center gap-2"><UserCheck className="w-4 h-4" />
                <span className="font-medium">Support session — acting as {orgName}.</span>
                <span className="opacity-80 text-xs">Every action is audited. Auto-exit in 30 min.</span></div>
            <Button size="sm" variant="outline" onClick={exit} className="bg-white text-amber-800 border-white hover:bg-amber-50" data-testid="global-impersonation-exit-btn">
                <LogOut className="w-3.5 h-3.5 mr-1" /> Exit</Button>
        </div>
    );
}

export default function DashboardShell({ children }) {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const { lang } = useT();
    const [mobileOpen, setMobileOpen] = useState(false);
    const [collapsed, setCollapsed] = useState(() => {
        try { return JSON.parse(localStorage.getItem("zanelvo.nav.collapsed") || "{}"); } catch { return {}; }
    });
    const [announcement, setAnnouncement] = useState(null);

    useEffect(() => { if (lang !== "en") setLang("en"); }, [lang]);
    useEffect(() => { setMobileOpen(false); }, [location.pathname]);
    useEffect(() => {
        (async () => {
            try {
                const r = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/support/announcement`);
                if (r.ok) { const d = await r.json(); if (d.active && d.title) setAnnouncement(d); }
            } catch { /* silent */ }
        })();
    }, []);

    const pageTitle = useMemo(() => {
        const p = location.pathname;
        const hit = Object.keys(TITLES).filter((k) => p === k || p.startsWith(k + "/")).sort((a, b) => b.length - a.length)[0];
        return TITLES[hit] || "Dashboard";
    }, [location.pathname]);
    usePageMeta(pageTitle);

    const isFounder = user?.role === "platform_founder";
    function toggleGroup(label) {
        const next = { ...collapsed, [label]: !collapsed[label] };
        setCollapsed(next);
        localStorage.setItem("zanelvo.nav.collapsed", JSON.stringify(next));
    }

    const Sidebar = (
        <>
            <div className="h-16 px-5 flex items-center justify-between border-b border-brand-line">
                <Link to="/app" data-testid="sidebar-brand-link"><Wordmark /></Link>
                <button className="md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X className="w-5 h-5" /></button>
            </div>
            <div className="px-3 pt-3"><SiteSwitcher /></div>
            <nav className="p-3 space-y-4 overflow-y-auto flex-1" data-testid="sidebar-nav">
                {GROUPS.map((g) => (
                    <div key={g.label}>
                        <button type="button" onClick={() => toggleGroup(g.label)}
                            className="w-full flex items-center justify-between px-3 mb-1 text-[10px] uppercase tracking-[0.18em] text-zinc-400 hover:text-zinc-600">
                            {g.label}
                            <ChevronDown className={`w-3 h-3 transition-transform ${collapsed[g.label] ? "-rotate-90" : ""}`} />
                        </button>
                        {!collapsed[g.label] && g.items.map(({ to, label, icon: Icon, key, end }) => (
                            <NavLink key={to} to={to} end={!!end} data-testid={`sidebar-${key}-link`}
                                className={({ isActive }) =>
                                    `group flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] transition-all ${
                                        isActive ? "bg-brand-copper/10 text-brand-copper font-medium shadow-[inset_3px_0_0_0_#4F46E5]"
                                                 : "text-zinc-600 hover:bg-zinc-100/80 hover:text-brand-ink dark:text-zinc-300 dark:hover:bg-white/5"}`}>
                                <Icon className="w-4 h-4 shrink-0" />{label}
                            </NavLink>
                        ))}
                    </div>
                ))}
                {isFounder && (
                    <NavLink to="/staff" data-testid="sidebar-founder-link"
                        className="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] border border-brand-copper/30 text-brand-copper hover:bg-brand-copper/10">
                        <Shield className="w-4 h-4" /> Staff panel
                    </NavLink>
                )}
            </nav>
            <div className="p-3 border-t border-brand-line">
                <Link to="/app/account" data-testid="sidebar-account-link" className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-zinc-100/80 dark:hover:bg-white/5">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-copper to-brand-accent text-white grid place-items-center text-xs font-semibold">
                        {(user?.full_name || user?.email || "?")[0]?.toUpperCase()}
                    </div>
                    <div className="min-w-0">
                        <div className="text-xs font-medium truncate" data-testid="sidebar-user-email">{user?.full_name || user?.email}</div>
                        <div className="text-[10px] uppercase tracking-widest text-zinc-400">{user?.role}</div>
                    </div>
                </Link>
            </div>
        </>
    );

    return (
        <div className="min-h-screen bg-brand-surface flex flex-col" data-testid="dashboard-shell">
            <ImpersonationBanner />
            <div className="flex flex-1 min-h-0">
                <aside className="hidden md:flex w-64 flex-col border-r border-brand-line bg-white dark:bg-zinc-950 sticky top-0 h-screen">{Sidebar}</aside>
                {mobileOpen && (
                    <div className="md:hidden fixed inset-0 z-40 flex">
                        <aside className="w-72 bg-white dark:bg-zinc-950 flex flex-col h-full shadow-2xl">{Sidebar}</aside>
                        <div className="flex-1 bg-black/40" onClick={() => setMobileOpen(false)} />
                    </div>
                )}

                <div className="flex-1 flex flex-col min-w-0">
                    {/* Header */}
                    <header className="h-16 sticky top-0 z-30 bg-white/80 dark:bg-zinc-950/80 backdrop-blur border-b border-brand-line px-4 md:px-8 flex items-center gap-3" data-testid="dashboard-header">
                        <button className="md:hidden p-2 -ml-2" onClick={() => setMobileOpen(true)} aria-label="Open menu" data-testid="mobile-menu-btn"><Menu className="w-5 h-5" /></button>
                        <div className="min-w-0">
                            <div className="text-[10px] uppercase tracking-widest text-zinc-400 hidden sm:block">{user?.org_name || "Workspace"}</div>
                            <h1 className="font-display text-lg leading-tight text-brand-ink truncate" data-testid="page-title">{pageTitle}</h1>
                        </div>
                        <div className="ml-auto flex items-center gap-1.5 md:gap-2">
                            <Button variant="gradient" size="sm" onClick={() => navigate("/app/editor")} data-testid="header-edit-site-btn" className="hidden sm:inline-flex">
                                <Pencil className="w-3.5 h-3.5" /> Edit site
                            </Button>
                            {user?.org_slug && (
                                <Button variant="ghost" size="icon" asChild title="View live site">
                                    <a href={`/site/${user.org_slug}`} target="_blank" rel="noreferrer" data-testid="header-view-site-link"><ExternalLink className="w-4 h-4" /></a>
                                </Button>
                            )}
                            <NotificationBell announcement={announcement} />
                            <ThemeToggle />
                            <Button variant="ghost" size="sm" className="text-zinc-600" data-testid="sidebar-logout-btn" onClick={() => { logout(); navigate("/"); }}>
                                <LogOut className="w-4 h-4" /><span className="hidden lg:inline">Log out</span>
                            </Button>
                        </div>
                    </header>
                    {announcement && (
                        <div className={`px-4 md:px-8 py-2 text-sm flex items-center gap-2 border-b ${announcement.level === "urgent" ? "bg-red-50 text-red-800 border-red-100" : announcement.level === "warn" ? "bg-amber-50 text-amber-800 border-amber-100" : "bg-brand-copper/5 text-brand-ink border-brand-line"}`} data-testid="announcement-banner">
                            <Megaphone className="w-4 h-4 shrink-0" /><span className="font-medium">{announcement.title}</span>{announcement.body && <span className="opacity-75 truncate">{announcement.body}</span>}
                        </div>
                    )}
                    <main className="flex-1 pb-20 md:pb-8" data-testid="dashboard-main">{children}</main>
                </div>

                {/* Mobile bottom tabs */}
                <nav className="md:hidden fixed bottom-0 inset-x-0 z-30 h-16 bg-white/95 dark:bg-zinc-950/95 backdrop-blur border-t border-brand-line flex items-stretch justify-around px-1" data-testid="mobile-bottom-nav">
                    {[{ to: "/app", icon: LayoutDashboard, label: "Home", end: true }, { to: "/app/crm", icon: Users, label: "CRM" },
                      { to: "/app/inbox", icon: Inbox, label: "Inbox" }, { to: "/app/calendar", icon: Calendar, label: "Bookings" },
                      { to: "/app/account", icon: UserCheck, label: "Account" }].map(({ to, icon: Icon, label, end }) => (
                        <NavLink key={to} to={to} end={!!end} data-testid={`mobile-tab-${label.toLowerCase()}`}
                            className={({ isActive }) => `flex flex-col items-center justify-center gap-0.5 flex-1 text-[10px] ${isActive ? "text-brand-copper" : "text-zinc-500"}`}>
                            <Icon className="w-5 h-5" />{label}
                        </NavLink>
                    ))}
                </nav>
            </div>
        </div>
    );
}
