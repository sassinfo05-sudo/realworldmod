import usePageMeta from "@/hooks/usePageMeta";
import { EditorProvider, useEditor } from "./EditorProvider";
import TopBar from "./TopBar";
import PagesPanel from "./PagesPanel";
import Canvas from "./Canvas";
import Inspector from "./Inspector";

function EditorLayout() {
    const { loading, website } = useEditor();
    if (loading) return <div className="min-h-screen flex items-center justify-center text-zinc-500">Loading your editor…</div>;
    if (!website) return <div className="min-h-screen flex items-center justify-center text-zinc-500">No website yet. Finish onboarding first.</div>;
    return (
        <div className="h-screen flex flex-col bg-brand-surface" data-testid="editor-page">
            <TopBar />
            <div className="flex-1 flex overflow-hidden">
                <PagesPanel />
                <Canvas />
                <Inspector />
            </div>
        </div>
    );
}

export default function Editor() {
    usePageMeta("Editor");
    return (
        <EditorProvider>
            <EditorLayout />
        </EditorProvider>
    );
}
