"""JWT + bcrypt + password reset tokens."""
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import bcrypt
import jwt

from . import config


def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:
        return False


def create_access_token(user_id: str, org_id: Optional[str], role: str, extra: Optional[dict] = None,
                        ttl_min: Optional[int] = None) -> str:
    now = datetime.now(timezone.utc)
    minutes = int(ttl_min) if ttl_min else config.JWT_ACCESS_TTL_MIN
    payload = {
        "sub": user_id,
        "org_id": org_id,
        "role": role,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=minutes)).timestamp()),
        **(extra or {}),
    }
    return jwt.encode(payload, config.JWT_SECRET, algorithm=config.JWT_ALG)


def create_impersonation_token(founder_user_id: str, target_org_id: str,
                                    session_id: str, minutes: int = 30) -> str:
    """Short-lived scoped token used ONLY while a founder is impersonating a tenant.
    Claims: sub=founder id, org_id=target org, role='owner', imp_sid=session id.
    Cannot be refreshed; expires with the impersonation session.
    """
    now = datetime.now(timezone.utc)
    payload = {
        "sub": founder_user_id,
        "org_id": target_org_id,
        "role": "owner",
        "imp_sid": session_id,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=minutes)).timestamp()),
    }
    return jwt.encode(payload, config.JWT_SECRET, algorithm=config.JWT_ALG)


def decode_access_token(token: str) -> dict:
    return jwt.decode(token, config.JWT_SECRET, algorithms=[config.JWT_ALG])


def generate_reset_token() -> str:
    return secrets.token_urlsafe(32)


def generate_readable_password(length: int = 16) -> str:
    """Human-typeable password: letters + digits, no symbols. For seed accounts only."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(length))
