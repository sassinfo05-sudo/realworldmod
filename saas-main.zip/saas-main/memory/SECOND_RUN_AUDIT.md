# ZANELVO — SECOND RUN AUDIT (Round 8)
_Completion audit of the second continuation. Preview: https://bootstrap-fix-2.preview.emergentagent.com_
_Credentials: /app/memory/test_credentials.md (regenerated this run; old ones rotated)._

## 1. Already working (proven by a passing test this run or a previous round's agent run)
- Auth: signup, login (persistent + in-memory rate limits), 2FA scaffolding, staff login (separate DB), RBAC (`require_org`, `require_staff`), impersonation audit.
- Website: onboarding interview → BusinessProfile → block-JSON site generation (industry variants), FactReview gate, editor (blocks, hidden, publish, rollback/revisions), public sites `/site/{slug}` incl. maintenance/password/redirects, sitemap, custom-domain DNS records + verification polling (adapter simulated for SSL issuance).
- CRM (contacts, lead scoring, timeline), unified inbox + scheduled sends, bookings/quotes/invoices/jobs, payments code path (Stripe signature-verified idempotent webhook; sandbox until keys), store (products, variants, collections, discounts, inventory, abandoned-checkout sweep), shipping suite (zones/rates/carriers directory/tracking/packing slips), numbers + AI voice (simulated until carrier), AI receptionist chat widget w/ human takeover, marketing campaigns w/ open/click tracking + A/B + revenue attribution, localization API + translation cache, branding/logo studio (SVG + AI image), staff panel (team, plans/P&L, tenants, fraud, email center, integrations, audit).
- **NEW this round (backend agent 21/23 → 23/23 after fix):** central cost service, P0 security fixes, pricing versioning, internal competitive matrix, provider status cards, storefront/site language switcher (Hebrew RTL verified by screenshot).

## 2. Partially working
- Website editor (`frontend/src/pages/editor/*`): click-to-edit, dnd-kit drag-reorder, inline contentEditable text, duplicate/delete blocks, 24-type block library, theme, device previews, autosave, undo/redo, revisions/rollback and media picker EXIST (not regression-tested this round). NOT built: section regeneration, reusable sections, template library/build-from-scratch path, blog, alt-text UI, chunked uploads.
- Custom domains: DNS records + ownership verification real; certificate provisioning uses a replaceable adapter (simulated) — status shown honestly as Sandbox.
- Commerce long tail: subscriptions, gift cards, bundles/upsells, returns/refunds flows, customer accounts, product CSV import/export — partial or missing.
- Automations: rule-based (no branching visual workflow builder, no version history / test mode).
- Analytics: campaign + UTM + last-touch revenue attribution exist; CAC/ROAS/LTV/cohorts/funnel builder are not built.
- Ads Creative Studio: copy/creative generation exists in marketing; no aspect-ratio exports, provenance, approvals, or ad-account connections.
- Support: tickets + help articles exist; unified support inbox / knowledge-base grounded AI support / status page not built.

## 3. Simulated integrations (labelled Sandbox / Not connected in Staff → Payments & email → Provider status)
- Email delivery (simulated sender until Resend/SendGrid/SMTP configured), Stripe/PayPal (not connected), phone numbers/voice (simulated until Telnyx/Twilio), live carrier rates/labels (Shippo/EasyPost not connected), ad platforms (not connected), domain SSL adapter (simulated). LLM (Emergent key) is CONNECTED.

## 4. Unfinished handoff items (carried from Rounds 6/7)
- Home + Pricing “wow” redesign; onboarding rework (interview out of signup, build-from-scratch + template gallery); website editor overhaul; drag&drop chunked uploads; live carrier rates; pro dashboard redesign; anti-abuse blocklist actions.

## 5. Bugs found & fixed this run
- Password-reset token returned in API + stored in plaintext; non-atomic consumption; no session invalidation → fixed (sha256 hash, find_one_and_update, sessions_invalidated_at, `<=` iat check).
- Team invite returned a temporary password → replaced with hashed set-password link flow.
- Staff member creation echoed temp password even when emailed → only in dev or when creator typed it.
- Invalid ObjectId → 500 → now 400 (middleware + handler). LlmError → 503 with friendly message.
- Wildcard CORS with credentials → credentials disabled for `*`.
- No request-size limits → 2 MB JSON / 25 MB multipart (413).
- SSRF in website import + outbound webhooks (private IP / loopback / metadata / redirects) → `services/netsafe.py` guard.
- Integration secrets stored plaintext → Fernet encryption at rest (`services/secretbox.py`), transparent migration on next save.
- Email inbound webhook accepted unauthenticated posts when no secret configured → refused in production, constant-time compare, rate-limited.
- Voice webhooks (Twilio/Retell) unauthenticated & unmetered → signature/shared-secret check + tenant metering with honest fallback.
- Public chat / translate consumed LLM without tenant budget → metered as `public=True`, plan cap + visitor daily cap.
- `generate_json` retried on budget/pause 503s → now re-raises immediately; retries metered with `retry_count`.
- Store order finalize: double-decrement + negative stock possible → atomic claim + guarded `$inc`.
- Production auto-seeding of demo accounts/data → gated by `APP_ENV`/`SEED_DEMO_DATA`; founder bootstrap via `FOUNDER_INITIAL_PASSWORD`.
- Old brand strings (“Revenue OS API”, importer UA, export filename, webhook header) → Zanelvo (legacy header kept alongside).
- Fake testimonials on Home (“Real businesses. Real results.”) → replaced with clearly-labelled example scenarios. Generator prompt: truth rule (no invented prices/reviews/stats).
- Secrets/creds in memory files & backend_test.py → redacted; test script reads TEST_OWNER_PASSWORD env.

## 6. Security issues still open (documented, not fixed)
- Rate limiting for non-auth buckets is in-process only (multi-worker deployments should add Redis); auth buckets are Mongo-backed.
- SVG sanitisation for uploaded/AI logos not implemented (logo_svg is generated client-side; uploads should be sanitised before rendering with dangerouslySetInnerHTML).
- CSV import size/row limits not audited beyond the global 25 MB body cap.
- 2FA for staff is skipped until an email provider is connected (by design; documented).

## 7. Cost-leak paths found
- Fixed: public chat/translate/voice unmetered; JSON retries without accounting; no pause/kill; no global cap; seed LLM calls unlabelled (now `platform/seed`).
- Open: background jobs (abandoned-checkout nudges, scheduled sends) are metered as email but have no per-job cap; image generation has no per-org daily cap beyond plan budget (feature caps available via controls).

## 8. Competitor-parity gaps
See `/app/memory/COMPETITOR_COMPARISON.md` and Staff → Competitive (internal). Largest gaps: template gallery/from-scratch + blog + section regeneration, commerce long tail, visual workflow automation, analytics (CAC/LTV/funnels), live provider connections. Full per-item matrix (A–N) is in HANDOFF_ROUND_8.md §2.

## 9. Implementation order followed this run
1) Environment rebuild + fresh credentials 2) central cost service + LLM/email metering 3) P0 security 4) pricing versioning 5) staff UI (controls/margin/export, provider status, competitive) 6) brand/truth sweep 7) storefront language switcher + RTL 8) tests + docs.

## 10. Verification results
- Backend agent (Round 8): 21/23 first pass; 1 real bug (iat `<` vs `<=`) fixed; 1 “failure” was a test-harness limitation (Content-Length spoofing) — server enforces 413 on real oversized bodies. Re-verified after fix: see test_result.md.
- Frontend agent: see test_result.md Round 8 frontend section.
- Manual screenshots: Staff cost/usage page, provider status cards, competitive matrix, Hebrew RTL public site.
