import InsightsDashboard from "@/components/InsightsDashboard";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Copy, ExternalLink, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

const STATUS_TONES = {
    draft: "bg-zinc-100 text-zinc-700",
    sent: "bg-blue-100 text-blue-800",
    partial: "bg-amber-100 text-amber-800",
    paid: "bg-emerald-100 text-emerald-800",
    overdue: "bg-red-100 text-red-800",
    void: "bg-zinc-100 text-zinc-500",
};

function InvoicesBase() {
    const [tab, setTab] = useState("all");
    const [invoices, setInvoices] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    async function load() {
        setLoading(true);
        try {
            const params = tab === "all" ? "" : `?status=${tab}`;
            const { data } = await api.get(`/invoices${params}`);
            setInvoices(data.invoices || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [tab]);

    const overdueCount = useMemo(() => invoices.filter((i) => i.status === "overdue").length, [invoices]);
    const outstanding = useMemo(() => invoices
        .filter((i) => i.status !== "paid" && i.status !== "void")
        .reduce((sum, i) => sum + ((i.total_cents || 0) - (i.amount_paid_cents || 0)), 0), [invoices]);

    return (
        <div className="p-6" data-testid="invoices-page">
            <div className="mb-6">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Payments</div>
                <h1 className="font-display text-3xl text-brand-ink font-medium">Invoices</h1>
                <p className="text-sm text-zinc-500 mt-1">Every invoice you send. Overdue ones nudge automatically. Payments post to the contact timeline.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                <div className="rounded-xl border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500">Outstanding</div>
                    <div className="mt-1 text-2xl font-mono text-brand-ink" data-testid="invoices-outstanding">{money(outstanding)}</div>
                </div>
                <div className="rounded-xl border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500">Overdue</div>
                    <div className="mt-1 text-2xl font-mono text-red-600" data-testid="invoices-overdue-count">{overdueCount}</div>
                </div>
                <div className="rounded-xl border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500">Provider</div>
                    <div className="mt-1 text-sm text-brand-ink">Simulated <span className="text-zinc-500">· in-app test checkout</span></div>
                </div>
            </div>

            <Tabs value={tab} onValueChange={setTab}>
                <TabsList data-testid="invoices-tabs">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="sent">Sent</TabsTrigger>
                    <TabsTrigger value="overdue">
                        Overdue {overdueCount ? <span className="ml-1 rounded-full bg-red-200 text-red-900 text-[10px] px-1.5">{overdueCount}</span> : null}
                    </TabsTrigger>
                    <TabsTrigger value="paid">Paid</TabsTrigger>
                </TabsList>
                <TabsContent value={tab} className="mt-4">
                    <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Number</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Due</TableHead>
                                    <TableHead>Total</TableHead>
                                    <TableHead>Paid</TableHead>
                                    <TableHead>Portal</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {invoices.map((inv) => (
                                    <TableRow key={inv.id} data-testid={`invoice-row-${inv.id}`} className="hover:bg-brand-cream/30 cursor-pointer"
                                              onClick={() => navigate(`/app/payments/${inv.id}`)}>
                                        <TableCell className="font-mono text-xs text-brand-copper">{inv.number || inv.id.slice(0, 8)}</TableCell>
                                        <TableCell>
                                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs ${STATUS_TONES[inv.status] || "bg-zinc-100"}`}>
                                                {inv.status === "overdue" && <AlertTriangle className="w-3 h-3 mr-1" />}
                                                {inv.status}
                                            </span>
                                        </TableCell>
                                        <TableCell className="text-xs">{inv.due_at ? new Date(inv.due_at).toLocaleDateString() : "—"}</TableCell>
                                        <TableCell className="font-mono">{money(inv.total_cents, inv.currency)}</TableCell>
                                        <TableCell className="font-mono text-emerald-700">{money(inv.amount_paid_cents, inv.currency)}</TableCell>
                                        <TableCell onClick={(e) => e.stopPropagation()}>
                                            {inv.portal_token && (
                                                <div className="flex gap-1">
                                                    <button
                                                        className="text-xs text-brand-copper hover:underline inline-flex items-center gap-1"
                                                        data-testid={`invoice-copy-portal-${inv.id}`}
                                                        onClick={() => {
                                                            navigator.clipboard.writeText(`${window.location.origin}/portal/invoice/${inv.id}?tk=${inv.portal_token}`);
                                                            toast.success("Portal link copied");
                                                        }}
                                                    ><Copy className="w-3 h-3" /> Link</button>
                                                    <a href={`/portal/invoice/${inv.id}?tk=${inv.portal_token}`} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>
                                                        <ExternalLink className="w-3 h-3 text-brand-copper" />
                                                    </a>
                                                </div>
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {!loading && !invoices.length && (
                                    <TableRow><TableCell colSpan={6} className="text-center text-zinc-500 py-10" data-testid="invoices-empty">No invoices yet. Convert an accepted quote to create one.</TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
}


// Dashboard wrapper: real stat cards + trend chart on top of the feature page.
export default function Invoices() {
    return (
        <>
            <div className="px-4 md:px-8 pt-6">
                <InsightsDashboard area="payments" title="Invoices & payments" subtitle="Cash collected, outstanding balances and overdue invoices." color="#059669" seriesKey="revenue" seriesFormat="usd" breakdownTitle="By provider" breakdownFormat="usd" />
            </div>
            <InvoicesBase />
        </>
    );
}
