"""One-shot migration: convert legacy 0-1 fraction rate fields to 0-100 percent scale.

Applies to fields:
- quotes.tax_rate, quotes.global_discount_percent, quotes.lines[].discount_percent, quotes.lines[].tax_rate
- invoices.tax_rate, invoices.lines[].tax_rate
- approval_rules.threshold_value (only when threshold_type='discount_percent')

Idempotent via a marker doc in `_migrations`. `subtotal_cents`, `tax_cents`, `total_cents`
are NOT recomputed — they were correct in cents under the old semantic and remain correct.

Also cleans up leftover tester bookings/contacts from the independent verification pass.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict

from ..db import get_db, utc_now_iso

logger = logging.getLogger(__name__)

MIGRATION_KEY = "phase4_percent_v2"


def _scale(val: Any) -> Any:
    """Convert a 0-1 fraction to 0-100 percent (idempotent when value already looks like a percent)."""
    if val is None:
        return val
    try:
        f = float(val)
    except (TypeError, ValueError):
        return val
    # If we already look like a percent (>= 1.0), leave it.
    if f > 1.0:
        return val
    return round(f * 100.0, 4)


async def _migrate_quotes(db) -> int:
    changed = 0
    async for q in db.quotes.find({}):
        updates: Dict[str, Any] = {}
        if q.get("tax_rate") is not None and float(q.get("tax_rate") or 0) <= 1.0:
            updates["tax_rate"] = _scale(q.get("tax_rate"))
        if q.get("global_discount_percent") is not None and float(q.get("global_discount_percent") or 0) <= 1.0:
            updates["global_discount_percent"] = _scale(q.get("global_discount_percent"))
        new_lines = []
        line_touched = False
        for line in (q.get("lines") or []):
            ln = dict(line)
            if ln.get("discount_percent") is not None and float(ln.get("discount_percent") or 0) <= 1.0:
                ln["discount_percent"] = _scale(ln.get("discount_percent")); line_touched = True
            if ln.get("tax_rate") is not None and float(ln.get("tax_rate") or 0) <= 1.0:
                ln["tax_rate"] = _scale(ln.get("tax_rate")); line_touched = True
            new_lines.append(ln)
        if line_touched:
            updates["lines"] = new_lines
        # Also fix versions[].lines snapshots for audit consistency.
        new_versions = []
        ver_touched = False
        for ver in (q.get("versions") or []):
            v = dict(ver)
            vlines = []
            for line in (v.get("lines") or []):
                ln = dict(line)
                if ln.get("discount_percent") is not None and float(ln.get("discount_percent") or 0) <= 1.0:
                    ln["discount_percent"] = _scale(ln.get("discount_percent")); ver_touched = True
                if ln.get("tax_rate") is not None and float(ln.get("tax_rate") or 0) <= 1.0:
                    ln["tax_rate"] = _scale(ln.get("tax_rate")); ver_touched = True
                vlines.append(ln)
            if vlines:
                v["lines"] = vlines
            new_versions.append(v)
        if ver_touched:
            updates["versions"] = new_versions
        if updates:
            updates["updated_at"] = utc_now_iso()
            await db.quotes.update_one({"_id": q["_id"]}, {"$set": updates})
            changed += 1
    return changed


async def _migrate_invoices(db) -> int:
    changed = 0
    async for inv in db.invoices.find({}):
        updates: Dict[str, Any] = {}
        if inv.get("tax_rate") is not None and float(inv.get("tax_rate") or 0) <= 1.0:
            updates["tax_rate"] = _scale(inv.get("tax_rate"))
        new_lines = []
        line_touched = False
        for line in (inv.get("lines") or []):
            ln = dict(line)
            if ln.get("tax_rate") is not None and float(ln.get("tax_rate") or 0) <= 1.0:
                ln["tax_rate"] = _scale(ln.get("tax_rate")); line_touched = True
            new_lines.append(ln)
        if line_touched:
            updates["lines"] = new_lines
        if updates:
            updates["updated_at"] = utc_now_iso()
            await db.invoices.update_one({"_id": inv["_id"]}, {"$set": updates})
            changed += 1
    return changed


async def _migrate_approval_rules(db) -> int:
    changed = 0
    async for rule in db.approval_rules.find({"threshold_type": "discount_percent"}):
        v = rule.get("threshold_value")
        if v is not None and float(v) <= 1.0:
            await db.approval_rules.update_one(
                {"_id": rule["_id"]},
                {"$set": {"threshold_value": _scale(v), "updated_at": utc_now_iso()}},
            )
            changed += 1
    return changed


# ---- Tester-data cleanup: remove leftover fixtures from the independent verification ----
# Patterns MUST be tester-specific — do NOT match legitimate demo contacts like
# `sara.klein@example.com` that live in seed_crm.
_TESTER_EMAIL_PATTERNS = [
    re.compile(r"^conflict\d+-", re.IGNORECASE),
    re.compile(r"^resched-", re.IGNORECASE),
    re.compile(r"^browser-test-\d+@", re.IGNORECASE),
    # Test harness in /app/backend/tests/test_phase4.py uses these prefixes
    re.compile(r"^public-book-", re.IGNORECASE),
    re.compile(r"^owner-book-", re.IGNORECASE),
    re.compile(r"^pay-flow-", re.IGNORECASE),
    re.compile(r"^portal_test_\d+@", re.IGNORECASE),
    re.compile(r"^testcust-", re.IGNORECASE),
    re.compile(r"^bookingtest-", re.IGNORECASE),
]


def _is_tester_email(email: str) -> bool:
    if not email:
        return False
    return any(p.search(email) for p in _TESTER_EMAIL_PATTERNS)


async def _cleanup_tester_data(db) -> Dict[str, int]:
    """Delete tester-authored contacts (matched by email pattern) and their bookings.
    Only runs inside orgs that own the tester contacts — no cross-tenant reach."""
    contact_ids_to_delete: list[str] = []
    async for c in db.contacts.find({}, {"emails": 1, "org_id": 1}):
        emails = c.get("emails") or []
        if any(_is_tester_email(e) for e in emails):
            contact_ids_to_delete.append(str(c["_id"]))
    counts = {"contacts": 0, "bookings": 0, "interactions": 0}
    if not contact_ids_to_delete:
        return counts
    from bson import ObjectId
    obj_ids = [ObjectId(cid) for cid in contact_ids_to_delete]
    b_res = await db.bookings.delete_many({"contact_id": {"$in": contact_ids_to_delete}})
    i_res = await db.interactions.delete_many({"contact_id": {"$in": contact_ids_to_delete}})
    c_res = await db.contacts.delete_many({"_id": {"$in": obj_ids}})
    counts["bookings"] = b_res.deleted_count
    counts["interactions"] = i_res.deleted_count
    counts["contacts"] = c_res.deleted_count
    return counts


async def run_phase4_percent_migration() -> None:
    db = get_db()
    marker = await db["_migrations"].find_one({"key": MIGRATION_KEY})
    if marker:
        # Migration ran before. Still clean up tester leftovers on each restart
        # (only ever removes docs matching the tester email patterns — safe).
        cleaned = await _cleanup_tester_data(db)
        if any(cleaned.values()):
            logger.info("Tester data cleanup: %s", cleaned)
        return
    q = await _migrate_quotes(db)
    i = await _migrate_invoices(db)
    r = await _migrate_approval_rules(db)
    cleaned = await _cleanup_tester_data(db)
    await db["_migrations"].insert_one({"key": MIGRATION_KEY, "at": utc_now_iso(),
                                        "quotes": q, "invoices": i, "rules": r,
                                        "cleanup": cleaned})
    logger.info("phase4 percent-scale migration applied: quotes=%d invoices=%d rules=%d cleanup=%s",
                q, i, r, cleaned)
