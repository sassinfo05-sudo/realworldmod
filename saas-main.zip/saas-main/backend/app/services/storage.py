"""Provider-neutral object-storage service.

One shared service that every uploaded/generated file goes through. Supports an S3-compatible
adapter (Cloudflare R2 / AWS S3 / Backblaze B2 / MinIO) and a local-filesystem adapter that is
ONLY permitted in explicit dev/test mode. Production refuses to use container-local storage as
permanent storage.

Provider credentials live in `platform_settings.storage` (Staff/Founder Setup Center), are
encrypted at rest (secretbox), masked in every response, and never logged.

Object keys are tenant-scoped and non-guessable: org/{org_id}/{asset_id}/{variant}
"""
from __future__ import annotations

import hashlib
import hmac
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, Optional

from .. import config
from ..db import get_db, utc_now_iso
from . import secretbox

# Fields whose change targets a *different* physical location → a new immutable config version so
# assets written under the old provider keep resolving through the old provider after a switch.
TARGET_FIELDS = ("provider", "bucket", "endpoint", "region", "public_base_url",
                 "access_key_id", "secret_access_key")
CONFIG_VERSIONS = "storage_config_versions"


class StorageError(Exception):
    def __init__(self, code: str, message: str = ""):
        self.code = code
        self.message = message or code
        super().__init__(self.message)


def object_key(org_id: str, asset_id: str, variant: str = "original") -> str:
    return f"org/{org_id}/{asset_id}/{variant}"


# --------------------------------------------------------------------------- adapters
class LocalFilesystemAdapter:
    """Dev/test only. Stores bytes on the container disk (NOT durable in production)."""
    provider = "local"

    def __init__(self, base: Optional[str] = None):
        # Default to a repo-relative, always-writable path (NOT a hardcoded /app path, which does
        # not exist on CI runners). If the chosen base is not writable, fall back to a temp dir so
        # dev/test uploads never fail with a spurious provider error.
        default = os.environ.get("LOCAL_STORAGE_DIR") or str(
            Path(__file__).resolve().parents[2] / "var" / "storage"
        )
        self.base = base or default
        try:
            os.makedirs(self.base, exist_ok=True)
            probe = os.path.join(self.base, ".writable")
            with open(probe, "w") as f:
                f.write("ok")
            os.remove(probe)
        except Exception:  # noqa: BLE001
            self.base = os.path.join(tempfile.gettempdir(), "zanelvo-storage")
            os.makedirs(self.base, exist_ok=True)

    def _p(self, key: str) -> str:
        p = os.path.join(self.base, key)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        return p

    async def put(self, key: str, data: bytes, content_type: Optional[str] = None) -> Dict[str, Any]:
        with open(self._p(key), "wb") as f:
            f.write(data)
        return {"key": key, "size": len(data)}

    async def get(self, key: str) -> bytes:
        try:
            with open(self._p(key), "rb") as f:
                return f.read()
        except FileNotFoundError:
            raise StorageError("not_found", "object missing")

    async def head(self, key: str) -> Dict[str, Any]:
        p = self._p(key)
        if not os.path.exists(p):
            return {"exists": False}
        return {"exists": True, "size": os.path.getsize(p)}

    async def copy(self, src: str, dst: str) -> None:
        await self.put(dst, await self.get(src))

    async def delete(self, key: str) -> bool:
        try:
            os.remove(self._p(key))
            return True
        except FileNotFoundError:
            return False

    def public_url(self, key: str) -> str:
        # Served by the app's public blob endpoint (local mode only).
        return f"/api/public/assets/{key}"

    def signed_url(self, key: str, ttl: int = 600) -> str:
        exp = int(time.time()) + int(ttl)
        sig = _sign(f"{key}:{exp}")
        return f"/api/assets/blob/{key}?exp={exp}&sig={sig}"

    async def health(self) -> Dict[str, Any]:
        try:
            os.makedirs(self.base, exist_ok=True)
            t = os.path.join(self.base, ".health")
            with open(t, "w") as f:
                f.write("ok")
            os.remove(t)
            return {"status": "sandbox", "provider": "local", "writable": True}
        except Exception as e:  # noqa: BLE001
            return {"status": "error", "provider": "local", "error": str(e)[:120]}


class S3CompatibleAdapter:
    """S3-compatible (R2/S3/B2/MinIO). boto3 lazy-imported; used only when configured."""

    def __init__(self, cfg: Dict[str, Any]):
        self.provider = cfg.get("provider") or "s3"
        self.bucket = cfg.get("bucket") or ""
        self.endpoint = cfg.get("endpoint") or None
        self.region = cfg.get("region") or "auto"
        self.public_base = (cfg.get("public_base_url") or "").rstrip("/")
        self._ak = cfg.get("access_key_id") or ""
        self._sk = cfg.get("secret_access_key") or ""

    def _client(self):
        import boto3  # lazy
        return boto3.client("s3", endpoint_url=self.endpoint, region_name=self.region,
                            aws_access_key_id=self._ak, aws_secret_access_key=self._sk)

    async def put(self, key: str, data: bytes, content_type: Optional[str] = None) -> Dict[str, Any]:
        self._client().put_object(Bucket=self.bucket, Key=key, Body=data,
                                  ContentType=content_type or "application/octet-stream")
        return {"key": key, "size": len(data)}

    async def get(self, key: str) -> bytes:
        return self._client().get_object(Bucket=self.bucket, Key=key)["Body"].read()

    async def head(self, key: str) -> Dict[str, Any]:
        try:
            h = self._client().head_object(Bucket=self.bucket, Key=key)
            return {"exists": True, "size": h["ContentLength"]}
        except Exception:  # noqa: BLE001
            return {"exists": False}

    async def copy(self, src: str, dst: str) -> None:
        self._client().copy_object(Bucket=self.bucket, Key=dst,
                                   CopySource={"Bucket": self.bucket, "Key": src})

    async def delete(self, key: str) -> bool:
        self._client().delete_object(Bucket=self.bucket, Key=key)
        return True

    def public_url(self, key: str) -> str:
        if self.public_base:
            return f"{self.public_base}/{key}"
        if self.endpoint:
            return f"{self.endpoint.rstrip('/')}/{self.bucket}/{key}"
        return f"https://{self.bucket}.s3.{self.region}.amazonaws.com/{key}"

    def signed_url(self, key: str, ttl: int = 600) -> str:
        return self._client().generate_presigned_url(
            "get_object", Params={"Bucket": self.bucket, "Key": key}, ExpiresIn=int(ttl))

    async def health(self) -> Dict[str, Any]:
        try:
            self._client().head_bucket(Bucket=self.bucket)
            return {"status": "connected", "provider": self.provider, "bucket": self.bucket}
        except Exception as e:  # noqa: BLE001
            return {"status": "error", "provider": self.provider, "error": str(e)[:160]}


class _DisabledProvider:
    provider = "disabled"

    async def put(self, *a, **k):
        raise StorageError("storage_not_configured",
                           "Object storage is not configured. Connect a provider in the Setup Center.")
    async def get(self, *a, **k):
        raise StorageError("not_found")
    async def head(self, *a, **k):
        return {"exists": False}
    async def copy(self, *a, **k):
        raise StorageError("storage_not_configured")
    async def delete(self, *a, **k):
        return False
    def public_url(self, key):
        return f"/api/public/assets/{key}"
    def signed_url(self, key, ttl=600):
        return f"/api/public/assets/{key}"
    async def health(self):
        return {"status": "not_connected", "provider": "none"}


# --------------------------------------------------------------------------- config + factory
STORAGE_FIELDS_SECRET = ("access_key_id", "secret_access_key")


async def get_storage_config(*, decrypt: bool = False) -> Dict[str, Any]:
    doc = await get_db().platform_settings.find_one({"key": "primary"}, {"storage": 1}) or {}
    cfg = dict((doc.get("storage") or {}))
    if decrypt:
        for f in STORAGE_FIELDS_SECRET:
            if cfg.get(f):
                cfg[f] = secretbox.decrypt(cfg[f]) if secretbox.is_encrypted(cfg[f]) else cfg[f]
    return cfg


def _is_configured(cfg: Dict[str, Any]) -> bool:
    return bool(cfg.get("provider") and cfg.get("provider") != "local"
                and cfg.get("bucket") and cfg.get("access_key_id") and cfg.get("secret_access_key"))


async def get_provider():
    cfg = await get_storage_config(decrypt=True)
    if _is_configured(cfg):
        return S3CompatibleAdapter(cfg)
    # Not configured with a real provider.
    if config.is_production():
        return _DisabledProvider()  # production refuses container-local permanent storage
    return LocalFilesystemAdapter()


async def current_config_version() -> int:
    """Version of the ACTIVE storage config. Incremented whenever the physical target changes."""
    cfg = await get_storage_config(decrypt=False)
    return int(cfg.get("config_version") or 0)


async def save_storage_config(patch_encrypted: Dict[str, Any]) -> Dict[str, Any]:
    """Merge a (secret-encrypted) config patch. If the physical target changed, mint a NEW immutable
    config version and snapshot it so assets written under prior versions stay readable after a switch."""
    db = get_db()
    prev = await get_storage_config(decrypt=False)
    cur = dict(prev)
    cur.update(patch_encrypted)
    changed = any(prev.get(k) != cur.get(k) for k in TARGET_FIELDS)
    version = int(cur.get("config_version") or 0)
    if changed:
        version += 1
        cur["config_version"] = version
        snap = {k: cur.get(k) for k in TARGET_FIELDS}
        snap["config_version"] = version
        await db[CONFIG_VERSIONS].update_one(
            {"version": version},
            {"$set": {"version": version, "config": snap, "created_at": utc_now_iso()}}, upsert=True)
    await db.platform_settings.update_one({"key": "primary"}, {"$set": {"storage": cur}}, upsert=True)
    return cur


async def get_provider_for(asset: Dict[str, Any]):
    """Resolve, read, sign and delete an asset through the EXACT provider/bucket it was written to
    (recorded on the asset), NOT the tenant's current provider — so switching providers never
    breaks previously uploaded assets. Secrets come from the recorded config version."""
    prov_name = (asset or {}).get("provider")
    if not prov_name or prov_name == "local":
        if config.is_production():
            return _DisabledProvider()
        return LocalFilesystemAdapter()
    cfg: Optional[Dict[str, Any]] = None
    ver = asset.get("provider_config_version")
    if ver is not None:
        vdoc = await get_db()[CONFIG_VERSIONS].find_one({"version": int(ver)}, {"_id": 0})
        if vdoc:
            cfg = dict(vdoc.get("config") or {})
    if cfg is None:
        cfg = await get_storage_config(decrypt=False)
    for f in STORAGE_FIELDS_SECRET:
        if cfg.get(f) and secretbox.is_encrypted(cfg[f]):
            cfg[f] = secretbox.decrypt(cfg[f])
    # The asset's own recorded target is immutable and authoritative.
    cfg = {**cfg, "provider": prov_name,
           "bucket": asset.get("bucket") or cfg.get("bucket"),
           "endpoint": asset.get("endpoint") or cfg.get("endpoint"),
           "region": asset.get("region") or cfg.get("region"),
           "public_base_url": asset.get("public_base") or cfg.get("public_base_url")}
    if not (cfg.get("bucket") and cfg.get("access_key_id") and cfg.get("secret_access_key")):
        return _DisabledProvider()
    return S3CompatibleAdapter(cfg)


async def provider_status() -> Dict[str, Any]:
    cfg = await get_storage_config(decrypt=True)
    prov = await get_provider()
    health = await prov.health()
    return {
        "provider": cfg.get("provider") or ("local" if not config.is_production() else "none"),
        "bucket": cfg.get("bucket") or None,
        "endpoint": cfg.get("endpoint") or None,
        "public_base_url": cfg.get("public_base_url") or None,
        "configured": _is_configured(cfg),
        "status": health.get("status"),
        "health": health,
        "is_production": config.is_production(),
    }


def mask_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    out = {}
    for k, v in (cfg or {}).items():
        if k in STORAGE_FIELDS_SECRET and v:
            out[k] = "\u2022\u2022\u2022\u2022 (set)"
        else:
            out[k] = v
    return out


# --------------------------------------------------------------------------- signing (local mode)
def _sign(payload: str) -> str:
    key = (os.environ.get("JWT_SECRET") or "zanelvo").encode()
    return hmac.new(key, payload.encode(), hashlib.sha256).hexdigest()[:32]


def verify_signed(key: str, exp: str, sig: str) -> bool:
    try:
        if int(exp) < int(time.time()):
            return False
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(_sign(f"{key}:{exp}"), sig or "")
