"""Phase 5 backend tests — Knowledge Base, AI Employees, Agent Studio, Chat Widget,
Call Simulator, Kill Switch, Cross-org isolation."""
from __future__ import annotations

import os
import time
import uuid
from datetime import date, timedelta

import pytest
import requests
from tests import _creds as _CREDS  # creds from env / test_credentials.md

BASE_URL = _CREDS.BASE_URL
OWNER_EMAIL = _CREDS.OWNER_EMAIL
OWNER_PW = _CREDS.OWNER_PASSWORD
FOUNDER_EMAIL = _CREDS.FOUNDER_EMAIL
FOUNDER_PW = _CREDS.FOUNDER_PASSWORD
SITE_SLUG = "demo-home-services"
LLM_TIMEOUT = 90  # LLM calls can take 2-6s but we allow room for tool loops


# -------- Fixtures --------

@pytest.fixture(scope="module")
def owner_token():
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": OWNER_EMAIL, "password": OWNER_PW}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def owner_headers(owner_token):
    return {"Authorization": f"Bearer {owner_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def receptionist_agent(owner_headers):
    r = requests.get(f"{BASE_URL}/api/ai/agents", headers=owner_headers, timeout=30)
    assert r.status_code == 200, r.text
    agents = r.json()["agents"]
    rec = next((a for a in agents if a.get("agent_type") == "receptionist"), None)
    assert rec, f"no receptionist agent in {[a['agent_type'] for a in agents]}"
    return rec


def _start_widget():
    r = requests.post(f"{BASE_URL}/api/public/chat/start",
                      json={"website_slug": SITE_SLUG}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()


def _widget_msg(token, message):
    r = requests.post(f"{BASE_URL}/api/public/chat/message",
                      json={"session_token": token, "message": message},
                      timeout=LLM_TIMEOUT)
    return r


# -------- Kill switch (helper to ensure ON before other tests) --------

def _ensure_ai_on(owner_headers):
    requests.put(f"{BASE_URL}/api/ai/kill-switch",
                 json={"ai_enabled": True, "reason": "test-restore"},
                 headers=owner_headers, timeout=30)


# ================================================================
# ACCEPTANCE 1a & 1b — Grounded pricing + honest I-don't-know
# ================================================================

class TestGroundedAnswers:
    def test_grounded_price_answer(self, owner_headers):
        _ensure_ai_on(owner_headers)
        s = _start_widget()
        r = _widget_msg(s["session_token"], "How much for a drain unblock?")
        assert r.status_code == 200, r.text
        data = r.json()
        reply = (data.get("reply") or "").lower()
        # Must contain a specific price. Catalog price is $220 currently.
        assert "220" in reply, f"Expected catalog price 220 in reply. Got: {data.get('reply')}"
        # Must not be a raw tool_call surfaced to end user
        assert data.get("action") in ("answer", None), f"expected action=answer, got {data.get('action')}"

    def test_honest_i_dont_know(self, owner_headers):
        _ensure_ai_on(owner_headers)
        s = _start_widget()
        r = _widget_msg(s["session_token"], "Do you install hot tubs from Sweden?")
        assert r.status_code == 200, r.text
        data = r.json()
        reply = (data.get("reply") or "").lower()
        # Must not invent a Swedish hot tub price. Model may list actual catalog
        # services as alternatives — that's fine. What we forbid is claiming to
        # install hot tubs with a fabricated price.
        assert "sweden" not in reply or "yes" not in reply.split(".")[0], \
            f"Reply implies we install Swedish hot tubs: {data.get('reply')}"
        # Should decline (contain a negative / offer)
        assert any(k in reply for k in ["don't", "do not", "not offer", "unable",
                                          "not a service", "we simply don't",
                                          "message", "follow up", "team"]), \
            f"Should decline. Reply: {data.get('reply')}"


# ================================================================
# ACCEPTANCE 2 — Real booking through chat
# ================================================================

class TestBookingThroughChat:
    def test_booking_via_chat_creates_db_record(self, owner_headers):
        _ensure_ai_on(owner_headers)
        # count bookings before
        before = requests.get(f"{BASE_URL}/api/booking/bookings",
                              headers=owner_headers, timeout=30)
        assert before.status_code == 200, before.text
        prior = before.json()
        prior_count = len(prior if isinstance(prior, list) else prior.get("bookings", []))

        s = _start_widget()
        # Pick a WEEKDAY (Mon..Fri) 3-7 days out so staff working hours cover it.
        target_d = date.today() + timedelta(days=3)
        while target_d.weekday() >= 5:
            target_d += timedelta(days=1)
        target = target_d.isoformat()
        unique = f"testcust-{uuid.uuid4().hex[:8]}@example.com"
        name = f"TEST Chat User {uuid.uuid4().hex[:4]}"
        msg = (f"Please book a drain unblock any time on {target}. "
               f"Name: {name}. Email: {unique}. Phone: 555-0199. "
               "Please pick the first available slot and confirm.")
        r = _widget_msg(s["session_token"], msg)
        assert r.status_code == 200, r.text
        data = r.json()
        # Give server a moment for DB writes
        time.sleep(1)

        result = data.get("result") or {}
        booking_id = (result.get("booking_id") or data.get("booking_id"))
        # Not all agents return booking_id at top level; check tool_calls too
        tool_calls = data.get("tool_calls") or []
        booked = booking_id or any(
            t.get("name") == "create_booking" and t.get("ok") for t in tool_calls
        )
        if not booked:
            pytest.fail(f"No booking created via chat. Response: {data}")

        # Verify DB has a new booking with source ai_chat
        after = requests.get(f"{BASE_URL}/api/booking/bookings",
                             headers=owner_headers, timeout=30)
        after_list = after.json() if isinstance(after.json(), list) else after.json().get("bookings", [])
        assert len(after_list) > prior_count, "booking count did not increase"

        ai_bookings = [b for b in after_list if b.get("source") == "ai_chat"]
        assert ai_bookings, f"no bookings with source=ai_chat found; sample: {after_list[:2]}"

        # Verify contact was auto-created (search by email)
        contacts_r = requests.get(f"{BASE_URL}/api/crm/contacts",
                                  headers=owner_headers, timeout=30, params={"q": unique})
        # Contact search may or may not be implemented; just make it soft
        if contacts_r.status_code == 200:
            body = contacts_r.json()
            contacts = body if isinstance(body, list) else body.get("contacts", [])
            found = [c for c in contacts if unique in (c.get("emails") or [])]
            assert found, f"Contact with {unique} not auto-created"


# ================================================================
# ACCEPTANCE 3 — Server-enforced human takeover
# ================================================================

class TestHumanTakeover:
    def test_takeover_pauses_ai_and_resume_restores(self, owner_headers):
        _ensure_ai_on(owner_headers)
        s = _start_widget()
        token = s["session_token"]
        cid = s["conversation_id"]

        # First AI turn to make sure conv is active
        r = _widget_msg(token, "Hi, do you have plumbing?")
        assert r.status_code == 200, r.text

        # Owner takeover
        t = requests.post(f"{BASE_URL}/api/ai/conversations/{cid}/takeover",
                          headers=owner_headers,
                          json={"reply": "Hi from a human"}, timeout=30)
        assert t.status_code == 200, t.text

        # Now visitor posts — must be paused
        r2 = _widget_msg(token, "Are you still there?")
        assert r2.status_code == 200, r2.text
        d2 = r2.json()
        assert d2.get("paused") is True, f"expected paused=true, got {d2}"

        # Resume
        res = requests.post(f"{BASE_URL}/api/ai/conversations/{cid}/resume",
                            headers=owner_headers, timeout=30)
        assert res.status_code == 200, res.text

        # Visitor msg → should get AI reply again
        r3 = _widget_msg(token, "What are your hours?")
        assert r3.status_code == 200, r3.text
        d3 = r3.json()
        assert not d3.get("paused"), f"should not be paused after resume: {d3}"
        assert d3.get("reply"), f"expected AI reply after resume, got {d3}"


# ================================================================
# ACCEPTANCE 4 — Agent Studio versioning, rollback, sandbox, kill switch
# ================================================================

class TestAgentStudio:
    def test_disable_booking_tool_prevents_booking_and_rollback_restores(self, owner_headers, receptionist_agent):
        _ensure_ai_on(owner_headers)
        agent_id = receptionist_agent["id"]
        # Fetch agent detail
        r = requests.get(f"{BASE_URL}/api/ai/agents/{agent_id}",
                         headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        detail = r.json()
        versions = detail.get("versions", [])
        assert versions, "no versions"
        original_live = next((v for v in versions if v.get("is_live")), versions[0])
        original_version_id = original_live["id"]

        # Create a new version WITHOUT create_booking / get_availability
        original_tools = original_live.get("allowed_tools") or []
        limited_tools = [t for t in original_tools
                         if t not in ("create_booking", "get_availability")]
        # ensure some tools are still allowed to avoid empty list issues
        if not limited_tools:
            limited_tools = ["get_services", "take_message"]

        new_ver_req = {
            "label": "TEST no-booking",
            "purpose": original_live.get("purpose") or "Answer customer questions",
            "tone": original_live.get("tone"),
            "languages": original_live.get("languages") or ["en"],
            "allowed_tools": limited_tools,
            "qualification_questions": original_live.get("qualification_questions") or [],
            "escalation_rules": original_live.get("escalation_rules") or [],
            "allowed_claims": original_live.get("allowed_claims"),
            "confidence_threshold": original_live.get("confidence_threshold", 0.4),
            "require_approval": bool(original_live.get("require_approval")),
            "system_prompt_override": original_live.get("system_prompt_override"),
            "model": original_live.get("model") or "claude-sonnet-4-6",
            "promote_to_live": True,
        }
        cr = requests.post(f"{BASE_URL}/api/ai/agents/{agent_id}/versions",
                           headers=owner_headers, json=new_ver_req, timeout=30)
        assert cr.status_code == 200, cr.text
        new_ver_id = cr.json()["id"]

        # Verify listing shows both versions and is_live on new one
        gd = requests.get(f"{BASE_URL}/api/ai/agents/{agent_id}",
                          headers=owner_headers, timeout=30).json()
        gv = {v["id"]: v for v in gd["versions"]}
        assert gv[new_ver_id]["is_live"] is True
        assert gv[original_version_id]["is_live"] is False
        assert len(gd["versions"]) >= 2

        # Count bookings before
        before = requests.get(f"{BASE_URL}/api/booking/bookings",
                              headers=owner_headers, timeout=30).json()
        before_list = before if isinstance(before, list) else before.get("bookings", [])
        prior = len(before_list)

        # Try to book via widget — should NOT create
        s = _start_widget()
        target = (date.today() + timedelta(days=5)).isoformat()
        unique = f"testcust-{uuid.uuid4().hex[:8]}@example.com"
        r = _widget_msg(s["session_token"],
                        f"Book drain unblock {target} 11:00. Name TEST User. "
                        f"Email {unique}. Phone 555-0100.")
        assert r.status_code == 200, r.text
        data = r.json()
        tool_calls = data.get("tool_calls") or []
        assert not any(t.get("name") == "create_booking" for t in tool_calls), \
            f"create_booking should not be called: {tool_calls}"

        after = requests.get(f"{BASE_URL}/api/booking/bookings",
                             headers=owner_headers, timeout=30).json()
        after_list = after if isinstance(after, list) else after.get("bookings", [])
        assert len(after_list) == prior, "booking count changed — tool restriction failed"

        # Rollback
        rb = requests.post(f"{BASE_URL}/api/ai/agents/{agent_id}/promote/{original_version_id}",
                           headers=owner_headers, timeout=30)
        assert rb.status_code == 200, rb.text

        gd2 = requests.get(f"{BASE_URL}/api/ai/agents/{agent_id}",
                           headers=owner_headers, timeout=30).json()
        gv2 = {v["id"]: v for v in gd2["versions"]}
        assert gv2[original_version_id]["is_live"] is True

    def test_sandbox_never_writes_to_crm(self, owner_headers, receptionist_agent):
        _ensure_ai_on(owner_headers)
        # Count bookings before
        before = requests.get(f"{BASE_URL}/api/booking/bookings",
                              headers=owner_headers, timeout=30).json()
        before_list = before if isinstance(before, list) else before.get("bookings", [])
        prior = len(before_list)

        target = (date.today() + timedelta(days=6)).isoformat()
        unique = f"sandbox+{uuid.uuid4().hex[:8]}@example.com"
        r = requests.post(f"{BASE_URL}/api/ai/sandbox/message",
                          headers=owner_headers, timeout=LLM_TIMEOUT,
                          json={"agent_id": receptionist_agent["id"],
                                "message": f"Book drain unblock {target} 12:00. Name TEST. "
                                           f"Email {unique}. Phone 555-0111."})
        assert r.status_code == 200, r.text

        after = requests.get(f"{BASE_URL}/api/booking/bookings",
                             headers=owner_headers, timeout=30).json()
        after_list = after if isinstance(after, list) else after.get("bookings", [])
        assert len(after_list) == prior, \
            f"Sandbox created a booking (invariant violation). before={prior}, after={len(after_list)}"

    def test_kill_switch_disables_widget_and_can_reenable(self, owner_headers):
        # Turn OFF
        r = requests.put(f"{BASE_URL}/api/ai/kill-switch",
                         headers=owner_headers,
                         json={"ai_enabled": False, "reason": "testing"}, timeout=30)
        assert r.status_code == 200, r.text
        # Widget should be disabled
        s = requests.post(f"{BASE_URL}/api/public/chat/start",
                          json={"website_slug": SITE_SLUG}, timeout=30)
        assert s.status_code == 200, s.text
        body = s.json()
        assert body.get("disabled") is True
        assert "session_token" not in body
        assert "paus" in (body.get("greeting") or "").lower()

        # Turn back on
        r = requests.put(f"{BASE_URL}/api/ai/kill-switch",
                         headers=owner_headers,
                         json={"ai_enabled": True, "reason": "restore"}, timeout=30)
        assert r.status_code == 200

        s2 = requests.post(f"{BASE_URL}/api/public/chat/start",
                           json={"website_slug": SITE_SLUG}, timeout=30)
        assert s2.status_code == 200
        assert s2.json().get("session_token"), "widget should be enabled again"


# ================================================================
# ACCEPTANCE 5 — Call simulator E2E
# ================================================================

class TestCallSimulator:
    def test_call_e2e_produces_record_with_transcript(self, owner_headers):
        _ensure_ai_on(owner_headers)
        r = requests.post(f"{BASE_URL}/api/ai/call/start",
                          headers=owner_headers,
                          json={"caller_name": "TEST Caller",
                                "caller_phone": "555-0123"}, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        cid = d["conversation_id"]
        call_id = d["call_record_id"]
        assert cid and call_id

        for msg in ["Hi, do you unblock drains?", "How much?", "OK thanks"]:
            tr = requests.post(f"{BASE_URL}/api/ai/call/turn",
                               headers=owner_headers,
                               json={"call_record_id": call_id,
                                     "caller_message": msg}, timeout=LLM_TIMEOUT)
            assert tr.status_code == 200, tr.text

        er = requests.post(f"{BASE_URL}/api/ai/call/end",
                           headers=owner_headers,
                           json={"call_record_id": call_id,
                                 "duration_seconds": 60}, timeout=30)
        assert er.status_code == 200, er.text

        # GET call
        gc = requests.get(f"{BASE_URL}/api/ai/calls/{call_id}",
                          headers=owner_headers, timeout=30)
        assert gc.status_code == 200, gc.text
        rec = gc.json()
        assert rec.get("transcript"), "transcript empty"
        assert rec.get("ai_summary"), "ai_summary empty"
        assert rec.get("outcome") in ("booked", "took_message", "no_action", "escalated")
        assert (rec.get("cost_cents") or 0) >= 0
        assert rec.get("simulated") is True

        # Conversation appears in list with channel=call
        conv_list = requests.get(f"{BASE_URL}/api/ai/conversations",
                                 headers=owner_headers, timeout=30).json()
        convs = conv_list.get("conversations", [])
        assert any(c["id"] == cid and c.get("channel") == "call" for c in convs), \
            "call conversation missing from list"


# ================================================================
# ACCEPTANCE 6 — Audit fields & cross-org isolation
# ================================================================

class TestAuditAndIsolation:
    def test_conversation_interactions_have_audit_fields(self, owner_headers):
        _ensure_ai_on(owner_headers)
        s = _start_widget()
        r = _widget_msg(s["session_token"], "What services do you offer?")
        assert r.status_code == 200
        cid = s["conversation_id"]
        cr = requests.get(f"{BASE_URL}/api/ai/conversations/{cid}",
                          headers=owner_headers, timeout=30)
        assert cr.status_code == 200, cr.text
        interactions = cr.json().get("interactions") or []
        assert interactions, "no interactions logged"
        i0 = interactions[0]
        for f in ("action", "model", "total_tokens", "cost_cents",
                  "latency_ms", "tools_used"):
            assert f in i0, f"missing field {f} in interaction {i0}"

    def test_usage_rollup(self, owner_headers):
        r = requests.get(f"{BASE_URL}/api/ai/usage?days=1",
                         headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "total" in d and "per_agent" in d
        assert d["total"]["interactions"] >= 0

    def test_public_widget_rejects_bad_slug(self):
        r = requests.post(f"{BASE_URL}/api/public/chat/start",
                          json={"website_slug": "nonexistent-slug-xyz"}, timeout=30)
        assert r.status_code == 404, r.text

    def test_knowledge_sources_scoped(self, owner_headers):
        r = requests.get(f"{BASE_URL}/api/ai/knowledge/sources",
                         headers=owner_headers, timeout=30)
        assert r.status_code == 200
        # All results have to be owner's org — but we can't assert that from black-box, we can just verify structure
        assert "sources" in r.json()


# ================================================================
# Knowledge base CRUD
# ================================================================

class TestKnowledgeCRUD:
    def test_faq_crud_and_refresh(self, owner_headers):
        title = f"TEST_FAQ_{uuid.uuid4().hex[:6]}"
        # create
        r = requests.post(f"{BASE_URL}/api/ai/knowledge/faq",
                          headers=owner_headers,
                          json={"title": title,
                                "body": "This is a test FAQ body."}, timeout=30)
        assert r.status_code == 200, r.text
        sid = r.json()["id"]

        # list — includes new
        lr = requests.get(f"{BASE_URL}/api/ai/knowledge/sources",
                          headers=owner_headers, timeout=30).json()
        assert any(s["id"] == sid for s in lr["sources"])

        # exclude
        pr = requests.patch(f"{BASE_URL}/api/ai/knowledge/sources/{sid}",
                            headers=owner_headers,
                            json={"status": "excluded"}, timeout=30)
        assert pr.status_code == 200, pr.text
        lr2 = requests.get(f"{BASE_URL}/api/ai/knowledge/sources",
                           headers=owner_headers, timeout=30).json()
        item = next(s for s in lr2["sources"] if s["id"] == sid)
        assert item["status"] == "excluded"

        # delete
        dr = requests.delete(f"{BASE_URL}/api/ai/knowledge/sources/{sid}",
                             headers=owner_headers, timeout=30)
        assert dr.status_code == 200, dr.text
        gr = requests.get(f"{BASE_URL}/api/ai/knowledge/sources/{sid}",
                          headers=owner_headers, timeout=30)
        assert gr.status_code == 404

    def test_refresh_ingests_pages(self, owner_headers):
        r = requests.post(f"{BASE_URL}/api/ai/knowledge/refresh",
                          headers=owner_headers, timeout=60)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("website_pages_ingested", 0) >= 4, \
            f"expected >=4 pages ingested, got {d.get('website_pages_ingested')}"
        assert d.get("structured_facts_id"), "no structured_facts_id"


# ================================================================
# Voice providers honest state
# ================================================================

class TestVoiceProviders:
    def test_providers_return_not_connected(self, owner_headers):
        r = requests.get(f"{BASE_URL}/api/ai/voice/providers",
                         headers=owner_headers, timeout=30)
        assert r.status_code == 200, r.text
        provs = {p["key"]: p for p in r.json()["providers"]}
        for k in ("retell", "twilio"):
            assert k in provs
            assert provs[k]["is_connected"] is False
            assert "not connected" in provs[k]["honest_status"].lower()
