import { Check } from "lucide-react";

export default function AboutSplitBlock({ block, theme }) {
    const { props = {} } = block;
    const { eyebrow, headline, body, bullets = [], image } = props;

    return (
        <section className="py-20" style={{ backgroundColor: theme?.background }}>
            <div className="mx-auto max-w-6xl px-6 grid md:grid-cols-2 gap-12 items-center">
                {image && (
                    <div className="rounded-2xl overflow-hidden border" style={{ borderColor: `${theme?.foreground}14` }}>
                        <img src={image} alt={props.image_alt || ""} className="w-full h-80 md:h-[440px] object-cover" />
                    </div>
                )}
                <div>
                    {eyebrow && (
                        <div className="text-xs uppercase tracking-[0.24em] mb-3"
                             style={{ color: theme?.primary }}>{eyebrow}</div>
                    )}
                    {headline && (
                        <h2 data-heading className="text-3xl md:text-4xl font-semibold leading-tight">
                            {headline}
                        </h2>
                    )}
                    {body && (
                        <p className="mt-5 text-base leading-relaxed" style={{ color: `${theme?.foreground}B0` }}>
                            {body}
                        </p>
                    )}
                    {bullets.length > 0 && (
                        <ul className="mt-6 space-y-3">
                            {bullets.map((b, i) => (
                                <li key={i} className="flex items-start gap-3">
                                    <span className="mt-0.5 w-5 h-5 rounded-full flex items-center justify-center"
                                          style={{ background: `${theme?.primary}14`, color: theme?.primary }}>
                                        <Check className="w-3 h-3" />
                                    </span>
                                    <span>{b}</span>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </section>
    );
}
