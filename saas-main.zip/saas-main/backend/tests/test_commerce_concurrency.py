"""Deterministic concurrency tests for commerce inventory + gift-card redemption.

No network / LLM. Proves:
  1. Concurrent gift-card redemptions across DISTINCT orders never over-redeem the balance.
  2. Concurrent redemptions for the SAME order are idempotent (charged once).
  3. Concurrent paid-order stock decrements never drive stock negative (oversell is clamped).

Run: cd /app/backend && python tests/test_commerce_concurrency.py
"""
import asyncio
import os
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))
except Exception:  # noqa: BLE001
    pass

from app.db import get_db, utc_now_iso  # noqa: E402
from app.routes.gift_cards import redeem_gift_card  # noqa: E402


async def _mk_card(org, balance):
    code = "GC" + uuid.uuid4().hex[:10].upper()
    await get_db().gift_cards.insert_one({
        "_id": uuid.uuid4().hex, "org_id": org, "code": code, "active": True,
        "initial_cents": balance, "balance_cents": balance, "currency": "USD",
        "history": [], "created_at": utc_now_iso(), "updated_at": utc_now_iso()})
    return code


async def scenario_giftcard_distinct_orders():
    org = f"gc-{uuid.uuid4()}"
    code = await _mk_card(org, 1000)
    # 10 concurrent redemptions of 300 each, DISTINCT orders → at most floor(1000/300)=3 full,
    # plus a partial for the remainder. Total redeemed must equal 1000 exactly, balance 0, never <0.
    results = await asyncio.gather(*[
        redeem_gift_card(get_db(), org, code, 300, f"order-{i}") for i in range(10)])
    g = await get_db().gift_cards.find_one({"org_id": org, "code": code})
    total = sum(results)
    bal = int(g["balance_cents"])
    await get_db().gift_cards.delete_many({"org_id": org})
    print(f"[GC DISTINCT]  redeemed_total=${total/100:.2f} final_balance=${bal/100:.2f} results={results}")
    assert bal >= 0, "gift-card balance went negative"
    assert total + bal == 1000, f"value not conserved: {total} + {bal} != 1000"
    assert total <= 1000, "over-redeemed the card"
    return total, bal


async def scenario_giftcard_same_order_idempotent():
    org = f"gc-{uuid.uuid4()}"
    code = await _mk_card(org, 1000)
    # 10 concurrent redemptions of 300 for the SAME order → charged exactly once (300).
    results = await asyncio.gather(*[
        redeem_gift_card(get_db(), org, code, 300, "order-SAME") for _ in range(10)])
    g = await get_db().gift_cards.find_one({"org_id": org, "code": code})
    redemptions = [h for h in g.get("history", []) if h.get("reason") == "redeemed"]
    bal = int(g["balance_cents"])
    await get_db().gift_cards.delete_many({"org_id": org})
    print(f"[GC SAME-ORDER] redemption_rows={len(redemptions)} final_balance=${bal/100:.2f}")
    assert len(redemptions) == 1, "same order redeemed more than once (not idempotent)"
    assert bal == 700, f"balance wrong: {bal}"
    return len(redemptions), bal


async def _decrement(org, pid, qty):
    """Exact atomic decrement used in store._finalize_paid_order."""
    db = get_db()
    r = await db.store_products.update_one(
        {"_id": pid, "org_id": org, "stock": {"$gte": qty}},
        {"$inc": {"stock": -qty}})
    return r.matched_count == 1  # True = decremented, False = would-oversell (clamped elsewhere)


async def scenario_inventory_no_oversell():
    org = f"inv-{uuid.uuid4()}"
    pid = uuid.uuid4().hex
    db = get_db()
    await db.store_products.insert_one({"_id": pid, "org_id": org, "stock": 5, "name": "Limited"})
    # 12 concurrent buyers each want 1 unit; only 5 in stock.
    results = await asyncio.gather(*[_decrement(org, pid, 1) for _ in range(12)])
    g = await db.store_products.find_one({"_id": pid})
    stock = int(g["stock"])
    ok = sum(1 for r in results if r)
    await db.store_products.delete_many({"org_id": org})
    print(f"[INVENTORY]    successful_decrements={ok} final_stock={stock} (started 5)")
    assert stock >= 0, "stock went negative (oversold)"
    assert ok == 5, f"expected exactly 5 successful decrements, got {ok}"
    assert stock == 0
    return ok, stock


async def main():
    print("=== Commerce concurrency proof ===")
    await scenario_giftcard_distinct_orders()
    await scenario_giftcard_same_order_idempotent()
    await scenario_inventory_no_oversell()
    print("ALL COMMERCE CONCURRENCY ASSERTIONS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
