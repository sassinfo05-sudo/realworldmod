import { useEffect, useMemo, useRef, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { RefreshCw, Upload, Plus, FileText, Globe2, ShieldCheck, ScrollText, AlertTriangle, Trash2 } from "lucide-react";

const KIND_ICON = {
    website_page: Globe2,
    faq: ScrollText,
    policy: ShieldCheck,
    upload: FileText,
    structured_facts: ShieldCheck,
};

const KIND_LABEL = {
    website_page: "Website page",
    faq: "FAQ",
    policy: "Policy",
    upload: "Upload",
    structured_facts: "Verified facts",
};

export default function KnowledgeBase() {
    const [sources, setSources] = useState([]);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [tab, setTab] = useState("all");
    const [openNewFaq, setOpenNewFaq] = useState(false);
    const [openNewPolicy, setOpenNewPolicy] = useState(false);
    const [openEdit, setOpenEdit] = useState(null);
    const [newForm, setNewForm] = useState({ title: "", body: "" });
    const [editForm, setEditForm] = useState({ title: "", body: "" });
    const fileRef = useRef(null);

    async function load() {
        setLoading(true);
        try {
            const { data } = await api.get("/ai/knowledge/sources");
            setSources(data.sources || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, []);

    async function refresh() {
        setBusy(true);
        try {
            const { data } = await api.post("/ai/knowledge/refresh");
            toast.success(`Refreshed: ${data.website_pages_ingested} pages, ${data.contradictions_flagged} contradictions`);
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Refresh failed"); }
        finally { setBusy(false); }
    }

    async function createFaq() {
        try {
            await api.post("/ai/knowledge/faq", newForm);
            toast.success("FAQ added");
            setOpenNewFaq(false); setNewForm({ title: "", body: "" });
            load();
        } catch (e) { toast.error("Save failed"); }
    }
    async function createPolicy() {
        try {
            await api.post("/ai/knowledge/policy", newForm);
            toast.success("Policy added");
            setOpenNewPolicy(false); setNewForm({ title: "", body: "" });
            load();
        } catch (e) { toast.error("Save failed"); }
    }

    async function upload(e) {
        const file = e.target.files?.[0];
        if (!file) return;
        setBusy(true);
        try {
            const fd = new FormData();
            fd.append("file", file);
            const r = await api.post("/ai/knowledge/upload", fd, { headers: { "Content-Type": "multipart/form-data" } });
            toast.success(`Uploaded ${file.name}`);
            load();
        } catch (err) { toast.error(err?.response?.data?.detail || "Upload failed"); }
        finally { setBusy(false); e.target.value = ""; }
    }

    async function toggleStatus(sid, status) {
        try {
            await api.patch(`/ai/knowledge/sources/${sid}`, { status });
            toast.success(status === "excluded" ? "Excluded from retrieval" : "Re-included");
            load();
        } catch { toast.error("Update failed"); }
    }

    async function deleteSource(sid) {
        if (!confirm("Delete this source? This cannot be undone.")) return;
        try {
            await api.delete(`/ai/knowledge/sources/${sid}`);
            toast.success("Deleted");
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Delete failed"); }
    }

    async function openSource(sid) {
        try {
            const { data } = await api.get(`/ai/knowledge/sources/${sid}`);
            setOpenEdit(data);
            setEditForm({ title: data.title, body: data.body_text || "" });
        } catch { toast.error("Failed to load source"); }
    }
    async function saveEdit() {
        try {
            await api.patch(`/ai/knowledge/sources/${openEdit.id}`, {
                title: editForm.title, body: editForm.body,
            });
            toast.success("Saved");
            setOpenEdit(null);
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Save failed"); }
    }

    const filtered = useMemo(() => tab === "all" ? sources : sources.filter((s) => s.kind === tab), [tab, sources]);
    const contradictionCount = useMemo(() => sources.filter((s) => s.contradiction_flag).length, [sources]);
    const structured = useMemo(() => sources.find((s) => s.kind === "structured_facts"), [sources]);

    return (
        <div className="p-6" data-testid="knowledge-page">
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Knowledge</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Business knowledge base</h1>
                    <p className="text-sm text-zinc-500 mt-1 max-w-2xl">
                        The AI answers <span className="italic">only</span> from this knowledge base plus your verified records.
                        Two classes: <span className="font-medium text-brand-ink">verified facts</span> (services / hours / policies)
                        and <span className="font-medium text-brand-ink">reference content</span> (site pages, FAQs, uploads).
                    </p>
                </div>
                <div className="flex flex-wrap gap-2">
                    <Button variant="outline" onClick={refresh} disabled={busy} data-testid="kb-refresh-btn"><RefreshCw className={`w-4 h-4 mr-1 ${busy ? "animate-spin" : ""}`} /> Refresh & ingest</Button>
                    <Button variant="outline" onClick={() => setOpenNewFaq(true)} data-testid="kb-new-faq-btn"><Plus className="w-4 h-4 mr-1" /> FAQ</Button>
                    <Button variant="outline" onClick={() => setOpenNewPolicy(true)} data-testid="kb-new-policy-btn"><Plus className="w-4 h-4 mr-1" /> Policy</Button>
                    <Button variant="outline" onClick={() => fileRef.current?.click()} data-testid="kb-upload-btn"><Upload className="w-4 h-4 mr-1" /> Upload</Button>
                    <input ref={fileRef} type="file" accept=".txt,.md,.csv,.pdf,.docx" className="hidden" onChange={upload} />
                </div>
            </div>

            {contradictionCount > 0 && (
                <div className="mt-4 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 p-3 text-sm flex items-start gap-2" data-testid="kb-contradiction-banner">
                    <AlertTriangle className="w-4 h-4 mt-0.5" />
                    <div>{contradictionCount} source{contradictionCount > 1 ? "s" : ""} mention price(s) that don't match your current catalog. Review and update or exclude them so the AI doesn't quote stale amounts.</div>
                </div>
            )}
            {structured && (
                <div className="mt-4 rounded-xl border-2 border-emerald-200 bg-emerald-50/40 p-4" data-testid="kb-structured-card">
                    <div className="flex items-center gap-2 text-brand-ink"><ShieldCheck className="w-4 h-4 text-emerald-700" /> <span className="font-medium">Verified facts</span> — always authoritative</div>
                    <div className="text-xs text-zinc-600 mt-1">Live from your services, hours, locations and policies. v{structured.version}, refreshed {structured.ingested_at}.</div>
                </div>
            )}

            <Tabs value={tab} onValueChange={setTab} className="mt-6">
                <TabsList data-testid="kb-tabs">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="website_page">Site pages</TabsTrigger>
                    <TabsTrigger value="faq">FAQs</TabsTrigger>
                    <TabsTrigger value="policy">Policies</TabsTrigger>
                    <TabsTrigger value="upload">Uploads</TabsTrigger>
                </TabsList>
                <TabsContent value={tab} className="mt-4">
                    <div className="rounded-lg border border-brand-line bg-white overflow-hidden">
                        <Table>
                            <TableHeader><TableRow>
                                <TableHead>Kind</TableHead>
                                <TableHead>Title</TableHead>
                                <TableHead>Chunks</TableHead>
                                <TableHead>Ingested</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead></TableHead>
                            </TableRow></TableHeader>
                            <TableBody>
                                {filtered.filter((s) => s.kind !== "structured_facts").map((s) => {
                                    const Icon = KIND_ICON[s.kind] || FileText;
                                    return (
                                        <TableRow key={s.id} data-testid={`kb-row-${s.id}`} className="hover:bg-brand-cream/30">
                                            <TableCell>
                                                <div className="flex items-center gap-2 text-xs">
                                                    <Icon className="w-3.5 h-3.5 text-brand-copper" />
                                                    {KIND_LABEL[s.kind] || s.kind}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <button className="text-left hover:underline text-brand-copper text-sm" onClick={() => openSource(s.id)} data-testid={`kb-open-${s.id}`}>{s.title}</button>
                                                {s.contradiction_flag && <div className="text-[10px] text-amber-700 mt-0.5">⚠ {s.contradiction_flag}</div>}
                                            </TableCell>
                                            <TableCell className="text-xs font-mono">{s.chunk_count}</TableCell>
                                            <TableCell className="text-xs text-zinc-500">{s.ingested_at?.split("T")[0]}</TableCell>
                                            <TableCell>
                                                <Badge className={s.status === "active" ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-600"}>{s.status}</Badge>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <div className="flex justify-end gap-1">
                                                    <Button size="sm" variant="ghost" onClick={() => toggleStatus(s.id, s.status === "active" ? "excluded" : "active")} data-testid={`kb-exclude-${s.id}`}>
                                                        {s.status === "active" ? "Exclude" : "Include"}
                                                    </Button>
                                                    <Button size="sm" variant="ghost" onClick={() => deleteSource(s.id)} data-testid={`kb-delete-${s.id}`}>
                                                        <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                                {!loading && !filtered.filter((s) => s.kind !== "structured_facts").length && (
                                    <TableRow><TableCell colSpan={6} className="text-center text-zinc-500 py-10">No sources here yet.</TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </TabsContent>
            </Tabs>

            {/* New FAQ dialog */}
            <Dialog open={openNewFaq} onOpenChange={setOpenNewFaq}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Add FAQ</DialogTitle></DialogHeader>
                    <Label className="text-xs">Question</Label>
                    <Input value={newForm.title} onChange={(e) => setNewForm({ ...newForm, title: e.target.value })} data-testid="new-faq-title" />
                    <Label className="text-xs">Answer</Label>
                    <Textarea rows={6} value={newForm.body} onChange={(e) => setNewForm({ ...newForm, body: e.target.value })} data-testid="new-faq-body" />
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setOpenNewFaq(false)}>Cancel</Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={createFaq} disabled={!newForm.title || !newForm.body} data-testid="new-faq-save">Save</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* New Policy */}
            <Dialog open={openNewPolicy} onOpenChange={setOpenNewPolicy}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Add policy</DialogTitle></DialogHeader>
                    <Label className="text-xs">Title</Label>
                    <Input value={newForm.title} onChange={(e) => setNewForm({ ...newForm, title: e.target.value })} data-testid="new-policy-title" />
                    <Label className="text-xs">Body</Label>
                    <Textarea rows={6} value={newForm.body} onChange={(e) => setNewForm({ ...newForm, body: e.target.value })} data-testid="new-policy-body" />
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setOpenNewPolicy(false)}>Cancel</Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={createPolicy} disabled={!newForm.title || !newForm.body} data-testid="new-policy-save">Save</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Edit */}
            <Dialog open={!!openEdit} onOpenChange={(o) => !o && setOpenEdit(null)}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader><DialogTitle>Edit: {openEdit?.title}</DialogTitle></DialogHeader>
                    <Label className="text-xs">Title</Label>
                    <Input value={editForm.title} onChange={(e) => setEditForm({ ...editForm, title: e.target.value })} data-testid="edit-source-title" />
                    <Label className="text-xs">Body</Label>
                    <Textarea rows={12} value={editForm.body} onChange={(e) => setEditForm({ ...editForm, body: e.target.value })} data-testid="edit-source-body" />
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setOpenEdit(null)}>Cancel</Button>
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white" onClick={saveEdit} data-testid="edit-source-save">Save changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
