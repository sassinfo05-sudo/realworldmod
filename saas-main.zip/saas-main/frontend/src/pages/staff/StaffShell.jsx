import { useEffect, useMemo, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import api, { clearImpersonation } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Wordmark } from "@/components/Logo";
import NotificationBell from "@/components/NotificationBell";
import ThemeToggle from "@/components/ThemeToggle";
import usePageMeta from "@/hooks/usePageMeta";
import {
    Activity, Users, BarChart3, ShieldAlert, ScrollText, HeartPulse, Ticket, LogOut, Palette, TrendingUp, Plug, Mail,
    FileText, UsersRound, CreditCard, ArrowLeft, Shield, Cpu, Swords,
    LifeBuoy, Rocket,
} from "lucide-react";
import { toast } from "sonner";

/** perm → which staff roles may see the item (owner sees all). Mirrors backend STAFF_ROLES. */
const NAV = [
    { to: "/staff", label: "Cockpit", icon: Activity, end: true, perm: null },
    { to: "/staff/go-live", label: "Go-Live", icon: Rocket, perm: "integrations.read" },
    { to: "/staff/team", label: "Team & roles", icon: UsersRound, perm: "staff" },
    { to: "/staff/payments", label: "Payments & email", icon: CreditCard, perm: "integrations.read" },
    { to: "/staff/pricing", label: "Plans & P&L", icon: TrendingUp, perm: "pricing" },
    { to: "/staff/ai-usage", label: "Cost, usage & margin", icon: Cpu, perm: "audit" },
    { to: "/staff/competitive", label: "Competitive (internal)", icon: Swords, perm: "audit" },
    { to: "/staff/tenants", label: "Tenants", icon: Users, perm: "tenants" },
    { to: "/staff/metrics", label: "Metrics", icon: BarChart3, perm: "metrics" },
    { to: "/staff/branding", label: "Branding", icon: Palette, perm: "branding" },
    { to: "/staff/integrations", label: "Integrations", icon: Plug, perm: "integrations.read" },
    { to: "/staff/emails", label: "Email addresses", icon: Mail, perm: "emails" },
    { to: "/staff/legal", label: "Legal & About", icon: FileText, perm: "legal" },
    { to: "/staff/controls", label: "Global controls", icon: ShieldAlert, perm: "controls" },
    { to: "/staff/support", label: "Support inbox", icon: LifeBuoy, perm: "tenants" },
    { to: "/staff/fraud", label: "Abuse & fraud", icon: ShieldAlert, perm: "audit" },
    { to: "/staff/audit", label: "Audit log", icon: ScrollText, perm: "audit" },
    { to: "/staff/health", label: "Health", icon: HeartPulse, perm: "health" },
    { to: "/staff/approvals", label: "Approvals", icon: Ticket, perm: "approvals" },
];

export default function StaffShell() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const [me, setMe] = useState(null);
    const [impersonating, setImpersonating] = useState(null);

    useEffect(() => {
        if (user?.role !== "platform_founder") return;
        api.get("/staff/me").then((r) => setMe(r.data)).catch(() => setMe({ role: "owner", perms: ["*"], legacy: true }));
        (async () => {
            try { const { data } = await api.get("/founder/impersonate/current"); setImpersonating(data.active ? data.session : null); } catch { /* none */ }
        })();
    }, [user]);

    const perms = me?.perms || [];
    const can = (perm) => !perm || perms.includes("*") || perms.includes(perm);
    const visible = useMemo(() => NAV.filter((n) => can(n.perm)), [perms]); // eslint-disable-line react-hooks/exhaustive-deps
    const current = visible.find((n) => n.end ? location.pathname === n.to : location.pathname.startsWith(n.to));
    usePageMeta(`${current?.label || "Staff"} · Staff`);

    async function exitImpersonation() {
        try { await api.post("/founder/impersonate/end"); toast.success("Impersonation ended"); setImpersonating(null);
              clearImpersonation(); navigate("/staff"); }
        catch { toast.error("Failed"); }
    }

    if (user?.role !== "platform_founder") {
        return (
            <div className="min-h-screen grid place-items-center bg-brand-surface p-10 text-center" data-testid="founder-not-authorized">
                <div><Shield className="w-10 h-10 mx-auto text-zinc-300" /><div className="text-lg font-medium text-brand-ink mt-3">Staff-only area</div>
                    <div className="mt-2 text-sm text-zinc-500">Sign in with a Zanelvo staff account.</div>
                    <Button className="mt-4" onClick={() => navigate("/staff/login")}>Staff sign in</Button></div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-brand-surface flex" data-testid="founder-shell">
            <aside className="hidden md:flex w-64 flex-col border-r border-brand-line bg-[#0B0A16] text-white sticky top-0 h-screen">
                <div className="h-16 px-5 flex items-center border-b border-white/10 gap-2"><Wordmark light /><span className="text-[10px] uppercase tracking-[0.25em] text-white/50 ml-1">Staff</span></div>
                <nav className="p-3 space-y-0.5 overflow-y-auto flex-1">
                    {visible.map(({ to, label, icon: Icon, end }) => (
                        <NavLink key={to} to={to} end={!!end} data-testid={`founder-nav-${label.toLowerCase().replace(/\W+/g, "-")}`}
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] transition ${isActive ? "bg-white/10 text-white font-medium" : "text-white/60 hover:text-white hover:bg-white/5"}`}>
                            <Icon className="w-4 h-4" />{label}
                        </NavLink>
                    ))}
                </nav>
                <div className="p-3 border-t border-white/10 text-xs">
                    <div className="px-2 truncate text-white/80" data-testid="founder-user-email">{user?.email}</div>
                    <div className="px-2 text-[10px] uppercase tracking-widest text-white/40 mt-0.5">{me?.role || user?.staff_role || "owner"}{me?.work_email ? ` · ${me.work_email}` : ""}</div>
                    <div className="mt-2 flex gap-1">
                        <Button size="sm" variant="ghost" className="text-white/70 hover:text-white hover:bg-white/10 flex-1 justify-start" onClick={() => navigate("/app")}><ArrowLeft className="w-3.5 h-3.5" /> Customer app</Button>
                        <Button size="sm" variant="ghost" className="text-white/70 hover:text-white hover:bg-white/10" onClick={() => { logout(); navigate("/staff/login"); }} data-testid="staff-logout"><LogOut className="w-3.5 h-3.5" /></Button>
                    </div>
                </div>
            </aside>
            <div className="flex-1 min-w-0 flex flex-col">
                {impersonating && (
                    <div className="bg-amber-500 text-white px-4 py-2 flex items-center justify-between gap-3" data-testid="impersonation-banner">
                        <div className="text-sm"><span className="font-medium">Support session — acting as another org.</span><span className="ml-2 opacity-80">Reason: {impersonating.reason} · expires {impersonating.expires_at?.slice(11, 16)}</span></div>
                        <Button size="sm" variant="outline" onClick={exitImpersonation} className="bg-white text-amber-800 border-white hover:bg-amber-50" data-testid="impersonation-exit-btn"><LogOut className="w-3.5 h-3.5 mr-1" /> Exit</Button>
                    </div>
                )}
                <header className="h-16 sticky top-0 z-30 bg-white/80 dark:bg-zinc-950/80 backdrop-blur border-b border-brand-line px-4 md:px-8 flex items-center gap-3">
                    <div><div className="text-[10px] uppercase tracking-widest text-brand-copper">Zanelvo Staff Panel</div><h1 className="font-display text-lg leading-tight text-brand-ink" data-testid="page-title">{current?.label || "Staff"}</h1></div>
                    <div className="ml-auto flex items-center gap-2"><NotificationBell /><ThemeToggle /></div>
                </header>
                <main className="flex-1"><Outlet /></main>
            </div>
            {/* mobile nav */}
            <nav className="md:hidden fixed bottom-0 inset-x-0 z-30 h-14 bg-[#0B0A16] text-white flex overflow-x-auto px-2 gap-1 items-center">
                {visible.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={!!end} className={({ isActive }) => `px-3 py-1.5 rounded-md text-xs whitespace-nowrap flex items-center gap-1 ${isActive ? "bg-white/15" : "text-white/60"}`}><Icon className="w-3.5 h-3.5" />{label}</NavLink>)}
            </nav>
        </div>
    );
}
