import { useEffect, useState } from "react";
import { toast } from "sonner";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Plus, Sparkles, Loader2, Trash2, ExternalLink, FileText } from "lucide-react";

const EMPTY = { title: "", slug: "", excerpt: "", body: "", cover_image: "", tags: [], seo: {}, status: "draft", language: "en" };

/** /app/blog — articles for the tenant's public site (/site/<slug>/blog). */
export default function Blog() {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [editing, setEditing] = useState(null);   // post object or EMPTY copy
    const [siteSlug, setSiteSlug] = useState(null);
    const [aiOpen, setAiOpen] = useState(false);
    const [aiTopic, setAiTopic] = useState("");
    const [aiBusy, setAiBusy] = useState(false);
    const [saving, setSaving] = useState(false);

    const load = async () => {
        setLoading(true);
        try {
            const [{ data }, site] = await Promise.all([
                api.get("/blog/posts"),
                api.get("/editor/website").catch(() => ({ data: null })),
            ]);
            setPosts(data.posts || []);
            setSiteSlug(site?.data?.website?.slug || null);
        } catch { toast.error("Could not load articles"); }
        finally { setLoading(false); }
    };
    useEffect(() => { load(); }, []);

    const save = async (publish) => {
        if (!editing?.title?.trim()) { toast.error("Give the article a title"); return; }
        setSaving(true);
        try {
            const payload = { ...editing, status: publish ? "published" : (editing.status || "draft"), slug: editing.slug || undefined,
                tags: (Array.isArray(editing.tags) ? editing.tags : String(editing.tags || "").split(",")).map((t) => t.trim()).filter(Boolean) };
            delete payload.id; delete payload.org_id; delete payload.author_id; delete payload.created_at; delete payload.updated_at; delete payload.published_at;
            if (editing.id) await api.patch(`/blog/posts/${editing.id}`, payload);
            else await api.post("/blog/posts", payload);
            toast.success(publish ? "Article published" : "Draft saved");
            setEditing(null);
            load();
        } catch (e) {
            const d = e?.response?.data?.detail;
            toast.error(typeof d === "string" ? d : (d?.[0]?.msg || d?.message || "Could not save"));
        } finally { setSaving(false); }
    };

    const remove = async (p) => {
        if (!window.confirm(`Delete “${p.title}”?`)) return;
        try { await api.delete(`/blog/posts/${p.id}`); toast.success("Deleted"); load(); }
        catch { toast.error("Could not delete"); }
    };

    const aiDraft = async () => {
        if (!aiTopic.trim() || aiBusy) return;
        setAiBusy(true);
        try {
            const { data } = await api.post("/blog/posts/ai-draft", { topic: aiTopic.trim() });
            setEditing({ ...EMPTY, ...data });
            setAiOpen(false); setAiTopic("");
            toast.success("Draft ready — review and edit before publishing");
        } catch (e) {
            const d = e?.response?.data?.detail;
            toast.error(typeof d === "string" ? d : (d?.message || "AI draft failed"));
        } finally { setAiBusy(false); }
    };

    return (
        <div className="p-6 md:p-8" data-testid="blog-page">
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Website</div>
                    <h1 className="font-display text-2xl md:text-3xl text-brand-ink font-medium">Blog & articles</h1>
                    <p className="mt-1 text-sm text-zinc-500">Published articles appear at {siteSlug ? <a className="text-brand-copper hover:underline" href={`/site/${siteSlug}/blog`} target="_blank" rel="noreferrer">/site/{siteSlug}/blog</a> : "your public site once it is published"} and in any “Blog — latest articles” section.</p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setAiOpen(true)} data-testid="blog-ai-draft"><Sparkles className="w-4 h-4 mr-1.5" /> Draft with AI</Button>
                    <Button onClick={() => setEditing({ ...EMPTY })} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="blog-new"><Plus className="w-4 h-4 mr-1.5" /> New article</Button>
                </div>
            </div>

            {loading ? <div className="mt-8 text-sm text-zinc-500 flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Loading…</div> : posts.length === 0 ? (
                <div className="mt-8 rounded-2xl border border-dashed border-brand-line p-10 text-center" data-testid="blog-empty">
                    <FileText className="w-8 h-8 mx-auto text-zinc-400" />
                    <div className="mt-3 font-medium text-brand-ink">No articles yet</div>
                    <p className="text-sm text-zinc-500 mt-1">Articles help you rank for the questions your customers search for.</p>
                </div>
            ) : (
                <div className="mt-6 rounded-2xl border border-brand-line bg-white divide-y divide-brand-line" data-testid="blog-list">
                    {posts.map((p) => (
                        <div key={p.id} className="p-4 flex items-center gap-4" data-testid={`blog-row-${p.id}`}>
                            <button type="button" className="flex-1 text-left" onClick={() => setEditing({ ...p, tags: p.tags || [] })}>
                                <div className="font-medium text-brand-ink">{p.title}</div>
                                <div className="text-xs text-zinc-500 mt-0.5">/{p.slug} · updated {new Date(p.updated_at).toLocaleDateString()}</div>
                            </button>
                            <Badge variant={p.status === "published" ? "default" : "secondary"} className="text-[10px] uppercase">{p.status}</Badge>
                            {p.status === "published" && siteSlug && (
                                <a href={`/site/${siteSlug}/blog/${p.slug}`} target="_blank" rel="noreferrer" className="text-zinc-400 hover:text-brand-ink" title="View"><ExternalLink className="w-4 h-4" /></a>
                            )}
                            <button type="button" onClick={() => remove(p)} className="text-zinc-400 hover:text-red-600" title="Delete" data-testid={`blog-delete-${p.id}`}><Trash2 className="w-4 h-4" /></button>
                        </div>
                    ))}
                </div>
            )}

            <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
                <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" data-testid="blog-editor">
                    <DialogHeader>
                        <DialogTitle>{editing?.id ? "Edit article" : "New article"}</DialogTitle>
                        <DialogDescription>Plain text — blank lines start new paragraphs, lines starting with “## ” become subheadings.</DialogDescription>
                    </DialogHeader>
                    {editing && (
                        <div className="space-y-3">
                            <Field label="Title"><Input value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} data-testid="blog-title" /></Field>
                            <div className="grid sm:grid-cols-2 gap-3">
                                <Field label="URL slug (optional)"><Input value={editing.slug || ""} onChange={(e) => setEditing({ ...editing, slug: e.target.value })} placeholder="auto from title" /></Field>
                                <Field label="Tags (comma separated)"><Input value={Array.isArray(editing.tags) ? editing.tags.join(", ") : editing.tags} onChange={(e) => setEditing({ ...editing, tags: e.target.value })} /></Field>
                            </div>
                            <Field label="Excerpt"><Textarea rows={2} value={editing.excerpt} onChange={(e) => setEditing({ ...editing, excerpt: e.target.value })} /></Field>
                            <Field label="Cover image URL (optional)"><Input value={editing.cover_image || ""} onChange={(e) => setEditing({ ...editing, cover_image: e.target.value })} /></Field>
                            <Field label="Body"><Textarea rows={14} value={editing.body} onChange={(e) => setEditing({ ...editing, body: e.target.value })} data-testid="blog-body" /></Field>
                            <div className="grid sm:grid-cols-2 gap-3">
                                <Field label="SEO title"><Input value={editing.seo?.title || ""} onChange={(e) => setEditing({ ...editing, seo: { ...(editing.seo || {}), title: e.target.value } })} /></Field>
                                <Field label="SEO description"><Input value={editing.seo?.description || ""} onChange={(e) => setEditing({ ...editing, seo: { ...(editing.seo || {}), description: e.target.value } })} /></Field>
                            </div>
                        </div>
                    )}
                    <DialogFooter className="gap-2">
                        <Button variant="outline" onClick={() => setEditing(null)} disabled={saving}>Cancel</Button>
                        <Button variant="outline" onClick={() => save(false)} disabled={saving} data-testid="blog-save-draft">Save draft</Button>
                        <Button onClick={() => save(true)} disabled={saving} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="blog-publish">{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : "Publish"}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={aiOpen} onOpenChange={setAiOpen}>
                <DialogContent data-testid="blog-ai-dialog">
                    <DialogHeader>
                        <DialogTitle>Draft an article with AI</DialogTitle>
                        <DialogDescription>Grounded in your business profile. It never invents prices, reviews or statistics — you review before publishing. Uses your plan's AI budget.</DialogDescription>
                    </DialogHeader>
                    <Field label="Topic"><Input value={aiTopic} onChange={(e) => setAiTopic(e.target.value)} placeholder="e.g. How to prepare your home for winter plumbing issues" data-testid="blog-ai-topic" /></Field>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setAiOpen(false)} disabled={aiBusy}>Cancel</Button>
                        <Button onClick={aiDraft} disabled={aiBusy || !aiTopic.trim()} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="blog-ai-go">{aiBusy ? <><Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> Writing…</> : "Generate draft"}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}

function Field({ label, children }) {
    return <div><Label className="text-xs uppercase tracking-widest text-zinc-500">{label}</Label><div className="mt-1">{children}</div></div>;
}
