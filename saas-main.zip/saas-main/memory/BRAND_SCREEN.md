# Brand Screen — Final Corrective Pass

Purpose: independent verification of the pre-screened finalists ("Quilvo", "Velquo")
supplied in the owner's brief, plus the previously-disqualified candidates recorded
for future reference. This file is the audit trail for the naming decision.

Date of screen: 2026-09-03 (UTC).

## Chosen brand

**Revenue OS** — neutral internal descriptor. Applied per the brief's explicit
fallback provision:

> "If no candidate's domain registrability can be genuinely verified, fall back
> to the neutral internal label 'Revenue OS' and record in BRAND_SCREEN.md
> exactly what the owner must verify before naming."

This is a label, not a trademark claim. It's a descriptor of what the product
is (an operating system for a service business's revenue surfaces). Cheapest
honest option under the current budget constraint.

## Verification evidence

### Quilvo — DISQUALIFIED

Web search "Quilvo" (exact quoted, high context):
- **Quilvo (Seattle startup, founded 2023)** — active product. "Command center
  for writing careers." Runs on `quilvo.app`. Has a REST API at
  `https://quilvo.app/api/v1` (Bearer auth) and an MCP server at
  `https://quilvo.app/mcp/quilvo` (OAuth with `mcp:use` grant). Tracked on
  Tracxn (unfunded). Direct conflict — active SaaS with the exact name.
- **Quilvo Alto** — Chilean fruit-packaging company (`quilvoalto.cl`).
  Different industry but same root name.
- Domain `quilvo.com`:
  - Live crawl of https://quilvo.com: parked/for-sale page on **Atom.com**.
    Listed at **$3,795 one-time** (lease-to-own $331 × 12 + $190 down).
  - RDAP (`https://rdap.org/domain/quilvo.com`): registration 2023-05-07,
    expiration 2027-05-07, registrar **Unstoppable Domains Inc.** (IANA 4326),
    nameservers `NS1.ATOM.COM`, `NS2.ATOM.COM`. Status: clientDeleteProhibited,
    clientTransferProhibited.

Verdict: **DISQUALIFIED**. An active SaaS operating under this exact name on
`quilvo.app` is a hard conflict regardless of `.com` availability.

### Velquo — DISQUALIFIED (soft conflicts + domain owned)

Web search "Velquo" (exact quoted, high context):
- **Velquo Games** — `velquogames.com` (About page returned no accessible
  content but the domain exists as a games entity). Different vertical, but
  same exact name in a public web presence.
- **"Velquo" mobile-app concept** — LinkedIn post by Shallom Issa
  (2025-10-22) presenting a concept design for a "digital lifestyle companion
  for digital nomads." Not a shipped product, but a public design-concept post
  under the exact name.
- **Etsy shop "Velquo"** — active shop namespace.
- Domain `velquo.com`:
  - Live crawl of https://velquo.com: **ERR_CONNECTION_CLOSED**. Server does
    not serve HTTP right now; domain not usable as-is by us.
  - RDAP (`https://rdap.org/domain/velquo.com`): registration 2026-07-14,
    expiration 2027-07-14, registrar **Tucows Domains Inc.** (IANA 69),
    nameservers `DNS.TECHNORAIL.COM`, `DNS2.TECHNORAIL.COM`, `DNS3.ARUBADNS.NET`,
    `DNS4.ARUBADNS.CZ` (Aruba S.p.A. — Italian hosting). Status:
    clientTransferProhibited, clientUpdateProhibited.

Verdict: **DISQUALIFIED**. Domain owned by a third party (Italian registrant,
recently registered July 2026). Domain registrability cannot be verified
without third-party negotiation. Plus multiple public exact-name usages
(games studio, LinkedIn concept, Etsy).

### Previously disqualified (recorded per brief)

Provided by the owner's pre-screen, retained here as the durable trail:
- **Yavren** — active French app publisher; YAVREN publishes on Google Play.
  Prior "unclaimed" claim was false.
- **Solvra** — active Indian companies + Solvra.AI energy platform.
- **Rivena** — Rivena Oy (Finnish ICT).
- **Zarvo** — Zarvo Labs (India) + Zarvo S.A. (Panama).
- **Corvela** — Austin AI healthcare.
- **Quenta** — Quenta Tech dev studio.
- **Omvio** — Omvio AB (Sweden IT consulting) + NL software sole prop.
- **Trelvo** — operator network.
- **Norvio** — direct conflict, conversational-AI platform.
- **Zorvane** — Zorvane Eltrix Inc. (NY).
- **Onvara** — Onvara GmbH (historical, previously used and retired).

## What the owner MUST verify before final naming

If the owner wants to move off the neutral "Revenue OS" descriptor to a real
proprietary brand, do all of the following BEFORE any customer-facing
announcement:

1. **Domain availability**, on the exact `.com` and the exact `.app`. Confirm
   via RDAP (`https://rdap.org/domain/<name>.com`) that the domain is
   unregistered (RDAP returns 404) or is available at registrar checkout.
2. **App-store search** on iOS App Store, Google Play, Microsoft Store,
   Chrome Web Store. Zero exact-name hits.
3. **Trademark search**:
   - USPTO TESS: https://tmsearch.uspto.gov/search/search-information
   - EUIPO eSearch: https://euipo.europa.eu/eSearch/
   - WIPO Global Brand Database: https://branddb.wipo.int/en/
   Search class 42 (SaaS) and 9 (software) and 35 (advertising/marketing).
4. **Company registry conflict scan** in at least US (SoS databases), UK
   (Companies House), and the owner's operating country. Look for exact name
   in incorporated entity names.
5. **Google + Bing web search** with the exact quoted name plus tokens like
   "startup", "app", "company", "SaaS". Zero pages that read as a going
   concern under the same name.
6. **Israel-specific pronunciation sanity check** (per original brief: name
   must be pronounceable in English AND Hebrew): read the name aloud in both.
   Reject if either produces an accidental word with negative meaning.

Only after all six pass should any UI copy, domain, or public communication
adopt the name. Until then, "Revenue OS" is the safe internal label.

## Where the current codebase stands

- Repo-wide case-insensitive `yavren` grep returns **zero hits** outside of
  `/app/memory/DECISIONS.md` (historical rebrand log), `/app/memory/BRAND_SCREEN.md`
  (this file), and `/app/test_reports/*.json` (immutable prior test outputs).
- Brand config `BRAND_DEFAULT["name"] = "Revenue OS"` in `/app/backend/app/config.py`.
- Seeded founder email: `founder@revenueos.com`.
- Seeded demo owner emails: `owner@demo.revenueos.com`, `owner@free-demo.revenueos.com`,
  `owner@launch-demo.revenueos.com`, `owner@autopilot-demo.revenueos.com`,
  `owner@auto-demo.revenueos.com`, `owner@beauty-demo.revenueos.com`.
- Webhook signature header: `X-Revenue-OS-Signature` (was `X-Yavren-Signature`).
- Front-end `localStorage` prefix: `revenue_os.` (was `yavren.`).
- MFA TOTP issuer: `Revenue OS`.
- All email/host defaults use `revenueos.local` (email) or `revenueos.app`
  (public-origin default) — none of which are owned by us yet. These are
  placeholders and must not appear in customer-facing announcements until the
  six-step verification above completes.
