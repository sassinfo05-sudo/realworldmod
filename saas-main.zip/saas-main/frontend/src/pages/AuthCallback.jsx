// REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

/**
 * Handles the return leg of Emergent-managed Google auth.
 * Emergent redirects here with `#session_id=...`. We POST that ONCE to the
 * backend, receive our own JWT + user, then navigate the new user into
 * onboarding (if their org has no business profile yet) or the app.
 */
export default function AuthCallback() {
    const navigate = useNavigate();
    const { persistToken } = useAuth();
    const processed = useRef(false);
    const [status, setStatus] = useState("Signing you in with Google…");

    useEffect(() => {
        if (processed.current) return;
        processed.current = true;

        const raw = window.location.hash?.replace(/^#/, "") || "";
        const params = new URLSearchParams(raw);
        const sessionId = params.get("session_id");

        if (!sessionId) {
            setStatus("Missing Google session. Redirecting to login…");
            toast.error("Google session missing. Please try again.");
            setTimeout(() => navigate("/login", { replace: true }), 1200);
            return;
        }

        (async () => {
            try {
                const { data } = await api.post("/auth/session-exchange", { session_id: sessionId });
                // Clean the URL fragment so a reload doesn't retry.
                window.history.replaceState(null, "", window.location.pathname);
                persistToken(data.access_token, data.user);
                toast.success("Signed in with Google.");
                navigate(data.needs_onboarding ? "/onboarding" : "/app", { replace: true });
            } catch (err) {
                const msg = err?.response?.data?.detail || "Google sign-in failed";
                toast.error(msg);
                setStatus(msg);
                setTimeout(() => navigate("/login", { replace: true }), 1400);
            }
        })();
    }, [navigate, persistToken]);

    return (
        <div className="min-h-screen bg-brand-surface flex items-center justify-center px-6">
            <div className="text-center max-w-sm" data-testid="auth-callback-status">
                <div className="mx-auto mb-6 h-10 w-10 rounded-full border-2 border-brand-copper border-t-transparent animate-spin" />
                <div className="font-display text-xl text-brand-ink">{status}</div>
            </div>
        </div>
    );
}
