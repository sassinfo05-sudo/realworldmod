#!/usr/bin/env python3
"""
Round 18 Backend Regression Test - LLM Lazy Import Verification

Tests that the emergentintegrations lazy import refactor did NOT break any functionality.
Focus: health, auth, tenant CRUD, and LLM-backed features.
"""
import os
import sys
import time
import requests
from typing import Dict, Optional

# Read backend URL from frontend/.env
BACKEND_URL = "https://bootstrap-fix-2.preview.emergentagent.com/api"

# Test credentials from /app/memory/test_credentials.md
FOUNDER_EMAIL = os.environ.get("TEST_FOUNDER_EMAIL", "founder@zanelvo.com")
OWNER_EMAIL = os.environ.get("TEST_OWNER_EMAIL", "owner@demo.zanelvo.com")


def _cred(email, env_key):
    """Load a test password from env or the gitignored creds file — never hardcoded in git."""
    v = os.environ.get(env_key)
    if v:
        return v
    try:
        import re
        txt = open("/app/memory/test_credentials.md", encoding="utf-8").read()
        m = re.search(re.escape(email) + r"[^`]*`([^`]+)`", txt)
        if m:
            return m.group(1)
    except Exception:
        pass
    return ""


FOUNDER_PASSWORD = _cred(FOUNDER_EMAIL, "TEST_FOUNDER_PASSWORD")
OWNER_PASSWORD = _cred(OWNER_EMAIL, "TEST_OWNER_PASSWORD")

# Test results tracking
results = {
    "passed": [],
    "failed": [],
    "warnings": []
}


def log_pass(test_name: str, details: str = ""):
    """Log a passing test."""
    msg = f"✅ PASS: {test_name}"
    if details:
        msg += f" - {details}"
    print(msg)
    results["passed"].append(test_name)


def log_fail(test_name: str, details: str):
    """Log a failing test."""
    msg = f"❌ FAIL: {test_name} - {details}"
    print(msg)
    results["failed"].append(f"{test_name}: {details}")


def log_warning(test_name: str, details: str):
    """Log a warning."""
    msg = f"⚠️  WARN: {test_name} - {details}"
    print(msg)
    results["warnings"].append(f"{test_name}: {details}")


def test_health_endpoints():
    """Test 1: Health and readiness endpoints."""
    print("\n" + "="*80)
    print("TEST 1: HEALTH & READINESS ENDPOINTS")
    print("="*80)
    
    # Test /api/health
    try:
        resp = requests.get(f"{BACKEND_URL}/health", timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("ok") and data.get("db", {}).get("ok"):
                log_pass("GET /api/health", f"ok={data['ok']}, db.ok={data['db']['ok']}")
            else:
                log_fail("GET /api/health", f"Response missing ok or db.ok: {data}")
        else:
            log_fail("GET /api/health", f"Status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        log_fail("GET /api/health", f"Exception: {e}")
    
    # Test /api/readiness
    try:
        resp = requests.get(f"{BACKEND_URL}/readiness", timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("app_ready"):
                log_pass("GET /api/readiness", f"app_ready={data['app_ready']}")
            else:
                log_fail("GET /api/readiness", f"app_ready not true: {data}")
        else:
            log_fail("GET /api/readiness", f"Status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        log_fail("GET /api/readiness", f"Exception: {e}")


def login(email: str, password: str) -> Optional[str]:
    """Helper: Login and return access token."""
    try:
        resp = requests.post(
            f"{BACKEND_URL}/auth/login",
            json={"email": email, "password": password},
            timeout=10
        )
        if resp.status_code == 200:
            data = resp.json()
            return data.get("access_token")
        else:
            print(f"Login failed for {email}: {resp.status_code} {resp.text[:200]}")
            return None
    except Exception as e:
        print(f"Login exception for {email}: {e}")
        return None


def test_auth():
    """Test 2: Auth for both founder and demo owner."""
    print("\n" + "="*80)
    print("TEST 2: AUTHENTICATION (FOUNDER & DEMO OWNER)")
    print("="*80)
    
    # Test founder login
    founder_token = login(FOUNDER_EMAIL, FOUNDER_PASSWORD)
    if founder_token:
        log_pass("Founder login", f"email={FOUNDER_EMAIL}, token length={len(founder_token)}")
        
        # Test authenticated endpoint with founder token
        try:
            resp = requests.get(
                f"{BACKEND_URL}/auth/me",
                headers={"Authorization": f"Bearer {founder_token}"},
                timeout=10
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("email") == FOUNDER_EMAIL:
                    log_pass("Founder /api/auth/me", f"email={data['email']}, role={data.get('role')}")
                else:
                    log_fail("Founder /api/auth/me", f"Email mismatch: {data}")
            else:
                log_fail("Founder /api/auth/me", f"Status {resp.status_code}: {resp.text[:200]}")
        except Exception as e:
            log_fail("Founder /api/auth/me", f"Exception: {e}")
    else:
        log_fail("Founder login", f"Failed to get token for {FOUNDER_EMAIL}")
    
    # Test demo owner login
    owner_token = login(OWNER_EMAIL, OWNER_PASSWORD)
    if owner_token:
        log_pass("Demo owner login", f"email={OWNER_EMAIL}, token length={len(owner_token)}")
        
        # Test authenticated endpoint with owner token
        try:
            resp = requests.get(
                f"{BACKEND_URL}/auth/me",
                headers={"Authorization": f"Bearer {owner_token}"},
                timeout=10
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("email") == OWNER_EMAIL:
                    log_pass("Demo owner /api/auth/me", f"email={data['email']}, role={data.get('role')}")
                else:
                    log_fail("Demo owner /api/auth/me", f"Email mismatch: {data}")
            else:
                log_fail("Demo owner /api/auth/me", f"Status {resp.status_code}: {resp.text[:200]}")
        except Exception as e:
            log_fail("Demo owner /api/auth/me", f"Exception: {e}")
    else:
        log_fail("Demo owner login", f"Failed to get token for {OWNER_EMAIL}")
    
    return founder_token, owner_token


def test_tenant_crud(owner_token: str):
    """Test 3: Core tenant CRUD sanity checks."""
    print("\n" + "="*80)
    print("TEST 3: TENANT-SCOPED CRUD OPERATIONS")
    print("="*80)
    
    if not owner_token:
        log_fail("Tenant CRUD", "No owner token available")
        return
    
    headers = {"Authorization": f"Bearer {owner_token}"}
    
    # Test CRM contacts list
    try:
        resp = requests.get(f"{BACKEND_URL}/crm/contacts", headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            contacts = data.get("contacts", [])
            log_pass("GET /api/crm/contacts", f"Retrieved {len(contacts)} contacts")
        else:
            log_fail("GET /api/crm/contacts", f"Status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        log_fail("GET /api/crm/contacts", f"Exception: {e}")
    
    # Test products list
    try:
        resp = requests.get(f"{BACKEND_URL}/store/products", headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            products = data.get("products", [])
            log_pass("GET /api/store/products", f"Retrieved {len(products)} products")
        else:
            log_fail("GET /api/store/products", f"Status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        log_fail("GET /api/store/products", f"Exception: {e}")
    
    # Test branding endpoint (tenant-scoped)
    try:
        resp = requests.get(f"{BACKEND_URL}/branding", headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            log_pass("GET /api/branding", f"Branding data retrieved with {len(data)} keys")
        else:
            log_fail("GET /api/branding", f"Status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        log_fail("GET /api/branding", f"Exception: {e}")


def test_llm_feature(owner_token: str):
    """Test 4: LLM-backed feature (proves lazy import works end-to-end)."""
    print("\n" + "="*80)
    print("TEST 4: LLM-BACKED FEATURE (LAZY IMPORT VERIFICATION)")
    print("="*80)
    
    if not owner_token:
        log_fail("LLM feature", "No owner token available")
        return
    
    headers = {"Authorization": f"Bearer {owner_token}"}
    
    # First, check if CMS collections exist
    try:
        resp = requests.get(f"{BACKEND_URL}/cms/collections", headers=headers, timeout=10)
        if resp.status_code == 200:
            collections = resp.json().get("collections", [])
            print(f"Found {len(collections)} CMS collections")
            
            if collections:
                # Try AI propose on first collection
                collection_id = collections[0].get("id")
                collection_name = collections[0].get("name", "unknown")
                
                print(f"Testing AI propose on collection: {collection_name} (id={collection_id})")
                
                try:
                    resp = requests.post(
                        f"{BACKEND_URL}/cms/collections/{collection_id}/ai-propose",
                        headers=headers,
                        json={"prompt": "Create a sample blog post about home services"},
                        timeout=30
                    )
                    
                    if resp.status_code == 200:
                        data = resp.json()
                        if data.get("fields"):
                            log_pass("CMS AI propose", f"Generated {len(data['fields'])} fields for collection {collection_name}")
                        else:
                            log_fail("CMS AI propose", f"No fields in response: {data}")
                    elif resp.status_code == 402:
                        log_warning("CMS AI propose", f"Budget exceeded (expected if key is low): {resp.text[:200]}")
                    else:
                        log_fail("CMS AI propose", f"Status {resp.status_code}: {resp.text[:200]}")
                except Exception as e:
                    log_fail("CMS AI propose", f"Exception: {e}")
            else:
                # No collections, try onboarding research instead
                print("No CMS collections found, testing onboarding research instead")
                test_onboarding_llm(owner_token)
        else:
            print(f"CMS collections endpoint returned {resp.status_code}, trying onboarding instead")
            test_onboarding_llm(owner_token)
    except Exception as e:
        print(f"CMS check failed: {e}, trying onboarding instead")
        test_onboarding_llm(owner_token)


def test_onboarding_llm(owner_token: str):
    """Fallback: Test onboarding research LLM feature."""
    headers = {"Authorization": f"Bearer {owner_token}"}
    
    try:
        resp = requests.post(
            f"{BACKEND_URL}/onboarding/research",
            headers=headers,
            json={
                "business_name": "Emerald Plumbing Services",
                "location": "Seattle",
                "country": "USA"
            },
            timeout=30
        )
        
        if resp.status_code == 200:
            data = resp.json()
            # The endpoint returns 'facts' not 'suggestions'
            if data.get("facts") and isinstance(data["facts"], dict):
                facts = data["facts"]
                log_pass("Onboarding research LLM", f"Generated business facts (business_name={facts.get('business_name')}, industry={facts.get('industry')})")
            else:
                log_fail("Onboarding research LLM", f"No facts in response: {data}")
        elif resp.status_code == 402:
            log_warning("Onboarding research LLM", f"Budget exceeded (expected if key is low): {resp.text[:200]}")
        else:
            log_fail("Onboarding research LLM", f"Status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        log_fail("Onboarding research LLM", f"Exception: {e}")


def test_backend_logs():
    """Test 5: Confirm no import errors in backend logs."""
    print("\n" + "="*80)
    print("TEST 5: BACKEND STARTUP LOGS (IMPORT ERROR CHECK)")
    print("="*80)
    
    try:
        # Check recent backend logs for actual Python import errors (not LLM errors)
        # Look for: ImportError, ModuleNotFoundError, "cannot import", "No module named"
        result = os.popen("tail -n 200 /var/log/supervisor/backend.*.log 2>&1 | grep -E 'ImportError|ModuleNotFoundError|cannot import name|No module named' | grep -v 'LLM' | head -20").read()
        
        if result.strip():
            log_fail("Backend import check", f"Found import errors in logs:\n{result}")
        else:
            log_pass("Backend import check", "No Python import errors found in recent logs")
        
        # Check for successful startup
        startup_check = os.popen("tail -n 100 /var/log/supervisor/backend.*.log 2>&1 | grep 'Application startup complete'").read()
        
        if "Application startup complete" in startup_check:
            log_pass("Backend startup", "Application started successfully")
        else:
            log_warning("Backend startup", "Could not confirm 'Application startup complete' in recent logs")
        
        # Check that emergentintegrations is NOT imported at startup (lazy import)
        emergent_check = os.popen("tail -n 200 /var/log/supervisor/backend.*.log 2>&1 | grep -i 'emergentintegrations' | grep -i 'import' | head -5").read()
        
        if emergent_check.strip():
            log_warning("Lazy import check", f"Found emergentintegrations import references (should be lazy): {emergent_check[:200]}")
        else:
            log_pass("Lazy import check", "emergentintegrations not imported at startup (lazy import working)")
            
    except Exception as e:
        log_fail("Backend log check", f"Exception: {e}")


def print_summary():
    """Print test summary."""
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    print(f"\n✅ PASSED: {len(results['passed'])} tests")
    for test in results['passed']:
        print(f"  - {test}")
    
    if results['warnings']:
        print(f"\n⚠️  WARNINGS: {len(results['warnings'])} items")
        for warning in results['warnings']:
            print(f"  - {warning}")
    
    if results['failed']:
        print(f"\n❌ FAILED: {len(results['failed'])} tests")
        for failure in results['failed']:
            print(f"  - {failure}")
    else:
        print("\n🎉 ALL CRITICAL TESTS PASSED!")
    
    print("\n" + "="*80)
    
    # Return exit code
    return 0 if not results['failed'] else 1


def main():
    """Run all tests."""
    print("="*80)
    print("ROUND 18 BACKEND REGRESSION TEST")
    print("LLM Lazy Import Verification")
    print("="*80)
    print(f"Backend URL: {BACKEND_URL}")
    print(f"Founder: {FOUNDER_EMAIL}")
    print(f"Demo Owner: {OWNER_EMAIL}")
    
    # Run tests in order
    test_health_endpoints()
    founder_token, owner_token = test_auth()
    test_tenant_crud(owner_token)
    test_llm_feature(owner_token)
    test_backend_logs()
    
    # Print summary and exit
    exit_code = print_summary()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
