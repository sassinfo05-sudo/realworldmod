"""Subscriptions — recurring products (owner mgmt + public subscribe + renewals).

Round 12. A product flagged `is_subscription` with a `billing_interval` (month|year) can be
subscribed to. Subscribing creates a `db.store_subscriptions` row + a first store order routed through
the store's payment provider (simulated in dev/demo, real Stripe when connected). When that first
order is PAID the subscription activates and `next_renewal_at` is scheduled.

Renewals: a background loop (dev/simulated) creates a new PAID order each period and advances the
date; owners can also force a renewal in dev via `/run-renewal`. Live recurring CHARGES require
Stripe Billing (not yet wired) — in production without a live provider, subscribe is refused, exactly
like store buy-now, so we never fake a charge.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .. import config
from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..services.payment_providers import CheckoutRequest

logger = logging.getLogger("app.subscriptions")

router = APIRouter(prefix="/store", tags=["subscriptions"])
public_router = APIRouter(prefix="/public/store", tags=["subscriptions-public"])

INTERVAL_DAYS = {"month": 30, "year": 365}


def _add_interval(interval: str) -> str:
    days = INTERVAL_DAYS.get(interval, 30)
    return (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()


def _sub_out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": d["_id"], "product_id": d.get("product_id"), "product_name": d.get("product_name"),
        "price_cents": int(d.get("price_cents", 0)), "currency": d.get("currency", "USD"),
        "interval": d.get("interval"), "status": d.get("status"),
        "buyer": d.get("buyer", {}), "customer_id": d.get("customer_id"),
        "current_period_start": d.get("current_period_start"),
        "next_renewal_at": d.get("next_renewal_at"),
        "orders": d.get("orders", []), "renewal_count": len(d.get("orders", [])),
        "provider": d.get("provider", "simulated"),
        "created_at": d.get("created_at"), "cancelled_at": d.get("cancelled_at"),
    }


# ============================ OWNER ============================

@router.get("/subscriptions")
async def list_subscriptions(status: Optional[str] = None, user: User = Depends(current_user),
                             org_id: str = Depends(require_org)):
    db = get_db()
    q: Dict[str, Any] = {"org_id": org_id}
    if status:
        q["status"] = status
    rows = [_sub_out(s) async for s in db.store_subscriptions.find(q).sort("created_at", -1)]
    mrr = 0
    for r in rows:
        if r["status"] == "active":
            monthly = r["price_cents"] if r["interval"] == "month" else round(r["price_cents"] / 12)
            mrr += monthly
    return {"subscriptions": rows, "active": sum(1 for r in rows if r["status"] == "active"), "mrr_cents": mrr}


@router.get("/subscriptions/{sid}")
async def get_subscription(sid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    s = await db.store_subscriptions.find_one({"_id": sid, "org_id": org_id})
    if not s:
        raise HTTPException(404, "Subscription not found")
    return _sub_out(s)


@router.post("/subscriptions/{sid}/cancel")
async def cancel_subscription(sid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    s = await db.store_subscriptions.find_one({"_id": sid, "org_id": org_id})
    if not s:
        raise HTTPException(404, "Subscription not found")
    await db.store_subscriptions.update_one(
        {"_id": sid, "org_id": org_id},
        {"$set": {"status": "cancelled", "next_renewal_at": None,
                  "cancelled_at": utc_now_iso(), "updated_at": utc_now_iso()}})
    return {"ok": True}


@router.post("/subscriptions/{sid}/run-renewal")
async def force_renewal(sid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """DEV/demo helper: process one renewal now (simulated payment). Refused when simulation is off."""
    if not config.simulation_allowed():
        raise HTTPException(400, {"error": "live_billing_required",
                                  "message": "Live recurring charges require Stripe Billing (connect a provider)."})
    db = get_db()
    s = await db.store_subscriptions.find_one({"_id": sid, "org_id": org_id})
    if not s:
        raise HTTPException(404, "Subscription not found")
    if s.get("status") != "active":
        raise HTTPException(400, "Subscription is not active")
    order_id = await _create_renewal_order(db, s)
    s = await db.store_subscriptions.find_one({"_id": sid, "org_id": org_id})
    return {"ok": True, "order_id": order_id, "subscription": _sub_out(s)}


# ============================ PUBLIC (subscribe) ============================

class SubscribeBuyer(BaseModel):
    name: str = ""
    email: str = ""
    phone: str = ""


class SubscribeReq(BaseModel):
    product_id: str
    buyer: SubscribeBuyer = SubscribeBuyer()
    success_url: str = "/store/thank-you"
    customer_token: str = Field(default="", max_length=800)


@public_router.post("/{org_id}/subscribe")
async def subscribe(org_id: str, req: SubscribeReq):
    db = get_db()
    product = await db.store_products.find_one({"_id": req.product_id, "org_id": org_id})
    if not product or not product.get("active", True):
        raise HTTPException(404, "Product not available")
    if not product.get("is_subscription"):
        raise HTTPException(400, "This product is not a subscription")
    interval = product.get("billing_interval", "month")
    price = int(product.get("price_cents", 0))
    if not req.buyer.email and not req.buyer.phone:
        raise HTTPException(400, "An email or phone is required")
    from .store import _resolve_store_provider, _shopper_id_from_token
    provider_key, provider = await _resolve_store_provider(db, org_id)
    if provider_key == "simulated" and not config.simulation_allowed():
        raise HTTPException(400, {"error": "payments_not_configured",
                                  "message": "This store has no live payment provider connected yet."})
    customer_id = _shopper_id_from_token(req.customer_token, org_id)
    now = utc_now_iso()
    sub_id = uuid.uuid4().hex
    order_id = uuid.uuid4().hex
    # First order (period 1)
    order = {
        "_id": order_id, "org_id": org_id, "subscription_id": sub_id,
        "items": [{"product_id": product["_id"], "name": product["name"], "price_cents": price, "qty": 1}],
        "subtotal_cents": price, "shipping_cents": 0, "discount_cents": 0, "tax_cents": 0,
        "total_cents": price, "amount_charged_cents": price, "currency": product.get("currency", "USD"),
        "status": "pending", "buyer": req.buyer.model_dump(), "customer_id": customer_id,
        "status_history": [{"status": "pending", "at": now, "actor": "subscribe", "note": f"Subscription {interval}"}],
        "provider": provider_key, "provider_session_id": None,
        "is_subscription_order": True, "created_at": now, "updated_at": now,
    }
    result = await provider.create_checkout(CheckoutRequest(
        invoice_id=order_id, amount_cents=price, currency=order["currency"],
        customer_email=req.buyer.email or None, success_url=req.success_url, cancel_url="/store",
        metadata={"kind": "subscription", "order_id": order_id, "org_id": org_id, "subscription_id": sub_id}))
    if not result.ok:
        raise HTTPException(502, "Could not start checkout")
    order["provider_session_id"] = result.session_id
    await db.store_orders.insert_one(order)
    sub = {
        "_id": sub_id, "org_id": org_id, "product_id": product["_id"], "product_name": product["name"],
        "price_cents": price, "currency": product.get("currency", "USD"), "interval": interval,
        "status": "pending", "buyer": req.buyer.model_dump(), "customer_id": customer_id,
        "current_period_start": None, "next_renewal_at": None, "orders": [order_id],
        "provider": provider_key, "created_at": now, "updated_at": now,
    }
    await db.store_subscriptions.insert_one(sub)
    await db.payments.insert_one({
        "_id": uuid.uuid4().hex, "org_id": org_id, "kind": "store_order", "order_id": order_id,
        "amount_cents": price, "currency": order["currency"], "method": provider_key, "provider": provider_key,
        "provider_session_id": result.session_id, "status": "initiated", "created_at": now, "updated_at": now})
    return {"subscription_id": sub_id, "order_id": order_id, "checkout_url": result.checkout_url,
            "session_id": result.session_id, "provider": provider_key, "interval": interval,
            "price_cents": price, "simulated": provider_key == "simulated"}


# ============================ RENEWALS ============================

async def activate_subscription_for_order(db, order: Dict[str, Any]) -> None:
    """Called from store._finalize_paid_order when a subscription's order is paid."""
    sid = order.get("subscription_id")
    if not sid:
        return
    s = await db.store_subscriptions.find_one({"_id": sid})
    if not s or s.get("status") == "cancelled":
        return
    now = utc_now_iso()
    if s.get("status") == "pending":
        # First payment → activate
        await db.store_subscriptions.update_one(
            {"_id": sid}, {"$set": {"status": "active", "current_period_start": now,
                                    "next_renewal_at": _add_interval(s.get("interval", "month")),
                                    "updated_at": now}})


async def _create_renewal_order(db, sub: Dict[str, Any]) -> str:
    """Create an already-PAID renewal order (simulated) and advance the period."""
    now = utc_now_iso()
    order_id = uuid.uuid4().hex
    price = int(sub.get("price_cents", 0))
    order = {
        "_id": order_id, "org_id": sub["org_id"], "subscription_id": sub["_id"],
        "items": [{"product_id": sub["product_id"], "name": sub.get("product_name"), "price_cents": price, "qty": 1}],
        "subtotal_cents": price, "shipping_cents": 0, "discount_cents": 0, "tax_cents": 0,
        "total_cents": price, "amount_charged_cents": price, "currency": sub.get("currency", "USD"),
        "status": "paid", "paid_at": now, "buyer": sub.get("buyer", {}), "customer_id": sub.get("customer_id"),
        "status_history": [{"status": "paid", "at": now, "actor": "renewal", "note": "Subscription renewal (simulated)"}],
        "provider": "simulated_recurring", "is_subscription_order": True, "is_renewal": True,
        "created_at": now, "updated_at": now,
    }
    await db.store_orders.insert_one(order)
    await db.payments.insert_one({
        "_id": uuid.uuid4().hex, "org_id": sub["org_id"], "kind": "store_order", "order_id": order_id,
        "amount_cents": price, "currency": sub.get("currency", "USD"), "method": "simulated_recurring",
        "provider": "simulated_recurring", "status": "paid", "created_at": now, "updated_at": now})
    await db.store_subscriptions.update_one(
        {"_id": sub["_id"]},
        {"$set": {"current_period_start": now, "next_renewal_at": _add_interval(sub.get("interval", "month")),
                  "updated_at": now}, "$push": {"orders": order_id}})
    return order_id


async def process_due_renewals(db) -> int:
    """Renew every active subscription whose next_renewal_at has passed. Simulated only."""
    if not config.simulation_allowed():
        return 0
    now = utc_now_iso()
    count = 0
    async for s in db.store_subscriptions.find({"status": "active", "next_renewal_at": {"$lte": now, "$ne": None}}):
        try:
            await _create_renewal_order(db, s)
            count += 1
        except Exception as e:  # noqa: BLE001
            logger.warning("renewal failed for %s: %s", s.get("_id"), e)
    return count


async def _renewal_loop():
    await asyncio.sleep(20)
    while True:
        try:
            db = get_db()
            n = await process_due_renewals(db)
            if n:
                logger.info("processed %d subscription renewals", n)
        except Exception as e:  # noqa: BLE001
            logger.warning("renewal loop error: %s", e)
        await asyncio.sleep(300)  # every 5 minutes


def start_renewal_loop():
    try:
        asyncio.get_event_loop().create_task(_renewal_loop())
    except RuntimeError:
        pass
