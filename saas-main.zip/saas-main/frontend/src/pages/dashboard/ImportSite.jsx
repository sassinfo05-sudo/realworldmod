import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowRight, Globe, CheckCircle2, Loader2, AlertTriangle } from "lucide-react";

export default function ImportSite() {
    const [url, setUrl] = useState("");
    const [runId, setRunId] = useState(null);
    const [run, setRun] = useState(null);
    const [busy, setBusy] = useState(false);
    const navigate = useNavigate();

    async function start() {
        if (!url.trim()) return;
        setBusy(true);
        try {
            const { data } = await api.post("/import/start", { source_url: url.trim() });
            setRunId(data.import_run_id);
            toast.success("Fetching your site…");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Could not start import");
        } finally {
            setBusy(false);
        }
    }

    useEffect(() => {
        if (!runId) return;
        const iv = setInterval(async () => {
            try {
                const { data } = await api.get(`/import/runs/${runId}`);
                setRun(data);
                if (data.status === "ready" || data.status === "failed") clearInterval(iv);
            } catch { /* keep polling */ }
        }, 2500);
        return () => clearInterval(iv);
    }, [runId]);

    return (
        <div className="p-6 md:p-10 max-w-3xl" data-testid="import-page">
            <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Already have a website?</div>
            <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium">Point us at your current site.</h1>
            <p className="mt-3 text-zinc-600">
                We'll fetch the public pages, extract your services, hours and copy, and generate an improved private preview. We never touch your existing site.
            </p>

            <div className="mt-8 rounded-2xl border border-brand-line bg-white p-6 space-y-3">
                <Label>Website URL</Label>
                <div className="flex gap-2">
                    <Input value={url} onChange={(e) => setUrl(e.target.value)}
                           placeholder="https://your-current-site.com"
                           className="font-mono text-sm"
                           data-testid="import-url-input" />
                    <Button className="bg-brand-copper hover:bg-brand-copperHover text-white"
                            onClick={start} disabled={busy || !url.trim()}
                            data-testid="import-start-btn">
                        {busy ? "Starting…" : "Import"}
                    </Button>
                </div>
                <div className="text-xs text-zinc-500">Respects robots.txt. Fetches up to 6 pages, 10 seconds per page.</div>
            </div>

            {run && (
                <div className="mt-6 rounded-2xl border border-brand-line bg-white p-6 space-y-4" data-testid="import-run-card">
                    <div className="flex items-center gap-3">
                        {run.status === "ready" ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> :
                         run.status === "failed" ? <AlertTriangle className="w-5 h-5 text-red-600" /> :
                         <Loader2 className="w-5 h-5 text-brand-copper animate-spin" />}
                        <div>
                            <div className="font-medium capitalize">{run.status.replace("_", " ")}</div>
                            <div className="text-xs text-zinc-500 font-mono break-all">{run.source_url}</div>
                        </div>
                    </div>

                    {run.fetched_pages?.length > 0 && (
                        <div>
                            <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Pages fetched ({run.fetched_pages.length})</div>
                            <ul className="text-sm space-y-1">
                                {run.fetched_pages.map((p, i) => (
                                    <li key={i} className="flex items-center gap-2" data-testid={`import-page-${i}`}>
                                        <Globe className="w-3.5 h-3.5 text-zinc-400" />
                                        <span className="truncate">{p.title}</span>
                                        <span className="text-zinc-500 font-mono text-xs truncate">{p.url}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}

                    {run.extracted_facts && Object.keys(run.extracted_facts).length > 0 && (
                        <div>
                            <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Facts we found</div>
                            <div className="text-sm space-y-1">
                                {Object.entries(run.extracted_facts).map(([k, v]) => (
                                    <div key={k} className="grid grid-cols-[140px_1fr] gap-2 py-1 border-b border-brand-line last:border-b-0" data-testid={`import-fact-${k}`}>
                                        <div className="text-xs uppercase tracking-widest text-zinc-500">{k.replace("_", " ")}</div>
                                        <div className="text-zinc-800 break-words">
                                            {Array.isArray(v) ? v.join(", ") : String(v || "—")}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {run.planned_redirects?.length > 0 && (
                        <div>
                            <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Planned redirects</div>
                            <ul className="text-sm font-mono space-y-1" data-testid="import-redirects">
                                {run.planned_redirects.map((r, i) => (
                                    <li key={i} className="text-zinc-700">
                                        <span className="text-zinc-500">{r.from}</span> → /{r.to}
                                    </li>
                                ))}
                            </ul>
                            <div className="mt-2 text-xs text-zinc-500">
                                Set these up at your registrar or in your old CMS to preserve SEO after switching.
                            </div>
                        </div>
                    )}

                    {run.status === "ready" && (
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white"
                                onClick={() => navigate("/app/editor")}
                                data-testid="import-open-editor">
                            Open the improved site in the editor <ArrowRight className="w-4 h-4 ml-1" />
                        </Button>
                    )}

                    {run.error && (
                        <div className="rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm" data-testid="import-error">
                            {run.error}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
