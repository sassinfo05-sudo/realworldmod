import { useEffect } from "react";
import { useBrand } from "@/context/BrandContext";

/** Per-page <title> + dynamic favicon. Call from any page: usePageMeta("Inbox"). */
export function setFavicon(svgOrUrl) {
    if (!svgOrUrl) return;
    let link = document.querySelector("link[rel~='icon']");
    if (!link) { link = document.createElement("link"); link.rel = "icon"; document.head.appendChild(link); }
    if (svgOrUrl.trim().startsWith("<svg")) {
        link.type = "image/svg+xml";
        link.href = `data:image/svg+xml;utf8,${encodeURIComponent(svgOrUrl)}`;
    } else {
        link.type = "";
        link.href = svgOrUrl;
    }
}

export function letterFavicon(letter, color = "#4F46E5") {
    const l = (letter || "Z").slice(0, 1).toUpperCase();
    return `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><rect width='64' height='64' rx='14' fill='${color}'/><text x='32' y='43' font-family='Inter,Arial,sans-serif' font-size='36' font-weight='700' fill='white' text-anchor='middle'>${l}</text></svg>`;
}

export default function usePageMeta(title, { favicon, siteName } = {}) {
    const brand = useBrand();
    useEffect(() => {
        const base = siteName || brand?.name || "Zanelvo";
        document.title = title ? `${title} · ${base}` : base;
        if (favicon) setFavicon(favicon);
        else if (brand?.logo_svg) setFavicon(brand.logo_svg);
        else setFavicon(letterFavicon(base[0]));
    }, [title, favicon, siteName, brand?.name, brand?.logo_svg]);
}
