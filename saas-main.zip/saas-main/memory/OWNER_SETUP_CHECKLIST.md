# Owner Setup Checklist

For an owner going live. Do these in order.

> **Setup philosophy.** The platform ships with payments, AI and email working out of
> the box (simulated/managed), so your customers (tenants) never hunt for API keys.
> **You, the owner/founder, configure the shared platform keys once** (Stripe, email
> provider, Cloudflare, voice, ads) in the Founder panel / backend `.env`. The only
> things a tenant ever sets up are things unique to them that you cannot own on their
> behalf — chiefly **their own custom domain**. Everything below marked _(founder-level)_
> is done once by you; _(tenant)_ items are the short list a customer touches.

## 1. Identity & brand
- [ ] Sign up at `/signup` → complete the interview.
- [ ] Review generated business facts in `/onboarding/review`.
- [ ] Open `/app/editor` → adjust hero, services, contact form.
- [ ] Upload logo + set primary color in **Setup → Brand** (or Settings → Brand).
- [ ] Publish.

## 2. Domain
- [ ] Register your domain (e.g. `zanelvo.com`) at your registrar.
- [ ] In `/app/domains`, add your hostname.
- [ ] Copy the CNAME + TXT records into your DNS provider.
- [ ] Wait for **Connected** state (DNS + SSL check).
- [ ] For Cloudflare-for-SaaS real cutover: platform needs `CF_API_TOKEN` and `CF_ACCOUNT_ID` set.

## 3. Team
- [ ] `/app/settings/team` → invite each teammate with the right role.
- [ ] Ask them to log in and enroll MFA in **Setup → Security & MFA**.

## 4. Email sending
- [ ] Choose Resend or SMTP.
- [ ] Add API key or SMTP credentials in **Setup → Email sending**.
- [ ] Send a test email to yourself.
- [ ] Add a `From:` address that matches a domain you own.

## 5. Payments
- [ ] _(tenant)_ Simulated provider works out of the box — buyers pay on the in-app test page.
- [ ] _(founder-level)_ For live charges: Stripe onboarding at `dashboard.stripe.com`.
      → Developers → API keys → copy the **Secret key** (`sk_live_…`/`sk_test_…`). Set
      `STRIPE_SECRET_KEY` in backend `.env`.
- [ ] _(founder-level)_ For webhooks: Stripe → Developers → Webhooks → **Add endpoint**
      = `{BACKEND_URL}/api/billing/webhook/stripe`, listen for `checkout.session.completed`.
      Copy the **Signing secret** (`whsec_…`) → set `STRIPE_WEBHOOK_SECRET` in backend `.env`.
      (Until this is set, the webhook endpoint safely returns **400** for every call — by design.)
- [ ] Restart backend, verify Payments shows Connected. Complete a real test payment.

## 5b. Online store & products
- [ ] _(tenant)_ **Products** (`/app/store/products`) → add products (image, price, stock, active),
      or **Import CSV** (map name/price/stock/sku/image), or **Source products**:
      - **Starter catalog** — one click, no account, seeds sample products to edit/delete.
      - **AliExpress / CJ Dropshipping** — dropship from a supplier. Paste the supplier key
        under **Integrations → E-commerce** first (see key steps in that page's cards).
- [ ] _(tenant)_ Share your storefront: `/store/{your_org_id}` (the **View storefront** button
      on the Products page). Buyers pick a product → **Buy now** → pay → stock decrements and
      the order appears under **Orders** (`/app/store/orders`), where you mark it **Fulfilled**.
- [ ] Buyer + owner get an order-paid email via your configured email provider (simulated
      until you connect one — honestly labeled).

## 6. Booking
- [ ] `/app/settings/services` → add every service, price, duration, buffers.
- [ ] `/app/settings/staff` → weekly working hours per teammate; assign services.
- [ ] Book a slot on your own site as a visitor to verify the confirmation email flow.

## 7. AI receptionist
- [ ] `/app/knowledge` → paste your key facts / FAQs / policy docs.
- [ ] `/app/ai/{receptionist_id}` → adjust the tone + allowed tools.
- [ ] Test in the sandbox before promoting.
- [ ] Enable the widget on your published site.

## 8. Voice (endpoints live — awaiting your number/agent binding)
Both webhook endpoints are already implemented and live. They stay in "configured —
awaiting binding" until you point a real provider at them (see `/app/ai/calls` cards).

- [ ] _(founder-level)_ **Twilio**: Console → Phone Numbers → your number → **Voice** →
      "A CALL COMES IN" = **Webhook**, **HTTP POST**, URL =
      `{BACKEND_URL}/api/voice/twilio/inbound?org_id=<ORG_ID>`. Save. Incoming callers now
      talk to your receptionist via a speech `<Gather>` loop.
- [ ] _(founder-level)_ **Retell**: Dashboard → your Agent → **Webhook URL** =
      `{BACKEND_URL}/api/voice/retell/webhook?org_id=<ORG_ID>`; attach a phone number.
- [ ] Otherwise use the in-app call simulator (`/app/ai/calls`) to demo behavior with no keys.

## 9. Calendars (adapter path — not yet live)
- [ ] Google / Microsoft calendar sync is architecture-ready but requires OAuth credentials to activate. Track in `INTEGRATIONS.md`.

## 10. Analytics / ads (adapter path)
- [ ] GA4 tracking id added under **Setup → Google Analytics 4**.
- [ ] Meta Pixel: paste id under **Setup → Meta Ads**.
- [ ] Google Ads conversion action: paste id under **Setup → Google Ads**.

## 11. Marketing
- [ ] `/app/marketing/campaigns` → create your first campaign.
- [ ] `/app/marketing/automations` → publish one of the seeded templates or your own.

## 12. Founder-only (`platform_founder` role)
- [ ] Complete MFA enrollment (required-by-default).
- [ ] Set an announcement banner if you're mid-migration.
- [ ] Review the cockpit weekly. Suspend a tenant only with a written reason (it lives in the audit log forever).

## Credentials to have on hand
- Stripe: publishable + secret keys.
- Resend or SMTP.
- Cloudflare API token + Account ID (for real custom-domain cutover).
- Retell API key or Twilio Account SID + Auth Token (for voice).
- Google Cloud OAuth client for Calendar / Business Profile.
- Meta Business Manager: App ID + access token for Ads / Pixel.

## Round 17 — Object storage (owner/founder action)
1. Create an S3-compatible bucket (Cloudflare R2 recommended, or AWS S3 / Backblaze B2).
2. In Setup Center → Storage (founder): PUT provider, bucket, endpoint, region, public_base_url (CDN),
   access_key_id, secret_access_key. (Entered in-app; never pasted into chat. Encrypted at rest.)
3. Run the storage test → expect Connected. Until then status is Sandbox/Not connected and, in production,
   new uploads are blocked (existing content unaffected).
4. Optional: run `python -m scripts.migrate_inline_assets --dry-run` then without --dry-run to move legacy
   base64 media into storage, then `--cleanup` after verification.
