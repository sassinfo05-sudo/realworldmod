import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PublicNav from "@/components/PublicNav";
import SocialButtons from "@/components/SocialButtons";
import { useAuth } from "@/context/AuthContext";
import { useBrand } from "@/context/BrandContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ShieldCheck } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [remember, setRemember] = useState(false);
    const [busy, setBusy] = useState(false);
    const [showEmail, setShowEmail] = useState(true);
    const { login, verify2fa, resend2fa } = useAuth();
    const brand = useBrand();
    const navigate = useNavigate();
    const [challenge, setChallenge] = useState(null);
    const [code, setCode] = useState("");
    usePageMeta("Log in");

    async function onSubmit(e) {
        e.preventDefault();
        setBusy(true);
        try {
            const res = await login(email.trim(), password, remember);
            if (res?.mfa_required) {
                setChallenge(res);
                if (res.dev_code) setCode(res.dev_code);
                return;
            }
            toast.success("Welcome back.");
            navigate(res?.role === "platform_founder" ? "/staff" : "/app");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Login failed");
        } finally {
            setBusy(false);
        }
    }

    async function onVerify(e) {
        e.preventDefault();
        setBusy(true);
        try {
            const u = await verify2fa(challenge.challenge_id, code.trim());
            toast.success("Welcome back.");
            navigate(u?.role === "platform_founder" ? "/staff" : "/app");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Incorrect code");
        } finally { setBusy(false); }
    }

    async function onResend() {
        try { const d = await resend2fa(challenge.challenge_id); setChallenge(d); if (d.dev_code) setCode(d.dev_code); toast.success("New code sent"); }
        catch (err) { toast.error(err?.response?.data?.detail || "Could not resend"); }
    }

    if (challenge) {
        return (
            <div className="min-h-screen bg-brand-surface">
                <PublicNav />
                <div className="mx-auto max-w-md px-6 py-16" data-testid="login-2fa">
                    <div className="w-12 h-12 rounded-2xl bg-brand-copper/10 text-brand-copper grid place-items-center mb-5"><ShieldCheck className="w-6 h-6" /></div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Two-factor check</h1>
                    <p className="mt-2 text-sm text-zinc-500">
                        {challenge.method === "totp" ? "Enter the 6-digit code from your authenticator app." : <>We emailed a 6-digit code to <b>{challenge.masked_email}</b>. It expires in {Math.round((challenge.expires_in_sec || 600) / 60)} minutes.</>}
                    </p>
                    {challenge.delivery === "simulated" && challenge.dev_code && (
                        <div className="mt-3 text-xs rounded-lg bg-amber-50 border border-amber-200 text-amber-800 px-3 py-2" data-testid="login-2fa-devcode">Email delivery is not live yet — your code is <b>{challenge.dev_code}</b>.</div>
                    )}
                    <form onSubmit={onVerify} className="mt-6 space-y-4">
                        <Input value={code} onChange={(e) => setCode(e.target.value.replace(/[^0-9a-zA-Z-]/g, ""))} inputMode="numeric" autoFocus placeholder="000000" maxLength={12}
                               className="text-center text-2xl tracking-[0.5em] h-14" data-testid="login-2fa-code" />
                        <Button type="submit" disabled={busy || code.length < 6} className="w-full" data-testid="login-2fa-submit">{busy ? "Verifying…" : "Verify & sign in"}</Button>
                    </form>
                    <div className="mt-5 flex items-center justify-between text-sm text-zinc-500">
                        <button type="button" onClick={() => { setChallenge(null); setCode(""); }} className="hover:text-brand-ink">Back</button>
                        {challenge.method === "email" && <button type="button" onClick={onResend} className="hover:text-brand-ink" data-testid="login-2fa-resend">Resend code</button>}
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-brand-surface">
            <PublicNav />
            <div className="mx-auto max-w-md px-6 py-16">
                <h1 className="font-display text-3xl text-brand-ink font-medium" data-testid="login-title">
                    Welcome back.
                </h1>
                <p className="mt-2 text-sm text-zinc-500">Log in to your {brand?.name} workspace.</p>
                <div className="mt-8">
                    <SocialButtons mode="login" />
                </div>
                {!showEmail ? (
                    <button type="button" onClick={() => setShowEmail(true)} data-testid="login-use-email"
                        className="mt-5 w-full text-center text-sm text-zinc-500 hover:text-brand-ink">
                        Use email &amp; password instead
                    </button>
                ) : (
                <form onSubmit={onSubmit} className="mt-4 space-y-4" data-testid="login-form">
                    <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                            id="email"
                            type="email"
                            required
                            autoComplete="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="mt-1"
                            data-testid="login-email"
                        />
                    </div>
                    <div>
                        <Label htmlFor="password">Password</Label>
                        <Input
                            id="password"
                            type="password"
                            required
                            autoComplete="current-password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="mt-1"
                            data-testid="login-password"
                        />
                    </div>
                    <div className="flex items-center justify-between">
                        <label className="flex items-center gap-2 text-sm text-zinc-600 cursor-pointer select-none" data-testid="login-remember">
                            <input
                                type="checkbox"
                                checked={remember}
                                onChange={(e) => setRemember(e.target.checked)}
                                className="h-4 w-4 rounded border-brand-line text-brand-copper focus:ring-brand-copper"
                                data-testid="login-remember-checkbox"
                            />
                            Keep me signed in for 30 days
                        </label>
                    </div>
                    <Button
                        type="submit"
                        disabled={busy}
                        className="w-full"
                        data-testid="login-submit"
                    >
                        {busy ? "Signing in…" : "Sign in"}
                    </Button>
                </form>
                )}
                <div className="mt-6 text-sm text-zinc-500 flex items-center justify-between">
                    <Link to="/reset" className="hover:text-brand-ink" data-testid="login-reset-link">
                        Forgot password?
                    </Link>
                    <Link to="/signup" className="hover:text-brand-ink" data-testid="login-signup-link">
                        Create account
                    </Link>
                </div>
            </div>
        </div>
    );
}
