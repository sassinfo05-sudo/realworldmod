/**
 * ExtraBlocks — the "gadget" library: FAQ, gallery, pricing table, video, map, stats,
 * team, logo cloud, countdown, social links, rich text. All theme-aware via CSS vars set by
 * BlockRenderer (--tenant-primary etc.). Props are edited in the Inspector's generic
 * content editor, so every prop here is a plain string / number / array of flat objects.
 */
import { useEffect, useState } from "react";
import { ChevronDown, Facebook, Instagram, Linkedin, Twitter, Youtube, Check, MapPin } from "lucide-react";

const Section = ({ children, className = "", bg }) => (
    <section className={`px-6 py-16 md:py-20 ${className}`} style={bg ? { background: bg } : undefined}>
        <div className="mx-auto max-w-6xl">{children}</div>
    </section>
);
const Heading = ({ title, subtitle }) => (
    (title || subtitle) ? (
        <div className="max-w-2xl mb-10">
            {title && <h2 data-heading className="text-3xl md:text-4xl font-semibold leading-tight">{title}</h2>}
            {subtitle && <p className="mt-3 text-base md:text-lg opacity-75">{subtitle}</p>}
        </div>
    ) : null
);

export function FaqBlock({ block }) {
    const { title = "Frequently asked questions", subtitle, items = [] } = block.props || {};
    const [open, setOpen] = useState(0);
    return (
        <Section>
            <Heading title={title} subtitle={subtitle} />
            <div className="divide-y" style={{ borderColor: "var(--tenant-surface)" }}>
                {items.map((it, i) => (
                    <div key={i} className="py-4">
                        <button type="button" onClick={() => setOpen(open === i ? -1 : i)}
                            className="w-full flex items-center justify-between text-left gap-4 font-medium text-lg">
                            {it.question}
                            <ChevronDown className={`w-5 h-5 transition-transform ${open === i ? "rotate-180" : ""}`} style={{ color: "var(--tenant-primary)" }} />
                        </button>
                        {open === i && <p className="mt-2 opacity-80 leading-relaxed">{it.answer}</p>}
                    </div>
                ))}
            </div>
        </Section>
    );
}

export function GalleryBlock({ block }) {
    const { title, subtitle, images = [], columns = 3 } = block.props || {};
    const cols = { 2: "md:grid-cols-2", 3: "md:grid-cols-3", 4: "md:grid-cols-4" }[Number(columns)] || "md:grid-cols-3";
    return (
        <Section>
            <Heading title={title} subtitle={subtitle} />
            <div className={`grid grid-cols-2 ${cols} gap-3 md:gap-4`}>
                {images.map((im, i) => (
                    <figure key={i} className="overflow-hidden group" style={{ borderRadius: "var(--tenant-radius)" }}>
                        <img src={im.url} alt={im.caption || ""} loading="lazy"
                            className="w-full h-48 md:h-56 object-cover group-hover:scale-105 transition-transform duration-500" />
                        {im.caption && <figcaption className="text-xs mt-1.5 opacity-70">{im.caption}</figcaption>}
                    </figure>
                ))}
            </div>
        </Section>
    );
}

export function PricingTableBlock({ block }) {
    const { title = "Simple pricing", subtitle, plans = [] } = block.props || {};
    return (
        <Section bg="var(--tenant-surface)">
            <Heading title={title} subtitle={subtitle} />
            <div className="grid md:grid-cols-3 gap-6">
                {plans.map((p, i) => (
                    <div key={i} className="p-7 bg-white/90 flex flex-col relative"
                        style={{ borderRadius: "var(--tenant-radius)", border: p.featured ? "2px solid var(--tenant-primary)" : "1px solid rgba(0,0,0,0.08)",
                                 boxShadow: p.featured ? "0 20px 50px -20px var(--tenant-primary)" : "none" }}>
                        {p.badge && <span className="absolute -top-3 left-6 text-xs px-2.5 py-1 rounded-full text-white" style={{ background: "var(--tenant-primary)" }}>{p.badge}</span>}
                        <div className="text-sm font-medium opacity-70">{p.name}</div>
                        <div className="mt-2 flex items-baseline gap-1"><span className="text-4xl font-semibold">{p.price}</span><span className="opacity-60 text-sm">{p.period}</span></div>
                        <p className="mt-2 text-sm opacity-70">{p.description}</p>
                        <ul className="mt-5 space-y-2 text-sm flex-1">
                            {String(p.features || "").split("\n").filter(Boolean).map((f, j) => (
                                <li key={j} className="flex gap-2"><Check className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "var(--tenant-primary)" }} />{f}</li>
                            ))}
                        </ul>
                        <a href={p.cta_href || "#contact"} className="mt-6 inline-flex justify-center px-5 py-2.5 rounded-md font-medium text-white"
                           style={{ background: p.featured ? "var(--tenant-primary)" : "var(--tenant-fg)" }}>{p.cta_label || "Choose"}</a>
                    </div>
                ))}
            </div>
        </Section>
    );
}

function embedUrl(url = "") {
    const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{6,})/);
    if (yt) return `https://www.youtube.com/embed/${yt[1]}`;
    const vm = url.match(/vimeo\.com\/(\d+)/);
    if (vm) return `https://player.vimeo.com/video/${vm[1]}`;
    return url;
}

export function VideoBlock({ block }) {
    const { title, subtitle, url = "", caption } = block.props || {};
    const src = embedUrl(url);
    const isFile = /\.(mp4|webm|mov)(\?|$)/i.test(url);
    return (
        <Section>
            <Heading title={title} subtitle={subtitle} />
            <div className="aspect-video overflow-hidden bg-black shadow-xl" style={{ borderRadius: "var(--tenant-radius)" }}>
                {isFile ? <video src={url} controls className="w-full h-full" /> :
                    src ? <iframe title={title || "video"} src={src} className="w-full h-full" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowFullScreen /> :
                    <div className="w-full h-full grid place-items-center text-white/60 text-sm">Add a YouTube, Vimeo or .mp4 URL</div>}
            </div>
            {caption && <p className="mt-3 text-sm opacity-70 text-center">{caption}</p>}
        </Section>
    );
}

export function MapBlock({ block }) {
    const { title = "Find us", subtitle, address = "", height = 380 } = block.props || {};
    const src = address ? `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed` : "";
    return (
        <Section>
            <Heading title={title} subtitle={subtitle} />
            <div className="overflow-hidden border" style={{ borderRadius: "var(--tenant-radius)", height: Number(height) || 380 }}>
                {src ? <iframe title="map" src={src} className="w-full h-full" loading="lazy" referrerPolicy="no-referrer-when-downgrade" /> :
                    <div className="w-full h-full grid place-items-center opacity-60 text-sm"><MapPin className="w-5 h-5 mr-2" /> Enter an address</div>}
            </div>
            {address && <p className="mt-3 text-sm opacity-75 flex items-center gap-2"><MapPin className="w-4 h-4" /> {address}</p>}
        </Section>
    );
}

export function StatsBlock({ block }) {
    const { title, subtitle, items = [] } = block.props || {};
    return (
        <Section bg="var(--tenant-primary)" className="text-white">
            <Heading title={title} subtitle={subtitle} />
            <div className={`grid grid-cols-2 md:grid-cols-${Math.min(4, Math.max(2, items.length || 4))} gap-8`}>
                {items.map((it, i) => (
                    <div key={i}>
                        <div data-heading className="text-4xl md:text-5xl font-semibold">{it.value}</div>
                        <div className="mt-1 text-sm opacity-85">{it.label}</div>
                    </div>
                ))}
            </div>
        </Section>
    );
}

export function TeamBlock({ block }) {
    const { title = "Meet the team", subtitle, members = [] } = block.props || {};
    return (
        <Section>
            <Heading title={title} subtitle={subtitle} />
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
                {members.map((m, i) => (
                    <div key={i} className="text-center">
                        <div className="mx-auto w-28 h-28 rounded-full overflow-hidden mb-3" style={{ background: "var(--tenant-surface)" }}>
                            {m.photo ? <img src={m.photo} alt={m.name} className="w-full h-full object-cover" /> :
                                <div className="w-full h-full grid place-items-center text-2xl font-semibold" style={{ color: "var(--tenant-primary)" }}>{(m.name || "?")[0]}</div>}
                        </div>
                        <div className="font-medium">{m.name}</div>
                        <div className="text-sm opacity-70">{m.role}</div>
                        {m.bio && <p className="text-xs mt-2 opacity-70 leading-relaxed">{m.bio}</p>}
                    </div>
                ))}
            </div>
        </Section>
    );
}

export function LogoCloudBlock({ block }) {
    const { title = "Trusted by", logos = [] } = block.props || {};
    return (
        <Section className="py-12 md:py-14">
            {title && <p className="text-center text-xs uppercase tracking-[0.2em] opacity-60 mb-8">{title}</p>}
            <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-6 opacity-70 grayscale hover:grayscale-0 transition">
                {logos.map((l, i) => l.url ? <img key={i} src={l.url} alt={l.name || ""} className="h-8 md:h-10 object-contain" /> :
                    <span key={i} className="text-lg font-semibold">{l.name}</span>)}
            </div>
        </Section>
    );
}

export function CountdownBlock({ block }) {
    const { title = "Launching soon", subtitle, target = "", cta_label, cta_href } = block.props || {};
    const [left, setLeft] = useState(0);
    useEffect(() => {
        const t = new Date(target).getTime();
        const tick = () => setLeft(Math.max(0, (isNaN(t) ? 0 : t) - Date.now()));
        tick();
        const id = setInterval(tick, 1000);
        return () => clearInterval(id);
    }, [target]);
    const d = Math.floor(left / 86400000), h = Math.floor(left / 3600000) % 24, m = Math.floor(left / 60000) % 60, s = Math.floor(left / 1000) % 60;
    return (
        <Section bg="var(--tenant-fg)" className="text-white text-center">
            <h2 data-heading className="text-3xl md:text-4xl font-semibold">{title}</h2>
            {subtitle && <p className="mt-3 opacity-75">{subtitle}</p>}
            <div className="mt-8 flex justify-center gap-4 md:gap-8">
                {[["Days", d], ["Hours", h], ["Min", m], ["Sec", s]].map(([l, v]) => (
                    <div key={l} className="w-20 md:w-24 py-4 rounded-xl bg-white/10 backdrop-blur">
                        <div className="text-3xl md:text-4xl font-semibold tabular-nums">{String(v).padStart(2, "0")}</div>
                        <div className="text-[11px] uppercase tracking-widest opacity-70 mt-1">{l}</div>
                    </div>
                ))}
            </div>
            {cta_label && <a href={cta_href || "#"} className="mt-8 inline-flex px-6 py-3 rounded-md font-medium text-white" style={{ background: "var(--tenant-primary)" }}>{cta_label}</a>}
        </Section>
    );
}

const SOCIAL_ICONS = { facebook: Facebook, instagram: Instagram, linkedin: Linkedin, twitter: Twitter, x: Twitter, youtube: Youtube };
export function SocialLinksBlock({ block }) {
    const { title = "Follow us", links = [] } = block.props || {};
    return (
        <Section className="py-12 text-center">
            {title && <h3 data-heading className="text-2xl font-semibold mb-6">{title}</h3>}
            <div className="flex justify-center gap-3 flex-wrap">
                {links.filter((l) => l.url).map((l, i) => {
                    const Icon = SOCIAL_ICONS[(l.network || "").toLowerCase()] || Instagram;
                    return (
                        <a key={i} href={l.url} target="_blank" rel="noreferrer" aria-label={l.network}
                           className="w-12 h-12 rounded-full grid place-items-center text-white hover:scale-110 transition-transform"
                           style={{ background: "var(--tenant-primary)" }}><Icon className="w-5 h-5" /></a>
                    );
                })}
            </div>
        </Section>
    );
}

export function TextBlock({ block }) {
    const { title, body = "", align = "left" } = block.props || {};
    return (
        <Section>
            <div className={`max-w-3xl ${align === "center" ? "mx-auto text-center" : ""}`}>
                {title && <h2 data-heading className="text-3xl font-semibold mb-4">{title}</h2>}
                {String(body).split(/\n{2,}/).map((p, i) => <p key={i} className="opacity-85 leading-relaxed mb-4 whitespace-pre-line">{p}</p>)}
            </div>
        </Section>
    );
}

export const EXTRA_REGISTRY = {
    faq: FaqBlock, gallery: GalleryBlock, pricing_table: PricingTableBlock, video: VideoBlock, map: MapBlock,
    stats: StatsBlock, team: TeamBlock, logo_cloud: LogoCloudBlock, countdown: CountdownBlock,
    social_links: SocialLinksBlock, text: TextBlock,
};

export const EXTRA_DEFAULT_PROPS = {
    faq: { title: "Frequently asked questions", subtitle: "Everything you need to know.", items: [
        { question: "How quickly can you start?", answer: "Usually within 48 hours of your first call." },
        { question: "Do you offer guarantees?", answer: "Yes — every job is backed by our satisfaction guarantee." },
        { question: "Which areas do you serve?", answer: "We cover the whole metro area and surrounding towns." }] },
    gallery: { title: "Our work", subtitle: "A few recent projects.", columns: 3, images: [
        { url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800", caption: "Kitchen refresh" },
        { url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800", caption: "Living room" },
        { url: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800", caption: "Bathroom" }] },
    pricing_table: { title: "Simple pricing", subtitle: "No surprises. Cancel anytime.", plans: [
        { name: "Basic", price: "$49", period: "/visit", description: "For small jobs.", features: "1 hour on site\nMaterials extra\nSame-week booking", cta_label: "Book Basic", cta_href: "#contact", featured: false },
        { name: "Standard", price: "$99", period: "/visit", description: "Our most popular option.", features: "Up to 3 hours\nMaterials included\nNext-day booking\nPriority support", cta_label: "Book Standard", cta_href: "#contact", featured: true, badge: "Most popular" },
        { name: "Premium", price: "$199", period: "/visit", description: "Full-day projects.", features: "Full day\nAll materials\nDedicated crew\n12-month warranty", cta_label: "Book Premium", cta_href: "#contact", featured: false }] },
    video: { title: "See how we work", subtitle: "", url: "https://www.youtube.com/watch?v=ysz5S6PUM-U", caption: "" },
    map: { title: "Find us", subtitle: "", address: "1600 Amphitheatre Parkway, Mountain View, CA", height: 380 },
    stats: { title: "", subtitle: "", items: [{ value: "1,200+", label: "Happy customers" }, { value: "15 yrs", label: "In business" }, { value: "4.9★", label: "Average rating" }, { value: "24/7", label: "Emergency service" }] },
    team: { title: "Meet the team", subtitle: "The people behind the work.", members: [
        { name: "Alex Rivera", role: "Founder", photo: "", bio: "" }, { name: "Sam Chen", role: "Lead technician", photo: "", bio: "" },
        { name: "Jordan Lee", role: "Customer care", photo: "", bio: "" }, { name: "Priya Patel", role: "Operations", photo: "", bio: "" }] },
    logo_cloud: { title: "Trusted by local businesses", logos: [{ name: "Acme Co", url: "" }, { name: "Northwind", url: "" }, { name: "Globex", url: "" }, { name: "Initech", url: "" }] },
    countdown: { title: "Grand opening", subtitle: "Doors open soon — be the first in line.", target: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 16), cta_label: "Reserve a spot", cta_href: "#contact" },
    social_links: { title: "Follow us", links: [{ network: "instagram", url: "https://instagram.com" }, { network: "facebook", url: "https://facebook.com" }, { network: "linkedin", url: "" }, { network: "youtube", url: "" }] },
    text: { title: "About this section", body: "Write anything here — a story, an announcement, or details about a service.\n\nBlank lines create new paragraphs.", align: "left" },
};
