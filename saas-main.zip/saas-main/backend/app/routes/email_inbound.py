"""Public inbound-email webhooks: Resend + SendGrid Inbound Parse (Round 10 / Gate 1G).

Authentication (in order of strength):
  1. Resend: provider-native **Svix signature** (`svix-id`, `svix-timestamp`, `svix-signature`) verified with
     the `resend_signing_secret` (whsec_…) from the Staff Email config. When that secret is configured the
     signature is REQUIRED (shared-secret fallback is disabled for Resend).
  2. Shared inbound secret (`?secret=` / `X-Inbound-Secret`), constant-time compared. SendGrid Inbound Parse
     does not sign payloads, so this is its only option (put the secret in the Parse URL).
  3. With neither configured the endpoint REFUSES in production and accepts only in dev/test/demo.

Tenant binding: the recipient address is resolved to an org (organization.contact_email /
inbound_email / tenant email from_email / a verified custom domain). Matching mail lands in that
tenant's unified inbox (conversation + message + CRM contact); everything else goes to the platform
(staff) inbox. Idempotent by provider event id.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import re
import time
from typing import Any, Dict, Optional

import uuid
from fastapi import APIRouter, HTTPException, Request

from ..db import get_db, utc_now_iso
from ..services import integrations as integ

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/webhooks/email", tags=["email-inbound"])

_SVIX_TOLERANCE_S = 300


def verify_svix(secret: str, headers: Dict[str, str], body: bytes) -> bool:
    """Standard Svix/Resend webhook verification (HMAC-SHA256 over `id.timestamp.body`)."""
    try:
        msg_id = headers.get("svix-id") or headers.get("webhook-id") or ""
        ts = headers.get("svix-timestamp") or headers.get("webhook-timestamp") or ""
        sigs = headers.get("svix-signature") or headers.get("webhook-signature") or ""
        if not (msg_id and ts and sigs):
            return False
        if abs(time.time() - int(ts)) > _SVIX_TOLERANCE_S:
            return False
        raw = secret.split("_", 1)[1] if secret.startswith("whsec_") else secret
        key = base64.b64decode(raw + "=" * (-len(raw) % 4))
        signed = f"{msg_id}.{ts}.".encode() + body
        expected = base64.b64encode(hmac.new(key, signed, hashlib.sha256).digest()).decode()
        for part in sigs.split(" "):
            if "," in part:
                _v, sig = part.split(",", 1)
                if hmac.compare_digest(sig, expected):
                    return True
        return False
    except Exception:  # noqa: BLE001
        return False


def verify_sendgrid_ecdsa(public_key_b64: str, headers: Dict[str, str], body: bytes) -> bool:
    """SendGrid Signed Event Webhook: ECDSA (P-256/SHA-256) over `timestamp + body`."""
    try:
        import base64
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        sig = headers.get("x-twilio-email-event-webhook-signature") or ""
        ts = headers.get("x-twilio-email-event-webhook-timestamp") or ""
        if not sig or not ts:
            return False
        if abs(time.time() - int(float(ts))) > 300:
            return False
        pem = ("-----BEGIN PUBLIC KEY-----\n" + public_key_b64.strip() + "\n-----END PUBLIC KEY-----\n").encode()
        pub = serialization.load_pem_public_key(pem)
        pub.verify(base64.b64decode(sig), ts.encode() + body, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:  # noqa: BLE001
        return False


async def _authenticate(request: Request, provider: str, body: bytes) -> Dict[str, Any]:
    """Returns {"ok": bool, "method": "svix"|"sendgrid_ecdsa"|"shared_secret"|"dev_open"|"none"}.
    Order: provider-native signature (required when configured) → shared secret → dev-open (non-prod only)."""
    from .. import config
    from ..services import rate_limit as rl
    rl.check("email_inbound_webhook", request, limit=120, window_seconds=60)
    cfg = (await integ._raw()).get("email", {}) or {}
    signing = (cfg.get("resend_signing_secret") or "").strip()
    sg_pub = (cfg.get("sendgrid_event_public_key") or "").strip()
    shared = (cfg.get("inbound_secret") or "").strip()
    hdrs = {k.lower(): v for k, v in request.headers.items()}
    if provider == "resend" and signing:
        ok = verify_svix(signing, hdrs, body)
        return {"ok": ok, "method": "svix"}
    if provider == "sendgrid" and sg_pub and "x-twilio-email-event-webhook-signature" in hdrs:
        return {"ok": verify_sendgrid_ecdsa(sg_pub, hdrs, body), "method": "sendgrid_ecdsa"}
    if shared:
        got = request.query_params.get("secret") or request.headers.get("x-inbound-secret") or ""
        return {"ok": hmac.compare_digest(str(got), str(shared)), "method": "shared_secret"}
    if config.APP_ENV in ("dev", "test", "demo"):
        return {"ok": True, "method": "dev_open"}
    return {"ok": False, "method": "none"}


_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")


def _addr(v: Any) -> str:
    """Extract a bare lowercase address from 'Name <a@b.c>' / list forms."""
    if isinstance(v, list):
        v = v[0] if v else ""
    m = _EMAIL_RE.search(str(v or ""))
    return (m.group(0) if m else str(v or "")).lower().strip()


async def resolve_org_for_address(to_email: str) -> Optional[str]:
    """Map a recipient address to a tenant org id (or None → platform inbox)."""
    db = get_db()
    to_email = (to_email or "").lower().strip()
    if not to_email or "@" not in to_email:
        return None
    domain = to_email.split("@", 1)[1]
    # 1) Platform-assigned tenant mailbox (verified identifier: we allocated it).
    org = await db.organizations.find_one({"inbound_email": to_email}, {"_id": 1})
    if org:
        return str(org["_id"])
    # Platform email domain is never a tenant domain: anything else @platform-domain goes to the platform inbox.
    try:
        from ..services import platform_settings as _ps
        _st = await _ps.get_settings()
        _pdom = (_st.get("email_domain") or ((_st.get("emails") or {}).get("support") or {}).get("address", "support@zanelvo.com").split("@")[-1] or "zanelvo.com").lower()
    except Exception:  # noqa: BLE001
        _pdom = "zanelvo.com"
    if domain == _pdom or domain.endswith("." + _pdom):
        return None
    # 2) Tenant custom domain — ONLY when ownership/DNS verification succeeded (state connected/active).
    #    Tenant-declared, unverified fields (contact_email, from_email, reply_to) are deliberately NOT used:
    #    a tenant could otherwise claim another tenant's address and receive their mail.
    dom = await db.domains.find_one(
        {"hostname": {"$in": [domain, f"www.{domain}"]},
         "state": {"$in": ["connected", "active"]}},
        {"org_id": 1})
    if dom and dom.get("org_id"):
        return str(dom["org_id"])
    return None


async def _deliver_to_tenant(org_id: str, msg: Dict[str, Any], provider: str) -> Dict[str, Any]:
    """Create contact + conversation + inbound message in the tenant's unified inbox."""
    from ..models_crm import Conversation, Message, MessageAddress
    from .crm import upsert_contact_from_form, _record_interaction
    db = get_db()
    from_email = _addr(msg.get("from"))
    contact_id = await upsert_contact_from_form(
        db, org_id, {"email": from_email, "name": msg.get("from_name", "")}, source="inbound_email")
    conv = Conversation(org_id=org_id, channel="email", contact_id=contact_id,
                        subject=msg.get("subject") or "(no subject)", status="open", unread=True,
                        last_message_at=utc_now_iso(),
                        last_message_preview=(msg.get("text") or "")[:160])
    r = await db.conversations.insert_one(conv.to_mongo())
    conv_id = str(r.inserted_id)
    m = Message(org_id=org_id, conversation_id=conv_id, direction="inbound", channel="email",
                from_addr=MessageAddress(email=from_email, name=msg.get("from_name") or None),
                subject=msg.get("subject") or "(no subject)", body_text=msg.get("text") or "",
                body_html=msg.get("html") or None, sent_at=utc_now_iso(),
                delivery={"provider": provider, "simulated": False, "status": "received"})
    mr = await db.messages.insert_one(m.to_mongo())
    await _record_interaction(db, org_id, contact_id=contact_id, type_="email_received",
                              summary=f"Received: {msg.get('subject') or '(no subject)'}",
                              ref_type="message", ref_id=str(mr.inserted_id),
                              meta={"conversation_id": conv_id, "provider": provider})
    return {"org_id": org_id, "conversation_id": conv_id, "message_id": str(mr.inserted_id)}


async def _save(msg: Dict[str, Any], provider: str, event_id: Optional[str] = None,
                auth_method: str = "") -> Dict[str, Any]:
    db = get_db()
    if event_id:
        # ATOMIC claim on the unique (provider, event_id) index — concurrent duplicates lose the race.
        from pymongo.errors import DuplicateKeyError
        try:
            await db.webhook_events.insert_one({"_id": f"email:{provider}:{event_id}", "provider": f"email:{provider}",
                                                "event_id": event_id, "created_at": utc_now_iso()})
        except DuplicateKeyError:
            return {"ok": True, "duplicate": True}
    to_email = _addr(msg.get("to"))
    org_id = await resolve_org_for_address(to_email)
    routed: Dict[str, Any] = {}
    if org_id:
        try:
            routed = await _deliver_to_tenant(org_id, msg, provider)
        except Exception as exc:  # noqa: BLE001
            logger.warning("inbound email tenant routing failed (%s): %s", org_id, exc)
            org_id = None
    await db.inbox_messages.insert_one({
        "provider": provider, "auth_method": auth_method, "org_id": org_id,
        "from_email": _addr(msg.get("from")), "from_name": msg.get("from_name", ""),
        "to_email": to_email, "subject": msg.get("subject") or "(no subject)",
        "text": msg.get("text", ""), "html": msg.get("html", ""),
        "direction": "inbound", "read": False, "replied": False, "created_at": utc_now_iso(),
        "routed_to": ("tenant" if org_id else "platform"), **({"tenant_ref": routed} if routed else {}),
    })
    return {"ok": True, "routed_to": ("tenant" if org_id else "platform"), "org_id": org_id}


@router.post("/resend")
async def resend_inbound(request: Request):
    body = await request.body()
    auth = await _authenticate(request, "resend", body)
    if not auth["ok"]:
        raise HTTPException(401 if auth["method"] == "none" else 403, "Invalid or missing webhook signature")
    try:
        import json
        event = json.loads(body or b"{}")
    except Exception:  # noqa: BLE001
        return {"ok": False}
    etype = event.get("type") or ""
    if etype in ("email.bounced", "email.complained", "email.delivered", "email.delivery_delayed"):
        return await _delivery_event("resend", etype.split(".", 1)[1], event.get("data", {}) or {}, event.get("created_at"))
    if etype != "email.received":
        return {"ok": True, "ignored": True}
    data = event.get("data", {}) or {}
    return await _save({"from": data.get("from", ""), "to": _first(data.get("to")),
                        "subject": data.get("subject", ""), "text": data.get("text", ""),
                        "html": data.get("html", "")}, "resend", data.get("email_id"), auth["method"])


@router.post("/sendgrid")
async def sendgrid_inbound(request: Request):
    body = await request.body()
    auth = await _authenticate(request, "sendgrid", body)
    if not auth["ok"]:
        raise HTTPException(401 if auth["method"] == "none" else 403, "Invalid or missing webhook signature")
    # SendGrid Event Webhook posts a JSON ARRAY of events (bounce/dropped/spamreport/delivered…);
    # the Inbound Parse webhook posts multipart form data. Handle both on this URL.
    if (request.headers.get("content-type") or "").startswith("application/json"):
        try:
            import json as _json
            events = _json.loads(body or b"[]")
        except Exception:  # noqa: BLE001
            return {"ok": False}
        handled = 0
        for ev in (events if isinstance(events, list) else [events]):
            kind = {"bounce": "bounced", "dropped": "bounced", "spamreport": "complained",
                    "delivered": "delivered", "deferred": "delivery_delayed"}.get(ev.get("event"))
            if kind:
                await _delivery_event("sendgrid", kind, {"to": ev.get("email"), "from": ev.get("from") or "",
                                                          "email_id": ev.get("sg_message_id"), "reason": ev.get("reason")}, ev.get("timestamp"))
                handled += 1
        return {"ok": True, "handled": handled}
    try:
        form = await request.form()
    except Exception:  # noqa: BLE001
        return {"ok": False}
    return await _save({"from": form.get("from", ""), "to": form.get("to", ""),
                        "subject": form.get("subject", ""), "text": form.get("text", ""),
                        "html": form.get("html", "")}, "sendgrid", None, auth["method"])


def _first(v: Any) -> str:
    if isinstance(v, list) and v:
        return str(v[0])
    return str(v or "")


# ---------------------------------------------------------------- delivery events (Round 11)

async def _delivery_event(provider: str, kind: str, data: Dict[str, Any], at: Any = None) -> Dict[str, Any]:
    """Bounce / complaint / delivered / delayed events from the provider.

    Tenant is resolved from the SENDER address (the tenant's from/reply address) via `resolve_org_for_address`;
    unresolved events belong to the platform's own mail. Hard bounces + complaints add the recipient to
    `db.suppressions` (tenant-scoped) so campaigns/workflows stop sending; `email_logs` rows are annotated.
    """
    db = get_db()
    to = _first(data.get("to")) if not isinstance(data.get("to"), str) else data.get("to")
    to = (to or "").strip().lower()
    frm = (data.get("from") or "").strip().lower()
    if "<" in frm and ">" in frm:
        frm = frm[frm.index("<") + 1:frm.index(">")]
    mid = data.get("email_id") or data.get("message_id")
    org_id = await resolve_org_for_address(frm) if frm else None
    now = utc_now_iso()
    row = {"_id": uuid.uuid4().hex, "provider": provider, "kind": kind, "to": to, "from": frm, "org_id": org_id,
           "provider_message_id": mid, "reason": (data.get("reason") or (data.get("bounce") or {}).get("message") or "")[:300],
           "created_at": now}
    await db.email_events.insert_one(row)
    if mid:
        await db.email_logs.update_many({"provider_message_id": mid},
                                        {"$set": {"delivery_status": kind, "delivery_updated_at": now}})
    if kind in ("bounced", "complained") and to:
        reason = "bounce" if kind == "bounced" else "complaint"
        if org_id:
            await db.suppressions.update_one({"org_id": org_id, "email": to},
                                             {"$set": {"reason": reason, "source": provider, "updated_at": now},
                                              "$setOnInsert": {"org_id": org_id, "email": to, "created_at": now}}, upsert=True)
        else:
            await db.platform_suppressions.update_one({"email": to}, {"$set": {"reason": reason, "source": provider, "updated_at": now},
                                                                       "$setOnInsert": {"email": to, "created_at": now}}, upsert=True)
    return {"ok": True, "kind": kind, "routed_to": "tenant" if org_id else "platform"}
