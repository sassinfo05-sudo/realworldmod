import React from "react";
import { Sun, Moon } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";

export default function ThemeToggle({ className = "" }) {
    const { isDark, toggle } = useTheme();
    return (
        <button
            type="button"
            onClick={toggle}
            aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
            title={isDark ? "Light mode" : "Dark mode"}
            data-testid="theme-toggle"
            className={`inline-flex items-center justify-center w-9 h-9 rounded-lg border border-brand-line text-zinc-500 hover:text-brand-ink hover:bg-brand-cream transition-colors ${className}`}
        >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
    );
}
