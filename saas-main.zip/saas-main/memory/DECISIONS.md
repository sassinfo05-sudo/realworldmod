# Brand Naming DECISIONS — Historical Record

_This is the ONLY file allowed to contain the deprecated "Onvara" reference — kept as an audit trail of why the rebrand happened and how the new name was chosen._

## Timeline

- **2026-09-03 (Phase 1 build)** — provisional name **"Onvara"** was picked after a light web-screen. Marked provisional pending registration.
- **2026-09-03 (post-Phase-1 correction)** — user reported that **Onvara GmbH** (onvara.de), an active German company in technical project / procurement services, uses the exact name. The original screen missed it. Rebrand required before Phase 2.
- **2026-09-03 (this decision)** — screened 22+ fresh candidates against active exact-name entities, confusingly similar SaaS brands, and negative language meanings. Picked **"Yavren"**.

## Requirements (from user, revised)

- Short, globally brandable, invented or distinctive English name; 1–3 syllables; easy to pronounce/hear/remember/spell. Brand quality comparable to Wix / Stripe / Canva.
- NOT restricted to websites, AI, calls, marketing, or one industry — the product becomes a full small-business operating system.
- No "AI + generic word" pattern.
- Hebrew pronunciation NO LONGER required.
- REJECT: active exact-name companies, confusingly similar tech/SaaS brands, major trademark conflicts (USPTO/EUIPO), negative meanings in Spanish/German/French/Portuguese/Arabic/Hindi, taken software product names.

## Chosen name: **Yavren** _(provisional pending registration)_

- Pronunciation: `YAV-ren` (2 syllables). Rhymes with "haven" but with a `-vren` ending.
- Coined; not a real word in the required languages.
- 6 letters, easy to spell, uncommon `Y-`-start creates a distinctive shelf presence.
- No industry/topic anchor — works for the full CRM + inbox + booking + payments + AI OS the product will become.

### Why Yavren cleared screening

Search: `"Yavren" company software trademark 2026` → **zero exact-name company hits**. Result returned only generic Class-42 trademark filing guidance (Razorpay Rize blog, Clarivate, IPZen), no companies, no domains, no products, no active filings. Cross-checked adjacent spellings (`Yavren Labs`, `Yavren Inc`, `Yavren GmbH`) — no active entities under those names either.

### Language screen

| Language | Meaning of "Yavren" | Verdict |
| --- | --- | --- |
| Spanish | none | clean |
| German | none | clean |
| French | none | clean |
| Portuguese | none | clean |
| Arabic | none | clean |
| Hindi | none | clean |

### Domain status

- `.com` availability was not verified via a paid registrar lookup; noted as "check-and-claim before public launch". Provisional pending registration per user instruction. `.app`, `.co`, and `.io` are acceptable fallbacks if `.com` is squatted.

## Screening evidence for the 22 rejected candidates

Each search was of the form `"<name>" company software SaaS trademark 2026` unless noted.

### Round 1 — initial 8 candidates

| # | Candidate | Verdict | Evidence |
| --- | --- | --- | --- |
| 1 | **Klora** | REJECT | Klora Pty Ltd (AU, IT consulting, ACN 654 961 841, active) + USPTO trademark KLORA (Serial 90778006) for supplements (Color Labs LLC). |
| 2 | **Kelva** | REJECT | kelva.ai (regulated-AI SaaS), Kelva Tech (BY, IT/AI content), Indian trademark KELVA (App. 5151441) in Class 9 through 2031. |
| 3 | **Ryzo** | REJECT | ryzo.nl (agentic SaaS replacement, NL), ryzo.tech (Shopify visual search), ryzohq.com (SMB software dev). |
| 4 | **Zorae** | REJECT | Confusingly close to Deloitte "Zora AI" + multiple Zora trademark filings (US/CA/IN). Zoráe operates jewelry brand. |
| 5 | **Ovryn** | REJECT | ovryn.io (SE, competitive-intel SaaS by Arocore AB) — direct SaaS competitor pattern. |
| 6 | **Havlo** | REJECT | Havlo Ltd (UK, business/domestic software dev, SIC 62.01/2), HAVLO Invest s.r.o. (CZ, IT consulting), Havlo Group (US, real-estate tech). |
| 7 | **Torvi** | REJECT | torvi.ai (enterprise AI agents), torvi.app (privacy messaging), torvi.io (tokenization infra), TORVI LIMITED (NZ). Saturated across tech. |
| 8 | **Grovi** | REJECT | Grovi.io (early-stage startup workflow), Grovi by GroveSoft (AI biz intelligence), Grovi.pro (Chicago IT consulting), GROVIS Indian trademark App. 7583697 in Class 42 for SaaS/PaaS/AIaaS. |

### Round 2 — 8 fresher coinages

| # | Candidate | Verdict | Evidence |
| --- | --- | --- | --- |
| 9 | **Skovi** | REJECT | Confusingly similar to **Skovik** (established SaaS expense-management platform). Skovi Marketing (US ads firm). SKOVI AS (NO real estate). |
| 10 | **Vrelo** | REJECT | Vrelo (Dubai SaaS for personal trainers, vreloapp.com), Vrelo GmbH (DE, HRB 124119), VRELO INC (CA), Vrelo d.o.o. (HR utility). |
| 11 | **Kroven** | REJECT | Kroven Brasil LTDA (BR, active in editing/publishing directories — adjacent to information services). Two liquidated Slavic shells (RU, LV) confirm the name has commercial history. |
| 12 | **Yarvon** | REJECT | Yarvon Labs (IN, software dev firm, Jul 2025). Also phonetic proximity to controversial figure "Curtis Yarvin". |
| 13 | **Odara** | REJECT | odara.rs (open-source Rust ETL), ODARA TECH SL (ES, digital consulting/software dev), Odara.Tech (afro-centered software house). |
| 14 | **Vellex** | REJECT | Vellex Computing (SF, AI hardware + PaaS), Vellex Digital (custom business software house). |
| 15 | **Nolyx** | REJECT | NOLYX AB (SE, org. 556640-1914, embedded industrial automation software — active). |
| 16 | **Torvana** | REJECT (barely) | No tech/SaaS collision, but three active exact-name entities under strict reading of the criterion: TORVANA PTY (AU 1995, unclear industry), SCI Torvana (FR real estate), Torvana Concepts LLC (AZ). Also Latin archaic "torvus" = grim (mild concern). |

### Round 3 — 6 more, aiming for uncommon letter patterns

| # | Candidate | Verdict | Evidence |
| --- | --- | --- | --- |
| 17 | **Belora** | REJECT | Belora Labs, Inc. (NY, real-time AI voice interpretation SaaS "Connect", Apr 2026). Directly in target space. |
| 18 | **Kavrell** | REJECT | Kavrel Trading Co (NY, Mar 2026), KAVRELL PTY (AU 1995), kavrel.store product. Multiple active exact-name entities. |
| 19 | **Trelvo** | REJECT | Trelvo (embedded operations consulting, Apr 2026), trelvo-app.com (marketing lead-gen). Both adjacent to our category. |
| 20 | **Klivra** | REJECT | Klivra Limited (NG, business SaaS: chatbot builder, HR onboarding, AI document scanner) — direct SaaS competitor with overlapping product lines. |
| 21 | **Norvax** | REJECT | Norvax, LLC (Chicago, 2001, SaaS for health-insurance sales/commission tracking, registered marks under GoHealth). |
| 22 | **Cardra** | REJECT | Cardra virtual credit cards (cardra.webflow.io, fintech — adjacent SaaS category). Cardra LLC (FL, 2026). Cardray Limited (UK, software publishing since 1992). |

### Round 4 — the winning finalist and its comparison

| # | Candidate | Verdict | Evidence |
| --- | --- | --- | --- |
| 23 | **Zavrik** | REJECT | GitHub developer handle (Artem Zavrazhyn), Zavrik beauty OÜ (EE), open-source Composer packages (`zavrik/laravel-*`). |
| **24** | **Yavren** | **PICK** | Zero exact-name company hits. Zero SaaS collisions. Zero adjacent-industry entities. Zero trademark filings. Only Class-42 filing guides returned. |

## Rejected "Onvara" — for the record

- Original 2026-09-03 screen missed **Onvara GmbH** (onvara.de), an active German company operating in technical project management / procurement services.
- Trademark risk in DE and adjacent EU markets. Reject.

## Domain / handle notes (to check when the founder registers)

- `yavren.com` — attempt claim first.
- Fallbacks: `yavren.app`, `yavren.co`, `yavren.io`.
- Social handles (`@yavren` on X, Instagram, LinkedIn) — likely available given zero web footprint.

## Signature line for all future references

> **Yavren — the quiet operating system for service businesses.**  
> _(Provisional name pending registration.)_
