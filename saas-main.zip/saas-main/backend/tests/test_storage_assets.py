"""Production storage / Asset Library foundation — backend regression.

Covers the atomic upload flow, quota reservation + enforcement, MIME/magic/size validation,
SVG sanitisation, checksum dedup, tenant isolation, trash/restore/purge storage accounting,
private signed URLs, and public blob serving. Creds resolved from env/creds file; plans and
per-tenant overrides written directly to Mongo (runtime source of truth).
"""
from __future__ import annotations

import os
import secrets
import uuid

import pytest
import requests

import _creds

API = _creds.api()

# 1x1 transparent PNG
PNG_B64 = ("iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGM8YWTEwMDAxMDAwMDAAAAO0AEwUN+6GAAAAABJRU5ErkJggg==")
PNG_BYTES = 79


def _hdr(tok):
    ip = f"10.{secrets.randbelow(250)}.{secrets.randbelow(250)}.{secrets.randbelow(250)}"
    return {"Authorization": f"Bearer {tok}", "X-Forwarded-For": ip}


def _signup():
    ip = f"10.{secrets.randbelow(250)}.{secrets.randbelow(250)}.{secrets.randbelow(250)}"
    email = f"stor-{uuid.uuid4().hex[:10]}@example.com"
    r = requests.post(f"{API}/auth/signup", headers={"X-Forwarded-For": ip},
                      json={"email": email, "password": "StorTest-Pass1!", "full_name": "Stor",
                            "business_name": f"Stor {uuid.uuid4().hex[:4]}"}, timeout=30)
    assert r.status_code in (200, 201), r.text
    tok = r.json()["access_token"]
    me = requests.get(f"{API}/auth/me", headers=_hdr(tok), timeout=30).json()
    org_id = me.get("org_id") or (me.get("user") or {}).get("org_id")
    return {"token": tok, "org_id": org_id}


def _db():
    from pymongo import MongoClient
    return MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]


def _set_plan(org_id, plan):
    _db().subscriptions.update_one({"org_id": org_id}, {"$set": {"plan_code": plan, "status": "active"}}, upsert=True)


def _override(org_id, nbytes):
    _db().storage_overrides.update_one({"org_id": org_id}, {"$set": {"org_id": org_id, "bytes": int(nbytes)}}, upsert=True)


@pytest.fixture(scope="module")
def owner():
    o = _signup(); _set_plan(o["org_id"], "autopilot")
    return o


def _upload_png(tok, visibility="public", mime="image/png", data=PNG_B64, size=PNG_BYTES):
    init = requests.post(f"{API}/assets/upload/init", headers=_hdr(tok),
                         json={"filename": "px.png", "mime": mime, "size": size, "visibility": visibility}, timeout=30)
    if init.status_code != 200:
        return init
    uid = init.json()["upload_id"]
    return requests.post(f"{API}/assets/upload/{uid}/finalize", headers=_hdr(tok),
                         json={"data_base64": data, "alt_text": "pixel"}, timeout=30)


def test_upload_and_usage(owner):
    tok = owner["token"]
    r = _upload_png(tok)
    assert r.status_code == 200, r.text
    a = r.json()
    assert a["id"] and a["object_key"].startswith(f"org/{owner['org_id']}/")
    assert a["sha256"] and a["media_type"] == "image" and a["width"] == 2 and a["height"] == 2
    u = requests.get(f"{API}/assets/usage", headers=_hdr(tok), timeout=30).json()
    assert u["active_bytes"] > 0 and u["file_count"] >= 1 and u["limit_bytes"] > 0
    # public serving works
    served = requests.get(f"{_creds.base_url()}{a['url']}", timeout=30)
    assert served.status_code == 200 and served.headers.get("content-type", "").startswith("image/")


def test_mime_and_size_validation(owner):
    tok = owner["token"]
    bad = requests.post(f"{API}/assets/upload/init", headers=_hdr(tok),
                        json={"filename": "x.exe", "mime": "application/x-msdownload", "size": 100}, timeout=30)
    assert bad.status_code == 415
    big = requests.post(f"{API}/assets/upload/init", headers=_hdr(tok),
                        json={"filename": "x.png", "mime": "image/png", "size": 999_999_999}, timeout=30)
    assert big.status_code == 413


def test_content_mismatch(owner):
    tok = owner["token"]
    import base64 as b64
    fake = b64.b64encode(b"this is not a png").decode()
    r = _upload_png(tok, data=fake, size=20)
    assert r.status_code == 415 and r.json()["detail"]["error"] == "content_mismatch"


def test_svg_sanitised(owner):
    tok = owner["token"]
    import base64 as b64
    svg = b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script><rect/></svg>'
    r = _upload_png(tok, mime="image/svg+xml", data=b64.b64encode(svg).decode(), size=len(svg))
    assert r.status_code == 200, r.text
    served = requests.get(f"{_creds.base_url()}{r.json()['url']}", timeout=30).text
    assert "<script" not in served.lower()


def test_dedup_same_checksum(owner):
    tok = owner["token"]
    a = _upload_png(tok); assert a.status_code == 200
    b = _upload_png(tok); assert b.status_code == 200
    assert b.json().get("deduplicated") is True
    assert b.json()["id"] == a.json()["id"]


def test_tenant_isolation():
    a = _signup(); _set_plan(a["org_id"], "autopilot")
    b = _signup(); _set_plan(b["org_id"], "autopilot")
    r = _upload_png(a["token"]); assert r.status_code == 200
    aid = r.json()["id"]
    assert requests.get(f"{API}/assets/{aid}", headers=_hdr(b["token"]), timeout=30).status_code == 404
    lst = requests.get(f"{API}/assets", headers=_hdr(b["token"]), timeout=30).json()
    assert all(x["id"] != aid for x in lst["assets"])


def test_trash_restore_purge_accounting():
    o = _signup(); _set_plan(o["org_id"], "autopilot"); tok = o["token"]
    r = _upload_png(tok); assert r.status_code == 200
    aid = r.json()["id"]
    u1 = requests.get(f"{API}/assets/usage", headers=_hdr(tok), timeout=30).json()
    assert requests.post(f"{API}/assets/{aid}/trash", headers=_hdr(tok), timeout=30).status_code == 200
    u2 = requests.get(f"{API}/assets/usage", headers=_hdr(tok), timeout=30).json()
    assert u2["trashed_bytes"] >= u1["active_bytes"] and u2["active_bytes"] < u1["active_bytes"]
    # trashed still counts toward used
    assert u2["used_bytes"] == u1["used_bytes"]
    assert requests.post(f"{API}/assets/{aid}/restore", headers=_hdr(tok), timeout=30).status_code == 200
    assert requests.post(f"{API}/assets/{aid}/trash", headers=_hdr(tok), timeout=30).status_code == 200
    p = requests.delete(f"{API}/assets/{aid}", headers=_hdr(tok), timeout=30)
    assert p.status_code == 200 and p.json()["freed_bytes"] > 0
    u3 = requests.get(f"{API}/assets/usage", headers=_hdr(tok), timeout=30).json()
    assert u3["used_bytes"] < u2["used_bytes"]


def test_quota_enforced_atomically():
    o = _signup(); _set_plan(o["org_id"], "free"); tok = o["token"]
    _override(o["org_id"], 40)  # 40 bytes: smaller than one 68-byte png
    r = _upload_png(tok)
    assert r.status_code == 402 and r.json()["detail"]["error"] == "storage_limit_reached"
    # raise override, now it fits
    _override(o["org_id"], 10_000)
    r2 = _upload_png(tok)
    assert r2.status_code == 200, r2.text


def test_private_requires_signature():
    o = _signup(); _set_plan(o["org_id"], "autopilot"); tok = o["token"]
    r = _upload_png(tok, visibility="private"); assert r.status_code == 200
    url = r.json()["url"]
    assert "sig=" in url  # signed, not a bare public url
    ok = requests.get(f"{_creds.base_url()}{url}", timeout=30)
    assert ok.status_code == 200
    # tampered signature rejected
    bad = requests.get(f"{_creds.base_url()}{url}sig-tamper", timeout=30)
    assert bad.status_code in (403, 404)


def test_invalid_asset_id_not_500(owner):
    tok = owner["token"]
    assert requests.get(f"{API}/assets/does-not-exist", headers=_hdr(tok), timeout=30).status_code == 404
