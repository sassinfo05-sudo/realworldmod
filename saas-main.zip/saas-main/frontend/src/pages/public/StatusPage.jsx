/** Round 11 — public status page (/status). Reads GET /api/support/status: live checks + staff-declared incidents. */
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { useBrand } from "@/context/BrandContext";
import { CheckCircle2, AlertTriangle, XCircle, RefreshCw } from "lucide-react";

const LABEL = { database: "Database", llm: "AI services", api: "API & dashboards", website_hosting: "Website hosting", email: "Email delivery", payments: "Payments" };
const tone = (s) => s === "operational" ? { Icon: CheckCircle2, cls: "text-emerald-600", bg: "bg-emerald-50 border-emerald-200" }
    : s === "outage" || s === "major_outage" ? { Icon: XCircle, cls: "text-red-600", bg: "bg-red-50 border-red-200" }
        : { Icon: AlertTriangle, cls: "text-amber-600", bg: "bg-amber-50 border-amber-200" };
const OVERALL = { operational: "All systems operational", degraded: "Partial degradation", major_outage: "Major outage" };

export default function StatusPage() {
    const brand = useBrand();
    const [data, setData] = useState(null);
    const [err, setErr] = useState(false);
    const load = () => api.get("/support/status").then((r) => { setData(r.data); setErr(false); }).catch(() => setErr(true));
    useEffect(() => { load(); const t = setInterval(load, 60000); document.title = `Status — ${brand?.name || "Zanelvo"}`; return () => clearInterval(t); }, [brand?.name]);
    const overall = err ? "major_outage" : data?.overall || "operational";
    const T = tone(overall);
    const active = (data?.incidents || []).filter((i) => i.status !== "resolved");
    const past = (data?.incidents || []).filter((i) => i.status === "resolved");
    return (
        <div className="min-h-screen bg-brand-cream text-brand-ink" data-testid="status-page">
            <header className="border-b border-brand-line bg-white/80 backdrop-blur">
                <div className="max-w-3xl mx-auto px-6 py-4 flex items-center justify-between">
                    <Link to="/" className="font-display text-lg font-semibold">{brand?.name || "Zanelvo"}</Link>
                    <span className="text-xs uppercase tracking-widest text-zinc-500">System status</span>
                </div>
            </header>
            <main className="max-w-3xl mx-auto px-6 py-10 space-y-8">
                <div className={`rounded-2xl border px-6 py-5 flex items-center gap-4 ${T.bg}`} data-testid="status-overall">
                    <T.Icon className={`w-8 h-8 ${T.cls}`} />
                    <div className="flex-1">
                        <div className="font-display text-2xl">{err ? "Status service unreachable" : OVERALL[overall] || overall}</div>
                        <div className="text-xs text-zinc-500 mt-0.5">{data?.as_of ? `Checked ${data.as_of.slice(0, 19).replace("T", " ")} UTC · refreshes every minute` : "Checking…"}</div>
                    </div>
                    <button onClick={load} className="text-zinc-500 hover:text-brand-ink" title="Refresh" data-testid="status-refresh"><RefreshCw className="w-4 h-4" /></button>
                </div>

                <section className="rounded-2xl border border-brand-line bg-white divide-y divide-brand-line" data-testid="status-components">
                    {(data?.checks || []).map((c) => { const t = tone(c.status); return (
                        <div key={c.component} className="flex items-center justify-between px-5 py-3 text-sm" data-testid={`status-component-${c.component}`}>
                            <span>{LABEL[c.component] || c.component}</span>
                            <span className={`flex items-center gap-1.5 ${t.cls}`}><t.Icon className="w-4 h-4" /> {c.status.replace("_", " ")}</span>
                        </div>); })}
                    {!data?.checks?.length && !err && <div className="px-5 py-3 text-sm text-zinc-500">Loading checks…</div>}
                </section>

                <section className="space-y-3">
                    <h2 className="font-display text-xl">Incidents</h2>
                    {active.length === 0 && <div className="rounded-2xl border border-brand-line bg-white px-5 py-4 text-sm text-zinc-600" data-testid="status-no-incidents">No active incidents.</div>}
                    {[...active, ...past].map((i) => (
                        <div key={i.id} className="rounded-2xl border border-brand-line bg-white px-5 py-4" data-testid={`status-incident-${i.id}`}>
                            <div className="flex flex-wrap items-center gap-2">
                                <span className="font-medium flex-1">{i.title}</span>
                                <span className={`text-[11px] px-2 py-0.5 rounded-full ${i.status === "resolved" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>{i.status}</span>
                                <span className="text-[11px] text-zinc-500">impact: {i.impact}</span>
                            </div>
                            <div className="mt-2 space-y-1">{(i.updates || []).map((u, k) => <div key={k} className="text-xs text-zinc-600"><span className="text-zinc-400">{u.at?.slice(0, 16).replace("T", " ")} · {u.status}</span>{u.message ? ` — ${u.message}` : ""}</div>)}</div>
                        </div>
                    ))}
                    {past.length > 0 && active.length === 0 && <p className="text-[11px] text-zinc-500">Showing incidents resolved in the last 7 days.</p>}
                </section>
                <p className="text-xs text-zinc-500">Need help? Sign in and open a ticket under Support — our team answers from a shared queue.</p>
            </main>
        </div>
    );
}
