"""Kept isolated from routes/bookings.py to avoid seed-time circular import.
Wraps `compute_quote_totals` in a stable shape."""
from typing import Any, Dict, List

from ..routes.bookings import compute_quote_totals


def compute_totals_like_route(lines: List[Dict[str, Any]], tax_rate: float = 0.0,
                                global_discount_percent: float = 0.0,
                                deposit: int = 0, currency: str = "USD") -> Dict[str, Any]:
    return compute_quote_totals(lines, global_discount_percent, tax_rate, deposit, currency)
