"""Deterministic test: the Mongo leader lock grants leadership to exactly one holder.

Run: cd /app/backend && python tests/test_leader_lock.py
"""
import asyncio
import os
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))
except Exception:  # noqa: BLE001
    pass

from app.services import leader_lock  # noqa: E402
from app.db import get_db  # noqa: E402


async def main():
    name = f"test-lock-{uuid.uuid4().hex[:8]}"
    db = get_db()
    # First acquire wins.
    a = await leader_lock.acquire(name, ttl_s=60)
    # Same instance re-acquiring (renewal) still True.
    b = await leader_lock.acquire(name, ttl_s=60)
    # Simulate a DIFFERENT instance by swapping the module instance id.
    orig = leader_lock.INSTANCE_ID
    leader_lock.INSTANCE_ID = f"other:{uuid.uuid4().hex[:6]}"
    try:
        c = await leader_lock.acquire(name, ttl_s=60)   # live lock held by orig → must fail
    finally:
        leader_lock.INSTANCE_ID = orig
    await db[leader_lock.LOCK_COLL].delete_many({"_id": name})
    print(f"[LEADER LOCK] first={a} renew={b} other_instance={c}")
    assert a is True and b is True, "leader should acquire + renew"
    assert c is False, "a second live instance must NOT win the lock"
    print("LEADER LOCK SINGLETON ASSERTION PASSED")


if __name__ == "__main__":
    asyncio.run(main())
