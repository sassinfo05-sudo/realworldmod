import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";

const EditorContext = createContext(null);
const MAX_HISTORY = 40;
const AUTOSAVE_MS = 900;

/**
 * Editor state is managed by a pure reducer so undo/redo/mutate transitions are atomic
 * and immune to React 18 strict-mode double-invocation of setState updaters (which caused
 * a prior bug where side-effect setState calls nested inside setState updaters resulted
 * in duplicate past-stack entries and undo appearing to be a no-op).
 *
 * The reducer owns { website, past, future, version }.  A separate effect watches
 * `version` and schedules the debounced server autosave.
 */

function draftOf(website) {
    return {
        theme: website.theme,
        pages: website.pages,
        nav_order: website.nav_order?.length ? website.nav_order : website.pages.map((p) => p.slug),
    };
}

function deepCopyDraft(website) {
    return {
        theme: { ...website.theme },
        pages: JSON.parse(JSON.stringify(website.pages)),
        nav_order: [...(website.nav_order || website.pages.map((p) => p.slug))],
    };
}

function reducer(state, action) {
    switch (action.type) {
        case "LOAD":
            return { website: action.website, past: [], future: [], version: 0 };
        case "REPLACE_FROM_SERVER":
            // Used after page CRUD (add/duplicate/delete/rename/publish/rollback) — reset
            // history because slugs/nav can change in ways that break local inverse ops.
            return { website: action.website, past: [], future: [], version: 0 };
        case "MUTATE": {
            const { website } = state;
            if (!website) return state;
            const before = draftOf(website);
            const workingCopy = deepCopyDraft(website);
            const next = action.mutator(workingCopy);
            if (!next) return state;
            const past = [...state.past, before];
            const trimmedPast = past.length > MAX_HISTORY ? past.slice(past.length - MAX_HISTORY) : past;
            return {
                website: { ...website, ...next },
                past: trimmedPast,
                future: [],
                version: state.version + 1,
            };
        }
        case "UNDO": {
            const { website, past, future } = state;
            if (!past.length || !website) return state;
            const cur = draftOf(website);
            const prev = past[past.length - 1];
            const nextFuture = [cur, ...future];
            const trimmedFuture = nextFuture.length > MAX_HISTORY ? nextFuture.slice(0, MAX_HISTORY) : nextFuture;
            return {
                website: { ...website, ...prev },
                past: past.slice(0, -1),
                future: trimmedFuture,
                version: state.version + 1,
            };
        }
        case "REDO": {
            const { website, past, future } = state;
            if (!future.length || !website) return state;
            const cur = draftOf(website);
            const next = future[0];
            const nextPast = [...past, cur];
            const trimmedPast = nextPast.length > MAX_HISTORY ? nextPast.slice(nextPast.length - MAX_HISTORY) : nextPast;
            return {
                website: { ...website, ...next },
                past: trimmedPast,
                future: future.slice(1),
                version: state.version + 1,
            };
        }
        default:
            return state;
    }
}

export function EditorProvider({ children }) {
    const [state, dispatch] = useReducer(reducer, { website: null, past: [], future: [], version: 0 });
    const { website, past, future, version } = state;
    const [loading, setLoading] = useState(true);
    const [selectedPageSlug, setSelectedPageSlug] = useState("home");
    const [selectedBlockId, setSelectedBlockId] = useState(null);
    const [device, setDevice] = useState("desktop"); // desktop | tablet | mobile
    const [saveState, setSaveState] = useState("idle"); // idle | dirty | saving | saved | error
    const saveTimer = useRef(null);
    const inFlight = useRef(false);
    const pendingSnapshot = useRef(null);
    const lastSavedVersion = useRef(0);

    const draft = useMemo(() => (website ? draftOf(website) : null), [website]);

    // Load initial state
    useEffect(() => {
        let cancelled = false;
        (async () => {
            try {
                const { data } = await api.get("/editor/website");
                if (cancelled) return;
                dispatch({ type: "LOAD", website: data.website });
                if (data.website?.pages?.length) setSelectedPageSlug(data.website.pages[0].slug);
            } catch (err) {
                if (!cancelled) toast.error(err?.response?.data?.detail || "Could not load your site.");
            } finally {
                if (!cancelled) setLoading(false);
            }
        })();
        return () => { cancelled = true; };
    }, []);

    // Debounced autosave — flushes whichever snapshot is pending. Safe under strict mode.
    const scheduleSave = useCallback((next) => {
        pendingSnapshot.current = next;
        setSaveState("dirty");
        if (saveTimer.current) clearTimeout(saveTimer.current);
        saveTimer.current = setTimeout(async () => {
            if (inFlight.current || !pendingSnapshot.current) return;
            const payload = pendingSnapshot.current;
            pendingSnapshot.current = null;
            inFlight.current = true;
            setSaveState("saving");
            try {
                await api.post("/editor/website/snapshot-set", payload);
                setSaveState("saved");
                setTimeout(() => setSaveState((s) => (s === "saved" ? "idle" : s)), 1400);
            } catch (err) {
                setSaveState("error");
                toast.error("Autosave failed — your last change is not on the server yet.");
            } finally {
                inFlight.current = false;
                if (pendingSnapshot.current) scheduleSave(pendingSnapshot.current);
            }
        }, AUTOSAVE_MS);
    }, []);

    /** Synchronously flush any pending autosave and wait for any in-flight save.
     *  Guarantees the server draft matches the latest local mutation before returning. */
    const flushPendingSaves = useCallback(async () => {
        if (saveTimer.current) { clearTimeout(saveTimer.current); saveTimer.current = null; }
        // First, ship whatever snapshot is queued (bypassing the debounce).
        if (pendingSnapshot.current) {
            const payload = pendingSnapshot.current;
            pendingSnapshot.current = null;
            inFlight.current = true;
            setSaveState("saving");
            try {
                await api.post("/editor/website/snapshot-set", payload);
                setSaveState("saved");
            } catch (err) {
                setSaveState("error");
                throw err;
            } finally {
                inFlight.current = false;
            }
        }
        // If a save was already mid-flight, wait for it to settle.
        while (inFlight.current) {
            // yield to the event loop until the in-flight save finishes
            // (bounded to ~2s worst case; snapshot-set is fast)
            // eslint-disable-next-line no-await-in-loop
            await new Promise((r) => setTimeout(r, 50));
        }
    }, []);

    // Autosave whenever the reducer's version counter advances (mutate/undo/redo).
    useEffect(() => {
        if (version === 0 || version === lastSavedVersion.current) return;
        lastSavedVersion.current = version;
        if (draft) scheduleSave(draft);
    }, [version, draft, scheduleSave]);

    // Global keyboard shortcuts (Cmd/Ctrl+Z, Cmd/Ctrl+Shift+Z / Ctrl+Y)
    useEffect(() => {
        const onKey = (e) => {
            const meta = e.metaKey || e.ctrlKey;
            if (!meta) return;
            const active = document.activeElement;
            const inField = active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA" || active.isContentEditable);
            if (inField) return;
            if (e.key === "z" && !e.shiftKey) { e.preventDefault(); dispatch({ type: "UNDO" }); }
            else if ((e.key === "z" && e.shiftKey) || e.key === "y") { e.preventDefault(); dispatch({ type: "REDO" }); }
        };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    }, []);

    const currentPage = useMemo(() => website?.pages?.find((p) => p.slug === selectedPageSlug) || null, [website, selectedPageSlug]);
    const selectedBlock = useMemo(() => {
        if (!currentPage) return null;
        return currentPage.blocks.find((b) => b.id === selectedBlockId) || null;
    }, [currentPage, selectedBlockId]);

    // ----- Mutations (all dispatch pure MUTATE actions) -----

    const applyMutation = useCallback((mutator) => {
        dispatch({ type: "MUTATE", mutator });
    }, []);

    const updateBlockProp = useCallback((blockId, path, value) => {
        applyMutation((s) => {
            for (const page of s.pages) {
                const b = page.blocks.find((x) => x.id === blockId);
                if (!b) continue;
                // Dotted path: e.g. "headline" or "primary_cta.label"
                const keys = path.split(".");
                let cur = b.props;
                for (let i = 0; i < keys.length - 1; i++) {
                    cur[keys[i]] = cur[keys[i]] ? { ...cur[keys[i]] } : {};
                    cur = cur[keys[i]];
                }
                cur[keys[keys.length - 1]] = value;
                return s;
            }
            return s;
        });
    }, [applyMutation]);

    const setBlockVariant = useCallback((blockId, variant) => {
        applyMutation((s) => {
            for (const page of s.pages) {
                const b = page.blocks.find((x) => x.id === blockId);
                if (b) { b.variant = variant; return s; }
            }
            return s;
        });
    }, [applyMutation]);

    const toggleBlockHidden = useCallback((blockId) => {
        applyMutation((s) => {
            for (const page of s.pages) {
                const b = page.blocks.find((x) => x.id === blockId);
                if (b) { b.hidden = !b.hidden; return s; }
            }
            return s;
        });
    }, [applyMutation]);

    const addBlock = useCallback((pageSlug, block, index) => {
        applyMutation((s) => {
            const page = s.pages.find((p) => p.slug === pageSlug);
            if (!page) return s;
            const newBlock = { id: crypto.randomUUID(), variant: "a", props: {}, style: {}, hidden: false, ...block };
            if (typeof index === "number" && index >= 0) page.blocks.splice(index, 0, newBlock);
            else page.blocks.push(newBlock);
            return s;
        });
    }, [applyMutation]);

    const duplicateBlock = useCallback((blockId) => {
        applyMutation((s) => {
            for (const page of s.pages) {
                const i = page.blocks.findIndex((b) => b.id === blockId);
                if (i < 0) continue;
                const src = page.blocks[i];
                const dup = { ...src, id: crypto.randomUUID(), props: { ...src.props }, style: { ...src.style } };
                page.blocks.splice(i + 1, 0, dup);
                return s;
            }
            return s;
        });
    }, [applyMutation]);

    const removeBlock = useCallback((blockId) => {
        applyMutation((s) => {
            for (const page of s.pages) {
                const i = page.blocks.findIndex((b) => b.id === blockId);
                if (i < 0) continue;
                page.blocks.splice(i, 1);
                return s;
            }
            return s;
        });
        setSelectedBlockId(null);
    }, [applyMutation]);

    /** Move block by direction ('up' | 'down') within its page. Returns quietly at ends. */
    const moveBlock = useCallback((blockId, direction) => {
        applyMutation((s) => {
            for (const page of s.pages) {
                const i = page.blocks.findIndex((b) => b.id === blockId);
                if (i < 0) continue;
                const j = direction === "up" ? i - 1 : i + 1;
                if (j < 0 || j >= page.blocks.length) return s;
                const [item] = page.blocks.splice(i, 1);
                page.blocks.splice(j, 0, item);
                return s;
            }
            return s;
        });
    }, [applyMutation]);

    const reorderBlocks = useCallback((pageSlug, orderedIds) => {
        applyMutation((s) => {
            const page = s.pages.find((p) => p.slug === pageSlug);
            if (!page) return s;
            const byId = Object.fromEntries(page.blocks.map((b) => [b.id, b]));
            page.blocks = orderedIds.map((id) => byId[id]).filter(Boolean);
            return s;
        });
    }, [applyMutation]);

    const patchTheme = useCallback((patch) => {
        applyMutation((s) => {
            s.theme = { ...s.theme, ...patch };
            return s;
        });
    }, [applyMutation]);

    // Pages — server-side because slugs/nav can shift in ways that make local inverse ops fragile.
    // We reset history after these because prior past entries may reference deleted slugs.
    const addPage = useCallback(async ({ title, slug }) => {
        try {
            const { data } = await api.post("/editor/website/pages", { title, slug });
            const { data: fresh } = await api.get("/editor/website");
            dispatch({ type: "REPLACE_FROM_SERVER", website: fresh.website });
            setSelectedPageSlug(data.slug);
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Could not add page");
        }
    }, []);

    const duplicatePage = useCallback(async (slug) => {
        const { data } = await api.post(`/editor/website/pages/${slug}/duplicate`);
        const { data: fresh } = await api.get("/editor/website");
        dispatch({ type: "REPLACE_FROM_SERVER", website: fresh.website });
        setSelectedPageSlug(data.slug);
    }, []);

    const renamePage = useCallback(async (slug, patch) => {
        const { data } = await api.patch(`/editor/website/pages/${slug}`, patch);
        const { data: fresh } = await api.get("/editor/website");
        dispatch({ type: "REPLACE_FROM_SERVER", website: fresh.website });
        setSelectedPageSlug(data.slug);
    }, []);

    const deletePage = useCallback(async (slug) => {
        await api.delete(`/editor/website/pages/${slug}`);
        const { data: fresh } = await api.get("/editor/website");
        dispatch({ type: "REPLACE_FROM_SERVER", website: fresh.website });
        setSelectedPageSlug(fresh.website.pages[0]?.slug || "home");
    }, []);

    const publish = useCallback(async ({ slug, note } = {}) => {
        // Flush ALL pending autosave writes (debounced + in-flight) before snapshotting,
        // so we can't publish stale state after a rapid edit → publish sequence.
        try {
            await flushPendingSaves();
        } catch {
            // If flush failed, we still try to publish with whatever's on the server,
            // but the toast from the autosave error already surfaced the problem.
        }
        const { data } = await api.post("/editor/website/publish", { slug, note });
        const { data: fresh } = await api.get("/editor/website");
        dispatch({ type: "REPLACE_FROM_SERVER", website: fresh.website });
        return data;
    }, [flushPendingSaves]);

    const undo = useCallback(() => dispatch({ type: "UNDO" }), []);
    const redo = useCallback(() => dispatch({ type: "REDO" }), []);

    /** AI "Regenerate copy" for one section (server-side, metered). Flushes autosave first so the
     *  model sees the latest props, then reloads the draft from the server. */
    const regenerateBlock = useCallback(async (blockId, instruction) => {
        try { await flushPendingSaves(); } catch { /* autosave toast already shown */ }
        const { data } = await api.post(`/editor/website/blocks/${blockId}/regenerate`, { instruction: instruction || null });
        const { data: fresh } = await api.get("/editor/website");
        dispatch({ type: "REPLACE_FROM_SERVER", website: fresh.website });
        return data.block;
    }, [flushPendingSaves]);

    /** Save one block as a reusable section (Round 11). Flushes autosave so the server sees the block. */
    const saveBlockAsSection = useCallback(async (blockId, name) => {
        try { await flushPendingSaves(); } catch { /* autosave toast already shown */ }
        const { data } = await api.post(`/editor/website/blocks/${blockId}/save-as-section`, { name });
        return data;
    }, [flushPendingSaves]);

    const refetch = useCallback(async () => {
        const { data } = await api.get("/editor/website");
        dispatch({ type: "REPLACE_FROM_SERVER", website: data.website });
    }, []);

    const value = useMemo(() => ({
        website, draft, loading, saveState,
        selectedPageSlug, setSelectedPageSlug,
        selectedBlockId, setSelectedBlockId,
        device, setDevice,
        currentPage, selectedBlock,
        canUndo: past.length > 0, canRedo: future.length > 0,
        undo, redo,
        updateBlockProp, setBlockVariant, toggleBlockHidden,
        addBlock, duplicateBlock, removeBlock, moveBlock, reorderBlocks,
        patchTheme,
        addPage, duplicatePage, renamePage, deletePage,
        publish, refetch, regenerateBlock, saveBlockAsSection,
    }), [website, draft, loading, saveState, selectedPageSlug, selectedBlockId, device, currentPage, selectedBlock,
        past.length, future.length, undo, redo,
        updateBlockProp, setBlockVariant, toggleBlockHidden,
        addBlock, duplicateBlock, removeBlock, moveBlock, reorderBlocks,
        patchTheme, addPage, duplicatePage, renamePage, deletePage, publish, refetch, regenerateBlock, saveBlockAsSection]);

    return <EditorContext.Provider value={value}>{children}</EditorContext.Provider>;
}

export function useEditor() {
    const ctx = useContext(EditorContext);
    if (!ctx) throw new Error("useEditor must be used inside EditorProvider");
    return ctx;
}
