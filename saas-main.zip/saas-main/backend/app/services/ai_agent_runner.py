"""Agent runner: orchestrates the retrieval + LLM + tool-loop for one conversation turn.

Design principles:
- Strict grounding: system prompt forbids fabricated facts; every price/hour/availability
  claim comes from a tool result or structured facts.
- Structured output: LLM must return a JSON object matching AgentDecision below.
- Bounded loop: at most `MAX_TOOL_STEPS` tool invocations per turn.
- Full audit: every model call and every tool invocation is recorded on AgentInteraction.
- Sandbox mode is transparent to the LLM — the same code path — but write tools no-op.
"""
from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Optional

from ..db import get_db, utc_now_iso
from ..models_ai import AgentInteraction, ChatMessage
from .ai_tools import ToolContext, run_tool, tool_spec_summary
from .knowledge import build_retrieval_context
from .llm import generate_json, LlmError

logger = logging.getLogger(__name__)

MAX_TOOL_STEPS = 4

# Rough per-1K-token cost estimates for the models we run. Anthropic reference pricing
# per Sonnet 4.6 (input $3, output $15 per M tokens); we hold this centrally so a single
# knob adjusts the whole cost trail without editing every call-site.
_COST_PER_1K = {
    "claude-sonnet-4-6": {"in": 0.003, "out": 0.015},
    "claude-sonnet-4-5": {"in": 0.003, "out": 0.015},
    "claude-haiku-4-5": {"in": 0.001, "out": 0.005},
}


def _estimate_cost_cents(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    m = _COST_PER_1K.get(model) or {"in": 0.003, "out": 0.015}
    return round(((prompt_tokens / 1000.0) * m["in"] + (completion_tokens / 1000.0) * m["out"]) * 100.0, 4)


def _approx_tokens(s: str) -> int:
    # ~4 chars per token — good enough for reporting.
    return max(1, int(len(s or "") / 4))


def _render_context(ctx_data: Dict[str, Any]) -> str:
    """Compact, LLM-friendly snapshot of the retrieval context."""
    lines: List[str] = []
    st = ctx_data.get("structured") or {}
    services = st.get("services") or []
    if services:
        lines.append("VERIFIED SERVICES (authoritative):")
        for s in services[:12]:
            price = f"${(s['price_cents'] or 0) / 100:.2f}"
            lines.append(f"  - id={s['id']} name={s['name']!r} price={price} duration={s['duration_minutes']}m bookable={s['bookable']}")
    if st.get("hours"):
        lines.append("HOURS: " + json.dumps(st["hours"])[:500])
    if st.get("locations"):
        lines.append("LOCATIONS: " + json.dumps(st["locations"])[:400])
    if st.get("policies"):
        lines.append("POLICIES: " + json.dumps(st["policies"])[:400])
    chunks = ctx_data.get("chunks") or []
    if chunks:
        lines.append("\nREFERENCE (from knowledge base — cite by source_id when used):")
        for h in chunks[:5]:
            lines.append(f"  [source_id={h['source_id']} kind={h['kind']} title={h['source_title']!r}] "
                              + (h["text"][:400]).replace("\n", " "))
    return "\n".join(lines) if lines else "(no context available)"


def _build_system_prompt(*, agent_version: Dict[str, Any], business_name: Optional[str],
                             context_text: str, tool_list_text: str,
                             sandbox: bool) -> str:
    tone = agent_version.get("tone") or "warm, concise, helpful"
    purpose = agent_version.get("purpose") or "help site visitors"
    allowed_claims = agent_version.get("allowed_claims") or ""
    lang = ", ".join(agent_version.get("languages") or ["en"])
    conf_thr = float(agent_version.get("confidence_threshold") or 0.4)
    escalation_rules = agent_version.get("escalation_rules") or []
    esc_desc = "\n".join(
        f"  - {r.get('kind')}: {r.get('value')}"
        for r in escalation_rules
    ) or "  (none)"
    allowed_tool_names = ", ".join(f'"{n}"' for n in (agent_version.get("allowed_tools") or [])) or '(NONE)'
    return (
f"""You are the {agent_version.get('agent_type', 'AI assistant')} for {business_name or 'this business'}.
Your purpose: {purpose}
Tone: {tone}. Languages: {lang}.

ANTI-HALLUCINATION RULES (non-negotiable):
- NEVER invent prices, hours, availability, addresses, staff names or policies.
- Prices, durations and services MUST come from VERIFIED SERVICES below. Quote them exactly.
- To answer about availability or to book, you MUST call the appropriate tool. Do not make times up.
- If the answer isn't in your context and no tool provides it, say honestly you don't have that
  information and offer to take a message via the take_message tool.
- Never leak or reference other businesses.

TOOL-NAME RULES (VERY IMPORTANT — read carefully):
- The ONLY valid tool_name values are (copy exactly): {allowed_tool_names}
- Never invent tool names. In particular, do NOT emit "check_availability", "book_appointment",
  "search", or any other name — the correct name for checking open slots is "get_availability",
  and the correct name for booking is "create_booking".
- If a tool you need is not in the list above, use intent="escalate" and explain that a
  human needs to take over.

BOOKING PROTOCOL (follow exactly when the visitor wants to book):
1. Call get_availability first with the requested service_id and date_from = the requested date
   (or today if unspecified). Look at the returned "slots" list.
2. If the visitor asked for a specific time, only use that exact start_at if it appears in
   the returned slots. Otherwise pick the closest available slot and CONFIRM the time in
   your reply, or offer the nearest 1-3 options.
3. Only then call create_booking with a start_at that EXACTLY matches a returned slot's
   start_at value (including seconds and timezone). Never guess a start_at time.

ESCALATION RULES:
{esc_desc}
If any of the above apply, or the visitor asks for a human, or confidence < {conf_thr},
respond with intent="escalate".

ALLOWED CLAIMS / GUARDRAILS:
{allowed_claims or '(none specified)'}

{"SANDBOX MODE: Write tools (create_booking, take_message) will be simulated — no real records are made." if sandbox else ""}

CONTEXT:
{context_text}

AVAILABLE TOOLS (call by name — use the exact names listed):
{tool_list_text or '(no tools enabled)'}

Every reply must be a single JSON object with this exact shape:
{{
  "intent": "answer" | "tool_call" | "escalate",
  "reply_text": "<what to say to the visitor as plain text; empty allowed if intent=tool_call>",
  "tool_name": "<one of the allowed tool names above OR null>",
  "tool_args": {{ }} ,
  "cited_source_ids": ["<source_id you used>"],
  "confidence": <float 0-1>
}}
No prose outside the JSON. No code fences. Never output anything except the JSON object.""")


def _messages_for_prompt(user_text: str, tool_history: List[Dict[str, Any]]) -> str:
    """Compose the user portion: latest visitor message + prior tool results this turn."""
    parts: List[str] = [f"Visitor message: {user_text!r}"]
    if tool_history:
        parts.append("\nPrior tool results this turn (for your use):")
        for h in tool_history:
            parts.append(f"  [tool={h['tool']} args={json.dumps(h['args'])[:200]}] "
                              f"ok={h['ok']} result={json.dumps(h['result'])[:800]}")
    parts.append("\nRespond now with a single JSON object.")
    return "\n".join(parts)


async def _record_interaction(*, org_id: str, agent_id: str, agent_version_id: str,
                                 conversation_id: Optional[str], call_record_id: Optional[str],
                                 action: str, model: str,
                                 prompt_tokens: int, completion_tokens: int, latency_ms: int,
                                 tools_used: List[Dict[str, Any]], outcome: str,
                                 confidence: float, error: Optional[str], is_sandbox: bool) -> str:
    db = get_db()
    total = prompt_tokens + completion_tokens
    cost = _estimate_cost_cents(model, prompt_tokens, completion_tokens)
    doc = AgentInteraction(
        org_id=org_id, agent_id=agent_id, agent_version_id=agent_version_id,
        conversation_id=conversation_id, call_record_id=call_record_id,
        action=action, model=model,
        prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
        total_tokens=total, cost_cents=cost, latency_ms=latency_ms,
        tools_used=tools_used, outcome=outcome, confidence=confidence,
        error=error, is_sandbox=is_sandbox,
    ).to_mongo()
    r = await db.agent_interactions.insert_one(doc)
    return str(r.inserted_id)


async def _load_agent_version(agent_id: str, version_id: Optional[str] = None) -> Dict[str, Any]:
    from bson import ObjectId
    db = get_db()
    if version_id:
        v = await db.agent_versions.find_one({"_id": ObjectId(version_id)})
    else:
        agent = await db.agents.find_one({"_id": ObjectId(agent_id)})
        if not agent:
            raise ValueError("agent not found")
        vid = agent.get("live_version_id")
        if not vid:
            raise ValueError("agent has no live version")
        v = await db.agent_versions.find_one({"_id": ObjectId(vid)})
    if not v:
        raise ValueError("agent version not found")
    return v


async def _persist_message(*, conversation_id: str, org_id: str, role: str,
                              content: str, tool_calls: Optional[List[Dict[str, Any]]] = None,
                              citations: Optional[List[Dict[str, str]]] = None,
                              confidence: Optional[float] = None,
                              author_user_id: Optional[str] = None) -> str:
    db = get_db()
    msg = ChatMessage(
        org_id=org_id, conversation_id=conversation_id, role=role,
        content=content, tool_calls=tool_calls, citations=citations,
        confidence=confidence, author_user_id=author_user_id,
        created_at_iso=utc_now_iso(),
    ).to_mongo()
    r = await db.chat_messages.insert_one(msg)
    await db.chat_conversations.update_one(
        {"_id": __import__("bson").ObjectId(conversation_id)},
        {"$set": {"last_message_at": utc_now_iso()}},
    )
    return str(r.inserted_id)


async def run_turn(*, org_id: str, agent_id: str, conversation_id: str,
                     user_text: str, website_slug: Optional[str] = None,
                     is_sandbox: bool = False, agent_version_id: Optional[str] = None,
                     call_record_id: Optional[str] = None) -> Dict[str, Any]:
    """Run one conversation turn. Persists visitor + AI messages, records audit.
    Returns {reply, action, tool_calls, citations, confidence, needs_human, escalation_reason,
              booking_id?, interaction_ids: [...]}
    """
    db = get_db()
    # Kill-switch guard
    ks = await db.kill_switches.find_one({"org_id": org_id})
    if ks and not ks.get("ai_enabled", True) and not is_sandbox:
        # Persist a system-fallback message
        await _persist_message(conversation_id=conversation_id, org_id=org_id, role="ai",
                                    content="Thanks for reaching out — a team member will follow up shortly.",
                                    confidence=0.0)
        await db.chat_conversations.update_one(
            {"_id": __import__("bson").ObjectId(conversation_id)},
            {"$set": {"needs_human": True, "escalation_reason": "org kill-switch enabled",
                        "status": "needs_human"}},
        )
        return {"reply": "Thanks for reaching out — a team member will follow up shortly.",
                 "action": "escalate", "needs_human": True,
                 "escalation_reason": "org kill-switch enabled",
                 "tool_calls": [], "citations": [], "confidence": 0.0,
                 "interaction_ids": []}

    version = await _load_agent_version(agent_id, agent_version_id)
    if not is_sandbox and not (version and version.get("is_live", True)):
        pass  # tolerate: an agent may not be live yet but we're still testing

    # Persist visitor message first
    await _persist_message(conversation_id=conversation_id, org_id=org_id, role="visitor",
                                content=user_text)

    tool_ctx = ToolContext(org_id=org_id, actor="sandbox" if is_sandbox else "agent",
                            website_slug=website_slug, conversation_id=conversation_id)

    # Retrieval
    retrieval = await build_retrieval_context(org_id, user_text, top_k=5)
    prof = await db.business_profiles.find_one({"org_id": org_id})
    business_name = (prof or {}).get("business_name") or (retrieval.get("structured") or {}).get("business_name")

    allowed_tools = list(version.get("allowed_tools") or [])
    # Prevent write tools when agent is not enabled to book
    tool_list_text = tool_spec_summary(allowed_tools)

    ctx_text = _render_context(retrieval)
    version_annotated = dict(version)
    version_annotated["agent_type"] = version.get("agent_type") or "receptionist"
    system_prompt = _build_system_prompt(
        agent_version=version_annotated, business_name=business_name,
        context_text=ctx_text, tool_list_text=tool_list_text, sandbox=is_sandbox,
    )

    interaction_ids: List[str] = []
    tool_history: List[Dict[str, Any]] = []
    reply_text = ""
    intent = "answer"
    tool_calls_out: List[Dict[str, Any]] = []
    citations = retrieval.get("citations") or []
    confidence = 0.5
    needs_human = False
    escalation_reason: Optional[str] = None
    booking_id: Optional[str] = None
    error: Optional[str] = None

    for step in range(MAX_TOOL_STEPS + 1):
        user_prompt = _messages_for_prompt(user_text, tool_history)
        started = time.time()
        decision = None
        llm_err: Optional[Exception] = None
        # Retry-once on transient LLM error before escalating (network flake, JSON parse
        # blip). Second failure still escalates, but the visitor sees a retry-friendly note.
        for attempt in range(2):
            try:
                decision = await generate_json(system_prompt, user_prompt, max_retries=1)
                llm_err = None
                break
            except LlmError as e:
                llm_err = e
        if llm_err is not None or decision is None:
            latency = int((time.time() - started) * 1000)
            error = str(llm_err)
            iid = await _record_interaction(
                org_id=org_id, agent_id=agent_id,
                agent_version_id=str(version.get("_id") or ""),
                conversation_id=conversation_id, call_record_id=call_record_id,
                action="error", model=version.get("model") or "claude-sonnet-4-6",
                prompt_tokens=_approx_tokens(system_prompt + user_prompt),
                completion_tokens=0, latency_ms=latency,
                tools_used=[], outcome="llm_error", confidence=0.0,
                error=error, is_sandbox=is_sandbox,
            )
            interaction_ids.append(iid)
            reply_text = ("Sorry — hiccup on my end. Could you say that again? "
                          "If it happens again I'll grab a teammate.")
            intent = "escalate"; needs_human = True; escalation_reason = "llm_error"
            break
        latency = int((time.time() - started) * 1000)

        intent = str(decision.get("intent") or "answer").lower()
        reply_text = str(decision.get("reply_text") or "").strip()
        tool_name = decision.get("tool_name")
        tool_args = decision.get("tool_args") or {}
        confidence = float(decision.get("confidence") or 0.5)
        cited = decision.get("cited_source_ids") or []
        if cited:
            # narrow citations to only the ones the LLM picked
            citations = [c for c in (retrieval.get("citations") or []) if c.get("source_id") in cited] or citations

        # Record this LLM call
        iid = await _record_interaction(
            org_id=org_id, agent_id=agent_id,
            agent_version_id=str(version.get("_id") or ""),
            conversation_id=conversation_id, call_record_id=call_record_id,
            action=intent, model=version.get("model") or "claude-sonnet-4-6",
            prompt_tokens=_approx_tokens(system_prompt + user_prompt),
            completion_tokens=_approx_tokens(json.dumps(decision)),
            latency_ms=latency,
            tools_used=[{"name": tool_name, "args": tool_args}] if tool_name else [],
            outcome=intent, confidence=confidence, error=None, is_sandbox=is_sandbox,
        )
        interaction_ids.append(iid)

        conf_thr = float(version.get("confidence_threshold") or 0.4)
        if confidence < conf_thr and intent != "escalate":
            intent = "escalate"
            escalation_reason = f"low_confidence ({confidence:.2f} < {conf_thr})"

        if intent == "tool_call":
            if not tool_name or tool_name not in allowed_tools:
                # Soft-fail: LLM hallucinated / picked disallowed tool. Feed error back so it can retry.
                allowed_list = ", ".join(allowed_tools) or "(no tools enabled)"
                tool_history.append({
                    "tool": tool_name or "(missing)",
                    "args": tool_args or {},
                    "ok": False,
                    "result": {"error": (f"Unknown or disallowed tool {tool_name!r}. "
                                          f"You may ONLY use one of: {allowed_list}. "
                                          "Retry with the correct name, or return intent='answer' / 'escalate'.")},
                })
                tool_calls_out.append({"name": tool_name, "args": tool_args,
                                            "ok": False, "result": None,
                                            "error": f"unknown/disallowed tool {tool_name!r}"})
                # loop again to let the LLM correct itself
                continue
            result = await run_tool(tool_name, tool_args or {}, tool_ctx)
            tool_calls_out.append({"name": tool_name, "args": tool_args,
                                        "ok": result.ok, "result": result.data,
                                        "error": result.error})
            tool_history.append({"tool": tool_name, "args": tool_args,
                                     "ok": result.ok,
                                     "result": (result.data if result.ok else {"error": result.error})})
            if tool_name == "create_booking" and result.ok and isinstance(result.data, dict):
                booking_id = result.data.get("booking_id")
            # loop again — feed tool result back to LLM for a final phrasing.
            continue

        # answer or escalate — done
        break
    else:
        # Ran out of steps without final answer
        intent = "escalate"; escalation_reason = "max_tool_steps"

    if intent == "escalate":
        needs_human = True
        await db.chat_conversations.update_one(
            {"_id": __import__("bson").ObjectId(conversation_id)},
            {"$set": {"needs_human": True, "escalation_reason": escalation_reason,
                        "status": "needs_human" if not is_sandbox else "sandbox"}},
        )
        if not reply_text:
            reply_text = ("Let me hand this over to someone on the team who can help. "
                            "Would you like to leave a name and email so we can follow up?")

    # Persist AI reply
    if not reply_text:
        reply_text = "Sorry — I didn't catch that. Could you rephrase?"
    # Final defence: extract booking_id from ANY successful create_booking tool_call
    # this turn — the loop already assigns it, but this ensures it's never lost if
    # the LLM issued multiple tool calls or the loop exited via the else clause.
    if not booking_id:
        for tc in tool_calls_out:
            if tc.get("name") == "create_booking" and tc.get("ok") and isinstance(tc.get("result"), dict):
                bid = tc["result"].get("booking_id")
                if bid:
                    booking_id = bid
                    break
    await _persist_message(conversation_id=conversation_id, org_id=org_id, role="ai",
                                content=reply_text,
                                tool_calls=tool_calls_out or None,
                                citations=citations or None,
                                confidence=confidence)

    return {"reply": reply_text, "action": intent, "tool_calls": tool_calls_out,
             "citations": citations, "confidence": confidence,
             "needs_human": needs_human, "escalation_reason": escalation_reason,
             "booking_id": booking_id, "interaction_ids": interaction_ids}
