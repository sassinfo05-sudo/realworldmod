"""Custom domain wizard endpoints. State transitions via provider adapter."""
import re
from typing import Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import Domain, User
from ..services.domain_providers import all_providers, get_provider, refresh_credentials

router = APIRouter(prefix="/domains", tags=["domains"])


_HOSTNAME_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")


def _normalize_hostname(h: str) -> str:
    h = (h or "").strip().lower().rstrip(".")
    if h.startswith("http://") or h.startswith("https://"):
        h = h.split("://", 1)[1]
    h = h.split("/")[0]
    return h


@router.get("/providers")
async def list_providers(user: User = Depends(current_user)):
    """Public-ish: any authenticated user can see which providers are wired."""
    await refresh_credentials()
    return {"providers": [
        {"key": p.key, "label": p.label, "is_connected": p.is_connected,
         "honest_status": p.honest_status}
        for p in all_providers()
    ]}


class DomainCreate(BaseModel):
    hostname: str
    website_id: str
    provider: str = "simulated"


@router.post("")
async def create_domain(req: DomainCreate, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    # Server-side entitlement: custom domains are a paid feature (never trust the UI gate).
    from ..services.entitlements import enforce_feature_enabled
    await enforce_feature_enabled(org_id, "custom_domain")
    hostname = _normalize_hostname(req.hostname)
    if not _HOSTNAME_RE.match(hostname):
        raise HTTPException(400, "Invalid hostname format")
    # Only allow binding a website in the same org
    website = await db.websites.find_one({"_id": ObjectId(req.website_id), "org_id": org_id})
    if not website:
        raise HTTPException(404, "Website not found for this workspace")
    if not website.get("slug"):
        raise HTTPException(400, "Publish your site once before attaching a custom domain")

    existing = await db.domains.find_one({"hostname": hostname})
    if existing:
        raise HTTPException(409, "This hostname is already claimed")

    await refresh_credentials()
    provider = get_provider(req.provider)
    status = await provider.create_hostname(hostname, origin_slug=website["slug"])

    domain = Domain(
        org_id=org_id,
        website_id=req.website_id,
        hostname=hostname,
        provider=req.provider,
        provider_ref=status.provider_ref,
        state=status.state,
        dns_records=status.dns_records or [],
        ownership=status.ownership_record or {},
        ssl_status=status.ssl_status,
        error_detail=status.error_detail,
        error_hint=status.error_hint,
        last_checked_at=utc_now_iso(),
    )
    res = await db.domains.insert_one(domain.to_mongo())
    domain.id = str(res.inserted_id)
    return domain.model_dump()


@router.get("")
async def list_domains(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    cursor = db.domains.find({"org_id": org_id, "state": {"$ne": "removed"}}).sort("created_at", -1)
    out = []
    async for d in cursor:
        out.append(Domain.from_mongo(d).model_dump())
    return {"domains": out}


@router.get("/{domain_id}/status")
async def poll_status(domain_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.domains.find_one({"_id": ObjectId(domain_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Domain not found")
    await refresh_credentials()
    provider = get_provider(doc.get("provider", "simulated"))
    status = await provider.check_status(doc["hostname"], doc.get("provider_ref"))

    updates = {
        "state": status.state,
        "ssl_status": status.ssl_status,
        "error_detail": status.error_detail,
        "error_hint": status.error_hint,
        "last_checked_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }
    if status.state == "connected" and not doc.get("connected_at"):
        updates["connected_at"] = utc_now_iso()
    await db.domains.update_one({"_id": doc["_id"]}, {"$set": updates})
    fresh = await db.domains.find_one({"_id": doc["_id"]})
    return Domain.from_mongo(fresh).model_dump()


@router.post("/{domain_id}/retry")
async def retry(domain_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.domains.find_one({"_id": ObjectId(domain_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Domain not found")
    await refresh_credentials()
    provider = get_provider(doc.get("provider", "simulated"))
    status = await provider.verify_ownership(doc["hostname"], doc.get("provider_ref"))
    await db.domains.update_one({"_id": doc["_id"]}, {"$set": {
        "state": status.state,
        "ssl_status": status.ssl_status,
        "error_detail": status.error_detail,
        "error_hint": status.error_hint,
        "last_checked_at": utc_now_iso(),
    }})
    fresh = await db.domains.find_one({"_id": doc["_id"]})
    return Domain.from_mongo(fresh).model_dump()


class DomainPatch(BaseModel):
    primary: Optional[bool] = None
    redirect_apex_to_www: Optional[bool] = None
    redirect_www_to_apex: Optional[bool] = None


@router.patch("/{domain_id}")
async def patch_domain(domain_id: str, patch: DomainPatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.domains.find_one({"_id": ObjectId(domain_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Domain not found")
    set_fields = {}
    if patch.primary is not None:
        if patch.primary:
            # unset primary on other domains for the same website
            await db.domains.update_many(
                {"org_id": org_id, "website_id": doc["website_id"], "_id": {"$ne": doc["_id"]}},
                {"$set": {"primary": False}}
            )
        set_fields["primary"] = patch.primary
    if patch.redirect_apex_to_www is not None:
        set_fields["redirect_apex_to_www"] = patch.redirect_apex_to_www
    if patch.redirect_www_to_apex is not None:
        set_fields["redirect_www_to_apex"] = patch.redirect_www_to_apex
    if set_fields:
        set_fields["updated_at"] = utc_now_iso()
        await db.domains.update_one({"_id": doc["_id"]}, {"$set": set_fields})
    fresh = await db.domains.find_one({"_id": doc["_id"]})
    return Domain.from_mongo(fresh).model_dump()


@router.delete("/{domain_id}")
async def delete_domain(domain_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.domains.find_one({"_id": ObjectId(domain_id), "org_id": org_id})
    if not doc:
        raise HTTPException(404, "Domain not found")
    await refresh_credentials()
    provider = get_provider(doc.get("provider", "simulated"))
    try:
        await provider.delete_hostname(doc["hostname"], doc.get("provider_ref"))
    except Exception:
        pass
    await db.domains.update_one({"_id": doc["_id"]}, {"$set": {
        "state": "removed", "updated_at": utc_now_iso()
    }})
    return {"ok": True}
