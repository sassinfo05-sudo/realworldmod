"""Round 11 — funnel / channel / commerce KPI reports (owner-scoped).

Mounted at /api/analytics/reports (the older `/api/analytics/track|summary` live in media_forms_analytics.py).
All numbers come from live collections; nothing is estimated or invented. Costs: none (pure aggregation).
"""
from __future__ import annotations

import csv
import io
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from ..db import get_db
from ..deps import current_user, require_org
from ..models import User
from ..services.attribution import channel_of

router = APIRouter(prefix="/analytics/reports", tags=["analytics-reports"])

FUNNEL_ORDER = ["pageview", "cta_click", "form_submit", "booking_created", "checkout_started", "order_paid"]
FUNNEL_LABELS = {"pageview": "Visits", "cta_click": "CTA clicks", "form_submit": "Form submits",
                 "booking_created": "Bookings", "checkout_started": "Checkouts started", "order_paid": "Orders paid"}


def _since(days: int) -> str:
    days = max(1, min(int(days or 30), 365))
    return (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()


def _pct(n: int, d: int) -> float:
    return round(100.0 * n / d, 1) if d else 0.0


async def _overview(db, org_id: str, days: int) -> Dict[str, Any]:
    since = _since(days)
    ev_q = {"org_id": org_id, "created_at": {"$gte": since}}

    # ---- funnel counts from analytics_events ----
    counts: Dict[str, int] = defaultdict(int)
    by_day: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    channel_events: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    async for e in db.analytics_events.find(ev_q, {"kind": 1, "created_at": 1, "meta": 1}).limit(200000):
        k = e.get("kind")
        counts[k] += 1
        day = str(e.get("created_at") or "")[:10]
        by_day[day][k] += 1
        meta = e.get("meta") or {}
        ch = meta.get("channel") or channel_of(meta.get("attribution"))
        channel_events[ch][k] += 1

    # ---- commerce KPIs from store_orders (paid/fulfilled) ----
    paid_q = {"org_id": org_id, "status": {"$in": ["paid", "fulfilled"]}, "created_at": {"$gte": since}}
    revenue = 0
    orders = 0
    refunds = 0
    refunded_cents = 0
    buyers: Dict[str, Dict[str, Any]] = {}
    channel_revenue: Dict[str, Dict[str, int]] = defaultdict(lambda: {"orders": 0, "revenue_cents": 0})
    async for o in db.store_orders.find(paid_q, {"total_cents": 1, "buyer": 1, "attribution": 1, "created_at": 1,
                                                   "refunded_cents": 1, "refund": 1}).limit(100000):
        total = int(o.get("total_cents", 0) or 0)
        revenue += total
        orders += 1
        key = ((o.get("buyer") or {}).get("email") or (o.get("buyer") or {}).get("phone") or "").strip().lower()
        if key:
            b = buyers.setdefault(key, {"orders": 0, "revenue_cents": 0})
            b["orders"] += 1
            b["revenue_cents"] += total
        ch = channel_of(o.get("attribution"))
        channel_revenue[ch]["orders"] += 1
        channel_revenue[ch]["revenue_cents"] += total
        day = str(o.get("created_at") or "")[:10]
        by_day[day]["revenue_cents"] += total
    async for o in db.store_orders.find({"org_id": org_id, "status": "refunded", "created_at": {"$gte": since}},
                                        {"total_cents": 1}).limit(100000):
        refunds += 1
        refunded_cents += int(o.get("total_cents", 0) or 0)

    repeat_buyers = sum(1 for b in buyers.values() if b["orders"] > 1)
    aov = int(revenue / orders) if orders else 0
    ltv = int(revenue / len(buyers)) if buyers else 0

    # Fill the funnel with order_paid from the orders collection if the event stream is younger than the orders.
    if counts.get("order_paid", 0) < orders:
        counts["order_paid"] = orders

    funnel: List[Dict[str, Any]] = []
    prev = None
    for k in FUNNEL_ORDER:
        n = int(counts.get(k, 0))
        funnel.append({"kind": k, "label": FUNNEL_LABELS[k], "count": n,
                       "rate_from_visits": _pct(n, counts.get("pageview", 0)),
                       "rate_from_previous": _pct(n, prev) if prev is not None else None})
        prev = n

    channels_all = set(channel_events) | set(channel_revenue)
    channels = []
    for ch in sorted(channels_all):
        ev = channel_events.get(ch, {})
        rv = channel_revenue.get(ch, {"orders": 0, "revenue_cents": 0})
        visits = int(ev.get("pageview", 0))
        leads = int(ev.get("form_submit", 0)) + int(ev.get("booking_created", 0))
        channels.append({"channel": ch, "visits": visits, "cta_clicks": int(ev.get("cta_click", 0)), "leads": leads,
                         "orders": rv["orders"], "revenue_cents": rv["revenue_cents"],
                         "lead_rate": _pct(leads, visits), "order_rate": _pct(rv["orders"], visits)})
    channels.sort(key=lambda c: (-(c["revenue_cents"]), -c["visits"]))

    days_sorted = sorted(by_day)
    timeseries = [{"day": d, "visits": by_day[d].get("pageview", 0), "leads": by_day[d].get("form_submit", 0) + by_day[d].get("booking_created", 0),
                   "orders": by_day[d].get("order_paid", 0), "revenue_cents": by_day[d].get("revenue_cents", 0)} for d in days_sorted]

    return {
        "days": max(1, min(int(days or 30), 365)), "since": since,
        "funnel": funnel,
        "channels": channels,
        "commerce": {"orders": orders, "revenue_cents": revenue, "aov_cents": aov, "buyers": len(buyers),
                     "repeat_buyers": repeat_buyers, "repeat_rate": _pct(repeat_buyers, len(buyers)),
                     "ltv_cents": ltv, "refunds": refunds, "refunded_cents": refunded_cents,
                     "refund_rate": _pct(refunds, orders + refunds)},
        "timeseries": timeseries,
        "notes": ["Revenue = paid/fulfilled store orders in the window (invoices and subscriptions are reported on Billing/Invoices).",
                  "Channel = UTM source/medium (or click ids) captured on the visitor's first visit and carried through the conversion.",
                  "CAC / ROAS need connected ad spend — not shown until an ad account is connected."],
    }


@router.get("/overview")
async def overview(days: int = 30, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return await _overview(get_db(), org_id, days)


@router.get("/export.csv")
async def export_csv(days: int = 30, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    data = await _overview(get_db(), org_id, days)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["section", "key", "visits", "cta_clicks", "leads", "orders", "revenue", "rate"])
    for f in data["funnel"]:
        w.writerow(["funnel", f["label"], "", "", "", f["count"], "", f["rate_from_visits"]])
    for c in data["channels"]:
        w.writerow(["channel", c["channel"], c["visits"], c["cta_clicks"], c["leads"], c["orders"], f"{c['revenue_cents'] / 100:.2f}", c["order_rate"]])
    cm = data["commerce"]
    for k, v in cm.items():
        w.writerow(["commerce", k, "", "", "", "", f"{v / 100:.2f}" if k.endswith("_cents") else v, ""])
    for t in data["timeseries"]:
        w.writerow(["day", t["day"], t["visits"], "", t["leads"], t["orders"], f"{t['revenue_cents'] / 100:.2f}", ""])
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": f"attachment; filename=zanelvo-analytics-{data['days']}d.csv"})
