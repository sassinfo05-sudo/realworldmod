"""One-off patcher: rebind stale hardcoded credential constants in tests/test_phase*.py to
resolve from tests/_creds (env / test_credentials.md). Idempotent."""
import glob
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
IMPORT_LINE = "from tests import _creds as _CREDS  # creds from env / test_credentials.md\n"

# constant name -> replacement expression
REBIND = {
    "FOUNDER_EMAIL": "_CREDS.FOUNDER_EMAIL",
    "OWNER_EMAIL": "_CREDS.OWNER_EMAIL",
    "DEMO_EMAIL": "_CREDS.OWNER_EMAIL",
    "FOUNDER_PW": "_CREDS.FOUNDER_PASSWORD",
    "FOUNDER_PASSWORD": "_CREDS.FOUNDER_PASSWORD",
    "OWNER_PW": "_CREDS.OWNER_PASSWORD",
    "OWNER_PASSWORD": "_CREDS.OWNER_PASSWORD",
    "DEMO_PASSWORD": "_CREDS.OWNER_PASSWORD",
}
LAUNCH_EMAILS = {
    "LAUNCH_EMAIL": ("owner@launch-demo.zanelvo.com", "LAUNCH_PW", "LAUNCH_PASSWORD"),
}

changed = []
for path in glob.glob(os.path.join(HERE, "test_phase*.py")):
    src = open(path, encoding="utf-8").read()
    orig = src
    # BASE_URL / API
    src = re.sub(r'^BASE_URL\s*=\s*os\.environ\.get\([^\n]*\)$', "BASE_URL = _CREDS.BASE_URL",
                 src, flags=re.M)
    src = re.sub(r'^API\s*=\s*f?"[^"\n]*/api"$', "API = _CREDS.API", src, flags=re.M)
    # Simple constant rebinds: NAME = "literal"  ->  NAME = _CREDS....
    for name, expr in REBIND.items():
        src = re.sub(rf'^{name}\s*=\s*"[^"\n]*"(\s*#.*)?$', f"{name} = {expr}\\1", src, flags=re.M)
    # Launch demo email + password (best effort)
    for name, (email, pw1, pw2) in LAUNCH_EMAILS.items():
        src = re.sub(rf'^{name}\s*=\s*"[^"\n]*"(\s*#.*)?$',
                     f'{name} = "{email}"\\1', src, flags=re.M)
        for pwn in (pw1, pw2):
            src = re.sub(rf'^{pwn}\s*=\s*"[^"\n]*"(\s*#.*)?$',
                         f'{pwn} = _CREDS.password_for("{email}")\\1', src, flags=re.M)
    if src != orig:
        # ensure the import is present (after the first import block)
        if "_CREDS" in src and IMPORT_LINE not in src:
            lines = src.splitlines(keepends=True)
            insert_at = 0
            for i, ln in enumerate(lines[:40]):
                if ln.startswith("import ") or ln.startswith("from "):
                    insert_at = i + 1
            lines.insert(insert_at, IMPORT_LINE)
            src = "".join(lines)
        open(path, "w", encoding="utf-8").write(src)
        changed.append(os.path.basename(path))

print("patched:", changed or "none")
