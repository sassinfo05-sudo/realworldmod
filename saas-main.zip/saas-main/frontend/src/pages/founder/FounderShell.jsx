import { useEffect, useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import api, { clearImpersonation } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import {
    Activity, Users, BarChart3, ShieldAlert, ScrollText, Zap, HeartPulse, Ticket,
    LogOut, Palette, TrendingUp, Plug, Mail, FileText,
} from "lucide-react";
import { toast } from "sonner";

const NAV = [
    { to: "/staff", label: "Cockpit", icon: Activity, end: true },
    { to: "/staff/branding", label: "Branding", icon: Palette },
    { to: "/staff/pricing", label: "Pricing", icon: TrendingUp },
    { to: "/staff/integrations", label: "Integrations", icon: Plug },
    { to: "/staff/emails", label: "Emails", icon: Mail },
    { to: "/staff/legal", label: "Legal & About", icon: FileText },
    { to: "/staff/tenants", label: "Tenants", icon: Users },
    { to: "/staff/metrics", label: "Metrics", icon: BarChart3 },
    { to: "/staff/controls", label: "Global controls", icon: ShieldAlert },
    { to: "/staff/audit", label: "Audit log", icon: ScrollText },
    { to: "/staff/health", label: "Health", icon: HeartPulse },
    { to: "/staff/approvals", label: "Approvals", icon: Ticket },
];

export default function FounderShell() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [impersonating, setImpersonating] = useState(null);

    async function refreshImpersonation() {
        try {
            const { data } = await api.get("/founder/impersonate/current");
            setImpersonating(data.active ? data.session : null);
            if (!data.active) {
                clearImpersonation();
            }
        } catch (e) { /* not founder or none */ }
    }
    useEffect(() => { refreshImpersonation(); const id = setInterval(refreshImpersonation, 60_000); return () => clearInterval(id); }, []);

    async function exitImpersonation() {
        try {
            await api.post("/founder/impersonate/end");
            toast.success("Impersonation ended");
            setImpersonating(null);
            clearImpersonation();
            navigate("/staff");
        } catch (e) { toast.error("Failed"); }
    }

    if (user?.role !== "platform_founder") {
        return (
            <div className="p-10 text-center" data-testid="founder-not-authorized">
                <div className="text-lg font-medium text-brand-ink">Founder-only area</div>
                <div className="mt-2 text-sm text-zinc-500">Your role is <span className="font-mono">{user?.role}</span> — this area is reserved for platform founders.</div>
            </div>
        );
    }

    return (
        <div className="min-h-full" data-testid="founder-shell">
            {impersonating && (
                <div className="bg-amber-500 text-white px-4 py-2 flex items-center justify-between gap-3" data-testid="impersonation-banner">
                    <div className="text-sm">
                        <span className="font-medium">Support session — acting as another org.</span>
                        <span className="ml-2 opacity-80">Reason: {impersonating.reason} · expires {impersonating.expires_at?.slice(11, 16)}</span>
                    </div>
                    <Button size="sm" variant="outline" onClick={exitImpersonation} className="bg-white text-amber-800 border-white hover:bg-amber-50" data-testid="impersonation-exit-btn">
                        <LogOut className="w-3.5 h-3.5 mr-1" /> Exit
                    </Button>
                </div>
            )}
            <div className="border-b border-brand-line bg-white sticky top-0 z-10 px-6 py-3 flex flex-wrap gap-2 items-center">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mr-3">Founder Control Center</div>
                <nav className="flex gap-1 flex-wrap">
                    {NAV.map(({ to, label, icon: Icon, end }) => (
                        <NavLink key={to} to={to} end={!!end}
                                    data-testid={`founder-nav-${label.toLowerCase().replace(/\W/g, "-")}`}
                                    className={({ isActive }) =>
                                        `inline-flex items-center gap-1.5 text-sm px-2.5 py-1.5 rounded-md ${
                                            isActive ? "bg-brand-cream text-brand-ink" : "text-zinc-500 hover:text-brand-ink"
                                        }`
                                    }>
                            <Icon className="w-3.5 h-3.5" /> {label}
                        </NavLink>
                    ))}
                </nav>
                <div className="ml-auto text-xs text-zinc-500 font-mono truncate max-w-[280px]" data-testid="founder-user-email">
                    {user?.email}
                </div>
            </div>
            <Outlet />
        </div>
    );
}
