import { useEffect, useMemo, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    DndContext, PointerSensor, useSensor, useSensors, closestCorners,
} from "@dnd-kit/core";
import { useDraggable, useDroppable } from "@dnd-kit/core";
import { toast } from "sonner";

function DealCard({ deal }) {
    const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: deal.id });
    const style = transform ? { transform: `translate(${transform.x}px, ${transform.y}px)` } : undefined;
    return (
        <div ref={setNodeRef} style={style} {...listeners} {...attributes}
             data-testid={`deal-card-${deal.id}`}
             className={`bg-white rounded-md border border-brand-line p-3 shadow-sm cursor-grab active:cursor-grabbing ${isDragging ? "opacity-40" : ""}`}>
            <div className="text-sm font-medium">{deal.name}</div>
            {deal.value != null && (
                <div className="text-xs text-brand-copper font-mono mt-1">${deal.value.toLocaleString()}</div>
            )}
        </div>
    );
}

function Column({ stage, deals }) {
    const { setNodeRef, isOver } = useDroppable({ id: stage.id });
    return (
        <div ref={setNodeRef}
             className={`flex-1 min-w-[220px] bg-brand-cream/50 rounded-lg border border-brand-line p-3 ${isOver ? "ring-2 ring-brand-copper" : ""}`}
             data-testid={`kanban-column-${stage.id}`}>
            <div className="flex items-center justify-between mb-3">
                <div className="text-xs uppercase tracking-widest text-zinc-600">{stage.name}</div>
                <Badge variant="outline" className="text-[10px]">{deals.length}</Badge>
            </div>
            <div className="space-y-2">
                {deals.map((d) => <DealCard key={d.id} deal={d} />)}
                {!deals.length && <div className="text-xs text-zinc-400 text-center py-4">No deals</div>}
            </div>
        </div>
    );
}

export default function CrmDeals() {
    const [pipeline, setPipeline] = useState(null);
    const [deals, setDeals] = useState([]);
    const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

    async function load() {
        const pl = await api.get("/crm/pipelines");
        const first = pl.data.pipelines[0];
        setPipeline(first);
        const dl = await api.get(`/crm/deals?pipeline_id=${first.id}`);
        setDeals(dl.data.deals || []);
    }
    useEffect(() => { load(); }, []);

    const dealsByStage = useMemo(() => {
        const map = {};
        (pipeline?.stages || []).forEach((s) => { map[s.id] = []; });
        deals.forEach((d) => {
            if (map[d.stage_id]) map[d.stage_id].push(d);
        });
        return map;
    }, [pipeline, deals]);

    async function onDragEnd(event) {
        const { active, over } = event;
        if (!over) return;
        const dealId = active.id;
        const newStageId = over.id;
        const deal = deals.find((d) => d.id === dealId);
        if (!deal || deal.stage_id === newStageId) return;
        // optimistic
        setDeals((cur) => cur.map((d) => d.id === dealId ? { ...d, stage_id: newStageId } : d));
        try {
            await api.patch(`/crm/deals/${dealId}/stage`, { stage_id: newStageId });
            toast.success("Stage updated");
        } catch (e) {
            toast.error("Could not move deal");
            load();  // rollback via refetch
        }
    }

    return (
        <div className="p-6" data-testid="crm-deals-page">
            <div className="mb-4">
                <h1 className="font-display text-2xl font-semibold">Deals</h1>
                <p className="text-sm text-zinc-500">Drag deals between stages to update. {pipeline?.name} pipeline.</p>
            </div>
            <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={onDragEnd}>
                <div className="flex gap-3 overflow-x-auto pb-4">
                    {(pipeline?.stages || []).sort((a,b) => a.order - b.order).map((s) => (
                        <Column key={s.id} stage={s} deals={dealsByStage[s.id] || []} />
                    ))}
                </div>
            </DndContext>
        </div>
    );
}
