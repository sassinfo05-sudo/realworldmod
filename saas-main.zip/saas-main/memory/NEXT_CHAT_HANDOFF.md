# Zanelvo — Handoff for Next Chat

Last updated: 2026-09 (end of Cycle 1 + path-based revert)

## 0) How to run / verify
- Services via **supervisor** only: `sudo supervisorctl restart backend|frontend|all`. Never start your own server.
- **.env was lost on import and rebuilt** — if it happens again: `backend/.env` needs MONGO_URL, DB_NAME=zanelvo_db, JWT_SECRET (random), JWT_ALG=HS256, JWT_ACCESS_TTL_MIN, EMERGENT_LLM_KEY, LLM_PROVIDER=anthropic, LLM_MODEL=claude-sonnet-4-6, FOUNDER_EMAIL=founder@zanelvo.com, DEMO_OWNER_EMAIL=owner@zanelvo.com, APP_ENV=dev, CORS_ORIGINS=*. `frontend/.env` needs REACT_APP_BACKEND_URL (preview host) + WDS_SOCKET_PORT=443.
- **Backend startup is slow (~15s)**: seed runs an LLM call to generate the demo site. `curl /api/brand` may return empty until ready. Wait before testing.
- **Credentials** (persist in `/app/memory/test_credentials.md`): founder@zanelvo.com / owner@zanelvo.com. Passwords in that file.

## 1) Gotchas learned
- **Login/Signup**: email form is now shown by DEFAULT (no toggle). data-testids: login-email, login-password, login-submit; signup-*.
- **Screenshot tool** re-renders the initial page_url and IGNORES post-interaction scroll/state — don't trust it for authed/scrolled views. For real browser checks use `/opt/plugins-venv/bin/python` with playwright (async_api) — it works and can read network + console.
- **Website Block types** live in a `Literal` at `backend/app/models.py` (~line 140). ANY new block type (e.g. we added `store`) MUST be added there or publishing/saving the site 500s on validation.
- Brand name/emails/legal come from `db.platform_settings` MERGED OVER `config.BRAND_DEFAULT`. Colors + logo_svg come straight from `config.BRAND_DEFAULT`. To reset brand, drop the platform_settings doc (or the whole zanelvo_db — creds persist via creds file).

## 2) Brand / theming (Cycle 1 done)
- Palette = indigo `#4F46E5` primary + sunset gradient (indigo→magenta #D6289B→amber #F59E0B).
- Platform UI recolors via **Tailwind tokens** in `frontend/tailwind.config.js` (`brand.copper` = primary indigo, `brand.copperHover`, `brand.accent`, `brand.gold`, `brand.ink`, `brand.cream`, `brand.line`). NOTE: token is still NAMED `copper` but holds indigo — hundreds of `brand-copper` classes recolor automatically. Do NOT rename the token.
- Logo = gradient "Z" SVG in `config.BRAND_DEFAULT["logo_svg"]` (has its own <linearGradient id="zvg">). Rendered by `frontend/src/components/Logo.jsx`.
- Tenant public-site colors use CSS vars `--tenant-*` from the website theme (separate system).

## 3) Customer site address = PATH based: `zanelvo.com/site/<name>`
- (User decided AGAINST app.zanelvo.com / wildcard subdomains. Emergent doesn't document wildcard support; app.zanelvo.com single-domain IS supported but user chose path form.)
- `<name>` = website **slug**. Rules enforced in `backend/app/services/publishing.py`:
  - `validate_subdomain()`: 4–12 letters a–z only; blocked `RESERVED_SUBDOMAINS`.
  - `normalize_subdomain()`: strips to letters, lowercases, caps 12.
  - `is_subdomain_available()`: unique across `websites.slug` + `slug_history`.
- Live check: `GET /api/editor/website/slug-available?slug=xxx` → {available, normalized, reason}.
- Publish (`POST /api/editor/website/publish`) validates chosen slug: 400 invalid/reserved, 409 taken.
- Public site served at route `/site/{slug}` (see `frontend/src/pages/public/PublicSite.jsx`, backend `routes/public_sites.py`).
- Legacy demo slug `demo-home-services` is grandfathered (has hyphens/>12). Fine.

## 4) Store features (done earlier this job, all tested)
- Refund+auto-restock: `POST /api/store/orders/{id}/refund {reason,restock}` (idempotent, buyer email). Cancel pending: `POST /api/store/orders/{id}/cancel`.
- Go-live: `GET /api/store/settings`, `POST /api/store/go-live {live}` (400 until Stripe key saved). Provider resolver `_resolve_store_provider()` picks real Stripe when store_mode=live+key else simulated.
- Abandoned nudge: `GET/POST /api/store/abandoned[/sweep]` + 10-min background loop `start_abandoned_sweep_loop()` in server startup.
- Store website block: component `frontend/src/components/blocks/StoreBlock.jsx`; public data via `/api/public/store/by-site/{slug}/products` + `/buy-now`. Registered in BlockRenderer + editor block-library + AddSectionMenu + models.py Literal.
- Payments/email are SIMULATED providers (honest labels) until real keys added per tenant (Setup → Integrations).

## 5) WHAT'S LEFT — next chat, in priority order

### Cycle 2 — Marketing 100× + "make every feature a dashboard"
Backend ALREADY EXISTS (verify, don't rebuild): `backend/app/routes/marketing.py` has campaigns (CRUD, ai-assist, send), automations (CRUD, publish, pause, runs, test-run), creative (generate, bundles, export). Founder growth console: `routes/founder*.py` (metrics, cockpit) + `frontend/src/pages/founder/*`.
TODO (mostly FRONTEND + some analytics aggregation):
1. **Marketing analytics dashboard**: real stats — sends/opens/clicks/conversions, revenue attribution, UTM breakdown, A/B results, trend charts. Check if events are tracked; add aggregation endpoints if missing.
2. **Own media**: let owners upload images/videos for campaigns/ads OR use AI-generated defaults. Reuse MediaPicker (`frontend/src/pages/editor/MediaPicker.jsx`) + existing media upload infra. For AI images use the image integration (ask user which: Nano Banana / OpenAI — via integration_playbook_expert_v2 + EMERGENT_LLM_KEY).
3. **AI + editable copy**: every campaign/ad gets AI-written titles & descriptions, editable inline, multi-variant. marketing.py already has ai-assist/creative — surface it in the UI.
4. **"Every feature a dashboard"**: upgrade thin pages (Marketing, AI, Bookings, Inbox, Payments, CRM) with top stat cards + charts + filters + empty-states. Frontend pages under `frontend/src/pages/dashboard/`.
5. Frontend pages to build/upgrade: `Marketing.jsx`, `AgentStudio.jsx`. Match brand tokens.

### Cycle 3 — Managed services ("everything through Zanelvo, owner profits") — NEEDS USER ACCOUNTS
Architecture: add a **metering + quota framework** and a "Zanelvo-managed vs bring-your-own-keys" mode to each adapter in `backend/app/services/tenant_integrations.py`.
1. Metering/quota engine (per-plan limits: emails, SMS, voice minutes, numbers) + overage tracking.
2. **Managed email first** (lowest compliance): platform Resend/SendGrid account, per-tenant reply/subdomain, quota enforced. Integration via integration_playbook_expert_v2.
3. **Stripe Connect** for customer payouts + platform application fee (owner's profit) + metered overage billing.
4. **Managed numbers/SMS/voice** via Twilio subaccounts: auto-provision numbers (instant), voice (instant), SMS needs A2P 10DLC registration (automatable but carrier review delay + fees). Optional: connect-existing-number (porting = manual).
5. **Auto-dropshipping**: central AliExpress/CJ creds, curated catalog, auto-order on sale. Adapters already scaffolded (routes/store.py sourcing). NO Shopify (competitor).
REQUIRED FROM USER before building live: Twilio/Telnyx acct, Resend/SendGrid acct, Stripe platform/Connect, AliExpress/CJ API. Until then: simulated mode, honestly labeled.

### Deferred / not doing
- **Host-aware routing** (app.zanelvo.com + wildcard <name>.zanelvo.com) — user chose path-based `/site/<name>` instead. Skip unless they revisit.
- Phase 8 leftovers: 3 labeled demo tenants (only 1 demo org now), Hebrew RTL pass, accessibility/perf pass, full marketing site (pricing/industries/security/legal exist as pages — verify depth), REQUIREMENTS_LEDGER/BUILD_LEDGER finalize.

## 6) Testing protocol
- Read/append `/app/test_result.md`; test BACKEND via deep_testing_backend_v2 first; ASK USER before frontend testing (auto_frontend_testing_agent). Tell the frontend agent the login steps (email form is visible by default now).
