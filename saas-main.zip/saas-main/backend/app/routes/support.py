"""Support: help center, tickets, AI support assistant (grounded ONLY on help articles),
status page (real health).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..services import audit
from ..services.help_articles import HELP_ARTICLES
from ..services.llm import generate_json, LlmError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/support", tags=["support"])


# ============ HELP CENTER ============

@router.get("/articles")
async def list_articles(q: Optional[str] = None,
                          category: Optional[str] = None):
    """Anonymous — help articles are public product docs."""
    db = get_db()
    query: Dict[str, Any] = {}
    if category:
        query["category"] = category
    if q:
        # naive keyword match — good enough for a few dozen articles
        query["$or"] = [
            {"title": {"$regex": q, "$options": "i"}},
            {"body_markdown": {"$regex": q, "$options": "i"}},
            {"keywords": {"$regex": q, "$options": "i"}},
        ]
    out = []
    async for a in db.help_articles.find(query).sort("order", 1):
        out.append({"slug": a["slug"], "title": a["title"],
                     "category": a["category"],
                     "keywords": a.get("keywords") or [],
                     "excerpt": (a.get("body_markdown") or "").strip().split("\n\n")[0][:220]})
    return {"articles": out, "categories": sorted({a["category"] for a in HELP_ARTICLES})}


@router.get("/articles/{slug}")
async def get_article(slug: str):
    db = get_db()
    a = await db.help_articles.find_one({"slug": slug})
    if not a:
        raise HTTPException(404, "Not found")
    a["id"] = str(a.pop("_id"))
    return a


# ============ SUPPORT TICKETS ============

class TicketCreate(BaseModel):
    subject: str = Field(min_length=3, max_length=200)
    category: str = "general"
    severity: str = "medium"      # low | medium | high | urgent
    body: str = Field(min_length=3)


@router.post("/tickets")
async def create_ticket(req: TicketCreate, request: Request,
                            user: User = Depends(current_user),
                            org_id: str = Depends(require_org)):
    db = get_db()
    doc = {"org_id": org_id, "user_id": user.id,
             "subject": req.subject.strip(),
             "category": req.category, "severity": req.severity,
             "status": "open",
             "messages": [{"author": "user", "user_id": user.id, "email": user.email,
                             "text": req.body, "created_at": utc_now_iso()}],
             "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    r = await db.support_tickets.insert_one(doc)
    await audit.record(action="support.ticket_create", actor_user_id=user.id,
                          actor_role=user.role, actor_email=user.email, org_id=org_id,
                          target_type="support_ticket", target_id=str(r.inserted_id),
                          meta={"subject": req.subject}, request=request)
    return {"id": str(r.inserted_id)}


@router.get("/tickets")
async def list_tickets(user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    out = []
    async for t in db.support_tickets.find({"org_id": org_id}).sort("created_at", -1).limit(200):
        out.append({"id": str(t["_id"]), "subject": t.get("subject"),
                     "category": t.get("category"), "severity": t.get("severity"),
                     "status": t.get("status"),
                     "messages_count": len(t.get("messages") or []),
                     "created_at": t.get("created_at"),
                     "updated_at": t.get("updated_at")})
    return {"tickets": out}


@router.get("/tickets/{tid}")
async def get_ticket(tid: str, user: User = Depends(current_user),
                        org_id: str = Depends(require_org)):
    db = get_db()
    t = await db.support_tickets.find_one({"_id": ObjectId(tid), "org_id": org_id})
    if not t:
        raise HTTPException(404, "Not found")
    t["id"] = str(t.pop("_id"))
    # Staff-only fields never reach the tenant (Round 11 unified staff inbox).
    for k in ("internal_notes", "lock", "history", "assignee_staff_id"):
        t.pop(k, None)
    t["assigned"] = bool(t.pop("assignee_email", None))
    return t


class TicketReply(BaseModel):
    text: str = Field(min_length=1)


@router.post("/tickets/{tid}/reply")
async def reply_ticket(tid: str, req: TicketReply,
                          user: User = Depends(current_user),
                          org_id: str = Depends(require_org)):
    db = get_db()
    t = await db.support_tickets.find_one({"_id": ObjectId(tid), "org_id": org_id})
    if not t:
        raise HTTPException(404, "Not found")
    await db.support_tickets.update_one({"_id": t["_id"]}, {"$push": {
        "messages": {"author": "user", "user_id": user.id, "email": user.email,
                       "text": req.text, "created_at": utc_now_iso()},
    }, "$set": {"updated_at": utc_now_iso(),
                 "status": "open" if t.get("status") == "resolved" else t.get("status", "open")}})
    return {"ok": True}


# ============ AI SUPPORT ASSISTANT (grounded ONLY on help articles) ============

class SupportAskReq(BaseModel):
    message: str


def _support_context() -> str:
    parts: List[str] = []
    for a in HELP_ARTICLES:
        parts.append(f"### {a['title']} (slug={a['slug']}, category={a['category']})\n"
                       + (a["body_markdown"] or "")[:1200])
    return "\n\n".join(parts)


@router.post("/ai/ask")
async def ai_support(req: SupportAskReq, user: User = Depends(current_user)):
    """AI answers ONLY from help articles. If it isn't in there, refuses honestly and
    prompts an escalation to a ticket. Same anti-hallucination discipline as receptionist.
    """
    system_prompt = (
        "You are Zanelvo's in-app support assistant. You answer STRICTLY and ONLY from the "
        "HELP ARTICLES provided in the CONTEXT. If the exact answer isn't in the context, "
        "reply intent='escalate' and suggest the visitor open a support ticket. "
        "Never invent product behavior, endpoints, or plan features not in CONTEXT. "
        "Cite by the slug of every help article you used.\n\n"
        f"CONTEXT (help articles):\n{_support_context()}\n\n"
        "Reply with a single JSON object: "
        '{"intent":"answer"|"escalate", "reply_text":"…", "cited_slugs":["slug1",…], "confidence":0.0-1.0}. '
        "No prose outside JSON."
    )
    try:
        decision = await generate_json(system_prompt, f"Visitor question: {req.message!r}",
                                            max_retries=1)
    except LlmError:
        return {"intent": "escalate",
                 "reply_text": "Sorry — I'm having trouble reaching my brain. Please open a ticket and we'll follow up.",
                 "cited_slugs": [], "confidence": 0.0}
    intent = decision.get("intent") or "answer"
    reply = str(decision.get("reply_text") or "").strip() or "I don't have that in the help center."
    slugs = decision.get("cited_slugs") or []
    return {"intent": intent, "reply_text": reply,
             "cited_slugs": slugs,
             "confidence": float(decision.get("confidence") or 0.5)}


# ============ STATUS PAGE (public health) ============

@router.get("/announcement")
async def public_announcement():
    """Read-only public read of the current active platform announcement."""
    db = get_db()
    ann = await db.announcements.find_one({"active": True}, sort=[("created_at", -1)])
    if not ann:
        return {"active": False}
    return {"active": True, "title": ann.get("title"), "body": ann.get("body"),
             "level": ann.get("level"), "created_at": ann.get("created_at")}


@router.get("/status")
async def status():
    """Public — real health signals from live collections + env."""
    db = get_db()
    checks = []
    # Mongo — try a quick count
    try:
        await db.organizations.estimated_document_count()
        checks.append({"component": "database", "status": "operational"})
    except Exception as e:  # noqa: BLE001
        checks.append({"component": "database", "status": "outage", "detail": str(e)[:120]})
    # LLM key
    import os as _os
    checks.append({"component": "llm",
                     "status": "operational" if _os.environ.get("EMERGENT_LLM_KEY") else "degraded",
                     "detail": None if _os.environ.get("EMERGENT_LLM_KEY") else "no key configured"})
    # Web
    checks.append({"component": "api", "status": "operational"})
    # Round 11 — staff-declared incidents (public status page). Active incidents degrade the overall status.
    incidents = []
    try:
        from datetime import datetime as _dt, timedelta as _td, timezone as _tz
        since = (_dt.now(_tz.utc) - _td(days=7)).isoformat()
        async for d in db.incidents.find({"$or": [{"status": {"$ne": "resolved"}}, {"created_at": {"$gte": since}}]}).sort("created_at", -1).limit(20):
            incidents.append({"id": d["_id"], "title": d.get("title"), "status": d.get("status"), "impact": d.get("impact"),
                              "components": d.get("components", []),
                              "updates": [{"at": u.get("at"), "status": u.get("status"), "message": u.get("message")} for u in (d.get("updates") or [])],
                              "started_at": d.get("started_at"), "resolved_at": d.get("resolved_at")})
    except Exception:  # noqa: BLE001
        incidents = []
    active = [i for i in incidents if i["status"] != "resolved"]
    for i in active:
        for comp in i.get("components") or []:
            for c in checks:
                if c["component"] == comp and c["status"] == "operational":
                    c["status"] = "outage" if i.get("impact") == "critical" else "degraded"
    overall = "operational" if all(c["status"] == "operational" for c in checks) else "degraded"
    if any(i.get("impact") == "critical" for i in active):
        overall = "major_outage"
    elif active and overall == "operational":
        overall = "degraded"
    return {"overall": overall, "checks": checks, "incidents": incidents, "active_incidents": len(active),
             "as_of": utc_now_iso()}


# ============ ACTIVATION CHECKLIST ============

@router.get("/activation")
async def activation_checklist(user: User = Depends(current_user),
                                  org_id: str = Depends(require_org)):
    from .setup import launch_score  # reuse
    ls = await launch_score(user, org_id)
    return ls
