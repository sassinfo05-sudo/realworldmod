"""Round 15 P0: prove atomic reservations cannot exceed a monetary cap under concurrency,
and that reserve() fails closed when reservation storage is unavailable.

No real LLM calls. Runs against the local Mongo the app uses. Single event loop (motor binds
to one loop), so both scenarios run inside one asyncio.run().

Run:  cd /app/backend && python -m pytest tests/test_r15_reservation_concurrency.py -q -s
  or: cd /app/backend && python tests/test_r15_reservation_concurrency.py
"""
import asyncio
import os
import uuid

os.environ.setdefault("APP_ENV", "test")


async def _concurrency_scenario():
    from app.services import usage
    from app.db import get_db

    db = get_db()
    org_id = f"test-conc-{uuid.uuid4().hex[:8]}"
    cap, est, n = 0.05, 0.02, 12
    max_allowed = int(cap // est)  # 2 fit; the 3rd (0.06) would exceed 0.05

    await usage.set_owner_ai_cap(org_id, cap)
    try:
        async def attempt():
            usage.set_context(org_id=org_id, feature="test/concurrency")
            res = await usage.reserve(kind="text", provider="test", model="test",
                                      est_cost=est, org_id=org_id, feature="test/concurrency")
            try:
                await usage.confirm_reservation(res, org_id=org_id)
                return True
            except Exception:
                return False
            finally:
                usage.reset_context()

        results = await asyncio.gather(*[attempt() for _ in range(n)])
        survivors = sum(1 for r in results if r)
        held = await usage._held_reservations({"org_id": org_id, "month": usage._month_key()})
        assert held <= cap + 1e-9, f"reserved ${held} exceeded cap ${cap}"
        assert 1 <= survivors <= max_allowed, f"{survivors} survived; expected 1..{max_allowed}"
        print(f"[concurrency] OK {survivors}/{n} survived; reserved=${held:.4f} <= cap=${cap:.2f}")
    finally:
        await db[usage.RESERVATIONS].delete_many({"org_id": org_id})
        await db[usage.ORG_AI_SETTINGS].delete_many({"org_id": org_id})


async def _fail_closed_scenario():
    from fastapi import HTTPException
    from app.services import usage

    class _BoomCollection:
        async def insert_one(self, *_a, **_k):
            raise RuntimeError("simulated mongo outage")

    class _BoomDB:
        def __getitem__(self, name):
            return _BoomCollection()

    orig = usage.get_db
    usage.get_db = lambda: _BoomDB()
    try:
        raised = False
        try:
            await usage.reserve(kind="text", provider="test", model="test", est_cost=0.01,
                                org_id="x", feature="test/failclosed")
        except HTTPException as e:
            raised = (e.status_code == 503)
        assert raised, "reserve() must fail closed (503) when storage is unavailable"
        print("[fail-closed] OK reserve() raised 503 when storage unavailable")
    finally:
        usage.get_db = orig


async def _run_all():
    await _concurrency_scenario()
    await _fail_closed_scenario()


def test_r15_reservations():
    asyncio.run(_run_all())


if __name__ == "__main__":
    asyncio.run(_run_all())
    print("ALL R15 RESERVATION TESTS PASSED")
