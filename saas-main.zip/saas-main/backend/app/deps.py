"""FastAPI dependencies: current user, org scoping, role checks.

Server-side enforcement: NEVER trust a client-supplied org_id. Every tenant-scoped
query MUST use `current_org_id` from the JWT via `require_org()`.
"""

import jwt
from fastapi import Depends, HTTPException, Request, status

from .db import get_db
from .models import User
from .security import decode_access_token


def _set_usage_ctx(request: Request, org_id, user_id) -> None:
    """Best-effort: seed the request-scoped usage context for LLM cost tracking."""
    try:
        from .services.usage import set_context
        set_context(org_id=org_id, user_id=user_id,
                    feature=getattr(getattr(request, "url", None), "path", None))
    except Exception:  # noqa: BLE001
        pass


async def _extract_token(request: Request) -> str:
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[len("Bearer ") :].strip()
    # Browser session: HttpOnly cookie + CSRF double-submit (services/session_cookies.py).
    from .services.session_cookies import token_from_cookie
    tok = token_from_cookie(request)
    if tok:
        return tok
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")


async def current_user(request: Request) -> User:
    token = await _extract_token(request)
    try:
        payload = decode_access_token(token)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

    db = get_db()
    # Zanelvo staff-panel session: separate account database.
    if payload.get("staff"):
        sdoc = await db.staff_accounts.find_one({"_id": _to_object(payload["sub"])})
        if not sdoc or not sdoc.get("active", True):
            raise HTTPException(status_code=401, detail="Staff account not found or disabled")
        # Staff sessions issued before a password change / forced logout are rejected.
        _sinv = sdoc.get("sessions_invalidated_at")
        if _sinv and int(payload.get("iat") or 0) <= int(_sinv):
            raise HTTPException(status_code=401, detail="Session expired — please sign in again")
        request.state.staff_role = sdoc.get("role", "support")
        return User(id=str(sdoc["_id"]), email=sdoc["email"], full_name=sdoc.get("full_name"),
                    password_hash=sdoc["password_hash"], org_id=None, role="platform_founder",
                    email_verified=True, staff_role=sdoc.get("role", "support"))
    imp_sid = payload.get("imp_sid")
    if imp_sid:
        # Impersonation token — the `sub` is the founder ACTOR, who may live in staff_accounts
        # (staff-panel founder) OR users (legacy founder). Resolve from either, THEN verify the
        # session is still active and expand into the target-org owner context.
        actor = await db.staff_accounts.find_one({"_id": _to_object(payload["sub"])})
        if not actor:
            actor = await db.users.find_one({"_id": _to_object(payload["sub"])})
        if not actor:
            raise HTTPException(status_code=401, detail="Impersonation actor not found")
        from bson import ObjectId as _OID
        from datetime import datetime as _dt, timezone as _tz
        try:
            sess = await db.impersonation_sessions.find_one({"_id": _OID(imp_sid), "active": True})
        except Exception:  # noqa: BLE001
            sess = None
        if not sess:
            raise HTTPException(status_code=401, detail="Impersonation session no longer active")
        try:
            exp = _dt.fromisoformat(sess["expires_at"].replace("Z", "+00:00"))
            if exp <= _dt.now(_tz.utc):
                await db.impersonation_sessions.update_one(
                    {"_id": sess["_id"]},
                    {"$set": {"active": False, "ended_at": _dt.now(_tz.utc).isoformat().replace("+00:00", "Z"),
                                "exit_reason": "expired"}},
                )
                raise HTTPException(status_code=401, detail="Impersonation session expired")
        except HTTPException:
            raise
        except Exception:  # noqa: BLE001
            pass
        if sess["target_org_id"] != payload.get("org_id"):
            raise HTTPException(status_code=401, detail="Impersonation token / session mismatch")
        # Bump actions_count and expose the session id via request.state for audit tagging.
        await db.impersonation_sessions.update_one({"_id": sess["_id"]},
                                                        {"$inc": {"actions_count": 1}})
        request.state.impersonation_session_id = imp_sid
        actor_id = str(actor["_id"])
        _set_usage_ctx(request, sess["target_org_id"], actor_id)
        # Return a User whose org_id + role reflect the acting-as identity.
        return User(id=actor_id, email=actor.get("email"), full_name=actor.get("full_name"),
                     password_hash=actor.get("password_hash", ""),
                     org_id=sess["target_org_id"], role="owner", email_verified=True)

    doc = await db.users.find_one({"_id": _to_object(payload["sub"])})
    if not doc:
        raise HTTPException(status_code=401, detail="User not found")
    # Sessions issued before a password reset / forced logout are rejected.
    inv = doc.get("sessions_invalidated_at")
    if inv and int(payload.get("iat") or 0) <= int(inv):
        raise HTTPException(status_code=401, detail="Session expired — please sign in again")
    _u = User.from_mongo(doc)
    _set_usage_ctx(request, _u.org_id, _u.id)
    return _u


def _to_object(id_str: str):
    from bson import ObjectId
    try:
        return ObjectId(id_str)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid subject")


async def require_org(user: User = Depends(current_user)) -> str:
    """Return the caller's org_id or 403. Platform founder has no org — must not access tenant data."""
    if not user.org_id:
        raise HTTPException(status_code=403, detail="No organization scope on this account")
    return user.org_id


def require_staff(*perms: str):
    """Staff-panel gating. Legacy founder user sessions (users collection) are treated as owner."""
    async def _check(user: User = Depends(current_user)) -> User:
        if user.role != "platform_founder":
            raise HTTPException(status_code=403, detail="Staff access only")
        role = user.staff_role or "owner"
        from .routes.staff import role_has  # local import to avoid cycle
        if perms and not any(role_has(role, p) for p in perms):
            raise HTTPException(status_code=403, detail=f"Your staff role ({role}) lacks: {', '.join(perms)}")
        return user
    return _check


def require_role(*allowed: str):
    """Dependency factory: allow only listed roles."""
    allowed_set = set(allowed)

    async def _check(user: User = Depends(current_user)) -> User:
        if user.role not in allowed_set:
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user

    return _check
