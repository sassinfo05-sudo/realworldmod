"""Staff email panel — send/receive, transactional automations, provider config, logs.

Mounted under /api/staff/email (staff-only, permission "emails"). The founder/owner
staff role configures the provider (Resend / SendGrid / SMTP) here — NOT on the
customer side. Everything runs in honest simulated mode until a provider is
connected. Inbound email arrives via the public webhook router (email_inbound).
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db, utc_now_iso
from ..deps import require_staff
from ..models import User
from ..services import integrations as integ
from ..services import platform_mail, platform_settings as ps, transactional as tx
from ..services.email_providers import list_providers

router = APIRouter(prefix="/api/staff/email", tags=["staff-email"])


@router.get("/overview")
async def overview(_: User = Depends(require_staff("emails"))):
    db = get_db()
    configured = await integ.is_configured("email")
    settings = await ps.get_settings()
    sent = await db.system_mail_log.count_documents({})
    inbound = await db.inbox_messages.count_documents({})
    unread = await db.inbox_messages.count_documents({"read": {"$ne": True}})
    automations = await tx.automation_state()
    return {
        "mode": "live" if configured else "simulated",
        "provider": (await integ._raw()).get("email", {}).get("provider", "none"),
        "addresses": settings.get("emails", {}),
        "counts": {"sent": sent, "inbound": inbound, "unread": unread,
                    "automations_on": sum(1 for v in automations.values() if v)},
        "providers": list_providers(),
    }


@router.get("/config")
async def get_config(_: User = Depends(require_staff("emails"))):
    pub = await integ.get_public()
    return {"email": pub.get("email", {}), "providers": list_providers(),
            "addresses": (await ps.get_settings()).get("emails", {})}


class ConfigIn(BaseModel):
    provider: Optional[str] = None
    resend_api_key: Optional[str] = None
    sendgrid_api_key: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_use_tls: Optional[bool] = None
    inbound_secret: Optional[str] = None
    resend_signing_secret: Optional[str] = None


@router.put("/config")
async def set_config(req: ConfigIn, _: User = Depends(require_staff("emails"))):
    patch = {k: v for k, v in req.model_dump().items() if v is not None}
    await integ.update({"email": patch})
    return {"ok": True, "email": (await integ.get_public()).get("email", {})}


class AddressIn(BaseModel):
    emails: Dict[str, Dict[str, str]]


@router.put("/addresses")
async def set_addresses(req: AddressIn, _: User = Depends(require_staff("emails"))):
    await ps.update_settings({"emails": req.emails})
    return {"ok": True, "addresses": (await ps.get_settings()).get("emails", {})}


@router.get("/templates")
async def templates(_: User = Depends(require_staff("emails"))):
    out = []
    for kind, meta in tx.AUTOMATIONS.items():
        rendered = await tx.render(meta["template"], _sample_vars(meta["template"]))
        out.append({"kind": kind, "label": meta["label"], "role": meta["role"],
                     "when": meta["when"], "desc": meta["desc"],
                     "subject": rendered["subject"], "html": rendered["html"]})
    return {"templates": out}


def _sample_vars(template: str) -> Dict[str, Any]:
    return {"name": "Alex", "code": "428913", "amount": "39.00", "item": "Business plan (monthly)",
            "days": "3", "device": "Chrome on macOS", "location": "London, UK",
            "message": "Thanks for reaching out — here's the answer to your question…",
            "subject": "Re: your enquiry", "verify_url": "#", "reset_url": "#"}


@router.get("/automations")
async def automations(_: User = Depends(require_staff("emails"))):
    states = await tx.automation_state()
    return {"automations": [
        {"kind": k, "enabled": states.get(k, m["default_on"]), **{x: m[x] for x in ("label", "role", "when", "desc")}}
        for k, m in tx.AUTOMATIONS.items()]}


@router.post("/automations/{kind}")
async def toggle_automation(kind: str, body: Dict[str, bool] = Body(...),
                             _: User = Depends(require_staff("emails"))):
    try:
        states = await tx.set_automation(kind, bool(body.get("enabled", True)))
    except ValueError:
        raise HTTPException(404, "Unknown automation")
    return {"ok": True, "automations": states}


class SendIn(BaseModel):
    to: str
    subject: str
    message: str
    role: str = "support"   # support | sales
    to_name: str = ""


@router.post("/send")
async def send(req: SendIn, actor: User = Depends(require_staff("emails"))):
    role = req.role if req.role in ("support", "sales") else "support"
    rendered = await tx.render("support_reply", {"subject": req.subject, "message": req.message})
    result = await platform_mail.send(role=role, to=req.to, subject=req.subject,
                                      text=req.message, html=rendered["html"])
    db = get_db()
    newest = await db.system_mail_log.find_one({"role": role, "to": req.to, "subject": req.subject},
                                               sort=[("created_at", -1)])
    if newest:
        await db.system_mail_log.update_one({"_id": newest["_id"]},
            {"$set": {"direction": "outbound", "body": req.message, "to_name": req.to_name,
                       "agent": actor.email, "kind": "manual"}})
    return {"ok": result.get("ok"), "simulated": result.get("simulated"), "error": result.get("error")}


class AiDraftIn(BaseModel):
    prompt: str
    tone: str = "friendly"        # friendly | professional | warm | urgent | concise
    audience: str = ""            # optional: who it's for
    existing: str = ""            # optional: current draft to improve


@router.post("/ai-draft")
async def ai_draft(req: AiDraftIn, actor: User = Depends(require_staff("emails"))):
    """AI writes/improves an email (subject + body) from a short brief. Metered like all LLM calls."""
    from ..services.llm import generate_json, LlmError
    from ..services.usage import set_context
    settings = await ps.get_settings()
    brand = settings.get("brand_name", "Zanelvo")
    set_context(feature="staff/email/ai-draft", user_id=actor.id)
    system = (
        f"You are the senior lifecycle & support copywriter for {brand}. Write a single email that is "
        f"clear, human and on-brand. Tone: {req.tone}. Keep it concise (max ~140 words), skimmable, and "
        "action-oriented with ONE clear ask. No spammy phrasing, no ALL CAPS, no emoji unless it truly fits. "
        "Return ONLY JSON: {\"subject\": str (max 60 chars), \"message\": str (plain text, use blank lines "
        "between short paragraphs), \"preheader\": str (max 90 chars)}."
    )
    brief = f"Brief: {req.prompt}\nAudience: {req.audience or 'a customer'}\n"
    if req.existing.strip():
        brief += f"\nImprove/rewrite this existing draft:\n{req.existing[:2000]}\n"
    try:
        data = await generate_json(system, brief, max_retries=1)
    except LlmError as e:
        raise HTTPException(status_code=502, detail=f"AI draft failed: {e}")
    return {
        "subject": str(data.get("subject") or "").strip()[:120],
        "message": str(data.get("message") or "").strip(),
        "preheader": str(data.get("preheader") or "").strip()[:120],
    }


@router.get("/logs")
async def logs(limit: int = 100, _: User = Depends(require_staff("emails"))):
    db = get_db()
    rows = [{**d, "_id": str(d["_id"]), "id": str(d["_id"])}
            async for d in db.system_mail_log.find({}).sort("created_at", -1).limit(min(limit, 300))]
    return {"logs": rows}


@router.get("/inbox")
async def inbox(_: User = Depends(require_staff("emails"))):
    db = get_db()
    rows = [{**d, "_id": str(d["_id"]), "id": str(d["_id"])}
            async for d in db.inbox_messages.find({}).sort("created_at", -1).limit(100)]
    return {"messages": rows}


@router.post("/inbox/{msg_id}/read")
async def mark_read(msg_id: str, _: User = Depends(require_staff("emails"))):
    from bson import ObjectId
    db = get_db()
    try:
        await db.inbox_messages.update_one({"_id": ObjectId(msg_id)}, {"$set": {"read": True}})
    except Exception:
        raise HTTPException(404, "Not found")
    return {"ok": True}


class ReplyIn(BaseModel):
    message: str
    role: str = "support"


@router.post("/inbox/{msg_id}/reply")
async def reply(msg_id: str, req: ReplyIn, actor: User = Depends(require_staff("emails"))):
    from bson import ObjectId
    db = get_db()
    try:
        msg = await db.inbox_messages.find_one({"_id": ObjectId(msg_id)})
    except Exception:
        msg = None
    if not msg:
        raise HTTPException(404, "Message not found")
    role = req.role if req.role in ("support", "sales") else "support"
    subject = "Re: " + (msg.get("subject") or "your message")
    rendered = await tx.render("support_reply", {"subject": subject, "message": req.message})
    result = await platform_mail.send(role=role, to=msg.get("from_email", ""), subject=subject,
                                      text=req.message, html=rendered["html"])
    await db.inbox_messages.update_one({"_id": msg["_id"]},
        {"$set": {"read": True, "replied": True, "replied_at": utc_now_iso(),
                   "reply_body": req.message, "agent": actor.email}})
    return {"ok": result.get("ok"), "simulated": result.get("simulated")}


class TestIn(BaseModel):
    to: str
    kind: str = "welcome"


@router.post("/test")
async def test_send(req: TestIn, _: User = Depends(require_staff("emails"))):
    if req.kind not in tx.AUTOMATIONS:
        raise HTTPException(400, "Unknown template")
    rendered = await tx.render(tx.AUTOMATIONS[req.kind]["template"], _sample_vars(tx.AUTOMATIONS[req.kind]["template"]))
    role = tx.AUTOMATIONS[req.kind]["role"]
    result = await platform_mail.send(role=role, to=req.to, subject="[Test] " + rendered["subject"],
                                      text=rendered["text"], html=rendered["html"])
    return {"ok": result.get("ok"), "simulated": result.get("simulated"), "error": result.get("error")}


_SAMPLE_INBOUND = [
    {"from": "sarah.doyle@gmail.com", "from_name": "Sarah Doyle", "to": "support@zanelvo.com",
     "subject": "Can I change my plan?", "text": "Hi, I'd like to upgrade to the Commerce plan — how do I do that? Thanks, Sarah"},
    {"from": "mreed@contractco.com", "from_name": "Marcus Reed", "to": "sales@zanelvo.com",
     "subject": "Multi-site pricing", "text": "We run 4 brands. Do you offer a discount for managing several websites under one account?"},
    {"from": "priya@studio.io", "from_name": "Priya Nair", "to": "support@zanelvo.com",
     "subject": "Custom domain not verifying", "text": "My domain has been 'pending' for an hour. Can you take a look?"},
]


@router.post("/inbox/simulate")
async def simulate_inbound(_: User = Depends(require_staff("emails"))):
    """Seed a sample inbound message (for demoing the inbox before DNS/MX is live)."""
    import random
    db = get_db()
    s = random.choice(_SAMPLE_INBOUND)
    await db.inbox_messages.insert_one({
        "provider": "simulated", "from_email": s["from"], "from_name": s["from_name"],
        "to_email": s["to"], "subject": s["subject"], "text": s["text"], "html": "",
        "direction": "inbound", "read": False, "replied": False, "created_at": utc_now_iso(),
    })
    return {"ok": True}
