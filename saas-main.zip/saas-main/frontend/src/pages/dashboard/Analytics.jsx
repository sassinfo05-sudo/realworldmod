import { useEffect, useState } from "react";
import api, { authHeaders } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Eye, MessageSquare, MousePointerClick, Download, ShoppingBag, Repeat, Wallet, Users } from "lucide-react";

function Stat({ label, value, Icon, sub }) {
    return (
        <div className="rounded-2xl border border-brand-line bg-white p-5">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-zinc-500">
                <Icon className="w-3.5 h-3.5 text-brand-copper" /> {label}
            </div>
            <div className="mt-2 font-display text-3xl text-brand-ink">{value ?? "—"}</div>
            {sub && <div className="text-xs text-zinc-500 mt-1">{sub}</div>}
        </div>
    );
}

const money = (c) => `$${((c || 0) / 100).toFixed(2)}`;
const CHANNEL_LABEL = { direct: "Direct", paid_search: "Paid search", paid_social: "Paid social", email: "Email", social: "Social",
    organic_search: "Organic search", referral: "Referral", other: "Other" };

/** Round 11 — funnel + channel + commerce KPIs from /api/analytics/reports/overview. */
function FunnelReport() {
    const [days, setDays] = useState(30);
    const [rep, setRep] = useState(null);
    const [err, setErr] = useState(null);
    useEffect(() => {
        setErr(null);
        api.get("/analytics/reports/overview", { params: { days } }).then((r) => setRep(r.data)).catch(() => setErr("Could not load the report"));
    }, [days]);
    const exportCsv = async () => {
        try {
            const r = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/analytics/reports/export.csv?days=${days}`, { headers: authHeaders(), credentials: "include" });
            if (!r.ok) throw new Error("export failed");
            const blob = await r.blob(); const url = URL.createObjectURL(blob);
            const a = document.createElement("a"); a.href = url; a.download = `zanelvo-analytics-${days}d.csv`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
        } catch { toast.error("Export failed"); }
    };
    const maxCount = Math.max(1, ...(rep?.funnel || []).map((f) => f.count));
    const cm = rep?.commerce || {};
    return (
        <div className="mt-8 space-y-6" data-testid="analytics-funnel-report">
            <div className="flex flex-wrap items-center gap-3">
                <h2 className="font-display text-xl text-brand-ink flex-1">Funnel &amp; channels</h2>
                <select value={days} onChange={(e) => setDays(Number(e.target.value))} className="bg-white border border-brand-line rounded-lg px-3 py-1.5 text-sm" data-testid="analytics-days">
                    <option value={7}>Last 7 days</option><option value={30}>Last 30 days</option><option value={90}>Last 90 days</option><option value={365}>Last 12 months</option>
                </select>
                <Button variant="outline" size="sm" className="border-brand-line" onClick={exportCsv} data-testid="analytics-export"><Download className="w-4 h-4 mr-1" /> Export CSV</Button>
            </div>
            {err && <div className="text-sm text-red-600">{err}</div>}

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3" data-testid="analytics-commerce">
                <Stat label="Revenue" value={money(cm.revenue_cents)} Icon={Wallet} sub={`${cm.orders ?? 0} paid orders`} />
                <Stat label="Avg order value" value={money(cm.aov_cents)} Icon={ShoppingBag} sub={`${cm.refunds ?? 0} refunds (${cm.refund_rate ?? 0}%)`} />
                <Stat label="Revenue / customer" value={money(cm.ltv_cents)} Icon={Users} sub={`${cm.buyers ?? 0} customers`} />
                <Stat label="Repeat rate" value={`${cm.repeat_rate ?? 0}%`} Icon={Repeat} sub={`${cm.repeat_buyers ?? 0} bought more than once`} />
            </div>

            <div className="rounded-2xl border border-brand-line bg-white p-6" data-testid="analytics-funnel">
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-4">Conversion funnel</div>
                <div className="space-y-2">
                    {(rep?.funnel || []).map((f) => (
                        <div key={f.kind} className="grid grid-cols-[140px_1fr_120px] items-center gap-3 text-sm" data-testid={`funnel-${f.kind}`}>
                            <span className="text-zinc-700">{f.label}</span>
                            <div className="h-6 bg-brand-cream rounded-md overflow-hidden"><div className="h-full bg-brand-copper/80 rounded-md" style={{ width: `${Math.max(2, (f.count / maxCount) * 100)}%` }} /></div>
                            <span className="font-mono text-right text-brand-ink">{f.count} <span className="text-zinc-400 text-xs">· {f.rate_from_visits}%</span></span>
                        </div>
                    ))}
                </div>
            </div>

            <div className="rounded-2xl border border-brand-line bg-white p-6 overflow-x-auto" data-testid="analytics-channels">
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-4">Channels (first touch)</div>
                {(!rep?.channels || rep.channels.length === 0) ? (
                    <div className="text-sm text-zinc-500">No attributed traffic yet. Add <span className="font-mono">?utm_source=…&amp;utm_medium=…</span> to the links you share and every visit, lead and order will be grouped here.</div>
                ) : (
                    <table className="w-full text-sm">
                        <thead><tr className="text-left text-xs text-zinc-500"><th className="py-1">Channel</th><th>Visits</th><th>CTA clicks</th><th>Leads</th><th>Orders</th><th>Revenue</th><th>Lead rate</th></tr></thead>
                        <tbody>
                            {rep.channels.map((c) => (
                                <tr key={c.channel} className="border-t border-brand-line" data-testid={`channel-${c.channel}`}>
                                    <td className="py-2 font-medium text-brand-ink">{CHANNEL_LABEL[c.channel] || c.channel}</td>
                                    <td>{c.visits}</td><td>{c.cta_clicks}</td><td>{c.leads}</td><td>{c.orders}</td>
                                    <td className="font-mono">{money(c.revenue_cents)}</td><td>{c.lead_rate}%</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            <div className="rounded-2xl border border-brand-line bg-white p-6" data-testid="analytics-timeseries">
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-4">Daily</div>
                {(!rep?.timeseries || rep.timeseries.length === 0) ? <div className="text-sm text-zinc-500">No activity in this window.</div> : (
                    <div className="flex items-end gap-1 h-28">
                        {rep.timeseries.slice(-60).map((t) => {
                            const maxV = Math.max(1, ...rep.timeseries.map((x) => x.visits));
                            return <div key={t.day} title={`${t.day}: ${t.visits} visits · ${t.leads} leads · ${t.orders} orders · ${money(t.revenue_cents)}`} className="flex-1 bg-brand-copper/70 rounded-t" style={{ height: `${Math.max(4, (t.visits / maxV) * 100)}%` }} />;
                        })}
                    </div>
                )}
            </div>
            <ul className="text-[11px] text-zinc-500 list-disc pl-4 space-y-0.5">{(rep?.notes || []).map((n, i) => <li key={i}>{n}</li>)}</ul>
        </div>
    );
}

export default function Analytics() {
    const [data, setData] = useState(null);
    useEffect(() => {
        api.get("/analytics/summary").then((r) => setData(r.data)).catch(() => {});
    }, []);

    return (
        <div className="p-6 md:p-10 max-w-5xl" data-testid="analytics-page">
            <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Analytics</div>
            <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium">Who's visiting, what they do.</h1>
            <p className="mt-3 text-zinc-600">Page views, form submits and CTA clicks for your site, plus the funnel from visit to paid order by acquisition channel. Campaign-level attribution lives under Marketing → Analytics.</p>

            <div className="mt-6 grid sm:grid-cols-3 gap-3" data-testid="analytics-totals">
                <Stat label="Page views" value={data?.totals?.pageviews} Icon={Eye} />
                <Stat label="Form submits" value={data?.totals?.form_submits} Icon={MessageSquare} />
                <Stat label="CTA clicks" value={data?.totals?.cta_clicks} Icon={MousePointerClick} />
            </div>

            <FunnelReport />

            <div className="mt-6 rounded-2xl border border-brand-line bg-white p-6" data-testid="analytics-by-page">
                <h2 className="font-display text-xl text-brand-ink">Top pages (all-time)</h2>
                <div className="mt-4 divide-y divide-brand-line">
                    {(data?.by_page || []).map((p) => (
                        <div key={p.page_slug || "unknown"} className="flex items-center justify-between py-2 text-sm">
                            <span className="font-mono">{p.page_slug || "—"}</span>
                            <span className="text-zinc-600">{p.views}</span>
                        </div>
                    ))}
                    {(!data?.by_page || data.by_page.length === 0) && (
                        <div className="text-sm text-zinc-500 py-2">No page views yet — publish and share your site to get started.</div>
                    )}
                </div>
            </div>
        </div>
    );
}
