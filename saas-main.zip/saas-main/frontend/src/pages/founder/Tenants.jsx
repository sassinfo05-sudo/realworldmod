import { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import api, { setImpersonationToken } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Search, LogIn, Pause, Play } from "lucide-react";

export function TenantList() {
    const [tenants, setTenants] = useState([]);
    const [q, setQ] = useState("");
    const [plan, setPlan] = useState("");
    const [loading, setLoading] = useState(true);
    const [impersonateTarget, setImpersonateTarget] = useState(null);
    const [reason, setReason] = useState("");
    const [busy, setBusy] = useState(false);
    const navigate = useNavigate();

    async function load() {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (q) params.append("q", q);
            if (plan) params.append("plan", plan);
            const { data } = await api.get(`/founder/tenants${params.toString() ? "?" + params.toString() : ""}`);
            setTenants(data.tenants || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); }, [plan]);

    async function impersonate() {
        if (!reason || reason.length < 6) { toast.error("Reason required (min 6 chars)"); return; }
        setBusy(true);
        try {
            const { data } = await api.post("/founder/impersonate/start", { target_org_id: impersonateTarget.id, reason });
            if (data.impersonation_token) {
                setImpersonationToken(data.impersonation_token);
                try { sessionStorage.setItem("zv.impersonation_org_name", impersonateTarget.name); } catch (e) { /* noop */ }
            }
            toast.success(`Now acting as ${impersonateTarget.name} — every action is audited`);
            setImpersonateTarget(null); setReason("");
            // Redirect the founder to the tenant dashboard root — from here every tenant
            // call auto-uses the impersonation token.
            navigate("/app");
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); }
        finally { setBusy(false); }
    }

    async function toggleSuspend(t) {
        const suspend = !t.suspended;
        const r = window.prompt(suspend ? "Reason for suspending?" : "Note (optional)", "");
        try {
            await api.post(`/founder/tenants/${t.id}/suspend`, { suspend, reason: r });
            toast.success(suspend ? "Suspended" : "Unsuspended");
            load();
        } catch (e) { toast.error("Failed"); }
    }

    return (
        <div className="p-6 max-w-7xl" data-testid="founder-tenants-page">
            <div className="mb-4 flex gap-2 flex-wrap items-center">
                <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-zinc-400" />
                    <Input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} placeholder="Search by name…" className="pl-8 w-64" data-testid="tenants-search" />
                </div>
                <select value={plan} onChange={(e) => setPlan(e.target.value)} className="border border-brand-line rounded px-2 py-1.5 text-sm bg-white" data-testid="tenants-plan-filter">
                    <option value="">All plans</option>
                    {["free", "launch", "revenue", "autopilot", "scale"].map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
                <Button variant="ghost" onClick={load}>Refresh</Button>
                <div className="ml-auto text-xs text-zinc-500 font-mono">{tenants.length} tenants</div>
            </div>

            <div className="border border-brand-line rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Tenant</TableHead>
                        <TableHead>Plan</TableHead>
                        <TableHead>Activation</TableHead>
                        <TableHead>Usage</TableHead>
                        <TableHead>MRR</TableHead>
                        <TableHead>Cost/mo</TableHead>
                        <TableHead>Health</TableHead>
                        <TableHead></TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {tenants.map((t) => (
                            <TableRow key={t.id} data-testid={`tenant-row-${t.id}`}>
                                <TableCell>
                                    <div className="text-sm font-medium text-brand-ink flex items-center gap-2">
                                        {t.name}
                                        {t.suspended && <Badge variant="destructive" className="text-[9px]">Suspended</Badge>}
                                    </div>
                                    <div className="text-xs text-zinc-500 font-mono truncate max-w-[220px]">{t.slug}</div>
                                </TableCell>
                                <TableCell>
                                    <Badge variant="outline" className="capitalize">{t.plan}</Badge>
                                    <div className="text-[10px] text-zinc-400 mt-0.5">{t.sub_status}</div>
                                </TableCell>
                                <TableCell className="text-xs">
                                    <div className={t.activation.published ? "text-emerald-700" : "text-zinc-500"}>
                                        {t.activation.published ? "✓ Published" : t.activation.has_site ? "○ Draft" : "○ No site"}
                                    </div>
                                    <div className={t.activation.ai_enabled ? "text-emerald-700" : "text-zinc-500"}>
                                        {t.activation.ai_enabled ? "✓ AI on" : "○ AI off"}
                                    </div>
                                </TableCell>
                                <TableCell className="text-xs font-mono">
                                    <div>{t.usage.ai_conversations} AI</div>
                                    <div>{t.usage.contacts} ctc</div>
                                </TableCell>
                                <TableCell className="font-mono text-sm">${t.mrr_usd}</TableCell>
                                <TableCell className="font-mono text-sm">${(t.cost_cents_this_month / 100).toFixed(2)}</TableCell>
                                <TableCell>
                                    <span className={`text-xs font-mono ${
                                        t.health_score >= 80 ? "text-emerald-600" :
                                        t.health_score >= 50 ? "text-amber-600" : "text-red-600"
                                    }`}>{t.health_score}</span>
                                    {t.health_factors.length > 0 && (
                                        <div className="text-[10px] text-zinc-400 truncate max-w-[140px]">{t.health_factors.join(", ")}</div>
                                    )}
                                </TableCell>
                                <TableCell className="whitespace-nowrap">
                                    <Button size="sm" variant="ghost" onClick={() => setImpersonateTarget(t)} data-testid={`tenant-${t.id}-impersonate`}>
                                        <LogIn className="w-3.5 h-3.5 mr-1" /> Enter
                                    </Button>
                                    <Button size="sm" variant="ghost" onClick={() => toggleSuspend(t)} data-testid={`tenant-${t.id}-suspend`}>
                                        {t.suspended ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                        {!loading && !tenants.length && (
                            <TableRow><TableCell colSpan={8} className="text-center py-10 text-zinc-500" data-testid="tenants-empty">No tenants match.</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={!!impersonateTarget} onOpenChange={(v) => !v && setImpersonateTarget(null)}>
                <DialogContent data-testid="impersonate-modal">
                    <DialogHeader><DialogTitle>Enter tenant: {impersonateTarget?.name}</DialogTitle></DialogHeader>
                    <div className="space-y-2">
                        <div className="text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded p-2">
                            Every action you take will be logged as an impersonation session, visible to auditors + the tenant. Session auto-exits in 30 min.
                        </div>
                        <Textarea placeholder="Why are you entering this org? (min 6 chars — e.g. 'debug booking flow ticket #123')"
                                     value={reason} onChange={(e) => setReason(e.target.value)}
                                     data-testid="impersonate-reason" />
                    </div>
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setImpersonateTarget(null)}>Cancel</Button>
                        <Button onClick={impersonate} disabled={busy || reason.length < 6} className="bg-amber-500 text-white hover:bg-amber-600" data-testid="impersonate-confirm-btn">Start session</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}

export function TenantDetail() {
    const { orgId } = useParams();
    const [data, setData] = useState(null);
    useEffect(() => {
        api.get(`/founder/tenants/${orgId}`).then((r) => setData(r.data));
    }, [orgId]);
    if (!data) return <div className="p-6 text-zinc-500">Loading…</div>;
    return (
        <div className="p-6 max-w-4xl space-y-4" data-testid="tenant-detail">
            <div>
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">Tenant</div>
                <h1 className="mt-1 font-display text-2xl text-brand-ink">{data.org.name}</h1>
                <div className="text-xs text-zinc-500 font-mono">{data.org.slug} · {data.org.id}</div>
            </div>
            <div className="grid md:grid-cols-2 gap-3">
                <div className="rounded-lg border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Subscription</div>
                    <div className="text-sm">Plan <span className="font-mono">{data.subscription?.plan_code || "free"}</span></div>
                    <div className="text-xs text-zinc-500">Status: {data.subscription?.status}</div>
                </div>
                <div className="rounded-lg border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Site</div>
                    <div className="text-sm">Slug <span className="font-mono">{data.website?.slug || "—"}</span></div>
                    <div className="text-xs text-zinc-500">Status: {data.website?.status || "no site"}</div>
                </div>
                <div className="rounded-lg border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Business profile</div>
                    <div className="text-sm">{data.business_profile?.business_name || "—"}</div>
                    <div className="text-xs text-zinc-500">{data.business_profile?.industry}</div>
                </div>
                <div className="rounded-lg border border-brand-line bg-white p-4">
                    <div className="text-xs uppercase tracking-widest text-zinc-500 mb-1">Usage this month</div>
                    <div className="text-xs font-mono">{JSON.stringify(data.usage)}</div>
                </div>
            </div>
            <div>
                <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Users</div>
                <div className="border border-brand-line rounded-lg bg-white overflow-hidden divide-y">
                    {data.users.map((u) => (
                        <div key={u.id} className="p-2 flex items-center gap-2 text-sm">
                            <div className="flex-1">{u.full_name || u.email}</div>
                            <div className="text-xs font-mono text-zinc-500">{u.email}</div>
                            <Badge variant="outline" className="text-[10px]">{u.role}</Badge>
                        </div>
                    ))}
                </div>
            </div>
            <Link to="/staff/tenants" className="inline-block text-xs text-brand-copper hover:underline" data-testid="tenant-detail-back">← Back to tenants</Link>
        </div>
    );
}
