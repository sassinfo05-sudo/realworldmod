import { useEffect, useState } from "react";
import api from "@/lib/api";

/** Public "Blog — latest articles" section. Reads the tenant's published posts by website slug. */
export default function BlogListBlock({ block, theme }) {
    const props = block.props || {};
    const { title = "Latest articles", subtitle = "", limit = 3 } = props;
    const slug = props.website_slug || (typeof window !== "undefined" && window.location.pathname.startsWith("/site/")
        ? window.location.pathname.split("/")[2] : null);
    const [posts, setPosts] = useState(null);

    useEffect(() => {
        if (!slug) { setPosts([]); return; }
        api.get(`/public/sites/${slug}/blog`, { params: { limit } }).then(({ data }) => setPosts(data.posts || [])).catch(() => setPosts([]));
    }, [slug, limit]);

    if (posts && posts.length === 0) {
        // In the editor (no slug / no posts) show an honest placeholder; on the live site render nothing.
        if (typeof window !== "undefined" && window.location.pathname.startsWith("/site/")) return null;
        return (
            <section className="py-14 px-6" data-block-type="blog_list">
                <div className="max-w-5xl mx-auto text-center text-sm opacity-70">Your latest published articles will appear here. Write one under Website → Blog.</div>
            </section>
        );
    }
    return (
        <section className="py-16 px-6" data-block-type="blog_list" style={{ background: "var(--tenant-background)" }}>
            <div className="max-w-6xl mx-auto">
                <div className="text-center mb-10">
                    <h2 data-heading className="text-3xl md:text-4xl font-semibold">{title}</h2>
                    {subtitle && <p className="mt-2 opacity-75">{subtitle}</p>}
                </div>
                <div className="grid md:grid-cols-3 gap-6">
                    {(posts || []).map((p) => (
                        <a key={p.slug} href={`/site/${slug}/blog/${p.slug}`} className="rounded-2xl overflow-hidden border hover:shadow-lg transition-shadow block"
                            style={{ borderColor: "var(--tenant-surface)", background: "var(--tenant-surface)" }} data-testid={`blog-card-${p.slug}`}>
                            {p.cover_image && <img src={p.cover_image} alt="" className="w-full h-40 object-cover" loading="lazy" />}
                            <div className="p-5">
                                {p.published_at && <div className="text-xs opacity-60">{new Date(p.published_at).toLocaleDateString()}</div>}
                                <div data-heading className="mt-1 font-semibold text-lg">{p.title}</div>
                                {p.excerpt && <p className="mt-2 text-sm opacity-75 line-clamp-3">{p.excerpt}</p>}
                                <div className="mt-3 text-sm font-medium" style={{ color: "var(--tenant-primary)" }}>Read more →</div>
                            </div>
                        </a>
                    ))}
                </div>
                {slug && (
                    <div className="text-center mt-8">
                        <a href={`/site/${slug}/blog`} className="text-sm font-medium underline-offset-4 hover:underline" style={{ color: "var(--tenant-primary)" }}>All articles</a>
                    </div>
                )}
            </div>
        </section>
    );
}
