"""Idempotent seed: brand, plans, platform founder + demo owner + org.

Passwords are generated fresh once, written to /app/memory/test_credentials.md.
On restart, if creds file already contains a password for that email, we reuse
its hash (so tests keep working across restarts) — otherwise we rotate.
"""
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path


from .. import config
from ..db import get_db
from ..security import generate_readable_password, hash_password

logger = logging.getLogger(__name__)

CREDS_PATH = Path("/app/memory/test_credentials.md")


def _read_existing_creds() -> dict:
    """Parse existing credentials file to reuse passwords across restarts."""
    out = {}
    if not CREDS_PATH.exists():
        return out
    text = CREDS_PATH.read_text()
    # simple parser: lines like "- **founder@zanelvo.com** — `PASSWORD`  (role: platform_founder)"
    for line in text.splitlines():
        m = re.search(r"\*\*([^*]+)\*\*\s*—\s*`([^`]+)`", line)
        if m:
            out[m.group(1).strip()] = m.group(2).strip()
    return out


def _write_creds(founder_email: str, founder_pw: str, owner_email: str, owner_pw: str) -> None:
    CREDS_PATH.parent.mkdir(parents=True, exist_ok=True)
    content = f"""# Test Credentials — Zanelvo

Generated: {datetime.now(timezone.utc).isoformat()}

Auth type: **JWT bearer** — POST `/api/auth/login` with `{{"email","password"}}` returns `{{"access_token": "..."}}`. Send header `Authorization: Bearer <token>`.

## Accounts

- **{founder_email}** — `{founder_pw}`  (role: platform_founder, no org)
- **{owner_email}** — `{owner_pw}`  (role: owner, org: Demo Home Services)

## Quick login curl

```bash
curl -X POST "$REACT_APP_BACKEND_URL/api/auth/login" \\
  -H "Content-Type: application/json" \\
  -d '{{"email":"{owner_email}","password":"{owner_pw}"}}'
```

## Notes

- Password reset flow: request via `POST /api/auth/password-reset/request` (token is emailed via the configured platform sender; returned inline only in development).
- Two-org isolation testing: create a second owner via `/api/auth/signup` and verify no cross-org reads.
"""
    CREDS_PATH.write_text(content)


async def seed_all() -> None:
    db = get_db()

    # --- brand --- (upsert on every restart in Phase 1; founder-editable arrives with the founder panel later)
    await db.brand_config.update_one(
        {"key": "primary"},
        {"$set": {**config.BRAND_DEFAULT, "updated_at": datetime.now(timezone.utc).isoformat()},
         "$setOnInsert": {"created_at": datetime.now(timezone.utc).isoformat(), "key": "primary"}},
        upsert=True,
    )
    logger.info("Upserted brand config for %s", config.BRAND_DEFAULT["name"])

    # --- plans ---
    # Founder edits (Staff panel → Plans) persist across restarts; the seed only
    # overwrites a plan when PLANS_SEED_VERSION is bumped or the plan is new.
    for plan in config.PLANS_SEED:
        existing = await db.plans.find_one({"code": plan["code"]}, {"seed_version": 1})
        if existing and existing.get("seed_version") == config.PLANS_SEED_VERSION:
            continue
        await db.plans.update_one(
            {"code": plan["code"]},
            {"$set": {**plan, "seed_version": config.PLANS_SEED_VERSION,
                      "updated_at": datetime.now(timezone.utc).isoformat()},
             "$setOnInsert": {"created_at": datetime.now(timezone.utc).isoformat()}},
            upsert=True,
        )
    logger.info("Seeded %d plans", len(config.PLANS_SEED))

    # --- accounts (idempotent w/ password persistence via creds file) ---
    # Production safety: demo org/owner + file-written credentials require an EXPLICIT opt-in flag
    # AND a non-production environment. Never enabled implicitly by APP_ENV alone. In production the
    # founder is created ONLY by the explicit `python -m scripts.bootstrap_founder` command.
    _flag = os.environ.get("SEED_DEMO_DATA", os.environ.get("SEED_DEMO", "")).lower() in ("1", "true", "yes")
    seed_demo = _flag and config.simulation_allowed()
    founder_email = config.FOUNDER_EMAIL
    if not seed_demo:
        # Production / non-seeded environments: the founder is created ONLY by the explicit one-time
        # command `python -m scripts.bootstrap_founder` (invite-link based). Startup never creates
        # accounts or reads bootstrap passwords from the environment.
        if not await db.users.find_one({"email": founder_email}):
            logger.warning("No founder account exists for %s — run `python -m scripts.bootstrap_founder` once.",
                           founder_email)
        return

    existing_creds = _read_existing_creds()
    owner_email = config.DEMO_OWNER_EMAIL

    founder_pw = existing_creds.get(founder_email) or generate_readable_password(18)
    owner_pw = existing_creds.get(owner_email) or generate_readable_password(16)

    # Demo org
    demo_org = await db.organizations.find_one({"slug": "demo-home-services"})
    if not demo_org:
        res = await db.organizations.insert_one({
            "slug": "demo-home-services",
            "name": "Demo Home Services",
            "industry": "home_services",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        demo_org_id = str(res.inserted_id)
    else:
        demo_org_id = str(demo_org["_id"])

    # Founder (no org)
    existing_founder = await db.users.find_one({"email": founder_email})
    if not existing_founder:
        await db.users.insert_one({
            "email": founder_email,
            "password_hash": hash_password(founder_pw),
            "full_name": "Zanelvo Founder",
            "org_id": None,
            "role": "platform_founder",
            "email_verified": True,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
    elif founder_email not in existing_creds:
        # rotate to match freshly generated password
        await db.users.update_one(
            {"email": founder_email},
            {"$set": {"password_hash": hash_password(founder_pw)}},
        )

    # Demo owner (attached to demo org)
    existing_owner = await db.users.find_one({"email": owner_email})
    if not existing_owner:
        await db.users.insert_one({
            "email": owner_email,
            "password_hash": hash_password(owner_pw),
            "full_name": "Demo Owner",
            "org_id": demo_org_id,
            "role": "owner",
            "email_verified": True,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
    elif owner_email not in existing_creds:
        await db.users.update_one(
            {"email": owner_email},
            {"$set": {"password_hash": hash_password(owner_pw)}},
        )

    _write_creds(founder_email, founder_pw, owner_email, owner_pw)
    logger.info("Seeded platform founder + demo owner (see /app/memory/test_credentials.md)")
