"""Deterministic stored-XSS regression tests for the server-side sanitizers.

No network / LLM. Proves the strict allowlist sanitizers strip active content from
tenant-authored SVG (logos) and HTML (legal / about copy) before it is ever stored.

Run: cd /app/backend && python -m pytest tests/test_xss_sanitizer.py -q
 or: cd /app/backend && python tests/test_xss_sanitizer.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.services.svg_safe import sanitize_svg, sanitize_html  # noqa: E402

SVG_PAYLOADS = [
    '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script><rect/></svg>',
    '<svg onload="alert(1)"><rect width="10" height="10"/></svg>',
    '<svg><image href="javascript:alert(1)"/></svg>',
    '<svg><a xlink:href="javascript:alert(1)"><text>x</text></a></svg>',
    '<svg><foreignObject><body xmlns="http://www.w3.org/1999/xhtml"><script>alert(1)</script></body></foreignObject></svg>',
    '<svg><rect onclick="alert(1)" fill="red"/></svg>',
]

HTML_PAYLOADS = [
    '<p>hello</p><script>alert(1)</script>',
    '<img src=x onerror=alert(1)>',
    '<a href="javascript:alert(1)">click</a>',
    '<div onmouseover="alert(1)">x</div>',
    '<iframe src="https://evil.example"></iframe>',
    '<style>body{background:url(javascript:alert(1))}</style>',
]

BAD_TOKENS = ["<script", "javascript:", "onerror", "onload", "onclick", "onmouseover", "<iframe", "<foreignobject"]


def _assert_clean(out: str, label: str):
    low = (out or "").lower()
    for tok in BAD_TOKENS:
        assert tok not in low, f"{label}: dangerous token '{tok}' survived -> {out!r}"


def test_svg_sanitizer_strips_active_content():
    for p in SVG_PAYLOADS:
        out = sanitize_svg(p)
        _assert_clean(out, "SVG")
    print(f"[SVG]  {len(SVG_PAYLOADS)} payloads neutralized")


def test_html_sanitizer_strips_active_content():
    for p in HTML_PAYLOADS:
        out = sanitize_html(p)
        _assert_clean(out, "HTML")
    print(f"[HTML] {len(HTML_PAYLOADS)} payloads neutralized")


def test_sanitizer_preserves_safe_markup():
    assert "rect" in sanitize_svg('<svg xmlns="http://www.w3.org/2000/svg"><rect width="10" height="10"/></svg>').lower()
    out = sanitize_html("<p>Hello <strong>world</strong></p>")
    assert "hello" in out.lower() and "strong" in out.lower()
    print("[SAFE] benign SVG/HTML preserved")


if __name__ == "__main__":
    test_svg_sanitizer_strips_active_content()
    test_html_sanitizer_strips_active_content()
    test_sanitizer_preserves_safe_markup()
    print("ALL XSS SANITIZER ASSERTIONS PASSED")
