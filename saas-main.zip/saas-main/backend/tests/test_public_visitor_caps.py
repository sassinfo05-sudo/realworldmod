"""Round 15 — public visitor anti-exhaustion caps: per-session, per-IP and tenant public ceiling.
Free plan AI cap = $0.10 → session cap $0.01 (floor), IP cap $0.02 (floor), tenant public/day $0.04.
A single visitor session must be blocked long before the tenant's monthly AI cap is reached."""
from __future__ import annotations

import asyncio
import uuid

import pytest
from fastapi import HTTPException


def test_visitor_caps_layered():
    import app.db as _appdb
    _appdb._mongo_client = None
    from app.db import get_db
    from app.services import usage

    org = f"org-vcap-{uuid.uuid4().hex[:8]}"

    async def run():
        db = get_db()
        await db.subscriptions.insert_one({"org_id": org, "plan_code": "free", "status": "active"})
        try:
            usage.set_context(org_id=org, feature="public_chat", public=True, visitor_ip="203.0.113.9", visitor_session="sess-A")
            # fresh visitor passes
            await usage.enforce_budget(org, feature="public_chat", public=True)
            # simulate $0.012 spent by session A from IP .9 today (over the $0.01 session floor)
            from app.db import utc_now_iso
            def _row(sess, ip):
                return {"id": uuid.uuid4().hex, "kind": "text", "feature": "public_chat", "org_id": org,
                        "public": True, "visitor_ip": ip, "visitor_session": sess, "cost_usd": 0.012,
                        "month": usage._month_key(), "created_at": utc_now_iso()}
            await db[usage.LEDGER].insert_one(_row("sess-A", "203.0.113.9"))
            with pytest.raises(HTTPException) as ei:
                await usage.enforce_budget(org, feature="public_chat", public=True)
            assert ei.value.detail.get("error") in ("public_session_cap_reached", "public_ip_cap_reached"), ei.value.detail
            # a DIFFERENT session from the same IP: session cap fine, IP cap ($0.02) still has room
            usage.set_context(visitor_session="sess-B")
            await usage.enforce_budget(org, feature="public_chat", public=True)
            # push the IP over $0.02
            await db[usage.LEDGER].insert_one(_row("sess-B", "203.0.113.9"))
            usage.set_context(visitor_session="sess-C")
            with pytest.raises(HTTPException) as ei2:
                await usage.enforce_budget(org, feature="public_chat", public=True)
            assert ei2.value.detail.get("error") == "public_ip_cap_reached", ei2.value.detail
            # a different IP still works — the TENANT's $0.10 monthly cap was never the thing that stopped us
            usage.set_context(visitor_ip="198.51.100.7", visitor_session="sess-D")
            await usage.enforce_budget(org, feature="public_chat", public=True)
            # ordinary (non-public) owner AI is unaffected by visitor caps at this spend level
            usage.set_context(public=False)
            await usage.enforce_budget(org, feature="editor", public=False)
        finally:
            await db.subscriptions.delete_many({"org_id": org})
            await db[usage.LEDGER].delete_many({"org_id": org})

    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(run())
    finally:
        loop.close()


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
