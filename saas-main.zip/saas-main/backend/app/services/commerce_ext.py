"""Commerce depth helpers (Round 10, Gate 4): stock reservations, tax rates, order status history,
variant option matrices. Pure Mongo helpers used by routes/store.py and routes/commerce_ext.py.
"""
from __future__ import annotations

import itertools
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from ..db import utc_now_iso

RESERVATION_TTL_MIN = 30


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------- stock reservations ----------------

async def expire_reservations(db, org_id: Optional[str] = None) -> int:
    q: Dict[str, Any] = {"status": "active", "expires_at": {"$lte": utc_now_iso()}}
    if org_id:
        q["org_id"] = org_id
    r = await db.stock_reservations.update_many(q, {"$set": {"status": "expired", "updated_at": utc_now_iso()}})
    return int(r.modified_count or 0)


async def reserved_qty(db, org_id: str, product_id: str) -> int:
    await expire_reservations(db, org_id)
    total = 0
    async for r in db.stock_reservations.find({"org_id": org_id, "product_id": product_id, "status": "active"},
                                              {"qty": 1}):
        total += int(r.get("qty", 0))
    return total


async def available_stock(db, product: Dict[str, Any]) -> int:
    if not product.get("track_inventory", True):
        return 10 ** 9
    held = await reserved_qty(db, product["org_id"], product["_id"])
    return max(0, int(product.get("stock", 0)) - held)


async def reserve_stock(db, org_id: str, product_id: str, qty: int, order_id: str,
                        ttl_min: int = RESERVATION_TTL_MIN) -> Dict[str, Any]:
    doc = {"_id": uuid.uuid4().hex, "org_id": org_id, "product_id": product_id, "qty": int(qty),
           "order_id": order_id, "status": "active",
           "expires_at": (_now() + timedelta(minutes=ttl_min)).isoformat(),
           "created_at": utc_now_iso(), "updated_at": utc_now_iso()}
    await db.stock_reservations.insert_one(doc)
    return doc


async def settle_reservation(db, order_id: str, status: str) -> None:
    """status: consumed (paid) | released (cancelled/expired checkout)."""
    await db.stock_reservations.update_many({"order_id": order_id, "status": "active"},
                                            {"$set": {"status": status, "updated_at": utc_now_iso()}})


# ---------------- tax ----------------

async def tax_rates(db, org_id: str) -> List[Dict[str, Any]]:
    doc = await db.store_tax_settings.find_one({"org_id": org_id}) or {}
    return list(doc.get("rates") or [])


async def compute_tax(db, org_id: str, country: str, region: str, taxable_cents: int) -> Dict[str, Any]:
    """Pick the most specific matching rate (country+region > country > '*'). Returns tax breakdown.
    `inclusive` rates mean prices already include tax → tax_cents is informational (not added)."""
    rates = await tax_rates(db, org_id)
    country = (country or "").upper()
    region = (region or "").upper()
    best = None
    for r in rates:
        c = (r.get("country") or "*").upper()
        rg = (r.get("region") or "").upper()
        if c not in ("*", country):
            continue
        if rg and rg != region:
            continue
        score = (2 if c == country else 0) + (1 if rg else 0)
        if best is None or score > best[0]:
            best = (score, r)
    if not best:
        return {"tax_cents": 0, "rate_pct": 0.0, "inclusive": False, "label": "", "applied": False}
    r = best[1]
    pct = float(r.get("pct") or 0)
    inclusive = bool(r.get("inclusive"))
    if inclusive:
        tax = round(taxable_cents - taxable_cents / (1 + pct / 100))
    else:
        tax = round(taxable_cents * pct / 100)
    return {"tax_cents": int(tax), "rate_pct": pct, "inclusive": inclusive, "label": r.get("label") or "Tax",
            "applied": True}


# ---------------- order status history / notes ----------------

async def push_status(db, order_id: str, status: str, actor: str = "system", note: str = "") -> None:
    await db.store_orders.update_one({"_id": order_id}, {"$push": {"status_history": {
        "status": status, "at": utc_now_iso(), "actor": actor, "note": note}}})


# ---------------- variant option matrix ----------------

def variant_matrix(options: List[Dict[str, Any]], base_price_cents: int = 0, base_stock: int = 0,
                   sku_prefix: str = "") -> List[Dict[str, Any]]:
    """options: [{name:'Size', values:['S','M']}, {name:'Colour', values:['Red']}] →
    [{name:'S / Red', options:{Size:'S', Colour:'Red'}, price_cents, stock, sku, barcode:''}, …] (max 100)."""
    clean = [(str(o.get("name", "")).strip(), [str(v).strip() for v in (o.get("values") or []) if str(v).strip()])
             for o in (options or []) if str(o.get("name", "")).strip()]
    clean = [(n, vs) for n, vs in clean if vs]
    if not clean:
        return []
    out = []
    for combo in itertools.product(*[vs for _, vs in clean]):
        if len(out) >= 100:
            break
        opts = {clean[i][0]: combo[i] for i in range(len(combo))}
        label = " / ".join(combo)
        sku = (sku_prefix + "-" if sku_prefix else "") + "-".join(c.upper().replace(" ", "")[:6] for c in combo)
        out.append({"name": label, "options": opts, "price_cents": int(base_price_cents), "stock": int(base_stock),
                    "sku": sku, "barcode": ""})
    return out
