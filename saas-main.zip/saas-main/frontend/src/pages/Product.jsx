import usePageMeta from "@/hooks/usePageMeta";
import PublicNav from "@/components/PublicNav";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useBrand } from "@/context/BrandContext";

const SECTIONS = [
    {
        eyebrow: "01 — The interview",
        title: "A ninety-second conversation, not a form",
        body: "We ask about your services, prices, service area, hours, what makes you different, and the tone you want. Free-text where free-text belongs. Structured where it matters.",
    },
    {
        eyebrow: "02 — The generation",
        title: "A tailored multi-page site, grounded in your facts",
        body: "Our AI writes original copy for a Home, Services, About and Contact page — with your actual services and prices sewn in. Two different businesses generate visibly different sites.",
    },
    {
        eyebrow: "03 — The review",
        title: "Every fact is yours to fix",
        body: "Prices, hours, differentiators — everything sits in a clean review screen. Edits get an owner-verified stamp so we know what's trusted.",
    },
    {
        eyebrow: "04 — The workspace",
        title: "CRM, inbox, booking, payments — already wired",
        body: "The sidebar already shows what's coming. No dead buttons. When you're ready to turn a module on, it flows into the same data your site already knows.",
    },
];

export default function Product() {
    usePageMeta("Product");
    const brand = useBrand();
    const name = brand?.name || "Our platform";
    return (
        <div className="min-h-screen bg-brand-surface">
            <PublicNav />
            <section className="py-20 md:py-28">
                <div className="mx-auto max-w-4xl px-6">
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">Product</div>
                    <h1 className="font-display text-4xl md:text-5xl text-brand-ink font-medium leading-tight max-w-3xl">
                        What {name} actually does — end to end.
                    </h1>
                    <p className="mt-5 text-zinc-600 max-w-2xl">
                        The operating system for service &amp; online businesses: AI website builder + hosting, CRM,
                        inbox, calendar, quotes/invoices/payments, AI employees, and a marketing studio — all wired to the same data.
                    </p>

                    <div className="mt-14 space-y-14" data-testid="product-sections">
                        {SECTIONS.map((s) => (
                            <div key={s.eyebrow} className="border-l-2 border-brand-copper pl-6">
                                <div className="text-xs uppercase tracking-[0.24em] text-zinc-500 mb-2">
                                    {s.eyebrow}
                                </div>
                                <h2 className="font-display text-2xl md:text-3xl text-brand-ink">{s.title}</h2>
                                <p className="mt-3 text-zinc-600 leading-relaxed">{s.body}</p>
                            </div>
                        ))}
                    </div>

                    <div className="mt-16">
                        <Link to="/signup" data-testid="product-cta-btn">
                            <Button size="lg" className="bg-brand-copper hover:bg-brand-copperHover text-white">
                                Build my website <ArrowRight className="ml-2 w-4 h-4" />
                            </Button>
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
}
