"""Phase 2 fix verification (iteration 3):
- Demo hero image healthy after seed migration
- OpenAPI still exposed
- Tenant isolation unchanged after EditorProvider refactor
- Publish / rollback regression
- Domain provider list still returns both providers with honest cloudflare status
- Form submission on demo-home-services still 200
- Public payload behavior for hidden blocks
"""

import os
import uuid
import requests
import pytest

import _creds

BASE = _creds.base_url()


@pytest.fixture(scope="module")
def owner_token():
    r = requests.post(f"{BASE}/api/auth/login", json={
        "email": _creds.OWNER_EMAIL,
        "password": _creds.OWNER_PASSWORD,
    }, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def owner_headers(owner_token):
    return {"Authorization": f"Bearer {owner_token}"}


@pytest.fixture(scope="module")
def fresh_owner():
    email = f"iso_{uuid.uuid4().hex[:10]}@example.com"
    password = "TestPass!23"
    r = requests.post(f"{BASE}/api/auth/signup", json={
        "email": email, "password": password, "business_name": "Iso Test",
    }, timeout=20)
    assert r.status_code in (200, 201), r.text
    tok = r.json().get("access_token")
    if not tok:
        r2 = requests.post(f"{BASE}/api/auth/login", json={"email": email, "password": password}, timeout=15)
        tok = r2.json()["access_token"]
    return {"email": email, "token": tok, "headers": {"Authorization": f"Bearer {tok}"}}


# --- demo hero image ---
def test_demo_hero_image_healthy():
    r = requests.get(f"{BASE}/api/public/sites/demo-home-services", timeout=15)
    assert r.status_code == 200
    home = next(p for p in r.json()["pages"] if p["slug"] == "home")
    hero = next(b for b in home["blocks"] if b["type"] == "hero")
    img = hero["props"].get("image")
    assert img, "hero has no image"
    resp = requests.get(img, timeout=15, allow_redirects=True)
    assert resp.status_code == 200, f"hero image {img} returned {resp.status_code}"


# --- openapi ---
def test_openapi_exposed():
    r = requests.get(f"{BASE}/api/openapi.json", timeout=10)
    assert r.status_code == 200
    spec = r.json()
    paths = spec.get("paths", {})
    # at least a couple of known editor endpoints
    assert any("/editor/website" in p for p in paths), "editor endpoints missing from openapi"


# --- tenant isolation ---
def test_tenant_isolation_fresh_user_gets_different_website(owner_headers, fresh_owner):
    r_owner = requests.get(f"{BASE}/api/editor/website", headers=owner_headers, timeout=15)
    r_fresh = requests.get(f"{BASE}/api/editor/website", headers=fresh_owner["headers"], timeout=15)
    # fresh user may not yet have a website (returns 404 or empty)
    if r_fresh.status_code == 404:
        pytest.skip("fresh org has no website (expected for pre-onboarding)")
    assert r_fresh.status_code == 200
    demo_site = r_owner.json()["website"]
    fresh_site = r_fresh.json()["website"]
    assert demo_site["id"] != fresh_site["id"], "fresh user got demo site!"


def test_tenant_isolation_cannot_patch_demo_block(owner_headers, fresh_owner):
    r = requests.get(f"{BASE}/api/editor/website", headers=owner_headers, timeout=15)
    home = next(p for p in r.json()["website"]["pages"] if p["slug"] == "home")
    demo_block_id = home["blocks"][0]["id"]
    r2 = requests.patch(
        f"{BASE}/api/editor/website/blocks/{demo_block_id}",
        headers=fresh_owner["headers"],
        json={"props": {"headline": "HACKED"}},
        timeout=15,
    )
    assert r2.status_code == 404, f"expected 404 got {r2.status_code}: {r2.text}"


# --- publish / rollback regression ---
def test_publish_and_rollback_flow(owner_headers):
    # Publish
    pub = requests.post(f"{BASE}/api/editor/website/publish", headers=owner_headers, json={"note": "iter3 test"}, timeout=20)
    assert pub.status_code == 200, pub.text
    rev_id = pub.json().get("revision_id") or pub.json().get("id")
    assert rev_id

    revs = requests.get(f"{BASE}/api/editor/website/revisions", headers=owner_headers, timeout=15)
    assert revs.status_code == 200
    rev_list = revs.json().get("revisions") or revs.json()
    assert any(r.get("id") == rev_id for r in rev_list), "new revision not in list"

    # Rollback to earliest
    earliest = rev_list[-1]["id"]
    rb = requests.post(f"{BASE}/api/editor/website/revisions/{earliest}/rollback",
                       headers=owner_headers, json={"note": "iter3 rollback"}, timeout=20)
    assert rb.status_code == 200, rb.text
    rb_body = rb.json()
    # revised list should have a new entry with rolled_back_from_id
    revs2 = requests.get(f"{BASE}/api/editor/website/revisions", headers=owner_headers, timeout=15).json()
    revs2_list = revs2.get("revisions") or revs2
    has_rollback = any(r.get("rolled_back_from_id") == earliest for r in revs2_list)
    assert has_rollback, "no revision with rolled_back_from_id set"


# --- domain providers ---
def test_domain_providers_list(owner_headers):
    r = requests.get(f"{BASE}/api/domains/providers", headers=owner_headers, timeout=10)
    assert r.status_code == 200
    providers = r.json().get("providers", r.json())
    keys = [p.get("key") or p.get("id") or p.get("name") for p in providers]
    assert len(providers) >= 2, f"expected >=2 providers, got {keys}"
    cloudflare = next((p for p in providers if (p.get("key") or p.get("name","")).lower().startswith("cloudflare")), None)
    assert cloudflare, "cloudflare provider missing"
    assert cloudflare.get("is_connected") in (False, None), "cloudflare should be not connected"
    honest = cloudflare.get("honest_status") or cloudflare.get("status_message") or cloudflare.get("status", "")
    assert "not connected" in str(honest).lower() or "cloudflare_api_token" in str(honest).lower(), \
        f"honest_status should say 'Not connected': {honest!r}"


# --- form submission on demo-home-services ---
def test_public_form_submission():
    r = requests.post(f"{BASE}/api/forms/submit",
                      json={"website_slug": "demo-home-services", "page_slug": "contact",
                            "fields": {"name": "Test", "email": "t@example.com", "message": "hi"}},
                      timeout=15)
    assert r.status_code in (200, 201), f"form submit failed: {r.status_code} {r.text[:200]}"
