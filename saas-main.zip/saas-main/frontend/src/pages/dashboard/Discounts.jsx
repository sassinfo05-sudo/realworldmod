import React, { useEffect, useState, useCallback } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Tag, Plus, Trash2, Layers, Percent, DollarSign, Ticket, Gift } from "lucide-react";

const card = "rounded-2xl border border-brand-line bg-white p-5 shadow-sm";
const input = "w-full border border-brand-line rounded-lg px-3 py-2 text-sm";

export default function Discounts() {
    const [tab, setTab] = useState("discounts");
    return (
        <div className="max-w-4xl mx-auto p-6 space-y-6">
            <div>
                <h1 className="font-display text-2xl text-brand-ink flex items-center gap-2"><Ticket className="w-6 h-6 text-brand-copper" /> Discounts, gift cards & collections</h1>
                <p className="text-brand-ink/60 mt-1 text-sm">Run promotions and group products to boost your average order value.</p>
            </div>
            <div className="flex gap-1 border-b border-brand-line">
                {[["discounts", "Discount codes", Percent], ["gift", "Gift cards", Gift], ["collections", "Collections", Layers]].map(([id, label, Icon]) => (
                    <button key={id} onClick={() => setTab(id)} className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px ${tab === id ? "border-brand-copper text-brand-copper" : "border-transparent text-zinc-500 hover:text-brand-ink"}`}>
                        <Icon className="w-4 h-4" /> {label}
                    </button>
                ))}
            </div>
            {tab === "discounts" ? <DiscountsTab /> : tab === "gift" ? <GiftCardsTab /> : <CollectionsTab />}
        </div>
    );
}

function DiscountsTab() {
    const [items, setItems] = useState([]);
    const [form, setForm] = useState({ code: "", type: "percent", value: 10, min_subtotal_cents: 0, active: true, auto: false, title: "", eligible_groups: "" });
    const [busy, setBusy] = useState(false);
    const load = useCallback(async () => { const { data } = await api.get("/store/discounts"); setItems(data.discounts || []); }, []);
    useEffect(() => { load(); }, [load]);
    const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
    const create = async () => {
        if (!form.code.trim()) return toast.error("Code required");
        setBusy(true);
        try { await api.post("/store/discounts", { ...form, value: Number(form.value), min_subtotal_cents: Math.round(Number(form.min_subtotal_cents) * 100), eligible_groups: form.eligible_groups.split(",").map((s) => s.trim()).filter(Boolean) }); toast.success("Discount created"); setForm({ code: "", type: "percent", value: 10, min_subtotal_cents: 0, active: true, auto: false, title: "", eligible_groups: "" }); load(); }
        catch (e) { toast.error(e?.response?.data?.detail || "Failed"); } finally { setBusy(false); }
    };
    const del = async (id) => { if (!window.confirm("Delete this code?")) return; await api.delete(`/store/discounts/${id}`); load(); };
    return (
        <div className="grid md:grid-cols-[320px_1fr] gap-5">
            <div className={card}>
                <div className="font-medium text-brand-ink mb-3 flex items-center gap-2"><Plus className="w-4 h-4" /> New code</div>
                <input className={input} placeholder="SUMMER20" value={form.code} onChange={(e) => set("code", e.target.value.toUpperCase())} />
                <div className="grid grid-cols-2 gap-2 mt-3">
                    <select className={input} value={form.type} onChange={(e) => set("type", e.target.value)}><option value="percent">% off</option><option value="fixed">$ off</option></select>
                    <input className={input} type="number" value={form.value} onChange={(e) => set("value", e.target.value)} placeholder={form.type === "percent" ? "10" : "5"} />
                </div>
                <label className="text-xs text-zinc-500 block mt-3">Minimum spend ($)</label>
                <input className={input} type="number" value={form.min_subtotal_cents} onChange={(e) => set("min_subtotal_cents", e.target.value)} />
                <label className="flex items-center gap-2 text-sm text-brand-ink mt-3 cursor-pointer" data-testid="discount-auto-toggle">
                    <input type="checkbox" checked={!!form.auto} onChange={(e) => set("auto", e.target.checked)} className="accent-brand-copper" />
                    Apply automatically at checkout (no code needed)
                </label>
                {form.auto && (
                    <input className={`${input} mt-2`} placeholder="Shopper-facing label, e.g. Spring sale — 10% off" value={form.title} onChange={(e) => set("title", e.target.value)} data-testid="discount-auto-title" />
                )}
                <p className="text-[11px] text-zinc-500 mt-2">Automatic rules never stack — the single largest saving is applied. Manual codes still work when typed.</p>
                <label className="text-xs text-zinc-500 block mt-3">Limit to customer groups (optional, comma-separated)</label>
                <input className={input} placeholder="vip, wholesale" value={form.eligible_groups} onChange={(e) => set("eligible_groups", e.target.value)} data-testid="discount-groups" />
                <p className="text-[11px] text-zinc-500 mt-1">Leave blank for everyone. Set a contact's group on their CRM profile.</p>
                <Button onClick={create} disabled={busy} className="mt-4 w-full bg-brand-copper hover:bg-brand-copperHover text-white">{busy ? "Creating…" : "Create code"}</Button>
            </div>
            <div className="space-y-2">
                {items.length === 0 && <div className={`${card} text-center text-sm text-zinc-400 py-10`}>No discount codes yet.</div>}
                {items.map((d) => (
                    <div key={d.id} className={`${card} flex items-center gap-4`}>
                        <div className="w-10 h-10 rounded-lg bg-brand-copper/10 text-brand-copper flex items-center justify-center">{d.type === "percent" ? <Percent className="w-5 h-5" /> : <DollarSign className="w-5 h-5" />}</div>
                        <div className="flex-1 min-w-0">
                            <div className="font-mono font-semibold text-brand-ink">{d.code}</div>
                            <div className="text-xs text-zinc-500">{d.type === "percent" ? `${d.value}% off` : `$${d.value} off`}{d.min_subtotal_cents ? ` · min $${(d.min_subtotal_cents / 100).toFixed(2)}` : ""} · used {d.used_count}{d.usage_limit ? `/${d.usage_limit}` : ""}</div>
                        </div>
                        {d.auto && <span className="text-xs px-2 py-1 rounded-full bg-indigo-50 text-indigo-700" data-testid={`discount-auto-badge-${d.id}`}>Automatic</span>}
                        <span className={`text-xs px-2 py-1 rounded-full ${d.active ? "bg-emerald-100 text-emerald-700" : "bg-zinc-100 text-zinc-500"}`}>{d.active ? "Active" : "Off"}</span>
                        <button onClick={() => del(d.id)}><Trash2 className="w-4 h-4 text-red-500" /></button>
                    </div>
                ))}
            </div>
        </div>
    );
}

function CollectionsTab() {
    const [items, setItems] = useState([]);
    const [products, setProducts] = useState([]);
    const [form, setForm] = useState({ name: "", description: "", product_ids: [] });
    const [busy, setBusy] = useState(false);
    const load = useCallback(async () => {
        const [c, p] = await Promise.all([api.get("/store/collections"), api.get("/store/products").catch(() => ({ data: { products: [] } }))]);
        setItems(c.data.collections || []); setProducts(p.data.products || []);
    }, []);
    useEffect(() => { load(); }, [load]);
    const toggle = (id) => setForm((f) => ({ ...f, product_ids: f.product_ids.includes(id) ? f.product_ids.filter((x) => x !== id) : [...f.product_ids, id] }));
    const create = async () => {
        if (!form.name.trim()) return toast.error("Name required");
        setBusy(true);
        try { await api.post("/store/collections", form); toast.success("Collection created"); setForm({ name: "", description: "", product_ids: [] }); load(); }
        catch { toast.error("Failed"); } finally { setBusy(false); }
    };
    const del = async (id) => { if (!window.confirm("Delete collection?")) return; await api.delete(`/store/collections/${id}`); load(); };
    return (
        <div className="grid md:grid-cols-[320px_1fr] gap-5">
            <div className={card}>
                <div className="font-medium text-brand-ink mb-3 flex items-center gap-2"><Plus className="w-4 h-4" /> New collection</div>
                <input className={input} placeholder="Best sellers" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
                <textarea className={`${input} mt-3`} rows={2} placeholder="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
                {products.length > 0 && (
                    <div className="mt-3 max-h-40 overflow-auto border border-brand-line rounded-lg p-2 space-y-1">
                        {products.map((p) => (
                            <label key={p.id} className="flex items-center gap-2 text-sm cursor-pointer">
                                <input type="checkbox" checked={form.product_ids.includes(p.id)} onChange={() => toggle(p.id)} />
                                <span className="truncate">{p.name}</span>
                            </label>
                        ))}
                    </div>
                )}
                <Button onClick={create} disabled={busy} className="mt-4 w-full bg-brand-copper hover:bg-brand-copperHover text-white">{busy ? "Creating…" : "Create collection"}</Button>
            </div>
            <div className="space-y-2">
                {items.length === 0 && <div className={`${card} text-center text-sm text-zinc-400 py-10`}>No collections yet.</div>}
                {items.map((c) => (
                    <div key={c.id} className={`${card} flex items-center gap-4`}>
                        <div className="w-10 h-10 rounded-lg bg-fuchsia-500/10 text-fuchsia-500 flex items-center justify-center"><Layers className="w-5 h-5" /></div>
                        <div className="flex-1 min-w-0"><div className="font-medium text-brand-ink">{c.name}</div><div className="text-xs text-zinc-500 truncate">{c.product_ids.length} products · /{c.slug}</div></div>
                        <button onClick={() => del(c.id)}><Trash2 className="w-4 h-4 text-red-500" /></button>
                    </div>
                ))}
            </div>
        </div>
    );
}


function money(c) { return `$${((c || 0) / 100).toFixed(2)}`; }

function GiftCardsTab() {
    const [items, setItems] = useState([]);
    const [outstanding, setOutstanding] = useState(0);
    const [amount, setAmount] = useState(25);
    const [recipient, setRecipient] = useState("");
    const [busy, setBusy] = useState(false);
    const load = useCallback(async () => {
        const { data } = await api.get("/store/gift-cards");
        setItems(data.gift_cards || []); setOutstanding(data.outstanding_cents || 0);
    }, []);
    useEffect(() => { load(); }, [load]);
    const issue = async () => {
        if (Number(amount) <= 0) return toast.error("Amount must be positive");
        setBusy(true);
        try { await api.post("/store/gift-cards", { amount_cents: Math.round(Number(amount) * 100), recipient_email: recipient.trim() }); toast.success("Gift card issued"); setAmount(25); setRecipient(""); load(); }
        catch (e) { toast.error(e?.response?.data?.detail || "Failed"); } finally { setBusy(false); }
    };
    const deactivate = async (id) => { await api.post(`/store/gift-cards/${id}/deactivate`); load(); };
    const activate = async (id) => { await api.post(`/store/gift-cards/${id}/activate`); load(); };
    const topUp = async (id) => {
        const v = window.prompt("Top up amount in dollars (use a negative number to deduct):", "10");
        if (v === null) return;
        try { await api.post(`/store/gift-cards/${id}/adjust`, { delta_cents: Math.round(Number(v) * 100), reason: "manual adjustment" }); load(); }
        catch (e) { toast.error(e?.response?.data?.detail || "Failed"); }
    };
    return (
        <div className="grid md:grid-cols-[320px_1fr] gap-5">
            <div className={card}>
                <div className="font-medium text-brand-ink mb-3 flex items-center gap-2"><Gift className="w-4 h-4" /> Issue a gift card</div>
                <label className="text-xs text-zinc-500 block">Amount ($)</label>
                <input className={input} type="number" value={amount} onChange={(e) => setAmount(e.target.value)} data-testid="giftcard-amount" />
                <label className="text-xs text-zinc-500 block mt-3">Recipient email (optional)</label>
                <input className={input} type="email" placeholder="friend@example.com" value={recipient} onChange={(e) => setRecipient(e.target.value)} data-testid="giftcard-recipient" />
                <Button onClick={issue} disabled={busy} className="mt-4 w-full bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="giftcard-issue">{busy ? "Issuing…" : "Issue gift card"}</Button>
                <p className="text-[11px] text-zinc-500 mt-2">Shoppers redeem the code at checkout. Sell a product with type “Gift card” to let customers buy them.</p>
                <div className="mt-4 pt-3 border-t border-brand-line text-sm flex items-center justify-between">
                    <span className="text-zinc-500">Outstanding balance</span>
                    <span className="font-mono font-semibold text-brand-ink" data-testid="giftcard-outstanding">{money(outstanding)}</span>
                </div>
            </div>
            <div className="space-y-2">
                {items.length === 0 && <div className={`${card} text-center text-sm text-zinc-400 py-10`}>No gift cards yet.</div>}
                {items.map((g) => (
                    <div key={g.id} className={`${card} flex items-center gap-4`} data-testid={`giftcard-row-${g.id}`}>
                        <div className="w-10 h-10 rounded-lg bg-brand-copper/10 text-brand-copper flex items-center justify-center"><Gift className="w-5 h-5" /></div>
                        <div className="flex-1 min-w-0">
                            <div className="font-mono font-semibold text-brand-ink truncate">{g.code}</div>
                            <div className="text-xs text-zinc-500">{money(g.balance_cents)} of {money(g.initial_cents)} left · {g.source === "purchase" ? "purchased" : "issued"}{g.recipient_email ? ` · ${g.recipient_email}` : ""}</div>
                        </div>
                        <button className="text-xs text-zinc-500 hover:text-brand-ink underline" onClick={() => topUp(g.id)}>Adjust</button>
                        {g.active
                            ? <button className="text-xs px-2 py-1 rounded-full bg-emerald-100 text-emerald-700" onClick={() => deactivate(g.id)}>Active</button>
                            : <button className="text-xs px-2 py-1 rounded-full bg-zinc-100 text-zinc-500" onClick={() => activate(g.id)}>Off</button>}
                    </div>
                ))}
            </div>
        </div>
    );
}
