import { useEffect, useRef, useState } from "react";
import { MessageCircle, X, Send, Bot, Loader2, User } from "lucide-react";

const API = process.env.REACT_APP_BACKEND_URL;

/**
 * ChatWidgetBlock — public site chat widget. Renders as a fixed-position bubble
 * that opens a panel. Talks to /api/public/chat/*. Grounded, tool-using receptionist.
 */
export default function ChatWidgetBlock({ block }) {
    const props = block?.props || {};
    const websiteSlug = props.website_slug;
    const accent = props.accent || "#C85A17";
    const openLabel = props.label || "Chat with us";

    const [open, setOpen] = useState(false);
    const [sessionToken, setSessionToken] = useState(null);
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState("");
    const [busy, setBusy] = useState(false);
    const [greeting, setGreeting] = useState("");
    const [status, setStatus] = useState("ai");
    const [disabled, setDisabled] = useState(false);
    const [error, setError] = useState(null);
    const scrollRef = useRef(null);

    useEffect(() => {
        if (open && !sessionToken && websiteSlug) {
            (async () => {
                try {
                    const r = await fetch(`${API}/api/public/chat/start`, {
                        method: "POST", headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ website_slug: websiteSlug }),
                    });
                    const d = await r.json();
                    if (d.disabled) {
                        setDisabled(true);
                        setGreeting(d.greeting || "Chat is offline right now.");
                        return;
                    }
                    setSessionToken(d.session_token);
                    setGreeting(d.greeting);
                    setMessages([{ role: "ai", content: d.greeting, id: "greeting" }]);
                } catch (e) { setError(e.message); }
            })();
        }
    }, [open, sessionToken, websiteSlug]);

    useEffect(() => {
        if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, [messages, busy]);

    async function send() {
        const text = input.trim();
        if (!text || !sessionToken || busy) return;
        setBusy(true); setError(null);
        setMessages((m) => [...m, { role: "visitor", content: text, id: `v-${Date.now()}` }]);
        setInput("");
        try {
            const r = await fetch(`${API}/api/public/chat/message`, {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ session_token: sessionToken, message: text }),
            });
            const d = await r.json();
            if (d.paused) {
                setMessages((m) => [...m, { role: "system", content: d.note, id: `sys-${Date.now()}` }]);
                setStatus("human");
                return;
            }
            setMessages((m) => [...m, {
                role: "ai", content: d.reply, id: `a-${Date.now()}`,
                citations: d.citations, confidence: d.confidence,
                needs_human: d.needs_human,
                booking_id: d.booking_id,
                escalation_reason: d.escalation_reason,
            }]);
            if (d.needs_human) setStatus("needs_human");
        } catch (e) {
            setError("Sorry — network hiccup. Please try that message again.");
        } finally { setBusy(false); }
    }

    if (!open) {
        return (
            <button
                onClick={() => setOpen(true)}
                data-testid="chat-widget-open-btn"
                className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-40 rounded-full text-white shadow-lg h-14 w-14 md:h-16 md:w-16 flex items-center justify-center hover:scale-105 transition-transform"
                style={{ backgroundColor: accent }}
                aria-label={openLabel}
            >
                <MessageCircle className="w-6 h-6" />
            </button>
        );
    }

    return (
        <div className="fixed inset-x-0 bottom-0 md:inset-auto md:bottom-6 md:right-6 z-40 md:w-96 md:h-[520px] w-full h-[70vh] rounded-t-2xl md:rounded-2xl bg-white border border-brand-line shadow-2xl flex flex-col overflow-hidden" data-testid="chat-widget-panel">
            <div className="px-4 py-3 flex items-center justify-between border-b border-brand-line" style={{ backgroundColor: accent }}>
                <div className="flex items-center gap-2 text-white">
                    <Bot className="w-4 h-4" />
                    <span className="text-sm font-medium">{props.title || "Assistant"}</span>
                </div>
                <button onClick={() => setOpen(false)} className="text-white/80 hover:text-white" aria-label="Close" data-testid="chat-widget-close-btn">
                    <X className="w-4 h-4" />
                </button>
            </div>

            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 space-y-2 bg-brand-surface" data-testid="chat-widget-messages">
                {messages.map((m) => (
                    <div key={m.id} className={`flex ${m.role === "visitor" ? "justify-end" : "justify-start"}`} data-testid={`chat-msg-${m.role}`}>
                        <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${
                            m.role === "visitor" ? "bg-brand-ink text-white" :
                            m.role === "system" ? "bg-amber-50 border border-amber-200 text-amber-900 italic" :
                            "bg-white border border-brand-line text-brand-ink whitespace-pre-wrap"
                        }`}>
                            {m.content}
                            {m.booking_id && (
                                <div className="mt-2 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 px-2 py-1 text-[11px]" data-testid="chat-widget-booking-confirmation">
                                    Booked · confirmation ref <span className="font-mono">{m.booking_id.slice(-6)}</span>
                                </div>
                            )}
                            {m.needs_human && (
                                <div className="text-[10px] mt-1 uppercase tracking-widest text-amber-700">Handing off to a human…</div>
                            )}
                        </div>
                    </div>
                ))}
                {busy && (
                    <div className="flex items-center gap-2 text-xs text-zinc-500">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" /> thinking…
                    </div>
                )}
                {disabled && (
                    <div className="rounded-md bg-amber-50 border border-amber-200 text-amber-900 p-3 text-xs">{greeting}</div>
                )}
                {error && <div className="rounded-md bg-red-50 border border-red-200 text-red-800 p-2 text-xs">{error}</div>}
                {status === "human" && (
                    <div className="rounded-md bg-emerald-50 border border-emerald-200 text-emerald-900 p-2 text-xs" data-testid="chat-widget-human-banner">
                        A team member has taken over — AI is paused.
                    </div>
                )}
            </div>

            {!disabled && (
                <form onSubmit={(e) => { e.preventDefault(); send(); }} className="border-t border-brand-line bg-white p-2 flex gap-1.5">
                    <input
                        type="text" value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Type your question…"
                        disabled={busy || status === "human"}
                        className="flex-1 rounded-full border border-brand-line px-3 py-2 text-sm focus:outline-none focus:ring-2"
                        data-testid="chat-widget-input"
                    />
                    <button
                        type="submit"
                        disabled={busy || !input.trim() || status === "human"}
                        style={{ backgroundColor: accent }}
                        className="rounded-full text-white h-9 w-9 flex items-center justify-center disabled:opacity-40"
                        data-testid="chat-widget-send-btn"
                    >
                        <Send className="w-4 h-4" />
                    </button>
                </form>
            )}
            <div className="px-3 py-1.5 text-[10px] text-zinc-400 text-center border-t border-brand-line bg-white/40">
                AI assistant · answers grounded in verified records
            </div>
        </div>
    );
}
