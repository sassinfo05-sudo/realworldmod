"""Interview-answers -> BusinessProfile + multi-page Website (block JSON).

Strategy:
1) One LLM call produces a strict-JSON BusinessProfile from interview answers.
2) A second LLM call produces the Website (Home/Services/About/Contact) as block JSON,
   grounded on the BusinessProfile so facts stay consistent.
Both calls use pydantic validation with retry. Images are attached server-side
(deterministic curated Unsplash URLs) so the model can't return broken links.
"""
import logging
import uuid
from typing import Any, Dict, List


from .. import config
from ..models import (
    Block,
    BusinessProfile,
    HourRow,
    KeyValue,
    LocationRow,
    Page,
    Service,
    Website,
    WebsiteTheme,
)
from .images import pick_images
from .llm import LlmError, generate_json

logger = logging.getLogger(__name__)


# ------------------------------ Business Profile ------------------------------

PROFILE_SYSTEM = """You are a senior brand strategist and copywriter who has helped hundreds of small service businesses.
Given an owner's interview answers, produce a clean, factual BusinessProfile.

Rules:
- Return ONLY a single JSON object matching the schema below. No prose. No code fences.
- Never invent facts the owner did not provide. If unclear, leave the field empty (empty string / empty list).
- Never invent prices, availability, certifications, licences, awards, reviews, ratings, guarantees, policies, phone numbers or addresses. Hero "stats" must be omitted unless the owner gave the numbers.
- Services: split whatever the owner listed into discrete items with realistic short descriptions and a price_display string (e.g., "$120", "From $80/hr", "Free estimate") when a number or range was given; otherwise leave price_display "".
- Hours: parse the owner's hours text into 7 rows for Mon..Sun. Use "closed": true for closed days. Times as "9:00 AM" / "5:00 PM" 12-hour format.
- Locations: parse the service area into one or more location rows (city + optional region + phone).
- Differentiators: 3-5 short punchy items (max 12 words each) grounded in what the owner said.
- Policies: 0-3 items (payment, warranty, cancellation) only if implied by the answers.
- `tagline`: one short, calm, non-hypey sentence. Do NOT use words like "revolutionary", "cutting-edge", "AI-powered".
- `about`: 2-4 sentence About paragraph in a human, first-person-plural voice.

Schema (all strings unless noted):
{
  "business_name": "...",
  "industry": "one of: home_services|automotive|beauty_wellness|professional_services|fitness|cleaning|events|other",
  "industry_label": "human label",
  "tagline": "...",
  "about": "...",
  "services": [{"name":"...","description":"...","price_display":"","unit":""}],
  "hours": [{"day":"Mon","open":"9:00 AM","close":"5:00 PM","closed":false}, ... 7 rows Mon..Sun],
  "locations": [{"name":"","address":"","city":"","region":"","phone":""}],
  "differentiators": [{"text":"..."}],
  "policies": [{"text":"..."}],
  "tone": "...",
  "goals": ["..."],
  "contact_email": "",
  "contact_phone": ""
}
"""


def _answers_prompt(answers: Dict[str, Any]) -> str:
    return (
        "OWNER'S INTERVIEW ANSWERS:\n"
        + "\n".join(f"- {k}: {v}" for k, v in answers.items() if v not in (None, "", []))
    )


async def generate_business_profile(org_id: str, answers: Dict[str, Any]) -> BusinessProfile:
    raw = await generate_json(PROFILE_SYSTEM, _answers_prompt(answers))

    # Coerce structure
    services = [
        Service(
            id=str(uuid.uuid4()),
            name=s.get("name", "").strip() or "Service",
            description=s.get("description", "").strip(),
            price_display=s.get("price_display", "") or None,
            unit=s.get("unit", "") or None,
        )
        for s in raw.get("services", [])[:20]
    ]
    hours = [
        HourRow(
            day=h.get("day", "Mon"),
            open=h.get("open") or None,
            close=h.get("close") or None,
            closed=bool(h.get("closed", False)),
        )
        for h in raw.get("hours", [])[:7]
    ]
    if len(hours) < 7:
        # pad with reasonable defaults so UI always renders a full week
        default_days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        present = {h.day for h in hours}
        for d in default_days:
            if d not in present:
                hours.append(HourRow(day=d, closed=(d in {"Sun"})))
        # sort back into weekday order
        order = {d: i for i, d in enumerate(default_days)}
        hours.sort(key=lambda x: order.get(x.day, 99))

    locations = [
        LocationRow(
            id=str(uuid.uuid4()),
            name=l.get("name") or None,
            address=l.get("address") or None,
            city=l.get("city") or None,
            region=l.get("region") or None,
            phone=l.get("phone") or None,
        )
        for l in raw.get("locations", [])[:10]
    ]
    diffs = [KeyValue(id=str(uuid.uuid4()), text=d.get("text", "").strip())
             for d in raw.get("differentiators", [])[:6] if d.get("text")]
    policies = [KeyValue(id=str(uuid.uuid4()), text=p.get("text", "").strip())
                for p in raw.get("policies", [])[:6] if p.get("text")]

    industry = raw.get("industry", "other")
    if industry not in {i["key"] for i in config.INDUSTRIES}:
        industry = "other"
    industry_label = next(
        (i["label"] for i in config.INDUSTRIES if i["key"] == industry),
        raw.get("industry_label", "Service business"),
    )

    return BusinessProfile(
        org_id=org_id,
        business_name=raw.get("business_name", "").strip() or answers.get("business_name", "Your Business"),
        industry=industry,
        industry_label=industry_label,
        tagline=raw.get("tagline", "").strip() or "Trusted local service.",
        about=raw.get("about", "").strip() or "",
        services=services,
        hours=hours,
        locations=locations,
        differentiators=diffs,
        policies=policies,
        tone=raw.get("tone") or answers.get("tone"),
        goals=raw.get("goals") or answers.get("goals") or [],
        contact_email=raw.get("contact_email") or answers.get("contact_email"),
        contact_phone=raw.get("contact_phone") or answers.get("contact_phone"),
    )


# ------------------------------ Theme ------------------------------

INDUSTRY_THEME_HINT = {
    "home_services": {"primary": "#D95A2B", "secondary": "#1E293B", "background": "#FAFAFA",
                       "surface": "#FFFFFF", "foreground": "#0F172A", "accent": "#0EA5E9",
                       "font_heading": "'Fraunces', serif", "font_body": "'DM Sans', sans-serif"},
    "automotive": {"primary": "#2563EB", "secondary": "#0F172A", "background": "#F8FAFC",
                    "surface": "#FFFFFF", "foreground": "#0F172A", "accent": "#F97316",
                    "font_heading": "'Archivo', sans-serif", "font_body": "'Inter', sans-serif"},
    "beauty_wellness": {"primary": "#8A5A3B", "secondary": "#2D2A26", "background": "#FBF7F2",
                         "surface": "#FFFFFF", "foreground": "#1F1B17", "accent": "#B8860B",
                         "font_heading": "'Fraunces', serif", "font_body": "'DM Sans', sans-serif"},
    "professional_services": {"primary": "#15803D", "secondary": "#111827", "background": "#F9FAFB",
                               "surface": "#FFFFFF", "foreground": "#111827", "accent": "#0369A1",
                               "font_heading": "'Fraunces', serif", "font_body": "'IBM Plex Sans', sans-serif"},
    "fitness": {"primary": "#DC2626", "secondary": "#0F172A", "background": "#0F172A",
                "surface": "#1E293B", "foreground": "#F8FAFC", "accent": "#F59E0B",
                "font_heading": "'Archivo', sans-serif", "font_body": "'Inter', sans-serif"},
    "cleaning": {"primary": "#0EA5E9", "secondary": "#0F172A", "background": "#F0F9FF",
                  "surface": "#FFFFFF", "foreground": "#0F172A", "accent": "#22C55E",
                  "font_heading": "'DM Serif Display', serif", "font_body": "'DM Sans', sans-serif"},
    "events": {"primary": "#9A3412", "secondary": "#1C1917", "background": "#FDF8F3",
                "surface": "#FFFFFF", "foreground": "#1C1917", "accent": "#D97706",
                "font_heading": "'Fraunces', serif", "font_body": "'DM Sans', sans-serif"},
    "other": {"primary": "#C85A17", "secondary": "#18181B", "background": "#FAFAFA",
              "surface": "#FFFFFF", "foreground": "#09090B", "accent": "#2563EB",
              "font_heading": "'Fraunces', serif", "font_body": "'DM Sans', sans-serif"},
}


def _theme_for(industry: str, color_pref: str = None) -> WebsiteTheme:
    base = INDUSTRY_THEME_HINT.get(industry) or INDUSTRY_THEME_HINT["other"]
    # optional color_pref nudge
    if color_pref == "bold":
        base = {**base, "primary": "#DC2626"}
    elif color_pref == "cool":
        base = {**base, "primary": "#2563EB"}
    elif color_pref == "neutral":
        base = {**base, "primary": "#18181B", "accent": "#C85A17"}
    return WebsiteTheme(industry=industry, **base)


# ------------------------------ Website blocks ------------------------------

WEBSITE_SYSTEM = """You are a senior website designer + copywriter for small service businesses.
Given a BusinessProfile, produce a tailored multi-page website as structured JSON blocks.
The output MUST feel like a real small business site — warm, human, credible — NOT a template.

Rules:
- Return ONLY one JSON object. No prose, no code fences.
- Two different businesses in different industries MUST produce visibly different structures, sections and copy.
- Reference the ACTUAL business facts (services with prices, hours, locations, differentiators) in your copy.
- Do NOT use words like "revolutionary", "cutting-edge", "AI-powered", "unleash", "level up".
- Copy MUST be original for this business — no lorem ipsum, no generic placeholders.
- Choose block variants that fit the industry (see hints).
- Every block must include a headline that is real copy grounded in the business.
- TRUTH RULE: never invent prices, availability, certifications, licences, awards, reviews, ratings, star counts,
  "years in business", customer numbers, guarantees, policies, phone numbers or addresses. If a fact was not
  supplied in the profile, leave that field empty or omit the block (e.g. no testimonials block without real reviews,
  hero "stats" only when the owner gave the numbers).

INDUSTRY VARIANT HINTS:
- home_services: variant "a" (bold trade hero) for Home; services grid variant "b" (2-col with price chips).
- beauty_wellness: variant "c" (editorial serif hero) for Home; services grid variant "a" (elegant 3-col).
- automotive: variant "b" (dark hero with stats) for Home; services grid variant "c" (dense list w/ pricing).
- professional_services: variant "a" (calm executive hero) for Home; services grid variant "a" (3-col).
- other: use "a".

REQUIRED PAGES: home, services, about, contact.

HOME must contain at minimum: 1 hero, 1 services_grid, 1 about_split, 1 testimonials, 1 cta_band, 1 footer.
SERVICES must contain: 1 hero (short), 1 services_grid (full), 1 cta_band, 1 footer.
ABOUT must contain: 1 hero (short), 1 about_split, 1 testimonials, 1 footer.
CONTACT must contain: 1 hero (short), 1 contact_hours, 1 footer.

BLOCK SCHEMA:
{"type":"hero","variant":"a|b|c","props":{"eyebrow":"","headline":"","subheadline":"","primary_cta":{"label":"","href":""},"secondary_cta":{"label":"","href":""},"stats":[{"label":"","value":""}]}}
{"type":"services_grid","variant":"a|b|c","props":{"eyebrow":"","headline":"","subheadline":"","service_refs":["ALL"]}}  # server injects real services
{"type":"about_split","variant":"a","props":{"eyebrow":"","headline":"","body":"","bullets":["...","..."]}}
{"type":"testimonials","variant":"a","props":{"eyebrow":"","headline":"","items":[{"quote":"","author":"","role":""}]}}   # ONLY real reviews the owner supplied verbatim; if none were supplied, OMIT this block entirely — never write placeholder or invented quotes
{"type":"cta_band","variant":"a","props":{"headline":"","subheadline":"","primary_cta":{"label":"","href":""}}}
{"type":"contact_hours","variant":"a","props":{"headline":"","subheadline":""}}   # server injects hours + locations
{"type":"footer","variant":"a","props":{"tagline":""}}

OUTPUT SHAPE:
{
  "pages": [
    {"slug":"home","title":"Home","seo":{"title":"","description":""},"blocks":[ ... ]},
    {"slug":"services","title":"Services","seo":{...},"blocks":[...]},
    {"slug":"about","title":"About","seo":{...},"blocks":[...]},
    {"slug":"contact","title":"Contact","seo":{...},"blocks":[...]}
  ]
}
"""


def _profile_prompt(profile: BusinessProfile) -> str:
    services_str = "\n".join(
        f"  - {s.name} ({s.price_display or 'no price given'}): {s.description}"
        for s in profile.services
    ) or "  (owner did not list services)"
    diffs_str = "\n".join(f"  - {d.text}" for d in profile.differentiators) or "  (none given)"
    locations_str = ", ".join(
        f"{l.city or l.name or 'location'}" for l in profile.locations
    ) or "unspecified"
    return f"""BUSINESS PROFILE:
- Name: {profile.business_name}
- Industry: {profile.industry} ({profile.industry_label})
- Tagline: {profile.tagline}
- About: {profile.about}
- Tone: {profile.tone or 'calm and confident'}
- Goals: {', '.join(profile.goals) if profile.goals else 'unspecified'}
- Locations: {locations_str}
- Services:
{services_str}
- Differentiators:
{diffs_str}
- Contact: {profile.contact_email or ''} / {profile.contact_phone or ''}
"""


def _attach_images(blocks: List[Block], industry: str) -> None:
    """Server-side image attachment so links can't be broken."""
    for b in blocks:
        if b.type == "hero":
            imgs = pick_images(industry, "hero", 1)
            b.props["image"] = imgs[0]
        elif b.type == "about_split":
            imgs = pick_images(industry, "about", 1)
            b.props["image"] = imgs[0]
        elif b.type == "cta_band":
            imgs = pick_images(industry, "cta", 1)
            b.props["background_image"] = imgs[0]


def _inject_facts(blocks: List[Block], profile: BusinessProfile) -> None:
    """Populate services_grid + contact_hours with real facts so LLM can't drift."""
    for b in blocks:
        if b.type == "services_grid":
            b.props["services"] = [
                {
                    "id": s.id,
                    "name": s.name,
                    "description": s.description,
                    "price_display": s.price_display or "",
                }
                for s in profile.services
            ]
        elif b.type == "contact_hours":
            b.props["hours"] = [h.model_dump() for h in profile.hours]
            b.props["locations"] = [l.model_dump() for l in profile.locations]
            b.props["email"] = profile.contact_email
            b.props["phone"] = profile.contact_phone
        elif b.type == "footer":
            b.props.setdefault("business_name", profile.business_name)
            b.props.setdefault("tagline", profile.tagline)
            b.props["email"] = profile.contact_email
            b.props["phone"] = profile.contact_phone


VALID_BLOCK_TYPES = {"hero", "services_grid", "about_split", "testimonials", "cta_band", "contact_hours", "footer"}


async def generate_website(org_id: str, profile: BusinessProfile, color_pref: str = None) -> Website:
    raw = await generate_json(WEBSITE_SYSTEM, _profile_prompt(profile))
    pages_raw = raw.get("pages", [])
    if not isinstance(pages_raw, list) or not pages_raw:
        raise LlmError("LLM returned no pages")

    required_slugs = {"home", "services", "about", "contact"}
    seen = set()
    pages: List[Page] = []
    for p in pages_raw:
        slug = p.get("slug")
        if slug not in required_slugs or slug in seen:
            continue
        seen.add(slug)
        blocks: List[Block] = []
        for bx in p.get("blocks", []):
            btype = bx.get("type")
            if btype not in VALID_BLOCK_TYPES:
                continue
            blocks.append(Block(
                id=str(uuid.uuid4()),
                type=btype,
                variant=bx.get("variant", "a") or "a",
                props=bx.get("props") or {},
                style=bx.get("style") or {},
            ))
        # Server-side augmentation
        _attach_images(blocks, profile.industry)
        _inject_facts(blocks, profile)
        pages.append(Page(
            id=str(uuid.uuid4()),
            slug=slug,
            title=p.get("title", slug.title()),
            seo=p.get("seo") or {"title": f"{profile.business_name} — {slug.title()}",
                                   "description": profile.tagline},
            blocks=blocks,
        ))

    # Ensure required pages exist (fallback minimal shell)
    for slug in required_slugs - seen:
        pages.append(Page(
            id=str(uuid.uuid4()),
            slug=slug,
            title=slug.title(),
            seo={"title": f"{profile.business_name} — {slug.title()}", "description": profile.tagline},
            blocks=[
                Block(id=str(uuid.uuid4()), type="hero", variant="a",
                      props={"headline": f"{slug.title()} — {profile.business_name}",
                             "subheadline": profile.tagline,
                             "primary_cta": {"label": "Contact us", "href": "/contact"}}),
                Block(id=str(uuid.uuid4()), type="footer", variant="a", props={}),
            ],
        ))
        # re-augment
        _attach_images(pages[-1].blocks, profile.industry)
        _inject_facts(pages[-1].blocks, profile)

    # order pages consistently
    order = ["home", "services", "about", "contact"]
    pages.sort(key=lambda p: order.index(p.slug))

    # HARDENING: guarantee every generated site has a working lead form on the
    # contact page. The LLM does add one in most runs, but we cannot rely on it —
    # this is the primary conversion primitive of the whole product.
    contact_page = next((p for p in pages if p.slug == "contact"), None)
    if contact_page and not any(b.type == "form" for b in contact_page.blocks):
        form_block = Block(
            id=str(uuid.uuid4()), type="form", variant="a",
            props={
                "headline": "Send us a message",
                "subheadline": "Tell us what's going on and we'll get back to you shortly.",
                "page_slug": "contact",
                "submit_label": "Send message",
                "fields": [
                    {"name": "name", "label": "Your name", "type": "text", "required": True},
                    {"name": "email", "label": "Email", "type": "email", "required": True},
                    {"name": "phone", "label": "Phone (optional)", "type": "tel", "required": False},
                    {"name": "message", "label": "How can we help?", "type": "textarea", "required": True},
                ],
            },
        )
        # Insert before the footer (if any), else append
        footer_idx = next((i for i, b in enumerate(contact_page.blocks) if b.type == "footer"), None)
        if footer_idx is not None:
            contact_page.blocks.insert(footer_idx, form_block)
        else:
            contact_page.blocks.append(form_block)

    color_pref = color_pref or "warm"
    theme = _theme_for(profile.industry, color_pref)

    return Website(
        org_id=org_id,
        business_profile_id=profile.id or "",
        theme=theme,
        pages=pages,
        status="draft",
    )
