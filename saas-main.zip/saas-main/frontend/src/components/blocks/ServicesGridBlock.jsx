export default function ServicesGridBlock({ block, theme }) {
    const { variant = "a", props = {} } = block;
    const services = props.services || [];
    const { eyebrow, headline, subheadline } = props;

    const Head = (
        <div className="max-w-2xl">
            {eyebrow && (
                <div className="text-xs uppercase tracking-[0.24em] mb-3" style={{ color: theme?.primary }}>
                    {eyebrow}
                </div>
            )}
            {headline && (
                <h2 data-heading className="text-3xl md:text-4xl font-semibold leading-tight">
                    {headline}
                </h2>
            )}
            {subheadline && (
                <p className="mt-3" style={{ color: `${theme?.foreground}A0` }}>
                    {subheadline}
                </p>
            )}
        </div>
    );

    if (variant === "c") {
        // dense list variant (automotive)
        return (
            <section className="py-20" style={{ backgroundColor: theme?.background }}>
                <div className="mx-auto max-w-5xl px-6">
                    {Head}
                    <ul className="mt-10 divide-y" style={{ borderColor: `${theme?.foreground}1A` }}>
                        {services.map((s) => (
                            <li key={s.id} className="py-5 flex items-center justify-between gap-6"
                                style={{ borderColor: `${theme?.foreground}1A` }}>
                                <div className="min-w-0">
                                    <div className="font-medium">{s.name}</div>
                                    {s.description && (
                                        <div className="text-sm mt-1" style={{ color: `${theme?.foreground}90` }}>
                                            {s.description}
                                        </div>
                                    )}
                                </div>
                                {s.price_display && (
                                    <div className="shrink-0 font-mono text-sm px-3 py-1 rounded-full"
                                         style={{ background: `${theme?.primary}14`, color: theme?.primary }}>
                                        {s.price_display}
                                    </div>
                                )}
                            </li>
                        ))}
                    </ul>
                </div>
            </section>
        );
    }

    if (variant === "b") {
        // 2-col with price chips
        return (
            <section className="py-20" style={{ backgroundColor: theme?.background }}>
                <div className="mx-auto max-w-6xl px-6">
                    {Head}
                    <div className="mt-12 grid md:grid-cols-2 gap-6">
                        {services.map((s) => (
                            <div key={s.id} className="rounded-2xl p-6 border transition-colors hover:border-current"
                                 style={{ background: theme?.surface, borderColor: `${theme?.foreground}14` }}>
                                <div className="flex items-start justify-between gap-4">
                                    <h3 data-heading className="text-lg font-semibold">{s.name}</h3>
                                    {s.price_display && (
                                        <span className="shrink-0 text-xs font-mono px-2.5 py-1 rounded-full"
                                              style={{ background: `${theme?.primary}14`, color: theme?.primary }}>
                                            {s.price_display}
                                        </span>
                                    )}
                                </div>
                                {s.description && (
                                    <p className="mt-2 text-sm" style={{ color: `${theme?.foreground}A0` }}>
                                        {s.description}
                                    </p>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        );
    }

    // variant a — elegant 3-col
    return (
        <section className="py-20" style={{ backgroundColor: theme?.background }}>
            <div className="mx-auto max-w-6xl px-6">
                {Head}
                <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                    {services.map((s) => (
                        <div key={s.id} className="rounded-xl p-6 border"
                             style={{ background: theme?.surface, borderColor: `${theme?.foreground}14` }}>
                            <h3 data-heading className="text-lg font-semibold">{s.name}</h3>
                            {s.description && (
                                <p className="mt-2 text-sm" style={{ color: `${theme?.foreground}A0` }}>{s.description}</p>
                            )}
                            {s.price_display && (
                                <div className="mt-4 pt-4 border-t text-sm font-mono"
                                     style={{ borderColor: `${theme?.foreground}14`, color: theme?.primary }}>
                                    {s.price_display}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
