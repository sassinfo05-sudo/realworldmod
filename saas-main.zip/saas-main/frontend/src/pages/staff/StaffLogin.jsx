import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Logo from "@/components/Logo";
import { toast } from "sonner";
import { ShieldCheck, Lock } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

/** Zanelvo Staff panel login — separate account database, email 2FA always on. */
export default function StaffLogin() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [challenge, setChallenge] = useState(null);
    const [code, setCode] = useState("");
    const [busy, setBusy] = useState(false);
    const { persistToken } = useAuth();
    const navigate = useNavigate();
    usePageMeta("Staff sign in");

    function finish(data) {
        const u = { id: data.staff.id, email: data.staff.email, full_name: data.staff.full_name, role: "platform_founder",
                    staff_role: data.staff.role, work_email: data.staff.work_email, org_id: null, org_name: "Zanelvo staff" };
        persistToken(data.access_token, u);
        toast.success(`Welcome, ${data.staff.full_name || data.staff.email}`);
        navigate("/staff");
    }
    async function onSubmit(e) {
        e.preventDefault(); setBusy(true);
        try {
            const { data } = await api.post("/staff/auth/login", { email: email.trim(), password });
            if (data.mfa_required) { setChallenge(data); if (data.dev_code) setCode(data.dev_code); return; }
            if (data.mfa_skipped_reason) toast.info("2FA skipped: " + data.mfa_skipped_reason);
            finish(data);
        } catch (err) { toast.error(err?.response?.data?.detail || "Sign-in failed"); } finally { setBusy(false); }
    }
    async function onVerify(e) {
        e.preventDefault(); setBusy(true);
        try { const { data } = await api.post("/staff/auth/2fa/verify", { challenge_id: challenge.challenge_id, code: code.trim() }); finish(data); }
        catch (err) { toast.error(err?.response?.data?.detail || "Incorrect code"); } finally { setBusy(false); }
    }
    async function onResend() {
        try { const { data } = await api.post("/staff/auth/2fa/resend", { challenge_id: challenge.challenge_id }); setChallenge(data); if (data.dev_code) setCode(data.dev_code); toast.success("New code sent"); }
        catch (err) { toast.error(err?.response?.data?.detail || "Could not resend"); }
    }

    return (
        <div className="min-h-screen grid lg:grid-cols-2 bg-brand-surface" data-testid="staff-login">
            <div className="hidden lg:flex flex-col justify-between p-12 text-white bg-[linear-gradient(135deg,#0B0A16_0%,#1E1B4B_50%,#4F46E5_100%)]">
                <Logo className="h-9" />
                <div>
                    <div className="text-xs uppercase tracking-[0.3em] opacity-70">Zanelvo Staff</div>
                    <h2 className="font-display text-4xl mt-3 leading-tight">Run the platform.<br />Pricing, payments, tenants, team.</h2>
                    <p className="mt-4 text-white/70 max-w-md text-sm">Every staff account uses two-factor codes and a role with just the permissions it needs. All actions are audited.</p>
                </div>
                <div className="text-xs text-white/50 flex items-center gap-2"><Lock className="w-3.5 h-3.5" /> Restricted area — zanelvo.com/staff</div>
            </div>
            <div className="flex items-center justify-center p-6">
                <div className="w-full max-w-sm">
                    <div className="lg:hidden mb-8"><Logo className="h-8" /></div>
                    {!challenge ? (
                        <form onSubmit={onSubmit} className="space-y-4" data-testid="staff-login-form">
                            <h1 className="font-display text-3xl text-brand-ink">Staff sign in</h1>
                            <p className="text-sm text-zinc-500">Use your staff account. Customers sign in at <a href="/login" className="text-brand-copper">/login</a>.</p>
                            <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="username" className="mt-1" data-testid="staff-login-email" /></div>
                            <div><Label>Password</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete="current-password" className="mt-1" data-testid="staff-login-password" /></div>
                            <Button type="submit" disabled={busy} className="w-full" data-testid="staff-login-submit">{busy ? "Signing in…" : "Continue"}</Button>
                        </form>
                    ) : (
                        <form onSubmit={onVerify} className="space-y-4" data-testid="staff-2fa-form">
                            <div className="w-12 h-12 rounded-2xl bg-brand-copper/10 text-brand-copper grid place-items-center"><ShieldCheck className="w-6 h-6" /></div>
                            <h1 className="font-display text-3xl text-brand-ink">Enter your code</h1>
                            <p className="text-sm text-zinc-500">Sent to <b>{challenge.masked_email}</b>. Staff 2FA can't be turned off.</p>
                            {challenge.dev_code && <div className="text-xs rounded-lg bg-amber-50 border border-amber-200 text-amber-800 px-3 py-2" data-testid="staff-2fa-devcode">Email delivery isn't live yet — your code is <b>{challenge.dev_code}</b>.</div>}
                            <Input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} inputMode="numeric" maxLength={6} autoFocus className="text-center text-2xl tracking-[0.5em] h-14" data-testid="staff-2fa-code" />
                            <Button type="submit" disabled={busy || code.length !== 6} className="w-full" data-testid="staff-2fa-submit">{busy ? "Verifying…" : "Verify & enter"}</Button>
                            <div className="flex justify-between text-sm text-zinc-500"><button type="button" onClick={() => setChallenge(null)}>Back</button><button type="button" onClick={onResend}>Resend code</button></div>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
}
