import { useState } from "react";
import api from "@/lib/api";
import { Lock, Mail, Clock } from "lucide-react";

/** Configurable private/maintenance page shown for a private tenant site. */
export default function MaintenancePage({ data, slug, onUnlocked }) {
    const [pw, setPw] = useState("");
    const [err, setErr] = useState("");
    const [busy, setBusy] = useState(false);
    const accent = data.accent || "#4F46E5";
    async function submit(e) {
        e.preventDefault(); setBusy(true); setErr("");
        try {
            const { data: r } = await api.post(`/public/sites/${slug}/unlock`, { password: pw });
            if (r.unlock_token) sessionStorage.setItem(`zanelvo.unlock.${slug}`, r.unlock_token);
            onUnlocked?.();
        } catch (e) { setErr(e?.response?.data?.detail || "Incorrect password"); } finally { setBusy(false); }
    }
    return (
        <div className="min-h-screen flex items-center justify-center p-6 text-center text-white" data-testid="maintenance-page"
             style={{ background: `radial-gradient(circle at 25% 15%, ${accent}33, transparent 55%), radial-gradient(circle at 80% 90%, ${accent}22, transparent 50%), #0B0A16` }}>
            <div className="max-w-md w-full">
                {data.show_logo !== false && (
                    <div className="mx-auto w-16 h-16 rounded-2xl grid place-items-center text-2xl font-semibold shadow-2xl mb-6" style={{ background: accent }}>{(data.business_name || "S")[0]}</div>
                )}
                {data.show_logo !== false && data.business_name && <div className="text-xs uppercase tracking-[0.25em] text-white/60 mb-3">{data.business_name}</div>}
                <h1 className="text-3xl md:text-4xl font-semibold leading-tight" data-testid="maintenance-title">{data.title}</h1>
                <p className="mt-3 text-white/70 leading-relaxed">{data.message}</p>
                {data.eta && <p className="mt-4 text-sm text-white/60 inline-flex items-center gap-2"><Clock className="w-4 h-4" /> Back {data.eta}</p>}
                {data.password_protected && (
                    <form onSubmit={submit} className="mt-8 flex gap-2 max-w-sm mx-auto" data-testid="maintenance-unlock-form">
                        <div className="relative flex-1">
                            <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
                            <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Site password" required
                                   className="w-full h-11 pl-9 pr-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:ring-2" style={{ "--tw-ring-color": accent }} data-testid="maintenance-password-input" />
                        </div>
                        <button type="submit" disabled={busy} className="h-11 px-5 rounded-lg font-medium text-white disabled:opacity-60" style={{ background: accent }} data-testid="maintenance-unlock-btn">{busy ? "…" : "Enter"}</button>
                    </form>
                )}
                {err && <p className="mt-3 text-sm text-red-300" data-testid="maintenance-error">{err}</p>}
                {data.contact_email && <a href={`mailto:${data.contact_email}`} className="mt-8 inline-flex items-center gap-2 text-sm text-white/60 hover:text-white"><Mail className="w-4 h-4" /> {data.contact_email}</a>}
            </div>
        </div>
    );
}
