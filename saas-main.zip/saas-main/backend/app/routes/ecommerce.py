"""Ecommerce extras — collections + discount codes (owner-scoped, /api/store).

Complements store.py (products/orders/inventory). Adds Shopify-style:
- Collections: group products for storefront browsing.
- Discount codes: percent / fixed, min-subtotal, usage limit, expiry, on/off.
  `validate` computes the discount for a subtotal so the storefront + checkout
  can apply it consistently.
"""
from __future__ import annotations

import re
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User

router = APIRouter(prefix="/store", tags=["ecommerce"])


def _slugify(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-") or uuid.uuid4().hex[:8]


# =========================== COLLECTIONS ===========================

def _collection_out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {"id": d["_id"], "name": d.get("name"), "slug": d.get("slug"),
            "description": d.get("description", ""), "image_url": d.get("image_url", ""),
            "product_ids": d.get("product_ids", []), "created_at": d.get("created_at")}


class CollectionIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = ""
    image_url: str = ""
    product_ids: List[str] = Field(default_factory=list)


@router.get("/collections")
async def list_collections(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = [_collection_out(c) async for c in db.store_collections.find({"org_id": org_id}).sort("created_at", -1)]
    return {"collections": rows}


@router.post("/collections")
async def create_collection(req: CollectionIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    now = utc_now_iso()
    doc = {"_id": uuid.uuid4().hex, "org_id": org_id, "name": req.name, "slug": _slugify(req.name),
           "description": req.description, "image_url": req.image_url, "product_ids": req.product_ids,
           "created_at": now, "updated_at": now}
    await db.store_collections.insert_one(doc)
    return _collection_out(doc)


@router.put("/collections/{cid}")
async def update_collection(cid: str, req: CollectionIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    patch = {"name": req.name, "slug": _slugify(req.name), "description": req.description,
             "image_url": req.image_url, "product_ids": req.product_ids, "updated_at": utc_now_iso()}
    res = await db.store_collections.find_one_and_update(
        {"_id": cid, "org_id": org_id}, {"$set": patch}, return_document=True)
    if not res:
        raise HTTPException(404, "Collection not found")
    return _collection_out(res)


@router.delete("/collections/{cid}")
async def delete_collection(cid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.store_collections.delete_one({"_id": cid, "org_id": org_id})
    if not r.deleted_count:
        raise HTTPException(404, "Collection not found")
    return {"ok": True}


# =========================== DISCOUNT CODES ===========================

def _discount_out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {"id": d["_id"], "code": d.get("code"), "type": d.get("type"),
            "value": d.get("value"), "min_subtotal_cents": int(d.get("min_subtotal_cents", 0)),
            "usage_limit": d.get("usage_limit"), "used_count": int(d.get("used_count", 0)),
            "active": bool(d.get("active", True)), "expires_at": d.get("expires_at"),
            "auto": bool(d.get("auto", False)), "title": d.get("title", ""),
            "eligible_groups": d.get("eligible_groups", []),
            "created_at": d.get("created_at")}


class DiscountIn(BaseModel):
    code: str = Field(min_length=2, max_length=40)
    type: str = "percent"  # percent | fixed
    value: float = Field(gt=0)             # percent (0-100) or fixed dollars
    min_subtotal_cents: int = Field(default=0, ge=0)
    usage_limit: Optional[int] = Field(default=None, ge=1)
    active: bool = True
    expires_at: Optional[str] = None       # ISO date/datetime string
    auto: bool = False                     # Round 11: automatic discount — applied at checkout without a code
    title: str = Field(default="", max_length=80)  # shopper-facing label for automatic discounts
    eligible_groups: List[str] = Field(default_factory=list)  # Round 12: limit to these customer groups (empty = everyone)


@router.get("/discounts")
async def list_discounts(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = [_discount_out(d) async for d in db.store_discounts.find({"org_id": org_id}).sort("created_at", -1)]
    return {"discounts": rows}


@router.post("/discounts")
async def create_discount(req: DiscountIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    code = req.code.strip().upper()
    if req.type not in ("percent", "fixed"):
        raise HTTPException(400, "type must be percent or fixed")
    if req.type == "percent" and req.value > 100:
        raise HTTPException(400, "percent cannot exceed 100")
    if await db.store_discounts.find_one({"org_id": org_id, "code": code}):
        raise HTTPException(409, "Code already exists")
    now = utc_now_iso()
    doc = {"_id": uuid.uuid4().hex, "org_id": org_id, "code": code, "type": req.type,
           "value": float(req.value), "min_subtotal_cents": req.min_subtotal_cents,
           "usage_limit": req.usage_limit, "used_count": 0, "active": req.active,
           "expires_at": req.expires_at, "auto": bool(req.auto), "title": req.title.strip(),
           "eligible_groups": [g.strip() for g in req.eligible_groups if g.strip()],
           "created_at": now, "updated_at": now}
    await db.store_discounts.insert_one(doc)
    return _discount_out(doc)


@router.put("/discounts/{did}")
async def update_discount(did: str, req: DiscountIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    patch = {"type": req.type, "value": float(req.value), "min_subtotal_cents": req.min_subtotal_cents,
             "usage_limit": req.usage_limit, "active": req.active, "expires_at": req.expires_at,
             "auto": bool(req.auto), "title": req.title.strip(),
             "eligible_groups": [g.strip() for g in req.eligible_groups if g.strip()],
             "updated_at": utc_now_iso()}
    res = await db.store_discounts.find_one_and_update(
        {"_id": did, "org_id": org_id}, {"$set": patch}, return_document=True)
    if not res:
        raise HTTPException(404, "Discount not found")
    return _discount_out(res)


@router.delete("/discounts/{did}")
async def delete_discount(did: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.store_discounts.delete_one({"_id": did, "org_id": org_id})
    if not r.deleted_count:
        raise HTTPException(404, "Discount not found")
    return {"ok": True}


def compute_discount(d: Dict[str, Any], subtotal_cents: int, buyer_group: Optional[str] = None) -> Dict[str, Any]:
    """Pure calculator used by validate + checkout. Returns {valid, discount_cents, message}."""
    now = utc_now_iso()
    if not d.get("active", True):
        return {"valid": False, "discount_cents": 0, "message": "This code is no longer active."}
    groups = d.get("eligible_groups") or []
    if groups and (buyer_group or "") not in groups:
        return {"valid": False, "discount_cents": 0, "message": "This offer is for a specific customer group."}
    if d.get("expires_at") and str(d["expires_at"]) < now:
        return {"valid": False, "discount_cents": 0, "message": "This code has expired."}
    if d.get("usage_limit") is not None and int(d.get("used_count", 0)) >= int(d["usage_limit"]):
        return {"valid": False, "discount_cents": 0, "message": "This code has reached its usage limit."}
    if subtotal_cents < int(d.get("min_subtotal_cents", 0)):
        need = int(d["min_subtotal_cents"]) / 100
        return {"valid": False, "discount_cents": 0, "message": f"Spend at least ${need:.2f} to use this code."}
    if d.get("type") == "percent":
        disc = round(subtotal_cents * float(d.get("value", 0)) / 100)
    else:
        disc = min(subtotal_cents, round(float(d.get("value", 0)) * 100))
    return {"valid": True, "discount_cents": int(disc), "message": "Code applied."}


async def best_discount(db, org_id: str, subtotal_cents: int, code: Optional[str] = None,
                        buyer_group: Optional[str] = None) -> Dict[str, Any]:
    """Round 11/12 — resolve the discount for a checkout.

    If `code` is given it must be a valid manual code (else {valid:False, reason}). Otherwise every active
    `auto: true` rule is evaluated and the single largest saving wins (no stacking). Group-limited rules only
    apply to the matching `buyer_group`. Never trusts the client.
    """
    if code:
        d = await db.store_discounts.find_one({"org_id": org_id, "code": code.strip().upper()})
        if not d:
            return {"valid": False, "discount_cents": 0, "code": code.strip().upper(), "auto": False, "message": "Code not found."}
        r = compute_discount(d, subtotal_cents, buyer_group)
        return {**r, "code": d.get("code"), "auto": False, "discount_id": d["_id"], "title": d.get("title", "")}
    best: Dict[str, Any] = {"valid": False, "discount_cents": 0, "code": "", "auto": True, "message": ""}
    async for d in db.store_discounts.find({"org_id": org_id, "auto": True, "active": True}):
        r = compute_discount(d, subtotal_cents, buyer_group)
        if r["valid"] and r["discount_cents"] > best["discount_cents"]:
            best = {**r, "code": d.get("code"), "auto": True, "discount_id": d["_id"], "title": d.get("title") or d.get("code")}
    return best


async def resolve_buyer_group(db, org_id: str, customer_id: Optional[str], email: Optional[str]) -> Optional[str]:
    """Find the customer group for a buyer — shop account first, then a CRM contact by email."""
    if customer_id:
        c = await db.shop_customers.find_one({"_id": customer_id, "org_id": org_id}, {"customer_group": 1})
        if c and c.get("customer_group"):
            return c["customer_group"]
    if email:
        ct = await db.contacts.find_one({"org_id": org_id, "emails": email.lower().strip()}, {"customer_group": 1})
        if ct and ct.get("customer_group"):
            return ct["customer_group"]
    return None


class ValidateIn(BaseModel):
    code: str
    subtotal_cents: int = Field(ge=0)


@router.post("/discounts/validate")
async def validate_discount(req: ValidateIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    d = await db.store_discounts.find_one({"org_id": org_id, "code": req.code.strip().upper()})
    if not d:
        return {"valid": False, "discount_cents": 0, "final_cents": req.subtotal_cents, "message": "Code not found."}
    result = compute_discount(d, req.subtotal_cents)
    result["final_cents"] = max(0, req.subtotal_cents - result["discount_cents"])
    return result
