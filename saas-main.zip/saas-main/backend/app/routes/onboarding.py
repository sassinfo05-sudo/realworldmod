"""Onboarding interview — steps, answer patch, and generation trigger."""
import logging

from bson import ObjectId
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel
from typing import Any, Dict, List, Optional

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import InterviewSession, User
from ..services.generation import generate_business_profile, generate_website
from ..services.llm import LlmError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/onboarding", tags=["onboarding"])


# --- Interview definition (server-authoritative so we can adjust without a redeploy) ---
INTERVIEW_STEPS: List[Dict[str, Any]] = [
    {
        "id": "business_name",
        "title": "What's the name of your business?",
        "hint": "Exactly as your customers know it.",
        "field": "business_name",
        "kind": "text",
        "required": True,
        "placeholder": "e.g., Riverside Plumbing",
    },
    {
        "id": "industry",
        "title": "What kind of work do you do?",
        "hint": "Pick the closest match — you can fine-tune the copy after.",
        "field": "industry",
        "kind": "industry",
        "required": True,
    },
    {
        "id": "services",
        "title": "What do you offer, and roughly what does it cost?",
        "hint": "One per line: name — short note — price. Skip prices you don't publish.",
        "field": "services_text",
        "kind": "textarea",
        "required": True,
        "placeholder": (
            "Emergency plumbing — 24/7 callouts — $180 first hour\n"
            "Drain unblock — most jobs fixed in one visit — $220\n"
            "Water heater install — includes haul-away — from $1,200"
        ),
    },
    {
        "id": "service_area",
        "title": "Where do you work?",
        "hint": "Cities or neighborhoods you serve. Add a phone if you have one.",
        "field": "service_area",
        "kind": "textarea",
        "required": True,
        "placeholder": "Austin, Round Rock, Cedar Park — (512) 555-0134",
    },
    {
        "id": "hours",
        "title": "When are you open?",
        "hint": "Free-form is fine — we'll structure it. Mention emergencies if you take them.",
        "field": "hours_text",
        "kind": "textarea",
        "required": True,
        "placeholder": "Mon–Fri 7am–6pm, Sat 8am–2pm, Sun closed. 24/7 emergency for burst pipes.",
    },
    {
        "id": "differentiators",
        "title": "Why do customers pick you?",
        "hint": "Three real reasons. Skip clichés — say what's actually true.",
        "field": "differentiators",
        "kind": "textarea",
        "required": True,
        "placeholder": (
            "Licensed & insured for 18 years\n"
            "Flat-rate quotes before we start\n"
            "Same-day service for 8 out of 10 calls"
        ),
    },
    {
        "id": "tone",
        "title": "How should the site sound?",
        "hint": "Pick a voice. We'll match it.",
        "field": "tone",
        "kind": "choice",
        "required": True,
        "options": [
            {"value": "warm_professional", "label": "Warm & professional",
             "note": "Approachable, no jargon."},
            {"value": "calm_confident", "label": "Calm & confident",
             "note": "Understated authority."},
            {"value": "bold_direct", "label": "Bold & direct",
             "note": "No fluff. Fast quotes."},
            {"value": "premium_editorial", "label": "Premium & editorial",
             "note": "Boutique feel."},
        ],
    },
    {
        "id": "goals",
        "title": "What do you want this site to do?",
        "hint": "Pick anything that matters.",
        "field": "goals",
        "kind": "multi",
        "required": True,
        "options": [
            {"value": "more_calls", "label": "More calls"},
            {"value": "more_bookings", "label": "More online bookings"},
            {"value": "more_quotes", "label": "More quote requests"},
            {"value": "faster_payments", "label": "Get paid faster"},
            {"value": "look_credible", "label": "Look more credible"},
        ],
    },
    {
        "id": "contact",
        "title": "How should people reach you?",
        "hint": "We'll put these on every page.",
        "field": "contact",
        "kind": "contact",
        "required": True,
    },
    {
        "id": "color_pref",
        "title": "Any visual preference?",
        "hint": "Optional. We'll pick a tasteful palette either way.",
        "field": "color_pref",
        "kind": "choice",
        "required": False,
        "options": [
            {"value": "warm", "label": "Warm", "note": "Amber, terracotta, cream."},
            {"value": "cool", "label": "Cool", "note": "Slate, navy, ocean."},
            {"value": "neutral", "label": "Neutral", "note": "Charcoal + one accent."},
            {"value": "bold", "label": "Bold", "note": "High contrast, punchy."},
        ],
    },
]


@router.get("/steps")
async def get_steps(user: User = Depends(current_user)):
    return {"steps": INTERVIEW_STEPS}


@router.get("/session")
async def get_or_create_session(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    existing = await db.interview_sessions.find_one({"org_id": org_id, "user_id": user.id})
    if existing:
        return InterviewSession.from_mongo(existing).model_dump()

    session = InterviewSession(org_id=org_id, user_id=user.id)
    doc = session.to_mongo()
    res = await db.interview_sessions.insert_one(doc)
    session.id = str(res.inserted_id)
    return session.model_dump()


class AnswerPatch(BaseModel):
    field: str
    value: Any
    step_index: Optional[int] = None


@router.patch("/session/answer")
async def patch_answer(patch: AnswerPatch,
                       user: User = Depends(current_user),
                       org_id: str = Depends(require_org)):
    db = get_db()
    valid_fields = {s["field"] for s in INTERVIEW_STEPS} | {"contact_email", "contact_phone"}
    if patch.field not in valid_fields:
        raise HTTPException(status_code=400, detail=f"Unknown field: {patch.field}")

    update = {f"answers.{patch.field}": patch.value, "updated_at": utc_now_iso()}
    if patch.step_index is not None:
        update["step_index"] = patch.step_index

    result = await db.interview_sessions.find_one_and_update(
        {"org_id": org_id, "user_id": user.id},
        {"$set": update},
        return_document=True,
    )
    if not result:
        raise HTTPException(status_code=404, detail="Interview session not found")
    return InterviewSession.from_mongo(result).model_dump()


class ResearchReq(BaseModel):
    business_name: str
    country: Optional[str] = None
    location: Optional[str] = None
    extra: Optional[str] = None


_RESEARCH_SYSTEM = (
    "You are a business research assistant. Given a business name and location, infer "
    "the most likely public profile for that small/local business. Return STRICT JSON "
    "only, no prose, with this exact shape: {"
    "\"business_name\": str, \"industry\": one of "
    "[home_services, automotive, beauty_wellness, professional_services, fitness, cleaning, events, other], "
    "\"industry_freetext\": str, \"tagline\": str, \"about\": str, "
    "\"services_text\": str (comma or newline separated likely services), "
    "\"service_area\": str, \"hours_text\": str, \"differentiators\": str, "
    "\"tone\": one of [warm, professional, bold, friendly], "
    "\"confidence\": one of [low, medium, high], "
    "\"note\": str (one line: what you assumed vs. verified)}. "
    "If you cannot find a real match, make reasonable, clearly-generic assumptions for "
    "that industry and set confidence to 'low'. Never invent specific prices or phone numbers."
)


@router.post("/research")
async def research_business(req: ResearchReq, user: User = Depends(current_user)):
    """AI lookup for an existing business. Returns structured, approvable facts.
    Uses the platform LLM key — no owner key required. Nothing is persisted here."""
    from ..services.llm import generate_json
    where = ", ".join([x for x in [req.location, req.country] if x]) or "unknown location"
    prompt = (
        f"Business name: {req.business_name}\nLocation: {where}\n"
        f"Extra context: {req.extra or 'none'}\n"
        "Produce the JSON profile now."
    )
    try:
        data = await generate_json(_RESEARCH_SYSTEM, prompt)
    except LlmError as e:
        raise HTTPException(status_code=502, detail=f"Research failed: {e}")
    # Never trust the model to echo the exact name/location
    data["business_name"] = data.get("business_name") or req.business_name
    if req.location or req.country:
        data.setdefault("service_area", where)
    return {"facts": data, "input": req.model_dump()}


class ResearchApply(BaseModel):
    answers: Dict[str, Any]


@router.post("/research/apply")
async def apply_research(body: ResearchApply,
                         user: User = Depends(current_user),
                         org_id: str = Depends(require_org)):
    """Persist the owner-approved facts into their interview session answers, so the
    existing /generate pipeline builds the site from them."""
    db = get_db()
    valid_fields = {s["field"] for s in INTERVIEW_STEPS} | {"contact_email", "contact_phone"}
    updates = {"updated_at": utc_now_iso()}
    for k, v in (body.answers or {}).items():
        if k in valid_fields:
            updates[f"answers.{k}"] = v
    # ensure a session exists
    existing = await db.interview_sessions.find_one({"org_id": org_id, "user_id": user.id})
    if not existing:
        session = InterviewSession(org_id=org_id, user_id=user.id)
        res = await db.interview_sessions.insert_one(session.to_mongo())
        _id = res.inserted_id
    else:
        _id = existing["_id"]
    result = await db.interview_sessions.find_one_and_update(
        {"_id": _id}, {"$set": updates}, return_document=True,
    )
    return InterviewSession.from_mongo(result).model_dump()



async def _run_generation(session_id_str: str, org_id: str):
    """Background task: generate BusinessProfile + Website, then update session."""
    db = get_db()
    try:
        sess_doc = await db.interview_sessions.find_one({"_id": ObjectId(session_id_str)})
        if not sess_doc:
            return
        session = InterviewSession.from_mongo(sess_doc)
        answers_dict = session.answers.model_dump()

        # 1) BusinessProfile
        profile = await generate_business_profile(org_id, answers_dict)
        prof_doc = profile.to_mongo()
        prof_res = await db.business_profiles.insert_one(prof_doc)
        profile.id = str(prof_res.inserted_id)

        # Sync org.industry so nav + theming can key off it later
        await db.organizations.update_one(
            {"_id": ObjectId(org_id)},
            {"$set": {"industry": profile.industry, "name": profile.business_name,
                      "updated_at": utc_now_iso()}},
        )

        # 2) Website
        website = await generate_website(org_id, profile, color_pref=answers_dict.get("color_pref"))
        website.business_profile_id = profile.id
        web_doc = website.to_mongo()
        web_res = await db.websites.insert_one(web_doc)
        website.id = str(web_res.inserted_id)

        await db.interview_sessions.update_one(
            {"_id": ObjectId(session_id_str)},
            {"$set": {
                "status": "ready",
                "business_profile_id": profile.id,
                "website_id": website.id,
                "error": None,
                "updated_at": utc_now_iso(),
            }},
        )
        logger.info("Generation ready for session %s (profile=%s website=%s)",
                    session_id_str, profile.id, website.id)
    except LlmError as e:
        logger.error("Generation LLM error: %s", e)
        await db.interview_sessions.update_one(
            {"_id": ObjectId(session_id_str)},
            {"$set": {"status": "failed", "error": str(e), "updated_at": utc_now_iso()}},
        )
    except Exception as e:  # noqa: BLE001
        logger.exception("Generation failed unexpectedly")
        await db.interview_sessions.update_one(
            {"_id": ObjectId(session_id_str)},
            {"$set": {"status": "failed", "error": f"{type(e).__name__}: {e}",
                      "updated_at": utc_now_iso()}},
        )


@router.post("/generate")
async def start_generation(background: BackgroundTasks,
                            user: User = Depends(current_user),
                            org_id: str = Depends(require_org)):
    db = get_db()
    sess_doc = await db.interview_sessions.find_one({"org_id": org_id, "user_id": user.id})
    if not sess_doc:
        raise HTTPException(status_code=404, detail="No interview session")
    session = InterviewSession.from_mongo(sess_doc)
    answers = session.answers
    required = ["business_name", "industry", "services_text", "service_area",
                "hours_text", "differentiators", "tone", "contact_email"]
    missing = [f for f in required if not getattr(answers, f, None)]
    if missing:
        raise HTTPException(status_code=400,
                            detail=f"Missing required answers: {', '.join(missing)}")

    await db.interview_sessions.update_one(
        {"_id": ObjectId(session.id)},
        {"$set": {"status": "generating", "error": None, "updated_at": utc_now_iso()}},
    )
    background.add_task(_run_generation, session.id, org_id)
    return {"ok": True, "status": "generating"}


@router.get("/session/status")
async def get_session_status(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    sess_doc = await db.interview_sessions.find_one({"org_id": org_id, "user_id": user.id})
    if not sess_doc:
        raise HTTPException(status_code=404, detail="No interview session")
    return InterviewSession.from_mongo(sess_doc).model_dump()
