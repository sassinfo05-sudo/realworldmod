# ZANELVO — ROUND 9 LIVE PROGRESS TRACKER

Legend: ⬜ uncompleted · 🟨 in progress · ✅ completed & verified

## Gate 1 — P0 security
- ✅ 1A Payment integrity (prod rejects simulated pay; real Stripe session; webhook-only activation) — backend 15/15
- ✅ 1B-svg Server-side SVG sanitization on branding save — verified
- ✅ 1B-head custom_head_html XSS removed + strict pixel-id validation — verified
- ✅ 1D-idem Tenant-scoped usage idempotency + unique index — verified
- ✅ repro yarn.lock committed + requirements.txt litellm conflict fixed
- ✅ 1C Page-password server-side hashing + rate-limited unlock token + noindex — verified (401/token/forged)
- ✅ 1F Webhook signing secret reversible-encrypted + show-once + real HMAC + X-Zanelvo only + rotate endpoint + PII-redacted stored payloads — verified (customer reproduces v1)
- ✅ 1B-upload Media SVG sanitize on upload + MIME-by-bytes + CSV row/byte caps — verified (spoof->415, svg sanitized)
- ✅ 1B-csp Strict CSP + HSTS + Permissions-Policy + COOP on API; index.html analytics/brand cleaned — verified
- ✅ 1J Secret scan: no real creds in tracked files (backend_test*.py now env-driven), stale-brand sweep done — verified
- ✅ 1I-auth Unified login-secure->canonical login; email codes hashed at rest; TOTP secret encrypted at rest — verified
- ✅ 1D-atomic Budget-warning email (one/period, atomic month-guard) added to settle(); holds already counted in caps (include_held=True) — verified callable. NOTE: full findOneAndUpdate atomic counters still a future refactor (reservations mitigate races today)
- 🟨 1G Inbound email provider-signature verification + org resolution
- ⬜ 1B-cookie JWT -> HttpOnly cookie + CSRF (BIG; may defer)
- ⬜ 1F-paypal PayPal signed webhook (needs PayPal creds)

## Notes
- Each completed item is verified by backend testing agent or a direct curl/unit check.
- Git: use chat "Save to Github"; agent does not push.
