"""Founder / production-bootstrap safety.

Guarantees:
* Email-match founder auto-promotion is DISABLED in production (fail-closed) — a founder is only
  ever provisioned explicitly (scripts.bootstrap_founder / staff invite).
* No hardcoded personal/default founder email is baked into source as a promotion default.
"""
from __future__ import annotations

import pathlib

from app import config


def test_autopromote_disabled_in_production(monkeypatch):
    monkeypatch.setattr(config, "APP_ENV", "production")
    assert config.simulation_allowed() is False
    assert config.is_production() is True
    assert config.is_founder_autopromote_allowed() is False


def test_autopromote_allowed_in_dev(monkeypatch):
    monkeypatch.setattr(config, "APP_ENV", "dev")
    assert config.is_founder_autopromote_allowed() is True


def test_no_hardcoded_personal_founder_default():
    """The source default for FOUNDER_EMAILS must be empty (env-only), with no personal address."""
    src = pathlib.Path(config.__file__).read_text(encoding="utf-8")
    # the getenv default for FOUNDER_EMAILS is the empty string
    assert 'os.environ.get("FOUNDER_EMAILS", "")' in src
    assert "idoyiron@gmail.com" not in src


def test_bootstrap_cli_present():
    """Explicit one-time founder bootstrap must exist as a deliberate CLI (not implicit startup)."""
    import importlib
    mod = importlib.import_module("scripts.bootstrap_founder")
    assert mod is not None
