"""Site template gallery + build-from-scratch (Round 10, Gate 3).

Templates are deterministic block-JSON designs per industry (no LLM cost). They reuse the
industry theme hints + curated image pools from generation/images so a template is instantly
publishable and truthful (placeholder copy is explicit, never invented facts/reviews/prices).
"""
from __future__ import annotations

import uuid
from typing import Any, Dict, List

from .generation import _theme_for
from .images import pick_images


def _b(t: str, props: Dict[str, Any], variant: str = "a") -> Dict[str, Any]:
    return {"id": str(uuid.uuid4()), "type": t, "variant": variant, "props": props, "style": {}, "hidden": False}


def _page(slug: str, title: str, blocks: List[Dict[str, Any]], name: str, desc: str = "") -> Dict[str, Any]:
    return {"id": str(uuid.uuid4()), "slug": slug, "title": title, "hidden": False,
            "seo": {"title": f"{name} — {title}", "description": desc}, "blocks": blocks}


def _form(name: str) -> Dict[str, Any]:
    return _b("form", {
        "headline": "Send us a message", "subheadline": "Tell us what you need and we'll get back to you shortly.",
        "page_slug": "contact", "submit_label": "Send message",
        "fields": [
            {"name": "name", "label": "Your name", "type": "text", "required": True},
            {"name": "email", "label": "Email", "type": "email", "required": True},
            {"name": "phone", "label": "Phone (optional)", "type": "tel", "required": False},
            {"name": "message", "label": "How can we help?", "type": "textarea", "required": True},
        ]})


def _footer(name: str) -> Dict[str, Any]:
    return _b("footer", {"business_name": name, "tagline": "", "email": "", "phone": ""})


TEMPLATES: List[Dict[str, Any]] = [
    {"id": "trades-bold", "name": "Trades & Home Services", "industry": "home_services", "color_pref": "warm",
     "description": "Bold hero, service grid, trust band and a prominent quote form. Built for plumbers, electricians, HVAC and roofers.",
     "tags": ["services", "quotes", "local"], "services": ["Repairs", "Installations", "Emergency call-outs"]},
    {"id": "studio-calm", "name": "Beauty & Wellness Studio", "industry": "beauty_wellness", "color_pref": "neutral",
     "description": "Soft palette, treatment menu, team section and a booking-first call to action.",
     "tags": ["bookings", "menu", "team"], "services": ["Signature treatment", "Express service", "Packages"]},
    {"id": "advisor-clean", "name": "Professional Services", "industry": "professional_services", "color_pref": "cool",
     "description": "Editorial layout for consultants, accountants and agencies: proof, process and a consultation form.",
     "tags": ["consulting", "b2b", "process"], "services": ["Advisory", "Implementation", "Ongoing support"]},
    {"id": "fit-dark", "name": "Fitness & Coaching", "industry": "fitness", "color_pref": "bold",
     "description": "High-energy dark theme with stats, class grid, pricing table and countdown for launches.",
     "tags": ["classes", "pricing", "dark"], "services": ["Group classes", "Personal training", "Online coaching"]},
    {"id": "clean-fresh", "name": "Cleaning & Maintenance", "industry": "cleaning", "color_pref": "cool",
     "description": "Fresh blue palette, FAQ block, service areas and an instant-quote form.",
     "tags": ["quotes", "faq", "recurring"], "services": ["Residential cleaning", "Commercial cleaning", "Deep clean"]},
    {"id": "events-warm", "name": "Events & Photography", "industry": "events", "color_pref": "warm",
     "description": "Gallery-led storytelling with testimonials placeholder, packages and an enquiry form.",
     "tags": ["gallery", "portfolio", "packages"], "services": ["Weddings", "Corporate events", "Portrait sessions"]},
    {"id": "auto-pro", "name": "Automotive", "industry": "automotive", "color_pref": "cool",
     "description": "Confident blue layout with services, opening hours + map and a booking CTA for garages and detailers.",
     "tags": ["garage", "hours", "map"], "services": ["Servicing", "Diagnostics", "Detailing"]},
    {"id": "starter-minimal", "name": "Minimal Starter", "industry": "other", "color_pref": "neutral",
     "description": "One-page starter: hero, three services, about, contact form. The fastest way to go live.",
     "tags": ["one-page", "minimal"], "services": ["Service one", "Service two", "Service three"]},
]


def list_templates() -> List[Dict[str, Any]]:
    out = []
    for t in TEMPLATES:
        theme = _theme_for(t["industry"], t["color_pref"]).model_dump()
        out.append({"id": t["id"], "name": t["name"], "industry": t["industry"], "description": t["description"],
                    "tags": t["tags"], "palette": {k: theme[k] for k in ("primary", "secondary", "background", "accent")},
                    "preview_image": pick_images(t["industry"], "hero", 1)[0],
                    "pages": ["home", "services", "about", "contact"] if t["id"] != "starter-minimal" else ["home"]})
    return out


def build_template(template_id: str, business_name: str, tagline: str = "") -> Dict[str, Any]:
    """Returns {"theme": {...}, "pages": [...], "nav_order": [...]} for the given template."""
    t = next((x for x in TEMPLATES if x["id"] == template_id), None)
    if not t:
        raise KeyError(template_id)
    name = (business_name or "Your business").strip()
    ind = t["industry"]
    tagline = tagline or "Tell visitors what you do in one clear sentence."
    theme = _theme_for(ind, t["color_pref"]).model_dump()
    hero_img = pick_images(ind, "hero", 1)[0]
    about_img = pick_images(ind, "about", 1)[0]
    cta_img = pick_images(ind, "cta", 1)[0]
    services = [{"name": s, "description": "Describe this service in one or two sentences."} for s in t["services"]]

    hero = _b("hero", {"headline": f"{name}", "subheadline": tagline, "image": hero_img,
                       "primary_cta": {"label": "Get a quote", "href": "/contact"},
                       "secondary_cta": {"label": "Our services", "href": "/services"}},
              variant="b" if ind in ("fitness", "events") else "a")
    grid = _b("services_grid", {"headline": "What we do", "services": services})
    about = _b("about_split", {"headline": f"About {name}", "body": "Share your story, experience and what makes you different. Keep it honest and specific.",
                               "bullets": ["Add a real strength", "Add another", "Add one more"], "image": about_img})
    cta = _b("cta_band", {"headline": "Ready to get started?", "subheadline": "Reach out today — we reply fast.",
                          "primary_cta": {"label": "Contact us", "href": "/contact"}, "background_image": cta_img})
    hours = _b("contact_hours", {"headline": "Hours & location", "hours": [
        {"day": "Mon", "open": "8:00", "close": "18:00"}, {"day": "Tue", "open": "8:00", "close": "18:00"},
        {"day": "Wed", "open": "8:00", "close": "18:00"}, {"day": "Thu", "open": "8:00", "close": "18:00"},
        {"day": "Fri", "open": "8:00", "close": "18:00"}, {"day": "Sat", "open": "9:00", "close": "14:00"},
        {"day": "Sun", "closed": True}],
        "locations": [{"label": "Main location", "address": "Add your address"}], "phone": "", "email": ""})
    faq = _b("faq", {"title": "Frequently asked questions", "items": [
        {"question": "How quickly can you start?", "answer": "Add your typical lead time."},
        {"question": "Do you offer free quotes?", "answer": "Explain how quotes work."},
        {"question": "Which areas do you cover?", "answer": "List your service areas."}]})
    stats = _b("stats", {"title": "Why choose us", "items": [
        {"label": "Years in business", "value": "—"}, {"label": "Jobs completed", "value": "—"}, {"label": "Response time", "value": "—"}]})
    gallery = _b("gallery", {"title": "Recent work", "columns": 3, "images": [{"url": u, "caption": ""} for u in pick_images(ind, "hero", 3)]})
    team = _b("team", {"title": "Meet the team", "members": [
        {"name": "Team member", "role": "Role", "photo": "", "bio": ""}, {"name": "Team member", "role": "Role", "photo": "", "bio": ""}]})
    pricing = _b("pricing_table", {"title": "Plans", "subtitle": "Add your real prices before publishing.", "plans": [
        {"name": "Starter", "price": "—", "period": "", "description": "Describe this plan.", "features": "Feature\nFeature", "cta_label": "Enquire", "cta_href": "/contact", "featured": False},
        {"name": "Pro", "price": "—", "period": "", "description": "Describe this plan.", "features": "Feature\nFeature\nFeature", "cta_label": "Enquire", "cta_href": "/contact", "featured": True, "badge": "Popular"}]})
    testi = _b("testimonials", {"headline": "What clients say", "items": [],
                                "note": "Add real client reviews here — leave empty until you have permission to publish them."})
    mapb = _b("map", {"title": "Find us", "address": "", "height": 380})
    blog = _b("blog_list", {"title": "Latest articles", "subtitle": "", "limit": 3})

    if t["id"] == "starter-minimal":
        pages = [_page("home", "Home", [hero, grid, about, cta, _form(name), _footer(name)], name, tagline)]
        return {"theme": theme, "pages": pages, "nav_order": ["home"]}

    home_blocks = [hero, grid]
    if ind == "fitness":
        home_blocks += [stats, pricing, _b("countdown", {"title": "Next programme starts soon", "target": "", "cta_label": "Reserve a spot", "cta_href": "/contact"})]
    elif ind == "events":
        home_blocks += [gallery, testi]
    elif ind == "professional_services":
        home_blocks += [stats, about]
    elif ind == "cleaning":
        home_blocks += [faq]
    elif ind == "automotive":
        home_blocks += [hours]
    else:
        home_blocks += [about, stats]
    home_blocks += [cta, _footer(name)]

    services_blocks = [_b("hero", {"headline": "Our services", "subheadline": "Everything we offer, explained simply.", "image": hero_img}, "c"),
                       _b("services_grid", {"headline": "Services", "items": services}, "b"), cta, _footer(name)]
    about_blocks = [about, team if ind in ("beauty_wellness", "professional_services", "fitness") else stats, blog, _footer(name)]
    contact_blocks = [_b("hero", {"headline": "Contact us", "subheadline": "We usually reply within one business day.", "image": cta_img}, "c"),
                      _form(name), hours if ind != "automotive" else mapb, _footer(name)]
    pages = [
        _page("home", "Home", home_blocks, name, tagline),
        _page("services", "Services", services_blocks, name, tagline),
        _page("about", "About", about_blocks, name, tagline),
        _page("contact", "Contact", contact_blocks, name, tagline),
    ]
    return {"theme": theme, "pages": pages, "nav_order": ["home", "services", "about", "contact"]}
