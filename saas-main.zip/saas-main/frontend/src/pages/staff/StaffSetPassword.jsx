import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Logo from "@/components/Logo";
import { toast } from "sonner";
import { KeyRound } from "lucide-react";
import usePageMeta from "@/hooks/usePageMeta";

/** Staff set-password page — consumes a single-use, short-lived invitation token. */
export default function StaffSetPassword() {
    const [params] = useSearchParams();
    const token = params.get("token") || "";
    const [password, setPassword] = useState("");
    const [confirm, setConfirm] = useState("");
    const [busy, setBusy] = useState(false);
    const [done, setDone] = useState(false);
    const navigate = useNavigate();
    usePageMeta("Set your staff password");

    async function submit(e) {
        e.preventDefault();
        if (password.length < 10) return toast.error("Use at least 10 characters.");
        if (password !== confirm) return toast.error("Passwords do not match.");
        setBusy(true);
        try {
            await api.post("/staff/auth/accept-invite", { token, password });
            setDone(true);
            toast.success("Password set — you can sign in now.");
        } catch (err) {
            toast.error(err?.response?.data?.detail?.message || err?.response?.data?.detail || "This link is invalid or has expired.");
        } finally {
            setBusy(false);
        }
    }

    return (
        <div className="min-h-screen grid place-items-center bg-zinc-50 px-4">
            <div className="w-full max-w-md rounded-2xl border border-brand-line bg-white p-8 shadow-sm">
                <div className="mb-6 flex items-center gap-3">
                    <Logo />
                    <span className="rounded-full bg-zinc-900 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-white">Staff</span>
                </div>
                <h1 className="text-xl font-semibold text-brand-ink flex items-center gap-2"><KeyRound className="h-5 w-5" /> Set your password</h1>
                <p className="mt-1 text-sm text-zinc-500">This invitation link works once and expires 48 hours after it was sent.</p>
                {!token ? (
                    <div className="mt-6 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900" data-testid="staff-setpw-missing">
                        No invitation token found in this link. Ask an admin to re-send your invitation.
                    </div>
                ) : done ? (
                    <div className="mt-6 space-y-4">
                        <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900" data-testid="staff-setpw-done">
                            Your password is set. Any older sessions for this account were signed out.
                        </div>
                        <Button className="w-full" onClick={() => navigate("/staff/login")} data-testid="staff-setpw-go-login">Go to staff sign in</Button>
                    </div>
                ) : (
                    <form onSubmit={submit} className="mt-6 space-y-4">
                        <div>
                            <Label htmlFor="pw">New password</Label>
                            <Input id="pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={10} autoComplete="new-password" className="mt-1" data-testid="staff-setpw-password" />
                        </div>
                        <div>
                            <Label htmlFor="pw2">Confirm password</Label>
                            <Input id="pw2" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required minLength={10} autoComplete="new-password" className="mt-1" data-testid="staff-setpw-confirm" />
                        </div>
                        <Button type="submit" className="w-full" disabled={busy} data-testid="staff-setpw-submit">{busy ? "Saving…" : "Set password"}</Button>
                    </form>
                )}
            </div>
        </div>
    );
}
