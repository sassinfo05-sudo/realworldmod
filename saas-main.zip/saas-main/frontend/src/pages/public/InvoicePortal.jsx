import { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, CreditCard, Loader2, ExternalLink } from "lucide-react";

const API = process.env.REACT_APP_BACKEND_URL;

function money(cents, currency = "USD") {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format((cents || 0) / 100);
}

export default function InvoicePortal() {
    const { iid } = useParams();
    const [params] = useSearchParams();
    const tk = params.get("tk");
    const navigate = useNavigate();
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [busy, setBusy] = useState(false);

    async function load() {
        try {
            const r = await fetch(`${API}/api/public/portal/invoice/${iid}?tk=${encodeURIComponent(tk)}`);
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            setData(await r.json());
        } catch (e) { setError(e.message); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [iid, tk]);

    async function startCheckout() {
        setBusy(true);
        try {
            const r = await fetch(`${API}/api/public/portal/invoice/${iid}/checkout?tk=${encodeURIComponent(tk)}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    invoice_id: iid,
                    provider: "simulated",
                    success_url: `/pay/success?iid=${iid}&tk=${encodeURIComponent(tk)}`,
                    cancel_url: `/pay/cancel?iid=${iid}&tk=${encodeURIComponent(tk)}`,
                }),
            });
            const d = await r.json();
            if (!r.ok) throw new Error(d.detail?.detail || d.detail || `HTTP ${r.status}`);
            // Navigate to simulated in-app checkout
            navigate(d.checkout_url);
        } catch (e) { setError(e.message); } finally { setBusy(false); }
    }

    if (error && !data) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-brand-surface p-6" data-testid="invoice-portal-error">
                <div className="max-w-md rounded-xl border border-brand-line bg-white p-8 text-center">
                    <XCircle className="w-8 h-8 text-red-500 mx-auto" />
                    <h1 className="font-display text-2xl text-brand-ink mt-3">This invoice link isn't valid.</h1>
                    <p className="text-sm text-zinc-500 mt-2">It may have expired. Please contact the business.</p>
                </div>
            </div>
        );
    }
    if (!data) {
        return <div className="min-h-screen flex items-center justify-center text-zinc-500"><Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading…</div>;
    }

    const inv = data.invoice;
    const outstanding = (inv.total_cents || 0) - (inv.amount_paid_cents || 0);
    const isPaid = inv.status === "paid" || outstanding <= 0;

    return (
        <div className="min-h-screen bg-brand-surface" data-testid="invoice-portal-page">
            <div className="max-w-2xl mx-auto py-8 md:py-16 px-4 md:px-6">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Invoice</div>
                <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium">
                    {inv.number || "Your invoice"}
                </h1>
                <p className="mt-2 text-sm text-zinc-500">
                    {data.business?.business_name ? `From ${data.business.business_name}. ` : ""}
                    {inv.due_at && !isPaid && (
                        <>Due <span className="font-mono">{new Date(inv.due_at).toLocaleDateString()}</span>.</>
                    )}
                </p>

                {isPaid && (
                    <div className="mt-6 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 flex items-start gap-3" data-testid="invoice-portal-paid-banner">
                        <CheckCircle2 className="w-5 h-5 mt-0.5" />
                        <div>
                            <div className="font-medium">Paid. Thank you!</div>
                            <div className="text-sm mt-0.5">A receipt has been emailed to you.</div>
                        </div>
                    </div>
                )}

                <div className="mt-6 rounded-2xl border border-brand-line bg-white overflow-hidden">
                    <div className="divide-y divide-brand-line">
                        {(inv.lines || []).map((l, idx) => (
                            <div key={l.id || idx} className="px-5 py-4 flex items-center justify-between gap-4" data-testid={`invoice-line-${idx}`}>
                                <div className="min-w-0">
                                    <div className="font-medium text-brand-ink truncate">{l.label}</div>
                                    {l.description && <div className="text-xs text-zinc-500 mt-0.5">{l.description}</div>}
                                    <div className="text-xs text-zinc-500 mt-0.5">{l.quantity} × {money(l.unit_price_cents, inv.currency)}</div>
                                </div>
                                <div className="font-mono text-sm text-brand-ink whitespace-nowrap">{money(l.quantity * l.unit_price_cents, inv.currency)}</div>
                            </div>
                        ))}
                    </div>
                    <div className="px-5 py-4 border-t border-brand-line bg-brand-cream/30 space-y-1">
                        <div className="flex justify-between text-sm"><span className="text-zinc-600">Subtotal</span><span className="font-mono">{money(inv.subtotal_cents, inv.currency)}</span></div>
                        {inv.tax_cents > 0 && <div className="flex justify-between text-sm"><span className="text-zinc-600">Tax</span><span className="font-mono">{money(inv.tax_cents, inv.currency)}</span></div>}
                        {inv.amount_paid_cents > 0 && <div className="flex justify-between text-sm text-emerald-700"><span>Paid</span><span className="font-mono">−{money(inv.amount_paid_cents, inv.currency)}</span></div>}
                        <div className="flex justify-between items-center pt-2 border-t border-brand-line">
                            <span className="text-brand-ink font-medium">{isPaid ? "Total" : "Amount due"}</span>
                            <span className="font-mono text-xl text-brand-ink" data-testid="invoice-portal-total">{money(isPaid ? inv.total_cents : outstanding, inv.currency)}</span>
                        </div>
                    </div>
                </div>

                {!isPaid && (
                    <div className="mt-6">
                        <Button
                            onClick={startCheckout}
                            disabled={busy}
                            className="w-full h-12 text-base bg-brand-copper hover:bg-brand-copperHover text-white"
                            data-testid="invoice-portal-pay-btn"
                        >
                            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CreditCard className="w-4 h-4 mr-2" />}
                            Pay {money(outstanding, inv.currency)}
                        </Button>
                        <div className="mt-2 text-xs text-zinc-500 flex items-center gap-1">
                            <ExternalLink className="w-3 h-3" /> Uses a simulated checkout — no real card is charged.
                        </div>
                    </div>
                )}
                {error && <div className="mt-4 rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm">{error}</div>}
            </div>
        </div>
    );
}
