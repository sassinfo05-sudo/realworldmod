"""Commerce depth routes (Round 10, Gate 4): tax rates, product CSV export, order notes/history,
returns (RMA), variant matrix generator, active stock reservations. Mounted under /api/store (owner)
and /api/public/store (public tax preview).
"""
from __future__ import annotations

import csv
import io
import uuid
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import current_user, require_org
from ..models import User
from ..services import commerce_ext as cx

router = APIRouter(prefix="/store", tags=["store-ext"])
public_router = APIRouter(prefix="/public/store", tags=["store-public-ext"])


# ---------------- tax rates ----------------

class TaxRate(BaseModel):
    country: str = Field(default="*", max_length=2)   # ISO-2 or '*'
    region: str = Field(default="", max_length=10)     # state/province code, optional
    pct: float = Field(ge=0, le=60)
    inclusive: bool = False                             # prices already include tax
    label: str = Field(default="Tax", max_length=40)


class TaxSettingsIn(BaseModel):
    rates: List[TaxRate] = Field(default_factory=list, max_length=100)
    display_inclusive: bool = False                    # storefront shows tax-inclusive prices


@router.get("/tax-rates")
async def get_tax_rates(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    doc = await db.store_tax_settings.find_one({"org_id": org_id}, {"_id": 0}) or {"rates": [], "display_inclusive": False}
    return {"rates": doc.get("rates", []), "display_inclusive": bool(doc.get("display_inclusive"))}


@router.put("/tax-rates")
async def put_tax_rates(req: TaxSettingsIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rates = [{**r.model_dump(), "country": (r.country or "*").upper(), "region": (r.region or "").upper()} for r in req.rates]
    await db.store_tax_settings.update_one({"org_id": org_id}, {"$set": {
        "org_id": org_id, "rates": rates, "display_inclusive": req.display_inclusive, "updated_at": utc_now_iso()}}, upsert=True)
    return {"ok": True, "rates": rates, "display_inclusive": req.display_inclusive}


@public_router.get("/{org_id}/tax-preview")
async def tax_preview(org_id: str, country: str = "", region: str = "", subtotal_cents: int = 0):
    db = get_db()
    return await cx.compute_tax(db, org_id, country, region, max(0, int(subtotal_cents)))


# ---------------- product CSV export ----------------

@router.get("/products/export.csv")
async def export_products_csv(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    buf = io.StringIO()
    w = csv.writer(buf)
    cols = ["id", "name", "description", "price", "compare_at_price", "currency", "stock", "track_inventory", "sku", "barcode",
            "weight_grams", "requires_shipping", "product_type", "digital_url", "image_url", "images", "tags", "collection_ids",
            "options", "variants", "active", "seo_title", "seo_description"]
    w.writerow(cols)
    import json as _json
    async for p in db.store_products.find({"org_id": org_id}).sort("created_at", 1):
        w.writerow([
            p["_id"], p.get("name", ""), p.get("description", ""), f"{int(p.get('price_cents', 0))/100:.2f}",
            f"{int(p.get('compare_at_cents', 0) or 0)/100:.2f}", p.get("currency", "USD"), int(p.get("stock", 0)),
            "true" if p.get("track_inventory", True) else "false", p.get("sku", ""), p.get("barcode", ""),
            int(p.get("weight_grams", 0) or 0), "true" if p.get("requires_shipping", True) else "false",
            p.get("product_type", "physical"), p.get("digital_url", ""), p.get("image_url", ""),
            "|".join(p.get("images", []) or []), "|".join(p.get("tags", []) or []), "|".join(p.get("collection_ids", []) or []),
            _json.dumps(p.get("options", []) or []), _json.dumps(p.get("variants", []) or []),
            "true" if p.get("active", True) else "false", p.get("seo_title", ""), p.get("seo_description", ""),
        ])
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": 'attachment; filename="zanelvo-products.csv"'})


# ---------------- variant matrix ----------------

class MatrixReq(BaseModel):
    options: List[Dict[str, Any]] = Field(default_factory=list, max_length=3)
    base_price_cents: int = Field(default=0, ge=0)
    base_stock: int = Field(default=0, ge=0)
    sku_prefix: str = Field(default="", max_length=20)


@router.post("/products/variant-matrix")
async def variant_matrix(req: MatrixReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    variants = cx.variant_matrix(req.options, req.base_price_cents, req.base_stock, req.sku_prefix)
    return {"variants": variants, "count": len(variants)}


# ---------------- reservations ----------------

@router.get("/reservations")
async def list_reservations(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    await cx.expire_reservations(db, org_id)
    rows = await db.stock_reservations.find({"org_id": org_id, "status": "active"}).sort("created_at", -1).to_list(200)
    for r in rows:
        r["id"] = r.pop("_id")
    return {"reservations": rows}


# ---------------- order notes / history / returns ----------------

class NoteIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


@router.post("/orders/{order_id}/notes")
async def add_order_note(order_id: str, req: NoteIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id}, {"_id": 1})
    if not o:
        raise HTTPException(404, "Order not found")
    note = {"id": uuid.uuid4().hex, "text": req.text.strip(), "author_id": user.id, "author": user.full_name or user.email,
            "at": utc_now_iso()}
    await db.store_orders.update_one({"_id": order_id}, {"$push": {"notes": note}, "$set": {"updated_at": utc_now_iso()}})
    return {"ok": True, "note": note}


@router.get("/orders/{order_id}/history")
async def order_history(order_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id},
                                       {"status_history": 1, "notes": 1, "status": 1, "returns": 1})
    if not o:
        raise HTTPException(404, "Order not found")
    return {"status": o.get("status"), "status_history": o.get("status_history", []), "notes": o.get("notes", []),
            "returns": o.get("returns", [])}


class ReturnIn(BaseModel):
    items: List[Dict[str, Any]] = Field(default_factory=list)   # [{product_id, qty, reason}]
    reason: str = Field(default="", max_length=500)
    restock: bool = True


@router.post("/orders/{order_id}/return")
async def request_return(order_id: str, req: ReturnIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """RMA: records a return against a paid/fulfilled order; optionally restocks. Refund money via /refund."""
    db = get_db()
    o = await db.store_orders.find_one({"_id": order_id, "org_id": org_id})
    if not o:
        raise HTTPException(404, "Order not found")
    if o.get("status") not in ("paid", "fulfilled", "refunded"):
        raise HTTPException(400, "Returns are only possible for paid or fulfilled orders")
    now = utc_now_iso()
    items = req.items or [{"product_id": it["product_id"], "qty": it["qty"], "reason": req.reason} for it in o.get("items", [])]
    rma = {"id": "RMA-" + uuid.uuid4().hex[:8].upper(), "items": items, "reason": req.reason, "restock": req.restock,
           "status": "received", "created_by": user.id, "created_at": now}
    if req.restock:
        for it in items:
            await db.store_products.update_one({"_id": it.get("product_id"), "org_id": org_id},
                                               {"$inc": {"stock": int(it.get("qty", 0))}, "$set": {"updated_at": now}})
    await db.store_orders.update_one({"_id": order_id}, {"$push": {"returns": rma}, "$set": {"updated_at": now}})
    await cx.push_status(db, order_id, "return_received", actor=user.email, note=f"{rma['id']}: {req.reason}"[:200])
    return {"ok": True, "return": rma}


# =========================== product feeds (Round 11) ===========================

class FeedsPatch(BaseModel):
    enabled: bool


@router.get("/feeds")
async def get_feeds(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Owner view of the public product feeds (Google Shopping XML + Meta/marketplace CSV)."""
    db = get_db()
    st = await db.store_settings.find_one({"org_id": org_id}) or {}
    return {"enabled": st.get("feeds_enabled", True) is not False,
            "xml_path": f"/api/public/store/{org_id}/feed.xml",
            "csv_path": f"/api/public/store/{org_id}/feed.csv"}


@router.put("/feeds")
async def put_feeds(req: FeedsPatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    await db.store_settings.update_one({"org_id": org_id},
                                       {"$set": {"feeds_enabled": bool(req.enabled), "updated_at": utc_now_iso()},
                                        "$setOnInsert": {"org_id": org_id}}, upsert=True)
    return await get_feeds(user=user, org_id=org_id)
