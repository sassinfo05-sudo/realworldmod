"""Simple in-process rate limiter. Enough for a single-worker dev/prod environment.

Not cluster-safe — a real deployment across N workers would want Redis-backed counters.
We fail closed (return 429) but honestly.
"""
from __future__ import annotations

import time
from collections import deque
from threading import Lock
from typing import Deque, Dict, Tuple

from fastapi import HTTPException, Request
from pymongo import ReturnDocument


_WINDOWS: Dict[Tuple[str, str], Deque[float]] = {}
_LOCK = Lock()


def _client_id(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    return request.client.host if request.client else "anon"


def check(bucket: str, request: Request, *, limit: int, window_seconds: int) -> None:
    """Raise 429 if the client has exceeded the bucket's limit in the sliding window."""
    key = (bucket, _client_id(request))
    now = time.time()
    cutoff = now - window_seconds
    with _LOCK:
        dq = _WINDOWS.setdefault(key, deque())
        while dq and dq[0] < cutoff:
            dq.popleft()
        if len(dq) >= limit:
            retry_in = int(dq[0] + window_seconds - now) + 1
            raise HTTPException(status_code=429, detail={
                "error": "rate_limited",
                "message": f"Too many attempts. Try again in {retry_in}s.",
                "retry_in_seconds": retry_in,
            })
        dq.append(now)


def check_or_pass(bucket: str, request: Request, *, limit: int, window_seconds: int) -> bool:
    try:
        check(bucket, request, limit=limit, window_seconds=window_seconds)
        return True
    except HTTPException:
        raise


# ---------------------------------------------------------------------------
# Persistent (multi-worker safe) limiter for security-sensitive buckets.
# Fixed windows stored in Mongo with atomic $inc; a TTL index expires old windows.
# Used for login / signup / password reset / 2FA — flows where an in-memory-only
# counter that resets on restart or differs per worker would be unsafe.
# ---------------------------------------------------------------------------
_PERSISTENT_INDEX_READY = False


async def check_persistent(bucket: str, request: Request, *, limit: int, window_seconds: int) -> None:
    global _PERSISTENT_INDEX_READY
    # Always apply the fast in-process check first (cheap, protects against bursts).
    check(bucket, request, limit=limit, window_seconds=window_seconds)
    try:
        from ..db import get_db
        from datetime import datetime, timezone
        db = get_db()
        if not _PERSISTENT_INDEX_READY:
            await db.rate_limits.create_index("expires_at", expireAfterSeconds=0)
            _PERSISTENT_INDEX_READY = True
        now = time.time()
        window_start = int(now // window_seconds) * window_seconds
        key = f"{bucket}:{_client_id(request)}:{window_start}"
        exp = datetime.fromtimestamp(window_start + window_seconds + 60, tz=timezone.utc)
        doc = await db.rate_limits.find_one_and_update(
            {"_id": key}, {"$inc": {"n": 1}, "$setOnInsert": {"expires_at": exp}},
            upsert=True, return_document=ReturnDocument.AFTER)
        if doc and int(doc.get("n", 0)) > limit:
            retry_in = int(window_start + window_seconds - now) + 1
            raise HTTPException(status_code=429, detail={
                "error": "rate_limited",
                "message": f"Too many attempts. Try again in {retry_in}s.",
                "retry_in_seconds": retry_in,
            })
    except HTTPException:
        raise
    except Exception:  # noqa: BLE001 — never fail open loudly; the in-memory check already ran
        pass


# ---------------------------------------------------------------------------
# Traffic observation (no cost, no PII): per path-group request counters for the
# staff health view. Path ids are collapsed so `/api/crm/contacts/<id>` groups together.
# ---------------------------------------------------------------------------
import re as _re  # noqa: E402

_OBS: Dict[str, int] = {}
_OBS_STARTED = time.time()
_ID_RE = _re.compile(r"/[0-9a-f]{24}(?=/|$)|/[0-9a-fA-F-]{36}(?=/|$)|/\d+(?=/|$)")


def observe(path: str) -> None:
    key = _ID_RE.sub("/{id}", path)
    with _LOCK:
        _OBS[key] = _OBS.get(key, 0) + 1
        if len(_OBS) > 2000:
            _OBS.clear()


def observed(top: int = 50) -> Dict[str, object]:
    with _LOCK:
        rows = sorted(_OBS.items(), key=lambda kv: -kv[1])[:top]
    return {"since": _OBS_STARTED, "total": sum(_OBS.values()),
            "top": [{"path": p, "count": c} for p, c in rows]}
