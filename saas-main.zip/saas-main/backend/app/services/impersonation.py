"""Impersonation session helpers + shared dep for founder-only routes.

- start(): creates a session with mandatory reason + 30-min hard expiry.
- current_session(): returns the currently-active session for a founder (if any).
- act_as_org(): dep that expands a founder token into a target org's context.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from bson import ObjectId
from fastapi import Depends, HTTPException

from ..db import get_db, utc_now_iso
from ..deps import current_user
from ..models import User

MAX_SESSION_MINUTES = 30


async def start(founder: User, target_org_id: str, reason: str) -> str:
    if founder.role != "platform_founder":
        raise HTTPException(403, "only platform founder can impersonate")
    reason = (reason or "").strip()
    if len(reason) < 6:
        raise HTTPException(422, "Reason is required (min 6 characters)")
    db = get_db()
    org = await db.organizations.find_one({"_id": ObjectId(target_org_id)})
    if not org:
        raise HTTPException(404, "Target organization not found")
    # Close any prior active sessions for this founder
    await db.impersonation_sessions.update_many(
        {"founder_user_id": founder.id, "active": True},
        {"$set": {"active": False, "ended_at": utc_now_iso(), "exit_reason": "replaced"}},
    )
    now = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=MAX_SESSION_MINUTES)
    doc = {
        "founder_user_id": founder.id,
        "target_org_id": target_org_id,
        "reason": reason,
        "started_at": now.isoformat().replace("+00:00", "Z"),
        "expires_at": expires.isoformat().replace("+00:00", "Z"),
        "active": True,
        "actions_count": 0,
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }
    r = await db.impersonation_sessions.insert_one(doc)
    return str(r.inserted_id)


async def end(founder: User, exit_reason: str = "manual") -> None:
    db = get_db()
    await db.impersonation_sessions.update_many(
        {"founder_user_id": founder.id, "active": True},
        {"$set": {"active": False, "ended_at": utc_now_iso(),
                    "exit_reason": exit_reason, "updated_at": utc_now_iso()}},
    )


async def current_session(founder: User) -> Optional[dict]:
    db = get_db()
    sess = await db.impersonation_sessions.find_one({"founder_user_id": founder.id,
                                                        "active": True})
    if not sess:
        return None
    try:
        exp = datetime.fromisoformat(sess["expires_at"].replace("Z", "+00:00"))
        if exp <= datetime.now(timezone.utc):
            await end(founder, exit_reason="expired")
            return None
    except Exception:  # noqa: BLE001
        pass
    return sess


async def touch(session_id: str) -> None:
    db = get_db()
    await db.impersonation_sessions.update_one(
        {"_id": ObjectId(session_id), "active": True},
        {"$inc": {"actions_count": 1}, "$set": {"updated_at": utc_now_iso()}},
    )


async def acting_org_id(user: User = Depends(current_user)) -> Optional[str]:
    """If founder has an active impersonation, returns the target org_id; else the
    caller's own org_id. NON-founders always get their own org_id (or None).
    """
    if user.role != "platform_founder":
        return user.org_id
    sess = await current_session(user)
    return sess["target_org_id"] if sess else None
