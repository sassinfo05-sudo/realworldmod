"""Inbox AI copilot — summarize / classify / draft-reply.

Every response is grounded in the org's BusinessProfile + conversation transcript,
and clearly labeled "AI draft — review before sending" in the UI. The service
NEVER auto-sends; every draft flows through the same send/schedule endpoints as
manual outbound.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .llm import generate_json, LlmError

logger = logging.getLogger(__name__)


def _transcript(messages: List[Dict[str, Any]]) -> str:
    lines: List[str] = []
    for m in messages[-30:]:  # last 30 messages max
        who = (m.get("direction") or "inbound")
        addr = m.get("from_addr") or {}
        who_line = f"[{who.upper()}] {(addr.get('name') or addr.get('email') or 'unknown')}"
        subj = m.get("subject") or ""
        body = (m.get("body_text") or _strip_html(m.get("body_html") or ""))[:1400]
        lines.append(f"{who_line}\nSubject: {subj}\n{body}\n---")
    return "\n".join(lines)[-8000:]


def _strip_html(html: str) -> str:
    import re as _re
    return _re.sub(r"<[^>]+>", "", html or "")


async def summarize_conversation(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
    system = (
        "You are a concise CRM inbox assistant. Summarize an email conversation in a way "
        "a small-business owner can act on in 10 seconds. Return STRICT JSON. Be factual — "
        "only mention specifics that appear in the transcript."
    )
    prompt = (
        f"TRANSCRIPT:\n{_transcript(messages)}\n\n"
        'Return JSON: {"summary": "<2-3 sentences, plain text>", '
        '"next_action": "<one line the owner should do next>", '
        '"unknowns": ["<a fact the customer hasn\'t provided yet>"]}'
    )
    try:
        data = await generate_json(system, prompt, max_retries=1)
        return {
            "summary": str(data.get("summary") or ""),
            "next_action": str(data.get("next_action") or ""),
            "unknowns": [str(u) for u in (data.get("unknowns") or [])][:5],
        }
    except LlmError as e:
        return {"summary": f"(AI summary unavailable: {e})", "next_action": "", "unknowns": []}


async def classify_message(message: Dict[str, Any], business: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    system = (
        "Classify a single inbound customer message. Return STRICT JSON. "
        "Confidence is 0-1. Never guess if there is not enough content — "
        "return intent='unclear' with a low confidence."
    )
    ctx_biz = "N/A"
    if business:
        ctx_biz = str({k: business.get(k) for k in ("business_name", "industry", "services")})
    body = message.get("body_text") or _strip_html(message.get("body_html") or "")
    prompt = (
        f"BUSINESS CONTEXT: {ctx_biz}\n"
        f"SUBJECT: {message.get('subject') or ''}\n"
        f"MESSAGE:\n{body[:3000]}\n\n"
        'Return JSON: {"intent": "quote|booking|support|complaint|info|spam|unclear", '
        '"urgency": "low|normal|high|urgent", "sentiment": "positive|neutral|negative", '
        '"confidence": <0-1>, "language": "<ISO code>"}'
    )
    try:
        data = await generate_json(system, prompt, max_retries=1)
        return {
            "intent": str(data.get("intent") or "unclear"),
            "urgency": str(data.get("urgency") or "normal"),
            "sentiment": str(data.get("sentiment") or "neutral"),
            "confidence": max(0.0, min(1.0, float(data.get("confidence") or 0.5))),
            "language": str(data.get("language") or "en")[:8],
        }
    except LlmError:
        return {"intent": "unclear", "urgency": "normal", "sentiment": "neutral",
                "confidence": 0.0, "language": "en"}


async def draft_reply(messages: List[Dict[str, Any]], business: Dict[str, Any],
                       owner_hint: Optional[str] = None) -> Dict[str, Any]:
    """Draft a reply the owner can review + send. NEVER invents facts.

    Grounding rules baked into the prompt:
    - Reference services / prices ONLY from `business.services`. If a service
      the customer asks about is missing, say "let me confirm and get back to you today".
    - Match the business tone (`business.tone`).
    - Keep it short (<= 160 words) and non-committal on schedules unless offered.
    - Do NOT invent phone numbers, addresses, or hours.
    """
    services = business.get("services") or []
    services_list = [{"name": s.get("name"), "price_display": s.get("price_display"),
                       "description": s.get("description")} for s in services][:20]
    system = (
        "You draft first-touch email replies for a small service business. RULES:\n"
        "1. Ground every fact in the BUSINESS_FACTS below. Prices come ONLY from the "
        "services list — DO NOT invent numbers. If a price/hours/policy is unknown, "
        "SAY the owner will confirm shortly.\n"
        "2. Match the tone. Keep replies short and warm (<= 160 words).\n"
        "3. Do NOT auto-schedule. Suggest 1-2 concrete next steps.\n"
        "4. Return STRICT JSON only.\n"
    )
    prompt = (
        f"BUSINESS_FACTS:\n"
        f"- name: {business.get('business_name')}\n"
        f"- tone: {business.get('tone') or 'calm_confident'}\n"
        f"- differentiators: {[d.get('text') for d in (business.get('differentiators') or [])][:5]}\n"
        f"- services: {services_list}\n"
        f"- contact_phone: {business.get('contact_phone') or 'unknown'}\n"
        f"- contact_email: {business.get('contact_email') or 'unknown'}\n\n"
        f"CONVERSATION:\n{_transcript(messages)}\n\n"
        f"OWNER HINT (optional): {owner_hint or 'none'}\n\n"
        'Return JSON: {"subject": "<short subject or Re: original>", '
        '"body_text": "<the reply as plain text>", '
        '"body_html": "<same content but with <p> paragraphs>", '
        '"facts_used": ["<which BUSINESS_FACTS you leaned on>"], '
        '"facts_missing": ["<a fact you explicitly said you would confirm>"]}'
    )
    try:
        data = await generate_json(system, prompt, max_retries=1)
        return {
            "subject": str(data.get("subject") or ""),
            "body_text": str(data.get("body_text") or ""),
            "body_html": str(data.get("body_html") or ""),
            "facts_used": [str(f) for f in (data.get("facts_used") or [])][:8],
            "facts_missing": [str(f) for f in (data.get("facts_missing") or [])][:8],
            "warning": "AI draft — review before sending.",
        }
    except LlmError as e:
        return {"subject": "", "body_text": "", "body_html": "",
                "facts_used": [], "facts_missing": [], "warning": f"AI unavailable: {e}"}


async def rewrite_message(text: str, action: str) -> str:
    """Actions: 'shorter' | 'longer' | 'warmer' | 'firmer' | 'translate:en' | 'translate:he'."""
    system = "You edit short business emails. Preserve intent. Return only the rewritten text — no preamble."
    lang = None
    if action.startswith("translate:"):
        lang = action.split(":", 1)[1]
    instruction = {
        "shorter": "Rewrite the email 30% shorter without losing meaning.",
        "longer": "Expand slightly (max 40% longer) to add polite context.",
        "warmer": "Rewrite with a warmer, more welcoming tone. Keep it professional.",
        "firmer": "Rewrite with a firmer, more direct tone. Stay respectful.",
    }.get(action)
    if lang:
        instruction = f"Translate to {lang}. Keep the original tone. Return only the translation."
    if not instruction:
        return text
    prompt = f"{instruction}\n\nORIGINAL:\n{text}"
    try:
        from .llm import generate_text
        return (await generate_text(system, prompt)).strip()
    except Exception:  # noqa: BLE001
        return text
