import InsightsDashboard from "@/components/InsightsDashboard";
import { useEffect, useState } from "react";
import { authHeaders } from "@/lib/api";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Send, Zap, Sparkles, Play, Pause, Download, FlaskConical, BarChart3, Plus, Trash2, ArrowUp, ArrowDown, Type, Heading, Image as ImageIcon, MousePointerClick, Minus, LayoutList } from "lucide-react";

// ---- Block-based email editor (Round 13) ----
const NEW_BLOCK = {
    heading: () => ({ type: "heading", text: "Your headline" }),
    text: () => ({ type: "text", text: "Write your message here. Links become tracked automatically." }),
    button: () => ({ type: "button", text: "Shop now", href: "https://" }),
    image: () => ({ type: "image", src: "https://", href: "", alt: "" }),
    divider: () => ({ type: "divider" }),
    spacer: () => ({ type: "spacer", size: 24 }),
};

function BlockEmailEditor({ blocks, setBlocks }) {
    const update = (i, patch) => setBlocks(blocks.map((b, idx) => (idx === i ? { ...b, ...patch } : b)));
    const remove = (i) => setBlocks(blocks.filter((_, idx) => idx !== i));
    const move = (i, dir) => {
        const j = i + dir;
        if (j < 0 || j >= blocks.length) return;
        const next = [...blocks];
        [next[i], next[j]] = [next[j], next[i]];
        setBlocks(next);
    };
    const add = (type) => setBlocks([...blocks, NEW_BLOCK[type]()]);
    const fieldCls = "w-full border border-brand-line rounded-md px-2 py-1.5 text-sm";
    const addBtns = [
        ["heading", Heading, "Heading"], ["text", Type, "Text"], ["button", MousePointerClick, "Button"],
        ["image", ImageIcon, "Image"], ["divider", Minus, "Divider"], ["spacer", LayoutList, "Spacer"],
    ];
    return (
        <div className="space-y-2" data-testid="email-block-editor">
            <div className="flex flex-wrap gap-1.5">
                {addBtns.map(([t, Icon, label]) => (
                    <button key={t} type="button" onClick={() => add(t)} data-testid={`email-add-${t}`}
                        className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-md border border-brand-line text-zinc-600 hover:bg-brand-cream/40">
                        <Icon className="w-3.5 h-3.5" /> {label}
                    </button>
                ))}
            </div>
            {blocks.length === 0 && <div className="text-xs text-zinc-400 py-3 text-center border border-dashed border-brand-line rounded-md">Add blocks to build your email.</div>}
            {blocks.map((b, i) => (
                <div key={i} className="rounded-md border border-brand-line p-2.5 bg-white space-y-2" data-testid={`email-block-${i}`}>
                    <div className="flex items-center justify-between">
                        <span className="text-[11px] font-medium uppercase tracking-wide text-zinc-500">{b.type}</span>
                        <div className="flex items-center gap-1">
                            <button type="button" onClick={() => move(i, -1)} className="p-1 text-zinc-400 hover:text-zinc-700" data-testid={`email-block-up-${i}`}><ArrowUp className="w-3.5 h-3.5" /></button>
                            <button type="button" onClick={() => move(i, 1)} className="p-1 text-zinc-400 hover:text-zinc-700" data-testid={`email-block-down-${i}`}><ArrowDown className="w-3.5 h-3.5" /></button>
                            <button type="button" onClick={() => remove(i)} className="p-1 text-zinc-400 hover:text-red-600" data-testid={`email-block-del-${i}`}><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                    </div>
                    {b.type === "heading" && <input className={fieldCls} value={b.text || ""} onChange={(e) => update(i, { text: e.target.value })} placeholder="Headline" data-testid={`email-field-heading-${i}`} />}
                    {b.type === "text" && <textarea rows={3} className={fieldCls} value={b.text || ""} onChange={(e) => update(i, { text: e.target.value })} placeholder="Body text" data-testid={`email-field-text-${i}`} />}
                    {b.type === "button" && (
                        <div className="grid grid-cols-2 gap-2">
                            <input className={fieldCls} value={b.text || ""} onChange={(e) => update(i, { text: e.target.value })} placeholder="Label" data-testid={`email-field-btnlabel-${i}`} />
                            <input className={fieldCls} value={b.href || ""} onChange={(e) => update(i, { href: e.target.value })} placeholder="https://link" data-testid={`email-field-btnhref-${i}`} />
                        </div>
                    )}
                    {b.type === "image" && (
                        <div className="space-y-2">
                            <input className={fieldCls} value={b.src || ""} onChange={(e) => update(i, { src: e.target.value })} placeholder="Image URL (https://)" data-testid={`email-field-imgsrc-${i}`} />
                            <div className="grid grid-cols-2 gap-2">
                                <input className={fieldCls} value={b.href || ""} onChange={(e) => update(i, { href: e.target.value })} placeholder="Link when clicked (optional)" />
                                <input className={fieldCls} value={b.alt || ""} onChange={(e) => update(i, { alt: e.target.value })} placeholder="Alt text" />
                            </div>
                        </div>
                    )}
                    {b.type === "spacer" && (
                        <input type="number" min={4} max={80} className={fieldCls + " w-28"} value={b.size ?? 24} onChange={(e) => update(i, { size: Number(e.target.value) })} placeholder="Height px" />
                    )}
                    {b.type === "divider" && <div className="text-xs text-zinc-400">A horizontal divider line.</div>}
                </div>
            ))}
        </div>
    );
}

function EmailPreview({ blocks }) {
    const [html, setHtml] = useState("");
    useEffect(() => {
        if (!blocks || blocks.length === 0) { setHtml(""); return; }
        const t = setTimeout(async () => {
            try {
                const { data } = await api.post("/marketing/campaigns/preview", { blocks });
                setHtml(data.html || "");
            } catch { /* noop */ }
        }, 500);
        return () => clearTimeout(t);
    }, [blocks]);
    if (!html) return null;
    return (
        <div className="rounded-lg border border-brand-line overflow-hidden" data-testid="email-preview">
            <div className="text-[11px] uppercase tracking-wide text-zinc-500 px-2 py-1 bg-brand-cream/30 border-b border-brand-line">Live preview</div>
            <iframe title="Email preview" srcDoc={html} className="w-full h-80 bg-white" sandbox="" />
        </div>
    );
}

function CampaignsTab() {
    const [items, setItems] = useState([]);
    const [name, setName] = useState("");
    const [subject, setSubject] = useState("");
    const [body, setBody] = useState("");
    const [tag, setTag] = useState("");
    const [busy, setBusy] = useState(false);
    const [abTest, setAbTest] = useState(false);
    const [subjectB, setSubjectB] = useState("");
    const [bodyB, setBodyB] = useState("");
    const [analytics, setAnalytics] = useState(null);
    const [aBusy, setABusy] = useState(false);
    const [blockMode, setBlockMode] = useState(false);
    const [blocks, setBlocks] = useState([]);

    async function load() {
        const { data } = await api.get("/marketing/campaigns");
        setItems(data.campaigns || []);
    }
    useEffect(() => { load(); }, []);

    async function create() {
        setBusy(true);
        try {
            const payload = { name, subject, body_text: body, segment: tag ? { tag } : {} };
            if (blockMode && blocks.length) payload.blocks = blocks;
            if (abTest && subjectB) {
                payload.ab_test = true;
                payload.variants = [
                    { key: "A", subject, body_text: body },
                    { key: "B", subject: subjectB, body_text: bodyB || body },
                ];
            }
            await api.post("/marketing/campaigns", payload);
            toast.success(abTest ? "A/B draft created" : "Draft created");
            setName(""); setSubject(""); setBody(""); setTag(""); setSubjectB(""); setBodyB(""); setAbTest(false);
            setBlocks([]); setBlockMode(false);
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); }
        finally { setBusy(false); }
    }
    async function aiAssist() {
        setBusy(true);
        try {
            const { data } = await api.post("/marketing/campaigns/ai-assist", {
                goal: name || "Reach out to happy customers", tone: "friendly",
            });
            if (data.subject) setSubject(data.subject);
            if (data.body_text) setBody(data.body_text);
        } catch (e) { toast.error("AI unavailable"); }
        finally { setBusy(false); }
    }
    async function send(id) {
        if (!window.confirm("Send now?")) return;
        try {
            const { data } = await api.post(`/marketing/campaigns/${id}/send`);
            toast.success(`Sent to ${data.metrics?.sent || 0} recipients`);
            load();
        } catch (e) { toast.error(e?.response?.data?.detail?.message || e?.response?.data?.detail || "Failed"); }
    }
    async function openAnalytics(id) {
        setABusy(true); setAnalytics({ loading: true });
        try {
            const { data } = await api.get(`/marketing/campaigns/${id}/analytics`);
            setAnalytics(data);
        } catch (e) { toast.error("Failed to load analytics"); setAnalytics(null); }
        finally { setABusy(false); }
    }
    const inputCls = "w-full border border-brand-line rounded-lg px-3 py-2 text-sm";

    return (
        <div data-testid="campaigns-tab" className="space-y-6">
            <div className="rounded-lg border border-brand-line bg-white p-4 space-y-2">
                <div className="text-xs uppercase tracking-widest text-zinc-500">New campaign</div>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Campaign name" data-testid="camp-name" />
                <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder={abTest ? "Variant A — subject line" : "Subject line"} data-testid="camp-subject" />
                <div className="inline-flex rounded-lg border border-brand-line overflow-hidden text-xs" data-testid="camp-design-toggle">
                    <button type="button" onClick={() => setBlockMode(false)} className={`px-3 py-1.5 ${!blockMode ? "bg-brand-copper text-white" : "text-zinc-600"}`} data-testid="camp-mode-text">Simple text</button>
                    <button type="button" onClick={() => setBlockMode(true)} className={`px-3 py-1.5 ${blockMode ? "bg-brand-copper text-white" : "text-zinc-600"}`} data-testid="camp-mode-blocks">Blocks (drag &amp; design)</button>
                </div>
                {!blockMode ? (
                    <Textarea rows={4} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Body text — links become tracked & UTM-tagged automatically" data-testid="camp-body" />
                ) : (
                    <div className="grid md:grid-cols-2 gap-3">
                        <BlockEmailEditor blocks={blocks} setBlocks={setBlocks} />
                        <EmailPreview blocks={blocks} />
                    </div>
                )}
                <label className="flex items-center gap-2 text-sm text-brand-ink pt-1 cursor-pointer">
                    <input type="checkbox" checked={abTest} onChange={(e) => setAbTest(e.target.checked)} data-testid="camp-ab-toggle" />
                    <span className="flex items-center gap-1"><FlaskConical className="w-3.5 h-3.5 text-indigo-600" /> A/B test two versions (split 50/50, auto-pick a winner)</span>
                </label>
                {abTest && (
                    <div className="rounded-lg border border-indigo-100 bg-indigo-50/50 p-3 space-y-2" data-testid="camp-variant-b">
                        <div className="text-[11px] font-medium text-indigo-800 uppercase tracking-wide">Variant B</div>
                        <Input value={subjectB} onChange={(e) => setSubjectB(e.target.value)} placeholder="Variant B — subject line" data-testid="camp-subject-b" />
                        <Textarea rows={3} value={bodyB} onChange={(e) => setBodyB(e.target.value)} placeholder="Variant B body (leave blank to reuse A's body)" data-testid="camp-body-b" />
                    </div>
                )}
                <div className="flex gap-2 items-center">
                    <Label className="text-xs whitespace-nowrap">Filter by tag (optional):</Label>
                    <Input className="w-48" value={tag} onChange={(e) => setTag(e.target.value)} placeholder="e.g. hot" data-testid="camp-tag" />
                </div>
                <div className="flex gap-2">
                    <Button size="sm" variant="ghost" onClick={aiAssist} disabled={busy} data-testid="camp-ai-btn">
                        <Sparkles className="w-3.5 h-3.5 mr-1" /> AI assist
                    </Button>
                    <Button size="sm" onClick={create} disabled={busy || !name || !subject} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="camp-create-btn">
                        Create draft
                    </Button>
                </div>
            </div>
            <div className="border border-brand-line rounded-lg bg-white overflow-hidden divide-y">
                {items.map((c) => (
                    <div key={c.id} className="p-3 flex items-center gap-3" data-testid={`campaign-${c.id}`}>
                        <div className="flex-1">
                            <div className="text-sm font-medium text-brand-ink flex items-center gap-2">
                                {c.name}
                                {c.ab_test && <Badge variant="outline" className="text-[9px] border-indigo-300 text-indigo-700">A/B</Badge>}
                            </div>
                            <div className="text-xs text-zinc-500">{c.subject}</div>
                            {c.metrics?.sent > 0 && (
                                <div className="text-[10px] text-zinc-600 mt-0.5 font-mono">
                                    sent {c.metrics.sent} · opens {c.metrics.unique_opens || 0} · clicks {c.metrics.unique_clicks || 0}
                                    {c.metrics.revenue_cents ? ` · $${(c.metrics.revenue_cents / 100).toFixed(0)} rev` : ""}
                                </div>
                            )}
                        </div>
                        <Badge variant="outline" className="text-[10px] capitalize">{c.status}</Badge>
                        {c.status === "sent" && (
                            <Button size="sm" variant="ghost" onClick={() => openAnalytics(c.id)} data-testid={`campaign-${c.id}-analytics`}>
                                <BarChart3 className="w-3.5 h-3.5 mr-1" /> Analytics
                            </Button>
                        )}
                        {c.status === "draft" && (
                            <Button size="sm" onClick={() => send(c.id)} data-testid={`campaign-${c.id}-send`}>
                                <Send className="w-3.5 h-3.5 mr-1" /> Send
                            </Button>
                        )}
                    </div>
                ))}
                {!items.length && <div className="text-center text-zinc-500 py-8 text-sm">No campaigns yet.</div>}
            </div>

            {analytics && (
                <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setAnalytics(null)} data-testid="analytics-modal">
                    <div className="bg-white rounded-2xl max-w-lg w-full p-6 max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                        {analytics.loading || aBusy ? <div className="text-center py-10 text-zinc-500">Loading analytics…</div> : (
                            <>
                                <div className="flex items-start justify-between">
                                    <div>
                                        <div className="text-xs uppercase tracking-widest text-zinc-500">Campaign analytics</div>
                                        <h3 className="text-lg font-semibold text-brand-ink">{analytics.name}</h3>
                                    </div>
                                    <button onClick={() => setAnalytics(null)} className="text-zinc-400 hover:text-zinc-700 text-xl leading-none">&times;</button>
                                </div>
                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
                                    {[
                                        ["Sent", analytics.analytics?.sent],
                                        ["Open rate", `${analytics.analytics?.open_rate ?? 0}%`],
                                        ["Click rate", `${analytics.analytics?.click_rate ?? 0}%`],
                                        ["Revenue", `$${analytics.analytics?.revenue ?? 0}`],
                                    ].map(([l, v]) => (
                                        <div key={l} className="rounded-lg border border-brand-line p-2 text-center">
                                            <div className="text-[10px] text-zinc-500 uppercase">{l}</div>
                                            <div className="text-lg font-semibold text-brand-ink">{v}</div>
                                        </div>
                                    ))}
                                </div>
                                <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs text-zinc-600">
                                    <div>Opens: <b>{analytics.analytics?.unique_opens}</b></div>
                                    <div>Clicks: <b>{analytics.analytics?.unique_clicks}</b></div>
                                    <div>Sales: <b>{analytics.analytics?.conversions}</b></div>
                                </div>
                                {analytics.analytics?.variants?.length > 0 && (
                                    <div className="mt-5">
                                        <div className="text-sm font-medium text-brand-ink mb-2 flex items-center gap-2">
                                            <FlaskConical className="w-4 h-4 text-indigo-600" /> A/B results
                                            {analytics.analytics.ab_winner && <Badge className="bg-emerald-600 text-white text-[10px]">Winner: {analytics.analytics.ab_winner}</Badge>}
                                        </div>
                                        <div className="space-y-2">
                                            {analytics.analytics.variants.map((v) => (
                                                <div key={v.key} className={`rounded-lg border p-2 ${analytics.analytics.ab_winner === v.key ? "border-emerald-400 bg-emerald-50" : "border-brand-line"}`}>
                                                    <div className="flex justify-between text-sm">
                                                        <span className="font-medium">Variant {v.key}</span>
                                                        <span className="text-zinc-500 text-xs">{v.sent} sent</span>
                                                    </div>
                                                    <div className="text-xs text-zinc-600 mt-1">Open {v.open_rate}% · Click {v.click_rate}% · {v.conversions} sales · ${v.revenue}</div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                                {analytics.recent?.length > 0 && (
                                    <div className="mt-5">
                                        <div className="text-xs font-medium text-zinc-500 uppercase mb-1">Recent engagement</div>
                                        <div className="space-y-1 max-h-40 overflow-y-auto">
                                            {analytics.recent.map((r, i) => (
                                                <div key={i} className="flex justify-between text-xs border-b border-brand-line/60 py-1">
                                                    <span className="truncate">{r.email}{r.variant ? ` (${r.variant})` : ""}</span>
                                                    <span className="text-zinc-500">{r.click_count ? `🖱 ${r.click_count}` : ""} {r.open_count ? `👁 ${r.open_count}` : ""}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

function AutomationsTab() {
    const [items, setItems] = useState([]);
    async function load() {
        const { data } = await api.get("/marketing/automations");
        setItems(data.automations || []);
    }
    useEffect(() => { load(); }, []);
    async function toggle(a) {
        try {
            await api.post(`/marketing/automations/${a.id}/${a.status === "paused" ? "publish" : "pause"}`);
            load();
        } catch { /* toast */ }
    }
    return (
        <div data-testid="automations-tab" className="space-y-3">
            <div className="text-xs text-zinc-500">
                Linear workflows: trigger → optional condition → 1-3 actions. Seed includes two templates.
            </div>
            <div className="border border-brand-line rounded-lg bg-white divide-y">
                {items.map((a) => (
                    <div key={a.id} className="p-3 flex items-center gap-3" data-testid={`automation-${a.id}`}>
                        <div className="flex-1">
                            <div className="text-sm font-medium text-brand-ink">{a.name}</div>
                            <div className="text-xs text-zinc-500 font-mono">
                                trigger: {a.trigger} · actions: {(a.actions || []).map((x) => x.type).join(", ")}
                            </div>
                        </div>
                        <Badge variant="outline" className="text-[10px] capitalize">{a.status}</Badge>
                        <Button size="sm" variant="ghost" onClick={() => toggle(a)} data-testid={`automation-${a.id}-toggle`}>
                            {a.status === "paused" ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                        </Button>
                    </div>
                ))}
                {!items.length && <div className="text-center text-zinc-500 py-8 text-sm">No automations.</div>}
            </div>
        </div>
    );
}

function CreativeTab() {
    const [name, setName] = useState("");
    const [offer, setOffer] = useState("");
    const [audience, setAudience] = useState("");
    const [languages, setLanguages] = useState(["en"]);
    const [busy, setBusy] = useState(false);
    const [bundles, setBundles] = useState([]);

    async function load() {
        const { data } = await api.get("/marketing/creative/bundles");
        setBundles(data.bundles || []);
    }
    useEffect(() => { load(); }, []);

    async function generate() {
        setBusy(true);
        try {
            await api.post("/marketing/creative/generate", {
                name, offer, audience, languages,
            });
            toast.success("Bundle generated");
            setName(""); setOffer(""); setAudience("");
            load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); }
        finally { setBusy(false); }
    }
    async function exportBundle(id) {
        if (busy) return;
        setBusy(true);
        try {
            const BASE = process.env.REACT_APP_BACKEND_URL;
                        const r = await fetch(`${BASE}/api/marketing/creative/bundles/${id}/export`, {
                headers: authHeaders(), credentials: "include",
            });
            if (!r.ok) {
                const t = await r.text().catch(() => "");
                throw new Error(t || `export failed (${r.status})`);
            }
            const raw = await r.blob();
            // Some proxies drop content-type; force application/zip so the browser
            // treats the blob as a downloadable file consistently.
            const blob = new Blob([raw], { type: "application/zip" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `creative-${id}.zip`;
            a.rel = "noopener";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            toast.success("Export downloaded");
        } catch (e) {
            toast.error(e?.message || "Export failed");
        } finally {
            setBusy(false);
        }
    }
    function toggleLang(l) {
        setLanguages(languages.includes(l) ? languages.filter((x) => x !== l) : [...languages, l]);
    }
    return (
        <div data-testid="creative-tab" className="space-y-4">
            <div className="rounded-lg border border-brand-line bg-white p-4 space-y-2">
                <div className="text-xs uppercase tracking-widest text-zinc-500">Generate ad bundle</div>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Campaign name" data-testid="creative-name" />
                <Input value={offer} onChange={(e) => setOffer(e.target.value)} placeholder="Offer (e.g. 20% off first job)" data-testid="creative-offer" />
                <Input value={audience} onChange={(e) => setAudience(e.target.value)} placeholder="Target audience" data-testid="creative-audience" />
                <div className="flex gap-2 items-center flex-wrap">
                    <Label className="text-xs">Languages:</Label>
                    {["en", "es", "he"].map((l) => (
                        <label key={l} className="text-xs flex items-center gap-1">
                            <input type="checkbox" checked={languages.includes(l)} onChange={() => toggleLang(l)} data-testid={`creative-lang-${l}`} />
                            {l.toUpperCase()}
                        </label>
                    ))}
                    <span className="text-[10px] text-amber-700 ml-auto">Images = DEMO placeholders</span>
                    <span className="text-[10px] font-semibold uppercase tracking-widest text-white bg-amber-600 px-1.5 py-0.5 rounded" data-testid="video-mocked-badge">
                        Video — MOCKED · demo output only
                    </span>
                </div>
                <Button size="sm" onClick={generate} disabled={busy || !offer || !audience} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="creative-gen-btn">
                    <Zap className="w-3.5 h-3.5 mr-1" /> Generate
                </Button>
            </div>
            <div className="space-y-3">
                {bundles.map((b) => (
                    <div key={b.id} className="rounded-lg border border-brand-line bg-white p-4" data-testid={`bundle-${b.id}`}>
                        <div className="flex items-center justify-between mb-2">
                            <div className="text-sm font-medium text-brand-ink">{b.name}</div>
                            <Button size="sm" variant="ghost" onClick={() => exportBundle(b.id)} data-testid={`bundle-${b.id}-export`}>
                                <Download className="w-3.5 h-3.5 mr-1" /> Export ZIP
                            </Button>
                        </div>
                        <div className="text-xs text-zinc-500 mb-2">{b.offer} · {b.audience}</div>
                        <div className="grid md:grid-cols-2 gap-2">
                            {(b.copy_variants || []).map((cv, i) => (
                                <div key={i} dir={cv.lang === "he" ? "rtl" : "ltr"}
                                        className="text-xs bg-brand-cream border border-brand-line rounded p-2">
                                    <div className="text-[10px] uppercase tracking-widest text-brand-copper mb-1">{cv.lang}</div>
                                    <div className="font-medium">{cv.headline}</div>
                                    <div className="text-zinc-600 mt-1">{cv.body}</div>
                                    <div className="text-brand-copper mt-1">{cv.cta}</div>
                                </div>
                            ))}
                        </div>
                        <div className="mt-2 text-[10px] text-zinc-500">
                            Providers — Google Ads: <span className="font-mono">{b.provider_state?.google_ads}</span> · Meta: <span className="font-mono">{b.provider_state?.meta_ads}</span> · image_gen: <span className="font-mono">{b.provider_state?.image_gen}</span> · video_gen: <span className="font-mono">{b.provider_state?.video_gen || "not_connected"}</span>
                        </div>
                    </div>
                ))}
                {!bundles.length && <div className="text-center text-zinc-500 py-6 text-sm">No bundles yet.</div>}
            </div>
        </div>
    );
}

function MarketingBase() {
    const [tab, setTab] = useState("campaigns");
    return (
        <div className="p-6 max-w-6xl" data-testid="marketing-page">
            <div className="mb-4">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">Marketing</div>
                <h1 className="mt-1 font-display text-2xl text-brand-ink">Campaigns, Automations, Creative</h1>
            </div>
            <div className="mb-4 flex gap-1">
                {[
                    { k: "campaigns", label: "Campaigns" },
                    { k: "automations", label: "Automations" },
                    { k: "creative", label: "Creative Studio" },
                ].map((t) => (
                    <button
                        key={t.k}
                        onClick={() => setTab(t.k)}
                        data-testid={`marketing-tab-${t.k}`}
                        className={`text-sm px-3 py-1.5 rounded-md ${
                            tab === t.k ? "bg-brand-cream text-brand-ink font-medium" : "text-zinc-500 hover:text-brand-ink"
                        }`}
                    >{t.label}</button>
                ))}
            </div>
            {tab === "campaigns" && <CampaignsTab />}
            {tab === "automations" && <AutomationsTab />}
            {tab === "creative" && <CreativeTab />}
        </div>
    );
}


// Dashboard wrapper: real stat cards + trend chart on top of the feature page.
export default function Marketing() {
    return (
        <>
            <div className="px-4 md:px-8 pt-6">
                <InsightsDashboard area="marketing" title="Marketing" subtitle="Campaigns, automations and ad creative — with real send, conversion and revenue attribution numbers." color="#EF4444" seriesKey="sends" seriesFormat="int" breakdownTitle="Traffic sources" breakdownFormat="int" />
            </div>
            <MarketingBase />
        </>
    );
}
