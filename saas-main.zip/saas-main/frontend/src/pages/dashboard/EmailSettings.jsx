import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Send, Trash2 } from "lucide-react";

function ProviderCard({ p, active, onPick }) {
    return (
        <button onClick={() => onPick(p.key)}
                data-testid={`provider-card-${p.key}`}
                className={`text-left p-4 rounded-lg border-2 ${active ? "border-brand-copper bg-brand-cream/40" : "border-brand-line bg-white"} hover:border-brand-copper transition-colors`}>
            <div className="flex items-center justify-between">
                <div className="text-sm font-medium">{p.label}</div>
                <Badge variant={p.is_connected ? "default" : "secondary"}
                       className={p.is_connected ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-600"}
                       data-testid={`provider-status-${p.key}`}>
                    {p.is_connected ? "Connected" : "Not connected"}
                </Badge>
            </div>
            <div className="text-xs text-zinc-600 mt-2">{p.honest_status}</div>
            <div className="text-[10px] text-zinc-400 mt-1">{p.docs}</div>
        </button>
    );
}

export default function EmailSettings() {
    const [providers, setProviders] = useState([]);
    const [cfg, setCfg] = useState(null);
    const [suppressions, setSuppressions] = useState([]);
    const [testResult, setTestResult] = useState(null);
    const [testTo, setTestTo] = useState("");
    const [busy, setBusy] = useState(false);

    async function load() {
        const [p, c, s] = await Promise.all([
            api.get("/email/providers"),
            api.get("/email/config"),
            api.get("/email/suppressions"),
        ]);
        setProviders(p.data.providers || []);
        setCfg(c.data);
        setSuppressions(s.data.suppressions || []);
    }
    useEffect(() => { load(); }, []);

    async function saveCfg(patch) {
        await api.patch("/email/config", patch);
        toast.success("Saved");
        load();
    }

    async function testSend() {
        setBusy(true);
        try {
            const { data } = await api.post("/email/test-send", { to: testTo, subject: "Zanelvo test", body_text: "Test message from Zanelvo." });
            setTestResult(data);
            (data.ok ? toast.success : toast.error)(data.message);
        } catch (e) { toast.error("Test send failed"); } finally { setBusy(false); }
    }

    async function addSuppression() {
        const e = prompt("Email to suppress?", "");
        if (!e) return;
        await api.post("/email/suppressions", { email: e, reason: "manual" });
        toast.success("Added to suppression list");
        load();
    }

    async function removeSuppression(email) {
        if (!window.confirm(`Remove ${email} from suppression list?`)) return;
        await api.delete(`/email/suppressions/${encodeURIComponent(email)}`);
        toast.success("Removed");
        load();
    }

    if (!cfg) return <div className="p-6 text-zinc-500">Loading…</div>;

    return (
        <div className="p-6 space-y-8 max-w-4xl" data-testid="email-settings-page">
            <div>
                <h2 className="text-lg font-medium text-brand-ink">Business email</h2>
                <p className="text-sm text-zinc-500">Configure how outbound emails are sent from your workspace.</p>
            </div>

            <section>
                <h2 className="text-sm font-medium mb-2">Provider</h2>
                <div className="grid md:grid-cols-3 gap-3">
                    {providers.map((p) => (
                        <ProviderCard key={p.key} p={p} active={cfg.provider === p.key}
                                        onPick={(k) => saveCfg({ provider: k })} />
                    ))}
                </div>
            </section>

            <section className="space-y-3">
                <h2 className="text-sm font-medium">From identity</h2>
                <div className="grid md:grid-cols-2 gap-3">
                    <Input placeholder="From email" defaultValue={cfg.from_email || ""}
                           onBlur={(e) => saveCfg({ from_email: e.target.value })}
                           data-testid="cfg-from-email" />
                    <Input placeholder="From name" defaultValue={cfg.from_name || ""}
                           onBlur={(e) => saveCfg({ from_name: e.target.value })}
                           data-testid="cfg-from-name" />
                    <Input placeholder="Reply-To (optional)" defaultValue={cfg.reply_to || ""}
                           onBlur={(e) => saveCfg({ reply_to: e.target.value })}
                           data-testid="cfg-reply-to" />
                </div>
            </section>

            {cfg.provider === "resend" && (
                <section className="space-y-3">
                    <h2 className="text-sm font-medium">Resend</h2>
                    <Input type="password" placeholder={cfg.resend_api_key_set ? "•••••• (set)" : "re_..."}
                           onBlur={(e) => e.target.value && saveCfg({ resend_api_key: e.target.value })}
                           data-testid="cfg-resend-key" />
                    <div className="text-[10px] text-zinc-500">Get at resend.com/api-keys</div>
                </section>
            )}

            {cfg.provider === "smtp" && (
                <section className="space-y-3">
                    <h2 className="text-sm font-medium">SMTP</h2>
                    <div className="grid md:grid-cols-2 gap-3">
                        <Input placeholder="Host" defaultValue={cfg.smtp_host || ""}
                               onBlur={(e) => e.target.value && saveCfg({ smtp_host: e.target.value })} data-testid="cfg-smtp-host" />
                        <Input placeholder="Port" type="number" defaultValue={cfg.smtp_port || ""}
                               onBlur={(e) => e.target.value && saveCfg({ smtp_port: parseInt(e.target.value) })} data-testid="cfg-smtp-port" />
                        <Input placeholder="Username" defaultValue={cfg.smtp_username || ""}
                               onBlur={(e) => saveCfg({ smtp_username: e.target.value })} />
                        <Input type="password" placeholder={cfg.smtp_password_set ? "•••••• (set)" : "Password"}
                               onBlur={(e) => e.target.value && saveCfg({ smtp_password: e.target.value })} />
                    </div>
                </section>
            )}

            <section className="rounded-lg border border-brand-line bg-white p-4 space-y-3" data-testid="test-send-panel">
                <h2 className="text-sm font-medium">Test send</h2>
                <div className="flex gap-2">
                    <Input placeholder="you@example.com" value={testTo}
                           onChange={(e) => setTestTo(e.target.value)}
                           className="max-w-sm" data-testid="test-to-input" />
                    <Button onClick={testSend} disabled={busy || !testTo} data-testid="test-send-btn">
                        <Send className="w-4 h-4 mr-2" /> {busy ? "Sending…" : "Send test"}
                    </Button>
                </div>
                {testResult && (
                    <div className={`text-xs mt-2 ${testResult.ok ? "text-emerald-700" : "text-red-700"}`} data-testid="test-result">
                        {testResult.simulated && <Badge variant="outline" className="mr-2 text-[9px]">simulated</Badge>}
                        {testResult.message}
                        {testResult.hint && <div className="text-zinc-500 mt-1">{testResult.hint}</div>}
                    </div>
                )}
            </section>

            <section>
                <div className="flex items-center justify-between mb-2">
                    <h2 className="text-sm font-medium">Suppression list</h2>
                    <Button variant="ghost" size="sm" onClick={addSuppression} data-testid="add-suppression-btn">Add</Button>
                </div>
                <div className="rounded-lg border border-brand-line bg-white divide-y divide-brand-line" data-testid="suppression-list">
                    {suppressions.map((s) => (
                        <div key={s.email} className="p-3 flex items-center justify-between text-sm">
                            <div>
                                <span className="font-mono">{s.email}</span>
                                <Badge variant="secondary" className="ml-2 text-[10px]">{s.reason}</Badge>
                            </div>
                            <Button variant="ghost" size="sm" onClick={() => removeSuppression(s.email)}
                                        data-testid={`remove-suppression-${s.email}`}>
                                <Trash2 className="w-4 h-4" />
                            </Button>
                        </div>
                    ))}
                    {!suppressions.length && <div className="p-4 text-xs text-zinc-500">No suppressed addresses.</div>}
                </div>
            </section>
        </div>
    );
}
