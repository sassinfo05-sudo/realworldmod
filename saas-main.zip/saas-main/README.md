# Revenue OS

Multi-tenant SaaS for small service businesses. AI-first workspace: website builder + hosting, CRM, email workspace, booking, quotes/invoices/payments, AI employees (chat + call simulator), marketing (campaigns, automations, creative studio), founder control center, entitlements-gated billing, setup center, in-app support.

## Quickstart

```bash
# backend
cd /app/backend && pip install -r requirements.txt
sudo supervisorctl restart backend

# frontend (yarn — never npm)
cd /app/frontend && yarn install
sudo supervisorctl restart frontend
```

All URLs, credentials, and DB names come from `.env` files — see `ENVIRONMENT_VARIABLES.md`. Never hardcode.

## Repository layout

```
/app
├── backend/                    FastAPI + Motor (async Mongo)
│   ├── app/
│   │   ├── routes/             per-module HTTP routes (all under /api)
│   │   ├── services/           business logic (LLM, ai_agent_runner, entitlements, audit, mfa, webhooks, seeds, …)
│   │   ├── models*.py          domain models (extend BaseDocument, PyObjectId)
│   │   ├── deps.py             current_user / require_org / require_role / impersonation
│   │   ├── security.py         JWT + bcrypt + impersonation token
│   │   └── config.py           env resolution
│   ├── server.py               FastAPI app, includes all routers under /api
│   ├── scripts/                one-shot migrations / cleanups
│   └── tests/                  pytest suites (phase5, phase6, phase6_followups)
├── frontend/                   React + Tailwind + shadcn/ui
│   └── src/
│       ├── pages/              dashboard/*, public/*, founder/*, editor/*, Home, Pricing, Legal, …
│       ├── components/         DashboardShell, BlockRenderer, PublicNav, ui/
│       ├── lib/                api client (impersonation-aware), i18n
│       └── context/            AuthContext, BrandContext
└── memory/                     PRD.md, BUILD_LEDGER.md, REQUIREMENTS_LEDGER.md, SECURITY.md, DEPLOYMENT.md, TESTING.md, ENVIRONMENT_VARIABLES.md, OWNER_SETUP_CHECKLIST.md, CHANGELOG.md, test_credentials.md
```

## Core paths

- Signup / interview / AI generation → publish: `/signup` → `/onboarding` → `/app` → `/app/editor`.
- Public site: `/site/{slug}` — footer "Powered by Revenue OS" on Free plans (paid removes).
- Owner dashboard: `/app` — 20+ modules under one shell.
- Founder panel: `/app/founder` (platform_founder role only).
- Docs: `/app/memory/`.

## Rules that will break things

- Never use npm. Always yarn.
- Never hardcode URLs, DB names, or secrets. All from `.env`.
- Never restart the backend for a code change — supervisor + hot reload handles it.
- Every backend route lives under `/api`. Client uses `REACT_APP_BACKEND_URL`.
- Every tenant-scoped write MUST use `require_org` (never trust client-supplied `org_id`).
