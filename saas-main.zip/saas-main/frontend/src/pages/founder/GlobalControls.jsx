import { useEffect, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ShieldAlert, Megaphone, Wrench, Flag } from "lucide-react";

export default function GlobalControls() {
    const [data, setData] = useState(null);
    const [ann, setAnn] = useState({ title: "", body: "", level: "info" });
    const [busy, setBusy] = useState(false);

    async function load() {
        const { data } = await api.get("/founder/global-controls");
        setData(data);
    }
    useEffect(() => { load(); }, []);

    async function setKill(patch) {
        setBusy(true);
        try {
            await api.put("/founder/global-controls/kill", patch);
            toast.success("Updated");
            load();
        } catch (e) { toast.error("Failed"); }
        finally { setBusy(false); }
    }
    async function publishAnn() {
        setBusy(true);
        try {
            await api.post("/founder/global-controls/announcement", ann);
            toast.success("Published");
            setAnn({ title: "", body: "", level: "info" });
            load();
        } catch (e) { toast.error("Failed"); }
        finally { setBusy(false); }
    }
    async function clearAnn() {
        try { await api.delete("/founder/global-controls/announcement"); toast.success("Cleared"); load(); }
        catch (e) { toast.error("Failed"); }
    }
    async function setMaint(enabled) {
        try {
            await api.put("/founder/global-controls/maintenance", { enabled, message: "Zanelvo is undergoing maintenance." });
            toast.success(enabled ? "Maintenance mode ON" : "Maintenance mode OFF");
            load();
        } catch (e) { toast.error("Failed"); }
    }
    async function toggleFlag(f, patch) {
        try {
            await api.put("/founder/global-controls/feature-flag", { key: f.key, ...patch });
            toast.success("Flag updated");
            load();
        } catch (e) { toast.error("Failed"); }
    }

    if (!data) return <div className="p-6 text-zinc-500">Loading…</div>;
    return (
        <div className="p-6 max-w-4xl space-y-6" data-testid="founder-controls-page">
            <div>
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Kill switches</div>
                <div className="grid md:grid-cols-3 gap-3">
                    {[
                        { k: "all_ai_disabled", label: "All AI" },
                        { k: "all_email_disabled", label: "All outbound email" },
                        { k: "all_public_chat_disabled", label: "All public chat widgets" },
                    ].map((row) => (
                        <div key={row.k} className={`rounded-lg border p-4 ${data.global_kill[row.k] ? "border-red-200 bg-red-50" : "border-brand-line bg-white"}`} data-testid={`kill-${row.k}`}>
                            <div className="flex items-center gap-2 mb-2"><ShieldAlert className="w-4 h-4 text-red-600" /><span className="font-medium text-brand-ink">{row.label}</span></div>
                            <div className="text-xs text-zinc-500 mb-3">Currently: <span className={data.global_kill[row.k] ? "text-red-700 font-medium" : "text-emerald-700"}>{data.global_kill[row.k] ? "DISABLED" : "enabled"}</span></div>
                            <Button size="sm" variant={data.global_kill[row.k] ? "outline" : "destructive"} onClick={() => setKill({ [row.k]: !data.global_kill[row.k] })} disabled={busy} data-testid={`kill-${row.k}-toggle`}>
                                {data.global_kill[row.k] ? "Re-enable" : "Disable globally"}
                            </Button>
                        </div>
                    ))}
                </div>
            </div>

            <div>
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Platform announcement</div>
                {data.announcement.active ? (
                    <div className={`rounded-lg border p-4 mb-3 ${
                        data.announcement.level === "urgent" ? "border-red-200 bg-red-50" :
                        data.announcement.level === "warn" ? "border-amber-200 bg-amber-50" : "border-brand-line bg-white"
                    }`} data-testid="ann-current">
                        <div className="text-xs uppercase tracking-widest text-zinc-500">{data.announcement.level}</div>
                        <div className="font-medium text-brand-ink mt-1">{data.announcement.title}</div>
                        <div className="text-sm text-zinc-600 mt-0.5">{data.announcement.body}</div>
                        <Button size="sm" variant="ghost" onClick={clearAnn} className="mt-2" data-testid="ann-clear-btn">Clear announcement</Button>
                    </div>
                ) : (
                    <div className="text-xs text-zinc-500 mb-2">No active announcement.</div>
                )}
                <div className="rounded-lg border border-brand-line bg-white p-4 space-y-2">
                    <div className="flex items-center gap-2"><Megaphone className="w-4 h-4 text-zinc-500" /><span className="font-medium text-brand-ink">New announcement</span></div>
                    <Input placeholder="Title" value={ann.title} onChange={(e) => setAnn({ ...ann, title: e.target.value })} data-testid="ann-title" />
                    <Textarea placeholder="Body" rows={2} value={ann.body} onChange={(e) => setAnn({ ...ann, body: e.target.value })} data-testid="ann-body" />
                    <select value={ann.level} onChange={(e) => setAnn({ ...ann, level: e.target.value })} className="border border-brand-line rounded px-2 py-1.5 text-sm bg-white">
                        <option value="info">info</option><option value="warn">warn</option><option value="urgent">urgent</option>
                    </select>
                    <Button size="sm" onClick={publishAnn} disabled={busy || !ann.title || !ann.body} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="ann-publish-btn">Publish</Button>
                </div>
            </div>

            <div>
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Maintenance mode</div>
                <div className={`rounded-lg border p-4 ${data.maintenance.enabled ? "border-amber-200 bg-amber-50" : "border-brand-line bg-white"}`} data-testid="maintenance-card">
                    <div className="flex items-center gap-2 mb-2"><Wrench className="w-4 h-4" /><span className="font-medium">Currently: {data.maintenance.enabled ? "ON" : "off"}</span></div>
                    <div className="flex gap-2">
                        <Button size="sm" variant={data.maintenance.enabled ? "outline" : "default"} onClick={() => setMaint(true)} data-testid="maint-on-btn">Turn ON</Button>
                        <Button size="sm" variant="ghost" onClick={() => setMaint(false)} data-testid="maint-off-btn">Turn OFF</Button>
                    </div>
                </div>
            </div>

            <div>
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Feature flags</div>
                <div className="border border-brand-line rounded-lg bg-white divide-y">
                    {data.feature_flags.map((f) => (
                        <div key={f.id} className="p-3 flex items-center gap-3" data-testid={`flag-${f.key}`}>
                            <Flag className="w-4 h-4 text-zinc-400" />
                            <div className="flex-1">
                                <div className="text-sm font-medium text-brand-ink">{f.label}</div>
                                <div className="text-xs text-zinc-500">{f.description}</div>
                            </div>
                            <label className="flex items-center gap-1.5 text-xs text-zinc-500">
                                <input type="checkbox" checked={f.enabled_globally} onChange={(e) => toggleFlag(f, { enabled_globally: e.target.checked })} data-testid={`flag-${f.key}-toggle`} />
                                Enabled globally
                            </label>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
