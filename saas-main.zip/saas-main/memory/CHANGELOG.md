# Changelog

## 2026-09-07 — Owner Go-Live Wizard (staff)
- New guided readiness screen at **/staff/go-live** (nav "Go-Live"): a single ordered checklist that walks
  the platform owner through Database, Public address, Object storage & CDN, Transactional email, Payments
  (Stripe), Custom domain & SSL, and AI models — each with a truthful status badge (Connected / Sandbox /
  Not connected / Error), the exact next action, and a deep link to the right setup page. Progress bar +
  a green "You're live" state when every essential is Connected.
- Backend aggregator `GET /api/staff/providers/go-live` (staff-scoped, non-destructive — no paid probes)
  reuses the existing provider checks + DB/public-URL/object-storage readiness; returns steps + summary +
  `app_ready` + `live_ready` + `pending`. Tested 7/7 (staff-only 403 for owners, 401 without token).
- Added an **inline object-storage config form** in the wizard (first UI for the founder storage endpoints):
  provider (S3/R2/B2/MinIO), bucket, endpoint, region, CDN base URL, keys — saved via `/api/founder/storage`
  with a "Test connection". Secrets are encrypted at rest and masked in responses (verified: no leakage).

## 2026-09-07 — Round 18 FINAL: storage/build/bootstrap remediation → CODE_GATE: PASS
- **Fixed GitHub/CI build failure** (`Could not find a version that satisfies the requirement
  emergentintegrations==0.2.0`): removed the private-CDN-only `emergentintegrations==0.2.0` pin from
  `backend/requirements.txt`, made its import LAZY in `app/services/llm.py`, and moved it to optional
  `backend/requirements-emergent.txt`. `requirements.txt` now installs cleanly from **public PyPI only**
  (proven: fresh-venv `pip install --index-url pypi.org -r requirements.txt` EXIT 0; `import server`
  works without the package). Dockerfiles + CI updated to install base deps from public PyPI and the
  optional LLM client separately. Satisfies Section A "remove reliance on a private package index."
- **Funded EMERGENT_LLM_KEY applied** → the 6 previously budget-blocked AI-grounding tests now **PASS
  6/6**; full backend suite = **199 passed / 0 failed / 18 skipped**.
- **Env rebuilt** after wipe-on-import (backend/.env + frontend/.env, deps reinstalled) → all services
  RUNNING, `/api/health` 200, `/api/readiness` app_ready:true/external_ready:false, founder+owner login 200.
- **Build reproducibility (A)**: frozen `yarn install --frozen-lockfile` + `yarn build` both PASS; backend
  installs from committed `requirements.txt`; ruff + compile EXIT 0; `pip-audit` 0 vulns (21 documented
  ignores); CI `|| true` fail-open removed. Docker builds not runnable in-session (no daemon) — Dockerfiles
  reviewed, steps reproduced individually.
- **Storage invariants (B)**: actual-size bypass, reservation leak on provider failure, signed-URL expiry,
  and provider-switch readability all fixed + tested (47 passed / 1 skipped in storage/config/entitlement
  suites); DB-unique idempotency, atomic trash/restore/purge, referenced-asset purge guard.
- **Plan allowances (C)**: enforced from DB config; bandwidth labelled Estimated (no CDN connected).
- **Bootstrap/readiness (F)**: single-use hashed 48h founder-bootstrap CLI; founder email de-hardcoded;
  readiness surfaces db/origin/storage/email; MFA copy accurate (prod fails closed).
- **Docs (G)** refreshed; no "Revenue OS" in customer-facing `frontend/src`; secret scan clean.
- **Honest gaps**: 6 LLM-grounding tests fail on EMERGENT_LLM_KEY budget-exhausted (external billing, not
  code); Asset Library cross-editor wiring (D) + expanded staff storage dashboards (E) remain increments.
- CODE_GATE: PASS (code-controlled). PRODUCTION_GATE: PENDING_OWNER_SETUP. See `ROUND_18_AUDIT.md` +
  `HANDOFF_ROUND_18.md`.

## 2026-09-07 — Round 18 (focused slice): Login Alerts UI + "Remember me" UI + lockfile
- **Login Alerts** (owner emailed on new device/location): backend `services/login_alerts.py` was already
  shipped and verified (device fingerprint via X-Device-Id+UA+IP, `login_history`/`login_devices`, first
  device silent, `security_alert` email on every new device/country, fail-open). Added the missing owner UI:
  a **"Recent sign-ins & devices"** card in `pages/dashboard/Security.jsx` (device, location/IP, time,
  "new device" badge) backed by `/api/auth/login-history` + `/api/auth/devices`.
- **Session Length ("remember me")**: backend `remember` flag → 30-day token, cookie Max-Age follows token
  exp; verified 1440 min vs 43200 min. Added the missing **"Keep me signed in for 30 days"** checkbox on
  `pages/Login.jsx` (wired through AuthContext `login(email, password, remember)`).
- **Build reproducibility**: regenerated `frontend/yarn.lock` (was missing) from current `package.json`.
- The broader Round-18 A–H storage/build/bootstrap remediation remains OPEN — see `memory/ROUND_18_AUDIT.md`.
  PRODUCTION_GATE stays PENDING_OWNER_SETUP.


## 2026-09-06 — Round 12: commerce depth (gift cards, shopper accounts, customer groups) + developer docs
- **Gift cards** (`routes/gift_cards.py`): owner CRUD + balance adjust/activate/deactivate; public balance check;
  applied as tender at checkout (partial or fully-covered free order); decremented only when the order is PAID
  (idempotent); auto-issued when a `product_type: gift_card` product is purchased. Outstanding-liability total for owners.
- **Shopper accounts + saved carts** (`routes/shop_customers.py`): passwordless email one-time-code login → scoped
  shopper JWT (role=`shopper`, org-bound; refused by owner/staff deps and cross-org); profile, server-side saved cart
  (hydrated), and order history (by customer_id or buyer email). buy-now `customer_token` links orders to the account.
- **Customer groups**: `contact.customer_group` + discount `eligible_groups[]` (group-only offers, resolved from the
  shopper account or a CRM contact by email). **Product bundles** (`bundle_items[]`) + `gift_card` product type.
- **Frontend**: storefront gift-card field + passwordless account dialog (sign-in + order history); Discounts page
  "Gift cards" tab + customer-group field; Products form gift_card/bundle types; CRM contact customer-group editor.
- **Developer docs** (`pages/Developers.jsx`, `/developers`): scoped `yv_` API keys, the real `/api/public/v1/*`
  endpoints, signed-webhook (`X-Zanelvo-Signature`) verification, limits & safety. Truthful vs `routes/public_api.py`.
- Backend testing agent: **38/38 PASS** (gift cards 8/8, shopper accounts + carts 11/11, customer groups 3/3).
- Still blocked on owner credentials: PayPal live, real SSL, live carrier rates, ad-account OAuth, SMS/WhatsApp, Stripe Connect/Billing.


## 2026-09-06 — Round 8: central cost service, P0 security, pricing versioning, language switcher (second continuation)
- **Central cost & usage service** (`services/usage.py`): enforce → reserve → settle/release for every paid op; universal ledger
  (request_id, idempotency_key, est/actual cost, latency, retries, cache hits, billing period); founder controls: pause-all,
  provider kill switches, global monthly budget, per-user share, per-feature caps, public-visitor daily cap; audit rows;
  margin summary (MRR vs metered cost); CSV ledger export; traffic observation. `services/llm.py` + `email_providers.MeteredProvider`
  wired. Public chat / translate / voice metered against the tenant with honest fallbacks. UI: `/staff/ai-usage` rebuilt.
- **P0 security**: hashed single-use reset tokens (atomic consume) + session invalidation; invite via set-password link (no temp
  password); staff temp password only when typed/dev; CORS credentials disabled for `*`; invalid ObjectId → 400; LlmError → 503;
  body-size limits (413); SSRF/DNS-rebinding guard for import + outbound webhooks (`services/netsafe.py`); integration secrets
  encrypted at rest (`services/secretbox.py`); Mongo-backed rate limits for auth flows; inbound-email + voice webhooks authenticated;
  atomic order finalize (no double/negative stock); production seeding gated (`APP_ENV`, `SEED_DEMO_DATA`, `FOUNDER_INITIAL_PASSWORD`);
  security headers + X-Request-Id; secrets/creds redacted from memory files and tests.
- **Pricing**: plan edits validated + versioned (`plan_pricing_history`, `GET /api/founder/plans-admin/{code}/history`).
- **Staff panel**: provider status cards (`/api/staff/providers/status`) on Payments & email; internal competitive matrix page.
- **Storefront/site language switcher** with Hebrew/Arabic RTL (`components/public/LanguageSwitcher.jsx`, public localization settings endpoint).
- **Truth/brand sweep**: fake testimonials → labelled example scenarios; generator truth rule (no invented prices/reviews/stats);
  API title/UA/headers/export names → Zanelvo; dev-progress copy removed from dashboard pages.
- Tests: backend agent 21/23 (1 real bug fixed: iat `<=`; 1 harness limitation). Frontend regression: see test_result.md.

## 2026-09-05 — Selling & shipping suite + product depth + logo studio (fifth continuation)
- **Online-selling & shipping suite** (native, "better than Shopify"), all backend-tested 8/8:
  - `services/shipping.py`: 47-country directory, real carrier directory (USPS/UPS/FedEx/DHL/
    Royal Mail/Evri/Australia Post/Aramex/Delhivery/Sendle…) + aggregators (Shippo/EasyPost/
    ShipStation) filtered by destination, rate engine (flat / weight-tier / price-tier /
    free-over-threshold, + handling fee), and printable Invoice + Packing-slip HTML renderers.
  - `routes/shipping.py` (owner `/api/store/shipping/*` + `/api/store/inventory/*` + order
    ship/invoice; public `/api/public/store/{org_id}/shipping/quote`): settings (ship-from,
    countries-served allowlist), zones CRUD, quote (owner+public, cheapest-first), inventory
    adjust/log/low-stock/bulk, `POST /orders/{id}/ship` (carrier+tracking, buyer email),
    `GET /orders/{id}/invoice?doc=invoice|packing`.
  - `routes/store.py`: products gained `weight_grams`+`requires_shipping`; **buy-now** now takes
    optional `country_code`+`shipping_option_id`, recomputes shipping server-side and adds
    `shipping_cents`/`total_cents` to the order + checkout amount (backward compatible).
  - Frontend: `pages/dashboard/Shipping.jsx` (Settings / Zones & rates / Carriers tabs);
    Orders.jsx gained Ship dialog (tracking + notify) + Print Invoice/Packing-slip + shipped status.
- **Product form depth** (Products.jsx, backend 6/6 tested): compare-at price, weight, product
  type (physical/digital + download URL), requires-shipping, tags, variants (name/stock/price),
  SEO title/description — all in the product editor dialog.
- **Logo Studio** (backend 6/6 tested, UI verified): `routes/branding.py` (`/api/branding`
  GET+PUT owner-scoped; upserts `org_branding` + mirrors `logo_svg` into website theme;
  WebsiteTheme gained optional `logo_svg`). `pages/dashboard/LogoStudio.jsx`: client-side SVG
  generator (monogram/wordmark/icon+text/badge, palettes, fonts, icons), live preview, Download
  SVG/PNG, Save-to-brand. PENDING: AI-image logo tab (needs provider choice) + public-site render.


## 2026-09-05 — Store engine + payments/voice + homepage revamp (fourth continuation)
- **NEW native online store** (no Shopify — competitor removed everywhere):
  - `routes/store.py`: owner Products CRUD, Orders list/detail/fulfill, public storefront
    (`/api/public/store/{org_id}/products`) + **buy-now** (creates order + simulated checkout).
  - **BUG FIX**: buyer-facing `POST /api/payments/simulated/pay` now flips the linked store
    order to **paid** and **decrements stock**, idempotently (double-pay → 400, no double
    decrement) via `bookings._apply_paid_event` → `store.apply_store_order_paid`.
  - **CSV product import** (analyze → map → execute); **product sourcing / dropshipping**
    (`services/product_sourcing.py`): built-in Starter catalog (6 items, zero-config) +
    AliExpress/CJ Dropshipping supplier adapters (honest 400 + setup steps until keyed).
  - Order-paid **notifications**: buyer confirmation + owner alert via existing email
    pipeline (simulated, honestly labeled) + `store_order_paid` timeline interaction on the
    buyer's CRM contact.
- **Real Stripe webhook** `POST /api/billing/webhook/stripe`: verifies signature (400 on
  bad/missing sig or unset `STRIPE_WEBHOOK_SECRET`), idempotent on event id (`stripe_events`),
  dispatches `checkout.session.completed` → store order / booking invoice / subscription.
  Unit tests `tests/test_store_stripe_webhook.py` (5/5: sig valid/invalid/replay/no-secret + idempotent stock).
- **Voice webhooks wired** (`routes/voice.py`): `POST /api/voice/twilio/inbound` returns TwiML
  speech-Gather loop bridged to the receptionist `run_turn`; `POST /api/voice/retell/webhook`
  returns Retell's `{response, response_id}`. Both live but honestly labeled "configured —
  awaiting your Twilio number / Retell agent binding" in `/api/ai/voice/providers`.
- **Frontend**: Products + Orders dashboard pages (MediaPicker, CSV import, sourcing dialog),
  public **Storefront** (`/store/:orgId`) buy-now flow, Store nav section.
- **Homepage revamp**: animated gradient hero + floating badges, auto-advancing product
  showcase ("slide" feel), trust marquee, scroll-reveal on every section, hover micro-
  interactions — all `prefers-reduced-motion` safe. Store added to features/FAQ.
- Backend verified by testing agent **26/26 PASS** (incl. the bug fix + idempotency).


## 2026-09-03 — Phase 7 + 8 slice
- Marketing module: campaigns E2E (create/segment/compose/AI-assist/send with consent+suppression+quiet-hours+global-kill+entitlement enforcement/report), automations (linear trigger→cond→1-3 actions, published templates, triggers wired on form_submitted + booking_created), Creative Studio (EN/ES/HE ad copy + RTL + storyboard + video script + ZIP export; images = labeled DEMO placeholders; video render = "requires provider credentials").
- Budget cap / requires_approval / paused fields enforced on campaign send.
- Two additional seeded demo tenants at parity — Ridgeline Auto Service (revenue plan) and Mira & Co. Beauty (autopilot plan). Both have published sites, services, staff, 8 contacts, 2 bookings, 1 quote, 1 invoice, receptionist enabled.
- i18n framework (`/app/frontend/src/lib/i18n.js`) + Hebrew translations for sidebar + `dir=rtl` layout flip when Hebrew active. Language switcher in the dashboard sidebar.
- Public marketing pages: `/industries`, `/security`, `/terms`, `/privacy` — concise real copy, no lorem, no fabricated claims.
- Docs: README, REQUIREMENTS_LEDGER (final matrix), OWNER_SETUP_CHECKLIST, ENVIRONMENT_VARIABLES, DEPLOYMENT, TESTING, CHANGELOG. `SECURITY.md` already carried MFA recovery + all Phase 6 guarantees.

## 2026-09-03 — Phase 6 follow-ups
- Central `enforce_entitlement(org, meter, increment)` used on contacts create, form intake, CSV import (batch pre-check), team invite, immediate email send, scheduled email release, website import.
- Public chat over AI-conversation cap returns `{disabled:true, over_limit:true, greeting}` — never a raw 402 to a visitor.
- Impersonation scoped JWT (`imp_sid` claim). Frontend api client picks the right token per URL. Every request bumps `actions_count`; every mutating action auto-tagged with `impersonation_session_id` in the audit log.
- `show_platform_branding` in public site payload → free-plan "Powered by Revenue OS" footer on the public site renderer. Cedar Lane Landscaping (Free demo) seeded with a published site so the flag is testable.
- `POST /api/public/v1/bookings` added (scope: `bookings:write`) — respects availability + past-date guards + fires `booking.created` webhook.
- Tester API key revoked; test tenant "Fresh Co 15221" purged.

## 2026-09-03 — Phase 6 initial
- Billing plans + entitlements + simulated checkout + coupon (`LAUNCH20`) + upgrade/downgrade/cancel/resume/dunning + billing invoices.
- Founder Control Center: cockpit, tenants, metrics, audited impersonation, audit log, global controls (3 kill switches, feature flags, announcement, maintenance), provider/queue health, dead-letter retry, approval queue.
- Setup Center: 21 connection cards + honest state + Test buttons, Launch Score (6 real checks), scoped API keys (`yv_live_*/yv_test_*`, sha256 storage), HMAC webhooks (5-min replay), ZIP data export, org soft-delete + 30-day grace.
- Support: 10 seeded help articles, tickets CRUD, grounded AI support assistant, public status + announcement.
- Security: TOTP MFA + 8 one-time backup codes, rate limits on auth + public chat, constant-time portal-token compare, founder recovery procedure documented.

## 2026-09-02 — Phase 5 (Knowledge + AI employees + Agent Studio + Voice sim)
- Grounded receptionist (chat + call sim), tool dispatch (services, hours, availability, create_booking, escalate), Agent Studio (versions, promote, rollback, sandbox), per-org + platform kill switches, knowledge extraction (pypdf + python-docx). Past-date + retry-once fixes came in Phase 6 follow-ups.

## 2026-09-01 — Phase 4 (CRM + Inbox + Booking + Quote-to-cash)
- Money contract migration (0-100 percent), portal tokens, simulated payments E2E, scheduled sends.

## 2026-08-31 — Phase 3 (Domains + Import + Analytics + Forms + Email)
- Custom domain wizard (simulated provider state machine), URL importer, form + analytics event tracking.

## 2026-08-30 — Phase 2 (Visual editor)
- Block schema, drag-reorder, revisions, publish.

## 2026-08-29 — Phase 1 (Brand + auth + onboarding + AI generation)
- Revenue OS brand, JWT + roles, interview → BusinessProfile + Website generation, fact review, pricing.

## 2026-09-03 — Final Corrective Pass
- **BRAND**: Prior brand rejected (confirmed conflict, active FR publisher +
  Google Play). Neutral label **Revenue OS** applied per brief's fallback
  after finalists Quilvo (active Seattle SaaS on quilvo.app) and Velquo
  (owned-.com + soft conflicts) both failed verification. Evidence in
  `BRAND_SCREEN.md`.
- **Auth**: Google sign-in via Emergent-managed OAuth on both `/login` and
  `/signup`. New Google users hit the same onboarding path as email users.
  `/api/auth/session-exchange` handles the server-side session_id → JWT swap.
- **Auth**: Apple Sign-In adapter route + `GET /api/auth/social-status`.
  Apple button hidden until owner configures `APPLE_TEAM_ID`, `APPLE_KEY_ID`,
  `APPLE_PRIVATE_KEY`, `APPLE_SERVICE_ID`. No dead button ever renders.
- **Repo grep**: the retired name now returns zero hits outside `DECISIONS.md`,
  `BRAND_SCREEN.md`, and `test_reports/*.json` (all historical).
- **Migration**: 7 seeded users renamed in-place preserving passwords.

## 2026-09-03 (later) — Final Fix Cycle (targeted)
- **P1**: `/api/public/booking/services` now returns services for
  `ridgeline-auto-service` (2) and `mira-co-beauty` (2). Seed writes
  `bookable=True, active=True` on new services and idempotently backfills
  those flags on legacy rows.
- **Quiet-hours test override**: `POST /api/marketing/campaigns/{cid}/send`
  accepts `X-Test-Override: <founder JWT>` to bypass the guard. Owner tokens
  are ignored (400 preserved). Documented in `TESTING.md`.
- **Cleanup**: removed draft campaign "Regr Test"
  (`6a99fe7190abf152a1b8c00a`), 4 contacts tagged `regr-supp`, and 1
  suppression for `supp-target2` on Demo Home Services.
- **OpenAPI**: `InviteReq.role` typed as
  `Literal["owner","manager","staff"]` — schema now exposes the enum; the
  runtime check refuses `readonly` on invite.
- **test_credentials.md** updated with all 7 seeded accounts (founder + demo
  + 3 phase-6 owners + 2 phase-7 owners) using fixed, documented passwords.
- **P0 hotfix (2026-09-03)**: App.js dup `Security` import renamed to `LegalSecurity` (build unblocked); `Message.conversation_id` now Optional so campaign + automation `send_email` inserts stop 500ing; campaign send is idempotent (already-sent short-circuit → no dup messages); `add_tag` executor no longer falls through to "unknown action" when `contact_id` is absent.
- **Final polish (2026-09-04)**: form_submitted trigger now passes contact_id → add_tag attaches (verified with public form POST); campaign segment supports {"tags":[…]} OR-match and rejects unknown keys with 422 (validated in create/update/send); cleaned 2 qa-hotfix contacts + 2 QA Hotfix campaigns; Creative Studio provider bar now labels video_gen too (was image_gen only).

## Zanelvo Rebrand Round (2026-09)
- **Rebrand:** Revenue OS → **Zanelvo** across backend + frontend + brand config + emails + docs. Domain zanelvo.com; dashboard app.zanelvo.com; customer sites {slug}.zanelvo.com. Founder/owner emails on @zanelvo.com.
- **Refunds & Cancellations:** POST /api/store/orders/{id}/refund (auto-restock, idempotent, buyer refund email) + /cancel for pending orders. Orders page got Refund (reason + restock toggle) and Cancel actions.
- **Store Block On Site:** new `store` website block (drag-in from editor) renders products + checkout on the customer's own site; portable via /api/public/store/by-site/{slug}/*. Added to demo home page.
- **Live Stripe Go-Live:** tenant payments gained store_mode(test|live)+webhook secret; GET /api/store/settings, POST /api/store/go-live (blocks live until Stripe key saved); buy-now auto-routes simulated↔real Stripe. Go-Live toggle in Setup → Integrations.
- **Abandoned Checkout Nudge:** pending-order recovery emails (idempotent), GET/POST /api/store/abandoned + 10-min background sweep loop for all orgs. "Recover abandoned carts" button on Orders page.
- **Homepage redesign:** dark bespoke hero with rendered product-dashboard mockup, gradient mesh + grid, bento feature grid, scroll-reveal + reduced-motion respected.
- Backend: 23/23 new store tests passed. Phase 7 (campaigns/automations/creative/founder cockpit+metrics) verified live (200s).

## Cycle 1 — Brand refresh + foundations (2026-09)
- **New logo:** custom gradient "Z" monogram (indigo→magenta→amber), self-colored SVG in brand config.
- **New palette:** replaced orange with indigo #4F46E5 primary + sunset gradient (indigo→magenta→amber). Recolored whole app via brand tokens + config theme + homepage accents.
- **Auth:** email+password form now visible by DEFAULT on Login and Signup (toggle removed).
- **Removed** the "Import website" feature (route + links).
- **Subdomain rules** for <name>.zanelvo.com: 4–12 letters (a–z only), reserved-name blocklist, uniqueness (incl. slug history). New GET /api/editor/website/slug-available live check; publish endpoint validates chosen slug (400 invalid/reserved, 409 taken).
- **Help center rebuilt:** dark hero search, 3 quick-help cards (AI assistant / tickets / status), category chips, richer article grid (backed by existing /api/support).
- app.zanelvo.com / <name>.zanelvo.com are surfaced in UI; the actual host split is a deploy-time DNS step.
- Verified: 5/5 Cycle-1 frontend checks passed; subdomain + colors + logo confirmed.
