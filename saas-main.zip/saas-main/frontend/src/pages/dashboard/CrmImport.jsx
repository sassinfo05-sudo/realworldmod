import { useRef, useState } from "react";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { Upload, Undo2 } from "lucide-react";

const TARGETS = [
    "skip", "email", "phone", "first_name", "last_name", "display_name",
    "company", "title", "address", "tag", "language",
];

export default function CrmImport() {
    const fileRef = useRef(null);
    const [run, setRun] = useState(null);
    const [mapping, setMapping] = useState([]);
    const [busy, setBusy] = useState(false);
    const [result, setResult] = useState(null);

    async function analyze(e) {
        const file = e.target.files?.[0];
        if (!file) return;
        setBusy(true);
        setResult(null);
        try {
            const fd = new FormData();
            fd.append("file", file);
            const { data } = await api.post("/crm/import/analyze", fd,
                { headers: { "Content-Type": "multipart/form-data" } });
            setRun({ ...data, run_id: data.run_id });
            setMapping(data.proposed_mapping || []);
            toast.success(`${data.total_rows} rows parsed`);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Analyze failed");
        } finally {
            setBusy(false);
            if (fileRef.current) fileRef.current.value = "";
        }
    }

    async function execute() {
        setBusy(true);
        try {
            const { data } = await api.post(`/crm/import/${run.run_id}/execute`, {
                mapping,
                on_duplicate: "update",
            });
            setResult(data);
            toast.success(`Imported: ${data.created} created, ${data.updated} updated, ${data.errors} errors`);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Execute failed");
        } finally {
            setBusy(false);
        }
    }

    async function rollback() {
        if (!window.confirm("Roll back this import? Created contacts will be deleted; updates reverted.")) return;
        setBusy(true);
        try {
            const { data } = await api.post(`/crm/import/${run.run_id}/rollback`);
            toast.success(`Rolled back: ${data.reverted_created} removed, ${data.reverted_updated} restored`);
            setResult(null);
            setRun(null);
            setMapping([]);
        } catch (e) {
            toast.error("Rollback failed");
        } finally { setBusy(false); }
    }

    return (
        <div className="p-6 space-y-6" data-testid="crm-import-page">
            <div>
                <h1 className="font-display text-2xl font-semibold">Import contacts</h1>
                <p className="text-sm text-zinc-500">Upload a CSV. We'll map columns, flag duplicates, and let you roll back if needed.</p>
            </div>

            {!run && (
                <div className="border-2 border-dashed border-brand-line rounded-lg p-10 text-center bg-white">
                    <Upload className="w-8 h-8 mx-auto text-zinc-400 mb-2" />
                    <div className="text-sm text-zinc-600">Drop a CSV file here or</div>
                    <input ref={fileRef} type="file" accept=".csv,text/csv" onChange={analyze} className="hidden"
                           data-testid="import-file-input" />
                    <Button className="mt-3" onClick={() => fileRef.current?.click()} data-testid="import-choose-file"
                            disabled={busy}>
                        Choose CSV
                    </Button>
                </div>
            )}

            {run && !result && (
                <div className="space-y-4">
                    <div className="flex items-center gap-3">
                        <div className="text-sm font-medium">{run.total_rows} rows · {run.columns?.length || 0} columns</div>
                        {(run.duplicates?.length || 0) > 0 && (
                            <Badge variant="destructive" data-testid="duplicate-count">
                                {run.duplicates.length} potential duplicates
                            </Badge>
                        )}
                    </div>

                    <div className="rounded-lg border border-brand-line bg-white overflow-hidden">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Column</TableHead>
                                    <TableHead>Sample</TableHead>
                                    <TableHead>Map to</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {mapping.map((m, i) => (
                                    <TableRow key={m.column}>
                                        <TableCell className="font-mono text-xs">{m.column}</TableCell>
                                        <TableCell className="text-xs text-zinc-500">
                                            {run.row_sample?.[0]?.[m.column] ?? ""}
                                        </TableCell>
                                        <TableCell>
                                            <Select value={m.target} onValueChange={(v) => {
                                                const next = [...mapping];
                                                next[i] = { ...next[i], target: v };
                                                setMapping(next);
                                            }}>
                                                <SelectTrigger data-testid={`map-${m.column}`} className="w-40">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {TARGETS.map((t) => (
                                                        <SelectItem key={t} value={t}>{t}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>

                    {(run.duplicates?.length || 0) > 0 && (
                        <div className="rounded-lg border border-amber-300 bg-amber-50 p-4">
                            <div className="text-sm font-medium mb-2">Duplicate preview (first 5)</div>
                            <ul className="text-xs space-y-1 font-mono" data-testid="duplicate-preview">
                                {run.duplicates.slice(0, 5).map((d, i) => (
                                    <li key={i}>Row {d.row_index + 1}: matches {d.match_name || d.match_id}</li>
                                ))}
                            </ul>
                        </div>
                    )}

                    <div className="flex gap-2 justify-end">
                        <Button variant="ghost" onClick={() => { setRun(null); setMapping([]); }}>Cancel</Button>
                        <Button onClick={execute} disabled={busy} data-testid="import-execute">
                            {busy ? "Importing…" : "Run import"}
                        </Button>
                    </div>
                </div>
            )}

            {result && (
                <div className="rounded-lg border border-brand-line bg-white p-6 space-y-3" data-testid="import-result">
                    <div className="text-sm font-medium">Import complete</div>
                    <div className="flex gap-2">
                        <Badge variant="secondary">{result.created} created</Badge>
                        <Badge variant="secondary">{result.updated} updated</Badge>
                        {result.errors > 0 && <Badge variant="destructive">{result.errors} errors</Badge>}
                    </div>
                    <Button variant="outline" onClick={rollback} disabled={busy} data-testid="import-rollback">
                        <Undo2 className="w-4 h-4 mr-2" /> Roll back
                    </Button>
                </div>
            )}
        </div>
    );
}
