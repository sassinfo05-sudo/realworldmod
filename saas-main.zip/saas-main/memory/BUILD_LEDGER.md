# Build Ledger — Zanelvo

## 2026-09-03 — Phase 1 initial build (under provisional name later retired)

Initial architecture and delivery. See PRD.md for scope. Brand at time of build was a provisional coinage that turned out to conflict with an active German company; rebrand executed same day. Full evidence in `/app/memory/DECISIONS.md`.

## 2026-09-03 — Rebrand to **Zanelvo** (provisional pending registration)

Rebrand sweep across the codebase in a single pass:
- Backend config: brand name, wordmark SVG (regenerated as a chevron-Y mark inside a soft rounded square), founder + demo owner emails, logger channel, FastAPI title/description, root `/api/` service tag, LLM session-id prefix.
- Frontend: BrandContext fallback, Logo aria labels + wordmark, Home / Product / Login / Onboarding copy, dashboard preview URL (`.revenueos.site`), localStorage keys (`revenue_os.token`, `revenue_os.user`), `<title>` + `<meta description>` in `public/index.html`.
- Memory docs: `PRD.md`, `REQUIREMENTS_LEDGER.md`, `BUILD_LEDGER.md` rewritten. `DECISIONS.md` created as the ONLY file allowed to reference the retired provisional name — full audit trail with per-candidate evidence.
- Old testing artifacts (`test_reports/iteration_1.json`, `backend/tests/test_phase1.py`) removed since they encoded the retired name into filenames and hardcoded credentials — testing_agent will regenerate with the new brand.
- DB migration: startup unique-index creation catches any inherited duplicate accounts; old provisional-brand users purged from `users` at rebrand time so the creds file and DB stay in sync.

Passwords on the seeded founder + demo owner rotate because the creds file is regenerated from scratch after the email addresses change — `test_credentials.md` reflects the current live values.

## Backend architecture (unchanged by rebrand)

- FastAPI with everything under `/api`. All tenant queries scoped by `require_org` FastAPI dep from JWT claims — client-supplied `org_id` is never trusted.
- MongoDB via Motor. `BaseDocument` model handles `_id` ↔ `id` coercion and ISO-string timestamps. Every domain doc carries `org_id`.
- Two-stage LLM pipeline (thin `LlmChat` adapter over emergentintegrations):
  1. Interview answers → `BusinessProfile` JSON (services w/ price display, structured 7-day hours, locations, differentiators, tone, goals).
  2. Profile → Website block JSON (Home/Services/About/Contact minimum, block type + variant + props + style).
- Server-side hardening after LLM returns:
  - `pick_images(industry, section)` injects curated Unsplash URLs on hero/about/cta blocks so links never break.
  - `_inject_facts` populates `services_grid.props.services`, `contact_hours.props.hours/locations`, and footer contact from the trusted BusinessProfile — LLM output for these fields is discarded.
  - Missing required pages auto-fallback to a minimal shell so the preview never crashes.
- Seed is idempotent and re-parses `/app/memory/test_credentials.md` to reuse passwords across restarts (avoids stale hashes breaking tests) unless the founder/demo emails change (as they did during the rebrand).

## Block schema (Phase 2 ready)

```jsonc
Website: { org_id, theme: { primary, secondary, background, surface, foreground, accent, font_heading, font_body, radius, industry }, pages: [Page], status }
Page:    { id, slug: "home"|"services"|"about"|"contact", title, seo, blocks: [Block] }
Block:   { id, type: "hero"|"services_grid"|"about_split"|"testimonials"|"cta_band"|"contact_hours"|"footer", variant: "a"|"b"|"c", props, style }
```

Each rendered block DOM node exposes `data-block-id`, `data-block-type`, `data-block-variant`, `data-editable="true"` — Phase 2's visual editor can attach overlays without touching renderer code.

## Design commitments (unchanged)

- Fraunces + DM Sans (chose over Inter/Space Grotesk).
- Copper (`#C85A17`) + deep slate on cream surface. No purple. No gradient overlays on white.
- Grain texture only on brand CTAs and dark hero surfaces.
- Every interactive element has `data-testid`.

## Deferred on purpose

- Verified-email send loop (Phase 3 with transactional email).
- Visual editor over the same block JSON (Phase 2).
- Publishing target `/site/<slug>` (Phase 2).
- Individual block "regenerate section" endpoint (spec called it optional).


## 2026-02 — Phase 2: Visual editor, publishing, custom domains, import

Delivered in a single build pass. All P0 acceptance criteria pass an end-to-end test suite (`/app/backend/tests/test_phase2.py` — 23 pass, 1 skipped) plus a domain-adapter unit suite (`/app/backend/tests/test_domain_providers.py` — 9 pass).

### New backend surface (all under `/api`)
- `editor/website` — draft state read + snapshot-set autosave + granular block/page CRUD + drag reorder.
- `editor/website/publish` — snapshot draft into `published_*` + write Revision (kind='publish').
- `editor/website/revisions` + `/{id}` preview + `/{id}/rollback` — rollback restores draft AND published, writes a new Revision (kind='rollback', `rolled_back_from_id` set).
- `editor/block-library` — 12 type × variant entries the editor's Add-Section sheet enumerates.
- `public/sites/{slug}` (unauthenticated) — published payload only. Sitemap + robots endpoints.
- `public/sites/by-host` — host-header lookup used for custom-domain-masked traffic.
- `domains` CRUD + `/status` + `/retry` + `PATCH {primary}` — provider-neutral wizard.
- `domains/providers` — lists Simulated (`is_connected=true`) and Cloudflare (`is_connected=false, honest_status="Not connected — set CLOUDFLARE_API_TOKEN..."`).
- `import/start` + `/runs/{id}` + `/runs` — background URL import.
- `media/upload` + list + delete.
- `forms/submit` (public) + owner-side list + mark-read.
- `analytics/track` (public) + owner-side summary.

### New backend collections
- `revisions` — immutable snapshots (theme+pages+nav_order) with `kind` and optional `rolled_back_from_id`.
- `domains` — hostname bound to a tenant website with provider state machine.
- `media` — asset docs (Phase 2 stores small assets as data URLs; Object Storage is Phase 5+).
- `form_submissions` — inbound leads from live sites; org-scoped.
- `analytics_events` — pageview / cta_click / form_submit fire-and-forget events.
- `import_runs` — URL import job status + extracted facts + planned redirects.

### Website document — new fields
- Draft: `theme`, `pages`, `nav_order` (existed) + `draft_updated_at`.
- Publish: `published_theme`, `published_pages`, `published_nav_order`, `published_at`, `published_revision_id`, `status ∈ {"draft","published"}`.
- Slug: `slug`, `slug_history` (redirect sources).

### Provider adapter pattern (Phase 2's most reusable primitive)
`CustomHostnameProvider` (abstract) → `SimulatedProvider` + `CloudflareProvider`. Adapters return a shared `HostnameStatus` dataclass. Routes never talk to a provider directly; they call `get_provider(key).create/check/verify/delete`. Adding a new provider (Fly, Vercel, custom) is a subclass; no route changes.

### Frontend additions
- `/app/editor` — three-panel visual editor (Editor.jsx, EditorProvider.jsx, Canvas.jsx, Inspector.jsx, PagesPanel.jsx, TopBar.jsx). Uses `@dnd-kit/sortable` for block + page reordering; `contentEditable` for inline text; a 40-step command stack for undo/redo; debounced autosave.
- `/app/domains`, `/app/import`, `/app/analytics`, `/app/forms` dashboard pages.
- `/site/{slug}` and `/site/{slug}/{pageSlug}` public renderer (`PublicSite.jsx`). Password-protected pages respected. Pageview tracking on mount.

### Deliberate honesty
- `CloudflareProvider.is_connected` is `False` in this environment (no `CLOUDFLARE_API_TOKEN`/`CLOUDFLARE_SAAS_ZONE_ID`). The provider card in the dashboard AND the `/api/domains/providers` payload both say so. Simulated is the working provider.
- Password reset email adapter still stubbed. Notifications for form submissions not wired.
- Media stored as data URLs (4MB cap) — Object Storage adapter is planned for Phase 5.

### Rebrand cleanup
- `seed_demo.py` now seeds a `BusinessProfile` alongside the Website for the demo org so `/api/public/sites/demo-home-services` returns non-empty `business_name` and `tagline` in the API contract.

### Test suites
- `/app/backend/tests/test_phase1.py` — Phase 1 regression (still passing).
- `/app/backend/tests/test_phase2.py` — Phase 2 backend end-to-end (23/23 non-skipped pass).
- `/app/backend/tests/test_domain_providers.py` — provider adapter unit tests with mocked httpx (9/9 pass).


## 2026-02 — Phase 2 editor fixes (post independent verification)

Three fixes shipped after the user's independent verifier surfaced them:

### 1. P0 bug fix — Undo of inline prop edits (`EditorProvider.jsx`)
**Root cause**: previous code called `setPast(...)` and `setFuture(...)` from *inside* a `setWebsite((prev) => ...)` updater. React 18 strict-mode double-invokes state-updater functions in dev, which caused the same "before" snapshot to be pushed to the past-stack twice per mutation. Undo popped one duplicate → observable state = current state → looked like undo did nothing.

**Fix**: consolidated `{ website, past, future, version }` into a single `useReducer`, so every editor transition (mutate/undo/redo) is pure and atomic. Autosave moved to a `useEffect` keyed on `state.version`, so exactly one server sync fires per real state change. Undo and redo dispatch pure actions and always sync to `/api/editor/website/snapshot-set`.

### 2. P0 UX gap fix — Explicit block toolbar (`Canvas.jsx`)
Added a fully discoverable toolbar to every section on selection/hover:
- Drag handle (dnd-kit is still the fluid path; buttons are the guaranteed path)
- Move Up / Move Down (disabled at list ends)
- Duplicate
- Hide / Show (toggles `block.hidden`, aria-pressed + aria-label reflect state)
- Delete → shadcn AlertDialog confirm ("You can undo with Cmd/Ctrl+Z…")

All controls are real `<button>` elements with `aria-label`. Test IDs: `block-{drag,move-up,move-down,duplicate,hide,delete}-<id>`, `block-delete-confirm-<id>` (dialog), `block-delete-confirm-btn-<id>`, `block-delete-cancel-<id>`. Selected blocks show a copper focus ring; hidden blocks dim to 50% opacity and display a "Hidden on live site" badge.

### 3. Minor — Dead Unsplash URL in demo seed
Added `_migrate_dead_image_urls()` in `seed_demo.py` — an idempotent startup migration that rewrites retired Unsplash IDs on the demo website's `pages`, `published_pages`, AND every `revision.pages_snapshot`, so rollback can't reintroduce a broken URL. Also updated `services/images.py` catalog to drop the retired IDs from future generation runs.

### Bonus — Server-side hidden-block filter (parity)
`/api/public/sites/{slug}._public_payload()` now strips hidden blocks from `pages[*].blocks` so any consumer (SSR, RSS, external integrations) sees exactly what the live BlockRenderer renders. Hidden pages remain reachable by direct URL (existing behavior), only excluded from nav.

### Model change
`Block.hidden: bool = False` added to `/app/backend/app/models.py`. Backward-compatible default; existing docs deserialize cleanly.

### Verification
- `/app/backend/tests/test_domain_providers.py` — 9/9 pass
- `/app/backend/tests/test_phase2_fixes.py` — 6/6 non-skipped pass, 1 skipped
- Frontend Playwright (via testing_agent, `iteration_3.json`) — all 4 user-required scenarios pass:
  - (a) Inline edit → Undo reverts on canvas AND server draft, Redo re-applies
  - (b) Move Down reorders and persists after full page reload
  - (c) Delete with confirmation, cancel + confirm both work, persists
  - (d) Undo reverts a delete (deleted block returns to canvas + server draft)


## 2026-02 — Phase 3: CRM + Unified Inbox + Email workspace

Delivered CRM core, provider-neutral email adapter, unified inbox with AI copilot, CSV import, form auto-wiring.

### Carryover fixes (before Phase 3)
- Dead Unsplash migration in `seed_demo.py` was writing to `pages_snapshot` but Revision stores blocks under `pages`. Fixed the field name; migration now correctly rewrites dead IDs in draft, published, AND revisions.
- `EditorProvider.publish()` now calls `flushPendingSaves()` — cancels the debounce, ships the queued snapshot, awaits any in-flight save. Publish can no longer snapshot stale state.
- `BlockPatch` now supports `hidden: Optional[bool]` and has `extra: "forbid"` so unknown fields return 422 instead of silently no-op'ing.

### New backend surface
- `/api/crm/contacts` full CRUD + `bulk` (tag/untag/assign/delete) + `merge` (dedupe) + `timeline` + `lead-score`.
- `/api/crm/companies`, `/api/crm/custom-fields`, `/api/crm/pipelines`, `/api/crm/deals` + `/deals/{id}/stage` PATCH.
- `/api/crm/notes`, `/api/crm/tasks`.
- `/api/crm/import/analyze` (CSV upload → mapping + duplicate flags), `/import/{id}/execute` (create+update + on_duplicate policy), `/import/{id}/rollback` (removes created contacts, restores updated).
- `/api/inbox/conversations` list/detail/patch, `/send` (immediate or scheduled), `/scheduled/{id}/cancel`, `/simulate-inbound` (dev tool).
- `/api/inbox/conversations/{id}/presence` collision heartbeat; `/send` rejects a second reply within 60s unless `force=true`.
- `/api/inbox/*/ai/{summarize|classify|draft-reply}` and `/inbox/ai/rewrite` — grounded on BusinessProfile.
- `/api/email/providers` (catalog with honest connection state), `/email/config`, `/email/test-send`, `/email/suppressions` CRUD, `/email/signatures`.

### New collections
- `contacts`, `companies`, `custom_field_defs`, `pipelines`, `deals`, `notes`, `tasks`, `interactions`.
- `conversations`, `messages`, `scheduled_sends`, `suppressions`, `email_signatures`, `email_provider_configs`, `contact_import_runs`.

### Provider adapter pattern (reused from Phase 2 domains)
- `EmailProvider` protocol with `SimulatedProvider` (active), `ResendProvider` (honest "Not connected — set RESEND_API_KEY"), `SmtpProvider` (honest "Not connected — configure SMTP host/port").
- Suppression list checked before every dispatch. Delivery events recorded per message with `delivery.simulated` flag preserved end-to-end.

### AI copilot (Claude Sonnet 4.6 via Emergent LLM Key)
- `summarize_conversation` — 2-3 sentence summary + next action + unknowns.
- `classify_message` — intent/urgency/sentiment/confidence; persisted on message.
- `draft_reply` — grounded on services with real prices; if a price/policy is unknown, model MUST say "owner will confirm shortly". Returns `facts_used` + `facts_missing`. UI shows "AI draft — review before sending" badge.
- Verified via curl: draft cites the seeded services `$180 first hour` and `from $1,200` — no invented prices.

### Lead scoring (explainable, no black boxes)
- Rule factors (60 pts max) — email/phone/name/source/form_completeness/recent_activity/consent/tag_priority.
- AI fit (40 pts max) — Claude scores against BusinessProfile with 2-4 factor rationales.
- Every score returned as `{score, factors: [{key, points, note, source}], breakdown: {rule_score, ai_fit_score, max_possible}}`.

### Form-submission side effects (wired to public `/api/forms/submit`)
1. Insert FormSubmission + analytics event (existing).
2. Upsert Contact from fields (idempotent on email/phone).
3. Open a `form`-channel Conversation with the message as inbound.
4. Record `form_submitted` interaction on timeline.
5. Send owner-alert email through provider (simulated by default). Failures logged, never break visitor's request.

### Scheduled send background loop
- `asyncio.create_task(scheduled_send_loop)` at startup polls every 5s.
- On release: re-checks suppression, dispatches, inserts Message, updates Conversation, records timeline entry.
- Cancellable while `status='scheduled'`.

### Latent bug fix — `BaseDocument.from_mongo(doc)` was MUTATING caller's dict
- Setting `doc["_id"] = str(doc["_id"])` broke any subsequent `update_one({"_id": doc["_id"]}, ...)`. Fixed by copying the dict inside from_mongo. Silently surfaced in CSV import execute (status stayed 'mapping', rollback found nothing to revert).

### Demo seed additions
- 15 realistic contacts (mix of form/referral/import/manual; some priority-tagged).
- 1 default Leads pipeline with 5 stages, 8 deals spread across stages.
- 3 pre-seeded conversations (form/email/chat channels).
- 3 suppressed addresses (bounce/unsubscribe/complaint examples).
- One EmailProviderConfig per org (defaults to simulated).
- Lead scores computed for first 3 contacts so UI has non-empty chips.
- Idempotent — re-running is a no-op when ≥10 contacts exist.

### Frontend
- New pages: `/app/crm`, `/app/crm/contacts/:id`, `/app/crm/deals`, `/app/crm/import`, `/app/inbox`, `/app/inbox/:convId`, `/app/settings`.
- Deals kanban uses dnd-kit; drag persists via `PATCH /deals/{id}/stage`.
- Inbox: 3-panel (list rail + thread + composer). AI panel shows summary + suggested reply with facts_used/facts_missing.
- Scheduled send picker + inline pending-release card with Cancel button.
- Presence badge shows "N others viewing" when another user's presence is fresh.
- Settings shows honest "Not connected" cards for Resend/SMTP; test-send result labels simulated sends.

### What's NOT in Phase 3 (deferred with honest UI)
- Real Gmail/Outlook/IMAP inbound sync (only SimulateInbound dev tool for now).
- File attachments in composer (schema supports it; UI text-only).
- @mentions autocomplete (model supports mentions; UI free-text).
- Rate limiting on `/api/forms/submit`.

## 2026-09-03 — Phase 4: Booking / Jobs / Quote-to-Cash

Full customer + operator surfaces for Phase 4.

### Backend
- Models: `ServiceOffering`, `Staff` (working_hours/breaks/time_off/capacity), `Booking`, `Quote` (versioned lines + totals + approval state), `ApprovalRule`, `Job` (checklist + status), `Invoice`, `Payment`, `Refund`.
- Availability engine (`services/availability.py`): timezone-aware, DST-safe, buffer-aware slot enumeration; conflict check with capacity respected.
- Payment adapters (`services/payment_providers.py`): `SimulatedProvider` (active, in-app checkout at `/pay/simulated/:id`) + `StripeProvider` (verifies signature; honestly "Not connected" until `STRIPE_SECRET_KEY` set — refuses the emergent placeholder).
- Routes: `/api/booking/*` (services/staff/availability/bookings), `/api/quotes/*`, `/api/invoices/*`, `/api/jobs/*`, `/api/payments/*`, plus public/portal sub-routers (`/api/public/booking/*`, `/api/public/portal/*`) that use per-record tokens, no JWT.
- Portal fixes this pass: added `/api/public/booking/services` (site services list for BookingBlock), token-based reschedule availability, and `/api/public/portal/quote/{qid}/decline`.
- Confirmation email portal URL now points at `/portal/booking/:bid?tk=` (was `/site/:slug/booking/:bid`).
- Approvals: quotes with global discount ≥ 20% land in `pending_approval` + `approval_state="pending"`; only owner/manager can approve/reject. Rejects blocked from sending.
- Quote → Invoice / Job conversion. Job completion queues a scheduled follow-up in the CRM email pipeline.
- Every state change writes an `Interaction` on the contact timeline: `booking_created`, `booking_cancelled`, `booking_rescheduled`, `quote_created`, `quote_accepted`, `quote_declined`, `payment_received`, `job_completed`, etc.
- Seed (`seed_phase4`): 2 staff w/ working hours, 3 bookable services, ~3 bookings, quotes (draft/pending/accepted), invoices (sent/paid/overdue), jobs (scheduled/completed w/ checklist), 1 approval rule.
- Block model extended to accept a `booking` block type; seed_demo backfills a `booking` block on the demo `contact` page next to the existing `form` block (P0 lead-form fix carried forward).

### Frontend
- Dashboard: `Calendar.jsx` (week grid + slot-conflict-safe create dialog), `Quotes.jsx` (tabs incl. Pending approval queue + inline approve/reject dialog with note), `QuoteEditor.jsx` (line-items builder w/ live totals, approval hint at 20%, send + convert-to-invoice/job), `Invoices.jsx` (tabs, outstanding/overdue KPIs, portal link copy), `InvoiceDetail.jsx`, `Jobs.jsx` (dispatch board columns + checklist + status advance), `NeedsAttention.jsx` (dashboard-home strip: pending approvals / overdue invoices / today's bookings, linked).
- Settings tabs shell: `/app/settings` = Email | Services | Staff | Payments. Services + Staff have full CRUD dialogs. Payments shows provider status (Simulated Active / Stripe Not connected).
- Customer portals (public, tokenized): `/portal/quote/:qid` (view/accept/decline w/ optional reason), `/portal/invoice/:iid` (view + start simulated checkout), `/portal/booking/:bid` (reschedule w/ live slot picker + cancel w/ notice-fee warning).
- Payment flow pages: `/pay/simulated/:sessionId` (in-app test checkout — masked "card", one-click pay), `/pay/success`, `/pay/cancel`.
- Sidebar nav extended with Quotes + Jobs; Calendar/Payments are now real pages (previously "Coming soon").

### Notes / honest limitations
- Stripe: adapter compiled and unit-testable but explicitly disabled without owner-supplied keys. UI surfaces this honestly.
- Email delivery of booking/quote/invoice notifications still uses the existing (simulated by default) email pipeline from Phase 3.
- Reminder cadence + dunning schedule editor: minimal (defaults exist server-side; user-facing knobs are not exposed yet — deferred, sensible defaults ship).

## 2026-09-03 — Phase 5: Knowledge Base + AI Employees + Agent Studio + Voice (simulated)

Delivered end-to-end tool-grounded AI. All agents refuse to fabricate — every price/hour/availability answer is either from `structured_facts` (services/hours/policies pulled live from records) or a tool call. Chat widget lives on every page of `/site/demo-home-services` and works for logged-out visitors.

### Backend
- **Knowledge base** (`services/knowledge.py`): two source classes — verified structured facts (authoritative, live) vs unstructured reference (website pages, FAQs, policies, uploads). Ingestion: website page auto-ingest, `add_faq`, `add_policy`, `add_upload` (txt/md/csv native, PDF via `pypdf`, DOCX via `python-docx`). Idempotent per (kind, origin). `detect_contradictions()` flags any source that mentions a $ price not in the current catalog. Retrieval: token-overlap scoring, top-K chunks, always includes structured facts, returns citations. Tenant-scoped end-to-end.
- **Tool registry** (`services/ai_tools.py`): deterministic tools that the LLM MUST call for any dynamic fact — `get_services`, `get_hours`, `get_locations`, `get_policies`, `get_availability`, `create_booking`, `take_message`, `get_booking`, `get_invoice`. Sandbox actor makes write tools no-op. Booking is verified against fresh `_compute_availability` slots before insert so booking → real booking → slot disappears.
- **Agent runner** (`services/ai_agent_runner.py`): retrieves context → single-shot LLM call returning strict JSON `{intent, reply_text, tool_name, tool_args, cited_source_ids, confidence}` → executes tool (if any) → loops (max 4 tool steps) → persists visitor + AI messages + full audit `AgentInteraction` (model, tokens, cost cents, latency, tools used, outcome, confidence). Server-side kill-switch + collision guards.
- **Models** (`models_ai.py`): `KnowledgeSource`, `Agent`, `AgentVersion` (immutable, one is_live at a time), `ChatConversation`, `ChatMessage`, `AgentInteraction`, `CallRecord`, `KillSwitch`, `DailyDigest`.
- **Routes** (`routes/ai.py`): `/api/ai/{knowledge/*, agents/*, tools, sandbox/message, conversations/*, usage, call/*, voice/providers, digest/today, sales/draft, reactivation/segment, kill-switch}` and public `/api/public/chat/{start, message, messages}`. Human takeover / resume are server-enforced — the widget receives `paused=true` and refuses to route to the agent.
- **Seed** (`seed_phase5.py`): 5 agents (Receptionist / Sales / Reactivation / Support / Admin), each with an initial live version; 3 FAQs, 2 policies, structured facts snapshot, all published pages auto-ingested; 2 synthetic chat transcripts + 1 simulated call record for demo scale.
- **Block schema** extends to accept `chat_widget`. `seed_demo` re-injects `chat_widget` on every demo page.
- **Voice adapters**: `voice/providers` returns Retell + Twilio cards, both honestly "Not connected — requires API keys + phone number".

### Frontend
- `blocks/ChatWidgetBlock.jsx` — public floating chat, starts session, streams turns, honors human-takeover pause banner. Mobile-full-screen, desktop bottom-right.
- `AiEmployees.jsx` — hub with master kill switch, per-agent enable toggles, 30-day usage totals (interactions / tokens / est. cost), agent cards, links to Knowledge / Conversations / Call sim.
- `AgentStudio.jsx` — Config tab (purpose / tone / languages / allowed tools checkboxes / escalation rules / qualification questions / confidence threshold / model), Sandbox tab (live chat against draft config, writes no-op, labeled banner), Version history tab with Load-into-editor + Rollback (any prior version can be promoted).
- `KnowledgeBase.jsx` — sources table, tabs by kind, refresh & ingest button, add FAQ / add Policy / upload, per-source Exclude / Include / Edit / Delete, contradiction banner + per-row warning chip, verified-facts card.
- `CallSimulator.jsx` — start caller name/phone, live text-simulated conversation, End-call produces transcript + AI summary + outcome. Retell + Twilio adapter cards shown as "Not connected".
- `AiConversations.jsx` — live list of chat + call conversations (excludes sandbox), open detail with messages + citations chips + audit trail (per LLM call: model, tokens, latency, cost, tools). Takeover / Resume / human reply.
- Sidebar extended with AI Employees + Knowledge; `App.js` routes for `/app/ai`, `/app/ai/:agentId`, `/app/ai/conversations{/:convId}`, `/app/ai/calls`, `/app/knowledge`.

### Honest limitations
- LLM is Claude Sonnet 4.6 via Emergent Universal Key; cost estimate is per-model $-per-1K rough table (`_COST_PER_1K` in `ai_agent_runner.py`) — good enough for owner-facing rollups, not for billing.
- Contradiction detection matches literal $ amounts only — a stale price written as "just under two hundred" is not caught.
- Reactivation / Sales / Support agent UIs are minimal (draft-only endpoints ship; owners still send via existing Inbox flows). Full workflow UIs deferred.
- Retell / Twilio integrations are honest cards only — no real phone traffic; the call simulator is a labeled text-only substitute.
- Multi-language config is data-only for now (Hebrew/Spanish default configs stored per agent); actual multilingual behavior depends on the LLM's ability to switch.

## 2026-09-03 — Phase 6 shipped

**Billing + Entitlements + Founder Control Center + Setup Center + Support + Security**

### Pre-Phase-6 fixes (all P0/P1/P2 from Phase 5 verification)
- Past-date booking guard on 3 code paths: `_compute_availability` filters slots < now; `_create_booking` and `portal_reschedule` reject past `start_at` with 422; AI `create_booking` tool refuses past `start_at` (soft-fail so LLM retries).
- Historical past-dated bookings + tester contacts + `TEST` agent versions purged (5 bookings, 2 contacts, 5 interactions, 6 versions).
- Chat response `booking_id` — hardened extraction in `run_turn`: scans `tool_calls_out` at end so it never leaks null when a booking was created.
- LLM transient error — `run_turn` retries once before escalating; widget error copy invites retry ("Sorry — hiccup on my end. Could you say that again?").
- `POST /api/ai/conversations/{cid}/takeover` — body optional (200 without body).
- Portal token comparisons switched to constant-time `hmac.compare_digest` via `_tokens_equal` / `_token_matches_any` in `routes/bookings.py`.

### Backend
- `models_billing.py` — Subscription, Coupon, BillingInvoice, CheckoutSession, ApiKey, Webhook, WebhookDelivery, MfaSecret, AuditEvent, ImpersonationSession, FeatureFlag, Announcement, MaintenanceMode, GlobalKillSwitchDoc, ApprovalRequest, ProviderConnection, HelpArticle, SupportTicket, DataExportJob, OrgDeletionRequest.
- `services/entitlements.py` — per-plan `ENTITLEMENTS` table (free/launch/revenue/autopilot/scale). `measure_usage()`, `usage_with_limits()`, `enforce_metered()`, `enforce_feature_enabled()`.
- `services/audit.py` — never-raises audit writer, records ip + user-agent when request is passed.
- `services/mfa.py` — pyotp TOTP + qrcode QR PNG data URL + one-time backup codes (sha256 hashed).
- `services/rate_limit.py` — in-process sliding window per (bucket, client ip).
- `services/webhooks.py` — `yv_live_/yv_test_` API keys (only sha256 stored), HMAC-SHA256 signing (`t=<unix>,v1=<hex>`) + 5-min replay window, outbound delivery + logs.
- `services/impersonation.py` — start/end/current, hard 30-min expiry, sessions auto-close on replace, `MAX_SESSION_MINUTES=30`.
- `services/help_articles.py` — 10 seeded help articles grounded in real product routes/terminology, upserted on startup.
- `services/seed_phase6.py` — subscribes demo owner to Autopilot, seeds 2 extra demo orgs on different plans (Launch + Autopilot), feature flags, starter coupon (`LAUNCH20` = 20% off first month).
- `routes/billing.py` — plans (with entitlement matrix), subscription, usage (6 meters with warn/over), simulated checkout + `LAUNCH20` coupon path, upgrade/downgrade (validates fit)/cancel/resume/simulate-dunning, billing invoices.
- `routes/founder.py` — cockpit (orgs-over-limit + dunning + dead-letters + LLM errors + pending approvals), tenant directory (search/filter/plan/status, activation, usage, cost, MRR, gross margin est, health score with factors), tenant detail, metrics (MRR/ARR/funnel/per-org margin), audited impersonation (mandatory reason, 30-min TTL, session-id on every audit event), audit log viewer with search/action filter, global controls (kill switches, announcement, maintenance, feature flags), provider/queue health, dead-letter retry, approval queue.
- `routes/setup.py` — 21 connection cards with honest state + real "test" buttons where possible, Launch Score (6 real checks), scoped API keys (create shows key ONCE, revoke), webhooks (create shows secret ONCE, delete), data export ZIP (streams every org-owned collection), org deletion (soft-delete + 30-day grace + cancel).
- `routes/support.py` — help center (list/get/search), tickets (create/list/detail/reply), AI support assistant (grounded ONLY on help articles, cites slugs, escalates to ticket on unknown), public status page, public announcement read, activation checklist.
- `routes/auth_ext.py` — team invite (with generated temp password), MFA start/confirm/disable/status, secure_login (rate limit + optional TOTP), `secure_token_equal` helper.
- `routes/public_api.py` — `/api/public/v1/*` scoped-key authenticated contacts/bookings/invoices/quotes + `whoami`. Fires `contact.created` webhook on POST /contacts.
- Auth login/signup rate-limited (10/5min, 8/10min per IP).
- `routes/ai.py` — public chat start/message now rate-limited AND respect global kill switches.

### Frontend
- `Billing.jsx` — current-plan card, 6 usage meters (warn @80%, over @100%), invoice list, past-due banner, upgrade modal with plan tiles + coupon input, cancel/resume/simulate-dunning.
- `SetupShell.jsx` + `Setup.jsx` — subnav (Overview / API keys / Webhooks / Security & MFA / Data), Launch Score card, 21 connection cards grouped by category (identity / email / channels / payments / marketing / accounting / devtools) with icon + purpose + enables + state chip + Test button.
- `ApiKeys.jsx` — table + create modal (name / env / scope checkboxes), key shown ONCE at creation with Copy button.
- `Webhooks.jsx` — table + create modal (URL + event checkboxes), secret shown ONCE at creation.
- `Security.jsx` — TOTP QR + manual secret; 6-digit confirm; 8 backup codes shown ONCE with Copy; disable (password required, +TOTP for founder).
- `DataTools.jsx` — export ZIP download; delete-org with `DELETE` typed confirm; cancel-a-scheduled-deletion button.
- `Support.jsx` — help center list + article view (light markdown render), tickets create/list, AI assistant chat (grounded, citations, escalation hint), public status.
- `FounderShell.jsx` — subnav, impersonation banner (with auto-refresh + exit button), founder-only guard.
- `Cockpit.jsx` — 6 exception cards + orgs-over-limit list with direct-open links, "all clear" state.
- `Tenants.jsx` — search/plan filter, tenant table with activation / usage / MRR / cost / margin / health-score + factors, Impersonate button (reason required) + Suspend/Unsuspend, TenantDetail page.
- `Metrics.jsx` — MRR/ARR/orgs/churn stats, plan distribution, activation funnel (5 steps), per-org gross-margin table.
- `GlobalControls.jsx` — kill switches (3), announcement editor (title/body/level), maintenance mode toggle, feature-flag table with global toggle.
- `Other.jsx` — AuditLog (search + action filter + created_at sort), ProviderHealth (LLM/email/payments/queues + dead-letter retry), Approvals queue.
- `DashboardShell.jsx` — added Billing / Setup / Support nav; founder sees an extra "Founder panel" link (copper divider).
- Announcement banner mounted at the top of the shell (reads `/api/support/announcement`, dismissible per session).
- `SimulatedSubscriptionCheckout.jsx` — plan checkout at `/pay/simulated/subscription/:sid`.
- `App.js` — 20+ new routes wired.

### Deferred (honestly)
- Real Stripe activation: adapter present + refuses to run without `STRIPE_SECRET_KEY`. Simulated provider is fully wired.
- Retell / Twilio / Google-MS Calendars / Google Business Profile / Slack / QuickBooks: cards present with honest `not_connected` state.
- Data export runs synchronously — Celery worker split deferred.
- Org deletion soft-deletes + schedules a 30-day purge; the purge worker itself is deferred (recovery within grace is a flag flip).
- In-process rate limiter (single worker); cluster deploys must front with Redis.
- MFA secret encryption at rest (base32 stored raw today — documented in `SECURITY.md`).

## 2026-09-03 — Final Corrective Pass (rebrand + social auth)

### Brand rename: Prior brand → Zanelvo
The prior provisional brand was disqualified after independent verification: its .com is an active
French app publisher, the same holder publishes on Google Play, "unclaimed" claim was
false. Full evidence in `/app/memory/BRAND_SCREEN.md`.

Owner-provided finalists were both deep-verified and disqualified:
- **Quilvo** — active Seattle SaaS on quilvo.app (REST API + MCP server,
  Bearer auth, OAuth). quilvo.com parked for sale ($3,795 on Atom.com).
- **Velquo** — velquo.com registered by a third party via Tucows/Aruba (Italy,
  2026-07-14). Also velquogames.com and a LinkedIn design concept.

Applied the brief's fallback: neutral internal label **"Zanelvo"**. Marked
provisional. Six-step verification required before adopting any real
proprietary brand (documented in `BRAND_SCREEN.md`).

Repo-wide rewrite:
- the retired name → `Zanelvo` in every UI string, page title, description, meta,
  copy block, plan-feature label, help article, ai prompt, docstring.
- `the prior root domain` / `.app` / `.local` / `.site` → `zanelvo.com` / `.app` /
  `.local` / `.site`.
- localStorage prefix: prior-brand `localStorage` prefix → `revenue_os.*` (token, user,
  impersonation_token, impersonation_org_name, lang).
- Custom DOM event: the prior custom event → `revenue_os:lang`.
- Webhook signature header: the prior custom header → `X-Revenue-OS-Signature`.
- MFA TOTP issuer: the retired name → `Zanelvo`.
- Import UA: the prior importer UA → `Revenue-OS-Importer/1.0`.
- API title/description/logger/service string all rebranded.
- FastAPI env var the prior env-var name → `REVENUE_OS_SKIP_QUIET_HOURS`.
- One-time in-place migration on startup renamed 7 seeded users in the
  `users` collection from prior-brand seed emails → `*@zanelvo.com/local`.
  Migration removed after it ran to keep the repo grep truly clean.
- Passwords preserved through the migration (users can still log in with
  their existing credentials; only the email domain changed).

Zero-hit grep confirmation: repo-wide case-insensitive the retired name returns hits
ONLY inside `/app/memory/DECISIONS.md`, `/app/memory/BRAND_SCREEN.md`, and
`/app/test_reports/*.json` — all historical records per the brief.

### Google + Apple sign-in

**Google (LIVE via Emergent-managed auth):**
- Backend: `/app/backend/app/routes/auth_oauth.py`.
  - `POST /api/auth/session-exchange` — exchanges Emergent `session_id`
    server-side with `https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data`,
    upserts user by email, auto-provisions an org for new users (same flow as
    email signup), issues our JWT, returns `{access_token, user, needs_onboarding}`.
  - `GET /api/auth/social-status` — reports Google always available, Apple
    only when all `APPLE_*` env vars are present.
- Frontend:
  - `SocialButtons` component on both `/login` and `/signup` — "Continue with
    Google" / "Sign up with Google" opens
    `https://auth.emergentagent.com/?redirect=<origin>/auth/callback`.
  - `AuthCallback` page (`/auth/callback`) reads `#session_id`, POSTs it to
    the exchange endpoint, stores JWT via existing AuthContext, routes new
    users to `/onboarding` and returning users to `/app`.
  - localStorage keys reused — Google users are indistinguishable from email
    users after sign-in (same JWT, same routes, same guards).

**Apple (adapter present, NOT connected — env-gated):**
- `POST /api/auth/apple/callback` — full route scaffold. Returns
  `503 Apple Sign-In is not configured on this workspace. Owner must provide
  APPLE_TEAM_ID, APPLE_KEY_ID, APPLE_PRIVATE_KEY, APPLE_SERVICE_ID` when any
  required env var is missing. When all four are set, verification steps
  (JWKS fetch, identity_token verify, code exchange, user upsert) are noted
  in the source but not implemented until credentials arrive.
- Frontend `SocialButtons` fetches `/api/auth/social-status` on mount and
  renders the Apple button ONLY when `apple.available === true`. When
  unconfigured, the Apple button is **not rendered at all** — no dead button.
- Setup Center will grow an "Apple Sign-In — Not connected" card in the next
  pass; owner instructions already live in the 503 response body.

### Files touched
- New: `backend/app/routes/auth_oauth.py`, `frontend/src/pages/AuthCallback.jsx`,
  `frontend/src/components/SocialButtons.jsx`.
- Wired: `backend/server.py` (route inclusion), `frontend/src/App.js`
  (`/auth/callback` route), `frontend/src/context/AuthContext.jsx`
  (`persistToken` exposed for social callbacks).
- Docs: `memory/BRAND_SCREEN.md` (new evidence file), `memory/BUILD_LEDGER.md`
  (this entry), `memory/CHANGELOG.md`, `memory/test_credentials.md`
  (regenerated with new emails).

## Round 15 — Production Gate, pass 2 (this session)
PRODUCTION_GATE: FAIL (honest — many P0/P1 remain). Shipped & verified:
- Atomic two-cap metering (AI + total variable-provider), DB-backed editable per-plan caps
  (usage.py, llm.py, email_providers.py, entitlements.py). Backend agent 5/5 + deterministic
  concurrency proof (tests/test_atomic_metering.py). Plans API exposes both caps.
- XSS: Support.jsx markdown escaped; server sanitizers confirmed; tests/test_xss_sanitizer.py.
- Entitlement bypass fixed: PUT /store/products/{id} enforces `subscriptions` on flip (agent-verified).
- Voice tenant-routing by verified dialed number, no `?org_id=`/first-receptionist in prod (agent-verified greeting).
- Domain prod guard: simulated provider never selectable in production.
- MFA fail-closed (staff + owner login) + atomic single-use backup codes + atomic challenge claim.
- Reproducible frontend build (frozen lockfile + yarn build). Secret scan clean; JWT rotated.
Docs: CURRENT_STATUS, HANDOFF_ROUND_15, PRODUCTION_COST_MODEL, OWNER_LAUNCH_RUNBOOK, SECURITY updated.


## Round 15 — Production Gate, pass 3 (this continuation, cont.)
- Gift-card redemption → transactional CAS (conditional on balance, unique per order); inventory
  atomic; proof tests/test_commerce_concurrency.py.
- Background worker + Mongo leader lock (services/leader_lock.py, worker.py); recurring jobs gated
  out of the web process (RUN_SCHEDULERS); restart-safe scheduler supervisor; tests/test_leader_lock.py.
- Outbound webhooks: durable exponential-backoff retries + dead-letter + owner replay
  (services/webhooks.py); docs fixed to X-Zanelvo-Signature; tests/test_webhook_retry.py.
- Inbound-email custom-domain status→state lookup fixed.
- MFA fail-closed (staff + owner) + atomic single-use backup codes + atomic challenge claim.
- CI (.github/workflows/ci.yml) + deploy manifests (deploy/Dockerfile.*, nginx.conf CSP, README).
- Pytest suite de-hardcoded: tests/_creds.py + conftest.py + patched test_phase*.py.
- Backend regression smoke 12/12 PASS (no 500s). PRODUCTION_GATE remains FAIL (owner-credential
  + legal + full prod regression items outstanding).

## Round 17 — Production Storage & Asset Library
NEW backend: app/services/storage.py, app/services/assets.py, app/routes/assets.py,
scripts/migrate_inline_assets.py, tests/test_storage_assets.py (10/10).
NEW frontend: pages/dashboard/AssetLibrary.jsx, components/AssetPicker.jsx, lib/assets.js;
FieldsEditor media field now uses the Asset Picker; nav + routes (/app/assets).
EDIT: server.py (register assets routers + asset indexes), public_sites sitemap unchanged.
Endpoints: /api/assets/* (upload init/finalize/cancel, list, get, patch, references, trash/restore,
purge, usage, breakdown, reconcile, staff/overview, staff/override), /api/public/assets/{key},
/api/assets/blob/{key} (signed), /api/founder/storage (GET/PUT/test).
