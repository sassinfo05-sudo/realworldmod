"""Public brand config + plans (white-label aware)."""
from fastapi import APIRouter

from ..db import get_db
from ..services import platform_settings as ps
from ..services.entitlements import entitlements_dict

router = APIRouter(tags=["public"])


@router.get("/brand")
async def get_brand():
    db = get_db()
    doc = await db.brand_config.find_one({"key": "primary"}, {"_id": 0}) or {}
    # Overlay founder-editable white-label identity so a rename propagates everywhere.
    settings = await ps.get_settings()
    if settings.get("brand_name"):
        doc["name"] = settings["brand_name"]
    doc["support_email"] = settings.get("support_email")
    doc["product_url"] = settings.get("product_url")
    doc["company_name"] = settings.get("company_name")
    doc["company_address"] = settings.get("company_address")
    doc["footer_note"] = settings.get("footer_note")
    # public-safe email map (support/sales/etc.) — these are intended for visitors
    emails = settings.get("emails") or {}
    doc["emails"] = {
        role: {"address": (cfg or {}).get("address", ""),
                "display_name": (cfg or {}).get("display_name", "")}
        for role, cfg in emails.items()
        if role in {"support", "sales", "marketing"}  # only publish visitor-safe ones
    }
    # Public-visible legal / about HTML (blank = template)
    doc["legal"] = settings.get("legal") or {}
    # Legal-review launch gate: generated Terms/Privacy are shown as DRAFT until a human confirms review.
    try:
        from .founder import _read_launch_gate
        doc["legal_reviewed"] = bool((await _read_launch_gate(db))["legal_reviewed"])
    except Exception:  # noqa: BLE001
        doc["legal_reviewed"] = False
    return doc


@router.get("/plans")
async def list_plans():
    db = get_db()
    settings = await ps.get_settings()
    disc = max(0.0, min(90.0, float(settings.get("annual_discount_pct", 20) or 0)))
    cursor = db.plans.find({}, {"_id": 0}).sort("order", 1)
    out = []
    async for p in cursor:
        price = float(p.get("price_usd") or 0)
        if p.get("annual_price_usd") is not None and price > 0:
            # Real annual price set in the Staff panel wins over the generic discount %.
            annual_total = round(float(p["annual_price_usd"]), 2)
            annual_monthly = round(annual_total / 12.0, 2)
            plan_disc = round((1 - annual_monthly / price) * 100, 1)
        else:
            annual_monthly = round(price * (1 - disc / 100.0), 2)
            annual_total = round(annual_monthly * 12, 2)
            plan_disc = disc
        p["price_monthly"] = price
        p["annual_discount_pct"] = plan_disc
        p["price_annual_monthly"] = annual_monthly  # per-month when billed annually
        p["price_annual_total"] = annual_total
        p["limits"] = entitlements_dict(p.get("code"))
        out.append(p)
    return out


@router.get("/industries")
async def list_industries():
    """Industry catalog used by the onboarding interview (questions step)."""
    from .. import config
    return config.INDUSTRIES
