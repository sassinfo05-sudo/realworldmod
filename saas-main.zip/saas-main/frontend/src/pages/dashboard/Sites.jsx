import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Globe2, Lock, Plus, Trash2, Check, Pencil, ExternalLink, Copy, ShieldCheck, Link2 } from "lucide-react";

/** Sites manager: multiple websites per plan, per-site private/maintenance mode, domain → page binding. */
export default function Sites() {
    const [state, setState] = useState(null);
    const [creating, setCreating] = useState(false);
    const [name, setName] = useState("");
    const [cloneFrom, setCloneFrom] = useState("");
    const [editing, setEditing] = useState(null);  // site for maintenance dialog
    const [busy, setBusy] = useState(false);

    async function load() {
        try { const { data } = await api.get("/sites"); setState(data); } catch (e) { toast.error("Could not load sites"); }
    }
    useEffect(() => { load(); }, []);
    const notifyChange = () => window.dispatchEvent(new Event("zanelvo:sites-changed"));

    async function create(e) {
        e.preventDefault(); setBusy(true);
        try {
            const { data } = await api.post("/sites", { name, clone_from: cloneFrom || null });
            setState(data); setCreating(false); setName(""); setCloneFrom(""); notifyChange();
            toast.success("Site created — it's now your active site");
        } catch (err) {
            const d = err?.response?.data?.detail;
            toast.error(typeof d === "object" ? d.message : d || "Could not create site");
        } finally { setBusy(false); }
    }
    async function activate(id) {
        try { const { data } = await api.post(`/sites/${id}/activate`); setState(data); notifyChange(); toast.success("Active site switched"); }
        catch { toast.error("Could not switch"); }
    }
    async function remove(site) {
        if (!window.confirm(`Delete "${site.name}"? This cannot be undone.`)) return;
        try { const { data } = await api.delete(`/sites/${site.id}`); setState(data); notifyChange(); toast.success("Site deleted"); }
        catch (e) { toast.error(e?.response?.data?.detail || "Could not delete"); }
    }
    async function rename(site) {
        const n = window.prompt("Site name", site.name);
        if (!n || n === site.name) return;
        try { const { data } = await api.patch(`/sites/${site.id}`, { name: n }); setState(data); notifyChange(); } catch { toast.error("Rename failed"); }
    }
    async function quickToggle(site, enabled) {
        try { const { data } = await api.put(`/sites/${site.id}/maintenance`, { enabled }); setState(data); notifyChange(); toast.success(enabled ? "Site is now private" : "Site is public again"); }
        catch { toast.error("Could not update"); }
    }

    if (!state) return <div className="p-8 text-sm text-zinc-500">Loading sites…</div>;
    return (
        <div className="px-4 md:px-8 py-6 md:py-8 max-w-[1200px] mx-auto" data-testid="sites-page">
            <div className="flex flex-wrap items-end justify-between gap-3 mb-6">
                <div>
                    <h2 className="font-display text-2xl md:text-3xl text-brand-ink dark:text-white">Sites & maintenance</h2>
                    <p className="text-sm text-zinc-500 mt-1">Run several websites from one account, each with its own pages, domains and private mode. <b>{state.used}/{state.limit}</b> used on your plan.</p>
                </div>
                <div className="flex gap-2">
                    {!state.can_create && <Button asChild variant="outline"><Link to="/app/billing" data-testid="sites-upgrade-link">Upgrade for more sites</Link></Button>}
                    <Button onClick={() => setCreating(true)} disabled={!state.can_create} data-testid="sites-new-btn"><Plus className="w-4 h-4" /> New site</Button>
                </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
                {state.sites.map((s) => (
                    <div key={s.id} className={`rounded-2xl border bg-white dark:bg-zinc-900 p-5 ${s.is_active ? "border-brand-copper shadow-[0_12px_40px_-20px_rgba(79,70,229,0.5)]" : "border-brand-line"}`} data-testid={`site-card-${s.id}`}>
                        <div className="flex items-start gap-3">
                            <span className="w-11 h-11 rounded-xl grid place-items-center text-white text-lg font-semibold shrink-0" style={{ background: s.theme_primary || "#4F46E5" }}>{(s.name || "S")[0]}</span>
                            <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                    <h3 className="font-medium truncate">{s.name}</h3>
                                    {s.is_active && <span className="text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full bg-brand-copper/10 text-brand-copper">Active</span>}
                                    <span className={`text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full ${s.maintenance.enabled ? "bg-amber-100 text-amber-800" : s.status === "published" ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-600"}`} data-testid={`site-status-${s.id}`}>
                                        {s.maintenance.enabled ? "Private" : s.status === "published" ? "Live" : "Draft"}
                                    </span>
                                </div>
                                <div className="text-xs text-zinc-500 mt-0.5">{s.pages} page{s.pages === 1 ? "" : "s"} · {s.public_url_path ? <a href={s.public_url_path} target="_blank" rel="noreferrer" className="hover:text-brand-copper inline-flex items-center gap-1">{window.location.host}{s.public_url_path} <ExternalLink className="w-3 h-3" /></a> : "not published yet"}</div>
                                {s.domains.length > 0 && (
                                    <div className="mt-2 flex flex-wrap gap-1.5">
                                        {s.domains.map((d) => <span key={d.id} className="text-[11px] px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-white/10 inline-flex items-center gap-1"><Link2 className="w-3 h-3" />{d.hostname}{d.landing_page_slug ? ` → /${d.landing_page_slug}` : ""} <span className={`w-1.5 h-1.5 rounded-full ${d.state === "connected" ? "bg-emerald-500" : "bg-amber-400"}`} /></span>)}
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="mt-4 flex items-center justify-between gap-2 border-t border-brand-line pt-3">
                            <label className="flex items-center gap-2 text-xs text-zinc-600">
                                <Switch checked={!!s.maintenance.enabled} onCheckedChange={(v) => quickToggle(s, v)} data-testid={`site-private-toggle-${s.id}`} />
                                <Lock className="w-3.5 h-3.5" /> Private / maintenance
                            </label>
                            <div className="flex gap-1">
                                <Button size="sm" variant="ghost" onClick={() => setEditing(s)} data-testid={`site-maintenance-btn-${s.id}`}><ShieldCheck className="w-3.5 h-3.5" /> Page & password</Button>
                                <Button size="sm" variant="ghost" onClick={() => rename(s)} title="Rename"><Pencil className="w-3.5 h-3.5" /></Button>
                                {!s.is_active && <Button size="sm" variant="outline" onClick={() => activate(s.id)} data-testid={`site-activate-${s.id}`}><Check className="w-3.5 h-3.5" /> Make active</Button>}
                                {state.sites.length > 1 && <Button size="sm" variant="ghost" className="text-red-600" onClick={() => remove(s)} title="Delete"><Trash2 className="w-3.5 h-3.5" /></Button>}
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="mt-8 rounded-2xl border border-dashed border-brand-line p-5 text-sm text-zinc-600 flex flex-wrap items-center gap-3">
                <Globe2 className="w-5 h-5 text-brand-copper" />
                <div className="flex-1 min-w-[240px]">Every page has its own address: <code className="text-xs bg-zinc-100 px-1.5 py-0.5 rounded">/site/&lt;name&gt;/&lt;page&gt;</code>. Connect a domain per site and point it at any page (e.g. <i>book.yourbiz.com → /booking</i>) from <Link to="/app/domains" className="text-brand-copper">Domains</Link>.</div>
            </div>

            <Dialog open={creating} onOpenChange={setCreating}>
                <DialogContent data-testid="sites-create-dialog">
                    <DialogHeader><DialogTitle>Create a new website</DialogTitle></DialogHeader>
                    <form onSubmit={create} className="space-y-4">
                        <div><Label>Site name</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Downtown branch" required minLength={2} className="mt-1" data-testid="sites-create-name" /></div>
                        <div><Label>Start from</Label>
                            <select value={cloneFrom} onChange={(e) => setCloneFrom(e.target.value)} className="mt-1 w-full h-10 rounded-lg border border-brand-line bg-white px-3 text-sm" data-testid="sites-create-clone">
                                <option value="">Blank starter (home page with hero, services, contact)</option>
                                {state.sites.map((s) => <option key={s.id} value={s.id}>Duplicate “{s.name}”</option>)}
                            </select></div>
                        <div className="flex justify-end gap-2"><Button type="button" variant="outline" onClick={() => setCreating(false)}>Cancel</Button><Button type="submit" disabled={busy} data-testid="sites-create-submit">{busy ? "Creating…" : "Create site"}</Button></div>
                    </form>
                </DialogContent>
            </Dialog>

            {editing && <MaintenanceDialog site={editing} onClose={() => setEditing(null)} onSaved={(d) => { setState(d); notifyChange(); setEditing(null); }} />}
        </div>
    );
}

function MaintenanceDialog({ site, onClose, onSaved }) {
    const m = site.maintenance || {};
    const [form, setForm] = useState({ enabled: !!m.enabled, title: m.title || "We'll be right back", message: m.message || "Our site is getting a fresh coat of paint. Check back soon!", eta: m.eta || "", accent: m.accent || site.theme_primary || "#4F46E5", show_logo: m.show_logo !== false, contact_email: m.contact_email || "", password: "" });
    const [clearPw, setClearPw] = useState(false);
    const [busy, setBusy] = useState(false);
    const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
    async function save(e) {
        e.preventDefault(); setBusy(true);
        try {
            const payload = { ...form };
            if (!form.password && !clearPw) delete payload.password;
            if (clearPw) payload.password = "";
            const { data } = await api.put(`/sites/${site.id}/maintenance`, payload);
            toast.success("Maintenance page saved"); onSaved(data);
        } catch (err) { toast.error(err?.response?.data?.detail || "Could not save"); } finally { setBusy(false); }
    }
    return (
        <Dialog open onOpenChange={(o) => !o && onClose()}>
            <DialogContent className="max-w-3xl" data-testid="maintenance-dialog">
                <DialogHeader><DialogTitle>Private / maintenance mode — {site.name}</DialogTitle></DialogHeader>
                <form onSubmit={save} className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                        <label className="flex items-center justify-between rounded-lg border border-brand-line p-3 text-sm"><span className="flex items-center gap-2"><Lock className="w-4 h-4" /> Site is private</span><Switch checked={form.enabled} onCheckedChange={(v) => set("enabled", v)} data-testid="maintenance-enabled" /></label>
                        <div><Label>Headline</Label><Input value={form.title} onChange={(e) => set("title", e.target.value)} className="mt-1" data-testid="maintenance-title" /></div>
                        <div><Label>Message</Label><textarea value={form.message} onChange={(e) => set("message", e.target.value)} rows={3} className="mt-1 w-full rounded-lg border border-brand-line px-3 py-2 text-sm" data-testid="maintenance-message" /></div>
                        <div className="grid grid-cols-2 gap-3">
                            <div><Label>Back on (optional)</Label><Input value={form.eta} onChange={(e) => set("eta", e.target.value)} placeholder="Monday 9am" className="mt-1" /></div>
                            <div><Label>Accent color</Label><div className="flex gap-2 mt-1"><input type="color" value={form.accent} onChange={(e) => set("accent", e.target.value)} className="h-10 w-12 rounded border border-brand-line" /><Input value={form.accent} onChange={(e) => set("accent", e.target.value)} /></div></div>
                        </div>
                        <div><Label>Contact email shown (optional)</Label><Input value={form.contact_email} onChange={(e) => set("contact_email", e.target.value)} placeholder="hello@yourbiz.com" className="mt-1" /></div>
                        <label className="flex items-center gap-2 text-sm"><Switch checked={form.show_logo} onCheckedChange={(v) => set("show_logo", v)} /> Show business name</label>
                        <div className="rounded-lg border border-brand-line p-3">
                            <Label>Visitor password {m.password_set && !clearPw && <span className="text-emerald-600 text-xs ml-1">● set</span>}</Label>
                            <Input type="text" value={form.password} onChange={(e) => { set("password", e.target.value); setClearPw(false); }} placeholder={m.password_set ? "Enter a new password to change" : "e.g. preview2026"} className="mt-1" data-testid="maintenance-password" />
                            <div className="flex items-center justify-between mt-2 text-xs text-zinc-500"><span>Visitors who know it can browse the private site for 24h.</span>{m.password_set && <button type="button" className="text-red-600" onClick={() => { setClearPw(true); set("password", ""); }}>Remove password</button>}</div>
                        </div>
                    </div>
                    <div>
                        <Label>Preview</Label>
                        <div className="mt-1 rounded-xl overflow-hidden border border-brand-line aspect-[4/5] flex flex-col items-center justify-center text-center p-6" style={{ background: `radial-gradient(circle at 30% 20%, ${form.accent}22, transparent 60%), #0B0A16` }}>
                            {form.show_logo && <div className="w-12 h-12 rounded-2xl grid place-items-center text-white text-xl font-semibold mb-4" style={{ background: form.accent }}>{(site.name || "S")[0]}</div>}
                            <div className="text-white text-xl font-semibold">{form.title}</div>
                            <p className="text-white/70 text-sm mt-2 max-w-xs">{form.message}</p>
                            {form.eta && <p className="text-white/50 text-xs mt-2">Back {form.eta}</p>}
                            {(form.password || m.password_set) && !clearPw && <div className="mt-5 w-full max-w-xs flex gap-2"><div className="flex-1 h-9 rounded-md bg-white/10 border border-white/20 text-left px-3 text-xs text-white/50 leading-9">Password</div><div className="h-9 px-3 rounded-md text-xs text-white leading-9" style={{ background: form.accent }}>Enter</div></div>}
                            {form.contact_email && <p className="text-white/50 text-xs mt-4">{form.contact_email}</p>}
                        </div>
                        <div className="flex justify-end gap-2 mt-4"><Button type="button" variant="outline" onClick={onClose}>Cancel</Button><Button type="submit" disabled={busy} data-testid="maintenance-save">{busy ? "Saving…" : "Save"}</Button></div>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}
