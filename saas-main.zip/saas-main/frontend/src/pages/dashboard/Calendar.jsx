import InsightsDashboard from "@/components/InsightsDashboard";
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calendar as CalIcon, Plus, Users, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";

function fmtDay(d) { return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }); }
function fmtTime(iso) { return new Date(iso).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" }); }
function isoDate(d) { return d.toISOString().slice(0, 10); }

const STATUS_TONES = {
    confirmed: "bg-brand-copper/12 text-brand-copper border-brand-copper/40",
    completed: "bg-emerald-100 text-emerald-800 border-emerald-200",
    cancelled: "bg-zinc-100 text-zinc-500 border-brand-line",
    no_show: "bg-amber-100 text-amber-800 border-amber-200",
};

function CalendarBase() {
    const [weekStart, setWeekStart] = useState(() => {
        const d = new Date(); d.setHours(0, 0, 0, 0);
        d.setDate(d.getDate() - d.getDay()); // Sunday-based week
        return d;
    });
    const [bookings, setBookings] = useState([]);
    const [staff, setStaff] = useState([]);
    const [services, setServices] = useState([]);
    const [filterStaff, setFilterStaff] = useState("all");
    const [loading, setLoading] = useState(true);
    const [openCreate, setOpenCreate] = useState(false);

    const days = useMemo(() => Array.from({ length: 7 }, (_, i) => {
        const d = new Date(weekStart); d.setDate(weekStart.getDate() + i); return d;
    }), [weekStart]);

    async function load() {
        setLoading(true);
        try {
            const df = isoDate(weekStart);
            const dtEnd = new Date(weekStart); dtEnd.setDate(dtEnd.getDate() + 7);
            const dt = isoDate(dtEnd);
            const [b, s, sv] = await Promise.all([
                api.get(`/booking/bookings?date_from=${df}&date_to=${dt}${filterStaff !== "all" ? `&staff_id=${filterStaff}` : ""}`),
                api.get("/booking/staff"),
                api.get("/booking/services"),
            ]);
            setBookings(b.data.bookings || []);
            setStaff(s.data.staff || []);
            setServices(sv.data.services || []);
        } finally { setLoading(false); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [weekStart, filterStaff]);

    const bookingsByDay = useMemo(() => {
        const map = {};
        for (const b of bookings) {
            const day = new Date(b.start_at); day.setHours(0, 0, 0, 0);
            const key = isoDate(day);
            (map[key] = map[key] || []).push(b);
        }
        for (const k of Object.keys(map)) map[k].sort((a, b) => a.start_at.localeCompare(b.start_at));
        return map;
    }, [bookings]);

    const staffMap = useMemo(() => Object.fromEntries(staff.map((s) => [s.id, s])), [staff]);
    const serviceMap = useMemo(() => Object.fromEntries(services.map((s) => [s.id, s])), [services]);

    function shift(days) {
        const d = new Date(weekStart); d.setDate(d.getDate() + days); setWeekStart(d);
    }

    return (
        <div className="p-6" data-testid="calendar-page">
            <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Calendar</div>
                    <h1 className="font-display text-3xl text-brand-ink font-medium">Bookings</h1>
                    <p className="text-sm text-zinc-500 mt-1">Every appointment on your team's calendar. Reschedules keep customers auto-notified.</p>
                </div>
                <div className="flex items-center gap-2">
                    <Select value={filterStaff} onValueChange={setFilterStaff}>
                        <SelectTrigger className="w-52" data-testid="calendar-staff-filter">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All staff</SelectItem>
                            {staff.map((s) => <SelectItem key={s.id} value={s.id}>{s.display_name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Button onClick={() => setOpenCreate(true)} className="bg-brand-copper hover:bg-brand-copperHover text-white" data-testid="calendar-new-booking-btn">
                        <Plus className="w-4 h-4 mr-1" /> New booking
                    </Button>
                </div>
            </div>

            {/* Week nav */}
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => shift(-7)} data-testid="calendar-prev-week"><ChevronLeft className="w-4 h-4" /></Button>
                    <div className="text-sm font-medium text-brand-ink" data-testid="calendar-week-label">
                        {fmtDay(days[0])} — {fmtDay(days[6])}
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => shift(7)} data-testid="calendar-next-week"><ChevronRight className="w-4 h-4" /></Button>
                    <Button variant="link" size="sm" onClick={() => {
                        const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - d.getDay()); setWeekStart(d);
                    }} data-testid="calendar-today-btn" className="text-brand-copper">Today</Button>
                </div>
                {loading && <span className="text-xs text-zinc-500 inline-flex items-center gap-1"><Loader2 className="w-3.5 h-3.5 animate-spin" /> loading</span>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-7 gap-2" data-testid="calendar-week-grid">
                {days.map((d, i) => {
                    const key = isoDate(d);
                    const today = key === isoDate(new Date());
                    const list = bookingsByDay[key] || [];
                    return (
                        <div key={key} className={`rounded-lg border ${today ? "border-brand-copper" : "border-brand-line"} bg-white overflow-hidden`} data-testid={`calendar-day-${key}`}>
                            <div className={`px-3 py-2 text-xs border-b ${today ? "bg-brand-cream/60 border-brand-copper/30 text-brand-ink font-medium" : "border-brand-line text-zinc-500"}`}>
                                <div>{fmtDay(d)}</div>
                            </div>
                            <div className="p-2 space-y-1.5 min-h-32">
                                {list.map((b) => {
                                    const svc = serviceMap[b.service_id];
                                    const st = staffMap[b.staff_id];
                                    return (
                                        <div key={b.id} data-testid={`calendar-booking-${b.id}`} className={`text-xs rounded-md border px-2 py-1.5 ${STATUS_TONES[b.status] || "border-brand-line"}`}>
                                            <div className="font-mono">{fmtTime(b.start_at)}</div>
                                            <div className="font-medium truncate text-brand-ink">{svc?.name || "Service"}</div>
                                            {st && <div className="text-zinc-500 truncate">{st.display_name}</div>}
                                        </div>
                                    );
                                })}
                                {!list.length && <div className="text-[10px] text-zinc-400 uppercase tracking-widest text-center py-3">no bookings</div>}
                            </div>
                        </div>
                    );
                })}
            </div>

            <NewBookingDialog
                open={openCreate}
                onOpenChange={setOpenCreate}
                services={services}
                staff={staff}
                onCreated={load}
            />
        </div>
    );
}

function NewBookingDialog({ open, onOpenChange, services, staff, onCreated }) {
    const [serviceId, setServiceId] = useState("");
    const [staffId, setStaffId] = useState("");
    const [dateFrom, setDateFrom] = useState(() => isoDate(new Date()));
    const [dateTo, setDateTo] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 7); return isoDate(d); });
    const [slots, setSlots] = useState([]);
    const [chosenSlot, setChosenSlot] = useState(null);
    const [customer, setCustomer] = useState({ name: "", email: "", phone: "", customer_notes: "" });
    const [busy, setBusy] = useState(false);
    const [err, setErr] = useState(null);

    useEffect(() => {
        if (!open) {
            setServiceId(""); setStaffId(""); setSlots([]); setChosenSlot(null);
            setCustomer({ name: "", email: "", phone: "", customer_notes: "" });
            setErr(null);
        }
    }, [open]);

    useEffect(() => {
        if (!serviceId) return;
        (async () => {
            try {
                const q = `/booking/availability?service_id=${serviceId}&date_from=${dateFrom}&date_to=${dateTo}${staffId ? `&staff_id=${staffId}` : ""}`;
                const { data } = await api.get(q);
                setSlots((data.slots || []).slice(0, 40));
            } catch (e) { setErr(e?.response?.data?.detail || e.message); }
        })();
    }, [serviceId, staffId, dateFrom, dateTo]);

    async function submit() {
        if (!chosenSlot || !customer.name || !customer.email) return;
        setBusy(true); setErr(null);
        try {
            await api.post("/booking/bookings", {
                service_id: serviceId,
                staff_id: chosenSlot.staff_id,
                start_at: chosenSlot.start_at,
                ...customer,
            });
            toast.success("Booking created — customer notified.");
            onOpenChange(false);
            onCreated?.();
        } catch (e) {
            const detail = e?.response?.data?.detail;
            setErr(typeof detail === "string" ? detail : detail?.detail || "Failed to book");
        } finally { setBusy(false); }
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl">
                <DialogHeader><DialogTitle>New booking</DialogTitle></DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label className="text-xs">Service</Label>
                        <Select value={serviceId} onValueChange={setServiceId}>
                            <SelectTrigger data-testid="new-booking-service-select"><SelectValue placeholder="Select service" /></SelectTrigger>
                            <SelectContent>
                                {services.map((s) => <SelectItem key={s.id} value={s.id}>{s.name} · {s.duration_minutes}m</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label className="text-xs">Assign staff (optional)</Label>
                        <Select value={staffId || "any"} onValueChange={(v) => setStaffId(v === "any" ? "" : v)}>
                            <SelectTrigger data-testid="new-booking-staff-select"><SelectValue placeholder="Any available" /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="any">Any available</SelectItem>
                                {staff.map((s) => <SelectItem key={s.id} value={s.id}>{s.display_name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label className="text-xs">From</Label>
                        <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
                    </div>
                    <div>
                        <Label className="text-xs">To</Label>
                        <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
                    </div>
                </div>

                {serviceId && (
                    <div>
                        <Label className="text-xs">Open slots</Label>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-52 overflow-y-auto mt-1" data-testid="new-booking-slots">
                            {slots.map((s) => (
                                <button key={`${s.start_at}-${s.staff_id}`} type="button"
                                    data-testid={`new-booking-slot-${s.start_at}`}
                                    onClick={() => setChosenSlot(s)}
                                    className={`rounded border px-2 py-1.5 text-xs text-left ${chosenSlot?.start_at === s.start_at && chosenSlot?.staff_id === s.staff_id ? "border-2 border-brand-copper bg-brand-cream/40" : "border-brand-line hover:border-brand-copper"}`}>
                                    <div className="font-mono">{new Date(s.start_at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</div>
                                    {s.staff_display_name && <div className="text-zinc-500">{s.staff_display_name}</div>}
                                </button>
                            ))}
                            {!slots.length && <div className="text-xs text-zinc-500 col-span-3">No slots — try another date range or staff.</div>}
                        </div>
                    </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <Label className="text-xs">Customer name</Label>
                        <Input value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} data-testid="new-booking-name" />
                    </div>
                    <div>
                        <Label className="text-xs">Email</Label>
                        <Input type="email" value={customer.email} onChange={(e) => setCustomer({ ...customer, email: e.target.value })} data-testid="new-booking-email" />
                    </div>
                    <div>
                        <Label className="text-xs">Phone</Label>
                        <Input value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} data-testid="new-booking-phone" />
                    </div>
                    <div>
                        <Label className="text-xs">Notes</Label>
                        <Input value={customer.customer_notes} onChange={(e) => setCustomer({ ...customer, customer_notes: e.target.value })} data-testid="new-booking-notes" />
                    </div>
                </div>

                {err && <div className="rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm" data-testid="new-booking-err">{err}</div>}

                <DialogFooter>
                    <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={submit} disabled={busy || !chosenSlot || !customer.name || !customer.email}
                        className="bg-brand-copper hover:bg-brand-copperHover text-white"
                        data-testid="new-booking-submit-btn">
                        {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CalIcon className="w-4 h-4 mr-2" />}
                        Create booking
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}


// Dashboard wrapper: real stat cards + trend chart on top of the feature page.
export default function Calendar() {
    return (
        <>
            <div className="px-4 md:px-8 pt-6">
                <InsightsDashboard area="bookings" title="Bookings" subtitle="Appointments, upcoming work and cancellation health." color="#F59E0B" seriesKey="bookings" seriesFormat="int" breakdownTitle="By service" breakdownFormat="int" />
            </div>
            <CalendarBase />
        </>
    );
}
