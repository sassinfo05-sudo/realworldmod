import { useEffect, useState } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { RefreshCw, CheckCircle2, FlaskConical, PlugZap, AlertTriangle } from "lucide-react";

const STYLE = {
    connected: { cls: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/20 dark:text-emerald-200", icon: CheckCircle2, label: "Connected" },
    sandbox: { cls: "bg-sky-100 text-sky-800 dark:bg-sky-500/20 dark:text-sky-200", icon: FlaskConical, label: "Sandbox" },
    not_connected: { cls: "bg-zinc-100 text-zinc-600 dark:bg-white/10 dark:text-white/60", icon: PlugZap, label: "Not connected" },
    error: { cls: "bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-200", icon: AlertTriangle, label: "Error" },
};

export default function ProviderStatusPanel() {
    const [data, setData] = useState(null);
    const [busy, setBusy] = useState(false);

    async function load(probe = false) {
        setBusy(true);
        try { const r = await api.get(`/staff/providers/status${probe ? "?probe=true" : ""}`); setData(r.data); if (probe) toast.success("Providers re-tested"); }
        catch (e) { toast.error(e?.response?.data?.detail || "Cannot load provider status"); }
        finally { setBusy(false); }
    }
    useEffect(() => { load(false); }, []);

    return (
        <div className="rounded-2xl border border-brand-line bg-white dark:bg-white/5 dark:border-white/10 p-5" data-testid="provider-status-panel">
            <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper">Setup Center</div>
                    <h3 className="font-display text-lg text-brand-ink dark:text-white">Provider connection status</h3>
                    <p className="text-xs text-zinc-500 mt-0.5">Truthful state per provider. Secrets are never displayed. {data?.checked_at ? `Last checked ${data.checked_at.slice(0, 19).replace("T", " ")} UTC` : ""}</p>
                </div>
                <button onClick={() => load(true)} disabled={busy} className="inline-flex items-center gap-1.5 text-sm rounded-md border border-brand-line dark:border-white/15 px-3 py-1.5" data-testid="provider-status-retest">
                    <RefreshCw className={`w-4 h-4 ${busy ? "animate-spin" : ""}`} /> Re-test (includes a 1-token AI ping)
                </button>
            </div>
            {data && (
                <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {data.cards.map((c) => {
                        const st = STYLE[c.status] || STYLE.not_connected; const Icon = st.icon;
                        return (
                            <div key={c.key} className="rounded-xl border border-brand-line dark:border-white/10 p-3 text-sm" data-testid={`provider-card-${c.key}`}>
                                <div className="flex items-center justify-between gap-2">
                                    <div className="font-medium text-brand-ink dark:text-white truncate">{c.label}</div>
                                    <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full whitespace-nowrap ${st.cls}`}><Icon className="w-3 h-3" />{st.label}</span>
                                </div>
                                {c.detail && <div className="text-xs text-zinc-500 mt-1">{c.detail}</div>}
                                {c.test?.ran && <div className="text-[11px] mt-1 text-zinc-500">Test: {c.test.ok ? "passed" : `failed${c.test.error ? ` (${c.test.error})` : ""}`}{c.test.latency_ms ? ` · ${c.test.latency_ms} ms` : ""}</div>}
                                {c.owner_action && <div className="text-[11px] mt-1.5 text-amber-700 dark:text-amber-300">Owner action: {c.owner_action}</div>}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
