"""Online-selling & shipping engine (native, better-than-Shopify).

Provides everything a business needs to sell + ship online:
  - Curated country directory (regionised) for building shipping zones + a
    "sell to these countries" allowlist.
  - A real-world carrier directory ("find shipping companies") filtered by the
    destination region, plus multi-carrier aggregators (Shippo/EasyPost/ShipStation)
    that connect once for live rates + labels across dozens of carriers.
  - A flexible rate engine: flat, weight-tiered, price-tiered and free-over-threshold
    rates grouped into zones (lists of country codes, with "*" = rest of world).
  - Printable invoice + packing-slip HTML renderers.

All persistence uses UUID string ids (JSON-safe, no ObjectId).
"""
from __future__ import annotations

import html
import uuid
from typing import Any, Dict, List, Optional

from ..db import get_db, utc_now_iso

# --------------------------------------------------------------------------- #
#  Country directory (regionised)                                             #
# --------------------------------------------------------------------------- #
COUNTRIES: List[Dict[str, str]] = [
    # North America
    {"code": "US", "name": "United States", "region": "North America"},
    {"code": "CA", "name": "Canada", "region": "North America"},
    {"code": "MX", "name": "Mexico", "region": "North America"},
    # Europe
    {"code": "GB", "name": "United Kingdom", "region": "Europe"},
    {"code": "IE", "name": "Ireland", "region": "Europe"},
    {"code": "FR", "name": "France", "region": "Europe"},
    {"code": "DE", "name": "Germany", "region": "Europe"},
    {"code": "ES", "name": "Spain", "region": "Europe"},
    {"code": "PT", "name": "Portugal", "region": "Europe"},
    {"code": "IT", "name": "Italy", "region": "Europe"},
    {"code": "NL", "name": "Netherlands", "region": "Europe"},
    {"code": "BE", "name": "Belgium", "region": "Europe"},
    {"code": "CH", "name": "Switzerland", "region": "Europe"},
    {"code": "AT", "name": "Austria", "region": "Europe"},
    {"code": "SE", "name": "Sweden", "region": "Europe"},
    {"code": "NO", "name": "Norway", "region": "Europe"},
    {"code": "DK", "name": "Denmark", "region": "Europe"},
    {"code": "FI", "name": "Finland", "region": "Europe"},
    {"code": "PL", "name": "Poland", "region": "Europe"},
    {"code": "CZ", "name": "Czechia", "region": "Europe"},
    {"code": "GR", "name": "Greece", "region": "Europe"},
    {"code": "RO", "name": "Romania", "region": "Europe"},
    # Middle East & Africa
    {"code": "AE", "name": "United Arab Emirates", "region": "Middle East"},
    {"code": "SA", "name": "Saudi Arabia", "region": "Middle East"},
    {"code": "IL", "name": "Israel", "region": "Middle East"},
    {"code": "TR", "name": "Turkey", "region": "Middle East"},
    {"code": "ZA", "name": "South Africa", "region": "Africa"},
    {"code": "NG", "name": "Nigeria", "region": "Africa"},
    {"code": "EG", "name": "Egypt", "region": "Africa"},
    {"code": "KE", "name": "Kenya", "region": "Africa"},
    # Asia
    {"code": "IN", "name": "India", "region": "Asia"},
    {"code": "CN", "name": "China", "region": "Asia"},
    {"code": "JP", "name": "Japan", "region": "Asia"},
    {"code": "KR", "name": "South Korea", "region": "Asia"},
    {"code": "SG", "name": "Singapore", "region": "Asia"},
    {"code": "HK", "name": "Hong Kong", "region": "Asia"},
    {"code": "MY", "name": "Malaysia", "region": "Asia"},
    {"code": "TH", "name": "Thailand", "region": "Asia"},
    {"code": "ID", "name": "Indonesia", "region": "Asia"},
    {"code": "PH", "name": "Philippines", "region": "Asia"},
    {"code": "VN", "name": "Vietnam", "region": "Asia"},
    # Oceania
    {"code": "AU", "name": "Australia", "region": "Oceania"},
    {"code": "NZ", "name": "New Zealand", "region": "Oceania"},
    # Latin America
    {"code": "BR", "name": "Brazil", "region": "Latin America"},
    {"code": "AR", "name": "Argentina", "region": "Latin America"},
    {"code": "CL", "name": "Chile", "region": "Latin America"},
    {"code": "CO", "name": "Colombia", "region": "Latin America"},
]

COUNTRY_NAME = {c["code"]: c["name"] for c in COUNTRIES}
COUNTRY_REGION = {c["code"]: c["region"] for c in COUNTRIES}


# --------------------------------------------------------------------------- #
#  Carrier directory (real companies)                                         #
# --------------------------------------------------------------------------- #
# region "GLOBAL" = ships (almost) everywhere. Otherwise the carrier appears when
# the destination country's region matches, or the destination code is listed.
CARRIERS: List[Dict[str, Any]] = [
    {"key": "dhl_express", "name": "DHL Express", "regions": ["GLOBAL"],
     "website": "https://www.dhl.com", "api": True,
     "services": ["Express Worldwide", "Economy Select"],
     "notes": "Fastest broad international coverage; great for parcels to 200+ countries."},
    {"key": "fedex", "name": "FedEx", "regions": ["GLOBAL"],
     "website": "https://www.fedex.com", "api": True,
     "services": ["International Priority", "International Economy", "Ground"],
     "notes": "Strong for US outbound + international express."},
    {"key": "ups", "name": "UPS", "regions": ["GLOBAL"],
     "website": "https://www.ups.com", "api": True,
     "services": ["Worldwide Expedited", "Worldwide Saver", "Ground"],
     "notes": "Reliable global network with good tracking."},
    {"key": "usps", "name": "USPS", "regions": ["North America"],
     "codes": ["US"], "website": "https://www.usps.com", "api": True,
     "services": ["Priority Mail", "Priority Express", "First-Class Package", "Ground Advantage"],
     "notes": "Best value for US domestic + lightweight international."},
    {"key": "canada_post", "name": "Canada Post", "regions": ["North America"],
     "codes": ["CA"], "website": "https://www.canadapost-postescanada.ca", "api": True,
     "services": ["Expedited Parcel", "Xpresspost", "Regular Parcel"],
     "notes": "Default choice for Canadian domestic shipping."},
    {"key": "royal_mail", "name": "Royal Mail", "regions": ["Europe"],
     "codes": ["GB"], "website": "https://www.royalmail.com", "api": True,
     "services": ["Tracked 24/48", "International Tracked"],
     "notes": "UK domestic + international; Click & Drop for labels."},
    {"key": "evri", "name": "Evri (Hermes)", "regions": ["Europe"], "codes": ["GB"],
     "website": "https://www.evri.com", "api": True,
     "services": ["Standard", "Next Day"],
     "notes": "Low-cost UK courier with pickup/drop-off points."},
    {"key": "dpd", "name": "DPD", "regions": ["Europe"],
     "website": "https://www.dpd.com", "api": True,
     "services": ["Classic", "Express"],
     "notes": "Excellent EU road network with 1-hour delivery windows."},
    {"key": "gls", "name": "GLS", "regions": ["Europe"],
     "website": "https://gls-group.com", "api": True,
     "services": ["Business Parcel", "EuroBusiness Parcel"],
     "notes": "Cost-effective EU parcel delivery."},
    {"key": "deutsche_post_dhl", "name": "Deutsche Post / DHL Paket", "regions": ["Europe"],
     "codes": ["DE"], "website": "https://www.dhl.de", "api": True,
     "services": ["DHL Paket", "Warenpost International"],
     "notes": "Germany domestic + EU."},
    {"key": "colissimo", "name": "La Poste / Colissimo", "regions": ["Europe"], "codes": ["FR"],
     "website": "https://www.laposte.fr", "api": True,
     "services": ["Colissimo Domicile", "Colissimo International"],
     "notes": "France domestic + international."},
    {"key": "postnl", "name": "PostNL", "regions": ["Europe"], "codes": ["NL"],
     "website": "https://www.postnl.nl", "api": True,
     "services": ["Standard", "Parcels EU"], "notes": "Netherlands domestic + EU."},
    {"key": "correos", "name": "Correos", "regions": ["Europe"], "codes": ["ES"],
     "website": "https://www.correos.es", "api": False,
     "services": ["Paq Estándar", "Paq Premium"], "notes": "Spain domestic + international."},
    {"key": "australia_post", "name": "Australia Post", "regions": ["Oceania"], "codes": ["AU"],
     "website": "https://auspost.com.au", "api": True,
     "services": ["Parcel Post", "Express Post", "International"],
     "notes": "Australia domestic + international."},
    {"key": "nz_post", "name": "NZ Post", "regions": ["Oceania"], "codes": ["NZ"],
     "website": "https://www.nzpost.co.nz", "api": True,
     "services": ["CourierPost", "International Economy"], "notes": "New Zealand domestic + intl."},
    {"key": "sendle", "name": "Sendle", "regions": ["Oceania", "North America"], "codes": ["AU", "US"],
     "website": "https://www.sendle.com", "api": True,
     "services": ["Standard", "Express"], "notes": "Carbon-neutral small-business courier."},
    {"key": "india_post", "name": "India Post", "regions": ["Asia"], "codes": ["IN"],
     "website": "https://www.indiapost.gov.in", "api": False,
     "services": ["Speed Post", "Registered Parcel"], "notes": "India domestic + international."},
    {"key": "delhivery", "name": "Delhivery", "regions": ["Asia"], "codes": ["IN"],
     "website": "https://www.delhivery.com", "api": True,
     "services": ["Surface", "Express"], "notes": "India's largest private logistics network."},
    {"key": "japan_post", "name": "Japan Post", "regions": ["Asia"], "codes": ["JP"],
     "website": "https://www.post.japanpost.jp", "api": False,
     "services": ["Yu-Pack", "EMS"], "notes": "Japan domestic + EMS international."},
    {"key": "sf_express", "name": "SF Express", "regions": ["Asia"], "codes": ["CN", "HK"],
     "website": "https://www.sf-express.com", "api": True,
     "services": ["Standard Express", "International"], "notes": "Leading China/HK courier."},
    {"key": "aramex", "name": "Aramex", "regions": ["Middle East", "Asia"],
     "website": "https://www.aramex.com", "api": True,
     "services": ["Domestic", "Express International"],
     "notes": "Strong across MENA + South Asia."},
]

# Multi-carrier aggregators — connect ONE key, get live rates + printable labels
# across dozens of carriers. This is the fastest way to "find shipping companies".
AGGREGATORS: List[Dict[str, Any]] = [
    {"key": "shippo", "name": "Shippo", "website": "https://goshippo.com",
     "regions": ["GLOBAL"], "api": True,
     "notes": "Connect one Shippo key for discounted live rates + labels from USPS, UPS, "
              "FedEx, DHL, Canada Post and 85+ carriers. Best all-round pick."},
    {"key": "easypost", "name": "EasyPost", "website": "https://www.easypost.com",
     "regions": ["GLOBAL"], "api": True,
     "notes": "Developer-friendly multi-carrier API — 100+ carriers, live rates, labels, tracking."},
    {"key": "shipstation", "name": "ShipStation", "website": "https://www.shipstation.com",
     "regions": ["GLOBAL"], "api": True,
     "notes": "Order + label management dashboard with negotiated carrier rates."},
]


def list_countries() -> List[Dict[str, str]]:
    return COUNTRIES


def carriers_for_country(country_code: Optional[str]) -> Dict[str, Any]:
    cc = (country_code or "").upper()
    region = COUNTRY_REGION.get(cc)
    out: List[Dict[str, Any]] = []
    for c in CARRIERS:
        regions = c.get("regions", [])
        codes = c.get("codes")
        if not cc:
            out.append(c)
            continue
        if "GLOBAL" in regions:
            out.append(c)
        elif codes and cc in codes:
            out.append(c)
        elif region and region in regions and not codes:
            out.append(c)
    return {"country": cc or None, "region": region,
            "carriers": out, "aggregators": AGGREGATORS}


# --------------------------------------------------------------------------- #
#  Settings                                                                    #
# --------------------------------------------------------------------------- #
DEFAULT_SETTINGS: Dict[str, Any] = {
    "origin": {"name": "", "address": "", "city": "", "region": "",
               "postal_code": "", "country": "US"},
    "weight_unit": "g",           # g | oz
    "default_weight_grams": 500,
    "handling_fee_cents": 0,
    "countries_served": ["*"],    # "*" = ship worldwide
    "currency": "USD",
}


async def get_settings(org_id: str) -> Dict[str, Any]:
    db = get_db()
    doc = await db.store_shipping_settings.find_one({"org_id": org_id})
    if not doc:
        return dict(DEFAULT_SETTINGS)
    merged = dict(DEFAULT_SETTINGS)
    for k in DEFAULT_SETTINGS:
        if k in doc and doc[k] is not None:
            merged[k] = doc[k]
    return merged


async def save_settings(org_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    db = get_db()
    cur = await get_settings(org_id)
    for k, v in patch.items():
        if k in DEFAULT_SETTINGS and v is not None:
            cur[k] = v
    cur["org_id"] = org_id
    cur["updated_at"] = utc_now_iso()
    await db.store_shipping_settings.update_one(
        {"org_id": org_id}, {"$set": cur}, upsert=True)
    cur.pop("_id", None)
    return cur


# --------------------------------------------------------------------------- #
#  Zones + rate engine                                                         #
# --------------------------------------------------------------------------- #
def _rate_out(r: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": r.get("id") or uuid.uuid4().hex,
        "name": r.get("name", "Shipping"),
        "type": r.get("type", "flat"),
        "amount_cents": int(r.get("amount_cents", 0) or 0),
        "free_over_cents": int(r.get("free_over_cents", 0) or 0),
        "tiers": r.get("tiers", []),
    }


def zone_out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": d["_id"],
        "name": d.get("name", "Zone"),
        "country_codes": d.get("country_codes", []),
        "rates": [_rate_out(r) for r in d.get("rates", [])],
        "created_at": d.get("created_at"),
        "updated_at": d.get("updated_at"),
    }


def compute_rate(rate: Dict[str, Any], subtotal_cents: int, weight_grams: int) -> Optional[int]:
    """Return the shipping cost in cents for a single rate, or None if not applicable."""
    rtype = rate.get("type", "flat")
    base = int(rate.get("amount_cents", 0) or 0)
    if rtype == "flat":
        return base
    if rtype == "free_over":
        threshold = int(rate.get("free_over_cents", 0) or 0)
        return 0 if subtotal_cents >= threshold else base
    if rtype in ("weight", "price"):
        metric = weight_grams if rtype == "weight" else subtotal_cents
        tiers = rate.get("tiers", []) or []
        # tiers evaluated in order; up_to null/empty = catch-all (infinity)
        for t in tiers:
            up = t.get("up_to")
            if up in (None, ""):
                return int(t.get("amount_cents", base) or base)
            if metric <= int(up):
                return int(t.get("amount_cents", base) or base)
        return base  # over all tiers -> fall back to base
    return base


async def quote(org_id: str, country_code: str, subtotal_cents: int,
                weight_grams: int) -> Dict[str, Any]:
    """Compute available shipping options for a destination. Applies the org's
    handling fee to every option. Honours the countries_served allowlist."""
    db = get_db()
    settings = await get_settings(org_id)
    cc = (country_code or "").upper()
    served = settings.get("countries_served", ["*"])
    if "*" not in served and cc not in served:
        return {"served": False, "options": [],
                "message": "This store does not ship to your country yet."}
    handling = int(settings.get("handling_fee_cents", 0) or 0)
    options: List[Dict[str, Any]] = []
    async for z in db.store_shipping_zones.find({"org_id": org_id}).sort("created_at", 1):
        codes = z.get("country_codes", [])
        covers = cc in codes or "*" in codes
        if not covers:
            continue
        for r in z.get("rates", []):
            cost = compute_rate(r, subtotal_cents, weight_grams)
            if cost is None:
                continue
            options.append({
                "id": f"{z['_id']}:{r.get('id')}",
                "zone": z.get("name", "Zone"),
                "name": r.get("name", "Shipping"),
                "amount_cents": max(0, int(cost) + handling),
            })
    options.sort(key=lambda o: o["amount_cents"])
    return {"served": True, "options": options,
            "message": "" if options else "No shipping rates configured for this destination."}


# --------------------------------------------------------------------------- #
#  Printable invoice + packing slip                                            #
# --------------------------------------------------------------------------- #
def _money(cents: int, currency: str = "USD") -> str:
    return f"{currency} {int(cents) / 100:,.2f}"


def render_document(order: Dict[str, Any], org: Dict[str, Any],
                    settings: Dict[str, Any], doc: str = "invoice") -> str:
    """Render a clean, printable invoice or packing slip as standalone HTML."""
    currency = order.get("currency", "USD")
    store_name = html.escape((org or {}).get("name", "Store"))
    buyer = order.get("buyer", {}) or {}
    origin = settings.get("origin", {}) or {}
    is_packing = doc == "packing"
    title = "Packing Slip" if is_packing else "Invoice"

    rows = ""
    for it in order.get("items", []):
        name = html.escape(str(it.get("name", "")))
        qty = int(it.get("qty", 1))
        price = int(it.get("price_cents", 0))
        line = price * qty
        if is_packing:
            rows += f"<tr><td>{name}</td><td class='r'>{qty}</td></tr>"
        else:
            rows += (f"<tr><td>{name}</td><td class='r'>{qty}</td>"
                     f"<td class='r'>{_money(price, currency)}</td>"
                     f"<td class='r'>{_money(line, currency)}</td></tr>")

    subtotal = int(order.get("subtotal_cents", 0))
    shipping = int(order.get("shipping_cents", 0) or 0)
    total = int(order.get("total_cents", subtotal + shipping))

    totals = ""
    if not is_packing:
        totals = f"""
        <table class="totals">
          <tr><td>Subtotal</td><td class="r">{_money(subtotal, currency)}</td></tr>
          <tr><td>Shipping</td><td class="r">{_money(shipping, currency)}</td></tr>
          <tr class="grand"><td>Total</td><td class="r">{_money(total, currency)}</td></tr>
        </table>"""

    header_cols = ("<th>Item</th><th class='r'>Qty</th>" if is_packing
                   else "<th>Item</th><th class='r'>Qty</th><th class='r'>Price</th><th class='r'>Amount</th>")

    ship_to = "<br>".join(html.escape(x) for x in [
        buyer.get("name", ""), buyer.get("address", ""),
        order.get("shipping_country", "") or buyer.get("country", ""),
        buyer.get("email", ""), buyer.get("phone", "")] if x)

    from_block = "<br>".join(html.escape(x) for x in [
        origin.get("name") or store_name, origin.get("address", ""),
        f"{origin.get('city','')} {origin.get('region','')} {origin.get('postal_code','')}".strip(),
        origin.get("country", "")] if x)

    fulfillment = order.get("fulfillment", {}) or {}
    tracking = ""
    if fulfillment.get("tracking_number"):
        tracking = (f"<p class='muted'>Carrier: {html.escape(str(fulfillment.get('carrier','')))} · "
                    f"Tracking: {html.escape(str(fulfillment.get('tracking_number','')))}</p>")

    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>{title} #{order.get('_id','')[:8]} — {store_name}</title>
<style>
  * {{ box-sizing:border-box; }}
  body {{ font-family: -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
          color:#1a1a1a; margin:0; padding:40px; background:#fff; }}
  .wrap {{ max-width:720px; margin:0 auto; }}
  .top {{ display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:28px; }}
  h1 {{ font-size:26px; margin:0 0 4px; letter-spacing:-0.5px; }}
  .muted {{ color:#666; font-size:13px; margin:2px 0; }}
  .cols {{ display:flex; gap:40px; margin:24px 0; }}
  .cols h3 {{ font-size:11px; text-transform:uppercase; letter-spacing:1px; color:#888; margin:0 0 6px; }}
  .cols div {{ font-size:14px; line-height:1.5; }}
  table.items {{ width:100%; border-collapse:collapse; margin-top:12px; font-size:14px; }}
  table.items th {{ text-align:left; border-bottom:2px solid #111; padding:8px 6px; font-size:12px;
                    text-transform:uppercase; letter-spacing:.5px; }}
  table.items td {{ padding:10px 6px; border-bottom:1px solid #eee; }}
  .r {{ text-align:right; }}
  table.totals {{ width:260px; margin-left:auto; margin-top:16px; font-size:14px; border-collapse:collapse; }}
  table.totals td {{ padding:6px 6px; }}
  table.totals tr.grand td {{ border-top:2px solid #111; font-weight:700; font-size:16px; padding-top:10px; }}
  .badge {{ display:inline-block; background:#111; color:#fff; padding:4px 10px; border-radius:6px;
            font-size:12px; letter-spacing:.5px; }}
  .foot {{ margin-top:40px; color:#999; font-size:12px; text-align:center; }}
  @media print {{ body {{ padding:0; }} .noprint {{ display:none; }} }}
</style></head>
<body><div class="wrap">
  <div class="top">
    <div><h1>{store_name}</h1><p class="muted">{title}</p></div>
    <div style="text-align:right">
      <span class="badge">{title.upper()}</span>
      <p class="muted">#{order.get('_id','')[:8]}</p>
      <p class="muted">{html.escape(str(order.get('created_at','') or '')[:10])}</p>
      <p class="muted">Status: {html.escape(str(order.get('status','')))}</p>
    </div>
  </div>
  <div class="cols">
    <div><h3>From</h3><div>{from_block or store_name}</div></div>
    <div><h3>Ship to</h3><div>{ship_to or '—'}</div></div>
  </div>
  {tracking}
  <table class="items"><thead><tr>{header_cols}</tr></thead><tbody>{rows}</tbody></table>
  {totals}
  <button class="noprint" onclick="window.print()"
    style="margin-top:24px;padding:10px 18px;border:0;border-radius:8px;background:#111;color:#fff;cursor:pointer;font-size:14px">
    Print / Save as PDF</button>
  <div class="foot">Thank you for your business.</div>
</div></body></html>"""
