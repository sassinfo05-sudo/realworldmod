"""Deterministic availability engine.

Given a Staff schedule, existing Bookings, buffers, and a target date range, returns
open slots for a given ServiceOffering. All calculations timezone-aware, DST-safe.
"""
from __future__ import annotations

from datetime import datetime, timedelta, time as dtime, date as ddate
from typing import Any, Dict, List, Optional, Tuple

try:
    from zoneinfo import ZoneInfo
except ImportError:
    from backports.zoneinfo import ZoneInfo  # type: ignore


def _parse_hhmm(s: str) -> dtime:
    hh, mm = s.split(":")
    return dtime(int(hh), int(mm))


def _iso_to_utc(iso: str) -> datetime:
    """Parse an ISO string to a UTC-aware datetime."""
    if iso.endswith("Z"):
        iso = iso[:-1] + "+00:00"
    dt = datetime.fromisoformat(iso)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=ZoneInfo("UTC"))
    return dt.astimezone(ZoneInfo("UTC"))


def compute_open_slots(
    *,
    staff: Dict[str, Any],
    existing_bookings: List[Dict[str, Any]],
    service_duration_minutes: int,
    service_buffer_before: int,
    service_buffer_after: int,
    date_from: ddate,
    date_to: ddate,
    slot_step_minutes: int = 30,
) -> List[Dict[str, Any]]:
    """Return ordered slot dicts [{start_at: ISO UTC, end_at: ISO UTC, staff_id: id}].

    Logic:
    1. For each date in [date_from, date_to], take staff.working_hours for that weekday
       and produce candidate windows in the staff's tz.
    2. Subtract breaks (weekly) and time_off (fixed ranges).
    3. Convert each window to UTC. Walk it at slot_step_minutes granularity.
    4. For each candidate slot [start, start + duration], reject if:
        - It overlaps ANY existing booking (accounting for buffers on BOTH sides).
        - It falls outside working hours (partial slot at end of shift).
    5. Cap `capacity` — if staff.capacity > 1, allow up to that many concurrent slots.
    """
    tz = ZoneInfo(staff.get("timezone") or "America/Los_Angeles")
    duration = timedelta(minutes=service_duration_minutes)
    step = timedelta(minutes=slot_step_minutes)
    buf_before_svc = timedelta(minutes=service_buffer_before)
    buf_after_svc = timedelta(minutes=service_buffer_after)

    # Pre-compute booking intervals with THEIR buffers, in UTC.
    booking_intervals: List[Tuple[datetime, datetime]] = []
    for b in existing_bookings:
        if b.get("status") in ("cancelled", "no_show"):
            continue
        try:
            s = _iso_to_utc(b["start_at"])
            e = _iso_to_utc(b["end_at"])
        except (KeyError, ValueError):
            continue
        # padding: max(service buffer, booking's own buffer)
        buf_b = timedelta(minutes=max(int(b.get("buffer_before_minutes") or 0), service_buffer_before))
        buf_a = timedelta(minutes=max(int(b.get("buffer_after_minutes") or 0), service_buffer_after))
        booking_intervals.append((s - buf_b, e + buf_a))

    hours_by_weekday: Dict[int, List[Tuple[dtime, dtime]]] = {}
    for wh in (staff.get("working_hours") or []):
        d = int(wh["day"])
        hours_by_weekday.setdefault(d, []).append((_parse_hhmm(wh["start"]), _parse_hhmm(wh["end"])))

    breaks_by_weekday: Dict[int, List[Tuple[dtime, dtime]]] = {}
    for br in (staff.get("breaks") or []):
        d = int(br["day"])
        breaks_by_weekday.setdefault(d, []).append((_parse_hhmm(br["start"]), _parse_hhmm(br["end"])))

    time_off_intervals: List[Tuple[datetime, datetime]] = []
    for to in (staff.get("time_off") or []):
        try:
            time_off_intervals.append((_iso_to_utc(to["start"]), _iso_to_utc(to["end"])))
        except (KeyError, ValueError):
            continue

    capacity = int(staff.get("capacity") or 1)

    def slot_blocked(slot_start_utc: datetime, slot_end_utc: datetime) -> bool:
        """Return True if the slot cannot be booked (respecting capacity)."""
        # Time off wins
        for os_s, os_e in time_off_intervals:
            if slot_start_utc < os_e and slot_end_utc > os_s:
                return True
        # Overlapping bookings — count them; if fewer than capacity, allowed.
        overlaps = 0
        for s, e in booking_intervals:
            if slot_start_utc - buf_after_svc < e and slot_end_utc + buf_before_svc > s:
                overlaps += 1
                if overlaps >= capacity:
                    return True
        return False

    open_slots: List[Dict[str, Any]] = []
    cur = date_from
    while cur <= date_to:
        weekday = cur.weekday()  # 0=Mon
        for shift_start, shift_end in hours_by_weekday.get(weekday, []):
            # Localized to staff tz then converted to UTC per-date to handle DST.
            local_start = datetime.combine(cur, shift_start, tzinfo=tz)
            local_end = datetime.combine(cur, shift_end, tzinfo=tz)
            # Break windows for this weekday
            weekday_breaks: List[Tuple[datetime, datetime]] = []
            for br_s, br_e in breaks_by_weekday.get(weekday, []):
                weekday_breaks.append((datetime.combine(cur, br_s, tzinfo=tz),
                                        datetime.combine(cur, br_e, tzinfo=tz)))

            slot_start_local = local_start
            while slot_start_local + duration <= local_end:
                slot_end_local = slot_start_local + duration
                # skip if inside a break window
                in_break = any(brs < slot_end_local and bre > slot_start_local
                                for brs, bre in weekday_breaks)
                if in_break:
                    slot_start_local += step
                    continue
                slot_start_utc = slot_start_local.astimezone(ZoneInfo("UTC"))
                slot_end_utc = slot_end_local.astimezone(ZoneInfo("UTC"))
                if not slot_blocked(slot_start_utc, slot_end_utc):
                    open_slots.append({
                        "start_at": slot_start_utc.isoformat().replace("+00:00", "Z"),
                        "end_at": slot_end_utc.isoformat().replace("+00:00", "Z"),
                        "staff_id": str(staff.get("_id") or staff.get("id") or ""),
                    })
                slot_start_local += step
        cur += timedelta(days=1)
    return open_slots


def check_conflict(*,
                    staff: Dict[str, Any],
                    existing_bookings: List[Dict[str, Any]],
                    start_at: str, end_at: str,
                    buffer_before: int, buffer_after: int) -> Optional[str]:
    """Return a short reason string if the requested [start_at, end_at] conflicts, else None.
    Called on every booking create/reschedule as the last-line defence.
    """
    s = _iso_to_utc(start_at)
    e = _iso_to_utc(end_at)
    buf_b = timedelta(minutes=buffer_before)
    buf_a = timedelta(minutes=buffer_after)
    capacity = int(staff.get("capacity") or 1)

    # time off
    for to in (staff.get("time_off") or []):
        try:
            to_s = _iso_to_utc(to["start"]); to_e = _iso_to_utc(to["end"])
        except Exception:  # noqa: BLE001
            continue
        if s < to_e and e > to_s:
            return "Staff is on time off during this slot."

    overlaps = 0
    for b in existing_bookings:
        if b.get("status") in ("cancelled", "no_show"):
            continue
        try:
            bs = _iso_to_utc(b["start_at"]) - timedelta(minutes=max(int(b.get("buffer_before_minutes") or 0), buffer_before))
            be = _iso_to_utc(b["end_at"]) + timedelta(minutes=max(int(b.get("buffer_after_minutes") or 0), buffer_after))
        except Exception:  # noqa: BLE001
            continue
        if s - buf_a < be and e + buf_b > bs:
            overlaps += 1
            if overlaps >= capacity:
                return "Slot conflicts with an existing booking."
    return None
