import { useState } from "react";
import { authHeaders } from "@/lib/api";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Download, AlertTriangle } from "lucide-react";

export default function DataTools() {
    const [busy, setBusy] = useState(false);
    const [confirmText, setConfirmText] = useState("");
    const [reason, setReason] = useState("");

    async function exportZip() {
        setBusy(true);
        try {
            const BASE = process.env.REACT_APP_BACKEND_URL;
            const r = await fetch(`${BASE}/api/setup/data-export`, {
                method: "POST",
                headers: authHeaders(), credentials: "include",
            });
            if (!r.ok) throw new Error("export failed");
            const blob = await r.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url; a.download = "zanelvo-export.zip";
            document.body.appendChild(a); a.click();
            document.body.removeChild(a); URL.revokeObjectURL(url);
            toast.success("Export downloaded");
        } catch (e) { toast.error("Export failed"); }
        finally { setBusy(false); }
    }
    async function deleteOrg() {
        if (confirmText !== "DELETE") {
            toast.error('Type "DELETE" to confirm');
            return;
        }
        setBusy(true);
        try {
            const { data } = await api.post("/setup/delete-org", { confirm: confirmText, reason });
            toast.success(`Scheduled for purge on ${data.purge_at?.slice(0, 10)} (30-day grace)`);
            setConfirmText(""); setReason("");
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed"); }
        finally { setBusy(false); }
    }
    async function cancelDelete() {
        setBusy(true);
        try {
            await api.post("/setup/delete-org/cancel");
            toast.success("Deletion canceled");
        } catch (e) { toast.error("Failed"); }
        finally { setBusy(false); }
    }

    return (
        <div className="p-6 max-w-2xl space-y-6" data-testid="data-tools-page">
            <div className="rounded-lg border border-brand-line bg-white p-5">
                <h2 className="text-lg font-medium text-brand-ink mb-1">Export your data</h2>
                <p className="text-sm text-zinc-500 mb-4">Downloads a ZIP with every org-owned collection as JSON. Nothing shared — for portability + audit.</p>
                <Button onClick={exportZip} disabled={busy} className="bg-brand-copper text-white hover:bg-brand-copperHover" data-testid="data-export-btn">
                    <Download className="w-4 h-4 mr-1" /> Download export
                </Button>
            </div>

            <div className="rounded-lg border border-red-200 bg-red-50 p-5">
                <div className="flex items-center gap-2 mb-2 text-red-900"><AlertTriangle className="w-5 h-5" /><span className="font-medium">Delete organization</span></div>
                <p className="text-sm text-red-800 mb-4">Soft-deletes your org with a 30-day grace window. Public site shows a maintenance page immediately. You can cancel within 30 days.</p>
                <div className="space-y-2">
                    <div>
                        <Label className="text-xs">Reason (optional)</Label>
                        <Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={2} />
                    </div>
                    <div>
                        <Label className="text-xs">Type <span className="font-mono">DELETE</span> to confirm</Label>
                        <Input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} data-testid="data-delete-confirm-input" />
                    </div>
                </div>
                <div className="mt-3 flex gap-2">
                    <Button onClick={deleteOrg} disabled={busy || confirmText !== "DELETE"} className="bg-red-600 text-white hover:bg-red-700" data-testid="data-delete-btn">Delete org</Button>
                    <Button variant="ghost" onClick={cancelDelete} data-testid="data-cancel-btn">Cancel a scheduled deletion</Button>
                </div>
            </div>
        </div>
    );
}
