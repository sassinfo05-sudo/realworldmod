import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import BlockRenderer from "@/components/BlockRenderer";
import NeedsAttention from "@/pages/dashboard/NeedsAttention";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Monitor, Smartphone, ArrowRight, ExternalLink } from "lucide-react";

const PAGE_ORDER = ["home", "services", "about", "contact"];

export default function Website() {
    const [website, setWebsite] = useState(null);
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(true);
    const [device, setDevice] = useState("desktop");
    const [pageSlug, setPageSlug] = useState("home");
    const [status, setStatus] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                const [w, p, s] = await Promise.allSettled([
                    api.get("/website"),
                    api.get("/business-profile"),
                    api.get("/onboarding/session/status").catch(() => ({ data: null })),
                ]);
                if (w.status === "fulfilled") setWebsite(w.value.data);
                if (p.status === "fulfilled") setProfile(p.value.data);
                if (s.status === "fulfilled" && s.value.data) setStatus(s.value.data.status);
            } finally {
                setLoading(false);
            }
        })();
    }, []);

    if (loading) {
        return <div className="p-10 text-zinc-500">Loading your workspace…</div>;
    }

    if (!website) {
        return (
            <div className="p-10 max-w-2xl" data-testid="website-empty">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-3">Website</div>
                <h1 className="font-display text-3xl text-brand-ink font-medium">Your site hasn't been generated yet.</h1>
                <p className="mt-3 text-zinc-600">
                    Answer a few questions and we'll write a tailored, multi-page site — grounded in your services, prices, and hours.
                </p>
                <div className="mt-6 flex gap-3">
                    <Button
                        onClick={() => navigate(status === "generating" ? "/generating" : "/onboarding")}
                        className="bg-brand-copper hover:bg-brand-copperHover text-white"
                        data-testid="website-start-btn"
                    >
                        {status === "generating" ? "See generation status" : "Start the interview"}
                        <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                    <Link to="/app/website/new" data-testid="website-templates-link-empty">
                        <Button variant="outline">Start from a template or blank</Button>
                    </Link>
                    <Link to="/research" data-testid="website-research-link-empty">
                        <Button variant="outline" data-testid="website-research-btn-empty">Research my business with AI</Button>
                    </Link>
                </div>
            </div>
        );
    }

    const page = website.pages.find((p) => p.slug === pageSlug) || website.pages[0];

    return (
        <div className="p-6 md:p-8" data-testid="website-page">
            <NeedsAttention />
            <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-1">Website</div>
                    <h1 className="font-display text-2xl md:text-3xl text-brand-ink font-medium">
                        {profile?.business_name || "Your site"}
                    </h1>
                    {profile?.tagline && <p className="mt-1 text-zinc-500 text-sm">{profile.tagline}</p>}
                    {website.slug ? (
                        <a
                            href={`/site/${website.slug}`}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-2 inline-flex items-center gap-1 text-sm text-brand-copper hover:underline"
                            data-testid="website-live-url"
                        >
                            <ExternalLink className="w-3.5 h-3.5" /> Live at /site/{website.slug}
                        </a>
                    ) : (
                        <div className="mt-2 text-sm text-zinc-500">Not published yet — open the editor and hit Publish.</div>
                    )}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                    <Link to="/app/editor" data-testid="website-open-editor">
                        <Button className="bg-brand-copper hover:bg-brand-copperHover text-white grain">
                            Open visual editor <ArrowRight className="w-4 h-4 ml-1" />
                        </Button>
                    </Link>
                    <Link to="/app/website/new" data-testid="website-new-design">
                        <Button variant="outline" size="sm">New design / templates</Button>
                    </Link>
                    <Link to="/app/seo" data-testid="website-seo-link">
                        <Button variant="outline" size="sm">SEO &amp; Analytics</Button>
                    </Link>
                    <Link to="/app/integrations" data-testid="website-integrations-link">
                        <Button variant="outline" size="sm">Integrations</Button>
                    </Link>
                    <Link to="/review" data-testid="website-review-link">
                        <Button variant="outline" size="sm">Review facts</Button>
                    </Link>
                </div>
            </div>

            {/* Page tabs + device toggle */}
            <div className="mt-6 flex items-center justify-between flex-wrap gap-3 border-b border-brand-line pb-3">
                <div className="flex items-center gap-1" data-testid="website-page-tabs">
                    {PAGE_ORDER.filter((s) => website.pages.some((p) => p.slug === s)).map((slug) => (
                        <button
                            key={slug}
                            onClick={() => setPageSlug(slug)}
                            data-testid={`website-tab-${slug}`}
                            className={`text-sm px-3 py-1.5 rounded-md capitalize transition-colors ${
                                pageSlug === slug
                                    ? "bg-brand-ink text-white"
                                    : "text-zinc-600 hover:bg-zinc-100"
                            }`}
                        >
                            {slug}
                        </button>
                    ))}
                </div>
                <Tabs value={device} onValueChange={setDevice}>
                    <TabsList data-testid="website-device-toggle">
                        <TabsTrigger value="desktop" data-testid="device-desktop">
                            <Monitor className="w-4 h-4 mr-1" /> Desktop
                        </TabsTrigger>
                        <TabsTrigger value="mobile" data-testid="device-mobile">
                            <Smartphone className="w-4 h-4 mr-1" /> Mobile
                        </TabsTrigger>
                    </TabsList>
                </Tabs>
            </div>

            {/* Preview frame */}
            <div className="mt-6" data-testid="website-preview">
                {device === "mobile" ? (
                    <div className="mx-auto rounded-[40px] border-[10px] border-brand-ink overflow-hidden bg-black shadow-xl"
                         style={{ width: 390, height: 780 }}>
                        <div className="relative bg-white h-full overflow-y-auto"
                             data-testid="website-preview-scroll">
                            {/* notch */}
                            <div className="sticky top-0 h-6 bg-black z-10 flex justify-center items-center">
                                <div className="w-24 h-4 bg-black rounded-b-2xl" />
                            </div>
                            {/* Render at a fixed "phone viewport" width and scale down to fit
                                the 390px frame. This gives Tailwind's md/lg breakpoints
                                predictable behavior (they DON'T fire on a 700px content width). */}
                            <div style={{
                                width: 700,
                                transform: "scale(0.557)",
                                transformOrigin: "top left",
                            }}>
                                <BlockRenderer page={page} theme={website.theme} />
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="w-full rounded-2xl border border-brand-line overflow-hidden bg-white shadow-sm">
                        <div className="flex items-center gap-2 px-4 py-2 border-b border-brand-line bg-zinc-50">
                            <span className="w-2.5 h-2.5 rounded-full bg-red-300" />
                            <span className="w-2.5 h-2.5 rounded-full bg-amber-300" />
                            <span className="w-2.5 h-2.5 rounded-full bg-emerald-300" />
                            <div className="ml-3 text-xs font-mono text-zinc-500 flex items-center gap-1">
                                <ExternalLink className="w-3 h-3" /> zanelvo.com/site/{website?.slug || (profile?.business_name || "your-site").toLowerCase().replace(/[^a-z]/g,'').slice(0,12)}{pageSlug === "home" ? "" : `/${pageSlug}`}
                            </div>
                        </div>
                        <div style={{ maxHeight: "72vh", overflowY: "auto" }} data-testid="website-preview-scroll">
                            <BlockRenderer page={page} theme={website.theme} />
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
