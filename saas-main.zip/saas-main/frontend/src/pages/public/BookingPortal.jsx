import { useEffect, useMemo, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Loader2, Calendar as CalIcon, Clock } from "lucide-react";

const API = process.env.REACT_APP_BACKEND_URL;

function fmtDate(iso) {
    return new Date(iso).toLocaleString(undefined, {
        weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit"
    });
}

export default function BookingPortal() {
    const { bid } = useParams();
    const [params] = useSearchParams();
    const tk = params.get("tk");
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [busy, setBusy] = useState(false);
    const [mode, setMode] = useState("idle"); // idle | rescheduling | cancelling | done
    const [slots, setSlots] = useState([]);
    const [chosen, setChosen] = useState(null);
    const [feeWarn, setFeeWarn] = useState(false);

    const dateFrom = useMemo(() => new Date().toISOString().slice(0, 10), []);
    const dateTo = useMemo(() => {
        const d = new Date(); d.setDate(d.getDate() + 21);
        return d.toISOString().slice(0, 10);
    }, []);

    async function load() {
        try {
            const r = await fetch(`${API}/api/public/portal/booking/${bid}?tk=${encodeURIComponent(tk)}`);
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            setData(await r.json());
        } catch (e) { setError(e.message); }
    }
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [bid, tk]);

    async function startReschedule() {
        setMode("rescheduling"); setError(null); setChosen(null);
        try {
            const r = await fetch(`${API}/api/public/portal/booking/${bid}/availability?tk=${encodeURIComponent(tk)}&date_from=${dateFrom}&date_to=${dateTo}`);
            if (!r.ok) throw new Error((await r.json()).detail || `HTTP ${r.status}`);
            const d = await r.json();
            setSlots((d.slots || []).slice(0, 30));
        } catch (e) { setError(e.message); }
    }

    async function confirmReschedule() {
        if (!chosen) return;
        setBusy(true);
        try {
            const r = await fetch(`${API}/api/public/portal/booking/${bid}/reschedule?tk=${encodeURIComponent(tk)}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ start_at: chosen.start_at }),
            });
            if (!r.ok) throw new Error((await r.json()).detail?.detail || (await r.json()).detail || `HTTP ${r.status}`);
            setMode("done");
            await load();
        } catch (e) { setError(String(e.message).replace(/^Error: /, "")); } finally { setBusy(false); }
    }

    async function cancel() {
        setBusy(true);
        try {
            const r = await fetch(`${API}/api/public/portal/booking/${bid}/cancel?tk=${encodeURIComponent(tk)}`, { method: "POST" });
            const d = await r.json();
            if (!r.ok) throw new Error(d.detail || `HTTP ${r.status}`);
            if (d.fee_may_apply) setFeeWarn(true);
            setMode("done");
            await load();
        } catch (e) { setError(e.message); } finally { setBusy(false); }
    }

    if (error && !data) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-brand-surface p-6" data-testid="booking-portal-error">
                <div className="max-w-md rounded-xl border border-brand-line bg-white p-8 text-center">
                    <XCircle className="w-8 h-8 text-red-500 mx-auto" />
                    <h1 className="font-display text-2xl text-brand-ink mt-3">This booking link isn't valid.</h1>
                    <p className="text-sm text-zinc-500 mt-2">It may have expired or been used already.</p>
                </div>
            </div>
        );
    }
    if (!data) {
        return <div className="min-h-screen flex items-center justify-center text-zinc-500"><Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading…</div>;
    }

    const b = data.booking;
    const isCancelled = b.status === "cancelled";

    return (
        <div className="min-h-screen bg-brand-surface" data-testid="booking-portal-page">
            <div className="max-w-2xl mx-auto py-8 md:py-16 px-4 md:px-6">
                <div className="text-xs uppercase tracking-[0.28em] text-brand-copper mb-2">Your booking</div>
                <h1 className="font-display text-3xl md:text-4xl text-brand-ink font-medium">{data.service?.name || "Appointment"}</h1>

                <div className="mt-6 rounded-2xl border border-brand-line bg-white p-5 md:p-6">
                    <div className="flex items-center gap-3 text-brand-ink">
                        <CalIcon className="w-5 h-5 text-brand-copper" />
                        <div>
                            <div className="font-medium" data-testid="booking-portal-time">{fmtDate(b.start_at)}</div>
                            <div className="text-xs text-zinc-500 mt-0.5">{data.service?.duration_minutes} min · #{b.booking_number}</div>
                        </div>
                    </div>
                    {isCancelled && (
                        <div className="mt-4 rounded-lg bg-zinc-50 border border-brand-line text-zinc-700 p-3 flex items-start gap-2" data-testid="booking-portal-cancelled-banner">
                            <XCircle className="w-4 h-4 mt-0.5" />
                            <div className="text-sm">This booking is cancelled{feeWarn ? " — the business may follow up about the late-notice policy." : "."}</div>
                        </div>
                    )}
                </div>

                {!isCancelled && mode === "idle" && (
                    <div className="mt-4 rounded-lg border border-dashed border-brand-line bg-white p-4 text-xs text-zinc-500" data-testid="booking-portal-policy">
                        <div className="flex items-center gap-2 text-brand-ink">
                            <Clock className="w-4 h-4" /> Policy
                        </div>
                        <div className="mt-1">{data.policy?.text || "Reschedule/cancel available up to 4 hours before your slot."}</div>
                    </div>
                )}

                {!isCancelled && mode === "idle" && (
                    <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <Button
                            onClick={startReschedule}
                            className="h-12 text-base bg-brand-copper hover:bg-brand-copperHover text-white"
                            data-testid="booking-portal-reschedule-btn"
                        >
                            Reschedule
                        </Button>
                        <Button
                            variant="outline"
                            onClick={cancel}
                            disabled={busy}
                            className="h-12 text-base"
                            data-testid="booking-portal-cancel-btn"
                        >
                            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                            Cancel booking
                        </Button>
                    </div>
                )}

                {mode === "rescheduling" && (
                    <div className="mt-6" data-testid="booking-portal-slots">
                        <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">Pick a new time</div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-80 overflow-y-auto">
                            {slots.map((s) => (
                                <button
                                    key={`${s.start_at}-${s.staff_id}`}
                                    onClick={() => setChosen(s)}
                                    data-testid={`booking-portal-slot-${s.start_at}`}
                                    className={`rounded-md p-2 text-left text-xs border ${chosen?.start_at === s.start_at ? "border-2 border-brand-copper bg-brand-cream/40" : "border-brand-line bg-white hover:border-brand-copper"}`}
                                >
                                    <div className="font-mono">{fmtDate(s.start_at)}</div>
                                    {s.staff_display_name && <div className="text-zinc-500 mt-0.5">{s.staff_display_name}</div>}
                                </button>
                            ))}
                            {!slots.length && <div className="col-span-3 text-xs text-zinc-500">No open times in the next 21 days. Please contact the business.</div>}
                        </div>
                        {error && <div className="mt-3 rounded-md bg-red-50 border border-red-200 text-red-800 p-3 text-sm">{error}</div>}
                        <div className="mt-4 flex gap-3">
                            <Button
                                onClick={confirmReschedule}
                                disabled={!chosen || busy}
                                className="bg-brand-copper hover:bg-brand-copperHover text-white"
                                data-testid="booking-portal-reschedule-confirm-btn"
                            >
                                {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                                Confirm new time
                            </Button>
                            <Button variant="ghost" onClick={() => { setMode("idle"); setError(null); }}>Cancel</Button>
                        </div>
                    </div>
                )}

                {mode === "done" && (
                    <div className="mt-6 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 p-4" data-testid="booking-portal-done">
                        <div className="font-medium">Done — your booking is updated.</div>
                        <div className="text-sm mt-1">A confirmation email is on its way.</div>
                    </div>
                )}
            </div>
        </div>
    );
}
