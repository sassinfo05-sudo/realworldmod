"""Round 11 — Staff operations: unified support inbox, incidents (public status page), fraud blocklist.

Mounted with its own `/api/staff/...` prefix (added via app.include_router like routes/staff.py).
Tenant-visible ticket replies live in `support_tickets.messages`; `internal_notes`, `assignee_*` and `lock`
are staff-only and are stripped from the tenant endpoints in routes/support.py.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..deps import require_staff
from ..models import User
from ..services import audit

router = APIRouter(prefix="/api/staff", tags=["staff-support"])

TICKET_STATUSES = ("open", "answered", "waiting_on_customer", "resolved", "closed")
LOCK_TTL_SEC = 60


def _oid(tid: str) -> ObjectId:
    try:
        return ObjectId(tid)
    except Exception:  # noqa: BLE001
        raise HTTPException(404, "Ticket not found")


def _lock_active(t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    lock = t.get("lock") or {}
    if not lock.get("staff_id") or not lock.get("expires_at"):
        return None
    return lock if str(lock["expires_at"]) > utc_now_iso() else None


async def _org_names(db, org_ids: List[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    oids = []
    for o in set(org_ids):
        try:
            oids.append(ObjectId(o))
        except Exception:  # noqa: BLE001
            continue
    async for o in db.organizations.find({"_id": {"$in": oids}}, {"name": 1}):
        out[str(o["_id"])] = o.get("name", "")
    return out


def _ticket_row(t: Dict[str, Any], org_name: str = "") -> Dict[str, Any]:
    msgs = t.get("messages") or []
    last = msgs[-1] if msgs else {}
    return {"id": str(t["_id"]), "org_id": t.get("org_id"), "org_name": org_name, "subject": t.get("subject"),
            "category": t.get("category"), "severity": t.get("severity"), "status": t.get("status", "open"),
            "assignee_staff_id": t.get("assignee_staff_id"), "assignee_email": t.get("assignee_email"),
            "messages_count": len(msgs), "last_author": last.get("author"), "last_preview": (last.get("text") or "")[:120],
            "internal_notes_count": len(t.get("internal_notes") or []), "lock": _lock_active(t),
            "first_response_at": t.get("first_response_at"), "created_at": t.get("created_at"), "updated_at": t.get("updated_at")}


# ---------------------------------------------------------------- unified support inbox

@router.get("/support/tickets")
async def staff_list_tickets(status: str = "", assignee: str = "", q: str = "", limit: int = 200,
                             staff: User = Depends(require_staff("tenants"))):
    db = get_db()
    flt: Dict[str, Any] = {}
    if status:
        flt["status"] = {"$in": [s for s in status.split(",") if s in TICKET_STATUSES]} if "," in status else status
    if assignee == "me":
        flt["assignee_staff_id"] = staff.id
    elif assignee == "unassigned":
        flt["assignee_staff_id"] = {"$in": [None, ""]}
    elif assignee:
        flt["assignee_staff_id"] = assignee
    if q.strip():
        import re as _re
        flt["subject"] = {"$regex": _re.escape(q.strip()[:80]), "$options": "i"}
    rows = [t async for t in db.support_tickets.find(flt).sort("updated_at", -1).limit(max(1, min(int(limit), 500)))]
    names = await _org_names(db, [t.get("org_id") for t in rows if t.get("org_id")])
    return {"tickets": [_ticket_row(t, names.get(t.get("org_id"), "")) for t in rows]}


@router.get("/support/stats")
async def staff_support_stats(days: int = 30, staff: User = Depends(require_staff("tenants"))):
    db = get_db()
    since = (datetime.now(timezone.utc) - timedelta(days=max(1, min(int(days), 365)))).isoformat()
    by_status: Dict[str, int] = {}
    async for r in db.support_tickets.aggregate([{"$group": {"_id": "$status", "n": {"$sum": 1}}}]):
        by_status[r["_id"] or "open"] = r["n"]
    unassigned = await db.support_tickets.count_documents({"status": {"$in": ["open", "answered", "waiting_on_customer"]},
                                                           "assignee_staff_id": {"$in": [None, ""]}})
    # median first-response time (minutes) over the window
    durations: List[float] = []
    async for t in db.support_tickets.find({"created_at": {"$gte": since}, "first_response_at": {"$exists": True}},
                                           {"created_at": 1, "first_response_at": 1}).limit(5000):
        try:
            a = datetime.fromisoformat(str(t["created_at"]).replace("Z", "+00:00"))
            b = datetime.fromisoformat(str(t["first_response_at"]).replace("Z", "+00:00"))
            durations.append((b - a).total_seconds() / 60)
        except Exception:  # noqa: BLE001
            continue
    durations.sort()
    median = round(durations[len(durations) // 2], 1) if durations else None
    per_assignee: List[Dict[str, Any]] = []
    async for r in db.support_tickets.aggregate([
        {"$match": {"status": {"$in": ["open", "answered", "waiting_on_customer"]}, "assignee_staff_id": {"$nin": [None, ""]}}},
        {"$group": {"_id": {"id": "$assignee_staff_id", "email": "$assignee_email"}, "n": {"$sum": 1}}}]):
        per_assignee.append({"staff_id": r["_id"].get("id"), "email": r["_id"].get("email"), "open": r["n"]})
    created = await db.support_tickets.count_documents({"created_at": {"$gte": since}})
    resolved = await db.support_tickets.count_documents({"resolved_at": {"$gte": since}})
    return {"by_status": by_status, "unassigned_open": unassigned, "median_first_response_min": median,
            "created_in_window": created, "resolved_in_window": resolved, "per_assignee": per_assignee, "days": days}


@router.get("/support/tickets/{tid}")
async def staff_get_ticket(tid: str, staff: User = Depends(require_staff("tenants"))):
    db = get_db()
    t = await db.support_tickets.find_one({"_id": _oid(tid)})
    if not t:
        raise HTTPException(404, "Ticket not found")
    names = await _org_names(db, [t.get("org_id")]) if t.get("org_id") else {}
    row = _ticket_row(t, names.get(t.get("org_id"), ""))
    row["messages"] = t.get("messages") or []
    row["internal_notes"] = t.get("internal_notes") or []
    row["history"] = t.get("history") or []
    return row


class AssignReq(BaseModel):
    staff_id: Optional[str] = None      # None/"" = unassign; "me" = current staff


@router.post("/support/tickets/{tid}/assign")
async def staff_assign(tid: str, req: AssignReq, request: Request, staff: User = Depends(require_staff("tenants"))):
    db = get_db()
    t = await db.support_tickets.find_one({"_id": _oid(tid)})
    if not t:
        raise HTTPException(404, "Ticket not found")
    sid, semail = None, None
    if req.staff_id == "me":
        sid, semail = staff.id, staff.email
    elif req.staff_id:
        acct = None
        try:
            acct = await db.staff_accounts.find_one({"_id": ObjectId(req.staff_id)})
        except Exception:  # noqa: BLE001
            acct = None
        if not acct:
            raise HTTPException(404, "Staff account not found")
        sid, semail = str(acct["_id"]), acct.get("email") or acct.get("work_email")
    now = utc_now_iso()
    await db.support_tickets.update_one({"_id": t["_id"]}, {
        "$set": {"assignee_staff_id": sid, "assignee_email": semail, "updated_at": now},
        "$push": {"history": {"at": now, "by": staff.email, "action": "assign", "detail": semail or "unassigned"}}})
    await audit.record(action="support.ticket_assign", actor_user_id=staff.id, actor_role=staff.role, actor_email=staff.email,
                       org_id=t.get("org_id"), target_type="support_ticket", target_id=tid, meta={"assignee": semail}, request=request)
    return {"ok": True, "assignee_staff_id": sid, "assignee_email": semail}


class NoteReq(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


@router.post("/support/tickets/{tid}/notes")
async def staff_add_note(tid: str, req: NoteReq, staff: User = Depends(require_staff("tenants"))):
    """Internal note — never shown to the tenant."""
    db = get_db()
    t = await db.support_tickets.find_one({"_id": _oid(tid)}, {"_id": 1})
    if not t:
        raise HTTPException(404, "Ticket not found")
    note = {"id": uuid.uuid4().hex, "staff_id": staff.id, "email": staff.email, "text": req.text.strip(), "created_at": utc_now_iso()}
    await db.support_tickets.update_one({"_id": t["_id"]}, {"$push": {"internal_notes": note}, "$set": {"updated_at": note["created_at"]}})
    return {"ok": True, "note": note}


class StaffReplyReq(BaseModel):
    text: str = Field(min_length=1, max_length=8000)
    status: Optional[str] = None       # optional status transition alongside the reply (default: answered)


@router.post("/support/tickets/{tid}/reply")
async def staff_reply(tid: str, req: StaffReplyReq, request: Request, staff: User = Depends(require_staff("tenants"))):
    """Tenant-visible reply. Refused (409) when another staff member holds the edit lock."""
    db = get_db()
    t = await db.support_tickets.find_one({"_id": _oid(tid)})
    if not t:
        raise HTTPException(404, "Ticket not found")
    lock = _lock_active(t)
    if lock and lock.get("staff_id") != staff.id:
        raise HTTPException(409, {"code": "ticket_locked", "by": lock.get("email"), "expires_at": lock.get("expires_at")})
    now = utc_now_iso()
    new_status = req.status if req.status in TICKET_STATUSES else "answered"
    sets: Dict[str, Any] = {"updated_at": now, "status": new_status}
    if not t.get("first_response_at"):
        sets["first_response_at"] = now
    if new_status in ("resolved", "closed"):
        sets["resolved_at"] = now
    if not t.get("assignee_staff_id"):
        sets["assignee_staff_id"], sets["assignee_email"] = staff.id, staff.email
    await db.support_tickets.update_one({"_id": t["_id"]}, {
        "$push": {"messages": {"author": "staff", "staff_id": staff.id, "email": staff.email, "text": req.text.strip(), "created_at": now},
                  "history": {"at": now, "by": staff.email, "action": "reply", "detail": new_status}},
        "$set": sets})
    # Notify the tenant owner (best effort; simulated until an email provider is connected).
    try:
        from ..services import platform_mail
        owner = await db.users.find_one({"_id": ObjectId(t["user_id"])}, {"email": 1}) if t.get("user_id") else None
        if owner and owner.get("email"):
            await platform_mail.send("support", owner["email"], f"Re: {t.get('subject', 'your support request')}",
                                     req.text.strip()[:4000])
    except Exception:  # noqa: BLE001
        pass
    await audit.record(action="support.ticket_reply", actor_user_id=staff.id, actor_role=staff.role, actor_email=staff.email,
                       org_id=t.get("org_id"), target_type="support_ticket", target_id=tid, meta={"status": new_status}, request=request)
    return {"ok": True, "status": new_status}


class StatusReq(BaseModel):
    status: str


@router.post("/support/tickets/{tid}/status")
async def staff_set_status(tid: str, req: StatusReq, staff: User = Depends(require_staff("tenants"))):
    if req.status not in TICKET_STATUSES:
        raise HTTPException(422, f"status must be one of {', '.join(TICKET_STATUSES)}")
    db = get_db()
    now = utc_now_iso()
    sets: Dict[str, Any] = {"status": req.status, "updated_at": now}
    if req.status in ("resolved", "closed"):
        sets["resolved_at"] = now
    r = await db.support_tickets.update_one({"_id": _oid(tid)}, {"$set": sets, "$push": {
        "history": {"at": now, "by": staff.email, "action": "status", "detail": req.status}}})
    if not r.matched_count:
        raise HTTPException(404, "Ticket not found")
    return {"ok": True, "status": req.status}


@router.post("/support/tickets/{tid}/lock")
async def staff_lock(tid: str, staff: User = Depends(require_staff("tenants"))):
    """Collision prevention: take/refresh a 60 s edit lock. 409 if someone else holds it."""
    db = get_db()
    t = await db.support_tickets.find_one({"_id": _oid(tid)}, {"lock": 1})
    if not t:
        raise HTTPException(404, "Ticket not found")
    lock = _lock_active(t)
    if lock and lock.get("staff_id") != staff.id:
        raise HTTPException(409, {"code": "ticket_locked", "by": lock.get("email"), "expires_at": lock.get("expires_at")})
    exp = (datetime.now(timezone.utc) + timedelta(seconds=LOCK_TTL_SEC)).isoformat()
    new_lock = {"staff_id": staff.id, "email": staff.email, "expires_at": exp}
    await db.support_tickets.update_one({"_id": t["_id"]}, {"$set": {"lock": new_lock}})
    return {"ok": True, "lock": new_lock}


@router.delete("/support/tickets/{tid}/lock")
async def staff_unlock(tid: str, staff: User = Depends(require_staff("tenants"))):
    db = get_db()
    await db.support_tickets.update_one({"_id": _oid(tid), "lock.staff_id": staff.id}, {"$unset": {"lock": ""}})
    return {"ok": True}


# ---------------------------------------------------------------- incidents (public status page)

INCIDENT_STATUSES = ("investigating", "identified", "monitoring", "resolved")
INCIDENT_IMPACTS = ("none", "minor", "major", "critical")


def _incident_out(d: Dict[str, Any]) -> Dict[str, Any]:
    return {"id": d["_id"], "title": d.get("title"), "status": d.get("status"), "impact": d.get("impact"),
            "components": d.get("components", []), "updates": d.get("updates", []),
            "started_at": d.get("started_at"), "resolved_at": d.get("resolved_at"), "created_at": d.get("created_at"),
            "updated_at": d.get("updated_at")}


class IncidentIn(BaseModel):
    title: str = Field(min_length=3, max_length=160)
    status: str = "investigating"
    impact: str = "minor"
    components: List[str] = Field(default_factory=list)   # e.g. ["api", "website_hosting", "email"]
    message: str = Field(default="", max_length=4000)


class IncidentUpdate(BaseModel):
    status: Optional[str] = None
    impact: Optional[str] = None
    message: str = Field(default="", max_length=4000)


@router.get("/incidents")
async def staff_list_incidents(limit: int = 50, staff: User = Depends(require_staff("health"))):
    db = get_db()
    rows = [_incident_out(d) async for d in db.incidents.find({}).sort("created_at", -1).limit(max(1, min(int(limit), 200)))]
    return {"incidents": rows}


@router.post("/incidents")
async def staff_create_incident(req: IncidentIn, request: Request, staff: User = Depends(require_staff("health"))):
    if req.status not in INCIDENT_STATUSES or req.impact not in INCIDENT_IMPACTS:
        raise HTTPException(422, "invalid status or impact")
    db = get_db()
    now = utc_now_iso()
    doc = {"_id": uuid.uuid4().hex, "title": req.title.strip(), "status": req.status, "impact": req.impact,
           "components": [c[:40] for c in req.components][:10],
           "updates": [{"at": now, "status": req.status, "message": req.message.strip(), "by": staff.email}],
           "started_at": now, "resolved_at": now if req.status == "resolved" else None,
           "created_by": staff.email, "created_at": now, "updated_at": now}
    await db.incidents.insert_one(doc)
    await audit.record(action="incident.create", actor_user_id=staff.id, actor_role=staff.role, actor_email=staff.email,
                       target_type="incident", target_id=doc["_id"], meta={"title": doc["title"]}, request=request)
    return _incident_out(doc)


@router.post("/incidents/{iid}/updates")
async def staff_update_incident(iid: str, req: IncidentUpdate, staff: User = Depends(require_staff("health"))):
    db = get_db()
    d = await db.incidents.find_one({"_id": iid})
    if not d:
        raise HTTPException(404, "Incident not found")
    if req.status and req.status not in INCIDENT_STATUSES:
        raise HTTPException(422, "invalid status")
    if req.impact and req.impact not in INCIDENT_IMPACTS:
        raise HTTPException(422, "invalid impact")
    now = utc_now_iso()
    status = req.status or d.get("status")
    sets: Dict[str, Any] = {"status": status, "updated_at": now}
    if req.impact:
        sets["impact"] = req.impact
    if status == "resolved":
        sets["resolved_at"] = now
    await db.incidents.update_one({"_id": iid}, {"$set": sets, "$push": {
        "updates": {"at": now, "status": status, "message": req.message.strip(), "by": staff.email}}})
    return _incident_out(await db.incidents.find_one({"_id": iid}))


# ---------------------------------------------------------------- fraud blocklist

BLOCK_KINDS = ("ip", "email_domain", "email")


class BlockIn(BaseModel):
    kind: str
    value: str = Field(min_length=2, max_length=200)
    reason: str = Field(default="", max_length=300)


@router.get("/fraud/blocklist")
async def staff_blocklist(staff: User = Depends(require_staff("audit"))):
    db = get_db()
    rows = [{"id": d["_id"], "kind": d.get("kind"), "value": d.get("value"), "reason": d.get("reason", ""), "active": d.get("active", True),
             "hits": int(d.get("hits", 0)), "created_by": d.get("created_by"), "created_at": d.get("created_at")}
            async for d in db.fraud_blocklist.find({}).sort("created_at", -1).limit(1000)]
    return {"entries": rows}


@router.post("/fraud/blocklist")
async def staff_block(req: BlockIn, request: Request, staff: User = Depends(require_staff("audit"))):
    if req.kind not in BLOCK_KINDS:
        raise HTTPException(422, f"kind must be one of {', '.join(BLOCK_KINDS)}")
    db = get_db()
    value = req.value.strip().lower()
    if req.kind == "email_domain":
        value = value.lstrip("@")
    if await db.fraud_blocklist.find_one({"kind": req.kind, "value": value}):
        raise HTTPException(409, "Already on the blocklist")
    doc = {"_id": uuid.uuid4().hex, "kind": req.kind, "value": value, "reason": req.reason.strip(), "active": True,
           "hits": 0, "created_by": staff.email, "created_at": utc_now_iso()}
    await db.fraud_blocklist.insert_one(doc)
    await audit.record(action="fraud.block", actor_user_id=staff.id, actor_role=staff.role, actor_email=staff.email,
                       target_type="fraud_blocklist", target_id=doc["_id"], meta={"kind": req.kind, "value": value}, request=request)
    return {"ok": True, "id": doc["_id"]}


@router.delete("/fraud/blocklist/{bid}")
async def staff_unblock(bid: str, request: Request, staff: User = Depends(require_staff("audit"))):
    db = get_db()
    r = await db.fraud_blocklist.delete_one({"_id": bid})
    if not r.deleted_count:
        raise HTTPException(404, "Entry not found")
    await audit.record(action="fraud.unblock", actor_user_id=staff.id, actor_role=staff.role, actor_email=staff.email,
                       target_type="fraud_blocklist", target_id=bid, meta={}, request=request)
    return {"ok": True}
