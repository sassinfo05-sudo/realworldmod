"""Visual workflow builder API (Round 10, Gate 5). Owner-scoped. Mounted at /api/workflows."""
from __future__ import annotations

from typing import Any, Dict, Optional

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..db import get_db, utc_now_iso
from ..services.entitlements import enforce_feature_enabled
from ..deps import current_user, require_org
from ..models import User
from ..services import workflows as wfs

router = APIRouter(prefix="/workflows", tags=["workflows"])


def _out(d: Dict[str, Any]) -> Dict[str, Any]:
    d = dict(d)
    d["id"] = str(d.pop("_id"))
    return d


def _run_out(d: Dict[str, Any]) -> Dict[str, Any]:
    d = dict(d)
    d["id"] = str(d.pop("_id"))
    ctx = d.get("context") or {}
    # never leak whole contact docs into lists
    d["context"] = {k: v for k, v in ctx.items() if k != "contact"} | ({"contact": {"id": (ctx.get("contact") or {}).get("id"),
                                                                                    "email": (ctx.get("contact") or {}).get("email"),
                                                                                    "name": (ctx.get("contact") or {}).get("name")}} if ctx.get("contact") else {})
    return d


@router.get("/catalog")
async def catalog(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return {"triggers": wfs.TRIGGERS, "node_types": wfs.NODE_TYPES,
            "templates": [{k: v for k, v in t.items()} for t in wfs.TEMPLATES]}


class WorkflowIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    trigger: str
    graph: Dict[str, Any] = Field(default_factory=lambda: {"nodes": [], "edges": []})
    settings: Dict[str, Any] = Field(default_factory=dict)   # cost_cap_usd, max_runs_per_day
    description: str = Field(default="", max_length=400)


class WorkflowPatch(BaseModel):
    name: Optional[str] = Field(default=None, max_length=120)
    trigger: Optional[str] = None
    graph: Optional[Dict[str, Any]] = None
    settings: Optional[Dict[str, Any]] = None
    description: Optional[str] = Field(default=None, max_length=400)


def _check_trigger(t: str) -> None:
    if t not in {x["key"] for x in wfs.TRIGGERS}:
        raise HTTPException(422, f"Unknown trigger '{t}'")


def _clean_settings(s: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if s.get("cost_cap_usd") is not None:
        out["cost_cap_usd"] = max(0.0, float(s.get("cost_cap_usd") or 0))
    if s.get("max_runs_per_day") is not None:
        out["max_runs_per_day"] = max(0, int(s.get("max_runs_per_day") or 0))
    return out


@router.get("")
async def list_workflows(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = await db.workflows.find({"org_id": org_id}).sort("updated_at", -1).to_list(200)
    return {"workflows": [_out(r) for r in rows]}


@router.post("", status_code=201)
async def create_workflow(req: WorkflowIn, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    await enforce_feature_enabled(org_id, "automations")
    _check_trigger(req.trigger)
    db = get_db()
    graph = req.graph if (req.graph.get("nodes")) else {"nodes": [{"id": "trigger", "type": "trigger", "config": {}, "position": {"x": 0, "y": 0}}], "edges": []}
    now = utc_now_iso()
    doc = {"org_id": org_id, "name": req.name.strip(), "description": req.description, "trigger": req.trigger, "graph": graph,
           "settings": _clean_settings(req.settings), "status": "draft", "version": 1, "versions": [],
           "stats": {"runs": 0, "completed": 0, "dead_letter": 0}, "created_by": user.id, "created_at": now, "updated_at": now}
    r = await db.workflows.insert_one(doc)
    doc["_id"] = r.inserted_id
    return _out(doc)


@router.post("/from-template/{key}", status_code=201)
async def create_from_template(key: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    await enforce_feature_enabled(org_id, "automations")
    t = next((x for x in wfs.TEMPLATES if x["key"] == key), None)
    if not t:
        raise HTTPException(404, "Template not found")
    return await create_workflow(WorkflowIn(name=t["name"], trigger=t["trigger"], graph=t["graph"], description=t["description"]),
                                 user=user, org_id=org_id)


async def _load(db, wid: str, org_id: str) -> Dict[str, Any]:
    d = await db.workflows.find_one({"_id": ObjectId(wid), "org_id": org_id})
    if not d:
        raise HTTPException(404, "Workflow not found")
    return d


@router.get("/{wid}")
async def get_workflow(wid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    return _out(await _load(get_db(), wid, org_id))


@router.get("/{wid}/ab-stats")
async def ab_stats(wid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Round 11 — per A/B-split node counts (live runs only; test runs are not counted)."""
    db = get_db()
    await _load(db, wid, org_id)
    rows = []
    async for r in db.workflow_ab_stats.find({"workflow_id": wid, "org_id": org_id}):
        a, b = int(r.get("count_a", 0)), int(r.get("count_b", 0))
        rows.append({"node_id": r["node_id"], "count_a": a, "count_b": b, "total": a + b,
                     "share_a": round(100.0 * a / (a + b), 1) if a + b else None})
    return {"workflow_id": wid, "nodes": rows}


@router.patch("/{wid}")
async def patch_workflow(wid: str, req: WorkflowPatch, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    d = await _load(db, wid, org_id)
    patch: Dict[str, Any] = {}
    if req.name is not None:
        patch["name"] = req.name.strip()
    if req.description is not None:
        patch["description"] = req.description
    if req.trigger is not None:
        _check_trigger(req.trigger)
        patch["trigger"] = req.trigger
    if req.graph is not None:
        patch["graph"] = req.graph
    if req.settings is not None:
        patch["settings"] = {**(d.get("settings") or {}), **_clean_settings(req.settings)}
    patch["updated_at"] = utc_now_iso()
    # editing a published workflow moves it back to draft until re-published (published version keeps running)
    if "graph" in patch and d.get("status") == "published":
        patch["status"] = "draft_changes"
    await db.workflows.update_one({"_id": d["_id"]}, {"$set": patch})
    return _out(await db.workflows.find_one({"_id": d["_id"]}))


@router.delete("/{wid}")
async def delete_workflow(wid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    d = await _load(db, wid, org_id)
    await db.workflows.delete_one({"_id": d["_id"]})
    await db.workflow_runs.update_many({"workflow_id": wid, "status": {"$in": ["running", "waiting", "awaiting_approval"]}},
                                       {"$set": {"status": "cancelled", "updated_at": utc_now_iso()}})
    return {"ok": True}


@router.post("/{wid}/validate")
async def validate_workflow(wid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    d = await _load(get_db(), wid, org_id)
    errs = wfs.validate_graph(d.get("graph") or {})
    return {"ok": not errs, "errors": errs}


@router.post("/{wid}/publish")
async def publish_workflow(wid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    await enforce_feature_enabled(org_id, "automations")
    db = get_db()
    d = await _load(db, wid, org_id)
    errs = wfs.validate_graph(d.get("graph") or {})
    if errs:
        raise HTTPException(422, {"error": "invalid_graph", "errors": errs})
    version = int(d.get("version") or 1) + (1 if d.get("versions") else 0)
    snap = {"version": version, "graph": d["graph"], "trigger": d["trigger"], "published_at": utc_now_iso(), "by": user.id}
    await db.workflows.update_one({"_id": d["_id"]}, {"$set": {"status": "published", "version": version, "published_at": utc_now_iso(),
                                                              "updated_at": utc_now_iso()}, "$push": {"versions": snap}})
    return _out(await db.workflows.find_one({"_id": d["_id"]}))


@router.post("/{wid}/pause")
async def pause_workflow(wid: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    d = await _load(db, wid, org_id)
    await db.workflows.update_one({"_id": d["_id"]}, {"$set": {"status": "paused", "updated_at": utc_now_iso()}})
    return _out(await db.workflows.find_one({"_id": d["_id"]}))


class TestRunReq(BaseModel):
    context: Dict[str, Any] = Field(default_factory=dict)   # e.g. {"email": "...", "contact_id": "...", "name": "..."}


@router.post("/{wid}/test-run")
async def test_run(wid: str, req: TestRunReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Dry run: walks the whole graph (delays/approvals are skipped, nothing is sent or mutated)."""
    db = get_db()
    d = await _load(db, wid, org_id)
    errs = wfs.validate_graph(d.get("graph") or {})
    if errs:
        raise HTTPException(422, {"error": "invalid_graph", "errors": errs})
    ctx = {"email": user.email, "name": user.full_name or "Test contact", **req.context}
    run = await wfs.start_run(d, ctx, test_mode=True, trigger=d.get("trigger"))
    return _run_out(run) if run.get("_id") else run


class ManualRunReq(BaseModel):
    context: Dict[str, Any] = Field(default_factory=dict)


@router.post("/{wid}/run")
async def manual_run(wid: str, req: ManualRunReq, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Real run for a specific contact/context (workflow must be published)."""
    db = get_db()
    d = await _load(db, wid, org_id)
    if d.get("status") != "published":
        raise HTTPException(400, "Publish the workflow before running it for real")
    run = await wfs.start_run(d, req.context, trigger="manual")
    return _run_out(run) if run.get("_id") else run


@router.get("/{wid}/runs")
async def runs(wid: str, status: Optional[str] = None, limit: int = 50, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    await _load(db, wid, org_id)
    q: Dict[str, Any] = {"workflow_id": wid, "org_id": org_id}
    if status:
        q["status"] = status
    rows = await db.workflow_runs.find(q).sort("created_at", -1).to_list(max(1, min(int(limit), 200)))
    return {"runs": [_run_out(r) for r in rows]}


@router.get("/runs/pending-approvals")
async def pending_approvals(user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    rows = await db.workflow_runs.find({"org_id": org_id, "status": "awaiting_approval"}).sort("updated_at", -1).to_list(100)
    return {"runs": [_run_out(r) for r in rows]}


@router.post("/runs/{run_id}/approve")
async def approve_run(run_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.workflow_runs.find_one({"_id": ObjectId(run_id), "org_id": org_id})
    if not r or r.get("status") != "awaiting_approval":
        raise HTTPException(404, "No run awaiting approval with that id")
    await db.workflow_runs.update_one({"_id": r["_id"]}, {"$set": {"status": "approved", "approved_by": user.id, "updated_at": utc_now_iso()},
                                                          "$push": {"steps": {"node_id": r.get("cursor"), "type": "approval", "ok": True,
                                                                              "result": {"approved_by": user.email}, "at": utc_now_iso()}}})
    return _run_out(await wfs.advance(r["_id"]))


@router.post("/runs/{run_id}/reject")
async def reject_run(run_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    db = get_db()
    r = await db.workflow_runs.find_one({"_id": ObjectId(run_id), "org_id": org_id})
    if not r or r.get("status") != "awaiting_approval":
        raise HTTPException(404, "No run awaiting approval with that id")
    await db.workflow_runs.update_one({"_id": r["_id"]}, {"$set": {"status": "cancelled", "rejected_by": user.id, "updated_at": utc_now_iso()}})
    return _run_out(await db.workflow_runs.find_one({"_id": r["_id"]}))


@router.post("/runs/{run_id}/retry")
async def retry_run(run_id: str, user: User = Depends(current_user), org_id: str = Depends(require_org)):
    """Replay a dead-lettered / failed run from the node where it stopped."""
    db = get_db()
    r = await db.workflow_runs.find_one({"_id": ObjectId(run_id), "org_id": org_id})
    if not r or r.get("status") not in ("dead_letter", "failed"):
        raise HTTPException(400, "Only dead-lettered or failed runs can be retried")
    await db.workflow_runs.update_one({"_id": r["_id"]}, {"$set": {"status": "running", "attempts": 0, "error": None, "updated_at": utc_now_iso()}})
    return _run_out(await wfs.advance(r["_id"]))
