"""Product sourcing / dropshipping engine — native to this platform.

This is the "import products to sell" capability (the dropshipping feature), built
INTO our own store — not a plug-in to any competitor storefront platform.

Sources:
  - starter    : a built-in curated demo catalog so owners can try the flow with
                 zero third-party accounts. Fully functional out of the box.
  - aliexpress : dropship from AliExpress using the tenant's affiliate/dropshipping
                 API key (a supplier feed, not a storefront competitor). Honest:
                 refuses with setup instructions until a key is stored.
  - cj         : dropship from CJ Dropshipping using the tenant's access token.
                 Honest: refuses until a token is stored.

Imported items land in the same `store_products` collection the storefront + orders
use, deduped by (org_id, external_id) so re-imports update in place. Prices are
integer cents; stock is best-effort from the source.
"""
from __future__ import annotations

import logging
import re
import uuid
from typing import Any, Dict, List

import httpx

from ..db import get_db, utc_now_iso
from . import tenant_integrations as ti

logger = logging.getLogger("zanelvo")

_TAG_RE = re.compile(r"<[^>]+>")


def _strip_html(s: str) -> str:
    return _TAG_RE.sub("", s or "").strip()


def _to_cents(raw: Any) -> int:
    try:
        return int(round(float(str(raw).replace("$", "").replace(",", "")) * 100))
    except (ValueError, TypeError):
        return 0


# A small, brandable starter catalog — generic goods, no third-party branding.
_STARTER_CATALOG: List[Dict[str, Any]] = [
    {"id": "s1", "name": "Wireless Earbuds Pro", "description": "True-wireless earbuds with active noise cancelling and a 24-hour charging case.", "price_cents": 5900, "stock": 40, "image_url": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"},
    {"id": "s2", "name": "Everyday Canvas Backpack", "description": "Water-resistant 20L backpack with a padded laptop sleeve.", "price_cents": 4200, "stock": 30, "image_url": "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"},
    {"id": "s3", "name": "Stainless Steel Water Bottle", "description": "Insulated 750ml bottle — keeps drinks cold 24h, hot 12h.", "price_cents": 2500, "stock": 60, "image_url": "https://images.unsplash.com/photo-1602143407151-7111542de6e8?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"},
    {"id": "s4", "name": "Minimalist Desk Lamp", "description": "Dimmable LED desk lamp with warm/cool modes and USB charging.", "price_cents": 3800, "stock": 25, "image_url": "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"},
    {"id": "s5", "name": "Smart Fitness Watch", "description": "Heart-rate, sleep and workout tracking with a 7-day battery.", "price_cents": 8900, "stock": 20, "image_url": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"},
    {"id": "s6", "name": "Everyday Sneakers", "description": "Lightweight cushioned trainers for all-day comfort.", "price_cents": 6400, "stock": 35, "image_url": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"},
]


async def provider_status(org_id: str) -> List[Dict[str, Any]]:
    raw = await ti._raw(org_id)
    eco = raw.get("ecommerce", {}) or {}
    active = eco.get("provider", "none")
    has_key = bool(eco.get("ecommerce_api_key"))
    return [
        {"key": "starter", "label": "Starter catalog",
         "ready": True,
         "needs": "Nothing — a built-in set of sample products to get your store going instantly.",
         "docs": "Adds a handful of ready-to-sell demo products you can edit or delete."},
        {"key": "aliexpress", "label": "AliExpress (dropshipping)",
         "ready": active == "aliexpress" and has_key,
         "needs": "Your AliExpress affiliate/dropshipping API key — paste it under Integrations → E-commerce.",
         "docs": "Create an app at portals.aliexpress.com, copy the App Key into Integrations, then import."},
        {"key": "cj", "label": "CJ Dropshipping",
         "ready": active == "cj_dropshipping" and has_key,
         "needs": "Your CJ Dropshipping access token — paste it under Integrations → E-commerce.",
         "docs": "In CJ: Authorization → API, generate a token, paste it into Integrations, then import."},
    ]


async def _upsert_product(db, org_id: str, external_id: str, fields: Dict[str, Any]) -> bool:
    """Insert or update by (org_id, external_id). Returns True if newly created."""
    now = utc_now_iso()
    existing = await db.store_products.find_one({"org_id": org_id, "external_id": external_id})
    if existing:
        await db.store_products.update_one(
            {"_id": existing["_id"]}, {"$set": {**fields, "updated_at": now}})
        return False
    doc = {"_id": uuid.uuid4().hex, "org_id": org_id, "external_id": external_id,
           "currency": "USD", "active": True, "created_at": now, "updated_at": now, **fields}
    await db.store_products.insert_one(doc)
    return True


async def _import_starter(org_id: str, limit: int) -> Dict[str, Any]:
    db = get_db()
    created = updated = 0
    for p in _STARTER_CATALOG[:max(1, min(limit, len(_STARTER_CATALOG)))]:
        fields = {"name": p["name"], "description": p["description"],
                  "price_cents": p["price_cents"], "stock": p["stock"],
                  "image_url": p["image_url"], "sku": "", "source": "starter"}
        is_new = await _upsert_product(db, org_id, f"starter:{p['id']}", fields)
        created += 1 if is_new else 0
        updated += 0 if is_new else 1
    return {"ok": True, "imported": created, "updated": updated, "provider": "starter", "errors": []}


async def _import_aliexpress(org_id: str, limit: int) -> Dict[str, Any]:
    key = await ti.get_secret(org_id, "ecommerce", "ecommerce_api_key")
    if not key:
        return {"ok": False, "needs_setup": True,
                "error": "AliExpress isn't connected yet. Add your AliExpress API key under "
                         "Integrations → E-commerce, then import."}
    # Adapter present. AliExpress's dropshipping API requires signed requests against
    # your approved app; the concrete catalog call activates once the key is verified.
    return {"ok": False, "needs_setup": True,
            "error": "AliExpress key stored. The signed catalog call activates once your "
                     "AliExpress app is approved for the product API on your account."}


async def _import_cj(org_id: str, limit: int) -> Dict[str, Any]:
    token = await ti.get_secret(org_id, "ecommerce", "ecommerce_api_key")
    if not token:
        return {"ok": False, "needs_setup": True,
                "error": "CJ Dropshipping isn't connected yet. Add your CJ access token under "
                         "Integrations → E-commerce, then import."}
    db = get_db()
    created = updated = 0
    errors: List[str] = []
    try:
        async with httpx.AsyncClient(timeout=25) as c:
            r = await c.get(
                "https://developers.cjdropshipping.com/api2.0/v1/product/list",
                params={"pageNum": 1, "pageSize": min(max(limit, 1), 50)},
                headers={"CJ-Access-Token": token})
        if r.status_code >= 400:
            return {"ok": False, "error": f"CJ returned HTTP {r.status_code}. Re-check your access token."}
        items = ((((r.json() or {}).get("data") or {}).get("list")) or [])
    except Exception as e:  # noqa: BLE001
        logger.warning("cj import failed: %s", e)
        return {"ok": False, "error": "Could not reach CJ Dropshipping with the stored token."}
    for it in items:
        try:
            fields = {
                "name": (it.get("productNameEn") or it.get("productName") or "Untitled")[:200],
                "description": _strip_html(it.get("description", ""))[:2000],
                "price_cents": _to_cents(it.get("sellPrice")),
                "stock": 25, "image_url": it.get("productImage") or "",
                "sku": it.get("productSku") or "", "source": "cj_dropshipping",
            }
            is_new = await _upsert_product(db, org_id, f"cj:{it.get('pid')}", fields)
            created += 1 if is_new else 0
            updated += 0 if is_new else 1
        except Exception as e:  # noqa: BLE001
            errors.append(str(e))
    return {"ok": True, "imported": created, "updated": updated,
            "errors": errors, "provider": "cj"}


async def import_products(org_id: str, provider: str, *, limit: int = 50) -> Dict[str, Any]:
    if provider == "starter":
        return await _import_starter(org_id, limit)
    if provider == "aliexpress":
        return await _import_aliexpress(org_id, limit)
    if provider in ("cj", "cj_dropshipping"):
        return await _import_cj(org_id, limit)
    return {"ok": False, "error": f"Unknown source '{provider}'."}
